package com.softexpert.ujs.davidhood.httpModule;

public interface RunanbleCallback {
    void finish(ResponseElement element);
}
