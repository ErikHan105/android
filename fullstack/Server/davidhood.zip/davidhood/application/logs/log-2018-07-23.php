<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-23 03:45:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-23 03:45:59 --> Config Class Initialized
INFO - 2018-07-23 03:45:59 --> Hooks Class Initialized
DEBUG - 2018-07-23 03:45:59 --> UTF-8 Support Enabled
INFO - 2018-07-23 03:45:59 --> Utf8 Class Initialized
INFO - 2018-07-23 03:45:59 --> URI Class Initialized
INFO - 2018-07-23 03:45:59 --> Router Class Initialized
INFO - 2018-07-23 03:45:59 --> Output Class Initialized
INFO - 2018-07-23 03:45:59 --> Security Class Initialized
DEBUG - 2018-07-23 03:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 03:45:59 --> Input Class Initialized
INFO - 2018-07-23 03:45:59 --> Language Class Initialized
INFO - 2018-07-23 03:45:59 --> Loader Class Initialized
INFO - 2018-07-23 03:45:59 --> Controller Class Initialized
INFO - 2018-07-23 03:45:59 --> Database Driver Class Initialized
INFO - 2018-07-23 03:45:59 --> Model Class Initialized
INFO - 2018-07-23 03:45:59 --> Helper loaded: url_helper
INFO - 2018-07-23 03:45:59 --> Model Class Initialized
INFO - 2018-07-23 03:45:59 --> Final output sent to browser
DEBUG - 2018-07-23 03:45:59 --> Total execution time: 0.0485
ERROR - 2018-07-23 03:49:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-23 03:49:24 --> Config Class Initialized
INFO - 2018-07-23 03:49:24 --> Hooks Class Initialized
DEBUG - 2018-07-23 03:49:24 --> UTF-8 Support Enabled
INFO - 2018-07-23 03:49:24 --> Utf8 Class Initialized
INFO - 2018-07-23 03:49:24 --> URI Class Initialized
INFO - 2018-07-23 03:49:24 --> Router Class Initialized
INFO - 2018-07-23 03:49:24 --> Output Class Initialized
INFO - 2018-07-23 03:49:24 --> Security Class Initialized
DEBUG - 2018-07-23 03:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 03:49:24 --> Input Class Initialized
INFO - 2018-07-23 03:49:24 --> Language Class Initialized
INFO - 2018-07-23 03:49:24 --> Loader Class Initialized
INFO - 2018-07-23 03:49:24 --> Controller Class Initialized
INFO - 2018-07-23 03:49:24 --> Database Driver Class Initialized
INFO - 2018-07-23 03:49:24 --> Model Class Initialized
INFO - 2018-07-23 03:49:24 --> Helper loaded: url_helper
INFO - 2018-07-23 03:49:24 --> Model Class Initialized
INFO - 2018-07-23 03:49:24 --> Final output sent to browser
DEBUG - 2018-07-23 03:49:24 --> Total execution time: 0.0340
ERROR - 2018-07-23 05:01:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-23 05:01:00 --> Config Class Initialized
INFO - 2018-07-23 05:01:00 --> Hooks Class Initialized
DEBUG - 2018-07-23 05:01:00 --> UTF-8 Support Enabled
INFO - 2018-07-23 05:01:00 --> Utf8 Class Initialized
INFO - 2018-07-23 05:01:00 --> URI Class Initialized
INFO - 2018-07-23 05:01:00 --> Router Class Initialized
INFO - 2018-07-23 05:01:00 --> Output Class Initialized
INFO - 2018-07-23 05:01:00 --> Security Class Initialized
DEBUG - 2018-07-23 05:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 05:01:00 --> Input Class Initialized
INFO - 2018-07-23 05:01:00 --> Language Class Initialized
INFO - 2018-07-23 05:01:00 --> Loader Class Initialized
INFO - 2018-07-23 05:01:00 --> Controller Class Initialized
INFO - 2018-07-23 05:01:00 --> Database Driver Class Initialized
INFO - 2018-07-23 05:01:00 --> Model Class Initialized
INFO - 2018-07-23 05:01:00 --> Helper loaded: url_helper
INFO - 2018-07-23 05:01:00 --> Model Class Initialized
ERROR - 2018-07-23 05:01:00 --> Severity: Notice --> Undefined index: user_id C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 29
ERROR - 2018-07-23 05:01:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 55
ERROR - 2018-07-23 05:01:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 21
INFO - 2018-07-23 05:01:00 --> Final output sent to browser
DEBUG - 2018-07-23 05:01:00 --> Total execution time: 0.0749
ERROR - 2018-07-23 05:01:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-23 05:01:06 --> Config Class Initialized
INFO - 2018-07-23 05:01:06 --> Hooks Class Initialized
DEBUG - 2018-07-23 05:01:06 --> UTF-8 Support Enabled
INFO - 2018-07-23 05:01:06 --> Utf8 Class Initialized
INFO - 2018-07-23 05:01:06 --> URI Class Initialized
INFO - 2018-07-23 05:01:06 --> Router Class Initialized
INFO - 2018-07-23 05:01:06 --> Output Class Initialized
INFO - 2018-07-23 05:01:06 --> Security Class Initialized
DEBUG - 2018-07-23 05:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-23 05:01:06 --> Input Class Initialized
INFO - 2018-07-23 05:01:06 --> Language Class Initialized
INFO - 2018-07-23 05:01:06 --> Loader Class Initialized
INFO - 2018-07-23 05:01:06 --> Controller Class Initialized
INFO - 2018-07-23 05:01:06 --> Database Driver Class Initialized
INFO - 2018-07-23 05:01:06 --> Model Class Initialized
INFO - 2018-07-23 05:01:06 --> Helper loaded: url_helper
INFO - 2018-07-23 05:01:06 --> Model Class Initialized
INFO - 2018-07-23 05:01:06 --> Final output sent to browser
DEBUG - 2018-07-23 05:01:06 --> Total execution time: 0.0610
