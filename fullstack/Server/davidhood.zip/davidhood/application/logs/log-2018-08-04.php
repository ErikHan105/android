<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-04 14:56:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-04 14:56:03 --> Config Class Initialized
INFO - 2018-08-04 14:56:03 --> Hooks Class Initialized
DEBUG - 2018-08-04 14:56:03 --> UTF-8 Support Enabled
INFO - 2018-08-04 14:56:03 --> Utf8 Class Initialized
INFO - 2018-08-04 14:56:03 --> URI Class Initialized
DEBUG - 2018-08-04 14:56:03 --> No URI present. Default controller set.
INFO - 2018-08-04 14:56:03 --> Router Class Initialized
INFO - 2018-08-04 14:56:03 --> Output Class Initialized
INFO - 2018-08-04 14:56:03 --> Security Class Initialized
DEBUG - 2018-08-04 14:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-04 14:56:03 --> Input Class Initialized
INFO - 2018-08-04 14:56:03 --> Language Class Initialized
INFO - 2018-08-04 14:56:03 --> Loader Class Initialized
INFO - 2018-08-04 14:56:03 --> Controller Class Initialized
INFO - 2018-08-04 14:56:03 --> Database Driver Class Initialized
INFO - 2018-08-04 14:56:03 --> Model Class Initialized
INFO - 2018-08-04 14:56:03 --> Helper loaded: url_helper
DEBUG - 2018-08-04 14:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-04 14:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-04 14:56:03 --> Model Class Initialized
INFO - 2018-08-04 14:56:03 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-04 14:56:03 --> Final output sent to browser
DEBUG - 2018-08-04 14:56:03 --> Total execution time: 0.2164
ERROR - 2018-08-04 14:56:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-04 14:56:08 --> Config Class Initialized
INFO - 2018-08-04 14:56:08 --> Hooks Class Initialized
DEBUG - 2018-08-04 14:56:08 --> UTF-8 Support Enabled
INFO - 2018-08-04 14:56:08 --> Utf8 Class Initialized
INFO - 2018-08-04 14:56:08 --> URI Class Initialized
DEBUG - 2018-08-04 14:56:08 --> No URI present. Default controller set.
INFO - 2018-08-04 14:56:08 --> Router Class Initialized
INFO - 2018-08-04 14:56:08 --> Output Class Initialized
INFO - 2018-08-04 14:56:08 --> Security Class Initialized
DEBUG - 2018-08-04 14:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-04 14:56:08 --> Input Class Initialized
INFO - 2018-08-04 14:56:08 --> Language Class Initialized
INFO - 2018-08-04 14:56:08 --> Loader Class Initialized
INFO - 2018-08-04 14:56:08 --> Controller Class Initialized
INFO - 2018-08-04 14:56:08 --> Database Driver Class Initialized
INFO - 2018-08-04 14:56:08 --> Model Class Initialized
INFO - 2018-08-04 14:56:08 --> Helper loaded: url_helper
DEBUG - 2018-08-04 14:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-04 14:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-04 14:56:09 --> Model Class Initialized
INFO - 2018-08-04 14:56:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-04 14:56:09 --> Final output sent to browser
DEBUG - 2018-08-04 14:56:09 --> Total execution time: 0.0502
ERROR - 2018-08-04 14:56:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-04 14:56:09 --> Config Class Initialized
INFO - 2018-08-04 14:56:09 --> Hooks Class Initialized
DEBUG - 2018-08-04 14:56:09 --> UTF-8 Support Enabled
INFO - 2018-08-04 14:56:09 --> Utf8 Class Initialized
INFO - 2018-08-04 14:56:09 --> URI Class Initialized
DEBUG - 2018-08-04 14:56:09 --> No URI present. Default controller set.
INFO - 2018-08-04 14:56:09 --> Router Class Initialized
INFO - 2018-08-04 14:56:09 --> Output Class Initialized
INFO - 2018-08-04 14:56:09 --> Security Class Initialized
DEBUG - 2018-08-04 14:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-04 14:56:09 --> Input Class Initialized
INFO - 2018-08-04 14:56:09 --> Language Class Initialized
INFO - 2018-08-04 14:56:09 --> Loader Class Initialized
INFO - 2018-08-04 14:56:09 --> Controller Class Initialized
INFO - 2018-08-04 14:56:09 --> Database Driver Class Initialized
INFO - 2018-08-04 14:56:09 --> Model Class Initialized
INFO - 2018-08-04 14:56:09 --> Helper loaded: url_helper
DEBUG - 2018-08-04 14:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-04 14:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-04 14:56:09 --> Model Class Initialized
INFO - 2018-08-04 14:56:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-04 14:56:09 --> Final output sent to browser
DEBUG - 2018-08-04 14:56:09 --> Total execution time: 0.0471
ERROR - 2018-08-04 14:56:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-04 14:56:10 --> Config Class Initialized
INFO - 2018-08-04 14:56:10 --> Hooks Class Initialized
DEBUG - 2018-08-04 14:56:10 --> UTF-8 Support Enabled
INFO - 2018-08-04 14:56:10 --> Utf8 Class Initialized
INFO - 2018-08-04 14:56:10 --> URI Class Initialized
INFO - 2018-08-04 14:56:10 --> Router Class Initialized
INFO - 2018-08-04 14:56:10 --> Output Class Initialized
INFO - 2018-08-04 14:56:10 --> Security Class Initialized
DEBUG - 2018-08-04 14:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-04 14:56:10 --> Input Class Initialized
INFO - 2018-08-04 14:56:10 --> Language Class Initialized
INFO - 2018-08-04 14:56:10 --> Loader Class Initialized
INFO - 2018-08-04 14:56:10 --> Controller Class Initialized
INFO - 2018-08-04 14:56:10 --> Database Driver Class Initialized
INFO - 2018-08-04 14:56:10 --> Model Class Initialized
INFO - 2018-08-04 14:56:10 --> Helper loaded: url_helper
DEBUG - 2018-08-04 14:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-04 14:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-04 14:56:10 --> Model Class Initialized
ERROR - 2018-08-04 14:56:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-04 14:56:10 --> Config Class Initialized
INFO - 2018-08-04 14:56:10 --> Hooks Class Initialized
DEBUG - 2018-08-04 14:56:10 --> UTF-8 Support Enabled
INFO - 2018-08-04 14:56:10 --> Utf8 Class Initialized
INFO - 2018-08-04 14:56:10 --> URI Class Initialized
INFO - 2018-08-04 14:56:10 --> Router Class Initialized
INFO - 2018-08-04 14:56:10 --> Output Class Initialized
INFO - 2018-08-04 14:56:10 --> Security Class Initialized
DEBUG - 2018-08-04 14:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-04 14:56:10 --> Input Class Initialized
INFO - 2018-08-04 14:56:10 --> Language Class Initialized
INFO - 2018-08-04 14:56:10 --> Loader Class Initialized
INFO - 2018-08-04 14:56:10 --> Controller Class Initialized
INFO - 2018-08-04 14:56:10 --> Database Driver Class Initialized
INFO - 2018-08-04 14:56:10 --> Model Class Initialized
INFO - 2018-08-04 14:56:10 --> Helper loaded: url_helper
DEBUG - 2018-08-04 14:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-04 14:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-04 14:56:10 --> Model Class Initialized
INFO - 2018-08-04 14:56:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-04 14:56:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-04 14:56:10 --> Final output sent to browser
DEBUG - 2018-08-04 14:56:10 --> Total execution time: 0.1160
ERROR - 2018-08-04 14:56:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-04 14:56:12 --> Config Class Initialized
INFO - 2018-08-04 14:56:12 --> Hooks Class Initialized
DEBUG - 2018-08-04 14:56:12 --> UTF-8 Support Enabled
INFO - 2018-08-04 14:56:12 --> Utf8 Class Initialized
INFO - 2018-08-04 14:56:12 --> URI Class Initialized
INFO - 2018-08-04 14:56:12 --> Router Class Initialized
INFO - 2018-08-04 14:56:12 --> Output Class Initialized
INFO - 2018-08-04 14:56:12 --> Security Class Initialized
DEBUG - 2018-08-04 14:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-04 14:56:12 --> Input Class Initialized
INFO - 2018-08-04 14:56:12 --> Language Class Initialized
INFO - 2018-08-04 14:56:12 --> Loader Class Initialized
INFO - 2018-08-04 14:56:12 --> Controller Class Initialized
INFO - 2018-08-04 14:56:12 --> Database Driver Class Initialized
INFO - 2018-08-04 14:56:12 --> Model Class Initialized
INFO - 2018-08-04 14:56:12 --> Helper loaded: url_helper
DEBUG - 2018-08-04 14:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-04 14:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-04 14:56:12 --> Model Class Initialized
INFO - 2018-08-04 14:56:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-04 14:56:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-08-04 14:56:12 --> Final output sent to browser
DEBUG - 2018-08-04 14:56:12 --> Total execution time: 0.0499
