<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-21 03:46:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 03:46:48 --> Config Class Initialized
INFO - 2017-06-21 03:46:48 --> Hooks Class Initialized
DEBUG - 2017-06-21 03:46:48 --> UTF-8 Support Enabled
INFO - 2017-06-21 03:46:48 --> Utf8 Class Initialized
INFO - 2017-06-21 03:46:48 --> URI Class Initialized
INFO - 2017-06-21 03:46:48 --> Router Class Initialized
INFO - 2017-06-21 03:46:48 --> Output Class Initialized
INFO - 2017-06-21 03:46:48 --> Security Class Initialized
DEBUG - 2017-06-21 03:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 03:46:48 --> Input Class Initialized
INFO - 2017-06-21 03:46:48 --> Language Class Initialized
INFO - 2017-06-21 03:46:48 --> Loader Class Initialized
INFO - 2017-06-21 03:46:48 --> Controller Class Initialized
INFO - 2017-06-21 03:46:48 --> Database Driver Class Initialized
INFO - 2017-06-21 03:46:48 --> Model Class Initialized
INFO - 2017-06-21 03:46:48 --> Helper loaded: form_helper
INFO - 2017-06-21 03:46:48 --> Helper loaded: url_helper
INFO - 2017-06-21 03:46:48 --> Model Class Initialized
INFO - 2017-06-21 03:46:48 --> Final output sent to browser
DEBUG - 2017-06-21 03:46:48 --> Total execution time: 0.0390
ERROR - 2017-06-21 03:46:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 03:46:49 --> Config Class Initialized
INFO - 2017-06-21 03:46:49 --> Hooks Class Initialized
DEBUG - 2017-06-21 03:46:49 --> UTF-8 Support Enabled
INFO - 2017-06-21 03:46:49 --> Utf8 Class Initialized
INFO - 2017-06-21 03:46:49 --> URI Class Initialized
INFO - 2017-06-21 03:46:49 --> Router Class Initialized
INFO - 2017-06-21 03:46:49 --> Output Class Initialized
INFO - 2017-06-21 03:46:49 --> Security Class Initialized
DEBUG - 2017-06-21 03:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 03:46:49 --> Input Class Initialized
INFO - 2017-06-21 03:46:49 --> Language Class Initialized
INFO - 2017-06-21 03:46:49 --> Loader Class Initialized
INFO - 2017-06-21 03:46:49 --> Controller Class Initialized
INFO - 2017-06-21 03:46:49 --> Database Driver Class Initialized
INFO - 2017-06-21 03:46:49 --> Model Class Initialized
INFO - 2017-06-21 03:46:49 --> Helper loaded: form_helper
INFO - 2017-06-21 03:46:49 --> Helper loaded: url_helper
INFO - 2017-06-21 03:46:49 --> Model Class Initialized
INFO - 2017-06-21 03:46:49 --> Final output sent to browser
DEBUG - 2017-06-21 03:46:49 --> Total execution time: 0.0320
ERROR - 2017-06-21 03:46:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 03:46:52 --> Config Class Initialized
INFO - 2017-06-21 03:46:52 --> Hooks Class Initialized
DEBUG - 2017-06-21 03:46:52 --> UTF-8 Support Enabled
INFO - 2017-06-21 03:46:52 --> Utf8 Class Initialized
INFO - 2017-06-21 03:46:52 --> URI Class Initialized
INFO - 2017-06-21 03:46:52 --> Router Class Initialized
INFO - 2017-06-21 03:46:52 --> Output Class Initialized
INFO - 2017-06-21 03:46:52 --> Security Class Initialized
DEBUG - 2017-06-21 03:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 03:46:52 --> Input Class Initialized
INFO - 2017-06-21 03:46:52 --> Language Class Initialized
INFO - 2017-06-21 03:46:52 --> Loader Class Initialized
INFO - 2017-06-21 03:46:52 --> Controller Class Initialized
INFO - 2017-06-21 03:46:52 --> Database Driver Class Initialized
INFO - 2017-06-21 03:46:52 --> Model Class Initialized
INFO - 2017-06-21 03:46:52 --> Helper loaded: form_helper
INFO - 2017-06-21 03:46:52 --> Helper loaded: url_helper
INFO - 2017-06-21 03:46:52 --> Model Class Initialized
INFO - 2017-06-21 03:46:52 --> Final output sent to browser
DEBUG - 2017-06-21 03:46:52 --> Total execution time: 0.0400
ERROR - 2017-06-21 09:26:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:26:25 --> Config Class Initialized
INFO - 2017-06-21 09:26:25 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:26:25 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:26:25 --> Utf8 Class Initialized
INFO - 2017-06-21 09:26:25 --> URI Class Initialized
DEBUG - 2017-06-21 09:26:25 --> No URI present. Default controller set.
INFO - 2017-06-21 09:26:25 --> Router Class Initialized
INFO - 2017-06-21 09:26:25 --> Output Class Initialized
INFO - 2017-06-21 09:26:25 --> Security Class Initialized
DEBUG - 2017-06-21 09:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:26:25 --> Input Class Initialized
INFO - 2017-06-21 09:26:25 --> Language Class Initialized
INFO - 2017-06-21 09:26:25 --> Loader Class Initialized
INFO - 2017-06-21 09:26:25 --> Controller Class Initialized
INFO - 2017-06-21 09:26:25 --> Database Driver Class Initialized
INFO - 2017-06-21 09:26:25 --> Model Class Initialized
INFO - 2017-06-21 09:26:25 --> Helper loaded: form_helper
INFO - 2017-06-21 09:26:25 --> Helper loaded: url_helper
INFO - 2017-06-21 09:26:25 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-06-21 09:26:25 --> Final output sent to browser
DEBUG - 2017-06-21 09:26:25 --> Total execution time: 0.0550
ERROR - 2017-06-21 09:26:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:26:27 --> Config Class Initialized
INFO - 2017-06-21 09:26:27 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:26:27 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:26:27 --> Utf8 Class Initialized
INFO - 2017-06-21 09:26:27 --> URI Class Initialized
INFO - 2017-06-21 09:26:27 --> Router Class Initialized
INFO - 2017-06-21 09:26:27 --> Output Class Initialized
INFO - 2017-06-21 09:26:27 --> Security Class Initialized
DEBUG - 2017-06-21 09:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:26:27 --> Input Class Initialized
INFO - 2017-06-21 09:26:27 --> Language Class Initialized
INFO - 2017-06-21 09:26:27 --> Loader Class Initialized
INFO - 2017-06-21 09:26:27 --> Controller Class Initialized
INFO - 2017-06-21 09:26:27 --> Database Driver Class Initialized
INFO - 2017-06-21 09:26:27 --> Model Class Initialized
INFO - 2017-06-21 09:26:27 --> Helper loaded: form_helper
INFO - 2017-06-21 09:26:27 --> Helper loaded: url_helper
INFO - 2017-06-21 09:26:27 --> Model Class Initialized
ERROR - 2017-06-21 09:26:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:26:27 --> Config Class Initialized
INFO - 2017-06-21 09:26:27 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:26:27 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:26:27 --> Utf8 Class Initialized
INFO - 2017-06-21 09:26:27 --> URI Class Initialized
INFO - 2017-06-21 09:26:27 --> Router Class Initialized
INFO - 2017-06-21 09:26:27 --> Output Class Initialized
INFO - 2017-06-21 09:26:27 --> Security Class Initialized
DEBUG - 2017-06-21 09:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:26:27 --> Input Class Initialized
INFO - 2017-06-21 09:26:27 --> Language Class Initialized
INFO - 2017-06-21 09:26:27 --> Loader Class Initialized
INFO - 2017-06-21 09:26:27 --> Controller Class Initialized
INFO - 2017-06-21 09:26:27 --> Database Driver Class Initialized
INFO - 2017-06-21 09:26:27 --> Model Class Initialized
INFO - 2017-06-21 09:26:27 --> Helper loaded: form_helper
INFO - 2017-06-21 09:26:27 --> Helper loaded: url_helper
INFO - 2017-06-21 09:26:27 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 09:26:27 --> Model Class Initialized
INFO - 2017-06-21 09:26:28 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-21 09:26:28 --> Final output sent to browser
DEBUG - 2017-06-21 09:26:28 --> Total execution time: 0.1410
ERROR - 2017-06-21 09:26:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:26:32 --> Config Class Initialized
INFO - 2017-06-21 09:26:32 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:26:32 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:26:32 --> Utf8 Class Initialized
INFO - 2017-06-21 09:26:32 --> URI Class Initialized
INFO - 2017-06-21 09:26:32 --> Router Class Initialized
INFO - 2017-06-21 09:26:32 --> Output Class Initialized
INFO - 2017-06-21 09:26:32 --> Security Class Initialized
DEBUG - 2017-06-21 09:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:26:32 --> Input Class Initialized
INFO - 2017-06-21 09:26:32 --> Language Class Initialized
INFO - 2017-06-21 09:26:32 --> Loader Class Initialized
INFO - 2017-06-21 09:26:32 --> Controller Class Initialized
INFO - 2017-06-21 09:26:32 --> Database Driver Class Initialized
INFO - 2017-06-21 09:26:32 --> Model Class Initialized
INFO - 2017-06-21 09:26:32 --> Helper loaded: form_helper
INFO - 2017-06-21 09:26:32 --> Helper loaded: url_helper
INFO - 2017-06-21 09:26:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 09:26:32 --> Model Class Initialized
INFO - 2017-06-21 09:26:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-21 09:26:32 --> Final output sent to browser
DEBUG - 2017-06-21 09:26:32 --> Total execution time: 0.0480
ERROR - 2017-06-21 09:26:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:26:54 --> Config Class Initialized
INFO - 2017-06-21 09:26:54 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:26:54 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:26:54 --> Utf8 Class Initialized
INFO - 2017-06-21 09:26:54 --> URI Class Initialized
INFO - 2017-06-21 09:26:54 --> Router Class Initialized
INFO - 2017-06-21 09:26:54 --> Output Class Initialized
INFO - 2017-06-21 09:26:54 --> Security Class Initialized
DEBUG - 2017-06-21 09:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:26:54 --> Input Class Initialized
INFO - 2017-06-21 09:26:54 --> Language Class Initialized
INFO - 2017-06-21 09:26:54 --> Loader Class Initialized
INFO - 2017-06-21 09:26:54 --> Controller Class Initialized
INFO - 2017-06-21 09:26:54 --> Database Driver Class Initialized
INFO - 2017-06-21 09:26:54 --> Model Class Initialized
INFO - 2017-06-21 09:26:54 --> Helper loaded: form_helper
INFO - 2017-06-21 09:26:54 --> Helper loaded: url_helper
INFO - 2017-06-21 09:26:54 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 09:26:54 --> Model Class Initialized
INFO - 2017-06-21 09:26:54 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-21 09:26:54 --> Final output sent to browser
DEBUG - 2017-06-21 09:26:54 --> Total execution time: 0.0400
ERROR - 2017-06-21 09:27:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:27:04 --> Config Class Initialized
INFO - 2017-06-21 09:27:04 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:27:04 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:27:04 --> Utf8 Class Initialized
INFO - 2017-06-21 09:27:04 --> URI Class Initialized
INFO - 2017-06-21 09:27:04 --> Router Class Initialized
INFO - 2017-06-21 09:27:04 --> Output Class Initialized
INFO - 2017-06-21 09:27:04 --> Security Class Initialized
DEBUG - 2017-06-21 09:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:27:04 --> Input Class Initialized
INFO - 2017-06-21 09:27:04 --> Language Class Initialized
INFO - 2017-06-21 09:27:04 --> Loader Class Initialized
INFO - 2017-06-21 09:27:04 --> Controller Class Initialized
INFO - 2017-06-21 09:27:04 --> Database Driver Class Initialized
INFO - 2017-06-21 09:27:04 --> Model Class Initialized
INFO - 2017-06-21 09:27:04 --> Helper loaded: form_helper
INFO - 2017-06-21 09:27:04 --> Helper loaded: url_helper
INFO - 2017-06-21 09:27:05 --> Upload Class Initialized
INFO - 2017-06-21 09:27:05 --> Final output sent to browser
DEBUG - 2017-06-21 09:27:05 --> Total execution time: 0.0740
ERROR - 2017-06-21 09:27:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:27:37 --> Config Class Initialized
INFO - 2017-06-21 09:27:37 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:27:37 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:27:37 --> Utf8 Class Initialized
INFO - 2017-06-21 09:27:37 --> URI Class Initialized
INFO - 2017-06-21 09:27:37 --> Router Class Initialized
INFO - 2017-06-21 09:27:37 --> Output Class Initialized
INFO - 2017-06-21 09:27:37 --> Security Class Initialized
DEBUG - 2017-06-21 09:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:27:37 --> Input Class Initialized
INFO - 2017-06-21 09:27:37 --> Language Class Initialized
INFO - 2017-06-21 09:27:37 --> Loader Class Initialized
INFO - 2017-06-21 09:27:37 --> Controller Class Initialized
INFO - 2017-06-21 09:27:37 --> Database Driver Class Initialized
INFO - 2017-06-21 09:27:37 --> Model Class Initialized
INFO - 2017-06-21 09:27:37 --> Helper loaded: form_helper
INFO - 2017-06-21 09:27:37 --> Helper loaded: url_helper
INFO - 2017-06-21 09:27:37 --> Upload Class Initialized
INFO - 2017-06-21 09:27:37 --> Final output sent to browser
DEBUG - 2017-06-21 09:27:37 --> Total execution time: 0.0450
ERROR - 2017-06-21 09:28:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:28:00 --> Config Class Initialized
INFO - 2017-06-21 09:28:00 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:28:00 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:28:00 --> Utf8 Class Initialized
INFO - 2017-06-21 09:28:00 --> URI Class Initialized
INFO - 2017-06-21 09:28:00 --> Router Class Initialized
INFO - 2017-06-21 09:28:00 --> Output Class Initialized
INFO - 2017-06-21 09:28:00 --> Security Class Initialized
DEBUG - 2017-06-21 09:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:28:00 --> Input Class Initialized
INFO - 2017-06-21 09:28:00 --> Language Class Initialized
INFO - 2017-06-21 09:28:00 --> Loader Class Initialized
INFO - 2017-06-21 09:28:00 --> Controller Class Initialized
INFO - 2017-06-21 09:28:00 --> Database Driver Class Initialized
INFO - 2017-06-21 09:28:00 --> Model Class Initialized
INFO - 2017-06-21 09:28:00 --> Helper loaded: form_helper
INFO - 2017-06-21 09:28:00 --> Helper loaded: url_helper
INFO - 2017-06-21 09:28:00 --> Upload Class Initialized
INFO - 2017-06-21 09:28:00 --> Final output sent to browser
DEBUG - 2017-06-21 09:28:00 --> Total execution time: 0.1640
ERROR - 2017-06-21 09:28:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:28:00 --> Config Class Initialized
INFO - 2017-06-21 09:28:00 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:28:00 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:28:00 --> Utf8 Class Initialized
INFO - 2017-06-21 09:28:00 --> URI Class Initialized
INFO - 2017-06-21 09:28:00 --> Router Class Initialized
INFO - 2017-06-21 09:28:00 --> Output Class Initialized
INFO - 2017-06-21 09:28:00 --> Security Class Initialized
DEBUG - 2017-06-21 09:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:28:00 --> Input Class Initialized
INFO - 2017-06-21 09:28:00 --> Language Class Initialized
INFO - 2017-06-21 09:28:00 --> Loader Class Initialized
INFO - 2017-06-21 09:28:00 --> Controller Class Initialized
INFO - 2017-06-21 09:28:00 --> Database Driver Class Initialized
INFO - 2017-06-21 09:28:00 --> Model Class Initialized
INFO - 2017-06-21 09:28:00 --> Helper loaded: form_helper
INFO - 2017-06-21 09:28:00 --> Helper loaded: url_helper
INFO - 2017-06-21 09:28:00 --> Upload Class Initialized
INFO - 2017-06-21 09:28:00 --> Final output sent to browser
DEBUG - 2017-06-21 09:28:00 --> Total execution time: 0.0710
ERROR - 2017-06-21 09:28:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:28:00 --> Config Class Initialized
INFO - 2017-06-21 09:28:00 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:28:00 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:28:00 --> Utf8 Class Initialized
INFO - 2017-06-21 09:28:00 --> URI Class Initialized
INFO - 2017-06-21 09:28:00 --> Router Class Initialized
INFO - 2017-06-21 09:28:00 --> Output Class Initialized
INFO - 2017-06-21 09:28:00 --> Security Class Initialized
DEBUG - 2017-06-21 09:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:28:00 --> Input Class Initialized
INFO - 2017-06-21 09:28:00 --> Language Class Initialized
INFO - 2017-06-21 09:28:00 --> Loader Class Initialized
INFO - 2017-06-21 09:28:00 --> Controller Class Initialized
INFO - 2017-06-21 09:28:00 --> Database Driver Class Initialized
INFO - 2017-06-21 09:28:00 --> Model Class Initialized
INFO - 2017-06-21 09:28:00 --> Helper loaded: form_helper
INFO - 2017-06-21 09:28:00 --> Helper loaded: url_helper
INFO - 2017-06-21 09:28:00 --> Upload Class Initialized
INFO - 2017-06-21 09:28:01 --> Final output sent to browser
DEBUG - 2017-06-21 09:28:01 --> Total execution time: 0.0720
ERROR - 2017-06-21 09:28:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:28:01 --> Config Class Initialized
INFO - 2017-06-21 09:28:01 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:28:01 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:28:01 --> Utf8 Class Initialized
INFO - 2017-06-21 09:28:01 --> URI Class Initialized
INFO - 2017-06-21 09:28:01 --> Router Class Initialized
INFO - 2017-06-21 09:28:01 --> Output Class Initialized
INFO - 2017-06-21 09:28:01 --> Security Class Initialized
DEBUG - 2017-06-21 09:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:28:01 --> Input Class Initialized
INFO - 2017-06-21 09:28:01 --> Language Class Initialized
INFO - 2017-06-21 09:28:01 --> Loader Class Initialized
INFO - 2017-06-21 09:28:01 --> Controller Class Initialized
INFO - 2017-06-21 09:28:01 --> Database Driver Class Initialized
INFO - 2017-06-21 09:28:01 --> Model Class Initialized
INFO - 2017-06-21 09:28:01 --> Helper loaded: form_helper
INFO - 2017-06-21 09:28:01 --> Helper loaded: url_helper
INFO - 2017-06-21 09:28:01 --> Upload Class Initialized
INFO - 2017-06-21 09:28:01 --> Final output sent to browser
DEBUG - 2017-06-21 09:28:01 --> Total execution time: 0.0600
ERROR - 2017-06-21 09:28:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:28:01 --> Config Class Initialized
INFO - 2017-06-21 09:28:01 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:28:01 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:28:01 --> Utf8 Class Initialized
INFO - 2017-06-21 09:28:01 --> URI Class Initialized
INFO - 2017-06-21 09:28:01 --> Router Class Initialized
INFO - 2017-06-21 09:28:01 --> Output Class Initialized
INFO - 2017-06-21 09:28:01 --> Security Class Initialized
DEBUG - 2017-06-21 09:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:28:01 --> Input Class Initialized
INFO - 2017-06-21 09:28:01 --> Language Class Initialized
INFO - 2017-06-21 09:28:01 --> Loader Class Initialized
INFO - 2017-06-21 09:28:01 --> Controller Class Initialized
INFO - 2017-06-21 09:28:01 --> Database Driver Class Initialized
INFO - 2017-06-21 09:28:01 --> Model Class Initialized
INFO - 2017-06-21 09:28:01 --> Helper loaded: form_helper
INFO - 2017-06-21 09:28:01 --> Helper loaded: url_helper
INFO - 2017-06-21 09:28:01 --> Upload Class Initialized
INFO - 2017-06-21 09:28:01 --> Final output sent to browser
DEBUG - 2017-06-21 09:28:01 --> Total execution time: 0.1040
ERROR - 2017-06-21 09:28:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:28:02 --> Config Class Initialized
INFO - 2017-06-21 09:28:02 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:28:02 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:28:02 --> Utf8 Class Initialized
INFO - 2017-06-21 09:28:02 --> URI Class Initialized
INFO - 2017-06-21 09:28:02 --> Router Class Initialized
INFO - 2017-06-21 09:28:02 --> Output Class Initialized
INFO - 2017-06-21 09:28:02 --> Security Class Initialized
DEBUG - 2017-06-21 09:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:28:02 --> Input Class Initialized
INFO - 2017-06-21 09:28:02 --> Language Class Initialized
INFO - 2017-06-21 09:28:02 --> Loader Class Initialized
INFO - 2017-06-21 09:28:02 --> Controller Class Initialized
INFO - 2017-06-21 09:28:02 --> Database Driver Class Initialized
INFO - 2017-06-21 09:28:02 --> Model Class Initialized
INFO - 2017-06-21 09:28:02 --> Helper loaded: form_helper
INFO - 2017-06-21 09:28:02 --> Helper loaded: url_helper
INFO - 2017-06-21 09:28:02 --> Upload Class Initialized
INFO - 2017-06-21 09:28:02 --> Final output sent to browser
DEBUG - 2017-06-21 09:28:02 --> Total execution time: 0.0780
ERROR - 2017-06-21 09:28:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:28:02 --> Config Class Initialized
INFO - 2017-06-21 09:28:02 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:28:02 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:28:02 --> Utf8 Class Initialized
INFO - 2017-06-21 09:28:02 --> URI Class Initialized
INFO - 2017-06-21 09:28:02 --> Router Class Initialized
INFO - 2017-06-21 09:28:02 --> Output Class Initialized
INFO - 2017-06-21 09:28:02 --> Security Class Initialized
DEBUG - 2017-06-21 09:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:28:02 --> Input Class Initialized
INFO - 2017-06-21 09:28:02 --> Language Class Initialized
INFO - 2017-06-21 09:28:02 --> Loader Class Initialized
INFO - 2017-06-21 09:28:02 --> Controller Class Initialized
INFO - 2017-06-21 09:28:02 --> Database Driver Class Initialized
INFO - 2017-06-21 09:28:02 --> Model Class Initialized
INFO - 2017-06-21 09:28:02 --> Helper loaded: form_helper
INFO - 2017-06-21 09:28:02 --> Helper loaded: url_helper
INFO - 2017-06-21 09:28:02 --> Upload Class Initialized
INFO - 2017-06-21 09:28:02 --> Final output sent to browser
DEBUG - 2017-06-21 09:28:02 --> Total execution time: 0.0670
ERROR - 2017-06-21 09:28:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:28:02 --> Config Class Initialized
INFO - 2017-06-21 09:28:02 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:28:02 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:28:02 --> Utf8 Class Initialized
INFO - 2017-06-21 09:28:02 --> URI Class Initialized
INFO - 2017-06-21 09:28:02 --> Router Class Initialized
INFO - 2017-06-21 09:28:02 --> Output Class Initialized
INFO - 2017-06-21 09:28:02 --> Security Class Initialized
DEBUG - 2017-06-21 09:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:28:02 --> Input Class Initialized
INFO - 2017-06-21 09:28:02 --> Language Class Initialized
INFO - 2017-06-21 09:28:02 --> Loader Class Initialized
INFO - 2017-06-21 09:28:02 --> Controller Class Initialized
INFO - 2017-06-21 09:28:02 --> Database Driver Class Initialized
INFO - 2017-06-21 09:28:03 --> Model Class Initialized
INFO - 2017-06-21 09:28:03 --> Helper loaded: form_helper
INFO - 2017-06-21 09:28:03 --> Helper loaded: url_helper
INFO - 2017-06-21 09:28:03 --> Upload Class Initialized
INFO - 2017-06-21 09:28:03 --> Final output sent to browser
DEBUG - 2017-06-21 09:28:03 --> Total execution time: 0.0750
ERROR - 2017-06-21 09:28:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:28:03 --> Config Class Initialized
INFO - 2017-06-21 09:28:03 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:28:03 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:28:03 --> Utf8 Class Initialized
INFO - 2017-06-21 09:28:03 --> URI Class Initialized
INFO - 2017-06-21 09:28:03 --> Router Class Initialized
INFO - 2017-06-21 09:28:03 --> Output Class Initialized
INFO - 2017-06-21 09:28:03 --> Security Class Initialized
DEBUG - 2017-06-21 09:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:28:03 --> Input Class Initialized
INFO - 2017-06-21 09:28:03 --> Language Class Initialized
INFO - 2017-06-21 09:28:03 --> Loader Class Initialized
INFO - 2017-06-21 09:28:03 --> Controller Class Initialized
INFO - 2017-06-21 09:28:03 --> Database Driver Class Initialized
INFO - 2017-06-21 09:28:03 --> Model Class Initialized
INFO - 2017-06-21 09:28:03 --> Helper loaded: form_helper
INFO - 2017-06-21 09:28:03 --> Helper loaded: url_helper
INFO - 2017-06-21 09:28:03 --> Upload Class Initialized
INFO - 2017-06-21 09:28:03 --> Final output sent to browser
DEBUG - 2017-06-21 09:28:03 --> Total execution time: 0.0840
ERROR - 2017-06-21 09:28:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:28:03 --> Config Class Initialized
INFO - 2017-06-21 09:28:03 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:28:03 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:28:03 --> Utf8 Class Initialized
INFO - 2017-06-21 09:28:03 --> URI Class Initialized
INFO - 2017-06-21 09:28:03 --> Router Class Initialized
INFO - 2017-06-21 09:28:03 --> Output Class Initialized
INFO - 2017-06-21 09:28:03 --> Security Class Initialized
DEBUG - 2017-06-21 09:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:28:03 --> Input Class Initialized
INFO - 2017-06-21 09:28:03 --> Language Class Initialized
INFO - 2017-06-21 09:28:03 --> Loader Class Initialized
INFO - 2017-06-21 09:28:03 --> Controller Class Initialized
INFO - 2017-06-21 09:28:03 --> Database Driver Class Initialized
INFO - 2017-06-21 09:28:03 --> Model Class Initialized
INFO - 2017-06-21 09:28:03 --> Helper loaded: form_helper
INFO - 2017-06-21 09:28:03 --> Helper loaded: url_helper
INFO - 2017-06-21 09:28:03 --> Upload Class Initialized
INFO - 2017-06-21 09:28:03 --> Final output sent to browser
DEBUG - 2017-06-21 09:28:03 --> Total execution time: 0.0650
ERROR - 2017-06-21 09:28:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:28:06 --> Config Class Initialized
INFO - 2017-06-21 09:28:06 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:28:06 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:28:06 --> Utf8 Class Initialized
INFO - 2017-06-21 09:28:06 --> URI Class Initialized
INFO - 2017-06-21 09:28:06 --> Router Class Initialized
INFO - 2017-06-21 09:28:06 --> Output Class Initialized
INFO - 2017-06-21 09:28:06 --> Security Class Initialized
DEBUG - 2017-06-21 09:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:28:06 --> Input Class Initialized
INFO - 2017-06-21 09:28:06 --> Language Class Initialized
INFO - 2017-06-21 09:28:06 --> Loader Class Initialized
INFO - 2017-06-21 09:28:06 --> Controller Class Initialized
INFO - 2017-06-21 09:28:06 --> Database Driver Class Initialized
INFO - 2017-06-21 09:28:06 --> Model Class Initialized
INFO - 2017-06-21 09:28:06 --> Helper loaded: form_helper
INFO - 2017-06-21 09:28:06 --> Helper loaded: url_helper
INFO - 2017-06-21 09:28:06 --> Model Class Initialized
INFO - 2017-06-21 09:28:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 09:28:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-21 09:28:06 --> Final output sent to browser
DEBUG - 2017-06-21 09:28:06 --> Total execution time: 0.2500
ERROR - 2017-06-21 09:28:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:28:14 --> Config Class Initialized
INFO - 2017-06-21 09:28:14 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:28:14 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:28:14 --> Utf8 Class Initialized
INFO - 2017-06-21 09:28:14 --> URI Class Initialized
INFO - 2017-06-21 09:28:14 --> Router Class Initialized
INFO - 2017-06-21 09:28:14 --> Output Class Initialized
INFO - 2017-06-21 09:28:14 --> Security Class Initialized
DEBUG - 2017-06-21 09:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:28:14 --> Input Class Initialized
INFO - 2017-06-21 09:28:14 --> Language Class Initialized
INFO - 2017-06-21 09:28:14 --> Loader Class Initialized
INFO - 2017-06-21 09:28:14 --> Controller Class Initialized
INFO - 2017-06-21 09:28:14 --> Database Driver Class Initialized
INFO - 2017-06-21 09:28:14 --> Model Class Initialized
INFO - 2017-06-21 09:28:14 --> Helper loaded: form_helper
INFO - 2017-06-21 09:28:14 --> Helper loaded: url_helper
INFO - 2017-06-21 09:28:14 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 09:28:14 --> Model Class Initialized
INFO - 2017-06-21 09:28:14 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-21 09:28:14 --> Final output sent to browser
DEBUG - 2017-06-21 09:28:14 --> Total execution time: 0.0480
ERROR - 2017-06-21 09:28:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:28:17 --> Config Class Initialized
INFO - 2017-06-21 09:28:17 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:28:17 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:28:17 --> Utf8 Class Initialized
INFO - 2017-06-21 09:28:17 --> URI Class Initialized
INFO - 2017-06-21 09:28:17 --> Router Class Initialized
INFO - 2017-06-21 09:28:17 --> Output Class Initialized
INFO - 2017-06-21 09:28:17 --> Security Class Initialized
DEBUG - 2017-06-21 09:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:28:17 --> Input Class Initialized
INFO - 2017-06-21 09:28:17 --> Language Class Initialized
INFO - 2017-06-21 09:28:17 --> Loader Class Initialized
INFO - 2017-06-21 09:28:17 --> Controller Class Initialized
INFO - 2017-06-21 09:28:17 --> Database Driver Class Initialized
INFO - 2017-06-21 09:28:17 --> Model Class Initialized
INFO - 2017-06-21 09:28:17 --> Helper loaded: form_helper
INFO - 2017-06-21 09:28:17 --> Helper loaded: url_helper
INFO - 2017-06-21 09:28:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 09:28:17 --> Model Class Initialized
INFO - 2017-06-21 09:28:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\purchase.php
INFO - 2017-06-21 09:28:17 --> Final output sent to browser
DEBUG - 2017-06-21 09:28:17 --> Total execution time: 0.1920
ERROR - 2017-06-21 09:32:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:32:54 --> Config Class Initialized
INFO - 2017-06-21 09:32:54 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:32:54 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:32:54 --> Utf8 Class Initialized
INFO - 2017-06-21 09:32:54 --> URI Class Initialized
INFO - 2017-06-21 09:32:54 --> Router Class Initialized
INFO - 2017-06-21 09:32:54 --> Output Class Initialized
INFO - 2017-06-21 09:32:54 --> Security Class Initialized
DEBUG - 2017-06-21 09:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:32:54 --> Input Class Initialized
INFO - 2017-06-21 09:32:54 --> Language Class Initialized
INFO - 2017-06-21 09:32:54 --> Loader Class Initialized
INFO - 2017-06-21 09:32:54 --> Controller Class Initialized
INFO - 2017-06-21 09:32:54 --> Database Driver Class Initialized
INFO - 2017-06-21 09:32:54 --> Model Class Initialized
INFO - 2017-06-21 09:32:54 --> Helper loaded: form_helper
INFO - 2017-06-21 09:32:54 --> Helper loaded: url_helper
INFO - 2017-06-21 09:32:54 --> Model Class Initialized
INFO - 2017-06-21 09:32:54 --> Final output sent to browser
DEBUG - 2017-06-21 09:32:54 --> Total execution time: 0.0550
ERROR - 2017-06-21 09:32:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:32:55 --> Config Class Initialized
INFO - 2017-06-21 09:32:55 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:32:55 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:32:55 --> Utf8 Class Initialized
INFO - 2017-06-21 09:32:55 --> URI Class Initialized
INFO - 2017-06-21 09:32:55 --> Router Class Initialized
INFO - 2017-06-21 09:32:55 --> Output Class Initialized
INFO - 2017-06-21 09:32:55 --> Security Class Initialized
DEBUG - 2017-06-21 09:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:32:55 --> Input Class Initialized
INFO - 2017-06-21 09:32:55 --> Language Class Initialized
INFO - 2017-06-21 09:32:55 --> Loader Class Initialized
INFO - 2017-06-21 09:32:55 --> Controller Class Initialized
INFO - 2017-06-21 09:32:55 --> Database Driver Class Initialized
INFO - 2017-06-21 09:32:55 --> Model Class Initialized
INFO - 2017-06-21 09:32:55 --> Helper loaded: form_helper
INFO - 2017-06-21 09:32:55 --> Helper loaded: url_helper
INFO - 2017-06-21 09:32:55 --> Model Class Initialized
INFO - 2017-06-21 09:32:55 --> Final output sent to browser
DEBUG - 2017-06-21 09:32:55 --> Total execution time: 0.0550
ERROR - 2017-06-21 09:33:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:33:28 --> Config Class Initialized
INFO - 2017-06-21 09:33:28 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:33:28 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:33:28 --> Utf8 Class Initialized
INFO - 2017-06-21 09:33:28 --> URI Class Initialized
INFO - 2017-06-21 09:33:28 --> Router Class Initialized
INFO - 2017-06-21 09:33:28 --> Output Class Initialized
INFO - 2017-06-21 09:33:28 --> Security Class Initialized
DEBUG - 2017-06-21 09:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:33:28 --> Input Class Initialized
INFO - 2017-06-21 09:33:28 --> Language Class Initialized
INFO - 2017-06-21 09:33:28 --> Loader Class Initialized
INFO - 2017-06-21 09:33:28 --> Controller Class Initialized
INFO - 2017-06-21 09:33:28 --> Database Driver Class Initialized
INFO - 2017-06-21 09:33:28 --> Model Class Initialized
INFO - 2017-06-21 09:33:28 --> Helper loaded: form_helper
INFO - 2017-06-21 09:33:28 --> Helper loaded: url_helper
INFO - 2017-06-21 09:33:28 --> Model Class Initialized
INFO - 2017-06-21 09:33:29 --> Final output sent to browser
DEBUG - 2017-06-21 09:33:29 --> Total execution time: 0.0850
ERROR - 2017-06-21 09:33:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:33:29 --> Config Class Initialized
INFO - 2017-06-21 09:33:29 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:33:29 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:33:29 --> Utf8 Class Initialized
INFO - 2017-06-21 09:33:29 --> URI Class Initialized
INFO - 2017-06-21 09:33:29 --> Router Class Initialized
INFO - 2017-06-21 09:33:29 --> Output Class Initialized
INFO - 2017-06-21 09:33:29 --> Security Class Initialized
DEBUG - 2017-06-21 09:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:33:29 --> Input Class Initialized
INFO - 2017-06-21 09:33:29 --> Language Class Initialized
INFO - 2017-06-21 09:33:29 --> Loader Class Initialized
INFO - 2017-06-21 09:33:29 --> Controller Class Initialized
INFO - 2017-06-21 09:33:29 --> Database Driver Class Initialized
INFO - 2017-06-21 09:33:29 --> Model Class Initialized
INFO - 2017-06-21 09:33:29 --> Helper loaded: form_helper
INFO - 2017-06-21 09:33:29 --> Helper loaded: url_helper
INFO - 2017-06-21 09:33:29 --> Model Class Initialized
INFO - 2017-06-21 09:33:29 --> Final output sent to browser
DEBUG - 2017-06-21 09:33:29 --> Total execution time: 0.0550
ERROR - 2017-06-21 09:33:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:33:31 --> Config Class Initialized
INFO - 2017-06-21 09:33:31 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:33:31 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:33:31 --> Utf8 Class Initialized
INFO - 2017-06-21 09:33:31 --> URI Class Initialized
INFO - 2017-06-21 09:33:31 --> Router Class Initialized
INFO - 2017-06-21 09:33:31 --> Output Class Initialized
INFO - 2017-06-21 09:33:31 --> Security Class Initialized
DEBUG - 2017-06-21 09:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:33:31 --> Input Class Initialized
INFO - 2017-06-21 09:33:31 --> Language Class Initialized
INFO - 2017-06-21 09:33:31 --> Loader Class Initialized
INFO - 2017-06-21 09:33:31 --> Controller Class Initialized
INFO - 2017-06-21 09:33:31 --> Database Driver Class Initialized
INFO - 2017-06-21 09:33:31 --> Model Class Initialized
INFO - 2017-06-21 09:33:31 --> Helper loaded: form_helper
INFO - 2017-06-21 09:33:31 --> Helper loaded: url_helper
INFO - 2017-06-21 09:33:31 --> Model Class Initialized
INFO - 2017-06-21 09:33:31 --> Final output sent to browser
DEBUG - 2017-06-21 09:33:31 --> Total execution time: 0.0425
ERROR - 2017-06-21 09:35:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:35:19 --> Config Class Initialized
INFO - 2017-06-21 09:35:19 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:35:19 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:35:19 --> Utf8 Class Initialized
INFO - 2017-06-21 09:35:19 --> URI Class Initialized
INFO - 2017-06-21 09:35:19 --> Router Class Initialized
INFO - 2017-06-21 09:35:19 --> Output Class Initialized
INFO - 2017-06-21 09:35:19 --> Security Class Initialized
DEBUG - 2017-06-21 09:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:35:19 --> Input Class Initialized
INFO - 2017-06-21 09:35:19 --> Language Class Initialized
INFO - 2017-06-21 09:35:19 --> Loader Class Initialized
INFO - 2017-06-21 09:35:19 --> Controller Class Initialized
INFO - 2017-06-21 09:35:19 --> Database Driver Class Initialized
INFO - 2017-06-21 09:35:19 --> Model Class Initialized
INFO - 2017-06-21 09:35:19 --> Helper loaded: form_helper
INFO - 2017-06-21 09:35:19 --> Helper loaded: url_helper
INFO - 2017-06-21 09:35:19 --> Model Class Initialized
INFO - 2017-06-21 09:35:19 --> Final output sent to browser
DEBUG - 2017-06-21 09:35:19 --> Total execution time: 0.0475
ERROR - 2017-06-21 09:35:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:35:20 --> Config Class Initialized
INFO - 2017-06-21 09:35:20 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:35:20 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:35:20 --> Utf8 Class Initialized
INFO - 2017-06-21 09:35:20 --> URI Class Initialized
INFO - 2017-06-21 09:35:20 --> Router Class Initialized
INFO - 2017-06-21 09:35:20 --> Output Class Initialized
INFO - 2017-06-21 09:35:20 --> Security Class Initialized
DEBUG - 2017-06-21 09:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:35:20 --> Input Class Initialized
INFO - 2017-06-21 09:35:20 --> Language Class Initialized
INFO - 2017-06-21 09:35:20 --> Loader Class Initialized
INFO - 2017-06-21 09:35:20 --> Controller Class Initialized
INFO - 2017-06-21 09:35:20 --> Database Driver Class Initialized
INFO - 2017-06-21 09:35:20 --> Model Class Initialized
INFO - 2017-06-21 09:35:20 --> Helper loaded: form_helper
INFO - 2017-06-21 09:35:20 --> Helper loaded: url_helper
INFO - 2017-06-21 09:35:20 --> Model Class Initialized
INFO - 2017-06-21 09:35:20 --> Final output sent to browser
DEBUG - 2017-06-21 09:35:20 --> Total execution time: 0.0585
ERROR - 2017-06-21 09:36:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:36:30 --> Config Class Initialized
INFO - 2017-06-21 09:36:30 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:36:30 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:36:30 --> Utf8 Class Initialized
INFO - 2017-06-21 09:36:30 --> URI Class Initialized
INFO - 2017-06-21 09:36:30 --> Router Class Initialized
INFO - 2017-06-21 09:36:30 --> Output Class Initialized
INFO - 2017-06-21 09:36:30 --> Security Class Initialized
DEBUG - 2017-06-21 09:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:36:30 --> Input Class Initialized
INFO - 2017-06-21 09:36:30 --> Language Class Initialized
INFO - 2017-06-21 09:36:30 --> Loader Class Initialized
INFO - 2017-06-21 09:36:30 --> Controller Class Initialized
INFO - 2017-06-21 09:36:30 --> Database Driver Class Initialized
INFO - 2017-06-21 09:36:30 --> Model Class Initialized
INFO - 2017-06-21 09:36:30 --> Helper loaded: form_helper
INFO - 2017-06-21 09:36:30 --> Helper loaded: url_helper
INFO - 2017-06-21 09:36:30 --> Model Class Initialized
INFO - 2017-06-21 09:36:30 --> Final output sent to browser
DEBUG - 2017-06-21 09:36:30 --> Total execution time: 0.0550
ERROR - 2017-06-21 09:36:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:36:34 --> Config Class Initialized
INFO - 2017-06-21 09:36:34 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:36:34 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:36:34 --> Utf8 Class Initialized
INFO - 2017-06-21 09:36:34 --> URI Class Initialized
INFO - 2017-06-21 09:36:34 --> Router Class Initialized
INFO - 2017-06-21 09:36:34 --> Output Class Initialized
INFO - 2017-06-21 09:36:34 --> Security Class Initialized
DEBUG - 2017-06-21 09:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:36:34 --> Input Class Initialized
INFO - 2017-06-21 09:36:34 --> Language Class Initialized
INFO - 2017-06-21 09:36:34 --> Loader Class Initialized
INFO - 2017-06-21 09:36:34 --> Controller Class Initialized
INFO - 2017-06-21 09:36:34 --> Database Driver Class Initialized
INFO - 2017-06-21 09:36:34 --> Model Class Initialized
INFO - 2017-06-21 09:36:34 --> Helper loaded: form_helper
INFO - 2017-06-21 09:36:34 --> Helper loaded: url_helper
INFO - 2017-06-21 09:36:34 --> Model Class Initialized
INFO - 2017-06-21 09:36:34 --> Final output sent to browser
DEBUG - 2017-06-21 09:36:34 --> Total execution time: 0.0975
ERROR - 2017-06-21 09:36:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:36:34 --> Config Class Initialized
INFO - 2017-06-21 09:36:34 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:36:34 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:36:34 --> Utf8 Class Initialized
INFO - 2017-06-21 09:36:34 --> URI Class Initialized
INFO - 2017-06-21 09:36:34 --> Router Class Initialized
INFO - 2017-06-21 09:36:34 --> Output Class Initialized
INFO - 2017-06-21 09:36:34 --> Security Class Initialized
DEBUG - 2017-06-21 09:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:36:34 --> Input Class Initialized
INFO - 2017-06-21 09:36:34 --> Language Class Initialized
INFO - 2017-06-21 09:36:34 --> Loader Class Initialized
INFO - 2017-06-21 09:36:34 --> Controller Class Initialized
INFO - 2017-06-21 09:36:34 --> Database Driver Class Initialized
INFO - 2017-06-21 09:36:34 --> Model Class Initialized
INFO - 2017-06-21 09:36:34 --> Helper loaded: form_helper
INFO - 2017-06-21 09:36:34 --> Helper loaded: url_helper
INFO - 2017-06-21 09:36:34 --> Model Class Initialized
INFO - 2017-06-21 09:36:34 --> Final output sent to browser
DEBUG - 2017-06-21 09:36:34 --> Total execution time: 0.0450
ERROR - 2017-06-21 09:37:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:37:57 --> Config Class Initialized
INFO - 2017-06-21 09:37:57 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:37:57 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:37:57 --> Utf8 Class Initialized
INFO - 2017-06-21 09:37:57 --> URI Class Initialized
INFO - 2017-06-21 09:37:57 --> Router Class Initialized
INFO - 2017-06-21 09:37:57 --> Output Class Initialized
INFO - 2017-06-21 09:37:57 --> Security Class Initialized
DEBUG - 2017-06-21 09:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:37:57 --> Input Class Initialized
INFO - 2017-06-21 09:37:57 --> Language Class Initialized
INFO - 2017-06-21 09:37:57 --> Loader Class Initialized
INFO - 2017-06-21 09:37:57 --> Controller Class Initialized
INFO - 2017-06-21 09:37:57 --> Database Driver Class Initialized
INFO - 2017-06-21 09:37:57 --> Model Class Initialized
INFO - 2017-06-21 09:37:57 --> Helper loaded: form_helper
INFO - 2017-06-21 09:37:57 --> Helper loaded: url_helper
INFO - 2017-06-21 09:37:57 --> Model Class Initialized
INFO - 2017-06-21 09:37:57 --> Final output sent to browser
DEBUG - 2017-06-21 09:37:57 --> Total execution time: 0.0538
ERROR - 2017-06-21 09:40:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:40:21 --> Config Class Initialized
INFO - 2017-06-21 09:40:21 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:40:21 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:40:21 --> Utf8 Class Initialized
INFO - 2017-06-21 09:40:21 --> URI Class Initialized
DEBUG - 2017-06-21 09:40:21 --> No URI present. Default controller set.
INFO - 2017-06-21 09:40:21 --> Router Class Initialized
INFO - 2017-06-21 09:40:21 --> Output Class Initialized
INFO - 2017-06-21 09:40:21 --> Security Class Initialized
DEBUG - 2017-06-21 09:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:40:21 --> Input Class Initialized
INFO - 2017-06-21 09:40:21 --> Language Class Initialized
INFO - 2017-06-21 09:40:21 --> Loader Class Initialized
INFO - 2017-06-21 09:40:21 --> Controller Class Initialized
INFO - 2017-06-21 09:40:21 --> Database Driver Class Initialized
INFO - 2017-06-21 09:40:21 --> Model Class Initialized
INFO - 2017-06-21 09:40:21 --> Helper loaded: form_helper
INFO - 2017-06-21 09:40:21 --> Helper loaded: url_helper
INFO - 2017-06-21 09:40:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-06-21 09:40:21 --> Final output sent to browser
DEBUG - 2017-06-21 09:40:21 --> Total execution time: 0.0550
ERROR - 2017-06-21 09:40:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:40:56 --> Config Class Initialized
INFO - 2017-06-21 09:40:56 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:40:56 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:40:56 --> Utf8 Class Initialized
INFO - 2017-06-21 09:40:56 --> URI Class Initialized
INFO - 2017-06-21 09:40:56 --> Router Class Initialized
INFO - 2017-06-21 09:40:56 --> Output Class Initialized
INFO - 2017-06-21 09:40:56 --> Security Class Initialized
DEBUG - 2017-06-21 09:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:40:56 --> Input Class Initialized
INFO - 2017-06-21 09:40:56 --> Language Class Initialized
INFO - 2017-06-21 09:40:56 --> Loader Class Initialized
INFO - 2017-06-21 09:40:56 --> Controller Class Initialized
INFO - 2017-06-21 09:40:56 --> Database Driver Class Initialized
INFO - 2017-06-21 09:40:56 --> Model Class Initialized
INFO - 2017-06-21 09:40:56 --> Helper loaded: form_helper
INFO - 2017-06-21 09:40:56 --> Helper loaded: url_helper
INFO - 2017-06-21 09:40:56 --> Model Class Initialized
INFO - 2017-06-21 09:40:56 --> Final output sent to browser
DEBUG - 2017-06-21 09:40:56 --> Total execution time: 0.0500
ERROR - 2017-06-21 09:40:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:40:57 --> Config Class Initialized
INFO - 2017-06-21 09:40:57 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:40:57 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:40:57 --> Utf8 Class Initialized
INFO - 2017-06-21 09:40:57 --> URI Class Initialized
INFO - 2017-06-21 09:40:57 --> Router Class Initialized
INFO - 2017-06-21 09:40:57 --> Output Class Initialized
INFO - 2017-06-21 09:40:57 --> Security Class Initialized
DEBUG - 2017-06-21 09:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:40:57 --> Input Class Initialized
INFO - 2017-06-21 09:40:57 --> Language Class Initialized
INFO - 2017-06-21 09:40:57 --> Loader Class Initialized
INFO - 2017-06-21 09:40:57 --> Controller Class Initialized
INFO - 2017-06-21 09:40:57 --> Database Driver Class Initialized
INFO - 2017-06-21 09:40:57 --> Model Class Initialized
INFO - 2017-06-21 09:40:57 --> Helper loaded: form_helper
INFO - 2017-06-21 09:40:57 --> Helper loaded: url_helper
INFO - 2017-06-21 09:40:57 --> Model Class Initialized
INFO - 2017-06-21 09:40:57 --> Final output sent to browser
DEBUG - 2017-06-21 09:40:57 --> Total execution time: 0.0450
ERROR - 2017-06-21 09:41:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:41:03 --> Config Class Initialized
INFO - 2017-06-21 09:41:03 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:41:03 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:41:03 --> Utf8 Class Initialized
INFO - 2017-06-21 09:41:03 --> URI Class Initialized
INFO - 2017-06-21 09:41:03 --> Router Class Initialized
INFO - 2017-06-21 09:41:03 --> Output Class Initialized
INFO - 2017-06-21 09:41:03 --> Security Class Initialized
DEBUG - 2017-06-21 09:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:41:03 --> Input Class Initialized
INFO - 2017-06-21 09:41:03 --> Language Class Initialized
INFO - 2017-06-21 09:41:03 --> Loader Class Initialized
INFO - 2017-06-21 09:41:03 --> Controller Class Initialized
INFO - 2017-06-21 09:41:03 --> Database Driver Class Initialized
INFO - 2017-06-21 09:41:03 --> Model Class Initialized
INFO - 2017-06-21 09:41:03 --> Helper loaded: form_helper
INFO - 2017-06-21 09:41:03 --> Helper loaded: url_helper
INFO - 2017-06-21 09:41:03 --> Model Class Initialized
INFO - 2017-06-21 09:41:03 --> Final output sent to browser
DEBUG - 2017-06-21 09:41:03 --> Total execution time: 0.2130
ERROR - 2017-06-21 09:41:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:41:03 --> Config Class Initialized
INFO - 2017-06-21 09:41:03 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:41:03 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:41:03 --> Utf8 Class Initialized
INFO - 2017-06-21 09:41:03 --> URI Class Initialized
INFO - 2017-06-21 09:41:03 --> Router Class Initialized
INFO - 2017-06-21 09:41:03 --> Output Class Initialized
INFO - 2017-06-21 09:41:03 --> Security Class Initialized
DEBUG - 2017-06-21 09:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:41:03 --> Input Class Initialized
INFO - 2017-06-21 09:41:03 --> Language Class Initialized
INFO - 2017-06-21 09:41:03 --> Loader Class Initialized
INFO - 2017-06-21 09:41:03 --> Controller Class Initialized
INFO - 2017-06-21 09:41:03 --> Database Driver Class Initialized
INFO - 2017-06-21 09:41:03 --> Model Class Initialized
INFO - 2017-06-21 09:41:03 --> Helper loaded: form_helper
INFO - 2017-06-21 09:41:03 --> Helper loaded: url_helper
INFO - 2017-06-21 09:41:03 --> Model Class Initialized
INFO - 2017-06-21 09:41:03 --> Final output sent to browser
DEBUG - 2017-06-21 09:41:03 --> Total execution time: 0.0570
ERROR - 2017-06-21 09:42:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:42:01 --> Config Class Initialized
INFO - 2017-06-21 09:42:01 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:42:01 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:42:01 --> Utf8 Class Initialized
INFO - 2017-06-21 09:42:01 --> URI Class Initialized
INFO - 2017-06-21 09:42:01 --> Router Class Initialized
INFO - 2017-06-21 09:42:01 --> Output Class Initialized
INFO - 2017-06-21 09:42:01 --> Security Class Initialized
DEBUG - 2017-06-21 09:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:42:01 --> Input Class Initialized
INFO - 2017-06-21 09:42:01 --> Language Class Initialized
INFO - 2017-06-21 09:42:01 --> Loader Class Initialized
INFO - 2017-06-21 09:42:02 --> Controller Class Initialized
INFO - 2017-06-21 09:42:02 --> Database Driver Class Initialized
INFO - 2017-06-21 09:42:02 --> Model Class Initialized
INFO - 2017-06-21 09:42:02 --> Helper loaded: form_helper
INFO - 2017-06-21 09:42:02 --> Helper loaded: url_helper
INFO - 2017-06-21 09:42:02 --> Model Class Initialized
INFO - 2017-06-21 09:42:02 --> Final output sent to browser
DEBUG - 2017-06-21 09:42:02 --> Total execution time: 0.0400
ERROR - 2017-06-21 09:48:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:48:28 --> Config Class Initialized
INFO - 2017-06-21 09:48:28 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:48:28 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:48:28 --> Utf8 Class Initialized
INFO - 2017-06-21 09:48:28 --> URI Class Initialized
INFO - 2017-06-21 09:48:28 --> Router Class Initialized
INFO - 2017-06-21 09:48:28 --> Output Class Initialized
INFO - 2017-06-21 09:48:28 --> Security Class Initialized
DEBUG - 2017-06-21 09:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:48:28 --> Input Class Initialized
INFO - 2017-06-21 09:48:28 --> Language Class Initialized
INFO - 2017-06-21 09:48:28 --> Loader Class Initialized
INFO - 2017-06-21 09:48:28 --> Controller Class Initialized
INFO - 2017-06-21 09:48:28 --> Database Driver Class Initialized
INFO - 2017-06-21 09:48:28 --> Model Class Initialized
INFO - 2017-06-21 09:48:28 --> Helper loaded: form_helper
INFO - 2017-06-21 09:48:28 --> Helper loaded: url_helper
INFO - 2017-06-21 09:48:28 --> Model Class Initialized
INFO - 2017-06-21 09:48:28 --> Final output sent to browser
DEBUG - 2017-06-21 09:48:28 --> Total execution time: 0.0450
ERROR - 2017-06-21 09:48:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:48:28 --> Config Class Initialized
INFO - 2017-06-21 09:48:28 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:48:28 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:48:28 --> Utf8 Class Initialized
INFO - 2017-06-21 09:48:28 --> URI Class Initialized
INFO - 2017-06-21 09:48:28 --> Router Class Initialized
INFO - 2017-06-21 09:48:28 --> Output Class Initialized
INFO - 2017-06-21 09:48:28 --> Security Class Initialized
DEBUG - 2017-06-21 09:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:48:28 --> Input Class Initialized
INFO - 2017-06-21 09:48:28 --> Language Class Initialized
INFO - 2017-06-21 09:48:28 --> Loader Class Initialized
INFO - 2017-06-21 09:48:28 --> Controller Class Initialized
INFO - 2017-06-21 09:48:28 --> Database Driver Class Initialized
INFO - 2017-06-21 09:48:28 --> Model Class Initialized
INFO - 2017-06-21 09:48:28 --> Helper loaded: form_helper
INFO - 2017-06-21 09:48:28 --> Helper loaded: url_helper
INFO - 2017-06-21 09:48:28 --> Model Class Initialized
INFO - 2017-06-21 09:48:28 --> Final output sent to browser
DEBUG - 2017-06-21 09:48:28 --> Total execution time: 0.0475
ERROR - 2017-06-21 09:50:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:50:20 --> Config Class Initialized
INFO - 2017-06-21 09:50:20 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:50:20 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:50:20 --> Utf8 Class Initialized
INFO - 2017-06-21 09:50:20 --> URI Class Initialized
INFO - 2017-06-21 09:50:20 --> Router Class Initialized
INFO - 2017-06-21 09:50:20 --> Output Class Initialized
INFO - 2017-06-21 09:50:20 --> Security Class Initialized
DEBUG - 2017-06-21 09:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:50:20 --> Input Class Initialized
INFO - 2017-06-21 09:50:20 --> Language Class Initialized
INFO - 2017-06-21 09:50:20 --> Loader Class Initialized
INFO - 2017-06-21 09:50:20 --> Controller Class Initialized
INFO - 2017-06-21 09:50:20 --> Database Driver Class Initialized
INFO - 2017-06-21 09:50:20 --> Model Class Initialized
INFO - 2017-06-21 09:50:20 --> Helper loaded: form_helper
INFO - 2017-06-21 09:50:20 --> Helper loaded: url_helper
INFO - 2017-06-21 09:50:20 --> Model Class Initialized
INFO - 2017-06-21 09:50:20 --> Final output sent to browser
DEBUG - 2017-06-21 09:50:20 --> Total execution time: 0.0575
ERROR - 2017-06-21 09:51:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:51:07 --> Config Class Initialized
INFO - 2017-06-21 09:51:07 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:51:07 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:51:07 --> Utf8 Class Initialized
INFO - 2017-06-21 09:51:07 --> URI Class Initialized
INFO - 2017-06-21 09:51:07 --> Router Class Initialized
INFO - 2017-06-21 09:51:07 --> Output Class Initialized
INFO - 2017-06-21 09:51:07 --> Security Class Initialized
DEBUG - 2017-06-21 09:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:51:07 --> Input Class Initialized
INFO - 2017-06-21 09:51:07 --> Language Class Initialized
INFO - 2017-06-21 09:51:07 --> Loader Class Initialized
INFO - 2017-06-21 09:51:07 --> Controller Class Initialized
INFO - 2017-06-21 09:51:07 --> Database Driver Class Initialized
INFO - 2017-06-21 09:51:07 --> Model Class Initialized
INFO - 2017-06-21 09:51:07 --> Helper loaded: form_helper
INFO - 2017-06-21 09:51:07 --> Helper loaded: url_helper
INFO - 2017-06-21 09:51:07 --> Model Class Initialized
INFO - 2017-06-21 09:51:07 --> Final output sent to browser
DEBUG - 2017-06-21 09:51:07 --> Total execution time: 0.0475
ERROR - 2017-06-21 09:52:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:52:34 --> Config Class Initialized
INFO - 2017-06-21 09:52:34 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:52:34 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:52:34 --> Utf8 Class Initialized
INFO - 2017-06-21 09:52:34 --> URI Class Initialized
INFO - 2017-06-21 09:52:34 --> Router Class Initialized
INFO - 2017-06-21 09:52:34 --> Output Class Initialized
INFO - 2017-06-21 09:52:34 --> Security Class Initialized
DEBUG - 2017-06-21 09:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:52:34 --> Input Class Initialized
INFO - 2017-06-21 09:52:34 --> Language Class Initialized
INFO - 2017-06-21 09:52:34 --> Loader Class Initialized
INFO - 2017-06-21 09:52:34 --> Controller Class Initialized
INFO - 2017-06-21 09:52:34 --> Database Driver Class Initialized
INFO - 2017-06-21 09:52:34 --> Model Class Initialized
INFO - 2017-06-21 09:52:34 --> Helper loaded: form_helper
INFO - 2017-06-21 09:52:34 --> Helper loaded: url_helper
INFO - 2017-06-21 09:52:34 --> Model Class Initialized
INFO - 2017-06-21 09:52:34 --> Final output sent to browser
DEBUG - 2017-06-21 09:52:34 --> Total execution time: 0.0625
ERROR - 2017-06-21 09:52:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:52:35 --> Config Class Initialized
INFO - 2017-06-21 09:52:35 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:52:35 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:52:35 --> Utf8 Class Initialized
INFO - 2017-06-21 09:52:35 --> URI Class Initialized
INFO - 2017-06-21 09:52:35 --> Router Class Initialized
INFO - 2017-06-21 09:52:35 --> Output Class Initialized
INFO - 2017-06-21 09:52:35 --> Security Class Initialized
DEBUG - 2017-06-21 09:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:52:35 --> Input Class Initialized
INFO - 2017-06-21 09:52:35 --> Language Class Initialized
INFO - 2017-06-21 09:52:35 --> Loader Class Initialized
INFO - 2017-06-21 09:52:35 --> Controller Class Initialized
INFO - 2017-06-21 09:52:35 --> Database Driver Class Initialized
INFO - 2017-06-21 09:52:35 --> Model Class Initialized
INFO - 2017-06-21 09:52:35 --> Helper loaded: form_helper
INFO - 2017-06-21 09:52:35 --> Helper loaded: url_helper
INFO - 2017-06-21 09:52:35 --> Model Class Initialized
INFO - 2017-06-21 09:52:35 --> Final output sent to browser
DEBUG - 2017-06-21 09:52:35 --> Total execution time: 0.0475
ERROR - 2017-06-21 09:52:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:52:48 --> Config Class Initialized
INFO - 2017-06-21 09:52:48 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:52:48 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:52:48 --> Utf8 Class Initialized
INFO - 2017-06-21 09:52:48 --> URI Class Initialized
INFO - 2017-06-21 09:52:48 --> Router Class Initialized
INFO - 2017-06-21 09:52:48 --> Output Class Initialized
INFO - 2017-06-21 09:52:48 --> Security Class Initialized
DEBUG - 2017-06-21 09:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:52:48 --> Input Class Initialized
INFO - 2017-06-21 09:52:48 --> Language Class Initialized
INFO - 2017-06-21 09:52:48 --> Loader Class Initialized
INFO - 2017-06-21 09:52:48 --> Controller Class Initialized
INFO - 2017-06-21 09:52:48 --> Database Driver Class Initialized
INFO - 2017-06-21 09:52:48 --> Model Class Initialized
INFO - 2017-06-21 09:52:48 --> Helper loaded: form_helper
INFO - 2017-06-21 09:52:48 --> Helper loaded: url_helper
INFO - 2017-06-21 09:52:48 --> Model Class Initialized
INFO - 2017-06-21 09:52:48 --> Final output sent to browser
DEBUG - 2017-06-21 09:52:48 --> Total execution time: 0.0500
ERROR - 2017-06-21 09:52:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:52:52 --> Config Class Initialized
INFO - 2017-06-21 09:52:52 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:52:52 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:52:52 --> Utf8 Class Initialized
INFO - 2017-06-21 09:52:52 --> URI Class Initialized
INFO - 2017-06-21 09:52:52 --> Router Class Initialized
INFO - 2017-06-21 09:52:52 --> Output Class Initialized
INFO - 2017-06-21 09:52:52 --> Security Class Initialized
DEBUG - 2017-06-21 09:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:52:52 --> Input Class Initialized
INFO - 2017-06-21 09:52:52 --> Language Class Initialized
INFO - 2017-06-21 09:52:52 --> Loader Class Initialized
INFO - 2017-06-21 09:52:52 --> Controller Class Initialized
INFO - 2017-06-21 09:52:52 --> Database Driver Class Initialized
INFO - 2017-06-21 09:52:52 --> Model Class Initialized
INFO - 2017-06-21 09:52:52 --> Helper loaded: form_helper
INFO - 2017-06-21 09:52:52 --> Helper loaded: url_helper
INFO - 2017-06-21 09:52:52 --> Model Class Initialized
INFO - 2017-06-21 09:52:52 --> Final output sent to browser
DEBUG - 2017-06-21 09:52:52 --> Total execution time: 0.1038
ERROR - 2017-06-21 09:52:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:52:52 --> Config Class Initialized
INFO - 2017-06-21 09:52:52 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:52:52 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:52:52 --> Utf8 Class Initialized
INFO - 2017-06-21 09:52:52 --> URI Class Initialized
INFO - 2017-06-21 09:52:52 --> Router Class Initialized
INFO - 2017-06-21 09:52:52 --> Output Class Initialized
INFO - 2017-06-21 09:52:52 --> Security Class Initialized
DEBUG - 2017-06-21 09:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:52:52 --> Input Class Initialized
INFO - 2017-06-21 09:52:52 --> Language Class Initialized
INFO - 2017-06-21 09:52:52 --> Loader Class Initialized
INFO - 2017-06-21 09:52:52 --> Controller Class Initialized
INFO - 2017-06-21 09:52:52 --> Database Driver Class Initialized
INFO - 2017-06-21 09:52:52 --> Model Class Initialized
INFO - 2017-06-21 09:52:52 --> Helper loaded: form_helper
INFO - 2017-06-21 09:52:52 --> Helper loaded: url_helper
INFO - 2017-06-21 09:52:52 --> Model Class Initialized
INFO - 2017-06-21 09:52:52 --> Final output sent to browser
DEBUG - 2017-06-21 09:52:52 --> Total execution time: 0.0500
ERROR - 2017-06-21 09:53:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:53:11 --> Config Class Initialized
INFO - 2017-06-21 09:53:11 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:53:11 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:53:11 --> Utf8 Class Initialized
INFO - 2017-06-21 09:53:11 --> URI Class Initialized
INFO - 2017-06-21 09:53:11 --> Router Class Initialized
INFO - 2017-06-21 09:53:11 --> Output Class Initialized
INFO - 2017-06-21 09:53:11 --> Security Class Initialized
DEBUG - 2017-06-21 09:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:53:11 --> Input Class Initialized
INFO - 2017-06-21 09:53:11 --> Language Class Initialized
INFO - 2017-06-21 09:53:11 --> Loader Class Initialized
INFO - 2017-06-21 09:53:11 --> Controller Class Initialized
INFO - 2017-06-21 09:53:11 --> Database Driver Class Initialized
INFO - 2017-06-21 09:53:11 --> Model Class Initialized
INFO - 2017-06-21 09:53:11 --> Helper loaded: form_helper
INFO - 2017-06-21 09:53:11 --> Helper loaded: url_helper
INFO - 2017-06-21 09:53:11 --> Model Class Initialized
INFO - 2017-06-21 09:53:11 --> Final output sent to browser
DEBUG - 2017-06-21 09:53:11 --> Total execution time: 0.0475
ERROR - 2017-06-21 09:53:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:53:41 --> Config Class Initialized
INFO - 2017-06-21 09:53:41 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:53:41 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:53:41 --> Utf8 Class Initialized
INFO - 2017-06-21 09:53:41 --> URI Class Initialized
INFO - 2017-06-21 09:53:41 --> Router Class Initialized
INFO - 2017-06-21 09:53:41 --> Output Class Initialized
INFO - 2017-06-21 09:53:41 --> Security Class Initialized
DEBUG - 2017-06-21 09:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:53:41 --> Input Class Initialized
INFO - 2017-06-21 09:53:41 --> Language Class Initialized
INFO - 2017-06-21 09:53:41 --> Loader Class Initialized
INFO - 2017-06-21 09:53:41 --> Controller Class Initialized
INFO - 2017-06-21 09:53:41 --> Database Driver Class Initialized
INFO - 2017-06-21 09:53:41 --> Model Class Initialized
INFO - 2017-06-21 09:53:41 --> Helper loaded: form_helper
INFO - 2017-06-21 09:53:41 --> Helper loaded: url_helper
INFO - 2017-06-21 09:53:41 --> Model Class Initialized
INFO - 2017-06-21 09:53:41 --> Final output sent to browser
DEBUG - 2017-06-21 09:53:41 --> Total execution time: 0.0490
ERROR - 2017-06-21 09:55:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:55:59 --> Config Class Initialized
INFO - 2017-06-21 09:55:59 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:55:59 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:55:59 --> Utf8 Class Initialized
INFO - 2017-06-21 09:55:59 --> URI Class Initialized
INFO - 2017-06-21 09:55:59 --> Router Class Initialized
INFO - 2017-06-21 09:55:59 --> Output Class Initialized
INFO - 2017-06-21 09:55:59 --> Security Class Initialized
DEBUG - 2017-06-21 09:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:55:59 --> Input Class Initialized
INFO - 2017-06-21 09:55:59 --> Language Class Initialized
INFO - 2017-06-21 09:55:59 --> Loader Class Initialized
INFO - 2017-06-21 09:55:59 --> Controller Class Initialized
INFO - 2017-06-21 09:55:59 --> Database Driver Class Initialized
INFO - 2017-06-21 09:55:59 --> Model Class Initialized
INFO - 2017-06-21 09:55:59 --> Helper loaded: form_helper
INFO - 2017-06-21 09:55:59 --> Helper loaded: url_helper
INFO - 2017-06-21 09:55:59 --> Model Class Initialized
INFO - 2017-06-21 09:55:59 --> Final output sent to browser
DEBUG - 2017-06-21 09:55:59 --> Total execution time: 0.0575
ERROR - 2017-06-21 09:56:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:56:00 --> Config Class Initialized
INFO - 2017-06-21 09:56:00 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:56:00 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:56:00 --> Utf8 Class Initialized
INFO - 2017-06-21 09:56:00 --> URI Class Initialized
INFO - 2017-06-21 09:56:00 --> Router Class Initialized
INFO - 2017-06-21 09:56:00 --> Output Class Initialized
INFO - 2017-06-21 09:56:00 --> Security Class Initialized
DEBUG - 2017-06-21 09:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:56:00 --> Input Class Initialized
INFO - 2017-06-21 09:56:00 --> Language Class Initialized
INFO - 2017-06-21 09:56:00 --> Loader Class Initialized
INFO - 2017-06-21 09:56:00 --> Controller Class Initialized
INFO - 2017-06-21 09:56:00 --> Database Driver Class Initialized
INFO - 2017-06-21 09:56:00 --> Model Class Initialized
INFO - 2017-06-21 09:56:00 --> Helper loaded: form_helper
INFO - 2017-06-21 09:56:00 --> Helper loaded: url_helper
INFO - 2017-06-21 09:56:00 --> Model Class Initialized
INFO - 2017-06-21 09:56:00 --> Final output sent to browser
DEBUG - 2017-06-21 09:56:00 --> Total execution time: 0.0725
ERROR - 2017-06-21 09:57:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:57:16 --> Config Class Initialized
INFO - 2017-06-21 09:57:16 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:57:16 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:57:16 --> Utf8 Class Initialized
INFO - 2017-06-21 09:57:16 --> URI Class Initialized
INFO - 2017-06-21 09:57:16 --> Router Class Initialized
INFO - 2017-06-21 09:57:16 --> Output Class Initialized
INFO - 2017-06-21 09:57:16 --> Security Class Initialized
DEBUG - 2017-06-21 09:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:57:16 --> Input Class Initialized
INFO - 2017-06-21 09:57:16 --> Language Class Initialized
INFO - 2017-06-21 09:57:16 --> Loader Class Initialized
INFO - 2017-06-21 09:57:16 --> Controller Class Initialized
INFO - 2017-06-21 09:57:16 --> Database Driver Class Initialized
INFO - 2017-06-21 09:57:16 --> Model Class Initialized
INFO - 2017-06-21 09:57:16 --> Helper loaded: form_helper
INFO - 2017-06-21 09:57:16 --> Helper loaded: url_helper
INFO - 2017-06-21 09:57:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 09:57:16 --> Model Class Initialized
INFO - 2017-06-21 09:57:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-21 09:57:16 --> Final output sent to browser
DEBUG - 2017-06-21 09:57:16 --> Total execution time: 0.0645
ERROR - 2017-06-21 09:57:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:57:25 --> Config Class Initialized
INFO - 2017-06-21 09:57:25 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:57:25 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:57:25 --> Utf8 Class Initialized
INFO - 2017-06-21 09:57:25 --> URI Class Initialized
INFO - 2017-06-21 09:57:25 --> Router Class Initialized
INFO - 2017-06-21 09:57:25 --> Output Class Initialized
INFO - 2017-06-21 09:57:25 --> Security Class Initialized
DEBUG - 2017-06-21 09:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:57:25 --> Input Class Initialized
INFO - 2017-06-21 09:57:25 --> Language Class Initialized
INFO - 2017-06-21 09:57:25 --> Loader Class Initialized
INFO - 2017-06-21 09:57:25 --> Controller Class Initialized
INFO - 2017-06-21 09:57:25 --> Database Driver Class Initialized
INFO - 2017-06-21 09:57:25 --> Model Class Initialized
INFO - 2017-06-21 09:57:25 --> Helper loaded: form_helper
INFO - 2017-06-21 09:57:25 --> Helper loaded: url_helper
INFO - 2017-06-21 09:57:25 --> Model Class Initialized
INFO - 2017-06-21 09:57:25 --> Final output sent to browser
DEBUG - 2017-06-21 09:57:25 --> Total execution time: 0.0460
ERROR - 2017-06-21 09:57:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:57:25 --> Config Class Initialized
INFO - 2017-06-21 09:57:25 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:57:25 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:57:25 --> Utf8 Class Initialized
INFO - 2017-06-21 09:57:25 --> URI Class Initialized
INFO - 2017-06-21 09:57:25 --> Router Class Initialized
INFO - 2017-06-21 09:57:25 --> Output Class Initialized
INFO - 2017-06-21 09:57:25 --> Security Class Initialized
DEBUG - 2017-06-21 09:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:57:25 --> Input Class Initialized
INFO - 2017-06-21 09:57:25 --> Language Class Initialized
INFO - 2017-06-21 09:57:25 --> Loader Class Initialized
INFO - 2017-06-21 09:57:25 --> Controller Class Initialized
INFO - 2017-06-21 09:57:25 --> Database Driver Class Initialized
INFO - 2017-06-21 09:57:25 --> Model Class Initialized
INFO - 2017-06-21 09:57:25 --> Helper loaded: form_helper
INFO - 2017-06-21 09:57:25 --> Helper loaded: url_helper
INFO - 2017-06-21 09:57:25 --> Model Class Initialized
INFO - 2017-06-21 09:57:25 --> Final output sent to browser
DEBUG - 2017-06-21 09:57:25 --> Total execution time: 0.0460
ERROR - 2017-06-21 09:58:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 09:58:24 --> Config Class Initialized
INFO - 2017-06-21 09:58:24 --> Hooks Class Initialized
DEBUG - 2017-06-21 09:58:24 --> UTF-8 Support Enabled
INFO - 2017-06-21 09:58:24 --> Utf8 Class Initialized
INFO - 2017-06-21 09:58:24 --> URI Class Initialized
INFO - 2017-06-21 09:58:24 --> Router Class Initialized
INFO - 2017-06-21 09:58:24 --> Output Class Initialized
INFO - 2017-06-21 09:58:24 --> Security Class Initialized
DEBUG - 2017-06-21 09:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 09:58:24 --> Input Class Initialized
INFO - 2017-06-21 09:58:24 --> Language Class Initialized
INFO - 2017-06-21 09:58:24 --> Loader Class Initialized
INFO - 2017-06-21 09:58:24 --> Controller Class Initialized
INFO - 2017-06-21 09:58:24 --> Database Driver Class Initialized
INFO - 2017-06-21 09:58:24 --> Model Class Initialized
INFO - 2017-06-21 09:58:24 --> Helper loaded: form_helper
INFO - 2017-06-21 09:58:24 --> Helper loaded: url_helper
INFO - 2017-06-21 09:58:24 --> Model Class Initialized
INFO - 2017-06-21 09:58:24 --> Final output sent to browser
DEBUG - 2017-06-21 09:58:24 --> Total execution time: 0.0450
ERROR - 2017-06-21 11:29:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:29:39 --> Config Class Initialized
INFO - 2017-06-21 11:29:39 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:29:39 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:29:39 --> Utf8 Class Initialized
INFO - 2017-06-21 11:29:39 --> URI Class Initialized
INFO - 2017-06-21 11:29:39 --> Router Class Initialized
INFO - 2017-06-21 11:29:39 --> Output Class Initialized
INFO - 2017-06-21 11:29:39 --> Security Class Initialized
DEBUG - 2017-06-21 11:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:29:39 --> Input Class Initialized
INFO - 2017-06-21 11:29:39 --> Language Class Initialized
INFO - 2017-06-21 11:29:39 --> Loader Class Initialized
INFO - 2017-06-21 11:29:39 --> Controller Class Initialized
INFO - 2017-06-21 11:29:39 --> Database Driver Class Initialized
INFO - 2017-06-21 11:29:39 --> Model Class Initialized
INFO - 2017-06-21 11:29:39 --> Helper loaded: form_helper
INFO - 2017-06-21 11:29:39 --> Helper loaded: url_helper
INFO - 2017-06-21 11:29:39 --> Model Class Initialized
INFO - 2017-06-21 11:29:39 --> Final output sent to browser
DEBUG - 2017-06-21 11:29:39 --> Total execution time: 0.0590
ERROR - 2017-06-21 11:29:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:29:40 --> Config Class Initialized
INFO - 2017-06-21 11:29:40 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:29:40 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:29:40 --> Utf8 Class Initialized
INFO - 2017-06-21 11:29:40 --> URI Class Initialized
INFO - 2017-06-21 11:29:40 --> Router Class Initialized
INFO - 2017-06-21 11:29:40 --> Output Class Initialized
INFO - 2017-06-21 11:29:40 --> Security Class Initialized
DEBUG - 2017-06-21 11:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:29:40 --> Input Class Initialized
INFO - 2017-06-21 11:29:40 --> Language Class Initialized
INFO - 2017-06-21 11:29:40 --> Loader Class Initialized
INFO - 2017-06-21 11:29:40 --> Controller Class Initialized
INFO - 2017-06-21 11:29:40 --> Database Driver Class Initialized
INFO - 2017-06-21 11:29:40 --> Model Class Initialized
INFO - 2017-06-21 11:29:40 --> Helper loaded: form_helper
INFO - 2017-06-21 11:29:40 --> Helper loaded: url_helper
INFO - 2017-06-21 11:29:40 --> Model Class Initialized
INFO - 2017-06-21 11:29:40 --> Final output sent to browser
DEBUG - 2017-06-21 11:29:40 --> Total execution time: 0.0510
ERROR - 2017-06-21 11:29:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:29:52 --> Config Class Initialized
INFO - 2017-06-21 11:29:52 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:29:52 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:29:52 --> Utf8 Class Initialized
INFO - 2017-06-21 11:29:52 --> URI Class Initialized
INFO - 2017-06-21 11:29:52 --> Router Class Initialized
INFO - 2017-06-21 11:29:52 --> Output Class Initialized
INFO - 2017-06-21 11:29:52 --> Security Class Initialized
DEBUG - 2017-06-21 11:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:29:52 --> Input Class Initialized
INFO - 2017-06-21 11:29:52 --> Language Class Initialized
INFO - 2017-06-21 11:29:52 --> Loader Class Initialized
INFO - 2017-06-21 11:29:52 --> Controller Class Initialized
INFO - 2017-06-21 11:29:52 --> Database Driver Class Initialized
INFO - 2017-06-21 11:29:52 --> Model Class Initialized
INFO - 2017-06-21 11:29:52 --> Helper loaded: form_helper
INFO - 2017-06-21 11:29:52 --> Helper loaded: url_helper
INFO - 2017-06-21 11:29:52 --> Model Class Initialized
INFO - 2017-06-21 11:29:52 --> Final output sent to browser
DEBUG - 2017-06-21 11:29:52 --> Total execution time: 0.0480
ERROR - 2017-06-21 11:30:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:30:03 --> Config Class Initialized
INFO - 2017-06-21 11:30:03 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:30:03 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:30:03 --> Utf8 Class Initialized
INFO - 2017-06-21 11:30:03 --> URI Class Initialized
INFO - 2017-06-21 11:30:03 --> Router Class Initialized
INFO - 2017-06-21 11:30:03 --> Output Class Initialized
INFO - 2017-06-21 11:30:03 --> Security Class Initialized
DEBUG - 2017-06-21 11:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:30:03 --> Input Class Initialized
INFO - 2017-06-21 11:30:03 --> Language Class Initialized
INFO - 2017-06-21 11:30:03 --> Loader Class Initialized
INFO - 2017-06-21 11:30:03 --> Controller Class Initialized
INFO - 2017-06-21 11:30:03 --> Database Driver Class Initialized
INFO - 2017-06-21 11:30:03 --> Model Class Initialized
INFO - 2017-06-21 11:30:03 --> Helper loaded: form_helper
INFO - 2017-06-21 11:30:03 --> Helper loaded: url_helper
INFO - 2017-06-21 11:30:03 --> Model Class Initialized
INFO - 2017-06-21 11:30:03 --> Final output sent to browser
DEBUG - 2017-06-21 11:30:03 --> Total execution time: 0.0510
ERROR - 2017-06-21 11:30:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:30:11 --> Config Class Initialized
INFO - 2017-06-21 11:30:11 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:30:11 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:30:11 --> Utf8 Class Initialized
INFO - 2017-06-21 11:30:11 --> URI Class Initialized
INFO - 2017-06-21 11:30:11 --> Router Class Initialized
INFO - 2017-06-21 11:30:11 --> Output Class Initialized
INFO - 2017-06-21 11:30:11 --> Security Class Initialized
DEBUG - 2017-06-21 11:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:30:11 --> Input Class Initialized
INFO - 2017-06-21 11:30:11 --> Language Class Initialized
INFO - 2017-06-21 11:30:11 --> Loader Class Initialized
INFO - 2017-06-21 11:30:11 --> Controller Class Initialized
INFO - 2017-06-21 11:30:11 --> Database Driver Class Initialized
INFO - 2017-06-21 11:30:11 --> Model Class Initialized
INFO - 2017-06-21 11:30:11 --> Helper loaded: form_helper
INFO - 2017-06-21 11:30:11 --> Helper loaded: url_helper
INFO - 2017-06-21 11:30:11 --> Model Class Initialized
INFO - 2017-06-21 11:30:11 --> Final output sent to browser
DEBUG - 2017-06-21 11:30:11 --> Total execution time: 0.0540
ERROR - 2017-06-21 11:33:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:33:57 --> Config Class Initialized
INFO - 2017-06-21 11:33:57 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:33:57 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:33:57 --> Utf8 Class Initialized
INFO - 2017-06-21 11:33:57 --> URI Class Initialized
INFO - 2017-06-21 11:33:57 --> Router Class Initialized
INFO - 2017-06-21 11:33:57 --> Output Class Initialized
INFO - 2017-06-21 11:33:57 --> Security Class Initialized
DEBUG - 2017-06-21 11:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:33:57 --> Input Class Initialized
INFO - 2017-06-21 11:33:57 --> Language Class Initialized
INFO - 2017-06-21 11:33:57 --> Loader Class Initialized
INFO - 2017-06-21 11:33:57 --> Controller Class Initialized
INFO - 2017-06-21 11:33:57 --> Database Driver Class Initialized
INFO - 2017-06-21 11:33:57 --> Model Class Initialized
INFO - 2017-06-21 11:33:57 --> Helper loaded: form_helper
INFO - 2017-06-21 11:33:57 --> Helper loaded: url_helper
INFO - 2017-06-21 11:33:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 11:33:57 --> Model Class Initialized
INFO - 2017-06-21 11:33:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-21 11:33:57 --> Final output sent to browser
DEBUG - 2017-06-21 11:33:57 --> Total execution time: 0.0700
ERROR - 2017-06-21 11:34:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:34:35 --> Config Class Initialized
INFO - 2017-06-21 11:34:35 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:34:35 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:34:35 --> Utf8 Class Initialized
INFO - 2017-06-21 11:34:35 --> URI Class Initialized
INFO - 2017-06-21 11:34:35 --> Router Class Initialized
INFO - 2017-06-21 11:34:35 --> Output Class Initialized
INFO - 2017-06-21 11:34:35 --> Security Class Initialized
DEBUG - 2017-06-21 11:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:34:35 --> Input Class Initialized
INFO - 2017-06-21 11:34:35 --> Language Class Initialized
INFO - 2017-06-21 11:34:35 --> Loader Class Initialized
INFO - 2017-06-21 11:34:35 --> Controller Class Initialized
INFO - 2017-06-21 11:34:35 --> Database Driver Class Initialized
INFO - 2017-06-21 11:34:35 --> Model Class Initialized
INFO - 2017-06-21 11:34:35 --> Helper loaded: form_helper
INFO - 2017-06-21 11:34:35 --> Helper loaded: url_helper
INFO - 2017-06-21 11:34:35 --> Final output sent to browser
DEBUG - 2017-06-21 11:34:35 --> Total execution time: 0.0460
ERROR - 2017-06-21 11:34:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:34:56 --> Config Class Initialized
INFO - 2017-06-21 11:34:56 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:34:56 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:34:56 --> Utf8 Class Initialized
INFO - 2017-06-21 11:34:56 --> URI Class Initialized
INFO - 2017-06-21 11:34:56 --> Router Class Initialized
INFO - 2017-06-21 11:34:56 --> Output Class Initialized
INFO - 2017-06-21 11:34:56 --> Security Class Initialized
DEBUG - 2017-06-21 11:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:34:56 --> Input Class Initialized
INFO - 2017-06-21 11:34:56 --> Language Class Initialized
INFO - 2017-06-21 11:34:56 --> Loader Class Initialized
INFO - 2017-06-21 11:34:56 --> Controller Class Initialized
INFO - 2017-06-21 11:34:56 --> Database Driver Class Initialized
INFO - 2017-06-21 11:34:56 --> Model Class Initialized
INFO - 2017-06-21 11:34:56 --> Helper loaded: form_helper
INFO - 2017-06-21 11:34:56 --> Helper loaded: url_helper
INFO - 2017-06-21 11:34:56 --> Final output sent to browser
DEBUG - 2017-06-21 11:34:56 --> Total execution time: 0.0500
ERROR - 2017-06-21 11:35:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:35:16 --> Config Class Initialized
INFO - 2017-06-21 11:35:16 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:35:16 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:35:16 --> Utf8 Class Initialized
INFO - 2017-06-21 11:35:16 --> URI Class Initialized
INFO - 2017-06-21 11:35:16 --> Router Class Initialized
INFO - 2017-06-21 11:35:16 --> Output Class Initialized
INFO - 2017-06-21 11:35:17 --> Security Class Initialized
DEBUG - 2017-06-21 11:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:35:17 --> Input Class Initialized
INFO - 2017-06-21 11:35:17 --> Language Class Initialized
INFO - 2017-06-21 11:35:17 --> Loader Class Initialized
INFO - 2017-06-21 11:35:17 --> Controller Class Initialized
INFO - 2017-06-21 11:35:17 --> Database Driver Class Initialized
INFO - 2017-06-21 11:35:17 --> Model Class Initialized
INFO - 2017-06-21 11:35:17 --> Helper loaded: form_helper
INFO - 2017-06-21 11:35:17 --> Helper loaded: url_helper
INFO - 2017-06-21 11:35:17 --> Model Class Initialized
INFO - 2017-06-21 11:35:17 --> Final output sent to browser
DEBUG - 2017-06-21 11:35:17 --> Total execution time: 0.0570
ERROR - 2017-06-21 11:35:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:35:23 --> Config Class Initialized
INFO - 2017-06-21 11:35:23 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:35:23 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:35:23 --> Utf8 Class Initialized
INFO - 2017-06-21 11:35:23 --> URI Class Initialized
INFO - 2017-06-21 11:35:23 --> Router Class Initialized
INFO - 2017-06-21 11:35:23 --> Output Class Initialized
INFO - 2017-06-21 11:35:23 --> Security Class Initialized
DEBUG - 2017-06-21 11:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:35:23 --> Input Class Initialized
INFO - 2017-06-21 11:35:23 --> Language Class Initialized
INFO - 2017-06-21 11:35:23 --> Loader Class Initialized
INFO - 2017-06-21 11:35:23 --> Controller Class Initialized
INFO - 2017-06-21 11:35:23 --> Database Driver Class Initialized
INFO - 2017-06-21 11:35:23 --> Model Class Initialized
INFO - 2017-06-21 11:35:23 --> Helper loaded: form_helper
INFO - 2017-06-21 11:35:23 --> Helper loaded: url_helper
INFO - 2017-06-21 11:35:23 --> Final output sent to browser
DEBUG - 2017-06-21 11:35:23 --> Total execution time: 0.0700
ERROR - 2017-06-21 11:35:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:35:44 --> Config Class Initialized
INFO - 2017-06-21 11:35:44 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:35:44 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:35:44 --> Utf8 Class Initialized
INFO - 2017-06-21 11:35:44 --> URI Class Initialized
INFO - 2017-06-21 11:35:44 --> Router Class Initialized
INFO - 2017-06-21 11:35:44 --> Output Class Initialized
INFO - 2017-06-21 11:35:44 --> Security Class Initialized
DEBUG - 2017-06-21 11:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:35:44 --> Input Class Initialized
INFO - 2017-06-21 11:35:44 --> Language Class Initialized
INFO - 2017-06-21 11:35:44 --> Loader Class Initialized
INFO - 2017-06-21 11:35:44 --> Controller Class Initialized
INFO - 2017-06-21 11:35:44 --> Database Driver Class Initialized
INFO - 2017-06-21 11:35:44 --> Model Class Initialized
INFO - 2017-06-21 11:35:44 --> Helper loaded: form_helper
INFO - 2017-06-21 11:35:44 --> Helper loaded: url_helper
INFO - 2017-06-21 11:35:44 --> Model Class Initialized
INFO - 2017-06-21 11:35:44 --> Final output sent to browser
DEBUG - 2017-06-21 11:35:44 --> Total execution time: 0.0420
ERROR - 2017-06-21 11:38:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:38:54 --> Config Class Initialized
INFO - 2017-06-21 11:38:54 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:38:54 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:38:54 --> Utf8 Class Initialized
INFO - 2017-06-21 11:38:54 --> URI Class Initialized
INFO - 2017-06-21 11:38:54 --> Router Class Initialized
INFO - 2017-06-21 11:38:54 --> Output Class Initialized
INFO - 2017-06-21 11:38:54 --> Security Class Initialized
DEBUG - 2017-06-21 11:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:38:54 --> Input Class Initialized
INFO - 2017-06-21 11:38:54 --> Language Class Initialized
INFO - 2017-06-21 11:38:54 --> Loader Class Initialized
INFO - 2017-06-21 11:38:54 --> Controller Class Initialized
INFO - 2017-06-21 11:38:54 --> Database Driver Class Initialized
INFO - 2017-06-21 11:38:54 --> Model Class Initialized
INFO - 2017-06-21 11:38:54 --> Helper loaded: form_helper
INFO - 2017-06-21 11:38:54 --> Helper loaded: url_helper
INFO - 2017-06-21 11:38:54 --> Model Class Initialized
INFO - 2017-06-21 11:38:54 --> Final output sent to browser
DEBUG - 2017-06-21 11:38:54 --> Total execution time: 0.0550
ERROR - 2017-06-21 11:38:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:38:55 --> Config Class Initialized
INFO - 2017-06-21 11:38:55 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:38:55 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:38:55 --> Utf8 Class Initialized
INFO - 2017-06-21 11:38:55 --> URI Class Initialized
INFO - 2017-06-21 11:38:55 --> Router Class Initialized
INFO - 2017-06-21 11:38:55 --> Output Class Initialized
INFO - 2017-06-21 11:38:55 --> Security Class Initialized
DEBUG - 2017-06-21 11:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:38:55 --> Input Class Initialized
INFO - 2017-06-21 11:38:55 --> Language Class Initialized
INFO - 2017-06-21 11:38:55 --> Loader Class Initialized
INFO - 2017-06-21 11:38:55 --> Controller Class Initialized
INFO - 2017-06-21 11:38:55 --> Database Driver Class Initialized
INFO - 2017-06-21 11:38:55 --> Model Class Initialized
INFO - 2017-06-21 11:38:55 --> Helper loaded: form_helper
INFO - 2017-06-21 11:38:55 --> Helper loaded: url_helper
INFO - 2017-06-21 11:38:55 --> Model Class Initialized
INFO - 2017-06-21 11:38:55 --> Final output sent to browser
DEBUG - 2017-06-21 11:38:55 --> Total execution time: 0.0620
ERROR - 2017-06-21 11:39:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:39:36 --> Config Class Initialized
INFO - 2017-06-21 11:39:36 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:39:36 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:39:36 --> Utf8 Class Initialized
INFO - 2017-06-21 11:39:36 --> URI Class Initialized
INFO - 2017-06-21 11:39:36 --> Router Class Initialized
INFO - 2017-06-21 11:39:36 --> Output Class Initialized
INFO - 2017-06-21 11:39:36 --> Security Class Initialized
DEBUG - 2017-06-21 11:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:39:36 --> Input Class Initialized
INFO - 2017-06-21 11:39:36 --> Language Class Initialized
INFO - 2017-06-21 11:39:36 --> Loader Class Initialized
INFO - 2017-06-21 11:39:36 --> Controller Class Initialized
INFO - 2017-06-21 11:39:36 --> Database Driver Class Initialized
INFO - 2017-06-21 11:39:36 --> Model Class Initialized
INFO - 2017-06-21 11:39:36 --> Helper loaded: form_helper
INFO - 2017-06-21 11:39:36 --> Helper loaded: url_helper
INFO - 2017-06-21 11:39:36 --> Model Class Initialized
INFO - 2017-06-21 11:39:36 --> Final output sent to browser
DEBUG - 2017-06-21 11:39:36 --> Total execution time: 0.0470
ERROR - 2017-06-21 11:39:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:39:46 --> Config Class Initialized
INFO - 2017-06-21 11:39:46 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:39:46 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:39:46 --> Utf8 Class Initialized
INFO - 2017-06-21 11:39:46 --> URI Class Initialized
INFO - 2017-06-21 11:39:46 --> Router Class Initialized
INFO - 2017-06-21 11:39:46 --> Output Class Initialized
INFO - 2017-06-21 11:39:46 --> Security Class Initialized
DEBUG - 2017-06-21 11:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:39:46 --> Input Class Initialized
INFO - 2017-06-21 11:39:46 --> Language Class Initialized
INFO - 2017-06-21 11:39:46 --> Loader Class Initialized
INFO - 2017-06-21 11:39:46 --> Controller Class Initialized
INFO - 2017-06-21 11:39:46 --> Database Driver Class Initialized
INFO - 2017-06-21 11:39:46 --> Model Class Initialized
INFO - 2017-06-21 11:39:46 --> Helper loaded: form_helper
INFO - 2017-06-21 11:39:46 --> Helper loaded: url_helper
INFO - 2017-06-21 11:39:46 --> Model Class Initialized
INFO - 2017-06-21 11:39:46 --> Final output sent to browser
DEBUG - 2017-06-21 11:39:46 --> Total execution time: 0.0600
ERROR - 2017-06-21 11:40:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:40:34 --> Config Class Initialized
INFO - 2017-06-21 11:40:34 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:40:34 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:40:34 --> Utf8 Class Initialized
INFO - 2017-06-21 11:40:34 --> URI Class Initialized
INFO - 2017-06-21 11:40:34 --> Router Class Initialized
INFO - 2017-06-21 11:40:34 --> Output Class Initialized
INFO - 2017-06-21 11:40:34 --> Security Class Initialized
DEBUG - 2017-06-21 11:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:40:34 --> Input Class Initialized
INFO - 2017-06-21 11:40:34 --> Language Class Initialized
INFO - 2017-06-21 11:40:34 --> Loader Class Initialized
INFO - 2017-06-21 11:40:34 --> Controller Class Initialized
INFO - 2017-06-21 11:40:34 --> Database Driver Class Initialized
INFO - 2017-06-21 11:40:34 --> Model Class Initialized
INFO - 2017-06-21 11:40:34 --> Helper loaded: form_helper
INFO - 2017-06-21 11:40:34 --> Helper loaded: url_helper
INFO - 2017-06-21 11:40:34 --> Model Class Initialized
INFO - 2017-06-21 11:40:34 --> Final output sent to browser
DEBUG - 2017-06-21 11:40:34 --> Total execution time: 0.0460
ERROR - 2017-06-21 11:40:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:40:35 --> Config Class Initialized
INFO - 2017-06-21 11:40:35 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:40:35 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:40:35 --> Utf8 Class Initialized
INFO - 2017-06-21 11:40:35 --> URI Class Initialized
INFO - 2017-06-21 11:40:35 --> Router Class Initialized
INFO - 2017-06-21 11:40:35 --> Output Class Initialized
INFO - 2017-06-21 11:40:35 --> Security Class Initialized
DEBUG - 2017-06-21 11:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:40:35 --> Input Class Initialized
INFO - 2017-06-21 11:40:35 --> Language Class Initialized
INFO - 2017-06-21 11:40:35 --> Loader Class Initialized
INFO - 2017-06-21 11:40:35 --> Controller Class Initialized
INFO - 2017-06-21 11:40:35 --> Database Driver Class Initialized
INFO - 2017-06-21 11:40:35 --> Model Class Initialized
INFO - 2017-06-21 11:40:35 --> Helper loaded: form_helper
INFO - 2017-06-21 11:40:35 --> Helper loaded: url_helper
INFO - 2017-06-21 11:40:35 --> Model Class Initialized
INFO - 2017-06-21 11:40:35 --> Final output sent to browser
DEBUG - 2017-06-21 11:40:35 --> Total execution time: 0.0560
ERROR - 2017-06-21 11:40:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:40:37 --> Config Class Initialized
INFO - 2017-06-21 11:40:37 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:40:37 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:40:37 --> Utf8 Class Initialized
INFO - 2017-06-21 11:40:37 --> URI Class Initialized
INFO - 2017-06-21 11:40:37 --> Router Class Initialized
INFO - 2017-06-21 11:40:37 --> Output Class Initialized
INFO - 2017-06-21 11:40:37 --> Security Class Initialized
DEBUG - 2017-06-21 11:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:40:37 --> Input Class Initialized
INFO - 2017-06-21 11:40:37 --> Language Class Initialized
INFO - 2017-06-21 11:40:37 --> Loader Class Initialized
INFO - 2017-06-21 11:40:37 --> Controller Class Initialized
INFO - 2017-06-21 11:40:37 --> Database Driver Class Initialized
INFO - 2017-06-21 11:40:37 --> Model Class Initialized
INFO - 2017-06-21 11:40:37 --> Helper loaded: form_helper
INFO - 2017-06-21 11:40:37 --> Helper loaded: url_helper
INFO - 2017-06-21 11:40:37 --> Model Class Initialized
INFO - 2017-06-21 11:40:37 --> Final output sent to browser
DEBUG - 2017-06-21 11:40:37 --> Total execution time: 0.0750
ERROR - 2017-06-21 11:41:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:41:10 --> Config Class Initialized
INFO - 2017-06-21 11:41:10 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:41:10 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:41:10 --> Utf8 Class Initialized
INFO - 2017-06-21 11:41:10 --> URI Class Initialized
INFO - 2017-06-21 11:41:10 --> Router Class Initialized
INFO - 2017-06-21 11:41:10 --> Output Class Initialized
INFO - 2017-06-21 11:41:10 --> Security Class Initialized
DEBUG - 2017-06-21 11:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:41:10 --> Input Class Initialized
INFO - 2017-06-21 11:41:10 --> Language Class Initialized
INFO - 2017-06-21 11:41:10 --> Loader Class Initialized
INFO - 2017-06-21 11:41:10 --> Controller Class Initialized
INFO - 2017-06-21 11:41:10 --> Database Driver Class Initialized
INFO - 2017-06-21 11:41:10 --> Model Class Initialized
INFO - 2017-06-21 11:41:10 --> Helper loaded: form_helper
INFO - 2017-06-21 11:41:10 --> Helper loaded: url_helper
INFO - 2017-06-21 11:41:10 --> Model Class Initialized
INFO - 2017-06-21 11:41:10 --> Final output sent to browser
DEBUG - 2017-06-21 11:41:10 --> Total execution time: 0.0650
ERROR - 2017-06-21 11:41:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:41:11 --> Config Class Initialized
INFO - 2017-06-21 11:41:11 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:41:11 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:41:11 --> Utf8 Class Initialized
INFO - 2017-06-21 11:41:11 --> URI Class Initialized
INFO - 2017-06-21 11:41:11 --> Router Class Initialized
INFO - 2017-06-21 11:41:11 --> Output Class Initialized
INFO - 2017-06-21 11:41:11 --> Security Class Initialized
DEBUG - 2017-06-21 11:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:41:11 --> Input Class Initialized
INFO - 2017-06-21 11:41:11 --> Language Class Initialized
INFO - 2017-06-21 11:41:11 --> Loader Class Initialized
INFO - 2017-06-21 11:41:11 --> Controller Class Initialized
INFO - 2017-06-21 11:41:11 --> Database Driver Class Initialized
INFO - 2017-06-21 11:41:11 --> Model Class Initialized
INFO - 2017-06-21 11:41:11 --> Helper loaded: form_helper
INFO - 2017-06-21 11:41:11 --> Helper loaded: url_helper
INFO - 2017-06-21 11:41:11 --> Model Class Initialized
INFO - 2017-06-21 11:41:11 --> Final output sent to browser
DEBUG - 2017-06-21 11:41:11 --> Total execution time: 0.0530
ERROR - 2017-06-21 11:41:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:41:30 --> Config Class Initialized
INFO - 2017-06-21 11:41:30 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:41:30 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:41:30 --> Utf8 Class Initialized
INFO - 2017-06-21 11:41:30 --> URI Class Initialized
INFO - 2017-06-21 11:41:30 --> Router Class Initialized
INFO - 2017-06-21 11:41:30 --> Output Class Initialized
INFO - 2017-06-21 11:41:30 --> Security Class Initialized
DEBUG - 2017-06-21 11:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:41:30 --> Input Class Initialized
INFO - 2017-06-21 11:41:30 --> Language Class Initialized
INFO - 2017-06-21 11:41:30 --> Loader Class Initialized
INFO - 2017-06-21 11:41:30 --> Controller Class Initialized
INFO - 2017-06-21 11:41:30 --> Database Driver Class Initialized
INFO - 2017-06-21 11:41:30 --> Model Class Initialized
INFO - 2017-06-21 11:41:30 --> Helper loaded: form_helper
INFO - 2017-06-21 11:41:30 --> Helper loaded: url_helper
INFO - 2017-06-21 11:41:30 --> Model Class Initialized
INFO - 2017-06-21 11:41:30 --> Final output sent to browser
DEBUG - 2017-06-21 11:41:30 --> Total execution time: 0.0500
ERROR - 2017-06-21 11:41:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:41:47 --> Config Class Initialized
INFO - 2017-06-21 11:41:47 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:41:47 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:41:47 --> Utf8 Class Initialized
INFO - 2017-06-21 11:41:47 --> URI Class Initialized
INFO - 2017-06-21 11:41:47 --> Router Class Initialized
INFO - 2017-06-21 11:41:47 --> Output Class Initialized
INFO - 2017-06-21 11:41:47 --> Security Class Initialized
DEBUG - 2017-06-21 11:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:41:47 --> Input Class Initialized
INFO - 2017-06-21 11:41:47 --> Language Class Initialized
INFO - 2017-06-21 11:41:47 --> Loader Class Initialized
INFO - 2017-06-21 11:41:47 --> Controller Class Initialized
INFO - 2017-06-21 11:41:47 --> Database Driver Class Initialized
INFO - 2017-06-21 11:41:47 --> Model Class Initialized
INFO - 2017-06-21 11:41:47 --> Helper loaded: form_helper
INFO - 2017-06-21 11:41:47 --> Helper loaded: url_helper
INFO - 2017-06-21 11:41:47 --> Model Class Initialized
INFO - 2017-06-21 11:41:47 --> Final output sent to browser
DEBUG - 2017-06-21 11:41:47 --> Total execution time: 0.0440
ERROR - 2017-06-21 11:41:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:41:48 --> Config Class Initialized
INFO - 2017-06-21 11:41:48 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:41:48 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:41:48 --> Utf8 Class Initialized
INFO - 2017-06-21 11:41:48 --> URI Class Initialized
INFO - 2017-06-21 11:41:48 --> Router Class Initialized
INFO - 2017-06-21 11:41:48 --> Output Class Initialized
INFO - 2017-06-21 11:41:48 --> Security Class Initialized
DEBUG - 2017-06-21 11:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:41:48 --> Input Class Initialized
INFO - 2017-06-21 11:41:48 --> Language Class Initialized
INFO - 2017-06-21 11:41:48 --> Loader Class Initialized
INFO - 2017-06-21 11:41:48 --> Controller Class Initialized
INFO - 2017-06-21 11:41:48 --> Database Driver Class Initialized
INFO - 2017-06-21 11:41:48 --> Model Class Initialized
INFO - 2017-06-21 11:41:48 --> Helper loaded: form_helper
INFO - 2017-06-21 11:41:48 --> Helper loaded: url_helper
INFO - 2017-06-21 11:41:48 --> Model Class Initialized
INFO - 2017-06-21 11:41:48 --> Final output sent to browser
DEBUG - 2017-06-21 11:41:48 --> Total execution time: 0.0570
ERROR - 2017-06-21 11:42:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:42:04 --> Config Class Initialized
INFO - 2017-06-21 11:42:04 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:42:04 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:42:04 --> Utf8 Class Initialized
INFO - 2017-06-21 11:42:04 --> URI Class Initialized
INFO - 2017-06-21 11:42:04 --> Router Class Initialized
INFO - 2017-06-21 11:42:04 --> Output Class Initialized
INFO - 2017-06-21 11:42:04 --> Security Class Initialized
DEBUG - 2017-06-21 11:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:42:04 --> Input Class Initialized
INFO - 2017-06-21 11:42:04 --> Language Class Initialized
INFO - 2017-06-21 11:42:04 --> Loader Class Initialized
INFO - 2017-06-21 11:42:04 --> Controller Class Initialized
INFO - 2017-06-21 11:42:04 --> Database Driver Class Initialized
INFO - 2017-06-21 11:42:04 --> Model Class Initialized
INFO - 2017-06-21 11:42:04 --> Helper loaded: form_helper
INFO - 2017-06-21 11:42:04 --> Helper loaded: url_helper
INFO - 2017-06-21 11:42:04 --> Model Class Initialized
INFO - 2017-06-21 11:42:04 --> Final output sent to browser
DEBUG - 2017-06-21 11:42:04 --> Total execution time: 0.0490
ERROR - 2017-06-21 11:42:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:42:15 --> Config Class Initialized
INFO - 2017-06-21 11:42:15 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:42:15 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:42:15 --> Utf8 Class Initialized
INFO - 2017-06-21 11:42:15 --> URI Class Initialized
INFO - 2017-06-21 11:42:15 --> Router Class Initialized
INFO - 2017-06-21 11:42:15 --> Output Class Initialized
INFO - 2017-06-21 11:42:15 --> Security Class Initialized
DEBUG - 2017-06-21 11:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:42:15 --> Input Class Initialized
INFO - 2017-06-21 11:42:15 --> Language Class Initialized
INFO - 2017-06-21 11:42:15 --> Loader Class Initialized
INFO - 2017-06-21 11:42:15 --> Controller Class Initialized
INFO - 2017-06-21 11:42:15 --> Database Driver Class Initialized
INFO - 2017-06-21 11:42:15 --> Model Class Initialized
INFO - 2017-06-21 11:42:15 --> Helper loaded: form_helper
INFO - 2017-06-21 11:42:15 --> Helper loaded: url_helper
INFO - 2017-06-21 11:42:15 --> Model Class Initialized
INFO - 2017-06-21 11:42:15 --> Final output sent to browser
DEBUG - 2017-06-21 11:42:15 --> Total execution time: 0.0490
ERROR - 2017-06-21 11:42:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:42:16 --> Config Class Initialized
INFO - 2017-06-21 11:42:16 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:42:16 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:42:16 --> Utf8 Class Initialized
INFO - 2017-06-21 11:42:16 --> URI Class Initialized
INFO - 2017-06-21 11:42:16 --> Router Class Initialized
INFO - 2017-06-21 11:42:16 --> Output Class Initialized
INFO - 2017-06-21 11:42:16 --> Security Class Initialized
DEBUG - 2017-06-21 11:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:42:16 --> Input Class Initialized
INFO - 2017-06-21 11:42:16 --> Language Class Initialized
INFO - 2017-06-21 11:42:16 --> Loader Class Initialized
INFO - 2017-06-21 11:42:16 --> Controller Class Initialized
INFO - 2017-06-21 11:42:16 --> Database Driver Class Initialized
INFO - 2017-06-21 11:42:16 --> Model Class Initialized
INFO - 2017-06-21 11:42:16 --> Helper loaded: form_helper
INFO - 2017-06-21 11:42:16 --> Helper loaded: url_helper
INFO - 2017-06-21 11:42:16 --> Model Class Initialized
INFO - 2017-06-21 11:42:16 --> Final output sent to browser
DEBUG - 2017-06-21 11:42:16 --> Total execution time: 0.0440
ERROR - 2017-06-21 11:42:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:42:35 --> Config Class Initialized
INFO - 2017-06-21 11:42:35 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:42:35 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:42:35 --> Utf8 Class Initialized
INFO - 2017-06-21 11:42:35 --> URI Class Initialized
INFO - 2017-06-21 11:42:35 --> Router Class Initialized
INFO - 2017-06-21 11:42:35 --> Output Class Initialized
INFO - 2017-06-21 11:42:35 --> Security Class Initialized
DEBUG - 2017-06-21 11:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:42:35 --> Input Class Initialized
INFO - 2017-06-21 11:42:35 --> Language Class Initialized
INFO - 2017-06-21 11:42:35 --> Loader Class Initialized
INFO - 2017-06-21 11:42:35 --> Controller Class Initialized
INFO - 2017-06-21 11:42:35 --> Database Driver Class Initialized
INFO - 2017-06-21 11:42:35 --> Model Class Initialized
INFO - 2017-06-21 11:42:35 --> Helper loaded: form_helper
INFO - 2017-06-21 11:42:35 --> Helper loaded: url_helper
INFO - 2017-06-21 11:42:35 --> Model Class Initialized
INFO - 2017-06-21 11:42:35 --> Final output sent to browser
DEBUG - 2017-06-21 11:42:35 --> Total execution time: 0.0440
ERROR - 2017-06-21 11:43:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:43:15 --> Config Class Initialized
INFO - 2017-06-21 11:43:15 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:43:15 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:43:15 --> Utf8 Class Initialized
INFO - 2017-06-21 11:43:15 --> URI Class Initialized
INFO - 2017-06-21 11:43:15 --> Router Class Initialized
INFO - 2017-06-21 11:43:15 --> Output Class Initialized
INFO - 2017-06-21 11:43:15 --> Security Class Initialized
DEBUG - 2017-06-21 11:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:43:15 --> Input Class Initialized
INFO - 2017-06-21 11:43:15 --> Language Class Initialized
INFO - 2017-06-21 11:43:15 --> Loader Class Initialized
INFO - 2017-06-21 11:43:15 --> Controller Class Initialized
INFO - 2017-06-21 11:43:15 --> Database Driver Class Initialized
INFO - 2017-06-21 11:43:15 --> Model Class Initialized
INFO - 2017-06-21 11:43:15 --> Helper loaded: form_helper
INFO - 2017-06-21 11:43:15 --> Helper loaded: url_helper
INFO - 2017-06-21 11:43:15 --> Model Class Initialized
INFO - 2017-06-21 11:43:15 --> Final output sent to browser
DEBUG - 2017-06-21 11:43:15 --> Total execution time: 0.0490
ERROR - 2017-06-21 11:43:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:43:16 --> Config Class Initialized
INFO - 2017-06-21 11:43:16 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:43:16 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:43:16 --> Utf8 Class Initialized
INFO - 2017-06-21 11:43:16 --> URI Class Initialized
INFO - 2017-06-21 11:43:16 --> Router Class Initialized
INFO - 2017-06-21 11:43:16 --> Output Class Initialized
INFO - 2017-06-21 11:43:16 --> Security Class Initialized
DEBUG - 2017-06-21 11:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:43:16 --> Input Class Initialized
INFO - 2017-06-21 11:43:16 --> Language Class Initialized
INFO - 2017-06-21 11:43:16 --> Loader Class Initialized
INFO - 2017-06-21 11:43:16 --> Controller Class Initialized
INFO - 2017-06-21 11:43:16 --> Database Driver Class Initialized
INFO - 2017-06-21 11:43:16 --> Model Class Initialized
INFO - 2017-06-21 11:43:16 --> Helper loaded: form_helper
INFO - 2017-06-21 11:43:16 --> Helper loaded: url_helper
INFO - 2017-06-21 11:43:16 --> Model Class Initialized
INFO - 2017-06-21 11:43:16 --> Final output sent to browser
DEBUG - 2017-06-21 11:43:16 --> Total execution time: 0.0440
ERROR - 2017-06-21 11:48:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:48:23 --> Config Class Initialized
INFO - 2017-06-21 11:48:23 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:48:23 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:48:23 --> Utf8 Class Initialized
INFO - 2017-06-21 11:48:23 --> URI Class Initialized
INFO - 2017-06-21 11:48:23 --> Router Class Initialized
INFO - 2017-06-21 11:48:23 --> Output Class Initialized
INFO - 2017-06-21 11:48:23 --> Security Class Initialized
DEBUG - 2017-06-21 11:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:48:23 --> Input Class Initialized
INFO - 2017-06-21 11:48:23 --> Language Class Initialized
INFO - 2017-06-21 11:48:23 --> Loader Class Initialized
INFO - 2017-06-21 11:48:23 --> Controller Class Initialized
INFO - 2017-06-21 11:48:23 --> Database Driver Class Initialized
INFO - 2017-06-21 11:48:23 --> Model Class Initialized
INFO - 2017-06-21 11:48:23 --> Helper loaded: form_helper
INFO - 2017-06-21 11:48:23 --> Helper loaded: url_helper
INFO - 2017-06-21 11:48:23 --> Model Class Initialized
INFO - 2017-06-21 11:48:23 --> Final output sent to browser
DEBUG - 2017-06-21 11:48:23 --> Total execution time: 0.0550
ERROR - 2017-06-21 11:48:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:48:24 --> Config Class Initialized
INFO - 2017-06-21 11:48:24 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:48:24 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:48:25 --> Utf8 Class Initialized
INFO - 2017-06-21 11:48:25 --> URI Class Initialized
INFO - 2017-06-21 11:48:25 --> Router Class Initialized
INFO - 2017-06-21 11:48:25 --> Output Class Initialized
INFO - 2017-06-21 11:48:25 --> Security Class Initialized
DEBUG - 2017-06-21 11:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:48:25 --> Input Class Initialized
INFO - 2017-06-21 11:48:25 --> Language Class Initialized
INFO - 2017-06-21 11:48:25 --> Loader Class Initialized
INFO - 2017-06-21 11:48:25 --> Controller Class Initialized
INFO - 2017-06-21 11:48:25 --> Database Driver Class Initialized
INFO - 2017-06-21 11:48:25 --> Model Class Initialized
INFO - 2017-06-21 11:48:25 --> Helper loaded: form_helper
INFO - 2017-06-21 11:48:25 --> Helper loaded: url_helper
INFO - 2017-06-21 11:48:25 --> Model Class Initialized
INFO - 2017-06-21 11:48:25 --> Final output sent to browser
DEBUG - 2017-06-21 11:48:25 --> Total execution time: 0.0530
ERROR - 2017-06-21 11:48:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:48:26 --> Config Class Initialized
INFO - 2017-06-21 11:48:26 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:48:26 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:48:26 --> Utf8 Class Initialized
INFO - 2017-06-21 11:48:26 --> URI Class Initialized
INFO - 2017-06-21 11:48:26 --> Router Class Initialized
INFO - 2017-06-21 11:48:26 --> Output Class Initialized
INFO - 2017-06-21 11:48:26 --> Security Class Initialized
DEBUG - 2017-06-21 11:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:48:26 --> Input Class Initialized
INFO - 2017-06-21 11:48:26 --> Language Class Initialized
INFO - 2017-06-21 11:48:26 --> Loader Class Initialized
INFO - 2017-06-21 11:48:26 --> Controller Class Initialized
INFO - 2017-06-21 11:48:26 --> Database Driver Class Initialized
INFO - 2017-06-21 11:48:26 --> Model Class Initialized
INFO - 2017-06-21 11:48:26 --> Helper loaded: form_helper
INFO - 2017-06-21 11:48:26 --> Helper loaded: url_helper
INFO - 2017-06-21 11:48:26 --> Model Class Initialized
INFO - 2017-06-21 11:48:26 --> Final output sent to browser
DEBUG - 2017-06-21 11:48:26 --> Total execution time: 0.0450
ERROR - 2017-06-21 11:48:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:48:55 --> Config Class Initialized
INFO - 2017-06-21 11:48:55 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:48:55 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:48:55 --> Utf8 Class Initialized
INFO - 2017-06-21 11:48:55 --> URI Class Initialized
INFO - 2017-06-21 11:48:55 --> Router Class Initialized
INFO - 2017-06-21 11:48:55 --> Output Class Initialized
INFO - 2017-06-21 11:48:55 --> Security Class Initialized
DEBUG - 2017-06-21 11:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:48:55 --> Input Class Initialized
INFO - 2017-06-21 11:48:55 --> Language Class Initialized
INFO - 2017-06-21 11:48:55 --> Loader Class Initialized
INFO - 2017-06-21 11:48:55 --> Controller Class Initialized
INFO - 2017-06-21 11:48:55 --> Database Driver Class Initialized
INFO - 2017-06-21 11:48:55 --> Model Class Initialized
INFO - 2017-06-21 11:48:55 --> Helper loaded: form_helper
INFO - 2017-06-21 11:48:55 --> Helper loaded: url_helper
INFO - 2017-06-21 11:48:55 --> Model Class Initialized
INFO - 2017-06-21 11:48:55 --> Final output sent to browser
DEBUG - 2017-06-21 11:48:55 --> Total execution time: 0.0530
ERROR - 2017-06-21 11:49:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:49:03 --> Config Class Initialized
INFO - 2017-06-21 11:49:03 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:49:03 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:49:03 --> Utf8 Class Initialized
INFO - 2017-06-21 11:49:03 --> URI Class Initialized
INFO - 2017-06-21 11:49:03 --> Router Class Initialized
INFO - 2017-06-21 11:49:03 --> Output Class Initialized
INFO - 2017-06-21 11:49:03 --> Security Class Initialized
DEBUG - 2017-06-21 11:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:49:03 --> Input Class Initialized
INFO - 2017-06-21 11:49:03 --> Language Class Initialized
INFO - 2017-06-21 11:49:03 --> Loader Class Initialized
INFO - 2017-06-21 11:49:03 --> Controller Class Initialized
INFO - 2017-06-21 11:49:03 --> Database Driver Class Initialized
INFO - 2017-06-21 11:49:03 --> Model Class Initialized
INFO - 2017-06-21 11:49:03 --> Helper loaded: form_helper
INFO - 2017-06-21 11:49:03 --> Helper loaded: url_helper
INFO - 2017-06-21 11:49:03 --> Model Class Initialized
INFO - 2017-06-21 11:49:03 --> Final output sent to browser
DEBUG - 2017-06-21 11:49:03 --> Total execution time: 0.0495
ERROR - 2017-06-21 11:49:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:49:25 --> Config Class Initialized
INFO - 2017-06-21 11:49:25 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:49:25 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:49:25 --> Utf8 Class Initialized
INFO - 2017-06-21 11:49:25 --> URI Class Initialized
INFO - 2017-06-21 11:49:25 --> Router Class Initialized
INFO - 2017-06-21 11:49:25 --> Output Class Initialized
INFO - 2017-06-21 11:49:25 --> Security Class Initialized
DEBUG - 2017-06-21 11:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:49:25 --> Input Class Initialized
INFO - 2017-06-21 11:49:25 --> Language Class Initialized
INFO - 2017-06-21 11:49:25 --> Loader Class Initialized
INFO - 2017-06-21 11:49:25 --> Controller Class Initialized
INFO - 2017-06-21 11:49:25 --> Database Driver Class Initialized
INFO - 2017-06-21 11:49:25 --> Model Class Initialized
INFO - 2017-06-21 11:49:25 --> Helper loaded: form_helper
INFO - 2017-06-21 11:49:25 --> Helper loaded: url_helper
INFO - 2017-06-21 11:49:25 --> Model Class Initialized
INFO - 2017-06-21 11:49:25 --> Final output sent to browser
DEBUG - 2017-06-21 11:49:25 --> Total execution time: 0.0550
ERROR - 2017-06-21 11:50:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:50:29 --> Config Class Initialized
INFO - 2017-06-21 11:50:29 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:50:29 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:50:29 --> Utf8 Class Initialized
INFO - 2017-06-21 11:50:29 --> URI Class Initialized
INFO - 2017-06-21 11:50:29 --> Router Class Initialized
INFO - 2017-06-21 11:50:29 --> Output Class Initialized
INFO - 2017-06-21 11:50:29 --> Security Class Initialized
DEBUG - 2017-06-21 11:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:50:29 --> Input Class Initialized
INFO - 2017-06-21 11:50:29 --> Language Class Initialized
INFO - 2017-06-21 11:50:29 --> Loader Class Initialized
INFO - 2017-06-21 11:50:29 --> Controller Class Initialized
INFO - 2017-06-21 11:50:29 --> Database Driver Class Initialized
INFO - 2017-06-21 11:50:29 --> Model Class Initialized
INFO - 2017-06-21 11:50:30 --> Helper loaded: form_helper
INFO - 2017-06-21 11:50:30 --> Helper loaded: url_helper
INFO - 2017-06-21 11:50:30 --> Model Class Initialized
INFO - 2017-06-21 11:50:30 --> Final output sent to browser
DEBUG - 2017-06-21 11:50:30 --> Total execution time: 0.0620
ERROR - 2017-06-21 11:50:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 11:50:30 --> Config Class Initialized
INFO - 2017-06-21 11:50:30 --> Hooks Class Initialized
DEBUG - 2017-06-21 11:50:30 --> UTF-8 Support Enabled
INFO - 2017-06-21 11:50:30 --> Utf8 Class Initialized
INFO - 2017-06-21 11:50:30 --> URI Class Initialized
INFO - 2017-06-21 11:50:30 --> Router Class Initialized
INFO - 2017-06-21 11:50:30 --> Output Class Initialized
INFO - 2017-06-21 11:50:30 --> Security Class Initialized
DEBUG - 2017-06-21 11:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 11:50:30 --> Input Class Initialized
INFO - 2017-06-21 11:50:30 --> Language Class Initialized
INFO - 2017-06-21 11:50:30 --> Loader Class Initialized
INFO - 2017-06-21 11:50:30 --> Controller Class Initialized
INFO - 2017-06-21 11:50:30 --> Database Driver Class Initialized
INFO - 2017-06-21 11:50:30 --> Model Class Initialized
INFO - 2017-06-21 11:50:31 --> Helper loaded: form_helper
INFO - 2017-06-21 11:50:31 --> Helper loaded: url_helper
INFO - 2017-06-21 11:50:31 --> Model Class Initialized
INFO - 2017-06-21 11:50:31 --> Final output sent to browser
DEBUG - 2017-06-21 11:50:31 --> Total execution time: 0.0590
ERROR - 2017-06-21 12:00:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 12:00:20 --> Config Class Initialized
INFO - 2017-06-21 12:00:20 --> Hooks Class Initialized
DEBUG - 2017-06-21 12:00:20 --> UTF-8 Support Enabled
INFO - 2017-06-21 12:00:20 --> Utf8 Class Initialized
INFO - 2017-06-21 12:00:20 --> URI Class Initialized
INFO - 2017-06-21 12:00:20 --> Router Class Initialized
INFO - 2017-06-21 12:00:20 --> Output Class Initialized
INFO - 2017-06-21 12:00:20 --> Security Class Initialized
DEBUG - 2017-06-21 12:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 12:00:20 --> Input Class Initialized
INFO - 2017-06-21 12:00:20 --> Language Class Initialized
INFO - 2017-06-21 12:00:20 --> Loader Class Initialized
INFO - 2017-06-21 12:00:20 --> Controller Class Initialized
INFO - 2017-06-21 12:00:20 --> Database Driver Class Initialized
INFO - 2017-06-21 12:00:20 --> Model Class Initialized
INFO - 2017-06-21 12:00:20 --> Helper loaded: form_helper
INFO - 2017-06-21 12:00:20 --> Helper loaded: url_helper
INFO - 2017-06-21 12:00:20 --> Model Class Initialized
INFO - 2017-06-21 12:00:20 --> Final output sent to browser
DEBUG - 2017-06-21 12:00:20 --> Total execution time: 0.0490
ERROR - 2017-06-21 12:02:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 12:02:40 --> Config Class Initialized
INFO - 2017-06-21 12:02:40 --> Hooks Class Initialized
DEBUG - 2017-06-21 12:02:40 --> UTF-8 Support Enabled
INFO - 2017-06-21 12:02:40 --> Utf8 Class Initialized
INFO - 2017-06-21 12:02:40 --> URI Class Initialized
INFO - 2017-06-21 12:02:40 --> Router Class Initialized
INFO - 2017-06-21 12:02:40 --> Output Class Initialized
INFO - 2017-06-21 12:02:40 --> Security Class Initialized
DEBUG - 2017-06-21 12:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 12:02:40 --> Input Class Initialized
INFO - 2017-06-21 12:02:40 --> Language Class Initialized
INFO - 2017-06-21 12:02:40 --> Loader Class Initialized
INFO - 2017-06-21 12:02:40 --> Controller Class Initialized
INFO - 2017-06-21 12:02:40 --> Database Driver Class Initialized
INFO - 2017-06-21 12:02:40 --> Model Class Initialized
INFO - 2017-06-21 12:02:40 --> Helper loaded: form_helper
INFO - 2017-06-21 12:02:40 --> Helper loaded: url_helper
INFO - 2017-06-21 12:02:40 --> Model Class Initialized
INFO - 2017-06-21 12:02:40 --> Final output sent to browser
DEBUG - 2017-06-21 12:02:40 --> Total execution time: 0.0460
ERROR - 2017-06-21 12:02:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 12:02:40 --> Config Class Initialized
INFO - 2017-06-21 12:02:40 --> Hooks Class Initialized
DEBUG - 2017-06-21 12:02:40 --> UTF-8 Support Enabled
INFO - 2017-06-21 12:02:40 --> Utf8 Class Initialized
INFO - 2017-06-21 12:02:40 --> URI Class Initialized
INFO - 2017-06-21 12:02:40 --> Router Class Initialized
INFO - 2017-06-21 12:02:40 --> Output Class Initialized
INFO - 2017-06-21 12:02:40 --> Security Class Initialized
DEBUG - 2017-06-21 12:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 12:02:40 --> Input Class Initialized
INFO - 2017-06-21 12:02:40 --> Language Class Initialized
INFO - 2017-06-21 12:02:40 --> Loader Class Initialized
INFO - 2017-06-21 12:02:40 --> Controller Class Initialized
INFO - 2017-06-21 12:02:40 --> Database Driver Class Initialized
INFO - 2017-06-21 12:02:40 --> Model Class Initialized
INFO - 2017-06-21 12:02:40 --> Helper loaded: form_helper
INFO - 2017-06-21 12:02:40 --> Helper loaded: url_helper
INFO - 2017-06-21 12:02:40 --> Model Class Initialized
INFO - 2017-06-21 12:02:40 --> Final output sent to browser
DEBUG - 2017-06-21 12:02:40 --> Total execution time: 0.0440
ERROR - 2017-06-21 12:02:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 12:02:46 --> Config Class Initialized
INFO - 2017-06-21 12:02:46 --> Hooks Class Initialized
DEBUG - 2017-06-21 12:02:46 --> UTF-8 Support Enabled
INFO - 2017-06-21 12:02:46 --> Utf8 Class Initialized
INFO - 2017-06-21 12:02:46 --> URI Class Initialized
INFO - 2017-06-21 12:02:46 --> Router Class Initialized
INFO - 2017-06-21 12:02:46 --> Output Class Initialized
INFO - 2017-06-21 12:02:46 --> Security Class Initialized
DEBUG - 2017-06-21 12:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 12:02:46 --> Input Class Initialized
INFO - 2017-06-21 12:02:46 --> Language Class Initialized
INFO - 2017-06-21 12:02:46 --> Loader Class Initialized
INFO - 2017-06-21 12:02:46 --> Controller Class Initialized
INFO - 2017-06-21 12:02:46 --> Database Driver Class Initialized
INFO - 2017-06-21 12:02:46 --> Model Class Initialized
INFO - 2017-06-21 12:02:46 --> Helper loaded: form_helper
INFO - 2017-06-21 12:02:46 --> Helper loaded: url_helper
INFO - 2017-06-21 12:02:46 --> Model Class Initialized
INFO - 2017-06-21 12:02:46 --> Final output sent to browser
DEBUG - 2017-06-21 12:02:46 --> Total execution time: 0.0680
ERROR - 2017-06-21 12:03:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 12:03:08 --> Config Class Initialized
INFO - 2017-06-21 12:03:08 --> Hooks Class Initialized
DEBUG - 2017-06-21 12:03:08 --> UTF-8 Support Enabled
INFO - 2017-06-21 12:03:08 --> Utf8 Class Initialized
INFO - 2017-06-21 12:03:08 --> URI Class Initialized
INFO - 2017-06-21 12:03:08 --> Router Class Initialized
INFO - 2017-06-21 12:03:08 --> Output Class Initialized
INFO - 2017-06-21 12:03:08 --> Security Class Initialized
DEBUG - 2017-06-21 12:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 12:03:08 --> Input Class Initialized
INFO - 2017-06-21 12:03:08 --> Language Class Initialized
INFO - 2017-06-21 12:03:08 --> Loader Class Initialized
INFO - 2017-06-21 12:03:08 --> Controller Class Initialized
INFO - 2017-06-21 12:03:08 --> Database Driver Class Initialized
INFO - 2017-06-21 12:03:08 --> Model Class Initialized
INFO - 2017-06-21 12:03:08 --> Helper loaded: form_helper
INFO - 2017-06-21 12:03:08 --> Helper loaded: url_helper
INFO - 2017-06-21 12:03:08 --> Model Class Initialized
INFO - 2017-06-21 12:03:08 --> Final output sent to browser
DEBUG - 2017-06-21 12:03:08 --> Total execution time: 0.0470
ERROR - 2017-06-21 12:03:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 12:03:49 --> Config Class Initialized
INFO - 2017-06-21 12:03:49 --> Hooks Class Initialized
DEBUG - 2017-06-21 12:03:49 --> UTF-8 Support Enabled
INFO - 2017-06-21 12:03:49 --> Utf8 Class Initialized
INFO - 2017-06-21 12:03:49 --> URI Class Initialized
INFO - 2017-06-21 12:03:49 --> Router Class Initialized
INFO - 2017-06-21 12:03:49 --> Output Class Initialized
INFO - 2017-06-21 12:03:49 --> Security Class Initialized
DEBUG - 2017-06-21 12:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 12:03:49 --> Input Class Initialized
INFO - 2017-06-21 12:03:49 --> Language Class Initialized
INFO - 2017-06-21 12:03:49 --> Loader Class Initialized
INFO - 2017-06-21 12:03:49 --> Controller Class Initialized
INFO - 2017-06-21 12:03:49 --> Database Driver Class Initialized
INFO - 2017-06-21 12:03:49 --> Model Class Initialized
INFO - 2017-06-21 12:03:49 --> Helper loaded: form_helper
INFO - 2017-06-21 12:03:49 --> Helper loaded: url_helper
INFO - 2017-06-21 12:03:49 --> Model Class Initialized
INFO - 2017-06-21 12:03:49 --> Final output sent to browser
DEBUG - 2017-06-21 12:03:49 --> Total execution time: 0.0440
ERROR - 2017-06-21 12:03:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 12:03:54 --> Config Class Initialized
INFO - 2017-06-21 12:03:54 --> Hooks Class Initialized
DEBUG - 2017-06-21 12:03:54 --> UTF-8 Support Enabled
INFO - 2017-06-21 12:03:54 --> Utf8 Class Initialized
INFO - 2017-06-21 12:03:54 --> URI Class Initialized
INFO - 2017-06-21 12:03:54 --> Router Class Initialized
INFO - 2017-06-21 12:03:54 --> Output Class Initialized
INFO - 2017-06-21 12:03:54 --> Security Class Initialized
DEBUG - 2017-06-21 12:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 12:03:54 --> Input Class Initialized
INFO - 2017-06-21 12:03:54 --> Language Class Initialized
INFO - 2017-06-21 12:03:54 --> Loader Class Initialized
INFO - 2017-06-21 12:03:54 --> Controller Class Initialized
INFO - 2017-06-21 12:03:54 --> Database Driver Class Initialized
INFO - 2017-06-21 12:03:54 --> Model Class Initialized
INFO - 2017-06-21 12:03:54 --> Helper loaded: form_helper
INFO - 2017-06-21 12:03:54 --> Helper loaded: url_helper
INFO - 2017-06-21 12:03:54 --> Model Class Initialized
INFO - 2017-06-21 12:03:54 --> Final output sent to browser
DEBUG - 2017-06-21 12:03:54 --> Total execution time: 0.0620
ERROR - 2017-06-21 12:04:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 12:04:10 --> Config Class Initialized
INFO - 2017-06-21 12:04:10 --> Hooks Class Initialized
DEBUG - 2017-06-21 12:04:10 --> UTF-8 Support Enabled
INFO - 2017-06-21 12:04:10 --> Utf8 Class Initialized
INFO - 2017-06-21 12:04:10 --> URI Class Initialized
INFO - 2017-06-21 12:04:10 --> Router Class Initialized
INFO - 2017-06-21 12:04:10 --> Output Class Initialized
INFO - 2017-06-21 12:04:10 --> Security Class Initialized
DEBUG - 2017-06-21 12:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 12:04:10 --> Input Class Initialized
INFO - 2017-06-21 12:04:10 --> Language Class Initialized
INFO - 2017-06-21 12:04:10 --> Loader Class Initialized
INFO - 2017-06-21 12:04:10 --> Controller Class Initialized
INFO - 2017-06-21 12:04:10 --> Database Driver Class Initialized
INFO - 2017-06-21 12:04:10 --> Model Class Initialized
INFO - 2017-06-21 12:04:10 --> Helper loaded: form_helper
INFO - 2017-06-21 12:04:10 --> Helper loaded: url_helper
INFO - 2017-06-21 12:04:10 --> Model Class Initialized
INFO - 2017-06-21 12:04:10 --> Final output sent to browser
DEBUG - 2017-06-21 12:04:10 --> Total execution time: 0.0560
ERROR - 2017-06-21 12:04:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 12:04:27 --> Config Class Initialized
INFO - 2017-06-21 12:04:27 --> Hooks Class Initialized
DEBUG - 2017-06-21 12:04:27 --> UTF-8 Support Enabled
INFO - 2017-06-21 12:04:27 --> Utf8 Class Initialized
INFO - 2017-06-21 12:04:27 --> URI Class Initialized
INFO - 2017-06-21 12:04:27 --> Router Class Initialized
INFO - 2017-06-21 12:04:27 --> Output Class Initialized
INFO - 2017-06-21 12:04:27 --> Security Class Initialized
DEBUG - 2017-06-21 12:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 12:04:27 --> Input Class Initialized
INFO - 2017-06-21 12:04:27 --> Language Class Initialized
INFO - 2017-06-21 12:04:27 --> Loader Class Initialized
INFO - 2017-06-21 12:04:27 --> Controller Class Initialized
INFO - 2017-06-21 12:04:27 --> Database Driver Class Initialized
INFO - 2017-06-21 12:04:27 --> Model Class Initialized
INFO - 2017-06-21 12:04:27 --> Helper loaded: form_helper
INFO - 2017-06-21 12:04:27 --> Helper loaded: url_helper
INFO - 2017-06-21 12:04:27 --> Model Class Initialized
INFO - 2017-06-21 12:04:27 --> Final output sent to browser
DEBUG - 2017-06-21 12:04:27 --> Total execution time: 0.0470
ERROR - 2017-06-21 12:07:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 12:07:02 --> Config Class Initialized
INFO - 2017-06-21 12:07:02 --> Hooks Class Initialized
DEBUG - 2017-06-21 12:07:02 --> UTF-8 Support Enabled
INFO - 2017-06-21 12:07:02 --> Utf8 Class Initialized
INFO - 2017-06-21 12:07:02 --> URI Class Initialized
INFO - 2017-06-21 12:07:02 --> Router Class Initialized
INFO - 2017-06-21 12:07:02 --> Output Class Initialized
INFO - 2017-06-21 12:07:02 --> Security Class Initialized
DEBUG - 2017-06-21 12:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 12:07:02 --> Input Class Initialized
INFO - 2017-06-21 12:07:02 --> Language Class Initialized
INFO - 2017-06-21 12:07:02 --> Loader Class Initialized
INFO - 2017-06-21 12:07:02 --> Controller Class Initialized
INFO - 2017-06-21 12:07:02 --> Database Driver Class Initialized
INFO - 2017-06-21 12:07:02 --> Model Class Initialized
INFO - 2017-06-21 12:07:02 --> Helper loaded: form_helper
INFO - 2017-06-21 12:07:02 --> Helper loaded: url_helper
INFO - 2017-06-21 12:07:02 --> Model Class Initialized
INFO - 2017-06-21 12:07:02 --> Final output sent to browser
DEBUG - 2017-06-21 12:07:02 --> Total execution time: 0.0570
ERROR - 2017-06-21 12:28:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 12:28:47 --> Config Class Initialized
INFO - 2017-06-21 12:28:47 --> Hooks Class Initialized
DEBUG - 2017-06-21 12:28:47 --> UTF-8 Support Enabled
INFO - 2017-06-21 12:28:47 --> Utf8 Class Initialized
INFO - 2017-06-21 12:28:47 --> URI Class Initialized
INFO - 2017-06-21 12:28:47 --> Router Class Initialized
INFO - 2017-06-21 12:28:47 --> Output Class Initialized
INFO - 2017-06-21 12:28:47 --> Security Class Initialized
DEBUG - 2017-06-21 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 12:28:47 --> Input Class Initialized
INFO - 2017-06-21 12:28:47 --> Language Class Initialized
INFO - 2017-06-21 12:28:47 --> Loader Class Initialized
INFO - 2017-06-21 12:28:47 --> Controller Class Initialized
INFO - 2017-06-21 12:28:47 --> Database Driver Class Initialized
INFO - 2017-06-21 12:28:47 --> Model Class Initialized
INFO - 2017-06-21 12:28:47 --> Helper loaded: form_helper
INFO - 2017-06-21 12:28:47 --> Helper loaded: url_helper
INFO - 2017-06-21 12:28:47 --> Model Class Initialized
INFO - 2017-06-21 12:28:47 --> Final output sent to browser
DEBUG - 2017-06-21 12:28:47 --> Total execution time: 0.0490
ERROR - 2017-06-21 12:44:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 12:44:59 --> Config Class Initialized
INFO - 2017-06-21 12:44:59 --> Hooks Class Initialized
DEBUG - 2017-06-21 12:44:59 --> UTF-8 Support Enabled
INFO - 2017-06-21 12:44:59 --> Utf8 Class Initialized
INFO - 2017-06-21 12:44:59 --> URI Class Initialized
INFO - 2017-06-21 12:44:59 --> Router Class Initialized
INFO - 2017-06-21 12:44:59 --> Output Class Initialized
INFO - 2017-06-21 12:44:59 --> Security Class Initialized
DEBUG - 2017-06-21 12:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 12:44:59 --> Input Class Initialized
INFO - 2017-06-21 12:44:59 --> Language Class Initialized
INFO - 2017-06-21 12:44:59 --> Loader Class Initialized
INFO - 2017-06-21 12:44:59 --> Controller Class Initialized
INFO - 2017-06-21 12:44:59 --> Database Driver Class Initialized
INFO - 2017-06-21 12:44:59 --> Model Class Initialized
INFO - 2017-06-21 12:44:59 --> Helper loaded: form_helper
INFO - 2017-06-21 12:44:59 --> Helper loaded: url_helper
INFO - 2017-06-21 12:44:59 --> Model Class Initialized
INFO - 2017-06-21 12:44:59 --> Final output sent to browser
DEBUG - 2017-06-21 12:44:59 --> Total execution time: 0.0530
ERROR - 2017-06-21 12:45:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 12:45:00 --> Config Class Initialized
INFO - 2017-06-21 12:45:00 --> Hooks Class Initialized
DEBUG - 2017-06-21 12:45:00 --> UTF-8 Support Enabled
INFO - 2017-06-21 12:45:00 --> Utf8 Class Initialized
INFO - 2017-06-21 12:45:00 --> URI Class Initialized
INFO - 2017-06-21 12:45:00 --> Router Class Initialized
INFO - 2017-06-21 12:45:00 --> Output Class Initialized
INFO - 2017-06-21 12:45:00 --> Security Class Initialized
DEBUG - 2017-06-21 12:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 12:45:00 --> Input Class Initialized
INFO - 2017-06-21 12:45:00 --> Language Class Initialized
INFO - 2017-06-21 12:45:00 --> Loader Class Initialized
INFO - 2017-06-21 12:45:00 --> Controller Class Initialized
INFO - 2017-06-21 12:45:00 --> Database Driver Class Initialized
INFO - 2017-06-21 12:45:00 --> Model Class Initialized
INFO - 2017-06-21 12:45:00 --> Helper loaded: form_helper
INFO - 2017-06-21 12:45:00 --> Helper loaded: url_helper
INFO - 2017-06-21 12:45:00 --> Model Class Initialized
INFO - 2017-06-21 12:45:00 --> Final output sent to browser
DEBUG - 2017-06-21 12:45:00 --> Total execution time: 0.0460
ERROR - 2017-06-21 13:01:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:01:55 --> Config Class Initialized
INFO - 2017-06-21 13:01:55 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:01:55 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:01:55 --> Utf8 Class Initialized
INFO - 2017-06-21 13:01:55 --> URI Class Initialized
INFO - 2017-06-21 13:01:55 --> Router Class Initialized
INFO - 2017-06-21 13:01:55 --> Output Class Initialized
INFO - 2017-06-21 13:01:55 --> Security Class Initialized
DEBUG - 2017-06-21 13:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:01:55 --> Input Class Initialized
INFO - 2017-06-21 13:01:55 --> Language Class Initialized
INFO - 2017-06-21 13:01:55 --> Loader Class Initialized
INFO - 2017-06-21 13:01:55 --> Controller Class Initialized
INFO - 2017-06-21 13:01:55 --> Database Driver Class Initialized
INFO - 2017-06-21 13:01:55 --> Model Class Initialized
INFO - 2017-06-21 13:01:55 --> Helper loaded: form_helper
INFO - 2017-06-21 13:01:55 --> Helper loaded: url_helper
INFO - 2017-06-21 13:01:55 --> Model Class Initialized
INFO - 2017-06-21 13:01:55 --> Final output sent to browser
DEBUG - 2017-06-21 13:01:55 --> Total execution time: 0.0485
ERROR - 2017-06-21 13:01:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:01:55 --> Config Class Initialized
INFO - 2017-06-21 13:01:55 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:01:55 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:01:55 --> Utf8 Class Initialized
INFO - 2017-06-21 13:01:55 --> URI Class Initialized
INFO - 2017-06-21 13:01:55 --> Router Class Initialized
INFO - 2017-06-21 13:01:55 --> Output Class Initialized
INFO - 2017-06-21 13:01:55 --> Security Class Initialized
DEBUG - 2017-06-21 13:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:01:55 --> Input Class Initialized
INFO - 2017-06-21 13:01:55 --> Language Class Initialized
INFO - 2017-06-21 13:01:55 --> Loader Class Initialized
INFO - 2017-06-21 13:01:55 --> Controller Class Initialized
INFO - 2017-06-21 13:01:55 --> Database Driver Class Initialized
INFO - 2017-06-21 13:01:55 --> Model Class Initialized
INFO - 2017-06-21 13:01:55 --> Helper loaded: form_helper
INFO - 2017-06-21 13:01:55 --> Helper loaded: url_helper
INFO - 2017-06-21 13:01:55 --> Model Class Initialized
INFO - 2017-06-21 13:01:55 --> Final output sent to browser
DEBUG - 2017-06-21 13:01:55 --> Total execution time: 0.0555
ERROR - 2017-06-21 13:02:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:02:36 --> Config Class Initialized
INFO - 2017-06-21 13:02:36 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:02:36 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:02:36 --> Utf8 Class Initialized
INFO - 2017-06-21 13:02:36 --> URI Class Initialized
INFO - 2017-06-21 13:02:36 --> Router Class Initialized
INFO - 2017-06-21 13:02:36 --> Output Class Initialized
INFO - 2017-06-21 13:02:36 --> Security Class Initialized
DEBUG - 2017-06-21 13:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:02:36 --> Input Class Initialized
INFO - 2017-06-21 13:02:36 --> Language Class Initialized
INFO - 2017-06-21 13:02:36 --> Loader Class Initialized
INFO - 2017-06-21 13:02:36 --> Controller Class Initialized
INFO - 2017-06-21 13:02:36 --> Database Driver Class Initialized
INFO - 2017-06-21 13:02:36 --> Model Class Initialized
INFO - 2017-06-21 13:02:36 --> Helper loaded: form_helper
INFO - 2017-06-21 13:02:36 --> Helper loaded: url_helper
INFO - 2017-06-21 13:02:36 --> Model Class Initialized
INFO - 2017-06-21 13:02:36 --> Final output sent to browser
DEBUG - 2017-06-21 13:02:36 --> Total execution time: 0.0530
ERROR - 2017-06-21 13:02:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:02:37 --> Config Class Initialized
INFO - 2017-06-21 13:02:37 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:02:37 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:02:37 --> Utf8 Class Initialized
INFO - 2017-06-21 13:02:37 --> URI Class Initialized
INFO - 2017-06-21 13:02:37 --> Router Class Initialized
INFO - 2017-06-21 13:02:37 --> Output Class Initialized
INFO - 2017-06-21 13:02:37 --> Security Class Initialized
DEBUG - 2017-06-21 13:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:02:37 --> Input Class Initialized
INFO - 2017-06-21 13:02:37 --> Language Class Initialized
INFO - 2017-06-21 13:02:37 --> Loader Class Initialized
INFO - 2017-06-21 13:02:37 --> Controller Class Initialized
INFO - 2017-06-21 13:02:37 --> Database Driver Class Initialized
INFO - 2017-06-21 13:02:37 --> Model Class Initialized
INFO - 2017-06-21 13:02:37 --> Helper loaded: form_helper
INFO - 2017-06-21 13:02:37 --> Helper loaded: url_helper
INFO - 2017-06-21 13:02:37 --> Model Class Initialized
INFO - 2017-06-21 13:02:37 --> Final output sent to browser
DEBUG - 2017-06-21 13:02:37 --> Total execution time: 0.0455
ERROR - 2017-06-21 13:05:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:05:06 --> Config Class Initialized
INFO - 2017-06-21 13:05:06 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:05:06 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:05:06 --> Utf8 Class Initialized
INFO - 2017-06-21 13:05:06 --> URI Class Initialized
INFO - 2017-06-21 13:05:06 --> Router Class Initialized
INFO - 2017-06-21 13:05:06 --> Output Class Initialized
INFO - 2017-06-21 13:05:06 --> Security Class Initialized
DEBUG - 2017-06-21 13:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:05:06 --> Input Class Initialized
INFO - 2017-06-21 13:05:06 --> Language Class Initialized
INFO - 2017-06-21 13:05:06 --> Loader Class Initialized
INFO - 2017-06-21 13:05:06 --> Controller Class Initialized
INFO - 2017-06-21 13:05:06 --> Database Driver Class Initialized
INFO - 2017-06-21 13:05:06 --> Model Class Initialized
INFO - 2017-06-21 13:05:06 --> Helper loaded: form_helper
INFO - 2017-06-21 13:05:06 --> Helper loaded: url_helper
INFO - 2017-06-21 13:05:06 --> Model Class Initialized
INFO - 2017-06-21 13:05:06 --> Final output sent to browser
DEBUG - 2017-06-21 13:05:06 --> Total execution time: 0.0645
ERROR - 2017-06-21 13:05:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:05:07 --> Config Class Initialized
INFO - 2017-06-21 13:05:07 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:05:07 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:05:07 --> Utf8 Class Initialized
INFO - 2017-06-21 13:05:07 --> URI Class Initialized
INFO - 2017-06-21 13:05:07 --> Router Class Initialized
INFO - 2017-06-21 13:05:07 --> Output Class Initialized
INFO - 2017-06-21 13:05:07 --> Security Class Initialized
DEBUG - 2017-06-21 13:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:05:07 --> Input Class Initialized
INFO - 2017-06-21 13:05:07 --> Language Class Initialized
INFO - 2017-06-21 13:05:07 --> Loader Class Initialized
INFO - 2017-06-21 13:05:07 --> Controller Class Initialized
INFO - 2017-06-21 13:05:07 --> Database Driver Class Initialized
INFO - 2017-06-21 13:05:07 --> Model Class Initialized
INFO - 2017-06-21 13:05:07 --> Helper loaded: form_helper
INFO - 2017-06-21 13:05:07 --> Helper loaded: url_helper
INFO - 2017-06-21 13:05:07 --> Model Class Initialized
INFO - 2017-06-21 13:05:07 --> Final output sent to browser
DEBUG - 2017-06-21 13:05:07 --> Total execution time: 0.0465
ERROR - 2017-06-21 13:05:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:05:33 --> Config Class Initialized
INFO - 2017-06-21 13:05:33 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:05:33 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:05:33 --> Utf8 Class Initialized
INFO - 2017-06-21 13:05:33 --> URI Class Initialized
INFO - 2017-06-21 13:05:33 --> Router Class Initialized
INFO - 2017-06-21 13:05:33 --> Output Class Initialized
INFO - 2017-06-21 13:05:33 --> Security Class Initialized
DEBUG - 2017-06-21 13:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:05:33 --> Input Class Initialized
INFO - 2017-06-21 13:05:33 --> Language Class Initialized
INFO - 2017-06-21 13:05:33 --> Loader Class Initialized
INFO - 2017-06-21 13:05:33 --> Controller Class Initialized
INFO - 2017-06-21 13:05:33 --> Database Driver Class Initialized
INFO - 2017-06-21 13:05:33 --> Model Class Initialized
INFO - 2017-06-21 13:05:33 --> Helper loaded: form_helper
INFO - 2017-06-21 13:05:33 --> Helper loaded: url_helper
INFO - 2017-06-21 13:05:33 --> Model Class Initialized
INFO - 2017-06-21 13:05:33 --> Final output sent to browser
DEBUG - 2017-06-21 13:05:33 --> Total execution time: 0.0610
ERROR - 2017-06-21 13:05:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:05:35 --> Config Class Initialized
INFO - 2017-06-21 13:05:35 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:05:35 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:05:35 --> Utf8 Class Initialized
INFO - 2017-06-21 13:05:35 --> URI Class Initialized
INFO - 2017-06-21 13:05:35 --> Router Class Initialized
INFO - 2017-06-21 13:05:35 --> Output Class Initialized
INFO - 2017-06-21 13:05:35 --> Security Class Initialized
DEBUG - 2017-06-21 13:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:05:35 --> Input Class Initialized
INFO - 2017-06-21 13:05:35 --> Language Class Initialized
INFO - 2017-06-21 13:05:35 --> Loader Class Initialized
INFO - 2017-06-21 13:05:35 --> Controller Class Initialized
INFO - 2017-06-21 13:05:35 --> Database Driver Class Initialized
INFO - 2017-06-21 13:05:35 --> Model Class Initialized
INFO - 2017-06-21 13:05:35 --> Helper loaded: form_helper
INFO - 2017-06-21 13:05:35 --> Helper loaded: url_helper
INFO - 2017-06-21 13:05:35 --> Model Class Initialized
INFO - 2017-06-21 13:05:35 --> Final output sent to browser
DEBUG - 2017-06-21 13:05:35 --> Total execution time: 0.0543
ERROR - 2017-06-21 13:05:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:05:40 --> Config Class Initialized
INFO - 2017-06-21 13:05:40 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:05:40 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:05:40 --> Utf8 Class Initialized
INFO - 2017-06-21 13:05:40 --> URI Class Initialized
INFO - 2017-06-21 13:05:40 --> Router Class Initialized
INFO - 2017-06-21 13:05:40 --> Output Class Initialized
INFO - 2017-06-21 13:05:40 --> Security Class Initialized
DEBUG - 2017-06-21 13:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:05:40 --> Input Class Initialized
INFO - 2017-06-21 13:05:40 --> Language Class Initialized
INFO - 2017-06-21 13:05:40 --> Loader Class Initialized
INFO - 2017-06-21 13:05:40 --> Controller Class Initialized
INFO - 2017-06-21 13:05:40 --> Database Driver Class Initialized
INFO - 2017-06-21 13:05:40 --> Model Class Initialized
INFO - 2017-06-21 13:05:40 --> Helper loaded: form_helper
INFO - 2017-06-21 13:05:40 --> Helper loaded: url_helper
INFO - 2017-06-21 13:05:40 --> Model Class Initialized
INFO - 2017-06-21 13:05:40 --> Final output sent to browser
DEBUG - 2017-06-21 13:05:40 --> Total execution time: 0.0460
ERROR - 2017-06-21 13:05:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:05:40 --> Config Class Initialized
INFO - 2017-06-21 13:05:40 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:05:40 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:05:40 --> Utf8 Class Initialized
INFO - 2017-06-21 13:05:40 --> URI Class Initialized
INFO - 2017-06-21 13:05:40 --> Router Class Initialized
INFO - 2017-06-21 13:05:40 --> Output Class Initialized
INFO - 2017-06-21 13:05:40 --> Security Class Initialized
DEBUG - 2017-06-21 13:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:05:40 --> Input Class Initialized
INFO - 2017-06-21 13:05:40 --> Language Class Initialized
INFO - 2017-06-21 13:05:40 --> Loader Class Initialized
INFO - 2017-06-21 13:05:40 --> Controller Class Initialized
INFO - 2017-06-21 13:05:40 --> Database Driver Class Initialized
INFO - 2017-06-21 13:05:40 --> Model Class Initialized
INFO - 2017-06-21 13:05:40 --> Helper loaded: form_helper
INFO - 2017-06-21 13:05:40 --> Helper loaded: url_helper
INFO - 2017-06-21 13:05:40 --> Model Class Initialized
INFO - 2017-06-21 13:05:40 --> Final output sent to browser
DEBUG - 2017-06-21 13:05:40 --> Total execution time: 0.0578
ERROR - 2017-06-21 13:06:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:06:09 --> Config Class Initialized
INFO - 2017-06-21 13:06:09 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:06:09 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:06:09 --> Utf8 Class Initialized
INFO - 2017-06-21 13:06:09 --> URI Class Initialized
INFO - 2017-06-21 13:06:09 --> Router Class Initialized
INFO - 2017-06-21 13:06:09 --> Output Class Initialized
INFO - 2017-06-21 13:06:09 --> Security Class Initialized
DEBUG - 2017-06-21 13:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:06:09 --> Input Class Initialized
INFO - 2017-06-21 13:06:09 --> Language Class Initialized
INFO - 2017-06-21 13:06:09 --> Loader Class Initialized
INFO - 2017-06-21 13:06:09 --> Controller Class Initialized
INFO - 2017-06-21 13:06:09 --> Database Driver Class Initialized
INFO - 2017-06-21 13:06:09 --> Model Class Initialized
INFO - 2017-06-21 13:06:09 --> Helper loaded: form_helper
INFO - 2017-06-21 13:06:09 --> Helper loaded: url_helper
INFO - 2017-06-21 13:06:09 --> Model Class Initialized
INFO - 2017-06-21 13:06:09 --> Final output sent to browser
DEBUG - 2017-06-21 13:06:09 --> Total execution time: 0.0570
ERROR - 2017-06-21 13:06:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:06:32 --> Config Class Initialized
INFO - 2017-06-21 13:06:32 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:06:32 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:06:32 --> Utf8 Class Initialized
INFO - 2017-06-21 13:06:32 --> URI Class Initialized
INFO - 2017-06-21 13:06:32 --> Router Class Initialized
INFO - 2017-06-21 13:06:32 --> Output Class Initialized
INFO - 2017-06-21 13:06:32 --> Security Class Initialized
DEBUG - 2017-06-21 13:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:06:32 --> Input Class Initialized
INFO - 2017-06-21 13:06:32 --> Language Class Initialized
INFO - 2017-06-21 13:06:32 --> Loader Class Initialized
INFO - 2017-06-21 13:06:32 --> Controller Class Initialized
INFO - 2017-06-21 13:06:32 --> Database Driver Class Initialized
INFO - 2017-06-21 13:06:32 --> Model Class Initialized
INFO - 2017-06-21 13:06:32 --> Helper loaded: form_helper
INFO - 2017-06-21 13:06:32 --> Helper loaded: url_helper
INFO - 2017-06-21 13:06:32 --> Model Class Initialized
INFO - 2017-06-21 13:06:32 --> Final output sent to browser
DEBUG - 2017-06-21 13:06:32 --> Total execution time: 0.0560
ERROR - 2017-06-21 13:06:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:06:54 --> Config Class Initialized
INFO - 2017-06-21 13:06:54 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:06:54 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:06:54 --> Utf8 Class Initialized
INFO - 2017-06-21 13:06:54 --> URI Class Initialized
INFO - 2017-06-21 13:06:54 --> Router Class Initialized
INFO - 2017-06-21 13:06:54 --> Output Class Initialized
INFO - 2017-06-21 13:06:54 --> Security Class Initialized
DEBUG - 2017-06-21 13:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:06:54 --> Input Class Initialized
INFO - 2017-06-21 13:06:54 --> Language Class Initialized
INFO - 2017-06-21 13:06:54 --> Loader Class Initialized
INFO - 2017-06-21 13:06:54 --> Controller Class Initialized
INFO - 2017-06-21 13:06:54 --> Database Driver Class Initialized
INFO - 2017-06-21 13:06:54 --> Model Class Initialized
INFO - 2017-06-21 13:06:54 --> Helper loaded: form_helper
INFO - 2017-06-21 13:06:54 --> Helper loaded: url_helper
INFO - 2017-06-21 13:06:54 --> Model Class Initialized
INFO - 2017-06-21 13:06:54 --> Final output sent to browser
DEBUG - 2017-06-21 13:06:54 --> Total execution time: 0.0450
ERROR - 2017-06-21 13:07:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:07:45 --> Config Class Initialized
INFO - 2017-06-21 13:07:45 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:07:45 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:07:45 --> Utf8 Class Initialized
INFO - 2017-06-21 13:07:45 --> URI Class Initialized
INFO - 2017-06-21 13:07:45 --> Router Class Initialized
INFO - 2017-06-21 13:07:45 --> Output Class Initialized
INFO - 2017-06-21 13:07:45 --> Security Class Initialized
DEBUG - 2017-06-21 13:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:07:45 --> Input Class Initialized
INFO - 2017-06-21 13:07:45 --> Language Class Initialized
INFO - 2017-06-21 13:07:45 --> Loader Class Initialized
INFO - 2017-06-21 13:07:45 --> Controller Class Initialized
INFO - 2017-06-21 13:07:45 --> Database Driver Class Initialized
INFO - 2017-06-21 13:07:45 --> Model Class Initialized
INFO - 2017-06-21 13:07:45 --> Helper loaded: form_helper
INFO - 2017-06-21 13:07:45 --> Helper loaded: url_helper
INFO - 2017-06-21 13:07:45 --> Model Class Initialized
INFO - 2017-06-21 13:07:45 --> Final output sent to browser
DEBUG - 2017-06-21 13:07:45 --> Total execution time: 0.0445
ERROR - 2017-06-21 13:07:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:07:46 --> Config Class Initialized
INFO - 2017-06-21 13:07:46 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:07:46 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:07:46 --> Utf8 Class Initialized
INFO - 2017-06-21 13:07:46 --> URI Class Initialized
INFO - 2017-06-21 13:07:46 --> Router Class Initialized
INFO - 2017-06-21 13:07:46 --> Output Class Initialized
INFO - 2017-06-21 13:07:46 --> Security Class Initialized
DEBUG - 2017-06-21 13:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:07:46 --> Input Class Initialized
INFO - 2017-06-21 13:07:46 --> Language Class Initialized
INFO - 2017-06-21 13:07:46 --> Loader Class Initialized
INFO - 2017-06-21 13:07:46 --> Controller Class Initialized
INFO - 2017-06-21 13:07:46 --> Database Driver Class Initialized
INFO - 2017-06-21 13:07:46 --> Model Class Initialized
INFO - 2017-06-21 13:07:46 --> Helper loaded: form_helper
INFO - 2017-06-21 13:07:46 --> Helper loaded: url_helper
INFO - 2017-06-21 13:07:46 --> Model Class Initialized
INFO - 2017-06-21 13:07:46 --> Final output sent to browser
DEBUG - 2017-06-21 13:07:46 --> Total execution time: 0.0460
ERROR - 2017-06-21 13:08:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:08:04 --> Config Class Initialized
INFO - 2017-06-21 13:08:04 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:08:04 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:08:04 --> Utf8 Class Initialized
INFO - 2017-06-21 13:08:04 --> URI Class Initialized
INFO - 2017-06-21 13:08:04 --> Router Class Initialized
INFO - 2017-06-21 13:08:04 --> Output Class Initialized
INFO - 2017-06-21 13:08:04 --> Security Class Initialized
DEBUG - 2017-06-21 13:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:08:04 --> Input Class Initialized
INFO - 2017-06-21 13:08:04 --> Language Class Initialized
INFO - 2017-06-21 13:08:04 --> Loader Class Initialized
INFO - 2017-06-21 13:08:04 --> Controller Class Initialized
INFO - 2017-06-21 13:08:04 --> Database Driver Class Initialized
INFO - 2017-06-21 13:08:04 --> Model Class Initialized
INFO - 2017-06-21 13:08:04 --> Helper loaded: form_helper
INFO - 2017-06-21 13:08:04 --> Helper loaded: url_helper
INFO - 2017-06-21 13:08:04 --> Model Class Initialized
INFO - 2017-06-21 13:08:04 --> Final output sent to browser
DEBUG - 2017-06-21 13:08:04 --> Total execution time: 0.0530
ERROR - 2017-06-21 13:08:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:08:48 --> Config Class Initialized
INFO - 2017-06-21 13:08:48 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:08:48 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:08:48 --> Utf8 Class Initialized
INFO - 2017-06-21 13:08:48 --> URI Class Initialized
INFO - 2017-06-21 13:08:48 --> Router Class Initialized
INFO - 2017-06-21 13:08:48 --> Output Class Initialized
INFO - 2017-06-21 13:08:48 --> Security Class Initialized
DEBUG - 2017-06-21 13:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:08:48 --> Input Class Initialized
INFO - 2017-06-21 13:08:48 --> Language Class Initialized
INFO - 2017-06-21 13:08:48 --> Loader Class Initialized
INFO - 2017-06-21 13:08:48 --> Controller Class Initialized
INFO - 2017-06-21 13:08:48 --> Database Driver Class Initialized
INFO - 2017-06-21 13:08:48 --> Model Class Initialized
INFO - 2017-06-21 13:08:48 --> Helper loaded: form_helper
INFO - 2017-06-21 13:08:48 --> Helper loaded: url_helper
INFO - 2017-06-21 13:08:48 --> Model Class Initialized
INFO - 2017-06-21 13:08:48 --> Final output sent to browser
DEBUG - 2017-06-21 13:08:48 --> Total execution time: 0.3645
ERROR - 2017-06-21 13:08:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:08:54 --> Config Class Initialized
INFO - 2017-06-21 13:08:54 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:08:54 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:08:54 --> Utf8 Class Initialized
INFO - 2017-06-21 13:08:54 --> URI Class Initialized
INFO - 2017-06-21 13:08:54 --> Router Class Initialized
INFO - 2017-06-21 13:08:54 --> Output Class Initialized
INFO - 2017-06-21 13:08:54 --> Security Class Initialized
DEBUG - 2017-06-21 13:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:08:54 --> Input Class Initialized
INFO - 2017-06-21 13:08:54 --> Language Class Initialized
INFO - 2017-06-21 13:08:54 --> Loader Class Initialized
INFO - 2017-06-21 13:08:54 --> Controller Class Initialized
INFO - 2017-06-21 13:08:54 --> Database Driver Class Initialized
INFO - 2017-06-21 13:08:54 --> Model Class Initialized
INFO - 2017-06-21 13:08:54 --> Helper loaded: form_helper
INFO - 2017-06-21 13:08:54 --> Helper loaded: url_helper
INFO - 2017-06-21 13:08:54 --> Model Class Initialized
INFO - 2017-06-21 13:08:54 --> Final output sent to browser
DEBUG - 2017-06-21 13:08:54 --> Total execution time: 0.0470
ERROR - 2017-06-21 13:08:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:08:55 --> Config Class Initialized
INFO - 2017-06-21 13:08:55 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:08:55 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:08:55 --> Utf8 Class Initialized
INFO - 2017-06-21 13:08:55 --> URI Class Initialized
INFO - 2017-06-21 13:08:55 --> Router Class Initialized
INFO - 2017-06-21 13:08:55 --> Output Class Initialized
INFO - 2017-06-21 13:08:55 --> Security Class Initialized
DEBUG - 2017-06-21 13:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:08:55 --> Input Class Initialized
INFO - 2017-06-21 13:08:55 --> Language Class Initialized
INFO - 2017-06-21 13:08:55 --> Loader Class Initialized
INFO - 2017-06-21 13:08:55 --> Controller Class Initialized
INFO - 2017-06-21 13:08:55 --> Database Driver Class Initialized
INFO - 2017-06-21 13:08:55 --> Model Class Initialized
INFO - 2017-06-21 13:08:55 --> Helper loaded: form_helper
INFO - 2017-06-21 13:08:55 --> Helper loaded: url_helper
INFO - 2017-06-21 13:08:55 --> Model Class Initialized
INFO - 2017-06-21 13:08:55 --> Final output sent to browser
DEBUG - 2017-06-21 13:08:55 --> Total execution time: 0.0450
ERROR - 2017-06-21 13:09:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:09:07 --> Config Class Initialized
INFO - 2017-06-21 13:09:07 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:09:07 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:09:07 --> Utf8 Class Initialized
INFO - 2017-06-21 13:09:07 --> URI Class Initialized
INFO - 2017-06-21 13:09:07 --> Router Class Initialized
INFO - 2017-06-21 13:09:07 --> Output Class Initialized
INFO - 2017-06-21 13:09:07 --> Security Class Initialized
DEBUG - 2017-06-21 13:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:09:07 --> Input Class Initialized
INFO - 2017-06-21 13:09:07 --> Language Class Initialized
INFO - 2017-06-21 13:09:07 --> Loader Class Initialized
INFO - 2017-06-21 13:09:07 --> Controller Class Initialized
INFO - 2017-06-21 13:09:07 --> Database Driver Class Initialized
INFO - 2017-06-21 13:09:07 --> Model Class Initialized
INFO - 2017-06-21 13:09:07 --> Helper loaded: form_helper
INFO - 2017-06-21 13:09:07 --> Helper loaded: url_helper
INFO - 2017-06-21 13:09:07 --> Model Class Initialized
INFO - 2017-06-21 13:09:07 --> Final output sent to browser
DEBUG - 2017-06-21 13:09:07 --> Total execution time: 0.0460
ERROR - 2017-06-21 13:09:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:09:07 --> Config Class Initialized
INFO - 2017-06-21 13:09:07 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:09:07 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:09:07 --> Utf8 Class Initialized
INFO - 2017-06-21 13:09:07 --> URI Class Initialized
INFO - 2017-06-21 13:09:07 --> Router Class Initialized
INFO - 2017-06-21 13:09:07 --> Output Class Initialized
INFO - 2017-06-21 13:09:07 --> Security Class Initialized
DEBUG - 2017-06-21 13:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:09:07 --> Input Class Initialized
INFO - 2017-06-21 13:09:07 --> Language Class Initialized
INFO - 2017-06-21 13:09:07 --> Loader Class Initialized
INFO - 2017-06-21 13:09:07 --> Controller Class Initialized
INFO - 2017-06-21 13:09:07 --> Database Driver Class Initialized
INFO - 2017-06-21 13:09:07 --> Model Class Initialized
INFO - 2017-06-21 13:09:07 --> Helper loaded: form_helper
INFO - 2017-06-21 13:09:07 --> Helper loaded: url_helper
INFO - 2017-06-21 13:09:07 --> Model Class Initialized
INFO - 2017-06-21 13:09:07 --> Final output sent to browser
DEBUG - 2017-06-21 13:09:07 --> Total execution time: 0.0530
ERROR - 2017-06-21 13:15:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:15:12 --> Config Class Initialized
INFO - 2017-06-21 13:15:12 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:15:12 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:15:12 --> Utf8 Class Initialized
INFO - 2017-06-21 13:15:12 --> URI Class Initialized
INFO - 2017-06-21 13:15:12 --> Router Class Initialized
INFO - 2017-06-21 13:15:12 --> Output Class Initialized
INFO - 2017-06-21 13:15:12 --> Security Class Initialized
DEBUG - 2017-06-21 13:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:15:12 --> Input Class Initialized
INFO - 2017-06-21 13:15:12 --> Language Class Initialized
INFO - 2017-06-21 13:15:12 --> Loader Class Initialized
INFO - 2017-06-21 13:15:12 --> Controller Class Initialized
INFO - 2017-06-21 13:15:12 --> Database Driver Class Initialized
INFO - 2017-06-21 13:15:12 --> Model Class Initialized
INFO - 2017-06-21 13:15:12 --> Helper loaded: form_helper
INFO - 2017-06-21 13:15:12 --> Helper loaded: url_helper
INFO - 2017-06-21 13:15:12 --> Model Class Initialized
INFO - 2017-06-21 13:15:12 --> Final output sent to browser
DEBUG - 2017-06-21 13:15:12 --> Total execution time: 0.0480
ERROR - 2017-06-21 13:15:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:15:12 --> Config Class Initialized
INFO - 2017-06-21 13:15:12 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:15:12 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:15:12 --> Utf8 Class Initialized
INFO - 2017-06-21 13:15:12 --> URI Class Initialized
INFO - 2017-06-21 13:15:12 --> Router Class Initialized
INFO - 2017-06-21 13:15:12 --> Output Class Initialized
INFO - 2017-06-21 13:15:12 --> Security Class Initialized
DEBUG - 2017-06-21 13:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:15:12 --> Input Class Initialized
INFO - 2017-06-21 13:15:12 --> Language Class Initialized
INFO - 2017-06-21 13:15:12 --> Loader Class Initialized
INFO - 2017-06-21 13:15:12 --> Controller Class Initialized
INFO - 2017-06-21 13:15:12 --> Database Driver Class Initialized
INFO - 2017-06-21 13:15:12 --> Model Class Initialized
INFO - 2017-06-21 13:15:12 --> Helper loaded: form_helper
INFO - 2017-06-21 13:15:12 --> Helper loaded: url_helper
INFO - 2017-06-21 13:15:12 --> Model Class Initialized
INFO - 2017-06-21 13:15:12 --> Final output sent to browser
DEBUG - 2017-06-21 13:15:12 --> Total execution time: 0.0440
ERROR - 2017-06-21 13:15:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:15:23 --> Config Class Initialized
INFO - 2017-06-21 13:15:23 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:15:23 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:15:23 --> Utf8 Class Initialized
INFO - 2017-06-21 13:15:23 --> URI Class Initialized
INFO - 2017-06-21 13:15:23 --> Router Class Initialized
INFO - 2017-06-21 13:15:23 --> Output Class Initialized
INFO - 2017-06-21 13:15:23 --> Security Class Initialized
DEBUG - 2017-06-21 13:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:15:23 --> Input Class Initialized
INFO - 2017-06-21 13:15:23 --> Language Class Initialized
INFO - 2017-06-21 13:15:23 --> Loader Class Initialized
INFO - 2017-06-21 13:15:23 --> Controller Class Initialized
INFO - 2017-06-21 13:15:23 --> Database Driver Class Initialized
INFO - 2017-06-21 13:15:23 --> Model Class Initialized
INFO - 2017-06-21 13:15:23 --> Helper loaded: form_helper
INFO - 2017-06-21 13:15:23 --> Helper loaded: url_helper
INFO - 2017-06-21 13:15:23 --> Model Class Initialized
INFO - 2017-06-21 13:15:23 --> Final output sent to browser
DEBUG - 2017-06-21 13:15:23 --> Total execution time: 0.0575
ERROR - 2017-06-21 13:16:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:16:05 --> Config Class Initialized
INFO - 2017-06-21 13:16:05 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:16:05 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:16:05 --> Utf8 Class Initialized
INFO - 2017-06-21 13:16:05 --> URI Class Initialized
INFO - 2017-06-21 13:16:05 --> Router Class Initialized
INFO - 2017-06-21 13:16:05 --> Output Class Initialized
INFO - 2017-06-21 13:16:05 --> Security Class Initialized
DEBUG - 2017-06-21 13:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:16:05 --> Input Class Initialized
INFO - 2017-06-21 13:16:05 --> Language Class Initialized
INFO - 2017-06-21 13:16:05 --> Loader Class Initialized
INFO - 2017-06-21 13:16:05 --> Controller Class Initialized
INFO - 2017-06-21 13:16:05 --> Database Driver Class Initialized
INFO - 2017-06-21 13:16:05 --> Model Class Initialized
INFO - 2017-06-21 13:16:05 --> Helper loaded: form_helper
INFO - 2017-06-21 13:16:05 --> Helper loaded: url_helper
INFO - 2017-06-21 13:16:05 --> Model Class Initialized
INFO - 2017-06-21 13:16:05 --> Final output sent to browser
DEBUG - 2017-06-21 13:16:05 --> Total execution time: 0.0440
ERROR - 2017-06-21 13:16:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:16:10 --> Config Class Initialized
INFO - 2017-06-21 13:16:10 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:16:10 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:16:10 --> Utf8 Class Initialized
INFO - 2017-06-21 13:16:10 --> URI Class Initialized
INFO - 2017-06-21 13:16:10 --> Router Class Initialized
INFO - 2017-06-21 13:16:10 --> Output Class Initialized
INFO - 2017-06-21 13:16:10 --> Security Class Initialized
DEBUG - 2017-06-21 13:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:16:10 --> Input Class Initialized
INFO - 2017-06-21 13:16:10 --> Language Class Initialized
INFO - 2017-06-21 13:16:10 --> Loader Class Initialized
INFO - 2017-06-21 13:16:10 --> Controller Class Initialized
INFO - 2017-06-21 13:16:10 --> Database Driver Class Initialized
INFO - 2017-06-21 13:16:10 --> Model Class Initialized
INFO - 2017-06-21 13:16:10 --> Helper loaded: form_helper
INFO - 2017-06-21 13:16:10 --> Helper loaded: url_helper
INFO - 2017-06-21 13:16:10 --> Model Class Initialized
INFO - 2017-06-21 13:16:10 --> Final output sent to browser
DEBUG - 2017-06-21 13:16:10 --> Total execution time: 0.0630
ERROR - 2017-06-21 13:16:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:16:13 --> Config Class Initialized
INFO - 2017-06-21 13:16:13 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:16:13 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:16:13 --> Utf8 Class Initialized
INFO - 2017-06-21 13:16:13 --> URI Class Initialized
INFO - 2017-06-21 13:16:13 --> Router Class Initialized
INFO - 2017-06-21 13:16:13 --> Output Class Initialized
INFO - 2017-06-21 13:16:13 --> Security Class Initialized
DEBUG - 2017-06-21 13:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:16:13 --> Input Class Initialized
INFO - 2017-06-21 13:16:13 --> Language Class Initialized
INFO - 2017-06-21 13:16:13 --> Loader Class Initialized
INFO - 2017-06-21 13:16:13 --> Controller Class Initialized
INFO - 2017-06-21 13:16:13 --> Database Driver Class Initialized
INFO - 2017-06-21 13:16:13 --> Model Class Initialized
INFO - 2017-06-21 13:16:13 --> Helper loaded: form_helper
INFO - 2017-06-21 13:16:13 --> Helper loaded: url_helper
INFO - 2017-06-21 13:16:13 --> Model Class Initialized
INFO - 2017-06-21 13:16:13 --> Final output sent to browser
DEBUG - 2017-06-21 13:16:13 --> Total execution time: 0.0435
ERROR - 2017-06-21 13:16:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:16:42 --> Config Class Initialized
INFO - 2017-06-21 13:16:42 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:16:42 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:16:42 --> Utf8 Class Initialized
INFO - 2017-06-21 13:16:42 --> URI Class Initialized
INFO - 2017-06-21 13:16:42 --> Router Class Initialized
INFO - 2017-06-21 13:16:42 --> Output Class Initialized
INFO - 2017-06-21 13:16:42 --> Security Class Initialized
DEBUG - 2017-06-21 13:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:16:42 --> Input Class Initialized
INFO - 2017-06-21 13:16:42 --> Language Class Initialized
INFO - 2017-06-21 13:16:42 --> Loader Class Initialized
INFO - 2017-06-21 13:16:42 --> Controller Class Initialized
INFO - 2017-06-21 13:16:42 --> Database Driver Class Initialized
INFO - 2017-06-21 13:16:42 --> Model Class Initialized
INFO - 2017-06-21 13:16:42 --> Helper loaded: form_helper
INFO - 2017-06-21 13:16:42 --> Helper loaded: url_helper
INFO - 2017-06-21 13:16:42 --> Model Class Initialized
INFO - 2017-06-21 13:16:42 --> Final output sent to browser
DEBUG - 2017-06-21 13:16:42 --> Total execution time: 0.0510
ERROR - 2017-06-21 13:16:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:16:44 --> Config Class Initialized
INFO - 2017-06-21 13:16:44 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:16:44 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:16:44 --> Utf8 Class Initialized
INFO - 2017-06-21 13:16:44 --> URI Class Initialized
INFO - 2017-06-21 13:16:44 --> Router Class Initialized
INFO - 2017-06-21 13:16:44 --> Output Class Initialized
INFO - 2017-06-21 13:16:44 --> Security Class Initialized
DEBUG - 2017-06-21 13:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:16:44 --> Input Class Initialized
INFO - 2017-06-21 13:16:44 --> Language Class Initialized
INFO - 2017-06-21 13:16:44 --> Loader Class Initialized
INFO - 2017-06-21 13:16:44 --> Controller Class Initialized
INFO - 2017-06-21 13:16:44 --> Database Driver Class Initialized
INFO - 2017-06-21 13:16:44 --> Model Class Initialized
INFO - 2017-06-21 13:16:44 --> Helper loaded: form_helper
INFO - 2017-06-21 13:16:44 --> Helper loaded: url_helper
INFO - 2017-06-21 13:16:44 --> Model Class Initialized
INFO - 2017-06-21 13:16:44 --> Final output sent to browser
DEBUG - 2017-06-21 13:16:44 --> Total execution time: 0.0460
ERROR - 2017-06-21 13:17:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:17:03 --> Config Class Initialized
INFO - 2017-06-21 13:17:03 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:17:03 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:17:03 --> Utf8 Class Initialized
INFO - 2017-06-21 13:17:03 --> URI Class Initialized
INFO - 2017-06-21 13:17:03 --> Router Class Initialized
INFO - 2017-06-21 13:17:03 --> Output Class Initialized
INFO - 2017-06-21 13:17:03 --> Security Class Initialized
DEBUG - 2017-06-21 13:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:17:03 --> Input Class Initialized
INFO - 2017-06-21 13:17:03 --> Language Class Initialized
INFO - 2017-06-21 13:17:03 --> Loader Class Initialized
INFO - 2017-06-21 13:17:03 --> Controller Class Initialized
INFO - 2017-06-21 13:17:03 --> Database Driver Class Initialized
INFO - 2017-06-21 13:17:03 --> Model Class Initialized
INFO - 2017-06-21 13:17:03 --> Helper loaded: form_helper
INFO - 2017-06-21 13:17:03 --> Helper loaded: url_helper
INFO - 2017-06-21 13:17:03 --> Model Class Initialized
INFO - 2017-06-21 13:17:03 --> Final output sent to browser
DEBUG - 2017-06-21 13:17:03 --> Total execution time: 0.0570
ERROR - 2017-06-21 13:18:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:18:04 --> Config Class Initialized
INFO - 2017-06-21 13:18:04 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:18:04 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:18:04 --> Utf8 Class Initialized
INFO - 2017-06-21 13:18:04 --> URI Class Initialized
INFO - 2017-06-21 13:18:04 --> Router Class Initialized
INFO - 2017-06-21 13:18:04 --> Output Class Initialized
INFO - 2017-06-21 13:18:04 --> Security Class Initialized
DEBUG - 2017-06-21 13:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:18:04 --> Input Class Initialized
INFO - 2017-06-21 13:18:04 --> Language Class Initialized
INFO - 2017-06-21 13:18:04 --> Loader Class Initialized
INFO - 2017-06-21 13:18:04 --> Controller Class Initialized
INFO - 2017-06-21 13:18:04 --> Database Driver Class Initialized
INFO - 2017-06-21 13:18:04 --> Model Class Initialized
INFO - 2017-06-21 13:18:04 --> Helper loaded: form_helper
INFO - 2017-06-21 13:18:04 --> Helper loaded: url_helper
INFO - 2017-06-21 13:18:04 --> Model Class Initialized
INFO - 2017-06-21 13:18:04 --> Final output sent to browser
DEBUG - 2017-06-21 13:18:04 --> Total execution time: 0.0470
ERROR - 2017-06-21 13:18:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:18:05 --> Config Class Initialized
INFO - 2017-06-21 13:18:05 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:18:05 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:18:05 --> Utf8 Class Initialized
INFO - 2017-06-21 13:18:05 --> URI Class Initialized
INFO - 2017-06-21 13:18:05 --> Router Class Initialized
INFO - 2017-06-21 13:18:05 --> Output Class Initialized
INFO - 2017-06-21 13:18:05 --> Security Class Initialized
DEBUG - 2017-06-21 13:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:18:05 --> Input Class Initialized
INFO - 2017-06-21 13:18:05 --> Language Class Initialized
INFO - 2017-06-21 13:18:05 --> Loader Class Initialized
INFO - 2017-06-21 13:18:05 --> Controller Class Initialized
INFO - 2017-06-21 13:18:05 --> Database Driver Class Initialized
INFO - 2017-06-21 13:18:05 --> Model Class Initialized
INFO - 2017-06-21 13:18:05 --> Helper loaded: form_helper
INFO - 2017-06-21 13:18:05 --> Helper loaded: url_helper
INFO - 2017-06-21 13:18:05 --> Model Class Initialized
INFO - 2017-06-21 13:18:05 --> Final output sent to browser
DEBUG - 2017-06-21 13:18:05 --> Total execution time: 0.0490
ERROR - 2017-06-21 13:18:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:18:17 --> Config Class Initialized
INFO - 2017-06-21 13:18:17 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:18:17 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:18:17 --> Utf8 Class Initialized
INFO - 2017-06-21 13:18:17 --> URI Class Initialized
INFO - 2017-06-21 13:18:17 --> Router Class Initialized
INFO - 2017-06-21 13:18:17 --> Output Class Initialized
INFO - 2017-06-21 13:18:17 --> Security Class Initialized
DEBUG - 2017-06-21 13:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:18:17 --> Input Class Initialized
INFO - 2017-06-21 13:18:17 --> Language Class Initialized
INFO - 2017-06-21 13:18:17 --> Loader Class Initialized
INFO - 2017-06-21 13:18:17 --> Controller Class Initialized
INFO - 2017-06-21 13:18:17 --> Database Driver Class Initialized
INFO - 2017-06-21 13:18:17 --> Model Class Initialized
INFO - 2017-06-21 13:18:17 --> Helper loaded: form_helper
INFO - 2017-06-21 13:18:17 --> Helper loaded: url_helper
INFO - 2017-06-21 13:18:17 --> Model Class Initialized
INFO - 2017-06-21 13:18:17 --> Final output sent to browser
DEBUG - 2017-06-21 13:18:17 --> Total execution time: 0.0580
ERROR - 2017-06-21 13:18:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:18:35 --> Config Class Initialized
INFO - 2017-06-21 13:18:35 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:18:35 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:18:35 --> Utf8 Class Initialized
INFO - 2017-06-21 13:18:35 --> URI Class Initialized
INFO - 2017-06-21 13:18:35 --> Router Class Initialized
INFO - 2017-06-21 13:18:35 --> Output Class Initialized
INFO - 2017-06-21 13:18:35 --> Security Class Initialized
DEBUG - 2017-06-21 13:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:18:35 --> Input Class Initialized
INFO - 2017-06-21 13:18:35 --> Language Class Initialized
INFO - 2017-06-21 13:18:35 --> Loader Class Initialized
INFO - 2017-06-21 13:18:35 --> Controller Class Initialized
INFO - 2017-06-21 13:18:35 --> Database Driver Class Initialized
INFO - 2017-06-21 13:18:35 --> Model Class Initialized
INFO - 2017-06-21 13:18:35 --> Helper loaded: form_helper
INFO - 2017-06-21 13:18:35 --> Helper loaded: url_helper
INFO - 2017-06-21 13:18:35 --> Model Class Initialized
INFO - 2017-06-21 13:18:35 --> Final output sent to browser
DEBUG - 2017-06-21 13:18:35 --> Total execution time: 0.0480
ERROR - 2017-06-21 13:19:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:19:10 --> Config Class Initialized
INFO - 2017-06-21 13:19:10 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:19:10 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:19:10 --> Utf8 Class Initialized
INFO - 2017-06-21 13:19:10 --> URI Class Initialized
INFO - 2017-06-21 13:19:10 --> Router Class Initialized
INFO - 2017-06-21 13:19:10 --> Output Class Initialized
INFO - 2017-06-21 13:19:10 --> Security Class Initialized
DEBUG - 2017-06-21 13:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:19:10 --> Input Class Initialized
INFO - 2017-06-21 13:19:10 --> Language Class Initialized
INFO - 2017-06-21 13:19:10 --> Loader Class Initialized
INFO - 2017-06-21 13:19:10 --> Controller Class Initialized
INFO - 2017-06-21 13:19:10 --> Database Driver Class Initialized
INFO - 2017-06-21 13:19:10 --> Model Class Initialized
INFO - 2017-06-21 13:19:10 --> Helper loaded: form_helper
INFO - 2017-06-21 13:19:10 --> Helper loaded: url_helper
INFO - 2017-06-21 13:19:10 --> Model Class Initialized
INFO - 2017-06-21 13:19:10 --> Final output sent to browser
DEBUG - 2017-06-21 13:19:10 --> Total execution time: 0.0550
ERROR - 2017-06-21 13:25:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:25:37 --> Config Class Initialized
INFO - 2017-06-21 13:25:37 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:25:37 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:25:37 --> Utf8 Class Initialized
INFO - 2017-06-21 13:25:37 --> URI Class Initialized
INFO - 2017-06-21 13:25:37 --> Router Class Initialized
INFO - 2017-06-21 13:25:37 --> Output Class Initialized
INFO - 2017-06-21 13:25:37 --> Security Class Initialized
DEBUG - 2017-06-21 13:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:25:37 --> Input Class Initialized
INFO - 2017-06-21 13:25:37 --> Language Class Initialized
INFO - 2017-06-21 13:25:37 --> Loader Class Initialized
INFO - 2017-06-21 13:25:37 --> Controller Class Initialized
INFO - 2017-06-21 13:25:37 --> Database Driver Class Initialized
INFO - 2017-06-21 13:25:37 --> Model Class Initialized
INFO - 2017-06-21 13:25:37 --> Helper loaded: form_helper
INFO - 2017-06-21 13:25:37 --> Helper loaded: url_helper
INFO - 2017-06-21 13:25:37 --> Model Class Initialized
INFO - 2017-06-21 13:25:37 --> Final output sent to browser
DEBUG - 2017-06-21 13:25:37 --> Total execution time: 0.0445
ERROR - 2017-06-21 13:25:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:25:38 --> Config Class Initialized
INFO - 2017-06-21 13:25:38 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:25:38 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:25:38 --> Utf8 Class Initialized
INFO - 2017-06-21 13:25:38 --> URI Class Initialized
INFO - 2017-06-21 13:25:38 --> Router Class Initialized
INFO - 2017-06-21 13:25:38 --> Output Class Initialized
INFO - 2017-06-21 13:25:38 --> Security Class Initialized
DEBUG - 2017-06-21 13:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:25:38 --> Input Class Initialized
INFO - 2017-06-21 13:25:38 --> Language Class Initialized
INFO - 2017-06-21 13:25:38 --> Loader Class Initialized
INFO - 2017-06-21 13:25:38 --> Controller Class Initialized
INFO - 2017-06-21 13:25:38 --> Database Driver Class Initialized
INFO - 2017-06-21 13:25:38 --> Model Class Initialized
INFO - 2017-06-21 13:25:38 --> Helper loaded: form_helper
INFO - 2017-06-21 13:25:38 --> Helper loaded: url_helper
INFO - 2017-06-21 13:25:38 --> Model Class Initialized
INFO - 2017-06-21 13:25:38 --> Final output sent to browser
DEBUG - 2017-06-21 13:25:38 --> Total execution time: 0.0450
ERROR - 2017-06-21 13:25:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:25:45 --> Config Class Initialized
INFO - 2017-06-21 13:25:45 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:25:45 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:25:45 --> Utf8 Class Initialized
INFO - 2017-06-21 13:25:45 --> URI Class Initialized
INFO - 2017-06-21 13:25:45 --> Router Class Initialized
INFO - 2017-06-21 13:25:45 --> Output Class Initialized
INFO - 2017-06-21 13:25:45 --> Security Class Initialized
DEBUG - 2017-06-21 13:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:25:45 --> Input Class Initialized
INFO - 2017-06-21 13:25:45 --> Language Class Initialized
INFO - 2017-06-21 13:25:45 --> Loader Class Initialized
INFO - 2017-06-21 13:25:45 --> Controller Class Initialized
INFO - 2017-06-21 13:25:45 --> Database Driver Class Initialized
INFO - 2017-06-21 13:25:45 --> Model Class Initialized
INFO - 2017-06-21 13:25:45 --> Helper loaded: form_helper
INFO - 2017-06-21 13:25:45 --> Helper loaded: url_helper
INFO - 2017-06-21 13:25:45 --> Model Class Initialized
INFO - 2017-06-21 13:25:45 --> Final output sent to browser
DEBUG - 2017-06-21 13:25:45 --> Total execution time: 0.0500
ERROR - 2017-06-21 13:26:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:26:15 --> Config Class Initialized
INFO - 2017-06-21 13:26:15 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:26:15 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:26:15 --> Utf8 Class Initialized
INFO - 2017-06-21 13:26:15 --> URI Class Initialized
INFO - 2017-06-21 13:26:15 --> Router Class Initialized
INFO - 2017-06-21 13:26:15 --> Output Class Initialized
INFO - 2017-06-21 13:26:15 --> Security Class Initialized
DEBUG - 2017-06-21 13:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:26:15 --> Input Class Initialized
INFO - 2017-06-21 13:26:15 --> Language Class Initialized
INFO - 2017-06-21 13:26:15 --> Loader Class Initialized
INFO - 2017-06-21 13:26:15 --> Controller Class Initialized
INFO - 2017-06-21 13:26:15 --> Database Driver Class Initialized
INFO - 2017-06-21 13:26:15 --> Model Class Initialized
INFO - 2017-06-21 13:26:15 --> Helper loaded: form_helper
INFO - 2017-06-21 13:26:15 --> Helper loaded: url_helper
INFO - 2017-06-21 13:26:15 --> Model Class Initialized
INFO - 2017-06-21 13:26:15 --> Final output sent to browser
DEBUG - 2017-06-21 13:26:15 --> Total execution time: 0.0500
ERROR - 2017-06-21 13:26:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:26:17 --> Config Class Initialized
INFO - 2017-06-21 13:26:17 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:26:17 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:26:17 --> Utf8 Class Initialized
INFO - 2017-06-21 13:26:17 --> URI Class Initialized
INFO - 2017-06-21 13:26:17 --> Router Class Initialized
INFO - 2017-06-21 13:26:17 --> Output Class Initialized
INFO - 2017-06-21 13:26:17 --> Security Class Initialized
DEBUG - 2017-06-21 13:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:26:17 --> Input Class Initialized
INFO - 2017-06-21 13:26:17 --> Language Class Initialized
INFO - 2017-06-21 13:26:17 --> Loader Class Initialized
INFO - 2017-06-21 13:26:17 --> Controller Class Initialized
INFO - 2017-06-21 13:26:17 --> Database Driver Class Initialized
INFO - 2017-06-21 13:26:17 --> Model Class Initialized
INFO - 2017-06-21 13:26:17 --> Helper loaded: form_helper
INFO - 2017-06-21 13:26:17 --> Helper loaded: url_helper
INFO - 2017-06-21 13:26:17 --> Model Class Initialized
INFO - 2017-06-21 13:26:17 --> Final output sent to browser
DEBUG - 2017-06-21 13:26:17 --> Total execution time: 0.0560
ERROR - 2017-06-21 13:26:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:26:20 --> Config Class Initialized
INFO - 2017-06-21 13:26:20 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:26:20 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:26:20 --> Utf8 Class Initialized
INFO - 2017-06-21 13:26:20 --> URI Class Initialized
INFO - 2017-06-21 13:26:20 --> Router Class Initialized
INFO - 2017-06-21 13:26:20 --> Output Class Initialized
INFO - 2017-06-21 13:26:20 --> Security Class Initialized
DEBUG - 2017-06-21 13:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:26:20 --> Input Class Initialized
INFO - 2017-06-21 13:26:20 --> Language Class Initialized
INFO - 2017-06-21 13:26:20 --> Loader Class Initialized
INFO - 2017-06-21 13:26:20 --> Controller Class Initialized
INFO - 2017-06-21 13:26:20 --> Database Driver Class Initialized
INFO - 2017-06-21 13:26:20 --> Model Class Initialized
INFO - 2017-06-21 13:26:20 --> Helper loaded: form_helper
INFO - 2017-06-21 13:26:20 --> Helper loaded: url_helper
INFO - 2017-06-21 13:26:20 --> Model Class Initialized
INFO - 2017-06-21 13:26:20 --> Final output sent to browser
DEBUG - 2017-06-21 13:26:20 --> Total execution time: 0.0450
ERROR - 2017-06-21 13:26:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:26:56 --> Config Class Initialized
INFO - 2017-06-21 13:26:56 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:26:56 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:26:56 --> Utf8 Class Initialized
INFO - 2017-06-21 13:26:56 --> URI Class Initialized
INFO - 2017-06-21 13:26:56 --> Router Class Initialized
INFO - 2017-06-21 13:26:56 --> Output Class Initialized
INFO - 2017-06-21 13:26:56 --> Security Class Initialized
DEBUG - 2017-06-21 13:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:26:56 --> Input Class Initialized
INFO - 2017-06-21 13:26:56 --> Language Class Initialized
INFO - 2017-06-21 13:26:56 --> Loader Class Initialized
INFO - 2017-06-21 13:26:56 --> Controller Class Initialized
INFO - 2017-06-21 13:26:56 --> Database Driver Class Initialized
INFO - 2017-06-21 13:26:56 --> Model Class Initialized
INFO - 2017-06-21 13:26:56 --> Helper loaded: form_helper
INFO - 2017-06-21 13:26:56 --> Helper loaded: url_helper
INFO - 2017-06-21 13:26:56 --> Model Class Initialized
INFO - 2017-06-21 13:26:56 --> Final output sent to browser
DEBUG - 2017-06-21 13:26:56 --> Total execution time: 0.0540
ERROR - 2017-06-21 13:27:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:27:34 --> Config Class Initialized
INFO - 2017-06-21 13:27:34 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:27:34 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:27:34 --> Utf8 Class Initialized
INFO - 2017-06-21 13:27:34 --> URI Class Initialized
INFO - 2017-06-21 13:27:34 --> Router Class Initialized
INFO - 2017-06-21 13:27:34 --> Output Class Initialized
INFO - 2017-06-21 13:27:34 --> Security Class Initialized
DEBUG - 2017-06-21 13:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:27:34 --> Input Class Initialized
INFO - 2017-06-21 13:27:34 --> Language Class Initialized
INFO - 2017-06-21 13:27:34 --> Loader Class Initialized
INFO - 2017-06-21 13:27:34 --> Controller Class Initialized
INFO - 2017-06-21 13:27:34 --> Database Driver Class Initialized
INFO - 2017-06-21 13:27:34 --> Model Class Initialized
INFO - 2017-06-21 13:27:34 --> Helper loaded: form_helper
INFO - 2017-06-21 13:27:34 --> Helper loaded: url_helper
INFO - 2017-06-21 13:27:34 --> Model Class Initialized
INFO - 2017-06-21 13:27:34 --> Final output sent to browser
DEBUG - 2017-06-21 13:27:34 --> Total execution time: 0.0525
ERROR - 2017-06-21 13:42:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:42:38 --> Config Class Initialized
INFO - 2017-06-21 13:42:38 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:42:38 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:42:38 --> Utf8 Class Initialized
INFO - 2017-06-21 13:42:38 --> URI Class Initialized
INFO - 2017-06-21 13:42:38 --> Router Class Initialized
INFO - 2017-06-21 13:42:38 --> Output Class Initialized
INFO - 2017-06-21 13:42:38 --> Security Class Initialized
DEBUG - 2017-06-21 13:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:42:38 --> Input Class Initialized
INFO - 2017-06-21 13:42:38 --> Language Class Initialized
INFO - 2017-06-21 13:42:38 --> Loader Class Initialized
INFO - 2017-06-21 13:42:38 --> Controller Class Initialized
INFO - 2017-06-21 13:42:38 --> Database Driver Class Initialized
INFO - 2017-06-21 13:42:38 --> Model Class Initialized
INFO - 2017-06-21 13:42:38 --> Helper loaded: form_helper
INFO - 2017-06-21 13:42:38 --> Helper loaded: url_helper
INFO - 2017-06-21 13:42:38 --> Model Class Initialized
INFO - 2017-06-21 13:42:38 --> Final output sent to browser
DEBUG - 2017-06-21 13:42:38 --> Total execution time: 0.0490
ERROR - 2017-06-21 13:42:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:42:50 --> Config Class Initialized
INFO - 2017-06-21 13:42:50 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:42:50 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:42:50 --> Utf8 Class Initialized
INFO - 2017-06-21 13:42:50 --> URI Class Initialized
INFO - 2017-06-21 13:42:50 --> Router Class Initialized
INFO - 2017-06-21 13:42:50 --> Output Class Initialized
INFO - 2017-06-21 13:42:50 --> Security Class Initialized
DEBUG - 2017-06-21 13:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:42:50 --> Input Class Initialized
INFO - 2017-06-21 13:42:50 --> Language Class Initialized
INFO - 2017-06-21 13:42:50 --> Loader Class Initialized
INFO - 2017-06-21 13:42:50 --> Controller Class Initialized
INFO - 2017-06-21 13:42:50 --> Database Driver Class Initialized
INFO - 2017-06-21 13:42:50 --> Model Class Initialized
INFO - 2017-06-21 13:42:50 --> Helper loaded: form_helper
INFO - 2017-06-21 13:42:50 --> Helper loaded: url_helper
INFO - 2017-06-21 13:42:50 --> Model Class Initialized
INFO - 2017-06-21 13:42:50 --> Final output sent to browser
DEBUG - 2017-06-21 13:42:50 --> Total execution time: 0.0505
ERROR - 2017-06-21 13:43:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:43:49 --> Config Class Initialized
INFO - 2017-06-21 13:43:49 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:43:49 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:43:49 --> Utf8 Class Initialized
INFO - 2017-06-21 13:43:49 --> URI Class Initialized
INFO - 2017-06-21 13:43:49 --> Router Class Initialized
INFO - 2017-06-21 13:43:49 --> Output Class Initialized
INFO - 2017-06-21 13:43:49 --> Security Class Initialized
DEBUG - 2017-06-21 13:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:43:49 --> Input Class Initialized
INFO - 2017-06-21 13:43:49 --> Language Class Initialized
INFO - 2017-06-21 13:43:49 --> Loader Class Initialized
INFO - 2017-06-21 13:43:49 --> Controller Class Initialized
INFO - 2017-06-21 13:43:49 --> Database Driver Class Initialized
INFO - 2017-06-21 13:43:49 --> Model Class Initialized
INFO - 2017-06-21 13:43:49 --> Helper loaded: form_helper
INFO - 2017-06-21 13:43:49 --> Helper loaded: url_helper
INFO - 2017-06-21 13:43:49 --> Model Class Initialized
INFO - 2017-06-21 13:43:49 --> Final output sent to browser
DEBUG - 2017-06-21 13:43:49 --> Total execution time: 0.0450
ERROR - 2017-06-21 13:43:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:43:50 --> Config Class Initialized
INFO - 2017-06-21 13:43:50 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:43:50 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:43:50 --> Utf8 Class Initialized
INFO - 2017-06-21 13:43:50 --> URI Class Initialized
INFO - 2017-06-21 13:43:50 --> Router Class Initialized
INFO - 2017-06-21 13:43:50 --> Output Class Initialized
INFO - 2017-06-21 13:43:50 --> Security Class Initialized
DEBUG - 2017-06-21 13:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:43:50 --> Input Class Initialized
INFO - 2017-06-21 13:43:50 --> Language Class Initialized
INFO - 2017-06-21 13:43:50 --> Loader Class Initialized
INFO - 2017-06-21 13:43:50 --> Controller Class Initialized
INFO - 2017-06-21 13:43:50 --> Database Driver Class Initialized
INFO - 2017-06-21 13:43:50 --> Model Class Initialized
INFO - 2017-06-21 13:43:50 --> Helper loaded: form_helper
INFO - 2017-06-21 13:43:50 --> Helper loaded: url_helper
INFO - 2017-06-21 13:43:50 --> Model Class Initialized
INFO - 2017-06-21 13:43:50 --> Final output sent to browser
DEBUG - 2017-06-21 13:43:50 --> Total execution time: 0.0430
ERROR - 2017-06-21 13:43:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:43:53 --> Config Class Initialized
INFO - 2017-06-21 13:43:53 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:43:53 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:43:53 --> Utf8 Class Initialized
INFO - 2017-06-21 13:43:53 --> URI Class Initialized
INFO - 2017-06-21 13:43:53 --> Router Class Initialized
INFO - 2017-06-21 13:43:53 --> Output Class Initialized
INFO - 2017-06-21 13:43:53 --> Security Class Initialized
DEBUG - 2017-06-21 13:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:43:53 --> Input Class Initialized
INFO - 2017-06-21 13:43:53 --> Language Class Initialized
INFO - 2017-06-21 13:43:53 --> Loader Class Initialized
INFO - 2017-06-21 13:43:53 --> Controller Class Initialized
INFO - 2017-06-21 13:43:53 --> Database Driver Class Initialized
INFO - 2017-06-21 13:43:53 --> Model Class Initialized
INFO - 2017-06-21 13:43:53 --> Helper loaded: form_helper
INFO - 2017-06-21 13:43:53 --> Helper loaded: url_helper
INFO - 2017-06-21 13:43:53 --> Model Class Initialized
INFO - 2017-06-21 13:43:53 --> Final output sent to browser
DEBUG - 2017-06-21 13:43:53 --> Total execution time: 0.0460
ERROR - 2017-06-21 13:43:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:43:56 --> Config Class Initialized
INFO - 2017-06-21 13:43:56 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:43:56 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:43:56 --> Utf8 Class Initialized
INFO - 2017-06-21 13:43:56 --> URI Class Initialized
INFO - 2017-06-21 13:43:56 --> Router Class Initialized
INFO - 2017-06-21 13:43:56 --> Output Class Initialized
INFO - 2017-06-21 13:43:56 --> Security Class Initialized
DEBUG - 2017-06-21 13:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:43:56 --> Input Class Initialized
INFO - 2017-06-21 13:43:56 --> Language Class Initialized
INFO - 2017-06-21 13:43:56 --> Loader Class Initialized
INFO - 2017-06-21 13:43:56 --> Controller Class Initialized
INFO - 2017-06-21 13:43:56 --> Database Driver Class Initialized
INFO - 2017-06-21 13:43:56 --> Model Class Initialized
INFO - 2017-06-21 13:43:56 --> Helper loaded: form_helper
INFO - 2017-06-21 13:43:56 --> Helper loaded: url_helper
INFO - 2017-06-21 13:43:56 --> Model Class Initialized
INFO - 2017-06-21 13:43:56 --> Final output sent to browser
DEBUG - 2017-06-21 13:43:56 --> Total execution time: 0.0610
ERROR - 2017-06-21 13:43:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:43:57 --> Config Class Initialized
INFO - 2017-06-21 13:43:57 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:43:57 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:43:57 --> Utf8 Class Initialized
INFO - 2017-06-21 13:43:57 --> URI Class Initialized
INFO - 2017-06-21 13:43:57 --> Router Class Initialized
INFO - 2017-06-21 13:43:57 --> Output Class Initialized
INFO - 2017-06-21 13:43:57 --> Security Class Initialized
DEBUG - 2017-06-21 13:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:43:57 --> Input Class Initialized
INFO - 2017-06-21 13:43:57 --> Language Class Initialized
INFO - 2017-06-21 13:43:57 --> Loader Class Initialized
INFO - 2017-06-21 13:43:57 --> Controller Class Initialized
INFO - 2017-06-21 13:43:57 --> Database Driver Class Initialized
INFO - 2017-06-21 13:43:57 --> Model Class Initialized
INFO - 2017-06-21 13:43:57 --> Helper loaded: form_helper
INFO - 2017-06-21 13:43:57 --> Helper loaded: url_helper
INFO - 2017-06-21 13:43:57 --> Model Class Initialized
INFO - 2017-06-21 13:43:57 --> Final output sent to browser
DEBUG - 2017-06-21 13:43:57 --> Total execution time: 0.0483
ERROR - 2017-06-21 13:44:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:44:00 --> Config Class Initialized
INFO - 2017-06-21 13:44:00 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:44:00 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:44:00 --> Utf8 Class Initialized
INFO - 2017-06-21 13:44:00 --> URI Class Initialized
INFO - 2017-06-21 13:44:00 --> Router Class Initialized
INFO - 2017-06-21 13:44:00 --> Output Class Initialized
INFO - 2017-06-21 13:44:00 --> Security Class Initialized
DEBUG - 2017-06-21 13:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:44:00 --> Input Class Initialized
INFO - 2017-06-21 13:44:00 --> Language Class Initialized
INFO - 2017-06-21 13:44:00 --> Loader Class Initialized
INFO - 2017-06-21 13:44:00 --> Controller Class Initialized
INFO - 2017-06-21 13:44:00 --> Database Driver Class Initialized
INFO - 2017-06-21 13:44:00 --> Model Class Initialized
INFO - 2017-06-21 13:44:00 --> Helper loaded: form_helper
INFO - 2017-06-21 13:44:00 --> Helper loaded: url_helper
INFO - 2017-06-21 13:44:00 --> Model Class Initialized
INFO - 2017-06-21 13:44:00 --> Final output sent to browser
DEBUG - 2017-06-21 13:44:00 --> Total execution time: 0.0425
ERROR - 2017-06-21 13:58:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:58:00 --> Config Class Initialized
INFO - 2017-06-21 13:58:00 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:58:00 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:58:00 --> Utf8 Class Initialized
INFO - 2017-06-21 13:58:00 --> URI Class Initialized
INFO - 2017-06-21 13:58:00 --> Router Class Initialized
INFO - 2017-06-21 13:58:00 --> Output Class Initialized
INFO - 2017-06-21 13:58:00 --> Security Class Initialized
DEBUG - 2017-06-21 13:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:58:00 --> Input Class Initialized
INFO - 2017-06-21 13:58:00 --> Language Class Initialized
INFO - 2017-06-21 13:58:00 --> Loader Class Initialized
INFO - 2017-06-21 13:58:00 --> Controller Class Initialized
INFO - 2017-06-21 13:58:00 --> Database Driver Class Initialized
INFO - 2017-06-21 13:58:00 --> Model Class Initialized
INFO - 2017-06-21 13:58:00 --> Helper loaded: form_helper
INFO - 2017-06-21 13:58:00 --> Helper loaded: url_helper
INFO - 2017-06-21 13:58:00 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 13:58:00 --> Model Class Initialized
INFO - 2017-06-21 13:58:00 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-06-21 13:58:00 --> Final output sent to browser
DEBUG - 2017-06-21 13:58:00 --> Total execution time: 0.0830
ERROR - 2017-06-21 13:58:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:58:02 --> Config Class Initialized
INFO - 2017-06-21 13:58:02 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:58:02 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:58:02 --> Utf8 Class Initialized
INFO - 2017-06-21 13:58:02 --> URI Class Initialized
INFO - 2017-06-21 13:58:02 --> Router Class Initialized
INFO - 2017-06-21 13:58:02 --> Output Class Initialized
INFO - 2017-06-21 13:58:02 --> Security Class Initialized
DEBUG - 2017-06-21 13:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:58:02 --> Input Class Initialized
INFO - 2017-06-21 13:58:02 --> Language Class Initialized
INFO - 2017-06-21 13:58:02 --> Loader Class Initialized
INFO - 2017-06-21 13:58:02 --> Controller Class Initialized
INFO - 2017-06-21 13:58:02 --> Database Driver Class Initialized
INFO - 2017-06-21 13:58:02 --> Model Class Initialized
INFO - 2017-06-21 13:58:02 --> Helper loaded: form_helper
INFO - 2017-06-21 13:58:02 --> Helper loaded: url_helper
INFO - 2017-06-21 13:58:02 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 13:58:02 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 13:58:02 --> Final output sent to browser
DEBUG - 2017-06-21 13:58:02 --> Total execution time: 0.0750
ERROR - 2017-06-21 13:58:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:58:24 --> Config Class Initialized
INFO - 2017-06-21 13:58:24 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:58:24 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:58:24 --> Utf8 Class Initialized
INFO - 2017-06-21 13:58:24 --> URI Class Initialized
INFO - 2017-06-21 13:58:24 --> Router Class Initialized
INFO - 2017-06-21 13:58:24 --> Output Class Initialized
INFO - 2017-06-21 13:58:24 --> Security Class Initialized
DEBUG - 2017-06-21 13:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:58:24 --> Input Class Initialized
INFO - 2017-06-21 13:58:24 --> Language Class Initialized
INFO - 2017-06-21 13:58:24 --> Loader Class Initialized
INFO - 2017-06-21 13:58:24 --> Controller Class Initialized
INFO - 2017-06-21 13:58:24 --> Database Driver Class Initialized
INFO - 2017-06-21 13:58:24 --> Model Class Initialized
INFO - 2017-06-21 13:58:24 --> Helper loaded: form_helper
INFO - 2017-06-21 13:58:24 --> Helper loaded: url_helper
INFO - 2017-06-21 13:58:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 13:58:24 --> Model Class Initialized
INFO - 2017-06-21 13:58:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 13:58:24 --> Final output sent to browser
DEBUG - 2017-06-21 13:58:24 --> Total execution time: 0.0790
ERROR - 2017-06-21 13:58:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:58:32 --> Config Class Initialized
INFO - 2017-06-21 13:58:32 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:58:32 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:58:32 --> Utf8 Class Initialized
INFO - 2017-06-21 13:58:32 --> URI Class Initialized
INFO - 2017-06-21 13:58:32 --> Router Class Initialized
INFO - 2017-06-21 13:58:32 --> Output Class Initialized
INFO - 2017-06-21 13:58:32 --> Security Class Initialized
DEBUG - 2017-06-21 13:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:58:32 --> Input Class Initialized
INFO - 2017-06-21 13:58:32 --> Language Class Initialized
INFO - 2017-06-21 13:58:32 --> Loader Class Initialized
INFO - 2017-06-21 13:58:32 --> Controller Class Initialized
INFO - 2017-06-21 13:58:32 --> Database Driver Class Initialized
INFO - 2017-06-21 13:58:32 --> Model Class Initialized
INFO - 2017-06-21 13:58:32 --> Helper loaded: form_helper
INFO - 2017-06-21 13:58:32 --> Helper loaded: url_helper
INFO - 2017-06-21 13:58:32 --> Upload Class Initialized
INFO - 2017-06-21 13:58:32 --> Final output sent to browser
DEBUG - 2017-06-21 13:58:32 --> Total execution time: 0.0510
ERROR - 2017-06-21 13:58:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:58:40 --> Config Class Initialized
INFO - 2017-06-21 13:58:40 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:58:40 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:58:40 --> Utf8 Class Initialized
INFO - 2017-06-21 13:58:40 --> URI Class Initialized
INFO - 2017-06-21 13:58:40 --> Router Class Initialized
INFO - 2017-06-21 13:58:40 --> Output Class Initialized
INFO - 2017-06-21 13:58:40 --> Security Class Initialized
DEBUG - 2017-06-21 13:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:58:40 --> Input Class Initialized
INFO - 2017-06-21 13:58:40 --> Language Class Initialized
INFO - 2017-06-21 13:58:40 --> Loader Class Initialized
INFO - 2017-06-21 13:58:40 --> Controller Class Initialized
INFO - 2017-06-21 13:58:40 --> Database Driver Class Initialized
INFO - 2017-06-21 13:58:40 --> Model Class Initialized
INFO - 2017-06-21 13:58:40 --> Helper loaded: form_helper
INFO - 2017-06-21 13:58:40 --> Helper loaded: url_helper
INFO - 2017-06-21 13:58:40 --> Model Class Initialized
INFO - 2017-06-21 13:58:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 13:58:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 13:58:40 --> Final output sent to browser
DEBUG - 2017-06-21 13:58:40 --> Total execution time: 0.1050
ERROR - 2017-06-21 13:59:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:59:05 --> Config Class Initialized
INFO - 2017-06-21 13:59:05 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:59:05 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:59:05 --> Utf8 Class Initialized
INFO - 2017-06-21 13:59:05 --> URI Class Initialized
INFO - 2017-06-21 13:59:05 --> Router Class Initialized
INFO - 2017-06-21 13:59:05 --> Output Class Initialized
INFO - 2017-06-21 13:59:05 --> Security Class Initialized
DEBUG - 2017-06-21 13:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:59:05 --> Input Class Initialized
INFO - 2017-06-21 13:59:05 --> Language Class Initialized
INFO - 2017-06-21 13:59:05 --> Loader Class Initialized
INFO - 2017-06-21 13:59:05 --> Controller Class Initialized
INFO - 2017-06-21 13:59:05 --> Database Driver Class Initialized
INFO - 2017-06-21 13:59:05 --> Model Class Initialized
INFO - 2017-06-21 13:59:05 --> Helper loaded: form_helper
INFO - 2017-06-21 13:59:05 --> Helper loaded: url_helper
INFO - 2017-06-21 13:59:05 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 13:59:05 --> Model Class Initialized
INFO - 2017-06-21 13:59:05 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-06-21 13:59:05 --> Final output sent to browser
DEBUG - 2017-06-21 13:59:05 --> Total execution time: 0.0440
ERROR - 2017-06-21 13:59:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:59:07 --> Config Class Initialized
INFO - 2017-06-21 13:59:07 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:59:07 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:59:07 --> Utf8 Class Initialized
INFO - 2017-06-21 13:59:07 --> URI Class Initialized
INFO - 2017-06-21 13:59:07 --> Router Class Initialized
INFO - 2017-06-21 13:59:07 --> Output Class Initialized
INFO - 2017-06-21 13:59:07 --> Security Class Initialized
DEBUG - 2017-06-21 13:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:59:07 --> Input Class Initialized
INFO - 2017-06-21 13:59:07 --> Language Class Initialized
INFO - 2017-06-21 13:59:07 --> Loader Class Initialized
INFO - 2017-06-21 13:59:07 --> Controller Class Initialized
INFO - 2017-06-21 13:59:07 --> Database Driver Class Initialized
INFO - 2017-06-21 13:59:07 --> Model Class Initialized
INFO - 2017-06-21 13:59:07 --> Helper loaded: form_helper
INFO - 2017-06-21 13:59:07 --> Helper loaded: url_helper
INFO - 2017-06-21 13:59:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 13:59:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 13:59:07 --> Final output sent to browser
DEBUG - 2017-06-21 13:59:07 --> Total execution time: 0.0440
ERROR - 2017-06-21 13:59:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:59:13 --> Config Class Initialized
INFO - 2017-06-21 13:59:13 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:59:13 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:59:13 --> Utf8 Class Initialized
INFO - 2017-06-21 13:59:13 --> URI Class Initialized
INFO - 2017-06-21 13:59:13 --> Router Class Initialized
INFO - 2017-06-21 13:59:13 --> Output Class Initialized
INFO - 2017-06-21 13:59:13 --> Security Class Initialized
DEBUG - 2017-06-21 13:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:59:13 --> Input Class Initialized
INFO - 2017-06-21 13:59:13 --> Language Class Initialized
INFO - 2017-06-21 13:59:13 --> Loader Class Initialized
INFO - 2017-06-21 13:59:13 --> Controller Class Initialized
INFO - 2017-06-21 13:59:13 --> Database Driver Class Initialized
INFO - 2017-06-21 13:59:13 --> Model Class Initialized
INFO - 2017-06-21 13:59:13 --> Helper loaded: form_helper
INFO - 2017-06-21 13:59:13 --> Helper loaded: url_helper
INFO - 2017-06-21 13:59:13 --> Upload Class Initialized
INFO - 2017-06-21 13:59:13 --> Final output sent to browser
DEBUG - 2017-06-21 13:59:13 --> Total execution time: 0.0620
ERROR - 2017-06-21 13:59:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:59:15 --> Config Class Initialized
INFO - 2017-06-21 13:59:15 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:59:15 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:59:15 --> Utf8 Class Initialized
INFO - 2017-06-21 13:59:15 --> URI Class Initialized
INFO - 2017-06-21 13:59:15 --> Router Class Initialized
INFO - 2017-06-21 13:59:15 --> Output Class Initialized
INFO - 2017-06-21 13:59:15 --> Security Class Initialized
DEBUG - 2017-06-21 13:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:59:15 --> Input Class Initialized
INFO - 2017-06-21 13:59:15 --> Language Class Initialized
INFO - 2017-06-21 13:59:15 --> Loader Class Initialized
INFO - 2017-06-21 13:59:15 --> Controller Class Initialized
INFO - 2017-06-21 13:59:15 --> Database Driver Class Initialized
INFO - 2017-06-21 13:59:15 --> Model Class Initialized
INFO - 2017-06-21 13:59:15 --> Helper loaded: form_helper
INFO - 2017-06-21 13:59:15 --> Helper loaded: url_helper
INFO - 2017-06-21 13:59:15 --> Model Class Initialized
INFO - 2017-06-21 13:59:15 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 13:59:15 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 13:59:15 --> Final output sent to browser
DEBUG - 2017-06-21 13:59:15 --> Total execution time: 0.5025
ERROR - 2017-06-21 13:59:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:59:17 --> Config Class Initialized
INFO - 2017-06-21 13:59:17 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:59:17 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:59:17 --> Utf8 Class Initialized
INFO - 2017-06-21 13:59:17 --> URI Class Initialized
INFO - 2017-06-21 13:59:17 --> Router Class Initialized
INFO - 2017-06-21 13:59:17 --> Output Class Initialized
INFO - 2017-06-21 13:59:17 --> Security Class Initialized
DEBUG - 2017-06-21 13:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:59:17 --> Input Class Initialized
INFO - 2017-06-21 13:59:17 --> Language Class Initialized
INFO - 2017-06-21 13:59:17 --> Loader Class Initialized
INFO - 2017-06-21 13:59:17 --> Controller Class Initialized
INFO - 2017-06-21 13:59:17 --> Database Driver Class Initialized
INFO - 2017-06-21 13:59:17 --> Model Class Initialized
INFO - 2017-06-21 13:59:17 --> Helper loaded: form_helper
INFO - 2017-06-21 13:59:17 --> Helper loaded: url_helper
INFO - 2017-06-21 13:59:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 13:59:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 13:59:17 --> Final output sent to browser
DEBUG - 2017-06-21 13:59:17 --> Total execution time: 0.0580
ERROR - 2017-06-21 13:59:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:59:22 --> Config Class Initialized
INFO - 2017-06-21 13:59:22 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:59:22 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:59:22 --> Utf8 Class Initialized
INFO - 2017-06-21 13:59:22 --> URI Class Initialized
INFO - 2017-06-21 13:59:22 --> Router Class Initialized
INFO - 2017-06-21 13:59:22 --> Output Class Initialized
INFO - 2017-06-21 13:59:22 --> Security Class Initialized
DEBUG - 2017-06-21 13:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:59:22 --> Input Class Initialized
INFO - 2017-06-21 13:59:22 --> Language Class Initialized
INFO - 2017-06-21 13:59:22 --> Loader Class Initialized
INFO - 2017-06-21 13:59:22 --> Controller Class Initialized
INFO - 2017-06-21 13:59:22 --> Database Driver Class Initialized
INFO - 2017-06-21 13:59:22 --> Model Class Initialized
INFO - 2017-06-21 13:59:22 --> Helper loaded: form_helper
INFO - 2017-06-21 13:59:22 --> Helper loaded: url_helper
INFO - 2017-06-21 13:59:22 --> Upload Class Initialized
INFO - 2017-06-21 13:59:22 --> Final output sent to browser
DEBUG - 2017-06-21 13:59:22 --> Total execution time: 0.0610
ERROR - 2017-06-21 13:59:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:59:23 --> Config Class Initialized
INFO - 2017-06-21 13:59:23 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:59:23 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:59:23 --> Utf8 Class Initialized
INFO - 2017-06-21 13:59:23 --> URI Class Initialized
INFO - 2017-06-21 13:59:23 --> Router Class Initialized
INFO - 2017-06-21 13:59:23 --> Output Class Initialized
INFO - 2017-06-21 13:59:23 --> Security Class Initialized
DEBUG - 2017-06-21 13:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:59:23 --> Input Class Initialized
INFO - 2017-06-21 13:59:23 --> Language Class Initialized
INFO - 2017-06-21 13:59:23 --> Loader Class Initialized
INFO - 2017-06-21 13:59:23 --> Controller Class Initialized
INFO - 2017-06-21 13:59:23 --> Database Driver Class Initialized
INFO - 2017-06-21 13:59:23 --> Model Class Initialized
INFO - 2017-06-21 13:59:23 --> Helper loaded: form_helper
INFO - 2017-06-21 13:59:23 --> Helper loaded: url_helper
INFO - 2017-06-21 13:59:23 --> Model Class Initialized
INFO - 2017-06-21 13:59:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 13:59:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 13:59:23 --> Final output sent to browser
DEBUG - 2017-06-21 13:59:23 --> Total execution time: 0.0710
ERROR - 2017-06-21 13:59:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:59:25 --> Config Class Initialized
INFO - 2017-06-21 13:59:25 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:59:25 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:59:25 --> Utf8 Class Initialized
INFO - 2017-06-21 13:59:25 --> URI Class Initialized
INFO - 2017-06-21 13:59:25 --> Router Class Initialized
INFO - 2017-06-21 13:59:25 --> Output Class Initialized
INFO - 2017-06-21 13:59:25 --> Security Class Initialized
DEBUG - 2017-06-21 13:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:59:25 --> Input Class Initialized
INFO - 2017-06-21 13:59:25 --> Language Class Initialized
INFO - 2017-06-21 13:59:25 --> Loader Class Initialized
INFO - 2017-06-21 13:59:25 --> Controller Class Initialized
INFO - 2017-06-21 13:59:25 --> Database Driver Class Initialized
INFO - 2017-06-21 13:59:25 --> Model Class Initialized
INFO - 2017-06-21 13:59:25 --> Helper loaded: form_helper
INFO - 2017-06-21 13:59:25 --> Helper loaded: url_helper
INFO - 2017-06-21 13:59:25 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 13:59:25 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 13:59:25 --> Final output sent to browser
DEBUG - 2017-06-21 13:59:25 --> Total execution time: 0.0660
ERROR - 2017-06-21 13:59:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:59:30 --> Config Class Initialized
INFO - 2017-06-21 13:59:30 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:59:30 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:59:30 --> Utf8 Class Initialized
INFO - 2017-06-21 13:59:30 --> URI Class Initialized
INFO - 2017-06-21 13:59:30 --> Router Class Initialized
INFO - 2017-06-21 13:59:30 --> Output Class Initialized
INFO - 2017-06-21 13:59:30 --> Security Class Initialized
DEBUG - 2017-06-21 13:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:59:30 --> Input Class Initialized
INFO - 2017-06-21 13:59:30 --> Language Class Initialized
INFO - 2017-06-21 13:59:30 --> Loader Class Initialized
INFO - 2017-06-21 13:59:30 --> Controller Class Initialized
INFO - 2017-06-21 13:59:30 --> Database Driver Class Initialized
INFO - 2017-06-21 13:59:30 --> Model Class Initialized
INFO - 2017-06-21 13:59:30 --> Helper loaded: form_helper
INFO - 2017-06-21 13:59:30 --> Helper loaded: url_helper
INFO - 2017-06-21 13:59:30 --> Upload Class Initialized
INFO - 2017-06-21 13:59:30 --> Final output sent to browser
DEBUG - 2017-06-21 13:59:30 --> Total execution time: 0.0510
ERROR - 2017-06-21 13:59:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:59:31 --> Config Class Initialized
INFO - 2017-06-21 13:59:31 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:59:31 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:59:31 --> Utf8 Class Initialized
INFO - 2017-06-21 13:59:31 --> URI Class Initialized
INFO - 2017-06-21 13:59:31 --> Router Class Initialized
INFO - 2017-06-21 13:59:31 --> Output Class Initialized
INFO - 2017-06-21 13:59:31 --> Security Class Initialized
DEBUG - 2017-06-21 13:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:59:31 --> Input Class Initialized
INFO - 2017-06-21 13:59:31 --> Language Class Initialized
INFO - 2017-06-21 13:59:31 --> Loader Class Initialized
INFO - 2017-06-21 13:59:31 --> Controller Class Initialized
INFO - 2017-06-21 13:59:31 --> Database Driver Class Initialized
INFO - 2017-06-21 13:59:31 --> Model Class Initialized
INFO - 2017-06-21 13:59:31 --> Helper loaded: form_helper
INFO - 2017-06-21 13:59:31 --> Helper loaded: url_helper
INFO - 2017-06-21 13:59:31 --> Model Class Initialized
INFO - 2017-06-21 13:59:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 13:59:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 13:59:32 --> Final output sent to browser
DEBUG - 2017-06-21 13:59:32 --> Total execution time: 0.1490
ERROR - 2017-06-21 13:59:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:59:38 --> Config Class Initialized
INFO - 2017-06-21 13:59:38 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:59:38 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:59:38 --> Utf8 Class Initialized
INFO - 2017-06-21 13:59:38 --> URI Class Initialized
INFO - 2017-06-21 13:59:38 --> Router Class Initialized
INFO - 2017-06-21 13:59:38 --> Output Class Initialized
INFO - 2017-06-21 13:59:38 --> Security Class Initialized
DEBUG - 2017-06-21 13:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:59:38 --> Input Class Initialized
INFO - 2017-06-21 13:59:38 --> Language Class Initialized
INFO - 2017-06-21 13:59:38 --> Loader Class Initialized
INFO - 2017-06-21 13:59:38 --> Controller Class Initialized
INFO - 2017-06-21 13:59:38 --> Database Driver Class Initialized
INFO - 2017-06-21 13:59:38 --> Model Class Initialized
INFO - 2017-06-21 13:59:38 --> Helper loaded: form_helper
INFO - 2017-06-21 13:59:38 --> Helper loaded: url_helper
INFO - 2017-06-21 13:59:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 13:59:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 13:59:38 --> Final output sent to browser
DEBUG - 2017-06-21 13:59:38 --> Total execution time: 0.0480
ERROR - 2017-06-21 13:59:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:59:51 --> Config Class Initialized
INFO - 2017-06-21 13:59:51 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:59:51 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:59:51 --> Utf8 Class Initialized
INFO - 2017-06-21 13:59:51 --> URI Class Initialized
INFO - 2017-06-21 13:59:51 --> Router Class Initialized
INFO - 2017-06-21 13:59:51 --> Output Class Initialized
INFO - 2017-06-21 13:59:51 --> Security Class Initialized
DEBUG - 2017-06-21 13:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:59:51 --> Input Class Initialized
INFO - 2017-06-21 13:59:51 --> Language Class Initialized
INFO - 2017-06-21 13:59:51 --> Loader Class Initialized
INFO - 2017-06-21 13:59:51 --> Controller Class Initialized
INFO - 2017-06-21 13:59:51 --> Database Driver Class Initialized
INFO - 2017-06-21 13:59:51 --> Model Class Initialized
INFO - 2017-06-21 13:59:51 --> Helper loaded: form_helper
INFO - 2017-06-21 13:59:51 --> Helper loaded: url_helper
INFO - 2017-06-21 13:59:51 --> Upload Class Initialized
INFO - 2017-06-21 13:59:51 --> Final output sent to browser
DEBUG - 2017-06-21 13:59:51 --> Total execution time: 0.0600
ERROR - 2017-06-21 13:59:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:59:52 --> Config Class Initialized
INFO - 2017-06-21 13:59:52 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:59:52 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:59:52 --> Utf8 Class Initialized
INFO - 2017-06-21 13:59:52 --> URI Class Initialized
INFO - 2017-06-21 13:59:52 --> Router Class Initialized
INFO - 2017-06-21 13:59:52 --> Output Class Initialized
INFO - 2017-06-21 13:59:52 --> Security Class Initialized
DEBUG - 2017-06-21 13:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:59:52 --> Input Class Initialized
INFO - 2017-06-21 13:59:52 --> Language Class Initialized
INFO - 2017-06-21 13:59:52 --> Loader Class Initialized
INFO - 2017-06-21 13:59:52 --> Controller Class Initialized
INFO - 2017-06-21 13:59:52 --> Database Driver Class Initialized
INFO - 2017-06-21 13:59:52 --> Model Class Initialized
INFO - 2017-06-21 13:59:52 --> Helper loaded: form_helper
INFO - 2017-06-21 13:59:52 --> Helper loaded: url_helper
INFO - 2017-06-21 13:59:52 --> Model Class Initialized
INFO - 2017-06-21 13:59:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 13:59:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 13:59:52 --> Final output sent to browser
DEBUG - 2017-06-21 13:59:52 --> Total execution time: 0.0870
ERROR - 2017-06-21 13:59:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 13:59:54 --> Config Class Initialized
INFO - 2017-06-21 13:59:54 --> Hooks Class Initialized
DEBUG - 2017-06-21 13:59:54 --> UTF-8 Support Enabled
INFO - 2017-06-21 13:59:54 --> Utf8 Class Initialized
INFO - 2017-06-21 13:59:54 --> URI Class Initialized
INFO - 2017-06-21 13:59:54 --> Router Class Initialized
INFO - 2017-06-21 13:59:54 --> Output Class Initialized
INFO - 2017-06-21 13:59:54 --> Security Class Initialized
DEBUG - 2017-06-21 13:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 13:59:54 --> Input Class Initialized
INFO - 2017-06-21 13:59:54 --> Language Class Initialized
INFO - 2017-06-21 13:59:54 --> Loader Class Initialized
INFO - 2017-06-21 13:59:54 --> Controller Class Initialized
INFO - 2017-06-21 13:59:54 --> Database Driver Class Initialized
INFO - 2017-06-21 13:59:54 --> Model Class Initialized
INFO - 2017-06-21 13:59:54 --> Helper loaded: form_helper
INFO - 2017-06-21 13:59:54 --> Helper loaded: url_helper
INFO - 2017-06-21 13:59:54 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 13:59:54 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 13:59:54 --> Final output sent to browser
DEBUG - 2017-06-21 13:59:54 --> Total execution time: 0.0760
ERROR - 2017-06-21 14:00:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:00:13 --> Config Class Initialized
INFO - 2017-06-21 14:00:13 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:00:13 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:00:13 --> Utf8 Class Initialized
INFO - 2017-06-21 14:00:13 --> URI Class Initialized
INFO - 2017-06-21 14:00:13 --> Router Class Initialized
INFO - 2017-06-21 14:00:13 --> Output Class Initialized
INFO - 2017-06-21 14:00:13 --> Security Class Initialized
DEBUG - 2017-06-21 14:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:00:13 --> Input Class Initialized
INFO - 2017-06-21 14:00:13 --> Language Class Initialized
INFO - 2017-06-21 14:00:13 --> Loader Class Initialized
INFO - 2017-06-21 14:00:13 --> Controller Class Initialized
INFO - 2017-06-21 14:00:13 --> Database Driver Class Initialized
INFO - 2017-06-21 14:00:13 --> Model Class Initialized
INFO - 2017-06-21 14:00:13 --> Helper loaded: form_helper
INFO - 2017-06-21 14:00:13 --> Helper loaded: url_helper
INFO - 2017-06-21 14:00:13 --> Upload Class Initialized
INFO - 2017-06-21 14:00:13 --> Final output sent to browser
DEBUG - 2017-06-21 14:00:13 --> Total execution time: 0.0880
ERROR - 2017-06-21 14:00:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:00:16 --> Config Class Initialized
INFO - 2017-06-21 14:00:16 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:00:16 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:00:16 --> Utf8 Class Initialized
INFO - 2017-06-21 14:00:16 --> URI Class Initialized
INFO - 2017-06-21 14:00:16 --> Router Class Initialized
INFO - 2017-06-21 14:00:16 --> Output Class Initialized
INFO - 2017-06-21 14:00:16 --> Security Class Initialized
DEBUG - 2017-06-21 14:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:00:16 --> Input Class Initialized
INFO - 2017-06-21 14:00:16 --> Language Class Initialized
INFO - 2017-06-21 14:00:16 --> Loader Class Initialized
INFO - 2017-06-21 14:00:16 --> Controller Class Initialized
INFO - 2017-06-21 14:00:16 --> Database Driver Class Initialized
INFO - 2017-06-21 14:00:16 --> Model Class Initialized
INFO - 2017-06-21 14:00:16 --> Helper loaded: form_helper
INFO - 2017-06-21 14:00:16 --> Helper loaded: url_helper
INFO - 2017-06-21 14:00:16 --> Model Class Initialized
INFO - 2017-06-21 14:00:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 14:00:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 14:00:16 --> Final output sent to browser
DEBUG - 2017-06-21 14:00:16 --> Total execution time: 0.1800
ERROR - 2017-06-21 14:00:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:00:18 --> Config Class Initialized
INFO - 2017-06-21 14:00:18 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:00:18 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:00:18 --> Utf8 Class Initialized
INFO - 2017-06-21 14:00:18 --> URI Class Initialized
INFO - 2017-06-21 14:00:18 --> Router Class Initialized
INFO - 2017-06-21 14:00:18 --> Output Class Initialized
INFO - 2017-06-21 14:00:18 --> Security Class Initialized
DEBUG - 2017-06-21 14:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:00:18 --> Input Class Initialized
INFO - 2017-06-21 14:00:18 --> Language Class Initialized
INFO - 2017-06-21 14:00:18 --> Loader Class Initialized
INFO - 2017-06-21 14:00:18 --> Controller Class Initialized
INFO - 2017-06-21 14:00:18 --> Database Driver Class Initialized
INFO - 2017-06-21 14:00:18 --> Model Class Initialized
INFO - 2017-06-21 14:00:18 --> Helper loaded: form_helper
INFO - 2017-06-21 14:00:18 --> Helper loaded: url_helper
INFO - 2017-06-21 14:00:18 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 14:00:18 --> Model Class Initialized
INFO - 2017-06-21 14:00:18 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-06-21 14:00:18 --> Final output sent to browser
DEBUG - 2017-06-21 14:00:18 --> Total execution time: 0.0870
ERROR - 2017-06-21 14:00:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:00:20 --> Config Class Initialized
INFO - 2017-06-21 14:00:20 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:00:20 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:00:20 --> Utf8 Class Initialized
INFO - 2017-06-21 14:00:20 --> URI Class Initialized
INFO - 2017-06-21 14:00:20 --> Router Class Initialized
INFO - 2017-06-21 14:00:20 --> Output Class Initialized
INFO - 2017-06-21 14:00:20 --> Security Class Initialized
DEBUG - 2017-06-21 14:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:00:20 --> Input Class Initialized
INFO - 2017-06-21 14:00:20 --> Language Class Initialized
INFO - 2017-06-21 14:00:20 --> Loader Class Initialized
INFO - 2017-06-21 14:00:20 --> Controller Class Initialized
INFO - 2017-06-21 14:00:20 --> Database Driver Class Initialized
INFO - 2017-06-21 14:00:20 --> Model Class Initialized
INFO - 2017-06-21 14:00:20 --> Helper loaded: form_helper
INFO - 2017-06-21 14:00:20 --> Helper loaded: url_helper
INFO - 2017-06-21 14:00:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 14:00:20 --> Model Class Initialized
INFO - 2017-06-21 14:00:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-06-21 14:00:20 --> Final output sent to browser
DEBUG - 2017-06-21 14:00:20 --> Total execution time: 0.0610
ERROR - 2017-06-21 14:00:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:00:23 --> Config Class Initialized
INFO - 2017-06-21 14:00:23 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:00:23 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:00:23 --> Utf8 Class Initialized
INFO - 2017-06-21 14:00:23 --> URI Class Initialized
INFO - 2017-06-21 14:00:23 --> Router Class Initialized
INFO - 2017-06-21 14:00:23 --> Output Class Initialized
INFO - 2017-06-21 14:00:23 --> Security Class Initialized
DEBUG - 2017-06-21 14:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:00:23 --> Input Class Initialized
INFO - 2017-06-21 14:00:23 --> Language Class Initialized
INFO - 2017-06-21 14:00:23 --> Loader Class Initialized
INFO - 2017-06-21 14:00:23 --> Controller Class Initialized
INFO - 2017-06-21 14:00:23 --> Database Driver Class Initialized
INFO - 2017-06-21 14:00:23 --> Model Class Initialized
INFO - 2017-06-21 14:00:23 --> Helper loaded: form_helper
INFO - 2017-06-21 14:00:23 --> Helper loaded: url_helper
INFO - 2017-06-21 14:00:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 14:00:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 14:00:23 --> Final output sent to browser
DEBUG - 2017-06-21 14:00:23 --> Total execution time: 0.0690
ERROR - 2017-06-21 14:00:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:00:30 --> Config Class Initialized
INFO - 2017-06-21 14:00:30 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:00:30 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:00:30 --> Utf8 Class Initialized
INFO - 2017-06-21 14:00:30 --> URI Class Initialized
INFO - 2017-06-21 14:00:30 --> Router Class Initialized
INFO - 2017-06-21 14:00:30 --> Output Class Initialized
INFO - 2017-06-21 14:00:30 --> Security Class Initialized
DEBUG - 2017-06-21 14:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:00:30 --> Input Class Initialized
INFO - 2017-06-21 14:00:30 --> Language Class Initialized
INFO - 2017-06-21 14:00:30 --> Loader Class Initialized
INFO - 2017-06-21 14:00:30 --> Controller Class Initialized
INFO - 2017-06-21 14:00:30 --> Database Driver Class Initialized
INFO - 2017-06-21 14:00:30 --> Model Class Initialized
INFO - 2017-06-21 14:00:30 --> Helper loaded: form_helper
INFO - 2017-06-21 14:00:30 --> Helper loaded: url_helper
INFO - 2017-06-21 14:00:30 --> Upload Class Initialized
INFO - 2017-06-21 14:00:30 --> Final output sent to browser
DEBUG - 2017-06-21 14:00:30 --> Total execution time: 0.0680
ERROR - 2017-06-21 14:00:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:00:32 --> Config Class Initialized
INFO - 2017-06-21 14:00:32 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:00:32 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:00:32 --> Utf8 Class Initialized
INFO - 2017-06-21 14:00:32 --> URI Class Initialized
INFO - 2017-06-21 14:00:32 --> Router Class Initialized
INFO - 2017-06-21 14:00:32 --> Output Class Initialized
INFO - 2017-06-21 14:00:32 --> Security Class Initialized
DEBUG - 2017-06-21 14:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:00:32 --> Input Class Initialized
INFO - 2017-06-21 14:00:32 --> Language Class Initialized
INFO - 2017-06-21 14:00:32 --> Loader Class Initialized
INFO - 2017-06-21 14:00:32 --> Controller Class Initialized
INFO - 2017-06-21 14:00:32 --> Database Driver Class Initialized
INFO - 2017-06-21 14:00:32 --> Model Class Initialized
INFO - 2017-06-21 14:00:32 --> Helper loaded: form_helper
INFO - 2017-06-21 14:00:32 --> Helper loaded: url_helper
INFO - 2017-06-21 14:00:32 --> Model Class Initialized
INFO - 2017-06-21 14:00:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 14:00:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 14:00:32 --> Final output sent to browser
DEBUG - 2017-06-21 14:00:32 --> Total execution time: 0.1310
ERROR - 2017-06-21 14:00:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:00:34 --> Config Class Initialized
INFO - 2017-06-21 14:00:34 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:00:34 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:00:34 --> Utf8 Class Initialized
INFO - 2017-06-21 14:00:34 --> URI Class Initialized
INFO - 2017-06-21 14:00:34 --> Router Class Initialized
INFO - 2017-06-21 14:00:34 --> Output Class Initialized
INFO - 2017-06-21 14:00:34 --> Security Class Initialized
DEBUG - 2017-06-21 14:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:00:34 --> Input Class Initialized
INFO - 2017-06-21 14:00:34 --> Language Class Initialized
INFO - 2017-06-21 14:00:34 --> Loader Class Initialized
INFO - 2017-06-21 14:00:34 --> Controller Class Initialized
INFO - 2017-06-21 14:00:34 --> Database Driver Class Initialized
INFO - 2017-06-21 14:00:34 --> Model Class Initialized
INFO - 2017-06-21 14:00:34 --> Helper loaded: form_helper
INFO - 2017-06-21 14:00:34 --> Helper loaded: url_helper
INFO - 2017-06-21 14:00:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 14:00:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 14:00:34 --> Final output sent to browser
DEBUG - 2017-06-21 14:00:34 --> Total execution time: 0.0830
ERROR - 2017-06-21 14:00:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:00:55 --> Config Class Initialized
INFO - 2017-06-21 14:00:55 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:00:55 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:00:55 --> Utf8 Class Initialized
INFO - 2017-06-21 14:00:55 --> URI Class Initialized
INFO - 2017-06-21 14:00:55 --> Router Class Initialized
INFO - 2017-06-21 14:00:55 --> Output Class Initialized
INFO - 2017-06-21 14:00:55 --> Security Class Initialized
DEBUG - 2017-06-21 14:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:00:55 --> Input Class Initialized
INFO - 2017-06-21 14:00:55 --> Language Class Initialized
INFO - 2017-06-21 14:00:55 --> Loader Class Initialized
INFO - 2017-06-21 14:00:55 --> Controller Class Initialized
INFO - 2017-06-21 14:00:55 --> Database Driver Class Initialized
INFO - 2017-06-21 14:00:55 --> Model Class Initialized
INFO - 2017-06-21 14:00:55 --> Helper loaded: form_helper
INFO - 2017-06-21 14:00:55 --> Helper loaded: url_helper
INFO - 2017-06-21 14:00:55 --> Upload Class Initialized
INFO - 2017-06-21 14:00:55 --> Final output sent to browser
DEBUG - 2017-06-21 14:00:55 --> Total execution time: 0.0680
ERROR - 2017-06-21 14:00:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:00:57 --> Config Class Initialized
INFO - 2017-06-21 14:00:57 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:00:57 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:00:57 --> Utf8 Class Initialized
INFO - 2017-06-21 14:00:57 --> URI Class Initialized
INFO - 2017-06-21 14:00:57 --> Router Class Initialized
INFO - 2017-06-21 14:00:57 --> Output Class Initialized
INFO - 2017-06-21 14:00:57 --> Security Class Initialized
DEBUG - 2017-06-21 14:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:00:57 --> Input Class Initialized
INFO - 2017-06-21 14:00:57 --> Language Class Initialized
INFO - 2017-06-21 14:00:57 --> Loader Class Initialized
INFO - 2017-06-21 14:00:57 --> Controller Class Initialized
INFO - 2017-06-21 14:00:57 --> Database Driver Class Initialized
INFO - 2017-06-21 14:00:57 --> Model Class Initialized
INFO - 2017-06-21 14:00:57 --> Helper loaded: form_helper
INFO - 2017-06-21 14:00:57 --> Helper loaded: url_helper
INFO - 2017-06-21 14:00:57 --> Model Class Initialized
INFO - 2017-06-21 14:00:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 14:00:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 14:00:58 --> Final output sent to browser
DEBUG - 2017-06-21 14:00:58 --> Total execution time: 0.3590
ERROR - 2017-06-21 14:00:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:00:59 --> Config Class Initialized
INFO - 2017-06-21 14:00:59 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:00:59 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:00:59 --> Utf8 Class Initialized
INFO - 2017-06-21 14:00:59 --> URI Class Initialized
INFO - 2017-06-21 14:00:59 --> Router Class Initialized
INFO - 2017-06-21 14:00:59 --> Output Class Initialized
INFO - 2017-06-21 14:00:59 --> Security Class Initialized
DEBUG - 2017-06-21 14:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:00:59 --> Input Class Initialized
INFO - 2017-06-21 14:00:59 --> Language Class Initialized
INFO - 2017-06-21 14:00:59 --> Loader Class Initialized
INFO - 2017-06-21 14:00:59 --> Controller Class Initialized
INFO - 2017-06-21 14:00:59 --> Database Driver Class Initialized
INFO - 2017-06-21 14:00:59 --> Model Class Initialized
INFO - 2017-06-21 14:00:59 --> Helper loaded: form_helper
INFO - 2017-06-21 14:00:59 --> Helper loaded: url_helper
INFO - 2017-06-21 14:00:59 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 14:00:59 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 14:00:59 --> Final output sent to browser
DEBUG - 2017-06-21 14:00:59 --> Total execution time: 0.0560
ERROR - 2017-06-21 14:01:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:01:06 --> Config Class Initialized
INFO - 2017-06-21 14:01:06 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:01:06 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:01:06 --> Utf8 Class Initialized
INFO - 2017-06-21 14:01:06 --> URI Class Initialized
INFO - 2017-06-21 14:01:06 --> Router Class Initialized
INFO - 2017-06-21 14:01:06 --> Output Class Initialized
INFO - 2017-06-21 14:01:06 --> Security Class Initialized
DEBUG - 2017-06-21 14:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:01:06 --> Input Class Initialized
INFO - 2017-06-21 14:01:06 --> Language Class Initialized
INFO - 2017-06-21 14:01:06 --> Loader Class Initialized
INFO - 2017-06-21 14:01:06 --> Controller Class Initialized
INFO - 2017-06-21 14:01:06 --> Database Driver Class Initialized
INFO - 2017-06-21 14:01:06 --> Model Class Initialized
INFO - 2017-06-21 14:01:06 --> Helper loaded: form_helper
INFO - 2017-06-21 14:01:06 --> Helper loaded: url_helper
INFO - 2017-06-21 14:01:06 --> Upload Class Initialized
INFO - 2017-06-21 14:01:06 --> Final output sent to browser
DEBUG - 2017-06-21 14:01:06 --> Total execution time: 0.0710
ERROR - 2017-06-21 14:01:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:01:07 --> Config Class Initialized
INFO - 2017-06-21 14:01:07 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:01:07 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:01:07 --> Utf8 Class Initialized
INFO - 2017-06-21 14:01:07 --> URI Class Initialized
INFO - 2017-06-21 14:01:07 --> Router Class Initialized
INFO - 2017-06-21 14:01:07 --> Output Class Initialized
INFO - 2017-06-21 14:01:07 --> Security Class Initialized
DEBUG - 2017-06-21 14:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:01:07 --> Input Class Initialized
INFO - 2017-06-21 14:01:07 --> Language Class Initialized
INFO - 2017-06-21 14:01:07 --> Loader Class Initialized
INFO - 2017-06-21 14:01:07 --> Controller Class Initialized
INFO - 2017-06-21 14:01:07 --> Database Driver Class Initialized
INFO - 2017-06-21 14:01:07 --> Model Class Initialized
INFO - 2017-06-21 14:01:07 --> Helper loaded: form_helper
INFO - 2017-06-21 14:01:07 --> Helper loaded: url_helper
INFO - 2017-06-21 14:01:07 --> Model Class Initialized
INFO - 2017-06-21 14:01:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 14:01:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 14:01:07 --> Final output sent to browser
DEBUG - 2017-06-21 14:01:07 --> Total execution time: 0.1790
ERROR - 2017-06-21 14:01:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:01:10 --> Config Class Initialized
INFO - 2017-06-21 14:01:10 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:01:10 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:01:10 --> Utf8 Class Initialized
INFO - 2017-06-21 14:01:10 --> URI Class Initialized
INFO - 2017-06-21 14:01:10 --> Router Class Initialized
INFO - 2017-06-21 14:01:10 --> Output Class Initialized
INFO - 2017-06-21 14:01:10 --> Security Class Initialized
DEBUG - 2017-06-21 14:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:01:10 --> Input Class Initialized
INFO - 2017-06-21 14:01:10 --> Language Class Initialized
INFO - 2017-06-21 14:01:10 --> Loader Class Initialized
INFO - 2017-06-21 14:01:10 --> Controller Class Initialized
INFO - 2017-06-21 14:01:10 --> Database Driver Class Initialized
INFO - 2017-06-21 14:01:10 --> Model Class Initialized
INFO - 2017-06-21 14:01:10 --> Helper loaded: form_helper
INFO - 2017-06-21 14:01:10 --> Helper loaded: url_helper
INFO - 2017-06-21 14:01:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 14:01:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 14:01:10 --> Final output sent to browser
DEBUG - 2017-06-21 14:01:10 --> Total execution time: 0.0860
ERROR - 2017-06-21 14:01:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:01:16 --> Config Class Initialized
INFO - 2017-06-21 14:01:16 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:01:16 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:01:16 --> Utf8 Class Initialized
INFO - 2017-06-21 14:01:16 --> URI Class Initialized
INFO - 2017-06-21 14:01:16 --> Router Class Initialized
INFO - 2017-06-21 14:01:16 --> Output Class Initialized
INFO - 2017-06-21 14:01:16 --> Security Class Initialized
DEBUG - 2017-06-21 14:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:01:16 --> Input Class Initialized
INFO - 2017-06-21 14:01:16 --> Language Class Initialized
INFO - 2017-06-21 14:01:16 --> Loader Class Initialized
INFO - 2017-06-21 14:01:16 --> Controller Class Initialized
INFO - 2017-06-21 14:01:16 --> Database Driver Class Initialized
INFO - 2017-06-21 14:01:16 --> Model Class Initialized
INFO - 2017-06-21 14:01:16 --> Helper loaded: form_helper
INFO - 2017-06-21 14:01:16 --> Helper loaded: url_helper
INFO - 2017-06-21 14:01:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 14:01:16 --> Model Class Initialized
INFO - 2017-06-21 14:01:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-06-21 14:01:16 --> Final output sent to browser
DEBUG - 2017-06-21 14:01:16 --> Total execution time: 0.0880
ERROR - 2017-06-21 14:01:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:01:19 --> Config Class Initialized
INFO - 2017-06-21 14:01:19 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:01:19 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:01:19 --> Utf8 Class Initialized
INFO - 2017-06-21 14:01:19 --> URI Class Initialized
INFO - 2017-06-21 14:01:19 --> Router Class Initialized
INFO - 2017-06-21 14:01:19 --> Output Class Initialized
INFO - 2017-06-21 14:01:19 --> Security Class Initialized
DEBUG - 2017-06-21 14:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:01:19 --> Input Class Initialized
INFO - 2017-06-21 14:01:19 --> Language Class Initialized
INFO - 2017-06-21 14:01:19 --> Loader Class Initialized
INFO - 2017-06-21 14:01:19 --> Controller Class Initialized
INFO - 2017-06-21 14:01:19 --> Database Driver Class Initialized
INFO - 2017-06-21 14:01:19 --> Model Class Initialized
INFO - 2017-06-21 14:01:19 --> Helper loaded: form_helper
INFO - 2017-06-21 14:01:19 --> Helper loaded: url_helper
INFO - 2017-06-21 14:01:19 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 14:01:19 --> Model Class Initialized
INFO - 2017-06-21 14:01:19 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-06-21 14:01:19 --> Final output sent to browser
DEBUG - 2017-06-21 14:01:19 --> Total execution time: 0.0590
ERROR - 2017-06-21 14:01:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:01:22 --> Config Class Initialized
INFO - 2017-06-21 14:01:22 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:01:22 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:01:22 --> Utf8 Class Initialized
INFO - 2017-06-21 14:01:22 --> URI Class Initialized
INFO - 2017-06-21 14:01:22 --> Router Class Initialized
INFO - 2017-06-21 14:01:22 --> Output Class Initialized
INFO - 2017-06-21 14:01:22 --> Security Class Initialized
DEBUG - 2017-06-21 14:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:01:22 --> Input Class Initialized
INFO - 2017-06-21 14:01:22 --> Language Class Initialized
INFO - 2017-06-21 14:01:22 --> Loader Class Initialized
INFO - 2017-06-21 14:01:22 --> Controller Class Initialized
INFO - 2017-06-21 14:01:22 --> Database Driver Class Initialized
INFO - 2017-06-21 14:01:22 --> Model Class Initialized
INFO - 2017-06-21 14:01:22 --> Helper loaded: form_helper
INFO - 2017-06-21 14:01:22 --> Helper loaded: url_helper
INFO - 2017-06-21 14:01:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 14:01:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 14:01:22 --> Final output sent to browser
DEBUG - 2017-06-21 14:01:22 --> Total execution time: 0.0410
ERROR - 2017-06-21 14:01:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:01:28 --> Config Class Initialized
INFO - 2017-06-21 14:01:28 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:01:28 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:01:28 --> Utf8 Class Initialized
INFO - 2017-06-21 14:01:28 --> URI Class Initialized
INFO - 2017-06-21 14:01:28 --> Router Class Initialized
INFO - 2017-06-21 14:01:28 --> Output Class Initialized
INFO - 2017-06-21 14:01:28 --> Security Class Initialized
DEBUG - 2017-06-21 14:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:01:28 --> Input Class Initialized
INFO - 2017-06-21 14:01:28 --> Language Class Initialized
INFO - 2017-06-21 14:01:28 --> Loader Class Initialized
INFO - 2017-06-21 14:01:28 --> Controller Class Initialized
INFO - 2017-06-21 14:01:28 --> Database Driver Class Initialized
INFO - 2017-06-21 14:01:28 --> Model Class Initialized
INFO - 2017-06-21 14:01:28 --> Helper loaded: form_helper
INFO - 2017-06-21 14:01:28 --> Helper loaded: url_helper
INFO - 2017-06-21 14:01:28 --> Upload Class Initialized
INFO - 2017-06-21 14:01:28 --> Final output sent to browser
DEBUG - 2017-06-21 14:01:28 --> Total execution time: 0.0720
ERROR - 2017-06-21 14:01:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:01:29 --> Config Class Initialized
INFO - 2017-06-21 14:01:29 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:01:29 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:01:29 --> Utf8 Class Initialized
INFO - 2017-06-21 14:01:29 --> URI Class Initialized
INFO - 2017-06-21 14:01:29 --> Router Class Initialized
INFO - 2017-06-21 14:01:29 --> Output Class Initialized
INFO - 2017-06-21 14:01:29 --> Security Class Initialized
DEBUG - 2017-06-21 14:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:01:29 --> Input Class Initialized
INFO - 2017-06-21 14:01:29 --> Language Class Initialized
INFO - 2017-06-21 14:01:29 --> Loader Class Initialized
INFO - 2017-06-21 14:01:29 --> Controller Class Initialized
INFO - 2017-06-21 14:01:29 --> Database Driver Class Initialized
INFO - 2017-06-21 14:01:29 --> Model Class Initialized
INFO - 2017-06-21 14:01:29 --> Helper loaded: form_helper
INFO - 2017-06-21 14:01:29 --> Helper loaded: url_helper
INFO - 2017-06-21 14:01:29 --> Model Class Initialized
INFO - 2017-06-21 14:01:29 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 14:01:29 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-21 14:01:29 --> Final output sent to browser
DEBUG - 2017-06-21 14:01:29 --> Total execution time: 0.1230
ERROR - 2017-06-21 14:01:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:01:33 --> Config Class Initialized
INFO - 2017-06-21 14:01:33 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:01:33 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:01:33 --> Utf8 Class Initialized
INFO - 2017-06-21 14:01:33 --> URI Class Initialized
INFO - 2017-06-21 14:01:33 --> Router Class Initialized
INFO - 2017-06-21 14:01:33 --> Output Class Initialized
INFO - 2017-06-21 14:01:33 --> Security Class Initialized
DEBUG - 2017-06-21 14:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:01:33 --> Input Class Initialized
INFO - 2017-06-21 14:01:33 --> Language Class Initialized
INFO - 2017-06-21 14:01:33 --> Loader Class Initialized
INFO - 2017-06-21 14:01:33 --> Controller Class Initialized
INFO - 2017-06-21 14:01:33 --> Database Driver Class Initialized
INFO - 2017-06-21 14:01:33 --> Model Class Initialized
INFO - 2017-06-21 14:01:33 --> Helper loaded: form_helper
INFO - 2017-06-21 14:01:33 --> Helper loaded: url_helper
INFO - 2017-06-21 14:01:33 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 14:01:33 --> Model Class Initialized
INFO - 2017-06-21 14:01:33 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-06-21 14:01:33 --> Final output sent to browser
DEBUG - 2017-06-21 14:01:33 --> Total execution time: 0.0570
ERROR - 2017-06-21 14:01:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:01:35 --> Config Class Initialized
INFO - 2017-06-21 14:01:35 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:01:35 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:01:35 --> Utf8 Class Initialized
INFO - 2017-06-21 14:01:35 --> URI Class Initialized
INFO - 2017-06-21 14:01:35 --> Router Class Initialized
INFO - 2017-06-21 14:01:35 --> Output Class Initialized
INFO - 2017-06-21 14:01:35 --> Security Class Initialized
DEBUG - 2017-06-21 14:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:01:35 --> Input Class Initialized
INFO - 2017-06-21 14:01:35 --> Language Class Initialized
INFO - 2017-06-21 14:01:35 --> Loader Class Initialized
INFO - 2017-06-21 14:01:35 --> Controller Class Initialized
INFO - 2017-06-21 14:01:35 --> Database Driver Class Initialized
INFO - 2017-06-21 14:01:35 --> Model Class Initialized
INFO - 2017-06-21 14:01:35 --> Helper loaded: form_helper
INFO - 2017-06-21 14:01:35 --> Helper loaded: url_helper
INFO - 2017-06-21 14:01:35 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 14:01:35 --> Model Class Initialized
INFO - 2017-06-21 14:01:35 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-06-21 14:01:35 --> Final output sent to browser
DEBUG - 2017-06-21 14:01:35 --> Total execution time: 0.0610
ERROR - 2017-06-21 14:01:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:01:36 --> Config Class Initialized
INFO - 2017-06-21 14:01:36 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:01:36 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:01:36 --> Utf8 Class Initialized
INFO - 2017-06-21 14:01:36 --> URI Class Initialized
INFO - 2017-06-21 14:01:36 --> Router Class Initialized
INFO - 2017-06-21 14:01:36 --> Output Class Initialized
INFO - 2017-06-21 14:01:36 --> Security Class Initialized
DEBUG - 2017-06-21 14:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:01:36 --> Input Class Initialized
INFO - 2017-06-21 14:01:36 --> Language Class Initialized
INFO - 2017-06-21 14:01:36 --> Loader Class Initialized
INFO - 2017-06-21 14:01:36 --> Controller Class Initialized
INFO - 2017-06-21 14:01:36 --> Database Driver Class Initialized
INFO - 2017-06-21 14:01:36 --> Model Class Initialized
INFO - 2017-06-21 14:01:36 --> Helper loaded: form_helper
INFO - 2017-06-21 14:01:36 --> Helper loaded: url_helper
INFO - 2017-06-21 14:01:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 14:01:36 --> Model Class Initialized
INFO - 2017-06-21 14:01:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-06-21 14:01:36 --> Final output sent to browser
DEBUG - 2017-06-21 14:01:36 --> Total execution time: 0.0540
ERROR - 2017-06-21 14:01:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:01:38 --> Config Class Initialized
INFO - 2017-06-21 14:01:38 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:01:38 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:01:38 --> Utf8 Class Initialized
INFO - 2017-06-21 14:01:38 --> URI Class Initialized
INFO - 2017-06-21 14:01:38 --> Router Class Initialized
INFO - 2017-06-21 14:01:38 --> Output Class Initialized
INFO - 2017-06-21 14:01:38 --> Security Class Initialized
DEBUG - 2017-06-21 14:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:01:38 --> Input Class Initialized
INFO - 2017-06-21 14:01:38 --> Language Class Initialized
INFO - 2017-06-21 14:01:38 --> Loader Class Initialized
INFO - 2017-06-21 14:01:38 --> Controller Class Initialized
INFO - 2017-06-21 14:01:38 --> Database Driver Class Initialized
INFO - 2017-06-21 14:01:38 --> Model Class Initialized
INFO - 2017-06-21 14:01:38 --> Helper loaded: form_helper
INFO - 2017-06-21 14:01:38 --> Helper loaded: url_helper
INFO - 2017-06-21 14:01:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 14:01:38 --> Model Class Initialized
INFO - 2017-06-21 14:01:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-06-21 14:01:38 --> Final output sent to browser
DEBUG - 2017-06-21 14:01:38 --> Total execution time: 0.0600
ERROR - 2017-06-21 14:01:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:01:39 --> Config Class Initialized
INFO - 2017-06-21 14:01:39 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:01:39 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:01:39 --> Utf8 Class Initialized
INFO - 2017-06-21 14:01:39 --> URI Class Initialized
INFO - 2017-06-21 14:01:39 --> Router Class Initialized
INFO - 2017-06-21 14:01:39 --> Output Class Initialized
INFO - 2017-06-21 14:01:39 --> Security Class Initialized
DEBUG - 2017-06-21 14:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:01:39 --> Input Class Initialized
INFO - 2017-06-21 14:01:39 --> Language Class Initialized
INFO - 2017-06-21 14:01:39 --> Loader Class Initialized
INFO - 2017-06-21 14:01:39 --> Controller Class Initialized
INFO - 2017-06-21 14:01:39 --> Database Driver Class Initialized
INFO - 2017-06-21 14:01:39 --> Model Class Initialized
INFO - 2017-06-21 14:01:39 --> Helper loaded: form_helper
INFO - 2017-06-21 14:01:39 --> Helper loaded: url_helper
INFO - 2017-06-21 14:01:39 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-21 14:01:39 --> Model Class Initialized
INFO - 2017-06-21 14:01:39 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-06-21 14:01:39 --> Final output sent to browser
DEBUG - 2017-06-21 14:01:39 --> Total execution time: 0.0780
ERROR - 2017-06-21 14:13:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:13:51 --> Config Class Initialized
INFO - 2017-06-21 14:13:51 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:13:51 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:13:51 --> Utf8 Class Initialized
INFO - 2017-06-21 14:13:51 --> URI Class Initialized
INFO - 2017-06-21 14:13:51 --> Router Class Initialized
INFO - 2017-06-21 14:13:51 --> Output Class Initialized
INFO - 2017-06-21 14:13:51 --> Security Class Initialized
DEBUG - 2017-06-21 14:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:13:51 --> Input Class Initialized
INFO - 2017-06-21 14:13:51 --> Language Class Initialized
INFO - 2017-06-21 14:13:51 --> Loader Class Initialized
INFO - 2017-06-21 14:13:51 --> Controller Class Initialized
INFO - 2017-06-21 14:13:51 --> Database Driver Class Initialized
INFO - 2017-06-21 14:13:51 --> Model Class Initialized
INFO - 2017-06-21 14:13:51 --> Helper loaded: form_helper
INFO - 2017-06-21 14:13:51 --> Helper loaded: url_helper
INFO - 2017-06-21 14:13:51 --> Model Class Initialized
INFO - 2017-06-21 14:13:51 --> Final output sent to browser
DEBUG - 2017-06-21 14:13:51 --> Total execution time: 0.0500
ERROR - 2017-06-21 14:14:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:14:16 --> Config Class Initialized
INFO - 2017-06-21 14:14:16 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:14:16 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:14:16 --> Utf8 Class Initialized
INFO - 2017-06-21 14:14:16 --> URI Class Initialized
INFO - 2017-06-21 14:14:16 --> Router Class Initialized
INFO - 2017-06-21 14:14:16 --> Output Class Initialized
INFO - 2017-06-21 14:14:16 --> Security Class Initialized
DEBUG - 2017-06-21 14:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:14:16 --> Input Class Initialized
INFO - 2017-06-21 14:14:16 --> Language Class Initialized
INFO - 2017-06-21 14:14:16 --> Loader Class Initialized
INFO - 2017-06-21 14:14:16 --> Controller Class Initialized
INFO - 2017-06-21 14:14:16 --> Database Driver Class Initialized
INFO - 2017-06-21 14:14:16 --> Model Class Initialized
INFO - 2017-06-21 14:14:16 --> Helper loaded: form_helper
INFO - 2017-06-21 14:14:16 --> Helper loaded: url_helper
INFO - 2017-06-21 14:14:16 --> Model Class Initialized
INFO - 2017-06-21 14:14:16 --> Final output sent to browser
DEBUG - 2017-06-21 14:14:16 --> Total execution time: 0.0650
ERROR - 2017-06-21 14:14:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:14:21 --> Config Class Initialized
INFO - 2017-06-21 14:14:21 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:14:21 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:14:21 --> Utf8 Class Initialized
INFO - 2017-06-21 14:14:21 --> URI Class Initialized
INFO - 2017-06-21 14:14:21 --> Router Class Initialized
INFO - 2017-06-21 14:14:21 --> Output Class Initialized
INFO - 2017-06-21 14:14:21 --> Security Class Initialized
DEBUG - 2017-06-21 14:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:14:21 --> Input Class Initialized
INFO - 2017-06-21 14:14:21 --> Language Class Initialized
INFO - 2017-06-21 14:14:21 --> Loader Class Initialized
INFO - 2017-06-21 14:14:21 --> Controller Class Initialized
INFO - 2017-06-21 14:14:21 --> Database Driver Class Initialized
INFO - 2017-06-21 14:14:21 --> Model Class Initialized
INFO - 2017-06-21 14:14:21 --> Helper loaded: form_helper
INFO - 2017-06-21 14:14:21 --> Helper loaded: url_helper
INFO - 2017-06-21 14:14:21 --> Model Class Initialized
INFO - 2017-06-21 14:14:21 --> Final output sent to browser
DEBUG - 2017-06-21 14:14:21 --> Total execution time: 0.0740
ERROR - 2017-06-21 14:26:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 14:26:19 --> Config Class Initialized
INFO - 2017-06-21 14:26:19 --> Hooks Class Initialized
DEBUG - 2017-06-21 14:26:19 --> UTF-8 Support Enabled
INFO - 2017-06-21 14:26:19 --> Utf8 Class Initialized
INFO - 2017-06-21 14:26:19 --> URI Class Initialized
INFO - 2017-06-21 14:26:19 --> Router Class Initialized
INFO - 2017-06-21 14:26:19 --> Output Class Initialized
INFO - 2017-06-21 14:26:19 --> Security Class Initialized
DEBUG - 2017-06-21 14:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 14:26:19 --> Input Class Initialized
INFO - 2017-06-21 14:26:19 --> Language Class Initialized
INFO - 2017-06-21 14:26:19 --> Loader Class Initialized
INFO - 2017-06-21 14:26:19 --> Controller Class Initialized
INFO - 2017-06-21 14:26:19 --> Database Driver Class Initialized
INFO - 2017-06-21 14:26:19 --> Model Class Initialized
INFO - 2017-06-21 14:26:19 --> Helper loaded: form_helper
INFO - 2017-06-21 14:26:19 --> Helper loaded: url_helper
INFO - 2017-06-21 14:26:19 --> Model Class Initialized
INFO - 2017-06-21 14:26:19 --> Final output sent to browser
DEBUG - 2017-06-21 14:26:19 --> Total execution time: 0.0680
ERROR - 2017-06-21 16:27:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 16:27:07 --> Config Class Initialized
INFO - 2017-06-21 16:27:07 --> Hooks Class Initialized
DEBUG - 2017-06-21 16:27:07 --> UTF-8 Support Enabled
INFO - 2017-06-21 16:27:07 --> Utf8 Class Initialized
INFO - 2017-06-21 16:27:07 --> URI Class Initialized
INFO - 2017-06-21 16:27:07 --> Router Class Initialized
INFO - 2017-06-21 16:27:07 --> Output Class Initialized
INFO - 2017-06-21 16:27:07 --> Security Class Initialized
DEBUG - 2017-06-21 16:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 16:27:07 --> Input Class Initialized
INFO - 2017-06-21 16:27:07 --> Language Class Initialized
INFO - 2017-06-21 16:27:07 --> Loader Class Initialized
INFO - 2017-06-21 16:27:07 --> Controller Class Initialized
INFO - 2017-06-21 16:27:07 --> Database Driver Class Initialized
INFO - 2017-06-21 16:27:07 --> Model Class Initialized
INFO - 2017-06-21 16:27:07 --> Helper loaded: form_helper
INFO - 2017-06-21 16:27:07 --> Helper loaded: url_helper
INFO - 2017-06-21 16:27:07 --> Model Class Initialized
INFO - 2017-06-21 16:27:07 --> Final output sent to browser
DEBUG - 2017-06-21 16:27:07 --> Total execution time: 0.0570
ERROR - 2017-06-21 16:27:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 16:27:08 --> Config Class Initialized
INFO - 2017-06-21 16:27:08 --> Hooks Class Initialized
DEBUG - 2017-06-21 16:27:08 --> UTF-8 Support Enabled
INFO - 2017-06-21 16:27:08 --> Utf8 Class Initialized
INFO - 2017-06-21 16:27:08 --> URI Class Initialized
INFO - 2017-06-21 16:27:09 --> Router Class Initialized
INFO - 2017-06-21 16:27:09 --> Output Class Initialized
INFO - 2017-06-21 16:27:09 --> Security Class Initialized
DEBUG - 2017-06-21 16:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 16:27:09 --> Input Class Initialized
INFO - 2017-06-21 16:27:09 --> Language Class Initialized
INFO - 2017-06-21 16:27:09 --> Loader Class Initialized
INFO - 2017-06-21 16:27:09 --> Controller Class Initialized
INFO - 2017-06-21 16:27:09 --> Database Driver Class Initialized
INFO - 2017-06-21 16:27:09 --> Model Class Initialized
INFO - 2017-06-21 16:27:09 --> Helper loaded: form_helper
INFO - 2017-06-21 16:27:09 --> Helper loaded: url_helper
INFO - 2017-06-21 16:27:09 --> Model Class Initialized
INFO - 2017-06-21 16:27:09 --> Final output sent to browser
DEBUG - 2017-06-21 16:27:09 --> Total execution time: 0.0420
ERROR - 2017-06-21 16:27:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 16:27:24 --> Config Class Initialized
INFO - 2017-06-21 16:27:24 --> Hooks Class Initialized
DEBUG - 2017-06-21 16:27:24 --> UTF-8 Support Enabled
INFO - 2017-06-21 16:27:24 --> Utf8 Class Initialized
INFO - 2017-06-21 16:27:24 --> URI Class Initialized
INFO - 2017-06-21 16:27:24 --> Router Class Initialized
INFO - 2017-06-21 16:27:24 --> Output Class Initialized
INFO - 2017-06-21 16:27:24 --> Security Class Initialized
DEBUG - 2017-06-21 16:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 16:27:24 --> Input Class Initialized
INFO - 2017-06-21 16:27:24 --> Language Class Initialized
INFO - 2017-06-21 16:27:24 --> Loader Class Initialized
INFO - 2017-06-21 16:27:25 --> Controller Class Initialized
INFO - 2017-06-21 16:27:25 --> Database Driver Class Initialized
INFO - 2017-06-21 16:27:25 --> Model Class Initialized
INFO - 2017-06-21 16:27:25 --> Helper loaded: form_helper
INFO - 2017-06-21 16:27:25 --> Helper loaded: url_helper
INFO - 2017-06-21 16:27:25 --> Model Class Initialized
INFO - 2017-06-21 16:27:25 --> Final output sent to browser
DEBUG - 2017-06-21 16:27:25 --> Total execution time: 0.0420
ERROR - 2017-06-21 16:27:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 16:27:27 --> Config Class Initialized
INFO - 2017-06-21 16:27:27 --> Hooks Class Initialized
DEBUG - 2017-06-21 16:27:27 --> UTF-8 Support Enabled
INFO - 2017-06-21 16:27:27 --> Utf8 Class Initialized
INFO - 2017-06-21 16:27:27 --> URI Class Initialized
INFO - 2017-06-21 16:27:27 --> Router Class Initialized
INFO - 2017-06-21 16:27:27 --> Output Class Initialized
INFO - 2017-06-21 16:27:27 --> Security Class Initialized
DEBUG - 2017-06-21 16:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 16:27:27 --> Input Class Initialized
INFO - 2017-06-21 16:27:27 --> Language Class Initialized
INFO - 2017-06-21 16:27:27 --> Loader Class Initialized
INFO - 2017-06-21 16:27:27 --> Controller Class Initialized
INFO - 2017-06-21 16:27:27 --> Database Driver Class Initialized
INFO - 2017-06-21 16:27:27 --> Model Class Initialized
INFO - 2017-06-21 16:27:27 --> Helper loaded: form_helper
INFO - 2017-06-21 16:27:27 --> Helper loaded: url_helper
INFO - 2017-06-21 16:27:27 --> Model Class Initialized
INFO - 2017-06-21 16:27:27 --> Final output sent to browser
DEBUG - 2017-06-21 16:27:27 --> Total execution time: 0.0460
ERROR - 2017-06-21 16:27:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 16:27:30 --> Config Class Initialized
INFO - 2017-06-21 16:27:30 --> Hooks Class Initialized
DEBUG - 2017-06-21 16:27:30 --> UTF-8 Support Enabled
INFO - 2017-06-21 16:27:30 --> Utf8 Class Initialized
INFO - 2017-06-21 16:27:30 --> URI Class Initialized
INFO - 2017-06-21 16:27:30 --> Router Class Initialized
INFO - 2017-06-21 16:27:30 --> Output Class Initialized
INFO - 2017-06-21 16:27:30 --> Security Class Initialized
DEBUG - 2017-06-21 16:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 16:27:30 --> Input Class Initialized
INFO - 2017-06-21 16:27:30 --> Language Class Initialized
INFO - 2017-06-21 16:27:30 --> Loader Class Initialized
INFO - 2017-06-21 16:27:30 --> Controller Class Initialized
INFO - 2017-06-21 16:27:30 --> Database Driver Class Initialized
INFO - 2017-06-21 16:27:30 --> Model Class Initialized
INFO - 2017-06-21 16:27:30 --> Helper loaded: form_helper
INFO - 2017-06-21 16:27:30 --> Helper loaded: url_helper
INFO - 2017-06-21 16:27:30 --> Model Class Initialized
INFO - 2017-06-21 16:27:30 --> Final output sent to browser
DEBUG - 2017-06-21 16:27:30 --> Total execution time: 0.0420
ERROR - 2017-06-21 16:27:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 16:27:32 --> Config Class Initialized
INFO - 2017-06-21 16:27:32 --> Hooks Class Initialized
DEBUG - 2017-06-21 16:27:32 --> UTF-8 Support Enabled
INFO - 2017-06-21 16:27:32 --> Utf8 Class Initialized
INFO - 2017-06-21 16:27:32 --> URI Class Initialized
INFO - 2017-06-21 16:27:32 --> Router Class Initialized
INFO - 2017-06-21 16:27:32 --> Output Class Initialized
INFO - 2017-06-21 16:27:32 --> Security Class Initialized
DEBUG - 2017-06-21 16:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 16:27:32 --> Input Class Initialized
INFO - 2017-06-21 16:27:32 --> Language Class Initialized
INFO - 2017-06-21 16:27:32 --> Loader Class Initialized
INFO - 2017-06-21 16:27:32 --> Controller Class Initialized
INFO - 2017-06-21 16:27:32 --> Database Driver Class Initialized
INFO - 2017-06-21 16:27:32 --> Model Class Initialized
INFO - 2017-06-21 16:27:32 --> Helper loaded: form_helper
INFO - 2017-06-21 16:27:32 --> Helper loaded: url_helper
INFO - 2017-06-21 16:27:32 --> Model Class Initialized
INFO - 2017-06-21 16:27:32 --> Final output sent to browser
DEBUG - 2017-06-21 16:27:32 --> Total execution time: 0.0415
ERROR - 2017-06-21 16:27:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 16:27:43 --> Config Class Initialized
INFO - 2017-06-21 16:27:43 --> Hooks Class Initialized
DEBUG - 2017-06-21 16:27:43 --> UTF-8 Support Enabled
INFO - 2017-06-21 16:27:43 --> Utf8 Class Initialized
INFO - 2017-06-21 16:27:43 --> URI Class Initialized
INFO - 2017-06-21 16:27:43 --> Router Class Initialized
INFO - 2017-06-21 16:27:43 --> Output Class Initialized
INFO - 2017-06-21 16:27:43 --> Security Class Initialized
DEBUG - 2017-06-21 16:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 16:27:43 --> Input Class Initialized
INFO - 2017-06-21 16:27:43 --> Language Class Initialized
INFO - 2017-06-21 16:27:43 --> Loader Class Initialized
INFO - 2017-06-21 16:27:43 --> Controller Class Initialized
INFO - 2017-06-21 16:27:43 --> Database Driver Class Initialized
INFO - 2017-06-21 16:27:43 --> Model Class Initialized
INFO - 2017-06-21 16:27:43 --> Helper loaded: form_helper
INFO - 2017-06-21 16:27:43 --> Helper loaded: url_helper
INFO - 2017-06-21 16:27:43 --> Model Class Initialized
INFO - 2017-06-21 16:27:43 --> Final output sent to browser
DEBUG - 2017-06-21 16:27:43 --> Total execution time: 0.0470
ERROR - 2017-06-21 16:27:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 16:27:46 --> Config Class Initialized
INFO - 2017-06-21 16:27:46 --> Hooks Class Initialized
DEBUG - 2017-06-21 16:27:46 --> UTF-8 Support Enabled
INFO - 2017-06-21 16:27:46 --> Utf8 Class Initialized
INFO - 2017-06-21 16:27:46 --> URI Class Initialized
INFO - 2017-06-21 16:27:46 --> Router Class Initialized
INFO - 2017-06-21 16:27:46 --> Output Class Initialized
INFO - 2017-06-21 16:27:46 --> Security Class Initialized
DEBUG - 2017-06-21 16:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 16:27:46 --> Input Class Initialized
INFO - 2017-06-21 16:27:46 --> Language Class Initialized
INFO - 2017-06-21 16:27:46 --> Loader Class Initialized
INFO - 2017-06-21 16:27:46 --> Controller Class Initialized
INFO - 2017-06-21 16:27:46 --> Database Driver Class Initialized
INFO - 2017-06-21 16:27:46 --> Model Class Initialized
INFO - 2017-06-21 16:27:46 --> Helper loaded: form_helper
INFO - 2017-06-21 16:27:46 --> Helper loaded: url_helper
INFO - 2017-06-21 16:27:46 --> Model Class Initialized
INFO - 2017-06-21 16:27:46 --> Final output sent to browser
DEBUG - 2017-06-21 16:27:46 --> Total execution time: 0.0460
ERROR - 2017-06-21 16:27:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 16:27:48 --> Config Class Initialized
INFO - 2017-06-21 16:27:48 --> Hooks Class Initialized
DEBUG - 2017-06-21 16:27:48 --> UTF-8 Support Enabled
INFO - 2017-06-21 16:27:48 --> Utf8 Class Initialized
INFO - 2017-06-21 16:27:48 --> URI Class Initialized
INFO - 2017-06-21 16:27:48 --> Router Class Initialized
INFO - 2017-06-21 16:27:48 --> Output Class Initialized
INFO - 2017-06-21 16:27:48 --> Security Class Initialized
DEBUG - 2017-06-21 16:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 16:27:48 --> Input Class Initialized
INFO - 2017-06-21 16:27:48 --> Language Class Initialized
INFO - 2017-06-21 16:27:48 --> Loader Class Initialized
INFO - 2017-06-21 16:27:48 --> Controller Class Initialized
INFO - 2017-06-21 16:27:48 --> Database Driver Class Initialized
INFO - 2017-06-21 16:27:48 --> Model Class Initialized
INFO - 2017-06-21 16:27:48 --> Helper loaded: form_helper
INFO - 2017-06-21 16:27:48 --> Helper loaded: url_helper
INFO - 2017-06-21 16:27:48 --> Model Class Initialized
INFO - 2017-06-21 16:27:48 --> Final output sent to browser
DEBUG - 2017-06-21 16:27:48 --> Total execution time: 0.0460
ERROR - 2017-06-21 16:27:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 16:27:55 --> Config Class Initialized
INFO - 2017-06-21 16:27:55 --> Hooks Class Initialized
DEBUG - 2017-06-21 16:27:55 --> UTF-8 Support Enabled
INFO - 2017-06-21 16:27:55 --> Utf8 Class Initialized
INFO - 2017-06-21 16:27:55 --> URI Class Initialized
INFO - 2017-06-21 16:27:55 --> Router Class Initialized
INFO - 2017-06-21 16:27:55 --> Output Class Initialized
INFO - 2017-06-21 16:27:55 --> Security Class Initialized
DEBUG - 2017-06-21 16:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 16:27:55 --> Input Class Initialized
INFO - 2017-06-21 16:27:55 --> Language Class Initialized
INFO - 2017-06-21 16:27:55 --> Loader Class Initialized
INFO - 2017-06-21 16:27:55 --> Controller Class Initialized
INFO - 2017-06-21 16:27:55 --> Database Driver Class Initialized
INFO - 2017-06-21 16:27:55 --> Model Class Initialized
INFO - 2017-06-21 16:27:55 --> Helper loaded: form_helper
INFO - 2017-06-21 16:27:55 --> Helper loaded: url_helper
INFO - 2017-06-21 16:27:55 --> Model Class Initialized
INFO - 2017-06-21 16:27:55 --> Final output sent to browser
DEBUG - 2017-06-21 16:27:55 --> Total execution time: 0.0420
ERROR - 2017-06-21 16:57:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 16:57:02 --> Config Class Initialized
INFO - 2017-06-21 16:57:02 --> Hooks Class Initialized
DEBUG - 2017-06-21 16:57:02 --> UTF-8 Support Enabled
INFO - 2017-06-21 16:57:02 --> Utf8 Class Initialized
INFO - 2017-06-21 16:57:02 --> URI Class Initialized
INFO - 2017-06-21 16:57:02 --> Router Class Initialized
INFO - 2017-06-21 16:57:02 --> Output Class Initialized
INFO - 2017-06-21 16:57:02 --> Security Class Initialized
DEBUG - 2017-06-21 16:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 16:57:02 --> Input Class Initialized
INFO - 2017-06-21 16:57:02 --> Language Class Initialized
INFO - 2017-06-21 16:57:02 --> Loader Class Initialized
INFO - 2017-06-21 16:57:02 --> Controller Class Initialized
INFO - 2017-06-21 16:57:02 --> Database Driver Class Initialized
INFO - 2017-06-21 16:57:02 --> Model Class Initialized
INFO - 2017-06-21 16:57:02 --> Helper loaded: form_helper
INFO - 2017-06-21 16:57:02 --> Helper loaded: url_helper
INFO - 2017-06-21 16:57:02 --> Model Class Initialized
INFO - 2017-06-21 16:57:02 --> Final output sent to browser
DEBUG - 2017-06-21 16:57:02 --> Total execution time: 0.0600
ERROR - 2017-06-21 16:57:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 16:57:03 --> Config Class Initialized
INFO - 2017-06-21 16:57:03 --> Hooks Class Initialized
DEBUG - 2017-06-21 16:57:03 --> UTF-8 Support Enabled
INFO - 2017-06-21 16:57:03 --> Utf8 Class Initialized
INFO - 2017-06-21 16:57:03 --> URI Class Initialized
INFO - 2017-06-21 16:57:03 --> Router Class Initialized
INFO - 2017-06-21 16:57:03 --> Output Class Initialized
INFO - 2017-06-21 16:57:03 --> Security Class Initialized
DEBUG - 2017-06-21 16:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 16:57:03 --> Input Class Initialized
INFO - 2017-06-21 16:57:03 --> Language Class Initialized
INFO - 2017-06-21 16:57:03 --> Loader Class Initialized
INFO - 2017-06-21 16:57:03 --> Controller Class Initialized
INFO - 2017-06-21 16:57:03 --> Database Driver Class Initialized
INFO - 2017-06-21 16:57:03 --> Model Class Initialized
INFO - 2017-06-21 16:57:03 --> Helper loaded: form_helper
INFO - 2017-06-21 16:57:03 --> Helper loaded: url_helper
INFO - 2017-06-21 16:57:03 --> Model Class Initialized
INFO - 2017-06-21 16:57:03 --> Final output sent to browser
DEBUG - 2017-06-21 16:57:03 --> Total execution time: 0.0470
ERROR - 2017-06-21 16:57:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 16:57:18 --> Config Class Initialized
INFO - 2017-06-21 16:57:18 --> Hooks Class Initialized
DEBUG - 2017-06-21 16:57:18 --> UTF-8 Support Enabled
INFO - 2017-06-21 16:57:18 --> Utf8 Class Initialized
INFO - 2017-06-21 16:57:18 --> URI Class Initialized
INFO - 2017-06-21 16:57:18 --> Router Class Initialized
INFO - 2017-06-21 16:57:18 --> Output Class Initialized
INFO - 2017-06-21 16:57:18 --> Security Class Initialized
DEBUG - 2017-06-21 16:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 16:57:18 --> Input Class Initialized
INFO - 2017-06-21 16:57:18 --> Language Class Initialized
INFO - 2017-06-21 16:57:18 --> Loader Class Initialized
INFO - 2017-06-21 16:57:18 --> Controller Class Initialized
INFO - 2017-06-21 16:57:18 --> Database Driver Class Initialized
INFO - 2017-06-21 16:57:18 --> Model Class Initialized
INFO - 2017-06-21 16:57:18 --> Helper loaded: form_helper
INFO - 2017-06-21 16:57:18 --> Helper loaded: url_helper
INFO - 2017-06-21 16:57:18 --> Model Class Initialized
INFO - 2017-06-21 16:57:18 --> Final output sent to browser
DEBUG - 2017-06-21 16:57:18 --> Total execution time: 0.0410
ERROR - 2017-06-21 16:58:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 16:58:41 --> Config Class Initialized
INFO - 2017-06-21 16:58:41 --> Hooks Class Initialized
DEBUG - 2017-06-21 16:58:41 --> UTF-8 Support Enabled
INFO - 2017-06-21 16:58:41 --> Utf8 Class Initialized
INFO - 2017-06-21 16:58:41 --> URI Class Initialized
INFO - 2017-06-21 16:58:41 --> Router Class Initialized
INFO - 2017-06-21 16:58:41 --> Output Class Initialized
INFO - 2017-06-21 16:58:41 --> Security Class Initialized
DEBUG - 2017-06-21 16:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 16:58:41 --> Input Class Initialized
INFO - 2017-06-21 16:58:41 --> Language Class Initialized
INFO - 2017-06-21 16:58:41 --> Loader Class Initialized
INFO - 2017-06-21 16:58:41 --> Controller Class Initialized
INFO - 2017-06-21 16:58:41 --> Database Driver Class Initialized
INFO - 2017-06-21 16:58:41 --> Model Class Initialized
INFO - 2017-06-21 16:58:41 --> Helper loaded: form_helper
INFO - 2017-06-21 16:58:41 --> Helper loaded: url_helper
INFO - 2017-06-21 16:58:41 --> Model Class Initialized
INFO - 2017-06-21 16:58:41 --> Final output sent to browser
DEBUG - 2017-06-21 16:58:41 --> Total execution time: 0.0600
ERROR - 2017-06-21 16:58:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 16:58:42 --> Config Class Initialized
INFO - 2017-06-21 16:58:42 --> Hooks Class Initialized
DEBUG - 2017-06-21 16:58:42 --> UTF-8 Support Enabled
INFO - 2017-06-21 16:58:42 --> Utf8 Class Initialized
INFO - 2017-06-21 16:58:42 --> URI Class Initialized
INFO - 2017-06-21 16:58:42 --> Router Class Initialized
INFO - 2017-06-21 16:58:42 --> Output Class Initialized
INFO - 2017-06-21 16:58:42 --> Security Class Initialized
DEBUG - 2017-06-21 16:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 16:58:42 --> Input Class Initialized
INFO - 2017-06-21 16:58:42 --> Language Class Initialized
INFO - 2017-06-21 16:58:42 --> Loader Class Initialized
INFO - 2017-06-21 16:58:42 --> Controller Class Initialized
INFO - 2017-06-21 16:58:42 --> Database Driver Class Initialized
INFO - 2017-06-21 16:58:42 --> Model Class Initialized
INFO - 2017-06-21 16:58:42 --> Helper loaded: form_helper
INFO - 2017-06-21 16:58:42 --> Helper loaded: url_helper
INFO - 2017-06-21 16:58:42 --> Model Class Initialized
INFO - 2017-06-21 16:58:42 --> Final output sent to browser
DEBUG - 2017-06-21 16:58:42 --> Total execution time: 0.0460
ERROR - 2017-06-21 17:00:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:00:32 --> Config Class Initialized
INFO - 2017-06-21 17:00:32 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:00:32 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:00:32 --> Utf8 Class Initialized
INFO - 2017-06-21 17:00:32 --> URI Class Initialized
INFO - 2017-06-21 17:00:32 --> Router Class Initialized
INFO - 2017-06-21 17:00:32 --> Output Class Initialized
INFO - 2017-06-21 17:00:32 --> Security Class Initialized
DEBUG - 2017-06-21 17:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:00:32 --> Input Class Initialized
INFO - 2017-06-21 17:00:32 --> Language Class Initialized
INFO - 2017-06-21 17:00:32 --> Loader Class Initialized
INFO - 2017-06-21 17:00:32 --> Controller Class Initialized
INFO - 2017-06-21 17:00:32 --> Database Driver Class Initialized
INFO - 2017-06-21 17:00:32 --> Model Class Initialized
INFO - 2017-06-21 17:00:32 --> Helper loaded: form_helper
INFO - 2017-06-21 17:00:32 --> Helper loaded: url_helper
INFO - 2017-06-21 17:00:32 --> Model Class Initialized
INFO - 2017-06-21 17:00:32 --> Final output sent to browser
DEBUG - 2017-06-21 17:00:32 --> Total execution time: 0.0460
ERROR - 2017-06-21 17:00:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:00:33 --> Config Class Initialized
INFO - 2017-06-21 17:00:33 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:00:33 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:00:33 --> Utf8 Class Initialized
INFO - 2017-06-21 17:00:33 --> URI Class Initialized
INFO - 2017-06-21 17:00:33 --> Router Class Initialized
INFO - 2017-06-21 17:00:33 --> Output Class Initialized
INFO - 2017-06-21 17:00:33 --> Security Class Initialized
DEBUG - 2017-06-21 17:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:00:33 --> Input Class Initialized
INFO - 2017-06-21 17:00:33 --> Language Class Initialized
INFO - 2017-06-21 17:00:33 --> Loader Class Initialized
INFO - 2017-06-21 17:00:33 --> Controller Class Initialized
INFO - 2017-06-21 17:00:33 --> Database Driver Class Initialized
INFO - 2017-06-21 17:00:33 --> Model Class Initialized
INFO - 2017-06-21 17:00:33 --> Helper loaded: form_helper
INFO - 2017-06-21 17:00:33 --> Helper loaded: url_helper
INFO - 2017-06-21 17:00:33 --> Model Class Initialized
INFO - 2017-06-21 17:00:33 --> Final output sent to browser
DEBUG - 2017-06-21 17:00:33 --> Total execution time: 0.0450
ERROR - 2017-06-21 17:00:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:00:56 --> Config Class Initialized
INFO - 2017-06-21 17:00:56 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:00:56 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:00:56 --> Utf8 Class Initialized
INFO - 2017-06-21 17:00:56 --> URI Class Initialized
INFO - 2017-06-21 17:00:56 --> Router Class Initialized
INFO - 2017-06-21 17:00:56 --> Output Class Initialized
INFO - 2017-06-21 17:00:56 --> Security Class Initialized
DEBUG - 2017-06-21 17:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:00:56 --> Input Class Initialized
INFO - 2017-06-21 17:00:56 --> Language Class Initialized
INFO - 2017-06-21 17:00:56 --> Loader Class Initialized
INFO - 2017-06-21 17:00:56 --> Controller Class Initialized
INFO - 2017-06-21 17:00:56 --> Database Driver Class Initialized
INFO - 2017-06-21 17:00:56 --> Model Class Initialized
INFO - 2017-06-21 17:00:56 --> Helper loaded: form_helper
INFO - 2017-06-21 17:00:56 --> Helper loaded: url_helper
INFO - 2017-06-21 17:00:56 --> Model Class Initialized
INFO - 2017-06-21 17:00:56 --> Final output sent to browser
DEBUG - 2017-06-21 17:00:56 --> Total execution time: 0.0620
ERROR - 2017-06-21 17:02:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:02:39 --> Config Class Initialized
INFO - 2017-06-21 17:02:39 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:02:39 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:02:39 --> Utf8 Class Initialized
INFO - 2017-06-21 17:02:39 --> URI Class Initialized
INFO - 2017-06-21 17:02:39 --> Router Class Initialized
INFO - 2017-06-21 17:02:39 --> Output Class Initialized
INFO - 2017-06-21 17:02:39 --> Security Class Initialized
DEBUG - 2017-06-21 17:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:02:39 --> Input Class Initialized
INFO - 2017-06-21 17:02:39 --> Language Class Initialized
INFO - 2017-06-21 17:02:39 --> Loader Class Initialized
INFO - 2017-06-21 17:02:39 --> Controller Class Initialized
INFO - 2017-06-21 17:02:39 --> Database Driver Class Initialized
INFO - 2017-06-21 17:02:39 --> Model Class Initialized
INFO - 2017-06-21 17:02:39 --> Helper loaded: form_helper
INFO - 2017-06-21 17:02:39 --> Helper loaded: url_helper
INFO - 2017-06-21 17:02:39 --> Model Class Initialized
INFO - 2017-06-21 17:02:39 --> Final output sent to browser
DEBUG - 2017-06-21 17:02:39 --> Total execution time: 0.0620
ERROR - 2017-06-21 17:02:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:02:40 --> Config Class Initialized
INFO - 2017-06-21 17:02:40 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:02:40 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:02:40 --> Utf8 Class Initialized
INFO - 2017-06-21 17:02:40 --> URI Class Initialized
INFO - 2017-06-21 17:02:40 --> Router Class Initialized
INFO - 2017-06-21 17:02:40 --> Output Class Initialized
INFO - 2017-06-21 17:02:40 --> Security Class Initialized
DEBUG - 2017-06-21 17:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:02:40 --> Input Class Initialized
INFO - 2017-06-21 17:02:40 --> Language Class Initialized
INFO - 2017-06-21 17:02:40 --> Loader Class Initialized
INFO - 2017-06-21 17:02:40 --> Controller Class Initialized
INFO - 2017-06-21 17:02:40 --> Database Driver Class Initialized
INFO - 2017-06-21 17:02:40 --> Model Class Initialized
INFO - 2017-06-21 17:02:40 --> Helper loaded: form_helper
INFO - 2017-06-21 17:02:40 --> Helper loaded: url_helper
INFO - 2017-06-21 17:02:40 --> Model Class Initialized
INFO - 2017-06-21 17:02:40 --> Final output sent to browser
DEBUG - 2017-06-21 17:02:40 --> Total execution time: 0.0550
ERROR - 2017-06-21 17:02:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:02:55 --> Config Class Initialized
INFO - 2017-06-21 17:02:55 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:02:55 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:02:55 --> Utf8 Class Initialized
INFO - 2017-06-21 17:02:55 --> URI Class Initialized
INFO - 2017-06-21 17:02:55 --> Router Class Initialized
INFO - 2017-06-21 17:02:55 --> Output Class Initialized
INFO - 2017-06-21 17:02:55 --> Security Class Initialized
DEBUG - 2017-06-21 17:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:02:55 --> Input Class Initialized
INFO - 2017-06-21 17:02:55 --> Language Class Initialized
INFO - 2017-06-21 17:02:55 --> Loader Class Initialized
INFO - 2017-06-21 17:02:55 --> Controller Class Initialized
INFO - 2017-06-21 17:02:55 --> Database Driver Class Initialized
INFO - 2017-06-21 17:02:55 --> Model Class Initialized
INFO - 2017-06-21 17:02:55 --> Helper loaded: form_helper
INFO - 2017-06-21 17:02:55 --> Helper loaded: url_helper
INFO - 2017-06-21 17:02:55 --> Model Class Initialized
INFO - 2017-06-21 17:02:55 --> Final output sent to browser
DEBUG - 2017-06-21 17:02:55 --> Total execution time: 0.0510
ERROR - 2017-06-21 17:03:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:03:52 --> Config Class Initialized
INFO - 2017-06-21 17:03:52 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:03:52 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:03:52 --> Utf8 Class Initialized
INFO - 2017-06-21 17:03:52 --> URI Class Initialized
INFO - 2017-06-21 17:03:52 --> Router Class Initialized
INFO - 2017-06-21 17:03:52 --> Output Class Initialized
INFO - 2017-06-21 17:03:52 --> Security Class Initialized
DEBUG - 2017-06-21 17:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:03:52 --> Input Class Initialized
INFO - 2017-06-21 17:03:52 --> Language Class Initialized
INFO - 2017-06-21 17:03:52 --> Loader Class Initialized
INFO - 2017-06-21 17:03:52 --> Controller Class Initialized
INFO - 2017-06-21 17:03:52 --> Database Driver Class Initialized
INFO - 2017-06-21 17:03:52 --> Model Class Initialized
INFO - 2017-06-21 17:03:52 --> Helper loaded: form_helper
INFO - 2017-06-21 17:03:52 --> Helper loaded: url_helper
INFO - 2017-06-21 17:03:52 --> Model Class Initialized
INFO - 2017-06-21 17:03:52 --> Final output sent to browser
DEBUG - 2017-06-21 17:03:52 --> Total execution time: 0.0675
ERROR - 2017-06-21 17:03:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:03:53 --> Config Class Initialized
INFO - 2017-06-21 17:03:53 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:03:53 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:03:53 --> Utf8 Class Initialized
INFO - 2017-06-21 17:03:53 --> URI Class Initialized
INFO - 2017-06-21 17:03:53 --> Router Class Initialized
INFO - 2017-06-21 17:03:53 --> Output Class Initialized
INFO - 2017-06-21 17:03:53 --> Security Class Initialized
DEBUG - 2017-06-21 17:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:03:53 --> Input Class Initialized
INFO - 2017-06-21 17:03:53 --> Language Class Initialized
INFO - 2017-06-21 17:03:53 --> Loader Class Initialized
INFO - 2017-06-21 17:03:53 --> Controller Class Initialized
INFO - 2017-06-21 17:03:53 --> Database Driver Class Initialized
INFO - 2017-06-21 17:03:53 --> Model Class Initialized
INFO - 2017-06-21 17:03:53 --> Helper loaded: form_helper
INFO - 2017-06-21 17:03:53 --> Helper loaded: url_helper
INFO - 2017-06-21 17:03:53 --> Model Class Initialized
INFO - 2017-06-21 17:03:53 --> Final output sent to browser
DEBUG - 2017-06-21 17:03:53 --> Total execution time: 0.0540
ERROR - 2017-06-21 17:04:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:04:04 --> Config Class Initialized
INFO - 2017-06-21 17:04:04 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:04:04 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:04:04 --> Utf8 Class Initialized
INFO - 2017-06-21 17:04:04 --> URI Class Initialized
INFO - 2017-06-21 17:04:04 --> Router Class Initialized
INFO - 2017-06-21 17:04:04 --> Output Class Initialized
INFO - 2017-06-21 17:04:04 --> Security Class Initialized
DEBUG - 2017-06-21 17:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:04:04 --> Input Class Initialized
INFO - 2017-06-21 17:04:04 --> Language Class Initialized
INFO - 2017-06-21 17:04:04 --> Loader Class Initialized
INFO - 2017-06-21 17:04:04 --> Controller Class Initialized
INFO - 2017-06-21 17:04:04 --> Database Driver Class Initialized
INFO - 2017-06-21 17:04:04 --> Model Class Initialized
INFO - 2017-06-21 17:04:04 --> Helper loaded: form_helper
INFO - 2017-06-21 17:04:04 --> Helper loaded: url_helper
INFO - 2017-06-21 17:04:04 --> Model Class Initialized
INFO - 2017-06-21 17:04:04 --> Final output sent to browser
DEBUG - 2017-06-21 17:04:04 --> Total execution time: 0.0540
ERROR - 2017-06-21 17:24:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:24:31 --> Config Class Initialized
INFO - 2017-06-21 17:24:31 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:24:31 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:24:31 --> Utf8 Class Initialized
INFO - 2017-06-21 17:24:31 --> URI Class Initialized
INFO - 2017-06-21 17:24:31 --> Router Class Initialized
INFO - 2017-06-21 17:24:31 --> Output Class Initialized
INFO - 2017-06-21 17:24:31 --> Security Class Initialized
DEBUG - 2017-06-21 17:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:24:31 --> Input Class Initialized
INFO - 2017-06-21 17:24:31 --> Language Class Initialized
INFO - 2017-06-21 17:24:31 --> Loader Class Initialized
INFO - 2017-06-21 17:24:31 --> Controller Class Initialized
INFO - 2017-06-21 17:24:31 --> Database Driver Class Initialized
INFO - 2017-06-21 17:24:31 --> Model Class Initialized
INFO - 2017-06-21 17:24:31 --> Helper loaded: form_helper
INFO - 2017-06-21 17:24:31 --> Helper loaded: url_helper
INFO - 2017-06-21 17:24:31 --> Model Class Initialized
INFO - 2017-06-21 17:24:31 --> Final output sent to browser
DEBUG - 2017-06-21 17:24:31 --> Total execution time: 0.0520
ERROR - 2017-06-21 17:24:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:24:32 --> Config Class Initialized
INFO - 2017-06-21 17:24:32 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:24:32 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:24:32 --> Utf8 Class Initialized
INFO - 2017-06-21 17:24:32 --> URI Class Initialized
INFO - 2017-06-21 17:24:32 --> Router Class Initialized
INFO - 2017-06-21 17:24:32 --> Output Class Initialized
INFO - 2017-06-21 17:24:32 --> Security Class Initialized
DEBUG - 2017-06-21 17:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:24:32 --> Input Class Initialized
INFO - 2017-06-21 17:24:32 --> Language Class Initialized
INFO - 2017-06-21 17:24:32 --> Loader Class Initialized
INFO - 2017-06-21 17:24:32 --> Controller Class Initialized
INFO - 2017-06-21 17:24:32 --> Database Driver Class Initialized
INFO - 2017-06-21 17:24:32 --> Model Class Initialized
INFO - 2017-06-21 17:24:32 --> Helper loaded: form_helper
INFO - 2017-06-21 17:24:32 --> Helper loaded: url_helper
INFO - 2017-06-21 17:24:32 --> Model Class Initialized
INFO - 2017-06-21 17:24:32 --> Final output sent to browser
DEBUG - 2017-06-21 17:24:32 --> Total execution time: 0.0520
ERROR - 2017-06-21 17:24:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:24:46 --> Config Class Initialized
INFO - 2017-06-21 17:24:46 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:24:46 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:24:46 --> Utf8 Class Initialized
INFO - 2017-06-21 17:24:46 --> URI Class Initialized
INFO - 2017-06-21 17:24:46 --> Router Class Initialized
INFO - 2017-06-21 17:24:46 --> Output Class Initialized
INFO - 2017-06-21 17:24:46 --> Security Class Initialized
DEBUG - 2017-06-21 17:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:24:46 --> Input Class Initialized
INFO - 2017-06-21 17:24:46 --> Language Class Initialized
INFO - 2017-06-21 17:24:46 --> Loader Class Initialized
INFO - 2017-06-21 17:24:46 --> Controller Class Initialized
INFO - 2017-06-21 17:24:46 --> Database Driver Class Initialized
INFO - 2017-06-21 17:24:46 --> Model Class Initialized
INFO - 2017-06-21 17:24:46 --> Helper loaded: form_helper
INFO - 2017-06-21 17:24:46 --> Helper loaded: url_helper
INFO - 2017-06-21 17:24:46 --> Model Class Initialized
INFO - 2017-06-21 17:24:46 --> Final output sent to browser
DEBUG - 2017-06-21 17:24:46 --> Total execution time: 0.0530
ERROR - 2017-06-21 17:29:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:29:16 --> Config Class Initialized
INFO - 2017-06-21 17:29:16 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:29:16 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:29:16 --> Utf8 Class Initialized
INFO - 2017-06-21 17:29:16 --> URI Class Initialized
INFO - 2017-06-21 17:29:16 --> Router Class Initialized
INFO - 2017-06-21 17:29:16 --> Output Class Initialized
INFO - 2017-06-21 17:29:16 --> Security Class Initialized
DEBUG - 2017-06-21 17:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:29:16 --> Input Class Initialized
INFO - 2017-06-21 17:29:16 --> Language Class Initialized
INFO - 2017-06-21 17:29:16 --> Loader Class Initialized
INFO - 2017-06-21 17:29:16 --> Controller Class Initialized
INFO - 2017-06-21 17:29:16 --> Database Driver Class Initialized
INFO - 2017-06-21 17:29:16 --> Model Class Initialized
INFO - 2017-06-21 17:29:16 --> Helper loaded: form_helper
INFO - 2017-06-21 17:29:16 --> Helper loaded: url_helper
INFO - 2017-06-21 17:29:16 --> Model Class Initialized
INFO - 2017-06-21 17:29:16 --> Final output sent to browser
DEBUG - 2017-06-21 17:29:16 --> Total execution time: 0.0640
ERROR - 2017-06-21 17:29:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:29:17 --> Config Class Initialized
INFO - 2017-06-21 17:29:17 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:29:17 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:29:17 --> Utf8 Class Initialized
INFO - 2017-06-21 17:29:17 --> URI Class Initialized
INFO - 2017-06-21 17:29:17 --> Router Class Initialized
INFO - 2017-06-21 17:29:17 --> Output Class Initialized
INFO - 2017-06-21 17:29:17 --> Security Class Initialized
DEBUG - 2017-06-21 17:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:29:17 --> Input Class Initialized
INFO - 2017-06-21 17:29:17 --> Language Class Initialized
INFO - 2017-06-21 17:29:17 --> Loader Class Initialized
INFO - 2017-06-21 17:29:17 --> Controller Class Initialized
INFO - 2017-06-21 17:29:17 --> Database Driver Class Initialized
INFO - 2017-06-21 17:29:17 --> Model Class Initialized
INFO - 2017-06-21 17:29:17 --> Helper loaded: form_helper
INFO - 2017-06-21 17:29:17 --> Helper loaded: url_helper
INFO - 2017-06-21 17:29:17 --> Model Class Initialized
INFO - 2017-06-21 17:29:17 --> Final output sent to browser
DEBUG - 2017-06-21 17:29:17 --> Total execution time: 0.0540
ERROR - 2017-06-21 17:29:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:29:31 --> Config Class Initialized
INFO - 2017-06-21 17:29:31 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:29:31 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:29:31 --> Utf8 Class Initialized
INFO - 2017-06-21 17:29:31 --> URI Class Initialized
INFO - 2017-06-21 17:29:31 --> Router Class Initialized
INFO - 2017-06-21 17:29:31 --> Output Class Initialized
INFO - 2017-06-21 17:29:31 --> Security Class Initialized
DEBUG - 2017-06-21 17:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:29:31 --> Input Class Initialized
INFO - 2017-06-21 17:29:31 --> Language Class Initialized
INFO - 2017-06-21 17:29:31 --> Loader Class Initialized
INFO - 2017-06-21 17:29:31 --> Controller Class Initialized
INFO - 2017-06-21 17:29:31 --> Database Driver Class Initialized
INFO - 2017-06-21 17:29:31 --> Model Class Initialized
INFO - 2017-06-21 17:29:31 --> Helper loaded: form_helper
INFO - 2017-06-21 17:29:31 --> Helper loaded: url_helper
INFO - 2017-06-21 17:29:31 --> Model Class Initialized
INFO - 2017-06-21 17:29:31 --> Final output sent to browser
DEBUG - 2017-06-21 17:29:31 --> Total execution time: 0.0440
ERROR - 2017-06-21 17:31:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:31:03 --> Config Class Initialized
INFO - 2017-06-21 17:31:03 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:31:03 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:31:03 --> Utf8 Class Initialized
INFO - 2017-06-21 17:31:03 --> URI Class Initialized
INFO - 2017-06-21 17:31:03 --> Router Class Initialized
INFO - 2017-06-21 17:31:03 --> Output Class Initialized
INFO - 2017-06-21 17:31:03 --> Security Class Initialized
DEBUG - 2017-06-21 17:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:31:03 --> Input Class Initialized
INFO - 2017-06-21 17:31:03 --> Language Class Initialized
INFO - 2017-06-21 17:31:03 --> Loader Class Initialized
INFO - 2017-06-21 17:31:03 --> Controller Class Initialized
INFO - 2017-06-21 17:31:03 --> Database Driver Class Initialized
INFO - 2017-06-21 17:31:03 --> Model Class Initialized
INFO - 2017-06-21 17:31:03 --> Helper loaded: form_helper
INFO - 2017-06-21 17:31:03 --> Helper loaded: url_helper
INFO - 2017-06-21 17:31:03 --> Model Class Initialized
INFO - 2017-06-21 17:31:03 --> Final output sent to browser
DEBUG - 2017-06-21 17:31:03 --> Total execution time: 0.0430
ERROR - 2017-06-21 17:31:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:31:04 --> Config Class Initialized
INFO - 2017-06-21 17:31:04 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:31:04 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:31:04 --> Utf8 Class Initialized
INFO - 2017-06-21 17:31:04 --> URI Class Initialized
INFO - 2017-06-21 17:31:04 --> Router Class Initialized
INFO - 2017-06-21 17:31:04 --> Output Class Initialized
INFO - 2017-06-21 17:31:04 --> Security Class Initialized
DEBUG - 2017-06-21 17:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:31:04 --> Input Class Initialized
INFO - 2017-06-21 17:31:04 --> Language Class Initialized
INFO - 2017-06-21 17:31:04 --> Loader Class Initialized
INFO - 2017-06-21 17:31:04 --> Controller Class Initialized
INFO - 2017-06-21 17:31:04 --> Database Driver Class Initialized
INFO - 2017-06-21 17:31:04 --> Model Class Initialized
INFO - 2017-06-21 17:31:04 --> Helper loaded: form_helper
INFO - 2017-06-21 17:31:04 --> Helper loaded: url_helper
INFO - 2017-06-21 17:31:04 --> Model Class Initialized
INFO - 2017-06-21 17:31:04 --> Final output sent to browser
DEBUG - 2017-06-21 17:31:04 --> Total execution time: 0.0440
ERROR - 2017-06-21 17:31:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:31:14 --> Config Class Initialized
INFO - 2017-06-21 17:31:14 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:31:14 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:31:14 --> Utf8 Class Initialized
INFO - 2017-06-21 17:31:14 --> URI Class Initialized
INFO - 2017-06-21 17:31:14 --> Router Class Initialized
INFO - 2017-06-21 17:31:14 --> Output Class Initialized
INFO - 2017-06-21 17:31:14 --> Security Class Initialized
DEBUG - 2017-06-21 17:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:31:14 --> Input Class Initialized
INFO - 2017-06-21 17:31:14 --> Language Class Initialized
INFO - 2017-06-21 17:31:14 --> Loader Class Initialized
INFO - 2017-06-21 17:31:14 --> Controller Class Initialized
INFO - 2017-06-21 17:31:14 --> Database Driver Class Initialized
INFO - 2017-06-21 17:31:14 --> Model Class Initialized
INFO - 2017-06-21 17:31:14 --> Helper loaded: form_helper
INFO - 2017-06-21 17:31:14 --> Helper loaded: url_helper
INFO - 2017-06-21 17:31:14 --> Model Class Initialized
INFO - 2017-06-21 17:31:14 --> Final output sent to browser
DEBUG - 2017-06-21 17:31:14 --> Total execution time: 0.0570
ERROR - 2017-06-21 17:32:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:32:23 --> Config Class Initialized
INFO - 2017-06-21 17:32:23 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:32:23 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:32:23 --> Utf8 Class Initialized
INFO - 2017-06-21 17:32:23 --> URI Class Initialized
INFO - 2017-06-21 17:32:23 --> Router Class Initialized
INFO - 2017-06-21 17:32:23 --> Output Class Initialized
INFO - 2017-06-21 17:32:23 --> Security Class Initialized
DEBUG - 2017-06-21 17:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:32:23 --> Input Class Initialized
INFO - 2017-06-21 17:32:23 --> Language Class Initialized
INFO - 2017-06-21 17:32:23 --> Loader Class Initialized
INFO - 2017-06-21 17:32:23 --> Controller Class Initialized
INFO - 2017-06-21 17:32:23 --> Database Driver Class Initialized
INFO - 2017-06-21 17:32:23 --> Model Class Initialized
INFO - 2017-06-21 17:32:23 --> Helper loaded: form_helper
INFO - 2017-06-21 17:32:23 --> Helper loaded: url_helper
INFO - 2017-06-21 17:32:23 --> Model Class Initialized
INFO - 2017-06-21 17:32:23 --> Final output sent to browser
DEBUG - 2017-06-21 17:32:23 --> Total execution time: 0.0490
ERROR - 2017-06-21 17:32:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:32:32 --> Config Class Initialized
INFO - 2017-06-21 17:32:32 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:32:32 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:32:32 --> Utf8 Class Initialized
INFO - 2017-06-21 17:32:32 --> URI Class Initialized
INFO - 2017-06-21 17:32:32 --> Router Class Initialized
INFO - 2017-06-21 17:32:32 --> Output Class Initialized
INFO - 2017-06-21 17:32:32 --> Security Class Initialized
DEBUG - 2017-06-21 17:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:32:32 --> Input Class Initialized
INFO - 2017-06-21 17:32:32 --> Language Class Initialized
INFO - 2017-06-21 17:32:32 --> Loader Class Initialized
INFO - 2017-06-21 17:32:32 --> Controller Class Initialized
INFO - 2017-06-21 17:32:32 --> Database Driver Class Initialized
INFO - 2017-06-21 17:32:32 --> Model Class Initialized
INFO - 2017-06-21 17:32:32 --> Helper loaded: form_helper
INFO - 2017-06-21 17:32:32 --> Helper loaded: url_helper
INFO - 2017-06-21 17:32:32 --> Model Class Initialized
INFO - 2017-06-21 17:32:32 --> Final output sent to browser
DEBUG - 2017-06-21 17:32:32 --> Total execution time: 0.0450
ERROR - 2017-06-21 17:33:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:33:42 --> Config Class Initialized
INFO - 2017-06-21 17:33:42 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:33:42 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:33:42 --> Utf8 Class Initialized
INFO - 2017-06-21 17:33:42 --> URI Class Initialized
INFO - 2017-06-21 17:33:42 --> Router Class Initialized
INFO - 2017-06-21 17:33:42 --> Output Class Initialized
INFO - 2017-06-21 17:33:42 --> Security Class Initialized
DEBUG - 2017-06-21 17:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:33:42 --> Input Class Initialized
INFO - 2017-06-21 17:33:42 --> Language Class Initialized
INFO - 2017-06-21 17:33:42 --> Loader Class Initialized
INFO - 2017-06-21 17:33:42 --> Controller Class Initialized
INFO - 2017-06-21 17:33:42 --> Database Driver Class Initialized
INFO - 2017-06-21 17:33:42 --> Model Class Initialized
INFO - 2017-06-21 17:33:42 --> Helper loaded: form_helper
INFO - 2017-06-21 17:33:42 --> Helper loaded: url_helper
INFO - 2017-06-21 17:33:42 --> Model Class Initialized
INFO - 2017-06-21 17:33:42 --> Final output sent to browser
DEBUG - 2017-06-21 17:33:42 --> Total execution time: 0.0480
ERROR - 2017-06-21 17:34:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:34:35 --> Config Class Initialized
INFO - 2017-06-21 17:34:35 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:34:35 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:34:35 --> Utf8 Class Initialized
INFO - 2017-06-21 17:34:35 --> URI Class Initialized
INFO - 2017-06-21 17:34:35 --> Router Class Initialized
INFO - 2017-06-21 17:34:35 --> Output Class Initialized
INFO - 2017-06-21 17:34:35 --> Security Class Initialized
DEBUG - 2017-06-21 17:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:34:35 --> Input Class Initialized
INFO - 2017-06-21 17:34:35 --> Language Class Initialized
INFO - 2017-06-21 17:34:35 --> Loader Class Initialized
INFO - 2017-06-21 17:34:35 --> Controller Class Initialized
INFO - 2017-06-21 17:34:35 --> Database Driver Class Initialized
INFO - 2017-06-21 17:34:35 --> Model Class Initialized
INFO - 2017-06-21 17:34:35 --> Helper loaded: form_helper
INFO - 2017-06-21 17:34:35 --> Helper loaded: url_helper
INFO - 2017-06-21 17:34:35 --> Model Class Initialized
INFO - 2017-06-21 17:34:35 --> Final output sent to browser
DEBUG - 2017-06-21 17:34:35 --> Total execution time: 0.0450
ERROR - 2017-06-21 17:34:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:34:42 --> Config Class Initialized
INFO - 2017-06-21 17:34:42 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:34:42 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:34:42 --> Utf8 Class Initialized
INFO - 2017-06-21 17:34:42 --> URI Class Initialized
INFO - 2017-06-21 17:34:42 --> Router Class Initialized
INFO - 2017-06-21 17:34:42 --> Output Class Initialized
INFO - 2017-06-21 17:34:42 --> Security Class Initialized
DEBUG - 2017-06-21 17:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:34:42 --> Input Class Initialized
INFO - 2017-06-21 17:34:42 --> Language Class Initialized
INFO - 2017-06-21 17:34:42 --> Loader Class Initialized
INFO - 2017-06-21 17:34:42 --> Controller Class Initialized
INFO - 2017-06-21 17:34:42 --> Database Driver Class Initialized
INFO - 2017-06-21 17:34:42 --> Model Class Initialized
INFO - 2017-06-21 17:34:42 --> Helper loaded: form_helper
INFO - 2017-06-21 17:34:42 --> Helper loaded: url_helper
INFO - 2017-06-21 17:34:42 --> Model Class Initialized
INFO - 2017-06-21 17:34:42 --> Final output sent to browser
DEBUG - 2017-06-21 17:34:42 --> Total execution time: 0.0520
ERROR - 2017-06-21 17:39:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:39:49 --> Config Class Initialized
INFO - 2017-06-21 17:39:49 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:39:49 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:39:49 --> Utf8 Class Initialized
INFO - 2017-06-21 17:39:49 --> URI Class Initialized
INFO - 2017-06-21 17:39:49 --> Router Class Initialized
INFO - 2017-06-21 17:39:49 --> Output Class Initialized
INFO - 2017-06-21 17:39:49 --> Security Class Initialized
DEBUG - 2017-06-21 17:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:39:49 --> Input Class Initialized
INFO - 2017-06-21 17:39:49 --> Language Class Initialized
INFO - 2017-06-21 17:39:49 --> Loader Class Initialized
INFO - 2017-06-21 17:39:49 --> Controller Class Initialized
INFO - 2017-06-21 17:39:49 --> Database Driver Class Initialized
INFO - 2017-06-21 17:39:49 --> Model Class Initialized
INFO - 2017-06-21 17:39:49 --> Helper loaded: form_helper
INFO - 2017-06-21 17:39:49 --> Helper loaded: url_helper
INFO - 2017-06-21 17:39:49 --> Model Class Initialized
INFO - 2017-06-21 17:39:49 --> Final output sent to browser
DEBUG - 2017-06-21 17:39:49 --> Total execution time: 0.0470
ERROR - 2017-06-21 17:39:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:39:50 --> Config Class Initialized
INFO - 2017-06-21 17:39:50 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:39:50 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:39:50 --> Utf8 Class Initialized
INFO - 2017-06-21 17:39:50 --> URI Class Initialized
INFO - 2017-06-21 17:39:50 --> Router Class Initialized
INFO - 2017-06-21 17:39:50 --> Output Class Initialized
INFO - 2017-06-21 17:39:50 --> Security Class Initialized
DEBUG - 2017-06-21 17:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:39:50 --> Input Class Initialized
INFO - 2017-06-21 17:39:50 --> Language Class Initialized
INFO - 2017-06-21 17:39:50 --> Loader Class Initialized
INFO - 2017-06-21 17:39:50 --> Controller Class Initialized
INFO - 2017-06-21 17:39:50 --> Database Driver Class Initialized
INFO - 2017-06-21 17:39:50 --> Model Class Initialized
INFO - 2017-06-21 17:39:50 --> Helper loaded: form_helper
INFO - 2017-06-21 17:39:50 --> Helper loaded: url_helper
INFO - 2017-06-21 17:39:50 --> Model Class Initialized
INFO - 2017-06-21 17:39:50 --> Final output sent to browser
DEBUG - 2017-06-21 17:39:50 --> Total execution time: 0.0440
ERROR - 2017-06-21 17:40:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:40:06 --> Config Class Initialized
INFO - 2017-06-21 17:40:06 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:40:06 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:40:06 --> Utf8 Class Initialized
INFO - 2017-06-21 17:40:06 --> URI Class Initialized
INFO - 2017-06-21 17:40:06 --> Router Class Initialized
INFO - 2017-06-21 17:40:06 --> Output Class Initialized
INFO - 2017-06-21 17:40:06 --> Security Class Initialized
DEBUG - 2017-06-21 17:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:40:06 --> Input Class Initialized
INFO - 2017-06-21 17:40:06 --> Language Class Initialized
INFO - 2017-06-21 17:40:06 --> Loader Class Initialized
INFO - 2017-06-21 17:40:06 --> Controller Class Initialized
INFO - 2017-06-21 17:40:06 --> Database Driver Class Initialized
INFO - 2017-06-21 17:40:06 --> Model Class Initialized
INFO - 2017-06-21 17:40:06 --> Helper loaded: form_helper
INFO - 2017-06-21 17:40:06 --> Helper loaded: url_helper
INFO - 2017-06-21 17:40:06 --> Model Class Initialized
INFO - 2017-06-21 17:40:06 --> Final output sent to browser
DEBUG - 2017-06-21 17:40:06 --> Total execution time: 0.0470
ERROR - 2017-06-21 17:40:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-21 17:40:35 --> Config Class Initialized
INFO - 2017-06-21 17:40:35 --> Hooks Class Initialized
DEBUG - 2017-06-21 17:40:35 --> UTF-8 Support Enabled
INFO - 2017-06-21 17:40:35 --> Utf8 Class Initialized
INFO - 2017-06-21 17:40:35 --> URI Class Initialized
INFO - 2017-06-21 17:40:35 --> Router Class Initialized
INFO - 2017-06-21 17:40:35 --> Output Class Initialized
INFO - 2017-06-21 17:40:35 --> Security Class Initialized
DEBUG - 2017-06-21 17:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-21 17:40:35 --> Input Class Initialized
INFO - 2017-06-21 17:40:35 --> Language Class Initialized
INFO - 2017-06-21 17:40:35 --> Loader Class Initialized
INFO - 2017-06-21 17:40:35 --> Controller Class Initialized
INFO - 2017-06-21 17:40:35 --> Database Driver Class Initialized
INFO - 2017-06-21 17:40:35 --> Model Class Initialized
INFO - 2017-06-21 17:40:35 --> Helper loaded: form_helper
INFO - 2017-06-21 17:40:35 --> Helper loaded: url_helper
INFO - 2017-06-21 17:40:35 --> Model Class Initialized
INFO - 2017-06-21 17:40:35 --> Final output sent to browser
DEBUG - 2017-06-21 17:40:35 --> Total execution time: 0.0520
