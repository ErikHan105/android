<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-26 18:40:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-26 18:40:09 --> Config Class Initialized
INFO - 2017-07-26 18:40:09 --> Hooks Class Initialized
DEBUG - 2017-07-26 18:40:09 --> UTF-8 Support Enabled
INFO - 2017-07-26 18:40:09 --> Utf8 Class Initialized
INFO - 2017-07-26 18:40:09 --> URI Class Initialized
DEBUG - 2017-07-26 18:40:09 --> No URI present. Default controller set.
INFO - 2017-07-26 18:40:09 --> Router Class Initialized
INFO - 2017-07-26 18:40:09 --> Output Class Initialized
INFO - 2017-07-26 18:40:09 --> Security Class Initialized
DEBUG - 2017-07-26 18:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 18:40:09 --> Input Class Initialized
INFO - 2017-07-26 18:40:09 --> Language Class Initialized
INFO - 2017-07-26 18:40:09 --> Loader Class Initialized
INFO - 2017-07-26 18:40:09 --> Controller Class Initialized
INFO - 2017-07-26 18:40:09 --> Database Driver Class Initialized
INFO - 2017-07-26 18:40:09 --> Model Class Initialized
INFO - 2017-07-26 18:40:09 --> Helper loaded: form_helper
INFO - 2017-07-26 18:40:09 --> Helper loaded: url_helper
INFO - 2017-07-26 18:40:09 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-26 18:40:09 --> Final output sent to browser
DEBUG - 2017-07-26 18:40:09 --> Total execution time: 0.1640
ERROR - 2017-07-26 18:40:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-26 18:40:12 --> Config Class Initialized
INFO - 2017-07-26 18:40:12 --> Hooks Class Initialized
DEBUG - 2017-07-26 18:40:12 --> UTF-8 Support Enabled
INFO - 2017-07-26 18:40:12 --> Utf8 Class Initialized
INFO - 2017-07-26 18:40:12 --> URI Class Initialized
INFO - 2017-07-26 18:40:12 --> Router Class Initialized
INFO - 2017-07-26 18:40:12 --> Output Class Initialized
INFO - 2017-07-26 18:40:12 --> Security Class Initialized
DEBUG - 2017-07-26 18:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 18:40:12 --> Input Class Initialized
INFO - 2017-07-26 18:40:12 --> Language Class Initialized
INFO - 2017-07-26 18:40:12 --> Loader Class Initialized
INFO - 2017-07-26 18:40:12 --> Controller Class Initialized
INFO - 2017-07-26 18:40:12 --> Database Driver Class Initialized
INFO - 2017-07-26 18:40:12 --> Model Class Initialized
INFO - 2017-07-26 18:40:12 --> Helper loaded: form_helper
INFO - 2017-07-26 18:40:12 --> Helper loaded: url_helper
INFO - 2017-07-26 18:40:12 --> Model Class Initialized
ERROR - 2017-07-26 18:40:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-26 18:40:12 --> Config Class Initialized
INFO - 2017-07-26 18:40:12 --> Hooks Class Initialized
DEBUG - 2017-07-26 18:40:12 --> UTF-8 Support Enabled
INFO - 2017-07-26 18:40:12 --> Utf8 Class Initialized
INFO - 2017-07-26 18:40:12 --> URI Class Initialized
INFO - 2017-07-26 18:40:12 --> Router Class Initialized
INFO - 2017-07-26 18:40:12 --> Output Class Initialized
INFO - 2017-07-26 18:40:12 --> Security Class Initialized
DEBUG - 2017-07-26 18:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 18:40:12 --> Input Class Initialized
INFO - 2017-07-26 18:40:12 --> Language Class Initialized
INFO - 2017-07-26 18:40:12 --> Loader Class Initialized
INFO - 2017-07-26 18:40:12 --> Controller Class Initialized
INFO - 2017-07-26 18:40:12 --> Database Driver Class Initialized
INFO - 2017-07-26 18:40:12 --> Model Class Initialized
INFO - 2017-07-26 18:40:12 --> Helper loaded: form_helper
INFO - 2017-07-26 18:40:12 --> Helper loaded: url_helper
INFO - 2017-07-26 18:40:12 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-26 18:40:12 --> Model Class Initialized
INFO - 2017-07-26 18:40:12 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-26 18:40:12 --> Final output sent to browser
DEBUG - 2017-07-26 18:40:12 --> Total execution time: 0.1950
ERROR - 2017-07-26 18:40:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-26 18:40:19 --> Config Class Initialized
INFO - 2017-07-26 18:40:19 --> Hooks Class Initialized
DEBUG - 2017-07-26 18:40:19 --> UTF-8 Support Enabled
INFO - 2017-07-26 18:40:19 --> Utf8 Class Initialized
INFO - 2017-07-26 18:40:19 --> URI Class Initialized
INFO - 2017-07-26 18:40:19 --> Router Class Initialized
INFO - 2017-07-26 18:40:19 --> Output Class Initialized
INFO - 2017-07-26 18:40:19 --> Security Class Initialized
DEBUG - 2017-07-26 18:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 18:40:19 --> Input Class Initialized
INFO - 2017-07-26 18:40:19 --> Language Class Initialized
INFO - 2017-07-26 18:40:19 --> Loader Class Initialized
INFO - 2017-07-26 18:40:19 --> Controller Class Initialized
INFO - 2017-07-26 18:40:19 --> Database Driver Class Initialized
INFO - 2017-07-26 18:40:19 --> Model Class Initialized
INFO - 2017-07-26 18:40:19 --> Helper loaded: form_helper
INFO - 2017-07-26 18:40:19 --> Helper loaded: url_helper
INFO - 2017-07-26 18:40:19 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-26 18:40:19 --> Model Class Initialized
INFO - 2017-07-26 18:40:19 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-26 18:40:19 --> Final output sent to browser
DEBUG - 2017-07-26 18:40:19 --> Total execution time: 0.1050
ERROR - 2017-07-26 18:40:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-26 18:40:20 --> Config Class Initialized
INFO - 2017-07-26 18:40:20 --> Hooks Class Initialized
DEBUG - 2017-07-26 18:40:20 --> UTF-8 Support Enabled
INFO - 2017-07-26 18:40:20 --> Utf8 Class Initialized
INFO - 2017-07-26 18:40:20 --> URI Class Initialized
INFO - 2017-07-26 18:40:20 --> Router Class Initialized
INFO - 2017-07-26 18:40:20 --> Output Class Initialized
INFO - 2017-07-26 18:40:20 --> Security Class Initialized
DEBUG - 2017-07-26 18:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 18:40:20 --> Input Class Initialized
INFO - 2017-07-26 18:40:20 --> Language Class Initialized
INFO - 2017-07-26 18:40:20 --> Loader Class Initialized
INFO - 2017-07-26 18:40:20 --> Controller Class Initialized
INFO - 2017-07-26 18:40:20 --> Database Driver Class Initialized
INFO - 2017-07-26 18:40:20 --> Model Class Initialized
INFO - 2017-07-26 18:40:20 --> Helper loaded: form_helper
INFO - 2017-07-26 18:40:20 --> Helper loaded: url_helper
INFO - 2017-07-26 18:40:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-26 18:40:20 --> Model Class Initialized
INFO - 2017-07-26 18:40:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-26 18:40:20 --> Final output sent to browser
DEBUG - 2017-07-26 18:40:20 --> Total execution time: 0.2520
