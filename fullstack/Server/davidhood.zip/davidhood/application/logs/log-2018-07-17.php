<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-17 05:46:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-17 05:46:48 --> Config Class Initialized
INFO - 2018-07-17 05:46:48 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:46:48 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:46:48 --> Utf8 Class Initialized
INFO - 2018-07-17 05:46:48 --> URI Class Initialized
INFO - 2018-07-17 05:46:48 --> Router Class Initialized
INFO - 2018-07-17 05:46:48 --> Output Class Initialized
INFO - 2018-07-17 05:46:48 --> Security Class Initialized
DEBUG - 2018-07-17 05:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:46:48 --> Input Class Initialized
INFO - 2018-07-17 05:46:48 --> Language Class Initialized
INFO - 2018-07-17 05:46:48 --> Loader Class Initialized
INFO - 2018-07-17 05:46:48 --> Controller Class Initialized
INFO - 2018-07-17 05:46:48 --> Database Driver Class Initialized
INFO - 2018-07-17 05:46:48 --> Model Class Initialized
INFO - 2018-07-17 05:46:48 --> Helper loaded: url_helper
INFO - 2018-07-17 05:46:48 --> Model Class Initialized
INFO - 2018-07-17 05:46:48 --> Final output sent to browser
DEBUG - 2018-07-17 05:46:48 --> Total execution time: 0.0381
ERROR - 2018-07-17 05:46:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-17 05:46:50 --> Config Class Initialized
INFO - 2018-07-17 05:46:50 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:46:50 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:46:50 --> Utf8 Class Initialized
INFO - 2018-07-17 05:46:50 --> URI Class Initialized
INFO - 2018-07-17 05:46:50 --> Router Class Initialized
INFO - 2018-07-17 05:46:50 --> Output Class Initialized
INFO - 2018-07-17 05:46:50 --> Security Class Initialized
DEBUG - 2018-07-17 05:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:46:50 --> Input Class Initialized
INFO - 2018-07-17 05:46:50 --> Language Class Initialized
INFO - 2018-07-17 05:46:50 --> Loader Class Initialized
INFO - 2018-07-17 05:46:50 --> Controller Class Initialized
INFO - 2018-07-17 05:46:50 --> Database Driver Class Initialized
INFO - 2018-07-17 05:46:50 --> Model Class Initialized
INFO - 2018-07-17 05:46:50 --> Helper loaded: url_helper
INFO - 2018-07-17 05:46:50 --> Model Class Initialized
INFO - 2018-07-17 05:46:50 --> Final output sent to browser
DEBUG - 2018-07-17 05:46:50 --> Total execution time: 0.0370
ERROR - 2018-07-17 05:46:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-17 05:46:50 --> Config Class Initialized
INFO - 2018-07-17 05:46:50 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:46:50 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:46:50 --> Utf8 Class Initialized
INFO - 2018-07-17 05:46:50 --> URI Class Initialized
INFO - 2018-07-17 05:46:50 --> Router Class Initialized
INFO - 2018-07-17 05:46:50 --> Output Class Initialized
INFO - 2018-07-17 05:46:50 --> Security Class Initialized
DEBUG - 2018-07-17 05:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:46:50 --> Input Class Initialized
INFO - 2018-07-17 05:46:50 --> Language Class Initialized
INFO - 2018-07-17 05:46:50 --> Loader Class Initialized
INFO - 2018-07-17 05:46:50 --> Controller Class Initialized
INFO - 2018-07-17 05:46:50 --> Database Driver Class Initialized
INFO - 2018-07-17 05:46:50 --> Model Class Initialized
INFO - 2018-07-17 05:46:50 --> Helper loaded: url_helper
INFO - 2018-07-17 05:46:50 --> Model Class Initialized
INFO - 2018-07-17 05:46:50 --> Final output sent to browser
DEBUG - 2018-07-17 05:46:50 --> Total execution time: 0.0407
ERROR - 2018-07-17 05:46:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-17 05:46:50 --> Config Class Initialized
INFO - 2018-07-17 05:46:50 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:46:50 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:46:50 --> Utf8 Class Initialized
INFO - 2018-07-17 05:46:50 --> URI Class Initialized
INFO - 2018-07-17 05:46:50 --> Router Class Initialized
INFO - 2018-07-17 05:46:50 --> Output Class Initialized
INFO - 2018-07-17 05:46:50 --> Security Class Initialized
DEBUG - 2018-07-17 05:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:46:50 --> Input Class Initialized
INFO - 2018-07-17 05:46:50 --> Language Class Initialized
INFO - 2018-07-17 05:46:50 --> Loader Class Initialized
INFO - 2018-07-17 05:46:50 --> Controller Class Initialized
INFO - 2018-07-17 05:46:50 --> Database Driver Class Initialized
INFO - 2018-07-17 05:46:50 --> Model Class Initialized
INFO - 2018-07-17 05:46:50 --> Helper loaded: url_helper
INFO - 2018-07-17 05:46:50 --> Model Class Initialized
INFO - 2018-07-17 05:46:50 --> Final output sent to browser
DEBUG - 2018-07-17 05:46:50 --> Total execution time: 0.0378
ERROR - 2018-07-17 05:47:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-17 05:47:59 --> Config Class Initialized
INFO - 2018-07-17 05:47:59 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:47:59 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:47:59 --> Utf8 Class Initialized
INFO - 2018-07-17 05:47:59 --> URI Class Initialized
INFO - 2018-07-17 05:47:59 --> Router Class Initialized
INFO - 2018-07-17 05:47:59 --> Output Class Initialized
INFO - 2018-07-17 05:47:59 --> Security Class Initialized
DEBUG - 2018-07-17 05:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:47:59 --> Input Class Initialized
INFO - 2018-07-17 05:47:59 --> Language Class Initialized
INFO - 2018-07-17 05:47:59 --> Loader Class Initialized
INFO - 2018-07-17 05:47:59 --> Controller Class Initialized
INFO - 2018-07-17 05:47:59 --> Database Driver Class Initialized
INFO - 2018-07-17 05:47:59 --> Model Class Initialized
INFO - 2018-07-17 05:47:59 --> Helper loaded: url_helper
INFO - 2018-07-17 05:47:59 --> Model Class Initialized
INFO - 2018-07-17 05:47:59 --> Final output sent to browser
DEBUG - 2018-07-17 05:47:59 --> Total execution time: 0.0366
ERROR - 2018-07-17 05:48:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-17 05:48:00 --> Config Class Initialized
INFO - 2018-07-17 05:48:00 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:48:00 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:48:00 --> Utf8 Class Initialized
INFO - 2018-07-17 05:48:00 --> URI Class Initialized
INFO - 2018-07-17 05:48:00 --> Router Class Initialized
INFO - 2018-07-17 05:48:00 --> Output Class Initialized
INFO - 2018-07-17 05:48:00 --> Security Class Initialized
DEBUG - 2018-07-17 05:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:48:00 --> Input Class Initialized
INFO - 2018-07-17 05:48:00 --> Language Class Initialized
INFO - 2018-07-17 05:48:00 --> Loader Class Initialized
INFO - 2018-07-17 05:48:00 --> Controller Class Initialized
INFO - 2018-07-17 05:48:00 --> Database Driver Class Initialized
INFO - 2018-07-17 05:48:00 --> Model Class Initialized
INFO - 2018-07-17 05:48:00 --> Helper loaded: url_helper
INFO - 2018-07-17 05:48:00 --> Model Class Initialized
INFO - 2018-07-17 05:48:00 --> Final output sent to browser
DEBUG - 2018-07-17 05:48:00 --> Total execution time: 0.0376
ERROR - 2018-07-17 05:48:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-17 05:48:00 --> Config Class Initialized
INFO - 2018-07-17 05:48:00 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:48:00 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:48:00 --> Utf8 Class Initialized
INFO - 2018-07-17 05:48:00 --> URI Class Initialized
INFO - 2018-07-17 05:48:00 --> Router Class Initialized
INFO - 2018-07-17 05:48:00 --> Output Class Initialized
INFO - 2018-07-17 05:48:00 --> Security Class Initialized
DEBUG - 2018-07-17 05:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:48:00 --> Input Class Initialized
INFO - 2018-07-17 05:48:00 --> Language Class Initialized
INFO - 2018-07-17 05:48:00 --> Loader Class Initialized
INFO - 2018-07-17 05:48:00 --> Controller Class Initialized
INFO - 2018-07-17 05:48:00 --> Database Driver Class Initialized
INFO - 2018-07-17 05:48:00 --> Model Class Initialized
INFO - 2018-07-17 05:48:00 --> Helper loaded: url_helper
INFO - 2018-07-17 05:48:00 --> Model Class Initialized
INFO - 2018-07-17 05:48:00 --> Final output sent to browser
DEBUG - 2018-07-17 05:48:00 --> Total execution time: 0.0398
ERROR - 2018-07-17 05:48:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-17 05:48:00 --> Config Class Initialized
INFO - 2018-07-17 05:48:00 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:48:00 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:48:00 --> Utf8 Class Initialized
INFO - 2018-07-17 05:48:00 --> URI Class Initialized
INFO - 2018-07-17 05:48:00 --> Router Class Initialized
INFO - 2018-07-17 05:48:00 --> Output Class Initialized
INFO - 2018-07-17 05:48:00 --> Security Class Initialized
DEBUG - 2018-07-17 05:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:48:00 --> Input Class Initialized
INFO - 2018-07-17 05:48:00 --> Language Class Initialized
INFO - 2018-07-17 05:48:00 --> Loader Class Initialized
INFO - 2018-07-17 05:48:00 --> Controller Class Initialized
INFO - 2018-07-17 05:48:00 --> Database Driver Class Initialized
INFO - 2018-07-17 05:48:00 --> Model Class Initialized
INFO - 2018-07-17 05:48:00 --> Helper loaded: url_helper
INFO - 2018-07-17 05:48:00 --> Model Class Initialized
INFO - 2018-07-17 05:48:00 --> Final output sent to browser
DEBUG - 2018-07-17 05:48:00 --> Total execution time: 0.0386
ERROR - 2018-07-17 05:50:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-17 05:50:36 --> Config Class Initialized
INFO - 2018-07-17 05:50:36 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:50:36 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:50:36 --> Utf8 Class Initialized
INFO - 2018-07-17 05:50:36 --> URI Class Initialized
INFO - 2018-07-17 05:50:36 --> Router Class Initialized
INFO - 2018-07-17 05:50:36 --> Output Class Initialized
INFO - 2018-07-17 05:50:36 --> Security Class Initialized
DEBUG - 2018-07-17 05:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:50:36 --> Input Class Initialized
INFO - 2018-07-17 05:50:36 --> Language Class Initialized
INFO - 2018-07-17 05:50:36 --> Loader Class Initialized
INFO - 2018-07-17 05:50:36 --> Controller Class Initialized
INFO - 2018-07-17 05:50:36 --> Database Driver Class Initialized
INFO - 2018-07-17 05:50:36 --> Model Class Initialized
INFO - 2018-07-17 05:50:36 --> Helper loaded: url_helper
INFO - 2018-07-17 05:50:36 --> Model Class Initialized
ERROR - 2018-07-17 05:50:37 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 74
INFO - 2018-07-17 05:50:37 --> Final output sent to browser
DEBUG - 2018-07-17 05:50:37 --> Total execution time: 1.0707
ERROR - 2018-07-17 05:54:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-17 05:54:00 --> Config Class Initialized
INFO - 2018-07-17 05:54:00 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:54:00 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:54:00 --> Utf8 Class Initialized
INFO - 2018-07-17 05:54:00 --> URI Class Initialized
INFO - 2018-07-17 05:54:00 --> Router Class Initialized
INFO - 2018-07-17 05:54:00 --> Output Class Initialized
INFO - 2018-07-17 05:54:00 --> Security Class Initialized
DEBUG - 2018-07-17 05:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:54:00 --> Input Class Initialized
INFO - 2018-07-17 05:54:00 --> Language Class Initialized
INFO - 2018-07-17 05:54:00 --> Loader Class Initialized
INFO - 2018-07-17 05:54:00 --> Controller Class Initialized
INFO - 2018-07-17 05:54:00 --> Database Driver Class Initialized
INFO - 2018-07-17 05:54:00 --> Model Class Initialized
INFO - 2018-07-17 05:54:00 --> Helper loaded: url_helper
INFO - 2018-07-17 05:54:00 --> Model Class Initialized
INFO - 2018-07-17 05:54:00 --> Final output sent to browser
DEBUG - 2018-07-17 05:54:00 --> Total execution time: 0.0464
ERROR - 2018-07-17 05:54:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-17 05:54:01 --> Config Class Initialized
INFO - 2018-07-17 05:54:01 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:54:01 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:54:01 --> Utf8 Class Initialized
INFO - 2018-07-17 05:54:01 --> URI Class Initialized
INFO - 2018-07-17 05:54:01 --> Router Class Initialized
INFO - 2018-07-17 05:54:01 --> Output Class Initialized
INFO - 2018-07-17 05:54:01 --> Security Class Initialized
DEBUG - 2018-07-17 05:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:54:01 --> Input Class Initialized
INFO - 2018-07-17 05:54:01 --> Language Class Initialized
INFO - 2018-07-17 05:54:01 --> Loader Class Initialized
INFO - 2018-07-17 05:54:01 --> Controller Class Initialized
INFO - 2018-07-17 05:54:01 --> Database Driver Class Initialized
INFO - 2018-07-17 05:54:01 --> Model Class Initialized
INFO - 2018-07-17 05:54:01 --> Helper loaded: url_helper
INFO - 2018-07-17 05:54:01 --> Model Class Initialized
INFO - 2018-07-17 05:54:01 --> Final output sent to browser
DEBUG - 2018-07-17 05:54:01 --> Total execution time: 0.0409
ERROR - 2018-07-17 05:54:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-17 05:54:01 --> Config Class Initialized
INFO - 2018-07-17 05:54:01 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:54:01 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:54:01 --> Utf8 Class Initialized
INFO - 2018-07-17 05:54:01 --> URI Class Initialized
INFO - 2018-07-17 05:54:01 --> Router Class Initialized
INFO - 2018-07-17 05:54:01 --> Output Class Initialized
INFO - 2018-07-17 05:54:01 --> Security Class Initialized
DEBUG - 2018-07-17 05:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:54:01 --> Input Class Initialized
INFO - 2018-07-17 05:54:01 --> Language Class Initialized
INFO - 2018-07-17 05:54:01 --> Loader Class Initialized
INFO - 2018-07-17 05:54:01 --> Controller Class Initialized
INFO - 2018-07-17 05:54:01 --> Database Driver Class Initialized
INFO - 2018-07-17 05:54:01 --> Model Class Initialized
INFO - 2018-07-17 05:54:01 --> Helper loaded: url_helper
INFO - 2018-07-17 05:54:01 --> Model Class Initialized
INFO - 2018-07-17 05:54:01 --> Final output sent to browser
DEBUG - 2018-07-17 05:54:01 --> Total execution time: 0.0411
ERROR - 2018-07-17 05:54:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-17 05:54:01 --> Config Class Initialized
INFO - 2018-07-17 05:54:01 --> Hooks Class Initialized
DEBUG - 2018-07-17 05:54:01 --> UTF-8 Support Enabled
INFO - 2018-07-17 05:54:01 --> Utf8 Class Initialized
INFO - 2018-07-17 05:54:01 --> URI Class Initialized
INFO - 2018-07-17 05:54:01 --> Router Class Initialized
INFO - 2018-07-17 05:54:01 --> Output Class Initialized
INFO - 2018-07-17 05:54:01 --> Security Class Initialized
DEBUG - 2018-07-17 05:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 05:54:01 --> Input Class Initialized
INFO - 2018-07-17 05:54:01 --> Language Class Initialized
INFO - 2018-07-17 05:54:01 --> Loader Class Initialized
INFO - 2018-07-17 05:54:01 --> Controller Class Initialized
INFO - 2018-07-17 05:54:01 --> Database Driver Class Initialized
INFO - 2018-07-17 05:54:01 --> Model Class Initialized
INFO - 2018-07-17 05:54:01 --> Helper loaded: url_helper
INFO - 2018-07-17 05:54:01 --> Model Class Initialized
INFO - 2018-07-17 05:54:01 --> Final output sent to browser
DEBUG - 2018-07-17 05:54:01 --> Total execution time: 0.0381
ERROR - 2018-07-17 06:39:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-17 06:39:03 --> Config Class Initialized
INFO - 2018-07-17 06:39:03 --> Hooks Class Initialized
DEBUG - 2018-07-17 06:39:03 --> UTF-8 Support Enabled
INFO - 2018-07-17 06:39:03 --> Utf8 Class Initialized
INFO - 2018-07-17 06:39:03 --> URI Class Initialized
INFO - 2018-07-17 06:39:03 --> Router Class Initialized
INFO - 2018-07-17 06:39:03 --> Output Class Initialized
INFO - 2018-07-17 06:39:03 --> Security Class Initialized
DEBUG - 2018-07-17 06:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 06:39:03 --> Input Class Initialized
INFO - 2018-07-17 06:39:03 --> Language Class Initialized
INFO - 2018-07-17 06:39:03 --> Loader Class Initialized
INFO - 2018-07-17 06:39:03 --> Controller Class Initialized
INFO - 2018-07-17 06:39:03 --> Database Driver Class Initialized
INFO - 2018-07-17 06:39:03 --> Model Class Initialized
INFO - 2018-07-17 06:39:03 --> Helper loaded: url_helper
INFO - 2018-07-17 06:39:03 --> Model Class Initialized
INFO - 2018-07-17 06:39:03 --> Final output sent to browser
DEBUG - 2018-07-17 06:39:03 --> Total execution time: 0.0519
ERROR - 2018-07-17 06:39:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-17 06:39:04 --> Config Class Initialized
INFO - 2018-07-17 06:39:04 --> Hooks Class Initialized
DEBUG - 2018-07-17 06:39:04 --> UTF-8 Support Enabled
INFO - 2018-07-17 06:39:04 --> Utf8 Class Initialized
INFO - 2018-07-17 06:39:04 --> URI Class Initialized
INFO - 2018-07-17 06:39:04 --> Router Class Initialized
INFO - 2018-07-17 06:39:04 --> Output Class Initialized
INFO - 2018-07-17 06:39:04 --> Security Class Initialized
DEBUG - 2018-07-17 06:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 06:39:04 --> Input Class Initialized
INFO - 2018-07-17 06:39:04 --> Language Class Initialized
INFO - 2018-07-17 06:39:04 --> Loader Class Initialized
INFO - 2018-07-17 06:39:04 --> Controller Class Initialized
INFO - 2018-07-17 06:39:04 --> Database Driver Class Initialized
INFO - 2018-07-17 06:39:04 --> Model Class Initialized
INFO - 2018-07-17 06:39:04 --> Helper loaded: url_helper
INFO - 2018-07-17 06:39:04 --> Model Class Initialized
INFO - 2018-07-17 06:39:04 --> Final output sent to browser
DEBUG - 2018-07-17 06:39:04 --> Total execution time: 0.0646
ERROR - 2018-07-17 06:39:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-17 06:39:04 --> Config Class Initialized
INFO - 2018-07-17 06:39:04 --> Hooks Class Initialized
DEBUG - 2018-07-17 06:39:04 --> UTF-8 Support Enabled
INFO - 2018-07-17 06:39:04 --> Utf8 Class Initialized
INFO - 2018-07-17 06:39:04 --> URI Class Initialized
INFO - 2018-07-17 06:39:04 --> Router Class Initialized
INFO - 2018-07-17 06:39:04 --> Output Class Initialized
INFO - 2018-07-17 06:39:04 --> Security Class Initialized
DEBUG - 2018-07-17 06:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 06:39:04 --> Input Class Initialized
INFO - 2018-07-17 06:39:04 --> Language Class Initialized
INFO - 2018-07-17 06:39:04 --> Loader Class Initialized
INFO - 2018-07-17 06:39:04 --> Controller Class Initialized
INFO - 2018-07-17 06:39:04 --> Database Driver Class Initialized
INFO - 2018-07-17 06:39:04 --> Model Class Initialized
INFO - 2018-07-17 06:39:04 --> Helper loaded: url_helper
INFO - 2018-07-17 06:39:04 --> Model Class Initialized
INFO - 2018-07-17 06:39:04 --> Final output sent to browser
DEBUG - 2018-07-17 06:39:04 --> Total execution time: 0.0572
ERROR - 2018-07-17 06:39:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-17 06:39:21 --> Config Class Initialized
INFO - 2018-07-17 06:39:21 --> Hooks Class Initialized
DEBUG - 2018-07-17 06:39:21 --> UTF-8 Support Enabled
INFO - 2018-07-17 06:39:21 --> Utf8 Class Initialized
INFO - 2018-07-17 06:39:21 --> URI Class Initialized
INFO - 2018-07-17 06:39:21 --> Router Class Initialized
INFO - 2018-07-17 06:39:21 --> Output Class Initialized
INFO - 2018-07-17 06:39:21 --> Security Class Initialized
DEBUG - 2018-07-17 06:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-17 06:39:21 --> Input Class Initialized
INFO - 2018-07-17 06:39:21 --> Language Class Initialized
INFO - 2018-07-17 06:39:21 --> Loader Class Initialized
INFO - 2018-07-17 06:39:21 --> Controller Class Initialized
INFO - 2018-07-17 06:39:21 --> Database Driver Class Initialized
INFO - 2018-07-17 06:39:21 --> Model Class Initialized
INFO - 2018-07-17 06:39:21 --> Helper loaded: url_helper
INFO - 2018-07-17 06:39:21 --> Model Class Initialized
INFO - 2018-07-17 06:39:21 --> Final output sent to browser
DEBUG - 2018-07-17 06:39:21 --> Total execution time: 0.0719
