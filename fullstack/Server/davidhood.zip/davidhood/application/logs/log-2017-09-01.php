<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-01 11:24:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-01 11:24:42 --> Config Class Initialized
INFO - 2017-09-01 11:24:42 --> Hooks Class Initialized
DEBUG - 2017-09-01 11:24:42 --> UTF-8 Support Enabled
INFO - 2017-09-01 11:24:42 --> Utf8 Class Initialized
INFO - 2017-09-01 11:24:42 --> URI Class Initialized
DEBUG - 2017-09-01 11:24:42 --> No URI present. Default controller set.
INFO - 2017-09-01 11:24:42 --> Router Class Initialized
INFO - 2017-09-01 11:24:42 --> Output Class Initialized
INFO - 2017-09-01 11:24:42 --> Security Class Initialized
DEBUG - 2017-09-01 11:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-01 11:24:42 --> Input Class Initialized
INFO - 2017-09-01 11:24:42 --> Language Class Initialized
INFO - 2017-09-01 11:24:42 --> Loader Class Initialized
INFO - 2017-09-01 11:24:42 --> Controller Class Initialized
INFO - 2017-09-01 11:24:42 --> Database Driver Class Initialized
INFO - 2017-09-01 11:24:42 --> Model Class Initialized
INFO - 2017-09-01 11:24:42 --> Helper loaded: form_helper
INFO - 2017-09-01 11:24:42 --> Helper loaded: url_helper
INFO - 2017-09-01 11:24:42 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-09-01 11:24:42 --> Final output sent to browser
DEBUG - 2017-09-01 11:24:42 --> Total execution time: 0.3600
ERROR - 2017-09-01 11:24:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-01 11:24:56 --> Config Class Initialized
INFO - 2017-09-01 11:24:56 --> Hooks Class Initialized
DEBUG - 2017-09-01 11:24:56 --> UTF-8 Support Enabled
INFO - 2017-09-01 11:24:56 --> Utf8 Class Initialized
INFO - 2017-09-01 11:24:56 --> URI Class Initialized
INFO - 2017-09-01 11:24:56 --> Router Class Initialized
INFO - 2017-09-01 11:24:56 --> Output Class Initialized
INFO - 2017-09-01 11:24:56 --> Security Class Initialized
DEBUG - 2017-09-01 11:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-01 11:24:56 --> Input Class Initialized
INFO - 2017-09-01 11:24:56 --> Language Class Initialized
INFO - 2017-09-01 11:24:56 --> Loader Class Initialized
INFO - 2017-09-01 11:24:56 --> Controller Class Initialized
INFO - 2017-09-01 11:24:56 --> Database Driver Class Initialized
INFO - 2017-09-01 11:24:56 --> Model Class Initialized
INFO - 2017-09-01 11:24:56 --> Helper loaded: form_helper
INFO - 2017-09-01 11:24:56 --> Helper loaded: url_helper
INFO - 2017-09-01 11:24:56 --> Model Class Initialized
ERROR - 2017-09-01 11:24:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-01 11:24:56 --> Config Class Initialized
INFO - 2017-09-01 11:24:56 --> Hooks Class Initialized
DEBUG - 2017-09-01 11:24:56 --> UTF-8 Support Enabled
INFO - 2017-09-01 11:24:56 --> Utf8 Class Initialized
INFO - 2017-09-01 11:24:56 --> URI Class Initialized
INFO - 2017-09-01 11:24:56 --> Router Class Initialized
INFO - 2017-09-01 11:24:56 --> Output Class Initialized
INFO - 2017-09-01 11:24:56 --> Security Class Initialized
DEBUG - 2017-09-01 11:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-01 11:24:57 --> Input Class Initialized
INFO - 2017-09-01 11:24:57 --> Language Class Initialized
INFO - 2017-09-01 11:24:57 --> Loader Class Initialized
INFO - 2017-09-01 11:24:57 --> Controller Class Initialized
INFO - 2017-09-01 11:24:57 --> Database Driver Class Initialized
INFO - 2017-09-01 11:24:57 --> Model Class Initialized
INFO - 2017-09-01 11:24:57 --> Helper loaded: form_helper
INFO - 2017-09-01 11:24:57 --> Helper loaded: url_helper
INFO - 2017-09-01 11:24:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-09-01 11:24:57 --> Model Class Initialized
INFO - 2017-09-01 11:24:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-09-01 11:24:57 --> Final output sent to browser
DEBUG - 2017-09-01 11:24:57 --> Total execution time: 0.2580
ERROR - 2017-09-01 11:25:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-01 11:25:12 --> Config Class Initialized
INFO - 2017-09-01 11:25:12 --> Hooks Class Initialized
DEBUG - 2017-09-01 11:25:12 --> UTF-8 Support Enabled
INFO - 2017-09-01 11:25:12 --> Utf8 Class Initialized
INFO - 2017-09-01 11:25:12 --> URI Class Initialized
INFO - 2017-09-01 11:25:12 --> Router Class Initialized
INFO - 2017-09-01 11:25:12 --> Output Class Initialized
INFO - 2017-09-01 11:25:12 --> Security Class Initialized
DEBUG - 2017-09-01 11:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-01 11:25:12 --> Input Class Initialized
INFO - 2017-09-01 11:25:12 --> Language Class Initialized
INFO - 2017-09-01 11:25:12 --> Loader Class Initialized
INFO - 2017-09-01 11:25:12 --> Controller Class Initialized
INFO - 2017-09-01 11:25:12 --> Database Driver Class Initialized
INFO - 2017-09-01 11:25:12 --> Model Class Initialized
INFO - 2017-09-01 11:25:12 --> Helper loaded: form_helper
INFO - 2017-09-01 11:25:12 --> Helper loaded: url_helper
INFO - 2017-09-01 11:25:12 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-09-01 11:25:12 --> Model Class Initialized
INFO - 2017-09-01 11:25:12 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-09-01 11:25:12 --> Final output sent to browser
DEBUG - 2017-09-01 11:25:12 --> Total execution time: 0.1180
ERROR - 2017-09-01 11:25:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-01 11:25:41 --> Config Class Initialized
INFO - 2017-09-01 11:25:41 --> Hooks Class Initialized
DEBUG - 2017-09-01 11:25:41 --> UTF-8 Support Enabled
INFO - 2017-09-01 11:25:41 --> Utf8 Class Initialized
INFO - 2017-09-01 11:25:41 --> URI Class Initialized
INFO - 2017-09-01 11:25:41 --> Router Class Initialized
INFO - 2017-09-01 11:25:41 --> Output Class Initialized
INFO - 2017-09-01 11:25:41 --> Security Class Initialized
DEBUG - 2017-09-01 11:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-01 11:25:41 --> Input Class Initialized
INFO - 2017-09-01 11:25:41 --> Language Class Initialized
INFO - 2017-09-01 11:25:41 --> Loader Class Initialized
INFO - 2017-09-01 11:25:41 --> Controller Class Initialized
INFO - 2017-09-01 11:25:41 --> Database Driver Class Initialized
INFO - 2017-09-01 11:25:41 --> Model Class Initialized
INFO - 2017-09-01 11:25:41 --> Helper loaded: form_helper
INFO - 2017-09-01 11:25:41 --> Helper loaded: url_helper
INFO - 2017-09-01 11:25:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-09-01 11:25:41 --> Model Class Initialized
INFO - 2017-09-01 11:25:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-09-01 11:25:41 --> Final output sent to browser
DEBUG - 2017-09-01 11:25:41 --> Total execution time: 0.2170
ERROR - 2017-09-01 11:36:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-01 11:36:06 --> Config Class Initialized
INFO - 2017-09-01 11:36:06 --> Hooks Class Initialized
DEBUG - 2017-09-01 11:36:06 --> UTF-8 Support Enabled
INFO - 2017-09-01 11:36:06 --> Utf8 Class Initialized
INFO - 2017-09-01 11:36:06 --> URI Class Initialized
INFO - 2017-09-01 11:36:06 --> Router Class Initialized
INFO - 2017-09-01 11:36:06 --> Output Class Initialized
INFO - 2017-09-01 11:36:06 --> Security Class Initialized
DEBUG - 2017-09-01 11:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-01 11:36:06 --> Input Class Initialized
INFO - 2017-09-01 11:36:06 --> Language Class Initialized
INFO - 2017-09-01 11:36:06 --> Loader Class Initialized
INFO - 2017-09-01 11:36:06 --> Controller Class Initialized
INFO - 2017-09-01 11:36:06 --> Database Driver Class Initialized
INFO - 2017-09-01 11:36:06 --> Model Class Initialized
INFO - 2017-09-01 11:36:06 --> Helper loaded: form_helper
INFO - 2017-09-01 11:36:06 --> Helper loaded: url_helper
INFO - 2017-09-01 11:36:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-09-01 11:36:06 --> Model Class Initialized
INFO - 2017-09-01 11:36:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-09-01 11:36:06 --> Final output sent to browser
DEBUG - 2017-09-01 11:36:06 --> Total execution time: 0.0610
