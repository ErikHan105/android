<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-19 16:51:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 16:51:18 --> Config Class Initialized
INFO - 2017-06-19 16:51:18 --> Hooks Class Initialized
DEBUG - 2017-06-19 16:51:18 --> UTF-8 Support Enabled
INFO - 2017-06-19 16:51:18 --> Utf8 Class Initialized
INFO - 2017-06-19 16:51:18 --> URI Class Initialized
DEBUG - 2017-06-19 16:51:18 --> No URI present. Default controller set.
INFO - 2017-06-19 16:51:18 --> Router Class Initialized
INFO - 2017-06-19 16:51:18 --> Output Class Initialized
INFO - 2017-06-19 16:51:18 --> Security Class Initialized
DEBUG - 2017-06-19 16:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 16:51:18 --> Input Class Initialized
INFO - 2017-06-19 16:51:18 --> Language Class Initialized
INFO - 2017-06-19 16:51:18 --> Loader Class Initialized
INFO - 2017-06-19 16:51:18 --> Controller Class Initialized
INFO - 2017-06-19 16:51:18 --> Database Driver Class Initialized
INFO - 2017-06-19 16:51:18 --> Model Class Initialized
INFO - 2017-06-19 16:51:18 --> Helper loaded: form_helper
INFO - 2017-06-19 16:51:18 --> Helper loaded: url_helper
INFO - 2017-06-19 16:51:18 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-06-19 16:51:18 --> Final output sent to browser
DEBUG - 2017-06-19 16:51:18 --> Total execution time: 0.1630
ERROR - 2017-06-19 16:51:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 16:51:19 --> Config Class Initialized
INFO - 2017-06-19 16:51:19 --> Hooks Class Initialized
DEBUG - 2017-06-19 16:51:19 --> UTF-8 Support Enabled
INFO - 2017-06-19 16:51:19 --> Utf8 Class Initialized
INFO - 2017-06-19 16:51:20 --> URI Class Initialized
INFO - 2017-06-19 16:51:20 --> Router Class Initialized
INFO - 2017-06-19 16:51:20 --> Output Class Initialized
INFO - 2017-06-19 16:51:20 --> Security Class Initialized
DEBUG - 2017-06-19 16:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 16:51:20 --> Input Class Initialized
INFO - 2017-06-19 16:51:20 --> Language Class Initialized
INFO - 2017-06-19 16:51:20 --> Loader Class Initialized
INFO - 2017-06-19 16:51:20 --> Controller Class Initialized
INFO - 2017-06-19 16:51:20 --> Database Driver Class Initialized
INFO - 2017-06-19 16:51:20 --> Model Class Initialized
INFO - 2017-06-19 16:51:20 --> Helper loaded: form_helper
INFO - 2017-06-19 16:51:20 --> Helper loaded: url_helper
INFO - 2017-06-19 16:51:20 --> Model Class Initialized
ERROR - 2017-06-19 16:51:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 16:51:20 --> Config Class Initialized
INFO - 2017-06-19 16:51:20 --> Hooks Class Initialized
DEBUG - 2017-06-19 16:51:20 --> UTF-8 Support Enabled
INFO - 2017-06-19 16:51:20 --> Utf8 Class Initialized
INFO - 2017-06-19 16:51:20 --> URI Class Initialized
INFO - 2017-06-19 16:51:20 --> Router Class Initialized
INFO - 2017-06-19 16:51:20 --> Output Class Initialized
INFO - 2017-06-19 16:51:20 --> Security Class Initialized
DEBUG - 2017-06-19 16:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 16:51:20 --> Input Class Initialized
INFO - 2017-06-19 16:51:20 --> Language Class Initialized
INFO - 2017-06-19 16:51:20 --> Loader Class Initialized
INFO - 2017-06-19 16:51:20 --> Controller Class Initialized
INFO - 2017-06-19 16:51:20 --> Database Driver Class Initialized
INFO - 2017-06-19 16:51:20 --> Model Class Initialized
INFO - 2017-06-19 16:51:20 --> Helper loaded: form_helper
INFO - 2017-06-19 16:51:20 --> Helper loaded: url_helper
INFO - 2017-06-19 16:51:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 16:51:20 --> Model Class Initialized
INFO - 2017-06-19 16:51:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-19 16:51:20 --> Final output sent to browser
DEBUG - 2017-06-19 16:51:20 --> Total execution time: 0.1410
ERROR - 2017-06-19 16:51:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 16:51:24 --> Config Class Initialized
INFO - 2017-06-19 16:51:24 --> Hooks Class Initialized
DEBUG - 2017-06-19 16:51:24 --> UTF-8 Support Enabled
INFO - 2017-06-19 16:51:24 --> Utf8 Class Initialized
INFO - 2017-06-19 16:51:24 --> URI Class Initialized
INFO - 2017-06-19 16:51:24 --> Router Class Initialized
INFO - 2017-06-19 16:51:24 --> Output Class Initialized
INFO - 2017-06-19 16:51:24 --> Security Class Initialized
DEBUG - 2017-06-19 16:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 16:51:24 --> Input Class Initialized
INFO - 2017-06-19 16:51:24 --> Language Class Initialized
INFO - 2017-06-19 16:51:24 --> Loader Class Initialized
INFO - 2017-06-19 16:51:24 --> Controller Class Initialized
INFO - 2017-06-19 16:51:24 --> Database Driver Class Initialized
INFO - 2017-06-19 16:51:24 --> Model Class Initialized
INFO - 2017-06-19 16:51:24 --> Helper loaded: form_helper
INFO - 2017-06-19 16:51:24 --> Helper loaded: url_helper
INFO - 2017-06-19 16:51:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 16:51:24 --> Model Class Initialized
INFO - 2017-06-19 16:51:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 16:51:24 --> Final output sent to browser
DEBUG - 2017-06-19 16:51:24 --> Total execution time: 0.0950
ERROR - 2017-06-19 16:51:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 16:51:43 --> Config Class Initialized
INFO - 2017-06-19 16:51:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 16:51:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 16:51:43 --> Utf8 Class Initialized
INFO - 2017-06-19 16:51:43 --> URI Class Initialized
INFO - 2017-06-19 16:51:43 --> Router Class Initialized
INFO - 2017-06-19 16:51:43 --> Output Class Initialized
INFO - 2017-06-19 16:51:43 --> Security Class Initialized
DEBUG - 2017-06-19 16:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 16:51:43 --> Input Class Initialized
INFO - 2017-06-19 16:51:43 --> Language Class Initialized
INFO - 2017-06-19 16:51:43 --> Loader Class Initialized
INFO - 2017-06-19 16:51:43 --> Controller Class Initialized
INFO - 2017-06-19 16:51:43 --> Database Driver Class Initialized
INFO - 2017-06-19 16:51:43 --> Model Class Initialized
INFO - 2017-06-19 16:51:43 --> Helper loaded: form_helper
INFO - 2017-06-19 16:51:43 --> Helper loaded: url_helper
ERROR - 2017-06-19 16:51:44 --> Severity: Notice --> Undefined index: input_track_file C:\xampp\htdocs\mystage\application\controllers\Services.php 266
INFO - 2017-06-19 16:51:44 --> Final output sent to browser
DEBUG - 2017-06-19 16:51:44 --> Total execution time: 0.1680
ERROR - 2017-06-19 16:52:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 16:52:53 --> Config Class Initialized
INFO - 2017-06-19 16:52:53 --> Hooks Class Initialized
DEBUG - 2017-06-19 16:52:53 --> UTF-8 Support Enabled
INFO - 2017-06-19 16:52:53 --> Utf8 Class Initialized
INFO - 2017-06-19 16:52:53 --> URI Class Initialized
INFO - 2017-06-19 16:52:53 --> Router Class Initialized
INFO - 2017-06-19 16:52:53 --> Output Class Initialized
INFO - 2017-06-19 16:52:53 --> Security Class Initialized
DEBUG - 2017-06-19 16:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 16:52:53 --> Input Class Initialized
INFO - 2017-06-19 16:52:53 --> Language Class Initialized
INFO - 2017-06-19 16:52:53 --> Loader Class Initialized
INFO - 2017-06-19 16:52:53 --> Controller Class Initialized
INFO - 2017-06-19 16:52:53 --> Database Driver Class Initialized
INFO - 2017-06-19 16:52:53 --> Model Class Initialized
INFO - 2017-06-19 16:52:53 --> Helper loaded: form_helper
INFO - 2017-06-19 16:52:53 --> Helper loaded: url_helper
INFO - 2017-06-19 16:52:53 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 16:52:53 --> Model Class Initialized
INFO - 2017-06-19 16:52:53 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 16:52:53 --> Final output sent to browser
DEBUG - 2017-06-19 16:52:53 --> Total execution time: 0.0440
ERROR - 2017-06-19 16:52:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 16:52:58 --> Config Class Initialized
INFO - 2017-06-19 16:52:58 --> Hooks Class Initialized
DEBUG - 2017-06-19 16:52:58 --> UTF-8 Support Enabled
INFO - 2017-06-19 16:52:58 --> Utf8 Class Initialized
INFO - 2017-06-19 16:52:58 --> URI Class Initialized
INFO - 2017-06-19 16:52:58 --> Router Class Initialized
INFO - 2017-06-19 16:52:58 --> Output Class Initialized
INFO - 2017-06-19 16:52:58 --> Security Class Initialized
DEBUG - 2017-06-19 16:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 16:52:58 --> Input Class Initialized
INFO - 2017-06-19 16:52:58 --> Language Class Initialized
INFO - 2017-06-19 16:52:58 --> Loader Class Initialized
INFO - 2017-06-19 16:52:58 --> Controller Class Initialized
INFO - 2017-06-19 16:52:58 --> Database Driver Class Initialized
INFO - 2017-06-19 16:52:58 --> Model Class Initialized
INFO - 2017-06-19 16:52:58 --> Helper loaded: form_helper
INFO - 2017-06-19 16:52:58 --> Helper loaded: url_helper
ERROR - 2017-06-19 16:52:58 --> Severity: Notice --> Undefined index: input_track_file C:\xampp\htdocs\mystage\application\controllers\Services.php 266
INFO - 2017-06-19 16:52:58 --> Final output sent to browser
DEBUG - 2017-06-19 16:52:58 --> Total execution time: 0.0800
ERROR - 2017-06-19 16:53:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 16:53:08 --> Config Class Initialized
INFO - 2017-06-19 16:53:08 --> Hooks Class Initialized
DEBUG - 2017-06-19 16:53:08 --> UTF-8 Support Enabled
INFO - 2017-06-19 16:53:08 --> Utf8 Class Initialized
INFO - 2017-06-19 16:53:08 --> URI Class Initialized
INFO - 2017-06-19 16:53:08 --> Router Class Initialized
INFO - 2017-06-19 16:53:08 --> Output Class Initialized
INFO - 2017-06-19 16:53:08 --> Security Class Initialized
DEBUG - 2017-06-19 16:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 16:53:08 --> Input Class Initialized
INFO - 2017-06-19 16:53:08 --> Language Class Initialized
INFO - 2017-06-19 16:53:08 --> Loader Class Initialized
INFO - 2017-06-19 16:53:08 --> Controller Class Initialized
INFO - 2017-06-19 16:53:08 --> Database Driver Class Initialized
INFO - 2017-06-19 16:53:08 --> Model Class Initialized
INFO - 2017-06-19 16:53:08 --> Helper loaded: form_helper
INFO - 2017-06-19 16:53:08 --> Helper loaded: url_helper
INFO - 2017-06-19 16:53:08 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 16:53:08 --> Model Class Initialized
INFO - 2017-06-19 16:53:08 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 16:53:08 --> Final output sent to browser
DEBUG - 2017-06-19 16:53:08 --> Total execution time: 0.0490
ERROR - 2017-06-19 16:53:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 16:53:09 --> Config Class Initialized
INFO - 2017-06-19 16:53:09 --> Hooks Class Initialized
DEBUG - 2017-06-19 16:53:09 --> UTF-8 Support Enabled
INFO - 2017-06-19 16:53:09 --> Utf8 Class Initialized
INFO - 2017-06-19 16:53:09 --> URI Class Initialized
INFO - 2017-06-19 16:53:09 --> Router Class Initialized
INFO - 2017-06-19 16:53:09 --> Output Class Initialized
INFO - 2017-06-19 16:53:09 --> Security Class Initialized
DEBUG - 2017-06-19 16:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 16:53:09 --> Input Class Initialized
INFO - 2017-06-19 16:53:09 --> Language Class Initialized
INFO - 2017-06-19 16:53:09 --> Loader Class Initialized
INFO - 2017-06-19 16:53:09 --> Controller Class Initialized
INFO - 2017-06-19 16:53:09 --> Database Driver Class Initialized
INFO - 2017-06-19 16:53:09 --> Model Class Initialized
INFO - 2017-06-19 16:53:09 --> Helper loaded: form_helper
INFO - 2017-06-19 16:53:09 --> Helper loaded: url_helper
INFO - 2017-06-19 16:53:09 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 16:53:09 --> Model Class Initialized
INFO - 2017-06-19 16:53:09 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 16:53:09 --> Final output sent to browser
DEBUG - 2017-06-19 16:53:09 --> Total execution time: 0.1130
ERROR - 2017-06-19 16:53:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 16:53:10 --> Config Class Initialized
INFO - 2017-06-19 16:53:10 --> Hooks Class Initialized
DEBUG - 2017-06-19 16:53:10 --> UTF-8 Support Enabled
INFO - 2017-06-19 16:53:10 --> Utf8 Class Initialized
INFO - 2017-06-19 16:53:10 --> URI Class Initialized
INFO - 2017-06-19 16:53:10 --> Router Class Initialized
INFO - 2017-06-19 16:53:10 --> Output Class Initialized
INFO - 2017-06-19 16:53:10 --> Security Class Initialized
DEBUG - 2017-06-19 16:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 16:53:10 --> Input Class Initialized
INFO - 2017-06-19 16:53:10 --> Language Class Initialized
INFO - 2017-06-19 16:53:10 --> Loader Class Initialized
INFO - 2017-06-19 16:53:10 --> Controller Class Initialized
INFO - 2017-06-19 16:53:10 --> Database Driver Class Initialized
INFO - 2017-06-19 16:53:10 --> Model Class Initialized
INFO - 2017-06-19 16:53:10 --> Helper loaded: form_helper
INFO - 2017-06-19 16:53:10 --> Helper loaded: url_helper
INFO - 2017-06-19 16:53:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 16:53:10 --> Model Class Initialized
INFO - 2017-06-19 16:53:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 16:53:10 --> Final output sent to browser
DEBUG - 2017-06-19 16:53:10 --> Total execution time: 0.0500
ERROR - 2017-06-19 16:53:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 16:53:15 --> Config Class Initialized
INFO - 2017-06-19 16:53:15 --> Hooks Class Initialized
DEBUG - 2017-06-19 16:53:15 --> UTF-8 Support Enabled
INFO - 2017-06-19 16:53:15 --> Utf8 Class Initialized
INFO - 2017-06-19 16:53:15 --> URI Class Initialized
INFO - 2017-06-19 16:53:15 --> Router Class Initialized
INFO - 2017-06-19 16:53:15 --> Output Class Initialized
INFO - 2017-06-19 16:53:15 --> Security Class Initialized
DEBUG - 2017-06-19 16:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 16:53:15 --> Input Class Initialized
INFO - 2017-06-19 16:53:15 --> Language Class Initialized
INFO - 2017-06-19 16:53:15 --> Loader Class Initialized
INFO - 2017-06-19 16:53:15 --> Controller Class Initialized
INFO - 2017-06-19 16:53:15 --> Database Driver Class Initialized
INFO - 2017-06-19 16:53:15 --> Model Class Initialized
INFO - 2017-06-19 16:53:15 --> Helper loaded: form_helper
INFO - 2017-06-19 16:53:15 --> Helper loaded: url_helper
ERROR - 2017-06-19 16:53:15 --> Severity: Notice --> Undefined index: input_track_file C:\xampp\htdocs\mystage\application\controllers\Services.php 266
INFO - 2017-06-19 16:53:15 --> Final output sent to browser
DEBUG - 2017-06-19 16:53:15 --> Total execution time: 0.0530
ERROR - 2017-06-19 16:53:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 16:53:21 --> Config Class Initialized
INFO - 2017-06-19 16:53:21 --> Hooks Class Initialized
DEBUG - 2017-06-19 16:53:21 --> UTF-8 Support Enabled
INFO - 2017-06-19 16:53:21 --> Utf8 Class Initialized
INFO - 2017-06-19 16:53:21 --> URI Class Initialized
INFO - 2017-06-19 16:53:21 --> Router Class Initialized
INFO - 2017-06-19 16:53:21 --> Output Class Initialized
INFO - 2017-06-19 16:53:21 --> Security Class Initialized
DEBUG - 2017-06-19 16:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 16:53:21 --> Input Class Initialized
INFO - 2017-06-19 16:53:21 --> Language Class Initialized
INFO - 2017-06-19 16:53:21 --> Loader Class Initialized
INFO - 2017-06-19 16:53:21 --> Controller Class Initialized
INFO - 2017-06-19 16:53:21 --> Database Driver Class Initialized
INFO - 2017-06-19 16:53:21 --> Model Class Initialized
INFO - 2017-06-19 16:53:21 --> Helper loaded: form_helper
INFO - 2017-06-19 16:53:21 --> Helper loaded: url_helper
INFO - 2017-06-19 16:53:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 16:53:21 --> Model Class Initialized
INFO - 2017-06-19 16:53:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 16:53:21 --> Final output sent to browser
DEBUG - 2017-06-19 16:53:21 --> Total execution time: 0.0530
ERROR - 2017-06-19 16:54:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 16:54:43 --> Config Class Initialized
INFO - 2017-06-19 16:54:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 16:54:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 16:54:43 --> Utf8 Class Initialized
INFO - 2017-06-19 16:54:43 --> URI Class Initialized
INFO - 2017-06-19 16:54:43 --> Router Class Initialized
INFO - 2017-06-19 16:54:43 --> Output Class Initialized
INFO - 2017-06-19 16:54:43 --> Security Class Initialized
DEBUG - 2017-06-19 16:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 16:54:43 --> Input Class Initialized
INFO - 2017-06-19 16:54:43 --> Language Class Initialized
INFO - 2017-06-19 16:54:43 --> Loader Class Initialized
INFO - 2017-06-19 16:54:43 --> Controller Class Initialized
INFO - 2017-06-19 16:54:43 --> Database Driver Class Initialized
INFO - 2017-06-19 16:54:43 --> Model Class Initialized
INFO - 2017-06-19 16:54:43 --> Helper loaded: form_helper
INFO - 2017-06-19 16:54:43 --> Helper loaded: url_helper
INFO - 2017-06-19 16:54:43 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 16:54:43 --> Model Class Initialized
INFO - 2017-06-19 16:54:43 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 16:54:43 --> Final output sent to browser
DEBUG - 2017-06-19 16:54:43 --> Total execution time: 0.0950
ERROR - 2017-06-19 16:54:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 16:54:48 --> Config Class Initialized
INFO - 2017-06-19 16:54:48 --> Hooks Class Initialized
DEBUG - 2017-06-19 16:54:48 --> UTF-8 Support Enabled
INFO - 2017-06-19 16:54:48 --> Utf8 Class Initialized
INFO - 2017-06-19 16:54:48 --> URI Class Initialized
INFO - 2017-06-19 16:54:48 --> Router Class Initialized
INFO - 2017-06-19 16:54:48 --> Output Class Initialized
INFO - 2017-06-19 16:54:48 --> Security Class Initialized
DEBUG - 2017-06-19 16:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 16:54:48 --> Input Class Initialized
INFO - 2017-06-19 16:54:48 --> Language Class Initialized
INFO - 2017-06-19 16:54:48 --> Loader Class Initialized
INFO - 2017-06-19 16:54:48 --> Controller Class Initialized
INFO - 2017-06-19 16:54:48 --> Database Driver Class Initialized
INFO - 2017-06-19 16:54:48 --> Model Class Initialized
INFO - 2017-06-19 16:54:48 --> Helper loaded: form_helper
INFO - 2017-06-19 16:54:48 --> Helper loaded: url_helper
INFO - 2017-06-19 16:54:48 --> Upload Class Initialized
INFO - 2017-06-19 16:54:48 --> Final output sent to browser
DEBUG - 2017-06-19 16:54:48 --> Total execution time: 0.1580
ERROR - 2017-06-19 17:00:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:00:20 --> Config Class Initialized
INFO - 2017-06-19 17:00:20 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:00:20 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:00:20 --> Utf8 Class Initialized
INFO - 2017-06-19 17:00:20 --> URI Class Initialized
INFO - 2017-06-19 17:00:20 --> Router Class Initialized
INFO - 2017-06-19 17:00:20 --> Output Class Initialized
INFO - 2017-06-19 17:00:20 --> Security Class Initialized
DEBUG - 2017-06-19 17:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:00:20 --> Input Class Initialized
INFO - 2017-06-19 17:00:20 --> Language Class Initialized
INFO - 2017-06-19 17:00:20 --> Loader Class Initialized
INFO - 2017-06-19 17:00:20 --> Controller Class Initialized
INFO - 2017-06-19 17:00:20 --> Database Driver Class Initialized
INFO - 2017-06-19 17:00:20 --> Model Class Initialized
INFO - 2017-06-19 17:00:20 --> Helper loaded: form_helper
INFO - 2017-06-19 17:00:20 --> Helper loaded: url_helper
INFO - 2017-06-19 17:00:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:00:20 --> Model Class Initialized
INFO - 2017-06-19 17:00:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:00:20 --> Final output sent to browser
DEBUG - 2017-06-19 17:00:20 --> Total execution time: 0.0810
ERROR - 2017-06-19 17:00:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:00:25 --> Config Class Initialized
INFO - 2017-06-19 17:00:25 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:00:25 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:00:25 --> Utf8 Class Initialized
INFO - 2017-06-19 17:00:25 --> URI Class Initialized
INFO - 2017-06-19 17:00:25 --> Router Class Initialized
INFO - 2017-06-19 17:00:25 --> Output Class Initialized
INFO - 2017-06-19 17:00:25 --> Security Class Initialized
DEBUG - 2017-06-19 17:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:00:25 --> Input Class Initialized
INFO - 2017-06-19 17:00:25 --> Language Class Initialized
INFO - 2017-06-19 17:00:25 --> Loader Class Initialized
INFO - 2017-06-19 17:00:25 --> Controller Class Initialized
INFO - 2017-06-19 17:00:25 --> Database Driver Class Initialized
ERROR - 2017-06-19 17:00:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:00:25 --> Model Class Initialized
INFO - 2017-06-19 17:00:25 --> Config Class Initialized
INFO - 2017-06-19 17:00:25 --> Hooks Class Initialized
INFO - 2017-06-19 17:00:25 --> Helper loaded: form_helper
DEBUG - 2017-06-19 17:00:25 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:00:25 --> Helper loaded: url_helper
INFO - 2017-06-19 17:00:25 --> Utf8 Class Initialized
INFO - 2017-06-19 17:00:25 --> URI Class Initialized
INFO - 2017-06-19 17:00:25 --> Upload Class Initialized
INFO - 2017-06-19 17:00:25 --> Final output sent to browser
INFO - 2017-06-19 17:00:25 --> Router Class Initialized
DEBUG - 2017-06-19 17:00:25 --> Total execution time: 0.0530
INFO - 2017-06-19 17:00:25 --> Output Class Initialized
INFO - 2017-06-19 17:00:25 --> Security Class Initialized
ERROR - 2017-06-19 17:00:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
DEBUG - 2017-06-19 17:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:00:25 --> Input Class Initialized
INFO - 2017-06-19 17:00:25 --> Config Class Initialized
INFO - 2017-06-19 17:00:25 --> Hooks Class Initialized
INFO - 2017-06-19 17:00:25 --> Language Class Initialized
DEBUG - 2017-06-19 17:00:25 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:00:25 --> Utf8 Class Initialized
INFO - 2017-06-19 17:00:25 --> Loader Class Initialized
INFO - 2017-06-19 17:00:25 --> URI Class Initialized
INFO - 2017-06-19 17:00:25 --> Controller Class Initialized
INFO - 2017-06-19 17:00:25 --> Router Class Initialized
INFO - 2017-06-19 17:00:25 --> Output Class Initialized
INFO - 2017-06-19 17:00:25 --> Database Driver Class Initialized
INFO - 2017-06-19 17:00:25 --> Security Class Initialized
INFO - 2017-06-19 17:00:25 --> Model Class Initialized
DEBUG - 2017-06-19 17:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:00:25 --> Input Class Initialized
INFO - 2017-06-19 17:00:25 --> Helper loaded: form_helper
INFO - 2017-06-19 17:00:25 --> Language Class Initialized
INFO - 2017-06-19 17:00:25 --> Helper loaded: url_helper
INFO - 2017-06-19 17:00:25 --> Upload Class Initialized
INFO - 2017-06-19 17:00:25 --> Final output sent to browser
DEBUG - 2017-06-19 17:00:25 --> Total execution time: 0.0570
INFO - 2017-06-19 17:00:25 --> Loader Class Initialized
INFO - 2017-06-19 17:00:25 --> Controller Class Initialized
INFO - 2017-06-19 17:00:25 --> Database Driver Class Initialized
INFO - 2017-06-19 17:00:25 --> Model Class Initialized
INFO - 2017-06-19 17:00:25 --> Helper loaded: form_helper
INFO - 2017-06-19 17:00:25 --> Helper loaded: url_helper
INFO - 2017-06-19 17:00:25 --> Upload Class Initialized
INFO - 2017-06-19 17:00:25 --> Final output sent to browser
DEBUG - 2017-06-19 17:00:25 --> Total execution time: 0.0530
ERROR - 2017-06-19 17:02:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:02:26 --> Config Class Initialized
INFO - 2017-06-19 17:02:26 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:02:26 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:02:26 --> Utf8 Class Initialized
INFO - 2017-06-19 17:02:26 --> URI Class Initialized
INFO - 2017-06-19 17:02:26 --> Router Class Initialized
INFO - 2017-06-19 17:02:26 --> Output Class Initialized
INFO - 2017-06-19 17:02:26 --> Security Class Initialized
DEBUG - 2017-06-19 17:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:02:26 --> Input Class Initialized
INFO - 2017-06-19 17:02:26 --> Language Class Initialized
INFO - 2017-06-19 17:02:26 --> Loader Class Initialized
INFO - 2017-06-19 17:02:26 --> Controller Class Initialized
INFO - 2017-06-19 17:02:26 --> Database Driver Class Initialized
INFO - 2017-06-19 17:02:26 --> Model Class Initialized
INFO - 2017-06-19 17:02:26 --> Helper loaded: form_helper
INFO - 2017-06-19 17:02:26 --> Helper loaded: url_helper
INFO - 2017-06-19 17:02:26 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:02:26 --> Model Class Initialized
INFO - 2017-06-19 17:02:26 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:02:26 --> Final output sent to browser
DEBUG - 2017-06-19 17:02:26 --> Total execution time: 0.0910
ERROR - 2017-06-19 17:02:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:02:31 --> Config Class Initialized
ERROR - 2017-06-19 17:02:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:02:31 --> Hooks Class Initialized
INFO - 2017-06-19 17:02:31 --> Config Class Initialized
INFO - 2017-06-19 17:02:31 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:02:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:02:31 --> Utf8 Class Initialized
DEBUG - 2017-06-19 17:02:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:02:31 --> URI Class Initialized
INFO - 2017-06-19 17:02:31 --> Utf8 Class Initialized
INFO - 2017-06-19 17:02:31 --> Router Class Initialized
INFO - 2017-06-19 17:02:31 --> URI Class Initialized
INFO - 2017-06-19 17:02:31 --> Router Class Initialized
INFO - 2017-06-19 17:02:31 --> Output Class Initialized
INFO - 2017-06-19 17:02:31 --> Security Class Initialized
INFO - 2017-06-19 17:02:31 --> Output Class Initialized
DEBUG - 2017-06-19 17:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:02:31 --> Security Class Initialized
INFO - 2017-06-19 17:02:31 --> Input Class Initialized
DEBUG - 2017-06-19 17:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:02:31 --> Language Class Initialized
INFO - 2017-06-19 17:02:31 --> Input Class Initialized
INFO - 2017-06-19 17:02:31 --> Language Class Initialized
INFO - 2017-06-19 17:02:31 --> Loader Class Initialized
INFO - 2017-06-19 17:02:31 --> Controller Class Initialized
INFO - 2017-06-19 17:02:31 --> Database Driver Class Initialized
INFO - 2017-06-19 17:02:31 --> Model Class Initialized
INFO - 2017-06-19 17:02:31 --> Helper loaded: form_helper
INFO - 2017-06-19 17:02:31 --> Helper loaded: url_helper
INFO - 2017-06-19 17:02:31 --> Upload Class Initialized
INFO - 2017-06-19 17:02:31 --> Final output sent to browser
DEBUG - 2017-06-19 17:02:31 --> Total execution time: 0.0470
INFO - 2017-06-19 17:02:31 --> Loader Class Initialized
INFO - 2017-06-19 17:02:31 --> Controller Class Initialized
INFO - 2017-06-19 17:02:31 --> Database Driver Class Initialized
INFO - 2017-06-19 17:02:31 --> Model Class Initialized
INFO - 2017-06-19 17:02:31 --> Helper loaded: form_helper
INFO - 2017-06-19 17:02:31 --> Helper loaded: url_helper
INFO - 2017-06-19 17:02:31 --> Upload Class Initialized
INFO - 2017-06-19 17:02:31 --> Final output sent to browser
DEBUG - 2017-06-19 17:02:31 --> Total execution time: 0.0700
ERROR - 2017-06-19 17:02:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:02:31 --> Config Class Initialized
ERROR - 2017-06-19 17:02:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:02:31 --> Hooks Class Initialized
INFO - 2017-06-19 17:02:31 --> Config Class Initialized
DEBUG - 2017-06-19 17:02:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:02:31 --> Hooks Class Initialized
INFO - 2017-06-19 17:02:31 --> Utf8 Class Initialized
INFO - 2017-06-19 17:02:31 --> URI Class Initialized
DEBUG - 2017-06-19 17:02:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:02:31 --> Utf8 Class Initialized
INFO - 2017-06-19 17:02:31 --> Router Class Initialized
INFO - 2017-06-19 17:02:31 --> URI Class Initialized
INFO - 2017-06-19 17:02:31 --> Output Class Initialized
INFO - 2017-06-19 17:02:31 --> Router Class Initialized
INFO - 2017-06-19 17:02:31 --> Security Class Initialized
INFO - 2017-06-19 17:02:31 --> Output Class Initialized
DEBUG - 2017-06-19 17:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:02:31 --> Input Class Initialized
INFO - 2017-06-19 17:02:31 --> Security Class Initialized
INFO - 2017-06-19 17:02:31 --> Language Class Initialized
DEBUG - 2017-06-19 17:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:02:31 --> Input Class Initialized
INFO - 2017-06-19 17:02:31 --> Language Class Initialized
INFO - 2017-06-19 17:02:31 --> Loader Class Initialized
INFO - 2017-06-19 17:02:31 --> Controller Class Initialized
INFO - 2017-06-19 17:02:31 --> Database Driver Class Initialized
INFO - 2017-06-19 17:02:31 --> Model Class Initialized
INFO - 2017-06-19 17:02:31 --> Helper loaded: form_helper
INFO - 2017-06-19 17:02:31 --> Helper loaded: url_helper
INFO - 2017-06-19 17:02:31 --> Upload Class Initialized
INFO - 2017-06-19 17:02:31 --> Final output sent to browser
DEBUG - 2017-06-19 17:02:31 --> Total execution time: 0.0440
INFO - 2017-06-19 17:02:31 --> Loader Class Initialized
INFO - 2017-06-19 17:02:31 --> Controller Class Initialized
INFO - 2017-06-19 17:02:31 --> Database Driver Class Initialized
INFO - 2017-06-19 17:02:31 --> Model Class Initialized
INFO - 2017-06-19 17:02:31 --> Helper loaded: form_helper
INFO - 2017-06-19 17:02:31 --> Helper loaded: url_helper
INFO - 2017-06-19 17:02:31 --> Upload Class Initialized
INFO - 2017-06-19 17:02:31 --> Final output sent to browser
DEBUG - 2017-06-19 17:02:31 --> Total execution time: 0.0760
ERROR - 2017-06-19 17:04:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:04:03 --> Config Class Initialized
INFO - 2017-06-19 17:04:03 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:04:03 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:04:03 --> Utf8 Class Initialized
INFO - 2017-06-19 17:04:03 --> URI Class Initialized
INFO - 2017-06-19 17:04:03 --> Router Class Initialized
INFO - 2017-06-19 17:04:03 --> Output Class Initialized
INFO - 2017-06-19 17:04:03 --> Security Class Initialized
DEBUG - 2017-06-19 17:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:04:03 --> Input Class Initialized
INFO - 2017-06-19 17:04:03 --> Language Class Initialized
INFO - 2017-06-19 17:04:03 --> Loader Class Initialized
INFO - 2017-06-19 17:04:03 --> Controller Class Initialized
INFO - 2017-06-19 17:04:03 --> Database Driver Class Initialized
INFO - 2017-06-19 17:04:03 --> Model Class Initialized
INFO - 2017-06-19 17:04:03 --> Helper loaded: form_helper
INFO - 2017-06-19 17:04:03 --> Helper loaded: url_helper
INFO - 2017-06-19 17:04:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:04:03 --> Model Class Initialized
INFO - 2017-06-19 17:04:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:04:03 --> Final output sent to browser
DEBUG - 2017-06-19 17:04:03 --> Total execution time: 0.0580
ERROR - 2017-06-19 17:04:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:04:06 --> Config Class Initialized
INFO - 2017-06-19 17:04:06 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:04:06 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:04:06 --> Utf8 Class Initialized
INFO - 2017-06-19 17:04:06 --> URI Class Initialized
INFO - 2017-06-19 17:04:06 --> Router Class Initialized
INFO - 2017-06-19 17:04:06 --> Output Class Initialized
INFO - 2017-06-19 17:04:06 --> Security Class Initialized
DEBUG - 2017-06-19 17:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:04:06 --> Input Class Initialized
INFO - 2017-06-19 17:04:06 --> Language Class Initialized
INFO - 2017-06-19 17:04:06 --> Loader Class Initialized
INFO - 2017-06-19 17:04:06 --> Controller Class Initialized
INFO - 2017-06-19 17:04:06 --> Database Driver Class Initialized
INFO - 2017-06-19 17:04:06 --> Model Class Initialized
INFO - 2017-06-19 17:04:06 --> Helper loaded: form_helper
INFO - 2017-06-19 17:04:06 --> Helper loaded: url_helper
INFO - 2017-06-19 17:04:06 --> Upload Class Initialized
INFO - 2017-06-19 17:04:06 --> Final output sent to browser
DEBUG - 2017-06-19 17:04:06 --> Total execution time: 0.0440
ERROR - 2017-06-19 17:04:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:04:16 --> Config Class Initialized
INFO - 2017-06-19 17:04:16 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:04:16 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:04:16 --> Utf8 Class Initialized
INFO - 2017-06-19 17:04:16 --> URI Class Initialized
INFO - 2017-06-19 17:04:16 --> Router Class Initialized
ERROR - 2017-06-19 17:04:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:04:16 --> Output Class Initialized
INFO - 2017-06-19 17:04:16 --> Config Class Initialized
INFO - 2017-06-19 17:04:16 --> Security Class Initialized
INFO - 2017-06-19 17:04:16 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-19 17:04:16 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:04:16 --> Input Class Initialized
INFO - 2017-06-19 17:04:16 --> Utf8 Class Initialized
INFO - 2017-06-19 17:04:16 --> Language Class Initialized
INFO - 2017-06-19 17:04:16 --> URI Class Initialized
INFO - 2017-06-19 17:04:16 --> Router Class Initialized
INFO - 2017-06-19 17:04:16 --> Loader Class Initialized
INFO - 2017-06-19 17:04:16 --> Controller Class Initialized
INFO - 2017-06-19 17:04:16 --> Output Class Initialized
INFO - 2017-06-19 17:04:16 --> Security Class Initialized
DEBUG - 2017-06-19 17:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:04:16 --> Database Driver Class Initialized
INFO - 2017-06-19 17:04:16 --> Input Class Initialized
INFO - 2017-06-19 17:04:16 --> Language Class Initialized
INFO - 2017-06-19 17:04:16 --> Model Class Initialized
INFO - 2017-06-19 17:04:16 --> Helper loaded: form_helper
INFO - 2017-06-19 17:04:16 --> Helper loaded: url_helper
INFO - 2017-06-19 17:04:16 --> Upload Class Initialized
INFO - 2017-06-19 17:04:16 --> Final output sent to browser
DEBUG - 2017-06-19 17:04:16 --> Total execution time: 0.0440
INFO - 2017-06-19 17:04:16 --> Loader Class Initialized
INFO - 2017-06-19 17:04:16 --> Controller Class Initialized
INFO - 2017-06-19 17:04:16 --> Database Driver Class Initialized
ERROR - 2017-06-19 17:04:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:04:16 --> Model Class Initialized
INFO - 2017-06-19 17:04:16 --> Config Class Initialized
INFO - 2017-06-19 17:04:16 --> Hooks Class Initialized
INFO - 2017-06-19 17:04:16 --> Helper loaded: form_helper
INFO - 2017-06-19 17:04:16 --> Helper loaded: url_helper
DEBUG - 2017-06-19 17:04:16 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:04:16 --> Upload Class Initialized
INFO - 2017-06-19 17:04:16 --> Utf8 Class Initialized
INFO - 2017-06-19 17:04:16 --> URI Class Initialized
INFO - 2017-06-19 17:04:16 --> Final output sent to browser
DEBUG - 2017-06-19 17:04:16 --> Total execution time: 0.0880
INFO - 2017-06-19 17:04:16 --> Router Class Initialized
INFO - 2017-06-19 17:04:16 --> Output Class Initialized
INFO - 2017-06-19 17:04:16 --> Security Class Initialized
ERROR - 2017-06-19 17:04:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
DEBUG - 2017-06-19 17:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:04:16 --> Input Class Initialized
INFO - 2017-06-19 17:04:16 --> Language Class Initialized
INFO - 2017-06-19 17:04:16 --> Config Class Initialized
INFO - 2017-06-19 17:04:16 --> Hooks Class Initialized
INFO - 2017-06-19 17:04:16 --> Loader Class Initialized
DEBUG - 2017-06-19 17:04:16 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:04:16 --> Controller Class Initialized
INFO - 2017-06-19 17:04:16 --> Utf8 Class Initialized
INFO - 2017-06-19 17:04:16 --> URI Class Initialized
INFO - 2017-06-19 17:04:16 --> Router Class Initialized
INFO - 2017-06-19 17:04:16 --> Database Driver Class Initialized
INFO - 2017-06-19 17:04:16 --> Output Class Initialized
INFO - 2017-06-19 17:04:16 --> Model Class Initialized
INFO - 2017-06-19 17:04:16 --> Security Class Initialized
INFO - 2017-06-19 17:04:16 --> Helper loaded: form_helper
DEBUG - 2017-06-19 17:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:04:16 --> Input Class Initialized
INFO - 2017-06-19 17:04:16 --> Helper loaded: url_helper
INFO - 2017-06-19 17:04:16 --> Language Class Initialized
INFO - 2017-06-19 17:04:16 --> Upload Class Initialized
INFO - 2017-06-19 17:04:16 --> Final output sent to browser
DEBUG - 2017-06-19 17:04:16 --> Total execution time: 0.0720
INFO - 2017-06-19 17:04:16 --> Loader Class Initialized
INFO - 2017-06-19 17:04:16 --> Controller Class Initialized
INFO - 2017-06-19 17:04:16 --> Database Driver Class Initialized
INFO - 2017-06-19 17:04:16 --> Model Class Initialized
INFO - 2017-06-19 17:04:16 --> Helper loaded: form_helper
INFO - 2017-06-19 17:04:16 --> Helper loaded: url_helper
INFO - 2017-06-19 17:04:16 --> Upload Class Initialized
INFO - 2017-06-19 17:04:16 --> Final output sent to browser
DEBUG - 2017-06-19 17:04:16 --> Total execution time: 0.0575
ERROR - 2017-06-19 17:04:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:04:46 --> Config Class Initialized
INFO - 2017-06-19 17:04:46 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:04:46 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:04:46 --> Utf8 Class Initialized
INFO - 2017-06-19 17:04:46 --> URI Class Initialized
INFO - 2017-06-19 17:04:46 --> Router Class Initialized
INFO - 2017-06-19 17:04:46 --> Output Class Initialized
INFO - 2017-06-19 17:04:46 --> Security Class Initialized
DEBUG - 2017-06-19 17:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:04:46 --> Input Class Initialized
INFO - 2017-06-19 17:04:46 --> Language Class Initialized
INFO - 2017-06-19 17:04:46 --> Loader Class Initialized
INFO - 2017-06-19 17:04:46 --> Controller Class Initialized
INFO - 2017-06-19 17:04:46 --> Database Driver Class Initialized
INFO - 2017-06-19 17:04:46 --> Model Class Initialized
INFO - 2017-06-19 17:04:46 --> Helper loaded: form_helper
INFO - 2017-06-19 17:04:46 --> Helper loaded: url_helper
INFO - 2017-06-19 17:04:46 --> Upload Class Initialized
INFO - 2017-06-19 17:04:46 --> Final output sent to browser
DEBUG - 2017-06-19 17:04:46 --> Total execution time: 0.0570
ERROR - 2017-06-19 17:04:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:04:47 --> Config Class Initialized
INFO - 2017-06-19 17:04:47 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:04:47 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:04:47 --> Utf8 Class Initialized
INFO - 2017-06-19 17:04:47 --> URI Class Initialized
INFO - 2017-06-19 17:04:47 --> Router Class Initialized
INFO - 2017-06-19 17:04:47 --> Output Class Initialized
INFO - 2017-06-19 17:04:47 --> Security Class Initialized
DEBUG - 2017-06-19 17:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:04:47 --> Input Class Initialized
INFO - 2017-06-19 17:04:47 --> Language Class Initialized
INFO - 2017-06-19 17:04:47 --> Loader Class Initialized
INFO - 2017-06-19 17:04:47 --> Controller Class Initialized
INFO - 2017-06-19 17:04:47 --> Database Driver Class Initialized
INFO - 2017-06-19 17:04:47 --> Model Class Initialized
INFO - 2017-06-19 17:04:47 --> Helper loaded: form_helper
INFO - 2017-06-19 17:04:47 --> Helper loaded: url_helper
INFO - 2017-06-19 17:04:47 --> Upload Class Initialized
INFO - 2017-06-19 17:04:47 --> Final output sent to browser
DEBUG - 2017-06-19 17:04:47 --> Total execution time: 0.0510
ERROR - 2017-06-19 17:04:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:04:47 --> Config Class Initialized
INFO - 2017-06-19 17:04:47 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:04:47 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:04:47 --> Utf8 Class Initialized
INFO - 2017-06-19 17:04:47 --> URI Class Initialized
INFO - 2017-06-19 17:04:47 --> Router Class Initialized
INFO - 2017-06-19 17:04:47 --> Output Class Initialized
INFO - 2017-06-19 17:04:47 --> Security Class Initialized
DEBUG - 2017-06-19 17:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:04:47 --> Input Class Initialized
INFO - 2017-06-19 17:04:47 --> Language Class Initialized
INFO - 2017-06-19 17:04:47 --> Loader Class Initialized
INFO - 2017-06-19 17:04:47 --> Controller Class Initialized
INFO - 2017-06-19 17:04:47 --> Database Driver Class Initialized
INFO - 2017-06-19 17:04:47 --> Model Class Initialized
INFO - 2017-06-19 17:04:47 --> Helper loaded: form_helper
INFO - 2017-06-19 17:04:47 --> Helper loaded: url_helper
INFO - 2017-06-19 17:04:47 --> Upload Class Initialized
INFO - 2017-06-19 17:04:47 --> Final output sent to browser
DEBUG - 2017-06-19 17:04:47 --> Total execution time: 0.0530
ERROR - 2017-06-19 17:07:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:07:03 --> Config Class Initialized
INFO - 2017-06-19 17:07:03 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:07:03 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:07:03 --> Utf8 Class Initialized
INFO - 2017-06-19 17:07:03 --> URI Class Initialized
INFO - 2017-06-19 17:07:03 --> Router Class Initialized
INFO - 2017-06-19 17:07:03 --> Output Class Initialized
INFO - 2017-06-19 17:07:03 --> Security Class Initialized
DEBUG - 2017-06-19 17:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:07:03 --> Input Class Initialized
INFO - 2017-06-19 17:07:03 --> Language Class Initialized
INFO - 2017-06-19 17:07:03 --> Loader Class Initialized
INFO - 2017-06-19 17:07:03 --> Controller Class Initialized
INFO - 2017-06-19 17:07:03 --> Database Driver Class Initialized
INFO - 2017-06-19 17:07:03 --> Model Class Initialized
INFO - 2017-06-19 17:07:03 --> Helper loaded: form_helper
INFO - 2017-06-19 17:07:03 --> Helper loaded: url_helper
INFO - 2017-06-19 17:07:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:07:03 --> Model Class Initialized
INFO - 2017-06-19 17:07:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:07:03 --> Final output sent to browser
DEBUG - 2017-06-19 17:07:03 --> Total execution time: 0.0880
ERROR - 2017-06-19 17:07:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:07:09 --> Config Class Initialized
INFO - 2017-06-19 17:07:09 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:07:09 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:07:09 --> Utf8 Class Initialized
INFO - 2017-06-19 17:07:09 --> URI Class Initialized
INFO - 2017-06-19 17:07:09 --> Router Class Initialized
INFO - 2017-06-19 17:07:09 --> Output Class Initialized
INFO - 2017-06-19 17:07:09 --> Security Class Initialized
DEBUG - 2017-06-19 17:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:07:09 --> Input Class Initialized
INFO - 2017-06-19 17:07:09 --> Language Class Initialized
INFO - 2017-06-19 17:07:09 --> Loader Class Initialized
INFO - 2017-06-19 17:07:09 --> Controller Class Initialized
INFO - 2017-06-19 17:07:09 --> Database Driver Class Initialized
INFO - 2017-06-19 17:07:09 --> Model Class Initialized
INFO - 2017-06-19 17:07:09 --> Helper loaded: form_helper
INFO - 2017-06-19 17:07:09 --> Helper loaded: url_helper
INFO - 2017-06-19 17:07:09 --> Upload Class Initialized
ERROR - 2017-06-19 17:07:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:07:09 --> Config Class Initialized
INFO - 2017-06-19 17:07:09 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:07:09 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:07:09 --> Utf8 Class Initialized
INFO - 2017-06-19 17:07:09 --> URI Class Initialized
INFO - 2017-06-19 17:07:09 --> Final output sent to browser
DEBUG - 2017-06-19 17:07:09 --> Total execution time: 0.0550
INFO - 2017-06-19 17:07:09 --> Router Class Initialized
INFO - 2017-06-19 17:07:09 --> Output Class Initialized
INFO - 2017-06-19 17:07:09 --> Security Class Initialized
DEBUG - 2017-06-19 17:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:07:09 --> Input Class Initialized
INFO - 2017-06-19 17:07:09 --> Language Class Initialized
INFO - 2017-06-19 17:07:09 --> Loader Class Initialized
INFO - 2017-06-19 17:07:09 --> Controller Class Initialized
INFO - 2017-06-19 17:07:09 --> Database Driver Class Initialized
INFO - 2017-06-19 17:07:09 --> Model Class Initialized
INFO - 2017-06-19 17:07:09 --> Helper loaded: form_helper
INFO - 2017-06-19 17:07:09 --> Helper loaded: url_helper
INFO - 2017-06-19 17:07:09 --> Upload Class Initialized
INFO - 2017-06-19 17:07:09 --> Final output sent to browser
DEBUG - 2017-06-19 17:07:09 --> Total execution time: 0.0725
ERROR - 2017-06-19 17:07:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:07:42 --> Config Class Initialized
INFO - 2017-06-19 17:07:42 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:07:42 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:07:42 --> Utf8 Class Initialized
INFO - 2017-06-19 17:07:42 --> URI Class Initialized
INFO - 2017-06-19 17:07:42 --> Router Class Initialized
INFO - 2017-06-19 17:07:42 --> Output Class Initialized
INFO - 2017-06-19 17:07:42 --> Security Class Initialized
DEBUG - 2017-06-19 17:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:07:42 --> Input Class Initialized
INFO - 2017-06-19 17:07:42 --> Language Class Initialized
INFO - 2017-06-19 17:07:42 --> Loader Class Initialized
INFO - 2017-06-19 17:07:42 --> Controller Class Initialized
INFO - 2017-06-19 17:07:42 --> Database Driver Class Initialized
INFO - 2017-06-19 17:07:42 --> Model Class Initialized
INFO - 2017-06-19 17:07:42 --> Helper loaded: form_helper
INFO - 2017-06-19 17:07:42 --> Helper loaded: url_helper
INFO - 2017-06-19 17:07:42 --> Upload Class Initialized
INFO - 2017-06-19 17:07:42 --> Final output sent to browser
DEBUG - 2017-06-19 17:07:42 --> Total execution time: 0.0560
ERROR - 2017-06-19 17:08:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:08:44 --> Config Class Initialized
INFO - 2017-06-19 17:08:44 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:08:44 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:08:44 --> Utf8 Class Initialized
INFO - 2017-06-19 17:08:44 --> URI Class Initialized
INFO - 2017-06-19 17:08:44 --> Router Class Initialized
INFO - 2017-06-19 17:08:44 --> Output Class Initialized
INFO - 2017-06-19 17:08:44 --> Security Class Initialized
DEBUG - 2017-06-19 17:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:08:44 --> Input Class Initialized
INFO - 2017-06-19 17:08:44 --> Language Class Initialized
INFO - 2017-06-19 17:08:44 --> Loader Class Initialized
INFO - 2017-06-19 17:08:44 --> Controller Class Initialized
INFO - 2017-06-19 17:08:44 --> Database Driver Class Initialized
INFO - 2017-06-19 17:08:44 --> Model Class Initialized
INFO - 2017-06-19 17:08:44 --> Helper loaded: form_helper
INFO - 2017-06-19 17:08:44 --> Helper loaded: url_helper
INFO - 2017-06-19 17:08:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:08:44 --> Model Class Initialized
INFO - 2017-06-19 17:08:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:08:44 --> Final output sent to browser
DEBUG - 2017-06-19 17:08:44 --> Total execution time: 0.0900
ERROR - 2017-06-19 17:08:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:08:48 --> Config Class Initialized
INFO - 2017-06-19 17:08:48 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:08:48 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:08:48 --> Utf8 Class Initialized
INFO - 2017-06-19 17:08:48 --> URI Class Initialized
INFO - 2017-06-19 17:08:48 --> Router Class Initialized
INFO - 2017-06-19 17:08:48 --> Output Class Initialized
INFO - 2017-06-19 17:08:48 --> Security Class Initialized
DEBUG - 2017-06-19 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:08:48 --> Input Class Initialized
INFO - 2017-06-19 17:08:48 --> Language Class Initialized
INFO - 2017-06-19 17:08:48 --> Loader Class Initialized
INFO - 2017-06-19 17:08:48 --> Controller Class Initialized
INFO - 2017-06-19 17:08:48 --> Database Driver Class Initialized
INFO - 2017-06-19 17:08:48 --> Model Class Initialized
INFO - 2017-06-19 17:08:48 --> Helper loaded: form_helper
INFO - 2017-06-19 17:08:48 --> Helper loaded: url_helper
INFO - 2017-06-19 17:08:48 --> Upload Class Initialized
INFO - 2017-06-19 17:08:48 --> Final output sent to browser
DEBUG - 2017-06-19 17:08:48 --> Total execution time: 0.0490
ERROR - 2017-06-19 17:08:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:08:55 --> Config Class Initialized
INFO - 2017-06-19 17:08:55 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:08:55 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:08:55 --> Utf8 Class Initialized
INFO - 2017-06-19 17:08:55 --> URI Class Initialized
INFO - 2017-06-19 17:08:55 --> Router Class Initialized
INFO - 2017-06-19 17:08:55 --> Output Class Initialized
INFO - 2017-06-19 17:08:55 --> Security Class Initialized
DEBUG - 2017-06-19 17:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:08:55 --> Input Class Initialized
INFO - 2017-06-19 17:08:55 --> Language Class Initialized
INFO - 2017-06-19 17:08:55 --> Loader Class Initialized
INFO - 2017-06-19 17:08:55 --> Controller Class Initialized
INFO - 2017-06-19 17:08:55 --> Database Driver Class Initialized
INFO - 2017-06-19 17:08:55 --> Model Class Initialized
INFO - 2017-06-19 17:08:55 --> Helper loaded: form_helper
INFO - 2017-06-19 17:08:55 --> Helper loaded: url_helper
INFO - 2017-06-19 17:08:55 --> Upload Class Initialized
INFO - 2017-06-19 17:08:55 --> Final output sent to browser
DEBUG - 2017-06-19 17:08:55 --> Total execution time: 0.0880
ERROR - 2017-06-19 17:08:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:08:56 --> Config Class Initialized
INFO - 2017-06-19 17:08:56 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:08:56 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:08:56 --> Utf8 Class Initialized
INFO - 2017-06-19 17:08:56 --> URI Class Initialized
INFO - 2017-06-19 17:08:56 --> Router Class Initialized
INFO - 2017-06-19 17:08:56 --> Output Class Initialized
INFO - 2017-06-19 17:08:56 --> Security Class Initialized
DEBUG - 2017-06-19 17:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:08:56 --> Input Class Initialized
INFO - 2017-06-19 17:08:56 --> Language Class Initialized
INFO - 2017-06-19 17:08:56 --> Loader Class Initialized
INFO - 2017-06-19 17:08:56 --> Controller Class Initialized
INFO - 2017-06-19 17:08:56 --> Database Driver Class Initialized
INFO - 2017-06-19 17:08:56 --> Model Class Initialized
INFO - 2017-06-19 17:08:56 --> Helper loaded: form_helper
INFO - 2017-06-19 17:08:56 --> Helper loaded: url_helper
INFO - 2017-06-19 17:08:56 --> Upload Class Initialized
INFO - 2017-06-19 17:08:56 --> Final output sent to browser
DEBUG - 2017-06-19 17:08:56 --> Total execution time: 0.0520
ERROR - 2017-06-19 17:08:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:08:57 --> Config Class Initialized
INFO - 2017-06-19 17:08:57 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:08:57 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:08:57 --> Utf8 Class Initialized
INFO - 2017-06-19 17:08:57 --> URI Class Initialized
INFO - 2017-06-19 17:08:57 --> Router Class Initialized
INFO - 2017-06-19 17:08:57 --> Output Class Initialized
INFO - 2017-06-19 17:08:57 --> Security Class Initialized
DEBUG - 2017-06-19 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:08:57 --> Input Class Initialized
INFO - 2017-06-19 17:08:57 --> Language Class Initialized
INFO - 2017-06-19 17:08:57 --> Loader Class Initialized
INFO - 2017-06-19 17:08:57 --> Controller Class Initialized
INFO - 2017-06-19 17:08:57 --> Database Driver Class Initialized
INFO - 2017-06-19 17:08:57 --> Model Class Initialized
INFO - 2017-06-19 17:08:57 --> Helper loaded: form_helper
INFO - 2017-06-19 17:08:57 --> Helper loaded: url_helper
INFO - 2017-06-19 17:08:57 --> Upload Class Initialized
INFO - 2017-06-19 17:08:57 --> Final output sent to browser
DEBUG - 2017-06-19 17:08:57 --> Total execution time: 0.0480
ERROR - 2017-06-19 17:16:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:16:44 --> Config Class Initialized
INFO - 2017-06-19 17:16:44 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:16:44 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:16:44 --> Utf8 Class Initialized
INFO - 2017-06-19 17:16:44 --> URI Class Initialized
INFO - 2017-06-19 17:16:44 --> Router Class Initialized
INFO - 2017-06-19 17:16:44 --> Output Class Initialized
INFO - 2017-06-19 17:16:44 --> Security Class Initialized
DEBUG - 2017-06-19 17:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:16:44 --> Input Class Initialized
INFO - 2017-06-19 17:16:44 --> Language Class Initialized
INFO - 2017-06-19 17:16:44 --> Loader Class Initialized
INFO - 2017-06-19 17:16:44 --> Controller Class Initialized
INFO - 2017-06-19 17:16:44 --> Database Driver Class Initialized
INFO - 2017-06-19 17:16:44 --> Model Class Initialized
INFO - 2017-06-19 17:16:44 --> Helper loaded: form_helper
INFO - 2017-06-19 17:16:44 --> Helper loaded: url_helper
INFO - 2017-06-19 17:16:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:16:44 --> Model Class Initialized
INFO - 2017-06-19 17:16:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:16:44 --> Final output sent to browser
DEBUG - 2017-06-19 17:16:44 --> Total execution time: 0.0660
ERROR - 2017-06-19 17:16:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:16:46 --> Config Class Initialized
INFO - 2017-06-19 17:16:46 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:16:46 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:16:46 --> Utf8 Class Initialized
INFO - 2017-06-19 17:16:46 --> URI Class Initialized
INFO - 2017-06-19 17:16:46 --> Router Class Initialized
INFO - 2017-06-19 17:16:46 --> Output Class Initialized
INFO - 2017-06-19 17:16:46 --> Security Class Initialized
DEBUG - 2017-06-19 17:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:16:46 --> Input Class Initialized
INFO - 2017-06-19 17:16:46 --> Language Class Initialized
INFO - 2017-06-19 17:16:46 --> Loader Class Initialized
INFO - 2017-06-19 17:16:46 --> Controller Class Initialized
INFO - 2017-06-19 17:16:46 --> Database Driver Class Initialized
INFO - 2017-06-19 17:16:46 --> Model Class Initialized
INFO - 2017-06-19 17:16:46 --> Helper loaded: form_helper
INFO - 2017-06-19 17:16:46 --> Helper loaded: url_helper
INFO - 2017-06-19 17:16:46 --> Upload Class Initialized
INFO - 2017-06-19 17:16:46 --> Final output sent to browser
DEBUG - 2017-06-19 17:16:46 --> Total execution time: 0.0830
ERROR - 2017-06-19 17:17:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:17:00 --> Config Class Initialized
INFO - 2017-06-19 17:17:00 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:17:00 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:17:00 --> Utf8 Class Initialized
INFO - 2017-06-19 17:17:00 --> URI Class Initialized
INFO - 2017-06-19 17:17:00 --> Router Class Initialized
INFO - 2017-06-19 17:17:00 --> Output Class Initialized
INFO - 2017-06-19 17:17:00 --> Security Class Initialized
DEBUG - 2017-06-19 17:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:17:00 --> Input Class Initialized
INFO - 2017-06-19 17:17:00 --> Language Class Initialized
INFO - 2017-06-19 17:17:00 --> Loader Class Initialized
INFO - 2017-06-19 17:17:00 --> Controller Class Initialized
INFO - 2017-06-19 17:17:00 --> Database Driver Class Initialized
INFO - 2017-06-19 17:17:00 --> Model Class Initialized
INFO - 2017-06-19 17:17:00 --> Helper loaded: form_helper
INFO - 2017-06-19 17:17:00 --> Helper loaded: url_helper
INFO - 2017-06-19 17:17:00 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:17:00 --> Model Class Initialized
INFO - 2017-06-19 17:17:00 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:17:00 --> Final output sent to browser
DEBUG - 2017-06-19 17:17:00 --> Total execution time: 0.0625
ERROR - 2017-06-19 17:17:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:17:04 --> Config Class Initialized
INFO - 2017-06-19 17:17:04 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:17:04 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:17:04 --> Utf8 Class Initialized
INFO - 2017-06-19 17:17:04 --> URI Class Initialized
INFO - 2017-06-19 17:17:04 --> Router Class Initialized
INFO - 2017-06-19 17:17:04 --> Output Class Initialized
INFO - 2017-06-19 17:17:04 --> Security Class Initialized
DEBUG - 2017-06-19 17:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:17:04 --> Input Class Initialized
INFO - 2017-06-19 17:17:04 --> Language Class Initialized
INFO - 2017-06-19 17:17:04 --> Loader Class Initialized
INFO - 2017-06-19 17:17:04 --> Controller Class Initialized
INFO - 2017-06-19 17:17:04 --> Database Driver Class Initialized
INFO - 2017-06-19 17:17:04 --> Model Class Initialized
INFO - 2017-06-19 17:17:04 --> Helper loaded: form_helper
INFO - 2017-06-19 17:17:05 --> Helper loaded: url_helper
INFO - 2017-06-19 17:17:05 --> Upload Class Initialized
INFO - 2017-06-19 17:17:05 --> Final output sent to browser
DEBUG - 2017-06-19 17:17:05 --> Total execution time: 0.0650
ERROR - 2017-06-19 17:19:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:19:05 --> Config Class Initialized
INFO - 2017-06-19 17:19:05 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:19:05 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:19:05 --> Utf8 Class Initialized
INFO - 2017-06-19 17:19:05 --> URI Class Initialized
INFO - 2017-06-19 17:19:05 --> Router Class Initialized
INFO - 2017-06-19 17:19:05 --> Output Class Initialized
INFO - 2017-06-19 17:19:05 --> Security Class Initialized
DEBUG - 2017-06-19 17:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:19:05 --> Input Class Initialized
INFO - 2017-06-19 17:19:05 --> Language Class Initialized
INFO - 2017-06-19 17:19:05 --> Loader Class Initialized
INFO - 2017-06-19 17:19:05 --> Controller Class Initialized
INFO - 2017-06-19 17:19:05 --> Database Driver Class Initialized
INFO - 2017-06-19 17:19:05 --> Model Class Initialized
INFO - 2017-06-19 17:19:05 --> Helper loaded: form_helper
INFO - 2017-06-19 17:19:05 --> Helper loaded: url_helper
INFO - 2017-06-19 17:19:05 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:19:05 --> Model Class Initialized
INFO - 2017-06-19 17:19:05 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:19:05 --> Final output sent to browser
DEBUG - 2017-06-19 17:19:05 --> Total execution time: 0.0560
ERROR - 2017-06-19 17:19:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:19:07 --> Config Class Initialized
INFO - 2017-06-19 17:19:07 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:19:07 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:19:07 --> Utf8 Class Initialized
INFO - 2017-06-19 17:19:07 --> URI Class Initialized
INFO - 2017-06-19 17:19:07 --> Router Class Initialized
INFO - 2017-06-19 17:19:07 --> Output Class Initialized
INFO - 2017-06-19 17:19:07 --> Security Class Initialized
DEBUG - 2017-06-19 17:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:19:07 --> Input Class Initialized
INFO - 2017-06-19 17:19:07 --> Language Class Initialized
INFO - 2017-06-19 17:19:07 --> Loader Class Initialized
INFO - 2017-06-19 17:19:07 --> Controller Class Initialized
INFO - 2017-06-19 17:19:07 --> Database Driver Class Initialized
INFO - 2017-06-19 17:19:07 --> Model Class Initialized
INFO - 2017-06-19 17:19:07 --> Helper loaded: form_helper
INFO - 2017-06-19 17:19:07 --> Helper loaded: url_helper
INFO - 2017-06-19 17:19:07 --> Upload Class Initialized
INFO - 2017-06-19 17:19:07 --> Final output sent to browser
DEBUG - 2017-06-19 17:19:07 --> Total execution time: 0.0600
ERROR - 2017-06-19 17:19:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:19:13 --> Config Class Initialized
INFO - 2017-06-19 17:19:13 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:19:13 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:19:13 --> Utf8 Class Initialized
INFO - 2017-06-19 17:19:13 --> URI Class Initialized
INFO - 2017-06-19 17:19:13 --> Router Class Initialized
INFO - 2017-06-19 17:19:13 --> Output Class Initialized
INFO - 2017-06-19 17:19:13 --> Security Class Initialized
DEBUG - 2017-06-19 17:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:19:13 --> Input Class Initialized
INFO - 2017-06-19 17:19:13 --> Language Class Initialized
INFO - 2017-06-19 17:19:13 --> Loader Class Initialized
INFO - 2017-06-19 17:19:13 --> Controller Class Initialized
INFO - 2017-06-19 17:19:13 --> Database Driver Class Initialized
INFO - 2017-06-19 17:19:13 --> Model Class Initialized
INFO - 2017-06-19 17:19:13 --> Helper loaded: form_helper
INFO - 2017-06-19 17:19:13 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:19:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:19:13 --> Upload Class Initialized
INFO - 2017-06-19 17:19:13 --> Config Class Initialized
INFO - 2017-06-19 17:19:13 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:19:13 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:19:13 --> Utf8 Class Initialized
INFO - 2017-06-19 17:19:13 --> URI Class Initialized
INFO - 2017-06-19 17:19:13 --> Router Class Initialized
INFO - 2017-06-19 17:19:13 --> Final output sent to browser
DEBUG - 2017-06-19 17:19:13 --> Total execution time: 0.0780
INFO - 2017-06-19 17:19:13 --> Output Class Initialized
INFO - 2017-06-19 17:19:13 --> Security Class Initialized
DEBUG - 2017-06-19 17:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:19:13 --> Input Class Initialized
INFO - 2017-06-19 17:19:13 --> Language Class Initialized
INFO - 2017-06-19 17:19:13 --> Loader Class Initialized
INFO - 2017-06-19 17:19:13 --> Controller Class Initialized
INFO - 2017-06-19 17:19:13 --> Database Driver Class Initialized
INFO - 2017-06-19 17:19:13 --> Model Class Initialized
INFO - 2017-06-19 17:19:13 --> Helper loaded: form_helper
INFO - 2017-06-19 17:19:13 --> Helper loaded: url_helper
INFO - 2017-06-19 17:19:13 --> Upload Class Initialized
INFO - 2017-06-19 17:19:13 --> Final output sent to browser
DEBUG - 2017-06-19 17:19:13 --> Total execution time: 0.0750
ERROR - 2017-06-19 17:19:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:19:23 --> Config Class Initialized
INFO - 2017-06-19 17:19:23 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:19:23 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:19:23 --> Utf8 Class Initialized
INFO - 2017-06-19 17:19:23 --> URI Class Initialized
INFO - 2017-06-19 17:19:23 --> Router Class Initialized
INFO - 2017-06-19 17:19:23 --> Output Class Initialized
INFO - 2017-06-19 17:19:23 --> Security Class Initialized
DEBUG - 2017-06-19 17:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:19:23 --> Input Class Initialized
INFO - 2017-06-19 17:19:23 --> Language Class Initialized
INFO - 2017-06-19 17:19:23 --> Loader Class Initialized
INFO - 2017-06-19 17:19:23 --> Controller Class Initialized
INFO - 2017-06-19 17:19:23 --> Database Driver Class Initialized
INFO - 2017-06-19 17:19:23 --> Model Class Initialized
INFO - 2017-06-19 17:19:23 --> Helper loaded: form_helper
INFO - 2017-06-19 17:19:23 --> Helper loaded: url_helper
INFO - 2017-06-19 17:19:23 --> Upload Class Initialized
INFO - 2017-06-19 17:19:23 --> Final output sent to browser
DEBUG - 2017-06-19 17:19:23 --> Total execution time: 0.0620
ERROR - 2017-06-19 17:19:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:19:24 --> Config Class Initialized
INFO - 2017-06-19 17:19:24 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:19:24 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:19:24 --> Utf8 Class Initialized
INFO - 2017-06-19 17:19:24 --> URI Class Initialized
INFO - 2017-06-19 17:19:24 --> Router Class Initialized
INFO - 2017-06-19 17:19:24 --> Output Class Initialized
INFO - 2017-06-19 17:19:24 --> Security Class Initialized
DEBUG - 2017-06-19 17:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:19:24 --> Input Class Initialized
INFO - 2017-06-19 17:19:24 --> Language Class Initialized
INFO - 2017-06-19 17:19:24 --> Loader Class Initialized
INFO - 2017-06-19 17:19:24 --> Controller Class Initialized
INFO - 2017-06-19 17:19:24 --> Database Driver Class Initialized
INFO - 2017-06-19 17:19:24 --> Model Class Initialized
INFO - 2017-06-19 17:19:24 --> Helper loaded: form_helper
INFO - 2017-06-19 17:19:24 --> Helper loaded: url_helper
INFO - 2017-06-19 17:19:24 --> Upload Class Initialized
INFO - 2017-06-19 17:19:24 --> Final output sent to browser
DEBUG - 2017-06-19 17:19:24 --> Total execution time: 0.0610
ERROR - 2017-06-19 17:19:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:19:24 --> Config Class Initialized
INFO - 2017-06-19 17:19:24 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:19:24 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:19:24 --> Utf8 Class Initialized
INFO - 2017-06-19 17:19:24 --> URI Class Initialized
INFO - 2017-06-19 17:19:24 --> Router Class Initialized
INFO - 2017-06-19 17:19:24 --> Output Class Initialized
INFO - 2017-06-19 17:19:24 --> Security Class Initialized
DEBUG - 2017-06-19 17:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:19:24 --> Input Class Initialized
INFO - 2017-06-19 17:19:24 --> Language Class Initialized
INFO - 2017-06-19 17:19:24 --> Loader Class Initialized
INFO - 2017-06-19 17:19:24 --> Controller Class Initialized
INFO - 2017-06-19 17:19:24 --> Database Driver Class Initialized
INFO - 2017-06-19 17:19:24 --> Model Class Initialized
INFO - 2017-06-19 17:19:24 --> Helper loaded: form_helper
INFO - 2017-06-19 17:19:24 --> Helper loaded: url_helper
INFO - 2017-06-19 17:19:24 --> Upload Class Initialized
INFO - 2017-06-19 17:19:24 --> Final output sent to browser
DEBUG - 2017-06-19 17:19:24 --> Total execution time: 0.0730
ERROR - 2017-06-19 17:19:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:19:24 --> Config Class Initialized
INFO - 2017-06-19 17:19:24 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:19:24 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:19:24 --> Utf8 Class Initialized
INFO - 2017-06-19 17:19:24 --> URI Class Initialized
INFO - 2017-06-19 17:19:24 --> Router Class Initialized
INFO - 2017-06-19 17:19:24 --> Output Class Initialized
INFO - 2017-06-19 17:19:24 --> Security Class Initialized
DEBUG - 2017-06-19 17:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:19:24 --> Input Class Initialized
INFO - 2017-06-19 17:19:24 --> Language Class Initialized
INFO - 2017-06-19 17:19:24 --> Loader Class Initialized
INFO - 2017-06-19 17:19:24 --> Controller Class Initialized
INFO - 2017-06-19 17:19:24 --> Database Driver Class Initialized
INFO - 2017-06-19 17:19:24 --> Model Class Initialized
INFO - 2017-06-19 17:19:24 --> Helper loaded: form_helper
INFO - 2017-06-19 17:19:24 --> Helper loaded: url_helper
INFO - 2017-06-19 17:19:24 --> Upload Class Initialized
INFO - 2017-06-19 17:19:24 --> Final output sent to browser
DEBUG - 2017-06-19 17:19:24 --> Total execution time: 0.0930
ERROR - 2017-06-19 17:19:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:19:24 --> Config Class Initialized
INFO - 2017-06-19 17:19:24 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:19:24 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:19:24 --> Utf8 Class Initialized
INFO - 2017-06-19 17:19:24 --> URI Class Initialized
INFO - 2017-06-19 17:19:24 --> Router Class Initialized
INFO - 2017-06-19 17:19:24 --> Output Class Initialized
INFO - 2017-06-19 17:19:24 --> Security Class Initialized
DEBUG - 2017-06-19 17:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:19:24 --> Input Class Initialized
INFO - 2017-06-19 17:19:24 --> Language Class Initialized
INFO - 2017-06-19 17:19:24 --> Loader Class Initialized
INFO - 2017-06-19 17:19:24 --> Controller Class Initialized
INFO - 2017-06-19 17:19:24 --> Database Driver Class Initialized
INFO - 2017-06-19 17:19:24 --> Model Class Initialized
INFO - 2017-06-19 17:19:24 --> Helper loaded: form_helper
INFO - 2017-06-19 17:19:24 --> Helper loaded: url_helper
INFO - 2017-06-19 17:19:24 --> Upload Class Initialized
INFO - 2017-06-19 17:19:24 --> Final output sent to browser
DEBUG - 2017-06-19 17:19:24 --> Total execution time: 0.0930
ERROR - 2017-06-19 17:19:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:19:24 --> Config Class Initialized
INFO - 2017-06-19 17:19:24 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:19:24 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:19:24 --> Utf8 Class Initialized
INFO - 2017-06-19 17:19:24 --> URI Class Initialized
INFO - 2017-06-19 17:19:24 --> Router Class Initialized
INFO - 2017-06-19 17:19:24 --> Output Class Initialized
INFO - 2017-06-19 17:19:24 --> Security Class Initialized
DEBUG - 2017-06-19 17:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:19:24 --> Input Class Initialized
INFO - 2017-06-19 17:19:24 --> Language Class Initialized
INFO - 2017-06-19 17:19:24 --> Loader Class Initialized
INFO - 2017-06-19 17:19:24 --> Controller Class Initialized
INFO - 2017-06-19 17:19:24 --> Database Driver Class Initialized
INFO - 2017-06-19 17:19:24 --> Model Class Initialized
INFO - 2017-06-19 17:19:24 --> Helper loaded: form_helper
INFO - 2017-06-19 17:19:24 --> Helper loaded: url_helper
INFO - 2017-06-19 17:19:24 --> Upload Class Initialized
INFO - 2017-06-19 17:19:24 --> Final output sent to browser
DEBUG - 2017-06-19 17:19:24 --> Total execution time: 0.0640
ERROR - 2017-06-19 17:19:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:19:58 --> Config Class Initialized
INFO - 2017-06-19 17:19:58 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:19:58 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:19:58 --> Utf8 Class Initialized
INFO - 2017-06-19 17:19:58 --> URI Class Initialized
INFO - 2017-06-19 17:19:58 --> Router Class Initialized
INFO - 2017-06-19 17:19:58 --> Output Class Initialized
INFO - 2017-06-19 17:19:58 --> Security Class Initialized
DEBUG - 2017-06-19 17:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:19:58 --> Input Class Initialized
INFO - 2017-06-19 17:19:58 --> Language Class Initialized
INFO - 2017-06-19 17:19:58 --> Loader Class Initialized
INFO - 2017-06-19 17:19:58 --> Controller Class Initialized
INFO - 2017-06-19 17:19:58 --> Database Driver Class Initialized
INFO - 2017-06-19 17:19:58 --> Model Class Initialized
INFO - 2017-06-19 17:19:58 --> Helper loaded: form_helper
INFO - 2017-06-19 17:19:58 --> Helper loaded: url_helper
INFO - 2017-06-19 17:19:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:19:58 --> Model Class Initialized
INFO - 2017-06-19 17:19:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:19:58 --> Final output sent to browser
DEBUG - 2017-06-19 17:19:58 --> Total execution time: 0.0650
ERROR - 2017-06-19 17:24:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:24:09 --> Config Class Initialized
INFO - 2017-06-19 17:24:09 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:24:09 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:24:09 --> Utf8 Class Initialized
INFO - 2017-06-19 17:24:09 --> URI Class Initialized
DEBUG - 2017-06-19 17:24:09 --> No URI present. Default controller set.
INFO - 2017-06-19 17:24:09 --> Router Class Initialized
INFO - 2017-06-19 17:24:09 --> Output Class Initialized
INFO - 2017-06-19 17:24:09 --> Security Class Initialized
DEBUG - 2017-06-19 17:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:24:09 --> Input Class Initialized
INFO - 2017-06-19 17:24:09 --> Language Class Initialized
INFO - 2017-06-19 17:24:09 --> Loader Class Initialized
INFO - 2017-06-19 17:24:09 --> Controller Class Initialized
INFO - 2017-06-19 17:24:09 --> Database Driver Class Initialized
INFO - 2017-06-19 17:24:09 --> Model Class Initialized
INFO - 2017-06-19 17:24:09 --> Helper loaded: form_helper
INFO - 2017-06-19 17:24:09 --> Helper loaded: url_helper
INFO - 2017-06-19 17:24:09 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-06-19 17:24:09 --> Final output sent to browser
DEBUG - 2017-06-19 17:24:09 --> Total execution time: 0.0580
ERROR - 2017-06-19 17:24:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:24:10 --> Config Class Initialized
INFO - 2017-06-19 17:24:10 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:24:10 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:24:10 --> Utf8 Class Initialized
INFO - 2017-06-19 17:24:10 --> URI Class Initialized
INFO - 2017-06-19 17:24:10 --> Router Class Initialized
INFO - 2017-06-19 17:24:10 --> Output Class Initialized
INFO - 2017-06-19 17:24:10 --> Security Class Initialized
DEBUG - 2017-06-19 17:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:24:10 --> Input Class Initialized
INFO - 2017-06-19 17:24:10 --> Language Class Initialized
INFO - 2017-06-19 17:24:10 --> Loader Class Initialized
INFO - 2017-06-19 17:24:10 --> Controller Class Initialized
INFO - 2017-06-19 17:24:10 --> Database Driver Class Initialized
INFO - 2017-06-19 17:24:10 --> Model Class Initialized
INFO - 2017-06-19 17:24:10 --> Helper loaded: form_helper
INFO - 2017-06-19 17:24:11 --> Helper loaded: url_helper
INFO - 2017-06-19 17:24:11 --> Model Class Initialized
ERROR - 2017-06-19 17:24:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:24:11 --> Config Class Initialized
INFO - 2017-06-19 17:24:11 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:24:11 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:24:11 --> Utf8 Class Initialized
INFO - 2017-06-19 17:24:11 --> URI Class Initialized
INFO - 2017-06-19 17:24:11 --> Router Class Initialized
INFO - 2017-06-19 17:24:11 --> Output Class Initialized
INFO - 2017-06-19 17:24:11 --> Security Class Initialized
DEBUG - 2017-06-19 17:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:24:11 --> Input Class Initialized
INFO - 2017-06-19 17:24:11 --> Language Class Initialized
INFO - 2017-06-19 17:24:11 --> Loader Class Initialized
INFO - 2017-06-19 17:24:11 --> Controller Class Initialized
INFO - 2017-06-19 17:24:11 --> Database Driver Class Initialized
INFO - 2017-06-19 17:24:11 --> Model Class Initialized
INFO - 2017-06-19 17:24:11 --> Helper loaded: form_helper
INFO - 2017-06-19 17:24:11 --> Helper loaded: url_helper
INFO - 2017-06-19 17:24:11 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:24:11 --> Model Class Initialized
INFO - 2017-06-19 17:24:11 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-19 17:24:11 --> Final output sent to browser
DEBUG - 2017-06-19 17:24:11 --> Total execution time: 0.0700
ERROR - 2017-06-19 17:24:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:24:13 --> Config Class Initialized
INFO - 2017-06-19 17:24:13 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:24:13 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:24:13 --> Utf8 Class Initialized
INFO - 2017-06-19 17:24:13 --> URI Class Initialized
INFO - 2017-06-19 17:24:13 --> Router Class Initialized
INFO - 2017-06-19 17:24:13 --> Output Class Initialized
INFO - 2017-06-19 17:24:13 --> Security Class Initialized
DEBUG - 2017-06-19 17:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:24:13 --> Input Class Initialized
INFO - 2017-06-19 17:24:13 --> Language Class Initialized
INFO - 2017-06-19 17:24:13 --> Loader Class Initialized
INFO - 2017-06-19 17:24:13 --> Controller Class Initialized
INFO - 2017-06-19 17:24:13 --> Database Driver Class Initialized
INFO - 2017-06-19 17:24:13 --> Model Class Initialized
INFO - 2017-06-19 17:24:13 --> Helper loaded: form_helper
INFO - 2017-06-19 17:24:13 --> Helper loaded: url_helper
INFO - 2017-06-19 17:24:13 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:24:13 --> Model Class Initialized
INFO - 2017-06-19 17:24:13 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:24:13 --> Final output sent to browser
DEBUG - 2017-06-19 17:24:13 --> Total execution time: 0.0720
ERROR - 2017-06-19 17:24:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:24:19 --> Config Class Initialized
INFO - 2017-06-19 17:24:19 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:24:19 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:24:19 --> Utf8 Class Initialized
INFO - 2017-06-19 17:24:19 --> URI Class Initialized
INFO - 2017-06-19 17:24:19 --> Router Class Initialized
INFO - 2017-06-19 17:24:19 --> Output Class Initialized
INFO - 2017-06-19 17:24:19 --> Security Class Initialized
DEBUG - 2017-06-19 17:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:24:19 --> Input Class Initialized
INFO - 2017-06-19 17:24:19 --> Language Class Initialized
INFO - 2017-06-19 17:24:19 --> Loader Class Initialized
INFO - 2017-06-19 17:24:19 --> Controller Class Initialized
INFO - 2017-06-19 17:24:19 --> Database Driver Class Initialized
INFO - 2017-06-19 17:24:19 --> Model Class Initialized
INFO - 2017-06-19 17:24:19 --> Helper loaded: form_helper
INFO - 2017-06-19 17:24:19 --> Helper loaded: url_helper
INFO - 2017-06-19 17:24:19 --> Upload Class Initialized
INFO - 2017-06-19 17:24:19 --> Final output sent to browser
DEBUG - 2017-06-19 17:24:19 --> Total execution time: 0.0760
ERROR - 2017-06-19 17:24:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:24:19 --> Config Class Initialized
INFO - 2017-06-19 17:24:19 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:24:19 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:24:19 --> Utf8 Class Initialized
INFO - 2017-06-19 17:24:19 --> URI Class Initialized
INFO - 2017-06-19 17:24:19 --> Router Class Initialized
INFO - 2017-06-19 17:24:19 --> Output Class Initialized
INFO - 2017-06-19 17:24:19 --> Security Class Initialized
DEBUG - 2017-06-19 17:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:24:19 --> Input Class Initialized
INFO - 2017-06-19 17:24:19 --> Language Class Initialized
INFO - 2017-06-19 17:24:19 --> Loader Class Initialized
INFO - 2017-06-19 17:24:19 --> Controller Class Initialized
INFO - 2017-06-19 17:24:19 --> Database Driver Class Initialized
INFO - 2017-06-19 17:24:19 --> Model Class Initialized
INFO - 2017-06-19 17:24:19 --> Helper loaded: form_helper
INFO - 2017-06-19 17:24:19 --> Helper loaded: url_helper
INFO - 2017-06-19 17:24:19 --> Upload Class Initialized
INFO - 2017-06-19 17:24:19 --> Final output sent to browser
DEBUG - 2017-06-19 17:24:19 --> Total execution time: 0.0800
ERROR - 2017-06-19 17:24:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:24:20 --> Config Class Initialized
INFO - 2017-06-19 17:24:20 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:24:20 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:24:20 --> Utf8 Class Initialized
INFO - 2017-06-19 17:24:20 --> URI Class Initialized
INFO - 2017-06-19 17:24:20 --> Router Class Initialized
INFO - 2017-06-19 17:24:20 --> Output Class Initialized
INFO - 2017-06-19 17:24:20 --> Security Class Initialized
DEBUG - 2017-06-19 17:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:24:20 --> Input Class Initialized
INFO - 2017-06-19 17:24:20 --> Language Class Initialized
INFO - 2017-06-19 17:24:20 --> Loader Class Initialized
INFO - 2017-06-19 17:24:20 --> Controller Class Initialized
INFO - 2017-06-19 17:24:20 --> Database Driver Class Initialized
INFO - 2017-06-19 17:24:20 --> Model Class Initialized
INFO - 2017-06-19 17:24:20 --> Helper loaded: form_helper
INFO - 2017-06-19 17:24:20 --> Helper loaded: url_helper
INFO - 2017-06-19 17:24:20 --> Upload Class Initialized
INFO - 2017-06-19 17:24:20 --> Final output sent to browser
DEBUG - 2017-06-19 17:24:20 --> Total execution time: 0.0760
ERROR - 2017-06-19 17:24:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:24:20 --> Config Class Initialized
INFO - 2017-06-19 17:24:20 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:24:20 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:24:20 --> Utf8 Class Initialized
INFO - 2017-06-19 17:24:20 --> URI Class Initialized
INFO - 2017-06-19 17:24:20 --> Router Class Initialized
INFO - 2017-06-19 17:24:20 --> Output Class Initialized
INFO - 2017-06-19 17:24:20 --> Security Class Initialized
DEBUG - 2017-06-19 17:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:24:20 --> Input Class Initialized
INFO - 2017-06-19 17:24:20 --> Language Class Initialized
INFO - 2017-06-19 17:24:20 --> Loader Class Initialized
INFO - 2017-06-19 17:24:20 --> Controller Class Initialized
INFO - 2017-06-19 17:24:20 --> Database Driver Class Initialized
INFO - 2017-06-19 17:24:20 --> Model Class Initialized
INFO - 2017-06-19 17:24:20 --> Helper loaded: form_helper
INFO - 2017-06-19 17:24:20 --> Helper loaded: url_helper
INFO - 2017-06-19 17:24:20 --> Upload Class Initialized
INFO - 2017-06-19 17:24:20 --> Final output sent to browser
DEBUG - 2017-06-19 17:24:20 --> Total execution time: 0.0780
ERROR - 2017-06-19 17:24:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:24:20 --> Config Class Initialized
INFO - 2017-06-19 17:24:20 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:24:20 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:24:20 --> Utf8 Class Initialized
INFO - 2017-06-19 17:24:20 --> URI Class Initialized
INFO - 2017-06-19 17:24:20 --> Router Class Initialized
INFO - 2017-06-19 17:24:20 --> Output Class Initialized
INFO - 2017-06-19 17:24:20 --> Security Class Initialized
DEBUG - 2017-06-19 17:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:24:20 --> Input Class Initialized
INFO - 2017-06-19 17:24:20 --> Language Class Initialized
INFO - 2017-06-19 17:24:20 --> Loader Class Initialized
INFO - 2017-06-19 17:24:20 --> Controller Class Initialized
INFO - 2017-06-19 17:24:20 --> Database Driver Class Initialized
INFO - 2017-06-19 17:24:20 --> Model Class Initialized
INFO - 2017-06-19 17:24:20 --> Helper loaded: form_helper
INFO - 2017-06-19 17:24:20 --> Helper loaded: url_helper
INFO - 2017-06-19 17:24:20 --> Upload Class Initialized
INFO - 2017-06-19 17:24:20 --> Final output sent to browser
DEBUG - 2017-06-19 17:24:20 --> Total execution time: 0.0830
ERROR - 2017-06-19 17:24:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:24:20 --> Config Class Initialized
INFO - 2017-06-19 17:24:20 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:24:20 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:24:20 --> Utf8 Class Initialized
INFO - 2017-06-19 17:24:20 --> URI Class Initialized
INFO - 2017-06-19 17:24:20 --> Router Class Initialized
INFO - 2017-06-19 17:24:20 --> Output Class Initialized
INFO - 2017-06-19 17:24:20 --> Security Class Initialized
DEBUG - 2017-06-19 17:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:24:20 --> Input Class Initialized
INFO - 2017-06-19 17:24:20 --> Language Class Initialized
INFO - 2017-06-19 17:24:20 --> Loader Class Initialized
INFO - 2017-06-19 17:24:20 --> Controller Class Initialized
INFO - 2017-06-19 17:24:20 --> Database Driver Class Initialized
INFO - 2017-06-19 17:24:20 --> Model Class Initialized
INFO - 2017-06-19 17:24:20 --> Helper loaded: form_helper
INFO - 2017-06-19 17:24:20 --> Helper loaded: url_helper
INFO - 2017-06-19 17:24:20 --> Upload Class Initialized
INFO - 2017-06-19 17:24:20 --> Final output sent to browser
DEBUG - 2017-06-19 17:24:20 --> Total execution time: 0.0940
ERROR - 2017-06-19 17:24:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:24:31 --> Config Class Initialized
INFO - 2017-06-19 17:24:31 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:24:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:24:31 --> Utf8 Class Initialized
INFO - 2017-06-19 17:24:31 --> URI Class Initialized
INFO - 2017-06-19 17:24:31 --> Router Class Initialized
INFO - 2017-06-19 17:24:31 --> Output Class Initialized
INFO - 2017-06-19 17:24:31 --> Security Class Initialized
DEBUG - 2017-06-19 17:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:24:31 --> Input Class Initialized
INFO - 2017-06-19 17:24:31 --> Language Class Initialized
INFO - 2017-06-19 17:24:31 --> Loader Class Initialized
INFO - 2017-06-19 17:24:31 --> Controller Class Initialized
INFO - 2017-06-19 17:24:31 --> Database Driver Class Initialized
INFO - 2017-06-19 17:24:31 --> Model Class Initialized
INFO - 2017-06-19 17:24:31 --> Helper loaded: form_helper
INFO - 2017-06-19 17:24:31 --> Helper loaded: url_helper
INFO - 2017-06-19 17:24:31 --> Upload Class Initialized
INFO - 2017-06-19 17:24:31 --> Final output sent to browser
DEBUG - 2017-06-19 17:24:31 --> Total execution time: 0.0930
ERROR - 2017-06-19 17:24:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:24:32 --> Config Class Initialized
INFO - 2017-06-19 17:24:32 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:24:32 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:24:32 --> Utf8 Class Initialized
INFO - 2017-06-19 17:24:32 --> URI Class Initialized
INFO - 2017-06-19 17:24:32 --> Router Class Initialized
INFO - 2017-06-19 17:24:32 --> Output Class Initialized
INFO - 2017-06-19 17:24:32 --> Security Class Initialized
DEBUG - 2017-06-19 17:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:24:32 --> Input Class Initialized
INFO - 2017-06-19 17:24:32 --> Language Class Initialized
INFO - 2017-06-19 17:24:32 --> Loader Class Initialized
INFO - 2017-06-19 17:24:32 --> Controller Class Initialized
INFO - 2017-06-19 17:24:32 --> Database Driver Class Initialized
INFO - 2017-06-19 17:24:32 --> Model Class Initialized
INFO - 2017-06-19 17:24:32 --> Helper loaded: form_helper
INFO - 2017-06-19 17:24:32 --> Helper loaded: url_helper
INFO - 2017-06-19 17:24:32 --> Upload Class Initialized
INFO - 2017-06-19 17:24:32 --> Final output sent to browser
DEBUG - 2017-06-19 17:24:32 --> Total execution time: 0.1170
ERROR - 2017-06-19 17:24:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:24:34 --> Config Class Initialized
INFO - 2017-06-19 17:24:34 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:24:34 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:24:34 --> Utf8 Class Initialized
INFO - 2017-06-19 17:24:34 --> URI Class Initialized
INFO - 2017-06-19 17:24:34 --> Router Class Initialized
INFO - 2017-06-19 17:24:34 --> Output Class Initialized
INFO - 2017-06-19 17:24:34 --> Security Class Initialized
DEBUG - 2017-06-19 17:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:24:34 --> Input Class Initialized
INFO - 2017-06-19 17:24:34 --> Language Class Initialized
INFO - 2017-06-19 17:24:34 --> Loader Class Initialized
INFO - 2017-06-19 17:24:34 --> Controller Class Initialized
INFO - 2017-06-19 17:24:34 --> Database Driver Class Initialized
INFO - 2017-06-19 17:24:34 --> Model Class Initialized
INFO - 2017-06-19 17:24:34 --> Helper loaded: form_helper
INFO - 2017-06-19 17:24:34 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:24:34 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:24:34 --> Upload Class Initialized
INFO - 2017-06-19 17:24:34 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:24:34 --> You did not select a file to upload.
INFO - 2017-06-19 17:24:34 --> Final output sent to browser
DEBUG - 2017-06-19 17:24:34 --> Total execution time: 0.0890
ERROR - 2017-06-19 17:24:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:24:34 --> Config Class Initialized
INFO - 2017-06-19 17:24:34 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:24:34 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:24:34 --> Utf8 Class Initialized
INFO - 2017-06-19 17:24:34 --> URI Class Initialized
INFO - 2017-06-19 17:24:34 --> Router Class Initialized
INFO - 2017-06-19 17:24:34 --> Output Class Initialized
INFO - 2017-06-19 17:24:34 --> Security Class Initialized
DEBUG - 2017-06-19 17:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:24:34 --> Input Class Initialized
INFO - 2017-06-19 17:24:34 --> Language Class Initialized
INFO - 2017-06-19 17:24:34 --> Loader Class Initialized
INFO - 2017-06-19 17:24:34 --> Controller Class Initialized
INFO - 2017-06-19 17:24:34 --> Database Driver Class Initialized
INFO - 2017-06-19 17:24:34 --> Model Class Initialized
INFO - 2017-06-19 17:24:34 --> Helper loaded: form_helper
INFO - 2017-06-19 17:24:34 --> Helper loaded: url_helper
INFO - 2017-06-19 17:24:34 --> Upload Class Initialized
INFO - 2017-06-19 17:24:34 --> Final output sent to browser
DEBUG - 2017-06-19 17:24:34 --> Total execution time: 0.0845
ERROR - 2017-06-19 17:24:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:24:34 --> Config Class Initialized
INFO - 2017-06-19 17:24:34 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:24:34 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:24:34 --> Utf8 Class Initialized
INFO - 2017-06-19 17:24:34 --> URI Class Initialized
INFO - 2017-06-19 17:24:34 --> Router Class Initialized
INFO - 2017-06-19 17:24:34 --> Output Class Initialized
INFO - 2017-06-19 17:24:34 --> Security Class Initialized
DEBUG - 2017-06-19 17:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:24:34 --> Input Class Initialized
INFO - 2017-06-19 17:24:34 --> Language Class Initialized
INFO - 2017-06-19 17:24:34 --> Loader Class Initialized
INFO - 2017-06-19 17:24:34 --> Controller Class Initialized
INFO - 2017-06-19 17:24:34 --> Database Driver Class Initialized
INFO - 2017-06-19 17:24:34 --> Model Class Initialized
INFO - 2017-06-19 17:24:34 --> Helper loaded: form_helper
INFO - 2017-06-19 17:24:34 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:24:34 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:24:34 --> Upload Class Initialized
INFO - 2017-06-19 17:24:34 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:24:34 --> You did not select a file to upload.
INFO - 2017-06-19 17:24:34 --> Final output sent to browser
DEBUG - 2017-06-19 17:24:34 --> Total execution time: 0.0645
ERROR - 2017-06-19 17:24:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:24:34 --> Config Class Initialized
INFO - 2017-06-19 17:24:34 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:24:34 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:24:34 --> Utf8 Class Initialized
INFO - 2017-06-19 17:24:34 --> URI Class Initialized
INFO - 2017-06-19 17:24:34 --> Router Class Initialized
INFO - 2017-06-19 17:24:34 --> Output Class Initialized
INFO - 2017-06-19 17:24:34 --> Security Class Initialized
DEBUG - 2017-06-19 17:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:24:34 --> Input Class Initialized
INFO - 2017-06-19 17:24:34 --> Language Class Initialized
INFO - 2017-06-19 17:24:34 --> Loader Class Initialized
INFO - 2017-06-19 17:24:34 --> Controller Class Initialized
INFO - 2017-06-19 17:24:34 --> Database Driver Class Initialized
INFO - 2017-06-19 17:24:34 --> Model Class Initialized
INFO - 2017-06-19 17:24:34 --> Helper loaded: form_helper
INFO - 2017-06-19 17:24:34 --> Helper loaded: url_helper
INFO - 2017-06-19 17:24:34 --> Upload Class Initialized
INFO - 2017-06-19 17:24:34 --> Final output sent to browser
DEBUG - 2017-06-19 17:24:34 --> Total execution time: 0.0750
ERROR - 2017-06-19 17:24:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:24:49 --> Config Class Initialized
INFO - 2017-06-19 17:24:49 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:24:49 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:24:49 --> Utf8 Class Initialized
INFO - 2017-06-19 17:24:49 --> URI Class Initialized
INFO - 2017-06-19 17:24:49 --> Router Class Initialized
INFO - 2017-06-19 17:24:49 --> Output Class Initialized
INFO - 2017-06-19 17:24:49 --> Security Class Initialized
DEBUG - 2017-06-19 17:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:24:49 --> Input Class Initialized
INFO - 2017-06-19 17:24:49 --> Language Class Initialized
INFO - 2017-06-19 17:24:49 --> Loader Class Initialized
INFO - 2017-06-19 17:24:49 --> Controller Class Initialized
INFO - 2017-06-19 17:24:49 --> Database Driver Class Initialized
INFO - 2017-06-19 17:24:49 --> Model Class Initialized
INFO - 2017-06-19 17:24:49 --> Helper loaded: form_helper
INFO - 2017-06-19 17:24:49 --> Helper loaded: url_helper
INFO - 2017-06-19 17:24:49 --> Upload Class Initialized
INFO - 2017-06-19 17:24:49 --> Final output sent to browser
DEBUG - 2017-06-19 17:24:49 --> Total execution time: 0.0720
ERROR - 2017-06-19 17:24:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:24:58 --> Config Class Initialized
INFO - 2017-06-19 17:24:58 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:24:58 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:24:58 --> Utf8 Class Initialized
INFO - 2017-06-19 17:24:58 --> URI Class Initialized
INFO - 2017-06-19 17:24:58 --> Router Class Initialized
INFO - 2017-06-19 17:24:58 --> Output Class Initialized
INFO - 2017-06-19 17:24:58 --> Security Class Initialized
DEBUG - 2017-06-19 17:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:24:58 --> Input Class Initialized
INFO - 2017-06-19 17:24:58 --> Language Class Initialized
INFO - 2017-06-19 17:24:58 --> Loader Class Initialized
INFO - 2017-06-19 17:24:58 --> Controller Class Initialized
INFO - 2017-06-19 17:24:58 --> Database Driver Class Initialized
INFO - 2017-06-19 17:24:58 --> Model Class Initialized
INFO - 2017-06-19 17:24:58 --> Helper loaded: form_helper
INFO - 2017-06-19 17:24:58 --> Helper loaded: url_helper
INFO - 2017-06-19 17:24:58 --> Upload Class Initialized
INFO - 2017-06-19 17:24:58 --> Final output sent to browser
DEBUG - 2017-06-19 17:24:58 --> Total execution time: 0.0600
ERROR - 2017-06-19 17:24:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:24:59 --> Config Class Initialized
INFO - 2017-06-19 17:24:59 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:24:59 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:24:59 --> Utf8 Class Initialized
INFO - 2017-06-19 17:24:59 --> URI Class Initialized
INFO - 2017-06-19 17:24:59 --> Router Class Initialized
INFO - 2017-06-19 17:24:59 --> Output Class Initialized
INFO - 2017-06-19 17:24:59 --> Security Class Initialized
DEBUG - 2017-06-19 17:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:24:59 --> Input Class Initialized
INFO - 2017-06-19 17:24:59 --> Language Class Initialized
INFO - 2017-06-19 17:24:59 --> Loader Class Initialized
INFO - 2017-06-19 17:24:59 --> Controller Class Initialized
INFO - 2017-06-19 17:24:59 --> Database Driver Class Initialized
INFO - 2017-06-19 17:24:59 --> Model Class Initialized
INFO - 2017-06-19 17:24:59 --> Helper loaded: form_helper
INFO - 2017-06-19 17:24:59 --> Helper loaded: url_helper
INFO - 2017-06-19 17:24:59 --> Upload Class Initialized
INFO - 2017-06-19 17:24:59 --> Final output sent to browser
DEBUG - 2017-06-19 17:24:59 --> Total execution time: 0.0640
ERROR - 2017-06-19 17:28:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:28:57 --> Config Class Initialized
INFO - 2017-06-19 17:28:57 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:28:57 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:28:57 --> Utf8 Class Initialized
INFO - 2017-06-19 17:28:57 --> URI Class Initialized
INFO - 2017-06-19 17:28:57 --> Router Class Initialized
INFO - 2017-06-19 17:28:57 --> Output Class Initialized
INFO - 2017-06-19 17:28:57 --> Security Class Initialized
DEBUG - 2017-06-19 17:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:28:57 --> Input Class Initialized
INFO - 2017-06-19 17:28:57 --> Language Class Initialized
INFO - 2017-06-19 17:28:57 --> Loader Class Initialized
INFO - 2017-06-19 17:28:57 --> Controller Class Initialized
INFO - 2017-06-19 17:28:57 --> Database Driver Class Initialized
INFO - 2017-06-19 17:28:57 --> Model Class Initialized
INFO - 2017-06-19 17:28:57 --> Helper loaded: form_helper
INFO - 2017-06-19 17:28:57 --> Helper loaded: url_helper
INFO - 2017-06-19 17:28:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:28:57 --> Model Class Initialized
INFO - 2017-06-19 17:28:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:28:57 --> Final output sent to browser
DEBUG - 2017-06-19 17:28:57 --> Total execution time: 0.0550
ERROR - 2017-06-19 17:29:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:29:29 --> Config Class Initialized
INFO - 2017-06-19 17:29:29 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:29:29 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:29:29 --> Utf8 Class Initialized
INFO - 2017-06-19 17:29:29 --> URI Class Initialized
INFO - 2017-06-19 17:29:29 --> Router Class Initialized
INFO - 2017-06-19 17:29:29 --> Output Class Initialized
INFO - 2017-06-19 17:29:29 --> Security Class Initialized
DEBUG - 2017-06-19 17:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:29:29 --> Input Class Initialized
INFO - 2017-06-19 17:29:29 --> Language Class Initialized
INFO - 2017-06-19 17:29:29 --> Loader Class Initialized
INFO - 2017-06-19 17:29:29 --> Controller Class Initialized
INFO - 2017-06-19 17:29:29 --> Database Driver Class Initialized
INFO - 2017-06-19 17:29:29 --> Model Class Initialized
INFO - 2017-06-19 17:29:29 --> Helper loaded: form_helper
INFO - 2017-06-19 17:29:29 --> Helper loaded: url_helper
INFO - 2017-06-19 17:29:29 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:29:29 --> Model Class Initialized
INFO - 2017-06-19 17:29:29 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:29:29 --> Final output sent to browser
DEBUG - 2017-06-19 17:29:29 --> Total execution time: 0.0720
ERROR - 2017-06-19 17:29:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:29:51 --> Config Class Initialized
INFO - 2017-06-19 17:29:51 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:29:51 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:29:51 --> Utf8 Class Initialized
INFO - 2017-06-19 17:29:51 --> URI Class Initialized
INFO - 2017-06-19 17:29:51 --> Router Class Initialized
INFO - 2017-06-19 17:29:51 --> Output Class Initialized
INFO - 2017-06-19 17:29:51 --> Security Class Initialized
DEBUG - 2017-06-19 17:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:29:51 --> Input Class Initialized
INFO - 2017-06-19 17:29:51 --> Language Class Initialized
INFO - 2017-06-19 17:29:51 --> Loader Class Initialized
INFO - 2017-06-19 17:29:51 --> Controller Class Initialized
INFO - 2017-06-19 17:29:51 --> Database Driver Class Initialized
INFO - 2017-06-19 17:29:51 --> Model Class Initialized
INFO - 2017-06-19 17:29:51 --> Helper loaded: form_helper
INFO - 2017-06-19 17:29:51 --> Helper loaded: url_helper
INFO - 2017-06-19 17:29:51 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:29:51 --> Model Class Initialized
INFO - 2017-06-19 17:29:51 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:29:52 --> Final output sent to browser
DEBUG - 2017-06-19 17:29:52 --> Total execution time: 0.0850
ERROR - 2017-06-19 17:30:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:30:05 --> Config Class Initialized
INFO - 2017-06-19 17:30:05 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:30:05 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:30:05 --> Utf8 Class Initialized
INFO - 2017-06-19 17:30:05 --> URI Class Initialized
INFO - 2017-06-19 17:30:05 --> Router Class Initialized
INFO - 2017-06-19 17:30:05 --> Output Class Initialized
INFO - 2017-06-19 17:30:05 --> Security Class Initialized
DEBUG - 2017-06-19 17:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:30:05 --> Input Class Initialized
INFO - 2017-06-19 17:30:05 --> Language Class Initialized
INFO - 2017-06-19 17:30:05 --> Loader Class Initialized
INFO - 2017-06-19 17:30:05 --> Controller Class Initialized
INFO - 2017-06-19 17:30:05 --> Database Driver Class Initialized
INFO - 2017-06-19 17:30:05 --> Model Class Initialized
INFO - 2017-06-19 17:30:05 --> Helper loaded: form_helper
INFO - 2017-06-19 17:30:05 --> Helper loaded: url_helper
INFO - 2017-06-19 17:30:05 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:30:05 --> Model Class Initialized
INFO - 2017-06-19 17:30:05 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:30:05 --> Final output sent to browser
DEBUG - 2017-06-19 17:30:05 --> Total execution time: 0.0620
ERROR - 2017-06-19 17:30:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:30:09 --> Config Class Initialized
INFO - 2017-06-19 17:30:09 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:30:09 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:30:09 --> Utf8 Class Initialized
INFO - 2017-06-19 17:30:09 --> URI Class Initialized
INFO - 2017-06-19 17:30:09 --> Router Class Initialized
INFO - 2017-06-19 17:30:09 --> Output Class Initialized
INFO - 2017-06-19 17:30:09 --> Security Class Initialized
DEBUG - 2017-06-19 17:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:30:09 --> Input Class Initialized
INFO - 2017-06-19 17:30:09 --> Language Class Initialized
INFO - 2017-06-19 17:30:09 --> Loader Class Initialized
INFO - 2017-06-19 17:30:09 --> Controller Class Initialized
INFO - 2017-06-19 17:30:09 --> Database Driver Class Initialized
INFO - 2017-06-19 17:30:10 --> Model Class Initialized
INFO - 2017-06-19 17:30:10 --> Helper loaded: form_helper
INFO - 2017-06-19 17:30:10 --> Helper loaded: url_helper
INFO - 2017-06-19 17:30:10 --> Upload Class Initialized
INFO - 2017-06-19 17:30:10 --> Final output sent to browser
DEBUG - 2017-06-19 17:30:10 --> Total execution time: 0.0650
ERROR - 2017-06-19 17:30:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:30:14 --> Config Class Initialized
INFO - 2017-06-19 17:30:14 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:30:14 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:30:15 --> Utf8 Class Initialized
INFO - 2017-06-19 17:30:15 --> URI Class Initialized
INFO - 2017-06-19 17:30:15 --> Router Class Initialized
INFO - 2017-06-19 17:30:15 --> Output Class Initialized
INFO - 2017-06-19 17:30:15 --> Security Class Initialized
DEBUG - 2017-06-19 17:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:30:15 --> Input Class Initialized
INFO - 2017-06-19 17:30:15 --> Language Class Initialized
INFO - 2017-06-19 17:30:15 --> Loader Class Initialized
INFO - 2017-06-19 17:30:15 --> Controller Class Initialized
INFO - 2017-06-19 17:30:15 --> Database Driver Class Initialized
INFO - 2017-06-19 17:30:15 --> Model Class Initialized
INFO - 2017-06-19 17:30:15 --> Helper loaded: form_helper
INFO - 2017-06-19 17:30:15 --> Helper loaded: url_helper
INFO - 2017-06-19 17:30:15 --> Upload Class Initialized
INFO - 2017-06-19 17:30:15 --> Final output sent to browser
DEBUG - 2017-06-19 17:30:15 --> Total execution time: 0.0840
ERROR - 2017-06-19 17:30:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:30:15 --> Config Class Initialized
INFO - 2017-06-19 17:30:15 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:30:15 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:30:15 --> Utf8 Class Initialized
INFO - 2017-06-19 17:30:15 --> URI Class Initialized
INFO - 2017-06-19 17:30:15 --> Router Class Initialized
INFO - 2017-06-19 17:30:15 --> Output Class Initialized
INFO - 2017-06-19 17:30:15 --> Security Class Initialized
DEBUG - 2017-06-19 17:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:30:15 --> Input Class Initialized
INFO - 2017-06-19 17:30:15 --> Language Class Initialized
INFO - 2017-06-19 17:30:15 --> Loader Class Initialized
INFO - 2017-06-19 17:30:15 --> Controller Class Initialized
INFO - 2017-06-19 17:30:15 --> Database Driver Class Initialized
INFO - 2017-06-19 17:30:15 --> Model Class Initialized
INFO - 2017-06-19 17:30:15 --> Helper loaded: form_helper
INFO - 2017-06-19 17:30:15 --> Helper loaded: url_helper
INFO - 2017-06-19 17:30:15 --> Upload Class Initialized
INFO - 2017-06-19 17:30:15 --> Final output sent to browser
DEBUG - 2017-06-19 17:30:15 --> Total execution time: 0.0790
ERROR - 2017-06-19 17:30:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:30:15 --> Config Class Initialized
INFO - 2017-06-19 17:30:15 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:30:15 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:30:15 --> Utf8 Class Initialized
INFO - 2017-06-19 17:30:15 --> URI Class Initialized
INFO - 2017-06-19 17:30:15 --> Router Class Initialized
INFO - 2017-06-19 17:30:15 --> Output Class Initialized
INFO - 2017-06-19 17:30:15 --> Security Class Initialized
DEBUG - 2017-06-19 17:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:30:15 --> Input Class Initialized
INFO - 2017-06-19 17:30:15 --> Language Class Initialized
INFO - 2017-06-19 17:30:15 --> Loader Class Initialized
INFO - 2017-06-19 17:30:15 --> Controller Class Initialized
INFO - 2017-06-19 17:30:15 --> Database Driver Class Initialized
INFO - 2017-06-19 17:30:15 --> Model Class Initialized
ERROR - 2017-06-19 17:30:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:30:15 --> Helper loaded: form_helper
INFO - 2017-06-19 17:30:15 --> Config Class Initialized
INFO - 2017-06-19 17:30:15 --> Helper loaded: url_helper
INFO - 2017-06-19 17:30:15 --> Hooks Class Initialized
INFO - 2017-06-19 17:30:15 --> Upload Class Initialized
DEBUG - 2017-06-19 17:30:15 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:30:15 --> Utf8 Class Initialized
INFO - 2017-06-19 17:30:15 --> URI Class Initialized
INFO - 2017-06-19 17:30:15 --> Router Class Initialized
INFO - 2017-06-19 17:30:15 --> Final output sent to browser
INFO - 2017-06-19 17:30:15 --> Output Class Initialized
DEBUG - 2017-06-19 17:30:15 --> Total execution time: 0.1040
INFO - 2017-06-19 17:30:15 --> Security Class Initialized
DEBUG - 2017-06-19 17:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:30:15 --> Input Class Initialized
INFO - 2017-06-19 17:30:15 --> Language Class Initialized
INFO - 2017-06-19 17:30:15 --> Loader Class Initialized
INFO - 2017-06-19 17:30:15 --> Controller Class Initialized
INFO - 2017-06-19 17:30:15 --> Database Driver Class Initialized
INFO - 2017-06-19 17:30:15 --> Model Class Initialized
INFO - 2017-06-19 17:30:15 --> Helper loaded: form_helper
INFO - 2017-06-19 17:30:15 --> Helper loaded: url_helper
INFO - 2017-06-19 17:30:15 --> Upload Class Initialized
INFO - 2017-06-19 17:30:15 --> Final output sent to browser
DEBUG - 2017-06-19 17:30:15 --> Total execution time: 0.0950
ERROR - 2017-06-19 17:30:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:30:15 --> Config Class Initialized
INFO - 2017-06-19 17:30:15 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:30:15 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:30:15 --> Utf8 Class Initialized
INFO - 2017-06-19 17:30:15 --> URI Class Initialized
INFO - 2017-06-19 17:30:15 --> Router Class Initialized
INFO - 2017-06-19 17:30:15 --> Output Class Initialized
INFO - 2017-06-19 17:30:15 --> Security Class Initialized
DEBUG - 2017-06-19 17:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:30:15 --> Input Class Initialized
INFO - 2017-06-19 17:30:15 --> Language Class Initialized
INFO - 2017-06-19 17:30:15 --> Loader Class Initialized
INFO - 2017-06-19 17:30:15 --> Controller Class Initialized
INFO - 2017-06-19 17:30:15 --> Database Driver Class Initialized
INFO - 2017-06-19 17:30:15 --> Model Class Initialized
INFO - 2017-06-19 17:30:15 --> Helper loaded: form_helper
INFO - 2017-06-19 17:30:15 --> Helper loaded: url_helper
INFO - 2017-06-19 17:30:15 --> Upload Class Initialized
INFO - 2017-06-19 17:30:15 --> Final output sent to browser
DEBUG - 2017-06-19 17:30:15 --> Total execution time: 0.0860
ERROR - 2017-06-19 17:30:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:30:15 --> Config Class Initialized
INFO - 2017-06-19 17:30:15 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:30:15 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:30:15 --> Utf8 Class Initialized
INFO - 2017-06-19 17:30:15 --> URI Class Initialized
INFO - 2017-06-19 17:30:15 --> Router Class Initialized
INFO - 2017-06-19 17:30:15 --> Output Class Initialized
INFO - 2017-06-19 17:30:15 --> Security Class Initialized
DEBUG - 2017-06-19 17:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:30:15 --> Input Class Initialized
INFO - 2017-06-19 17:30:15 --> Language Class Initialized
INFO - 2017-06-19 17:30:15 --> Loader Class Initialized
INFO - 2017-06-19 17:30:15 --> Controller Class Initialized
INFO - 2017-06-19 17:30:15 --> Database Driver Class Initialized
INFO - 2017-06-19 17:30:15 --> Model Class Initialized
INFO - 2017-06-19 17:30:15 --> Helper loaded: form_helper
INFO - 2017-06-19 17:30:15 --> Helper loaded: url_helper
INFO - 2017-06-19 17:30:15 --> Upload Class Initialized
INFO - 2017-06-19 17:30:15 --> Final output sent to browser
DEBUG - 2017-06-19 17:30:15 --> Total execution time: 0.0840
ERROR - 2017-06-19 17:30:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:30:16 --> Config Class Initialized
INFO - 2017-06-19 17:30:16 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:30:16 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:30:16 --> Utf8 Class Initialized
INFO - 2017-06-19 17:30:16 --> URI Class Initialized
INFO - 2017-06-19 17:30:16 --> Router Class Initialized
INFO - 2017-06-19 17:30:16 --> Output Class Initialized
INFO - 2017-06-19 17:30:16 --> Security Class Initialized
DEBUG - 2017-06-19 17:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:30:16 --> Input Class Initialized
INFO - 2017-06-19 17:30:16 --> Language Class Initialized
INFO - 2017-06-19 17:30:16 --> Loader Class Initialized
INFO - 2017-06-19 17:30:16 --> Controller Class Initialized
INFO - 2017-06-19 17:30:16 --> Database Driver Class Initialized
INFO - 2017-06-19 17:30:16 --> Model Class Initialized
INFO - 2017-06-19 17:30:16 --> Helper loaded: form_helper
INFO - 2017-06-19 17:30:16 --> Helper loaded: url_helper
INFO - 2017-06-19 17:30:16 --> Upload Class Initialized
INFO - 2017-06-19 17:30:16 --> Final output sent to browser
DEBUG - 2017-06-19 17:30:16 --> Total execution time: 0.1440
ERROR - 2017-06-19 17:30:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:30:16 --> Config Class Initialized
INFO - 2017-06-19 17:30:16 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:30:16 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:30:16 --> Utf8 Class Initialized
INFO - 2017-06-19 17:30:16 --> URI Class Initialized
INFO - 2017-06-19 17:30:16 --> Router Class Initialized
INFO - 2017-06-19 17:30:16 --> Output Class Initialized
INFO - 2017-06-19 17:30:16 --> Security Class Initialized
DEBUG - 2017-06-19 17:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:30:16 --> Input Class Initialized
ERROR - 2017-06-19 17:30:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:30:16 --> Language Class Initialized
INFO - 2017-06-19 17:30:16 --> Config Class Initialized
INFO - 2017-06-19 17:30:16 --> Loader Class Initialized
INFO - 2017-06-19 17:30:16 --> Hooks Class Initialized
INFO - 2017-06-19 17:30:16 --> Controller Class Initialized
DEBUG - 2017-06-19 17:30:16 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:30:16 --> Utf8 Class Initialized
INFO - 2017-06-19 17:30:16 --> URI Class Initialized
INFO - 2017-06-19 17:30:16 --> Database Driver Class Initialized
INFO - 2017-06-19 17:30:16 --> Router Class Initialized
INFO - 2017-06-19 17:30:16 --> Output Class Initialized
INFO - 2017-06-19 17:30:16 --> Security Class Initialized
DEBUG - 2017-06-19 17:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:30:16 --> Input Class Initialized
INFO - 2017-06-19 17:30:16 --> Model Class Initialized
INFO - 2017-06-19 17:30:16 --> Language Class Initialized
INFO - 2017-06-19 17:30:16 --> Helper loaded: form_helper
INFO - 2017-06-19 17:30:16 --> Helper loaded: url_helper
INFO - 2017-06-19 17:30:16 --> Upload Class Initialized
INFO - 2017-06-19 17:30:16 --> Final output sent to browser
DEBUG - 2017-06-19 17:30:16 --> Total execution time: 0.1550
INFO - 2017-06-19 17:30:16 --> Loader Class Initialized
INFO - 2017-06-19 17:30:16 --> Controller Class Initialized
INFO - 2017-06-19 17:30:16 --> Database Driver Class Initialized
INFO - 2017-06-19 17:30:16 --> Model Class Initialized
INFO - 2017-06-19 17:30:16 --> Helper loaded: form_helper
INFO - 2017-06-19 17:30:16 --> Helper loaded: url_helper
INFO - 2017-06-19 17:30:16 --> Upload Class Initialized
INFO - 2017-06-19 17:30:17 --> Final output sent to browser
DEBUG - 2017-06-19 17:30:17 --> Total execution time: 0.4865
ERROR - 2017-06-19 17:30:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:30:17 --> Config Class Initialized
INFO - 2017-06-19 17:30:17 --> Hooks Class Initialized
ERROR - 2017-06-19 17:30:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:30:17 --> Config Class Initialized
INFO - 2017-06-19 17:30:17 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:30:17 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:30:17 --> Utf8 Class Initialized
INFO - 2017-06-19 17:30:17 --> URI Class Initialized
INFO - 2017-06-19 17:30:17 --> Router Class Initialized
INFO - 2017-06-19 17:30:17 --> Output Class Initialized
INFO - 2017-06-19 17:30:17 --> Security Class Initialized
DEBUG - 2017-06-19 17:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:30:17 --> Input Class Initialized
INFO - 2017-06-19 17:30:17 --> Language Class Initialized
INFO - 2017-06-19 17:30:18 --> Loader Class Initialized
INFO - 2017-06-19 17:30:18 --> Controller Class Initialized
INFO - 2017-06-19 17:30:18 --> Database Driver Class Initialized
INFO - 2017-06-19 17:30:18 --> Model Class Initialized
INFO - 2017-06-19 17:30:18 --> Helper loaded: form_helper
INFO - 2017-06-19 17:30:18 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:30:18 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
DEBUG - 2017-06-19 17:30:18 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:30:18 --> Utf8 Class Initialized
INFO - 2017-06-19 17:30:18 --> URI Class Initialized
INFO - 2017-06-19 17:30:18 --> Router Class Initialized
INFO - 2017-06-19 17:30:18 --> Output Class Initialized
INFO - 2017-06-19 17:30:18 --> Security Class Initialized
INFO - 2017-06-19 17:30:18 --> Upload Class Initialized
DEBUG - 2017-06-19 17:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:30:18 --> Input Class Initialized
INFO - 2017-06-19 17:30:18 --> Language Class Initialized
INFO - 2017-06-19 17:30:18 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:30:18 --> You did not select a file to upload.
INFO - 2017-06-19 17:30:18 --> Final output sent to browser
DEBUG - 2017-06-19 17:30:18 --> Total execution time: 0.7000
INFO - 2017-06-19 17:30:18 --> Loader Class Initialized
INFO - 2017-06-19 17:30:18 --> Controller Class Initialized
INFO - 2017-06-19 17:30:18 --> Database Driver Class Initialized
INFO - 2017-06-19 17:30:18 --> Model Class Initialized
INFO - 2017-06-19 17:30:18 --> Helper loaded: form_helper
INFO - 2017-06-19 17:30:18 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:30:18 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:30:18 --> Upload Class Initialized
INFO - 2017-06-19 17:30:18 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:30:18 --> You did not select a file to upload.
INFO - 2017-06-19 17:30:18 --> Final output sent to browser
DEBUG - 2017-06-19 17:30:18 --> Total execution time: 0.7440
ERROR - 2017-06-19 17:30:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:30:19 --> Config Class Initialized
INFO - 2017-06-19 17:30:19 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:30:19 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:30:19 --> Utf8 Class Initialized
INFO - 2017-06-19 17:30:19 --> URI Class Initialized
INFO - 2017-06-19 17:30:19 --> Router Class Initialized
INFO - 2017-06-19 17:30:19 --> Output Class Initialized
INFO - 2017-06-19 17:30:19 --> Security Class Initialized
DEBUG - 2017-06-19 17:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:30:19 --> Input Class Initialized
INFO - 2017-06-19 17:30:19 --> Language Class Initialized
INFO - 2017-06-19 17:30:19 --> Loader Class Initialized
INFO - 2017-06-19 17:30:19 --> Controller Class Initialized
INFO - 2017-06-19 17:30:19 --> Database Driver Class Initialized
INFO - 2017-06-19 17:30:19 --> Model Class Initialized
INFO - 2017-06-19 17:30:19 --> Helper loaded: form_helper
INFO - 2017-06-19 17:30:19 --> Helper loaded: url_helper
INFO - 2017-06-19 17:30:19 --> Upload Class Initialized
INFO - 2017-06-19 17:30:19 --> Final output sent to browser
DEBUG - 2017-06-19 17:30:19 --> Total execution time: 0.0760
ERROR - 2017-06-19 17:30:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:30:20 --> Config Class Initialized
INFO - 2017-06-19 17:30:20 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:30:20 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:30:20 --> Utf8 Class Initialized
INFO - 2017-06-19 17:30:20 --> URI Class Initialized
INFO - 2017-06-19 17:30:20 --> Router Class Initialized
INFO - 2017-06-19 17:30:20 --> Output Class Initialized
INFO - 2017-06-19 17:30:20 --> Security Class Initialized
DEBUG - 2017-06-19 17:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:30:20 --> Input Class Initialized
INFO - 2017-06-19 17:30:20 --> Language Class Initialized
INFO - 2017-06-19 17:30:20 --> Loader Class Initialized
INFO - 2017-06-19 17:30:20 --> Controller Class Initialized
INFO - 2017-06-19 17:30:20 --> Database Driver Class Initialized
INFO - 2017-06-19 17:30:20 --> Model Class Initialized
INFO - 2017-06-19 17:30:20 --> Helper loaded: form_helper
INFO - 2017-06-19 17:30:20 --> Helper loaded: url_helper
INFO - 2017-06-19 17:30:20 --> Upload Class Initialized
INFO - 2017-06-19 17:30:20 --> Final output sent to browser
DEBUG - 2017-06-19 17:30:20 --> Total execution time: 0.1320
ERROR - 2017-06-19 17:30:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:30:21 --> Config Class Initialized
INFO - 2017-06-19 17:30:21 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:30:21 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:30:21 --> Utf8 Class Initialized
INFO - 2017-06-19 17:30:21 --> URI Class Initialized
INFO - 2017-06-19 17:30:21 --> Router Class Initialized
INFO - 2017-06-19 17:30:21 --> Output Class Initialized
INFO - 2017-06-19 17:30:21 --> Security Class Initialized
DEBUG - 2017-06-19 17:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:30:21 --> Input Class Initialized
INFO - 2017-06-19 17:30:21 --> Language Class Initialized
INFO - 2017-06-19 17:30:21 --> Loader Class Initialized
INFO - 2017-06-19 17:30:21 --> Controller Class Initialized
INFO - 2017-06-19 17:30:21 --> Database Driver Class Initialized
INFO - 2017-06-19 17:30:21 --> Model Class Initialized
INFO - 2017-06-19 17:30:21 --> Helper loaded: form_helper
INFO - 2017-06-19 17:30:21 --> Helper loaded: url_helper
INFO - 2017-06-19 17:30:21 --> Upload Class Initialized
INFO - 2017-06-19 17:30:21 --> Final output sent to browser
DEBUG - 2017-06-19 17:30:21 --> Total execution time: 0.0560
ERROR - 2017-06-19 17:30:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:30:22 --> Config Class Initialized
INFO - 2017-06-19 17:30:22 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:30:22 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:30:22 --> Utf8 Class Initialized
INFO - 2017-06-19 17:30:22 --> URI Class Initialized
INFO - 2017-06-19 17:30:22 --> Router Class Initialized
INFO - 2017-06-19 17:30:22 --> Output Class Initialized
INFO - 2017-06-19 17:30:22 --> Security Class Initialized
DEBUG - 2017-06-19 17:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:30:22 --> Input Class Initialized
INFO - 2017-06-19 17:30:22 --> Language Class Initialized
INFO - 2017-06-19 17:30:22 --> Loader Class Initialized
INFO - 2017-06-19 17:30:22 --> Controller Class Initialized
INFO - 2017-06-19 17:30:22 --> Database Driver Class Initialized
INFO - 2017-06-19 17:30:22 --> Model Class Initialized
INFO - 2017-06-19 17:30:22 --> Helper loaded: form_helper
INFO - 2017-06-19 17:30:22 --> Helper loaded: url_helper
INFO - 2017-06-19 17:30:22 --> Upload Class Initialized
INFO - 2017-06-19 17:30:22 --> Final output sent to browser
DEBUG - 2017-06-19 17:30:22 --> Total execution time: 0.0570
ERROR - 2017-06-19 17:31:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:22 --> Config Class Initialized
INFO - 2017-06-19 17:31:22 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:31:22 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:22 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:22 --> URI Class Initialized
INFO - 2017-06-19 17:31:22 --> Router Class Initialized
INFO - 2017-06-19 17:31:22 --> Output Class Initialized
INFO - 2017-06-19 17:31:22 --> Security Class Initialized
DEBUG - 2017-06-19 17:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:22 --> Input Class Initialized
INFO - 2017-06-19 17:31:22 --> Language Class Initialized
INFO - 2017-06-19 17:31:22 --> Loader Class Initialized
INFO - 2017-06-19 17:31:22 --> Controller Class Initialized
INFO - 2017-06-19 17:31:22 --> Database Driver Class Initialized
INFO - 2017-06-19 17:31:22 --> Model Class Initialized
INFO - 2017-06-19 17:31:22 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:22 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:31:22 --> Model Class Initialized
INFO - 2017-06-19 17:31:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:31:22 --> Final output sent to browser
DEBUG - 2017-06-19 17:31:22 --> Total execution time: 0.0700
ERROR - 2017-06-19 17:31:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:27 --> Config Class Initialized
INFO - 2017-06-19 17:31:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:31:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:27 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:27 --> URI Class Initialized
INFO - 2017-06-19 17:31:27 --> Router Class Initialized
INFO - 2017-06-19 17:31:27 --> Output Class Initialized
INFO - 2017-06-19 17:31:27 --> Security Class Initialized
DEBUG - 2017-06-19 17:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:27 --> Input Class Initialized
INFO - 2017-06-19 17:31:27 --> Language Class Initialized
INFO - 2017-06-19 17:31:27 --> Loader Class Initialized
INFO - 2017-06-19 17:31:27 --> Controller Class Initialized
INFO - 2017-06-19 17:31:27 --> Database Driver Class Initialized
INFO - 2017-06-19 17:31:27 --> Model Class Initialized
INFO - 2017-06-19 17:31:27 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:27 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:27 --> Upload Class Initialized
INFO - 2017-06-19 17:31:27 --> Final output sent to browser
DEBUG - 2017-06-19 17:31:27 --> Total execution time: 0.0550
ERROR - 2017-06-19 17:31:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:31 --> Config Class Initialized
INFO - 2017-06-19 17:31:31 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:31:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:31 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:31 --> URI Class Initialized
INFO - 2017-06-19 17:31:31 --> Router Class Initialized
INFO - 2017-06-19 17:31:31 --> Output Class Initialized
ERROR - 2017-06-19 17:31:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:31 --> Security Class Initialized
DEBUG - 2017-06-19 17:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:31 --> Config Class Initialized
INFO - 2017-06-19 17:31:31 --> Input Class Initialized
INFO - 2017-06-19 17:31:31 --> Hooks Class Initialized
INFO - 2017-06-19 17:31:31 --> Language Class Initialized
DEBUG - 2017-06-19 17:31:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:31 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:31 --> Loader Class Initialized
INFO - 2017-06-19 17:31:31 --> URI Class Initialized
INFO - 2017-06-19 17:31:31 --> Controller Class Initialized
INFO - 2017-06-19 17:31:31 --> Router Class Initialized
INFO - 2017-06-19 17:31:31 --> Output Class Initialized
INFO - 2017-06-19 17:31:31 --> Security Class Initialized
INFO - 2017-06-19 17:31:31 --> Database Driver Class Initialized
INFO - 2017-06-19 17:31:31 --> Model Class Initialized
DEBUG - 2017-06-19 17:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:31 --> Input Class Initialized
INFO - 2017-06-19 17:31:31 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:31 --> Language Class Initialized
INFO - 2017-06-19 17:31:31 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:31 --> Upload Class Initialized
INFO - 2017-06-19 17:31:31 --> Final output sent to browser
DEBUG - 2017-06-19 17:31:31 --> Total execution time: 0.0970
INFO - 2017-06-19 17:31:31 --> Loader Class Initialized
INFO - 2017-06-19 17:31:31 --> Controller Class Initialized
INFO - 2017-06-19 17:31:31 --> Database Driver Class Initialized
ERROR - 2017-06-19 17:31:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:31 --> Config Class Initialized
INFO - 2017-06-19 17:31:32 --> Hooks Class Initialized
INFO - 2017-06-19 17:31:32 --> Model Class Initialized
DEBUG - 2017-06-19 17:31:32 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:32 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:32 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:32 --> URI Class Initialized
INFO - 2017-06-19 17:31:32 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:32 --> Router Class Initialized
INFO - 2017-06-19 17:31:32 --> Upload Class Initialized
INFO - 2017-06-19 17:31:32 --> Output Class Initialized
INFO - 2017-06-19 17:31:32 --> Security Class Initialized
DEBUG - 2017-06-19 17:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:32 --> Input Class Initialized
INFO - 2017-06-19 17:31:32 --> Final output sent to browser
INFO - 2017-06-19 17:31:32 --> Language Class Initialized
DEBUG - 2017-06-19 17:31:32 --> Total execution time: 0.1750
INFO - 2017-06-19 17:31:32 --> Loader Class Initialized
INFO - 2017-06-19 17:31:32 --> Controller Class Initialized
INFO - 2017-06-19 17:31:32 --> Database Driver Class Initialized
INFO - 2017-06-19 17:31:32 --> Model Class Initialized
INFO - 2017-06-19 17:31:32 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:32 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:32 --> Upload Class Initialized
INFO - 2017-06-19 17:31:32 --> Final output sent to browser
DEBUG - 2017-06-19 17:31:32 --> Total execution time: 0.1000
ERROR - 2017-06-19 17:31:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:32 --> Config Class Initialized
INFO - 2017-06-19 17:31:32 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:31:32 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:32 --> Utf8 Class Initialized
ERROR - 2017-06-19 17:31:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:32 --> URI Class Initialized
INFO - 2017-06-19 17:31:32 --> Config Class Initialized
INFO - 2017-06-19 17:31:32 --> Hooks Class Initialized
INFO - 2017-06-19 17:31:32 --> Router Class Initialized
INFO - 2017-06-19 17:31:32 --> Output Class Initialized
DEBUG - 2017-06-19 17:31:32 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:32 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:32 --> Security Class Initialized
INFO - 2017-06-19 17:31:32 --> URI Class Initialized
DEBUG - 2017-06-19 17:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:32 --> Input Class Initialized
INFO - 2017-06-19 17:31:32 --> Router Class Initialized
INFO - 2017-06-19 17:31:32 --> Language Class Initialized
INFO - 2017-06-19 17:31:32 --> Output Class Initialized
INFO - 2017-06-19 17:31:32 --> Security Class Initialized
INFO - 2017-06-19 17:31:32 --> Loader Class Initialized
INFO - 2017-06-19 17:31:32 --> Controller Class Initialized
DEBUG - 2017-06-19 17:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:32 --> Input Class Initialized
INFO - 2017-06-19 17:31:32 --> Language Class Initialized
INFO - 2017-06-19 17:31:32 --> Database Driver Class Initialized
INFO - 2017-06-19 17:31:32 --> Model Class Initialized
INFO - 2017-06-19 17:31:32 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:32 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:32 --> Upload Class Initialized
INFO - 2017-06-19 17:31:32 --> Final output sent to browser
DEBUG - 2017-06-19 17:31:32 --> Total execution time: 0.0490
INFO - 2017-06-19 17:31:32 --> Loader Class Initialized
INFO - 2017-06-19 17:31:32 --> Controller Class Initialized
INFO - 2017-06-19 17:31:32 --> Database Driver Class Initialized
INFO - 2017-06-19 17:31:32 --> Model Class Initialized
INFO - 2017-06-19 17:31:32 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:32 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:32 --> Upload Class Initialized
INFO - 2017-06-19 17:31:32 --> Final output sent to browser
DEBUG - 2017-06-19 17:31:32 --> Total execution time: 0.0790
ERROR - 2017-06-19 17:31:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:47 --> Config Class Initialized
INFO - 2017-06-19 17:31:47 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:31:47 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:47 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:47 --> URI Class Initialized
INFO - 2017-06-19 17:31:47 --> Router Class Initialized
INFO - 2017-06-19 17:31:47 --> Output Class Initialized
INFO - 2017-06-19 17:31:47 --> Security Class Initialized
DEBUG - 2017-06-19 17:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:47 --> Input Class Initialized
INFO - 2017-06-19 17:31:47 --> Language Class Initialized
INFO - 2017-06-19 17:31:47 --> Loader Class Initialized
INFO - 2017-06-19 17:31:47 --> Controller Class Initialized
INFO - 2017-06-19 17:31:47 --> Database Driver Class Initialized
INFO - 2017-06-19 17:31:47 --> Model Class Initialized
INFO - 2017-06-19 17:31:47 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:47 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:47 --> Upload Class Initialized
INFO - 2017-06-19 17:31:47 --> Final output sent to browser
DEBUG - 2017-06-19 17:31:47 --> Total execution time: 0.0740
ERROR - 2017-06-19 17:31:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:47 --> Config Class Initialized
INFO - 2017-06-19 17:31:47 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:31:47 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:47 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:47 --> URI Class Initialized
ERROR - 2017-06-19 17:31:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:47 --> Config Class Initialized
INFO - 2017-06-19 17:31:47 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:31:47 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:47 --> Router Class Initialized
INFO - 2017-06-19 17:31:47 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:47 --> URI Class Initialized
INFO - 2017-06-19 17:31:47 --> Output Class Initialized
INFO - 2017-06-19 17:31:47 --> Router Class Initialized
INFO - 2017-06-19 17:31:47 --> Security Class Initialized
INFO - 2017-06-19 17:31:47 --> Output Class Initialized
INFO - 2017-06-19 17:31:47 --> Security Class Initialized
DEBUG - 2017-06-19 17:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:47 --> Input Class Initialized
INFO - 2017-06-19 17:31:47 --> Language Class Initialized
INFO - 2017-06-19 17:31:47 --> Loader Class Initialized
DEBUG - 2017-06-19 17:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:47 --> Controller Class Initialized
INFO - 2017-06-19 17:31:47 --> Input Class Initialized
INFO - 2017-06-19 17:31:47 --> Language Class Initialized
INFO - 2017-06-19 17:31:47 --> Database Driver Class Initialized
INFO - 2017-06-19 17:31:48 --> Model Class Initialized
INFO - 2017-06-19 17:31:48 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:48 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:48 --> Upload Class Initialized
INFO - 2017-06-19 17:31:48 --> Final output sent to browser
DEBUG - 2017-06-19 17:31:48 --> Total execution time: 0.3060
INFO - 2017-06-19 17:31:48 --> Loader Class Initialized
INFO - 2017-06-19 17:31:48 --> Controller Class Initialized
INFO - 2017-06-19 17:31:48 --> Database Driver Class Initialized
ERROR - 2017-06-19 17:31:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:48 --> Model Class Initialized
INFO - 2017-06-19 17:31:48 --> Config Class Initialized
INFO - 2017-06-19 17:31:48 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:48 --> Hooks Class Initialized
INFO - 2017-06-19 17:31:48 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:48 --> Upload Class Initialized
DEBUG - 2017-06-19 17:31:48 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:48 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:48 --> URI Class Initialized
INFO - 2017-06-19 17:31:48 --> Final output sent to browser
ERROR - 2017-06-19 17:31:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
DEBUG - 2017-06-19 17:31:48 --> Total execution time: 0.5271
INFO - 2017-06-19 17:31:48 --> Router Class Initialized
INFO - 2017-06-19 17:31:48 --> Config Class Initialized
INFO - 2017-06-19 17:31:48 --> Output Class Initialized
INFO - 2017-06-19 17:31:48 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:31:48 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:48 --> Security Class Initialized
INFO - 2017-06-19 17:31:48 --> Utf8 Class Initialized
DEBUG - 2017-06-19 17:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:48 --> URI Class Initialized
INFO - 2017-06-19 17:31:48 --> Input Class Initialized
INFO - 2017-06-19 17:31:48 --> Router Class Initialized
INFO - 2017-06-19 17:31:48 --> Output Class Initialized
INFO - 2017-06-19 17:31:48 --> Language Class Initialized
INFO - 2017-06-19 17:31:48 --> Security Class Initialized
DEBUG - 2017-06-19 17:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:48 --> Loader Class Initialized
INFO - 2017-06-19 17:31:48 --> Input Class Initialized
INFO - 2017-06-19 17:31:48 --> Controller Class Initialized
INFO - 2017-06-19 17:31:48 --> Language Class Initialized
INFO - 2017-06-19 17:31:48 --> Database Driver Class Initialized
INFO - 2017-06-19 17:31:48 --> Model Class Initialized
INFO - 2017-06-19 17:31:48 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:48 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:48 --> Upload Class Initialized
ERROR - 2017-06-19 17:31:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:48 --> Config Class Initialized
INFO - 2017-06-19 17:31:48 --> Hooks Class Initialized
INFO - 2017-06-19 17:31:48 --> Final output sent to browser
DEBUG - 2017-06-19 17:31:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-19 17:31:48 --> Total execution time: 0.1335
INFO - 2017-06-19 17:31:48 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:48 --> URI Class Initialized
INFO - 2017-06-19 17:31:48 --> Loader Class Initialized
INFO - 2017-06-19 17:31:48 --> Controller Class Initialized
INFO - 2017-06-19 17:31:48 --> Router Class Initialized
INFO - 2017-06-19 17:31:48 --> Output Class Initialized
INFO - 2017-06-19 17:31:48 --> Security Class Initialized
INFO - 2017-06-19 17:31:48 --> Database Driver Class Initialized
DEBUG - 2017-06-19 17:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:48 --> Input Class Initialized
INFO - 2017-06-19 17:31:48 --> Language Class Initialized
INFO - 2017-06-19 17:31:48 --> Model Class Initialized
INFO - 2017-06-19 17:31:48 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:48 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:48 --> Upload Class Initialized
INFO - 2017-06-19 17:31:48 --> Final output sent to browser
DEBUG - 2017-06-19 17:31:48 --> Total execution time: 0.2180
INFO - 2017-06-19 17:31:48 --> Loader Class Initialized
INFO - 2017-06-19 17:31:48 --> Controller Class Initialized
INFO - 2017-06-19 17:31:48 --> Database Driver Class Initialized
INFO - 2017-06-19 17:31:48 --> Model Class Initialized
INFO - 2017-06-19 17:31:48 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:48 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:48 --> Upload Class Initialized
INFO - 2017-06-19 17:31:48 --> Final output sent to browser
DEBUG - 2017-06-19 17:31:48 --> Total execution time: 0.2295
ERROR - 2017-06-19 17:31:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:48 --> Config Class Initialized
INFO - 2017-06-19 17:31:48 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:31:48 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:48 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:48 --> URI Class Initialized
INFO - 2017-06-19 17:31:48 --> Router Class Initialized
INFO - 2017-06-19 17:31:48 --> Output Class Initialized
INFO - 2017-06-19 17:31:48 --> Security Class Initialized
DEBUG - 2017-06-19 17:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:48 --> Input Class Initialized
INFO - 2017-06-19 17:31:48 --> Language Class Initialized
INFO - 2017-06-19 17:31:48 --> Loader Class Initialized
INFO - 2017-06-19 17:31:48 --> Controller Class Initialized
INFO - 2017-06-19 17:31:48 --> Database Driver Class Initialized
INFO - 2017-06-19 17:31:48 --> Model Class Initialized
INFO - 2017-06-19 17:31:48 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:48 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:48 --> Upload Class Initialized
INFO - 2017-06-19 17:31:48 --> Final output sent to browser
DEBUG - 2017-06-19 17:31:48 --> Total execution time: 0.1160
ERROR - 2017-06-19 17:31:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:49 --> Config Class Initialized
INFO - 2017-06-19 17:31:49 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:31:49 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:49 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:49 --> URI Class Initialized
INFO - 2017-06-19 17:31:49 --> Router Class Initialized
INFO - 2017-06-19 17:31:49 --> Output Class Initialized
INFO - 2017-06-19 17:31:49 --> Security Class Initialized
DEBUG - 2017-06-19 17:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:49 --> Input Class Initialized
INFO - 2017-06-19 17:31:49 --> Language Class Initialized
INFO - 2017-06-19 17:31:49 --> Loader Class Initialized
INFO - 2017-06-19 17:31:49 --> Controller Class Initialized
INFO - 2017-06-19 17:31:49 --> Database Driver Class Initialized
INFO - 2017-06-19 17:31:49 --> Model Class Initialized
INFO - 2017-06-19 17:31:49 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:49 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:49 --> Upload Class Initialized
INFO - 2017-06-19 17:31:49 --> Final output sent to browser
DEBUG - 2017-06-19 17:31:49 --> Total execution time: 0.1345
ERROR - 2017-06-19 17:31:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:49 --> Config Class Initialized
INFO - 2017-06-19 17:31:49 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:31:49 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:49 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:49 --> URI Class Initialized
INFO - 2017-06-19 17:31:49 --> Router Class Initialized
INFO - 2017-06-19 17:31:49 --> Output Class Initialized
INFO - 2017-06-19 17:31:49 --> Security Class Initialized
DEBUG - 2017-06-19 17:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:49 --> Input Class Initialized
INFO - 2017-06-19 17:31:49 --> Language Class Initialized
INFO - 2017-06-19 17:31:49 --> Loader Class Initialized
INFO - 2017-06-19 17:31:49 --> Controller Class Initialized
INFO - 2017-06-19 17:31:49 --> Database Driver Class Initialized
INFO - 2017-06-19 17:31:49 --> Model Class Initialized
INFO - 2017-06-19 17:31:49 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:49 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:31:49 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:31:49 --> Upload Class Initialized
INFO - 2017-06-19 17:31:49 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:31:49 --> You did not select a file to upload.
INFO - 2017-06-19 17:31:49 --> Final output sent to browser
DEBUG - 2017-06-19 17:31:49 --> Total execution time: 0.3110
ERROR - 2017-06-19 17:31:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:50 --> Config Class Initialized
INFO - 2017-06-19 17:31:50 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:31:50 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:50 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:50 --> URI Class Initialized
INFO - 2017-06-19 17:31:50 --> Router Class Initialized
INFO - 2017-06-19 17:31:50 --> Output Class Initialized
INFO - 2017-06-19 17:31:50 --> Security Class Initialized
DEBUG - 2017-06-19 17:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:50 --> Input Class Initialized
INFO - 2017-06-19 17:31:50 --> Language Class Initialized
INFO - 2017-06-19 17:31:50 --> Loader Class Initialized
INFO - 2017-06-19 17:31:50 --> Controller Class Initialized
ERROR - 2017-06-19 17:31:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:50 --> Config Class Initialized
INFO - 2017-06-19 17:31:50 --> Hooks Class Initialized
INFO - 2017-06-19 17:31:50 --> Database Driver Class Initialized
DEBUG - 2017-06-19 17:31:50 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:50 --> Model Class Initialized
INFO - 2017-06-19 17:31:50 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:50 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:50 --> URI Class Initialized
INFO - 2017-06-19 17:31:50 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:50 --> Router Class Initialized
ERROR - 2017-06-19 17:31:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:50 --> Upload Class Initialized
INFO - 2017-06-19 17:31:50 --> Config Class Initialized
INFO - 2017-06-19 17:31:50 --> Hooks Class Initialized
INFO - 2017-06-19 17:31:50 --> Output Class Initialized
DEBUG - 2017-06-19 17:31:50 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:50 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:50 --> Security Class Initialized
INFO - 2017-06-19 17:31:50 --> URI Class Initialized
INFO - 2017-06-19 17:31:50 --> Router Class Initialized
DEBUG - 2017-06-19 17:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:50 --> Input Class Initialized
INFO - 2017-06-19 17:31:50 --> Output Class Initialized
INFO - 2017-06-19 17:31:50 --> Final output sent to browser
INFO - 2017-06-19 17:31:50 --> Security Class Initialized
INFO - 2017-06-19 17:31:50 --> Language Class Initialized
DEBUG - 2017-06-19 17:31:50 --> Total execution time: 0.0880
DEBUG - 2017-06-19 17:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:50 --> Input Class Initialized
INFO - 2017-06-19 17:31:50 --> Language Class Initialized
INFO - 2017-06-19 17:31:50 --> Loader Class Initialized
INFO - 2017-06-19 17:31:50 --> Controller Class Initialized
INFO - 2017-06-19 17:31:50 --> Database Driver Class Initialized
INFO - 2017-06-19 17:31:50 --> Model Class Initialized
INFO - 2017-06-19 17:31:50 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:50 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:50 --> Upload Class Initialized
ERROR - 2017-06-19 17:31:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:50 --> Config Class Initialized
INFO - 2017-06-19 17:31:50 --> Hooks Class Initialized
INFO - 2017-06-19 17:31:50 --> Final output sent to browser
DEBUG - 2017-06-19 17:31:50 --> Total execution time: 0.1060
DEBUG - 2017-06-19 17:31:50 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:50 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:50 --> Loader Class Initialized
INFO - 2017-06-19 17:31:50 --> Controller Class Initialized
INFO - 2017-06-19 17:31:50 --> URI Class Initialized
INFO - 2017-06-19 17:31:50 --> Router Class Initialized
INFO - 2017-06-19 17:31:50 --> Database Driver Class Initialized
INFO - 2017-06-19 17:31:50 --> Output Class Initialized
INFO - 2017-06-19 17:31:50 --> Security Class Initialized
DEBUG - 2017-06-19 17:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:50 --> Input Class Initialized
INFO - 2017-06-19 17:31:50 --> Model Class Initialized
INFO - 2017-06-19 17:31:50 --> Language Class Initialized
INFO - 2017-06-19 17:31:50 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:50 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:50 --> Upload Class Initialized
INFO - 2017-06-19 17:31:50 --> Final output sent to browser
DEBUG - 2017-06-19 17:31:50 --> Total execution time: 0.1635
INFO - 2017-06-19 17:31:50 --> Loader Class Initialized
INFO - 2017-06-19 17:31:50 --> Controller Class Initialized
INFO - 2017-06-19 17:31:50 --> Database Driver Class Initialized
INFO - 2017-06-19 17:31:50 --> Model Class Initialized
INFO - 2017-06-19 17:31:50 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:50 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:31:50 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:31:50 --> Upload Class Initialized
INFO - 2017-06-19 17:31:50 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:31:50 --> You did not select a file to upload.
INFO - 2017-06-19 17:31:50 --> Final output sent to browser
DEBUG - 2017-06-19 17:31:50 --> Total execution time: 0.1610
ERROR - 2017-06-19 17:31:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:50 --> Config Class Initialized
INFO - 2017-06-19 17:31:50 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:31:50 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:50 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:50 --> URI Class Initialized
INFO - 2017-06-19 17:31:50 --> Router Class Initialized
INFO - 2017-06-19 17:31:50 --> Output Class Initialized
INFO - 2017-06-19 17:31:50 --> Security Class Initialized
DEBUG - 2017-06-19 17:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:50 --> Input Class Initialized
INFO - 2017-06-19 17:31:50 --> Language Class Initialized
INFO - 2017-06-19 17:31:50 --> Loader Class Initialized
INFO - 2017-06-19 17:31:50 --> Controller Class Initialized
INFO - 2017-06-19 17:31:50 --> Database Driver Class Initialized
INFO - 2017-06-19 17:31:50 --> Model Class Initialized
INFO - 2017-06-19 17:31:50 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:50 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:50 --> Upload Class Initialized
INFO - 2017-06-19 17:31:50 --> Final output sent to browser
DEBUG - 2017-06-19 17:31:50 --> Total execution time: 0.0945
ERROR - 2017-06-19 17:31:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:31:50 --> Config Class Initialized
INFO - 2017-06-19 17:31:50 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:31:50 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:31:50 --> Utf8 Class Initialized
INFO - 2017-06-19 17:31:50 --> URI Class Initialized
INFO - 2017-06-19 17:31:50 --> Router Class Initialized
INFO - 2017-06-19 17:31:50 --> Output Class Initialized
INFO - 2017-06-19 17:31:50 --> Security Class Initialized
DEBUG - 2017-06-19 17:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:31:50 --> Input Class Initialized
INFO - 2017-06-19 17:31:50 --> Language Class Initialized
INFO - 2017-06-19 17:31:50 --> Loader Class Initialized
INFO - 2017-06-19 17:31:50 --> Controller Class Initialized
INFO - 2017-06-19 17:31:50 --> Database Driver Class Initialized
INFO - 2017-06-19 17:31:50 --> Model Class Initialized
INFO - 2017-06-19 17:31:50 --> Helper loaded: form_helper
INFO - 2017-06-19 17:31:50 --> Helper loaded: url_helper
INFO - 2017-06-19 17:31:50 --> Upload Class Initialized
INFO - 2017-06-19 17:31:50 --> Final output sent to browser
DEBUG - 2017-06-19 17:31:50 --> Total execution time: 0.1385
ERROR - 2017-06-19 17:32:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:32:40 --> Config Class Initialized
INFO - 2017-06-19 17:32:40 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:32:40 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:32:40 --> Utf8 Class Initialized
INFO - 2017-06-19 17:32:40 --> URI Class Initialized
INFO - 2017-06-19 17:32:40 --> Router Class Initialized
INFO - 2017-06-19 17:32:40 --> Output Class Initialized
INFO - 2017-06-19 17:32:40 --> Security Class Initialized
DEBUG - 2017-06-19 17:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:32:40 --> Input Class Initialized
INFO - 2017-06-19 17:32:40 --> Language Class Initialized
INFO - 2017-06-19 17:32:40 --> Loader Class Initialized
INFO - 2017-06-19 17:32:40 --> Controller Class Initialized
INFO - 2017-06-19 17:32:40 --> Database Driver Class Initialized
INFO - 2017-06-19 17:32:40 --> Model Class Initialized
INFO - 2017-06-19 17:32:40 --> Helper loaded: form_helper
INFO - 2017-06-19 17:32:40 --> Helper loaded: url_helper
INFO - 2017-06-19 17:32:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:32:40 --> Model Class Initialized
INFO - 2017-06-19 17:32:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:32:40 --> Final output sent to browser
DEBUG - 2017-06-19 17:32:40 --> Total execution time: 0.0640
ERROR - 2017-06-19 17:32:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:32:45 --> Config Class Initialized
INFO - 2017-06-19 17:32:45 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:32:45 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:32:45 --> Utf8 Class Initialized
INFO - 2017-06-19 17:32:45 --> URI Class Initialized
INFO - 2017-06-19 17:32:45 --> Router Class Initialized
INFO - 2017-06-19 17:32:45 --> Output Class Initialized
INFO - 2017-06-19 17:32:45 --> Security Class Initialized
DEBUG - 2017-06-19 17:32:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-06-19 17:32:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:32:45 --> Input Class Initialized
INFO - 2017-06-19 17:32:45 --> Config Class Initialized
INFO - 2017-06-19 17:32:45 --> Language Class Initialized
INFO - 2017-06-19 17:32:45 --> Hooks Class Initialized
INFO - 2017-06-19 17:32:45 --> Loader Class Initialized
DEBUG - 2017-06-19 17:32:45 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:32:45 --> Utf8 Class Initialized
INFO - 2017-06-19 17:32:45 --> Controller Class Initialized
INFO - 2017-06-19 17:32:45 --> URI Class Initialized
INFO - 2017-06-19 17:32:45 --> Router Class Initialized
INFO - 2017-06-19 17:32:45 --> Output Class Initialized
INFO - 2017-06-19 17:32:45 --> Database Driver Class Initialized
INFO - 2017-06-19 17:32:45 --> Security Class Initialized
DEBUG - 2017-06-19 17:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:32:45 --> Model Class Initialized
INFO - 2017-06-19 17:32:45 --> Input Class Initialized
INFO - 2017-06-19 17:32:45 --> Helper loaded: form_helper
INFO - 2017-06-19 17:32:45 --> Language Class Initialized
INFO - 2017-06-19 17:32:45 --> Helper loaded: url_helper
INFO - 2017-06-19 17:32:45 --> Upload Class Initialized
INFO - 2017-06-19 17:32:45 --> Final output sent to browser
ERROR - 2017-06-19 17:32:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
DEBUG - 2017-06-19 17:32:45 --> Total execution time: 0.0910
INFO - 2017-06-19 17:32:45 --> Config Class Initialized
INFO - 2017-06-19 17:32:45 --> Loader Class Initialized
INFO - 2017-06-19 17:32:45 --> Hooks Class Initialized
INFO - 2017-06-19 17:32:45 --> Controller Class Initialized
DEBUG - 2017-06-19 17:32:45 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:32:45 --> Utf8 Class Initialized
INFO - 2017-06-19 17:32:45 --> Database Driver Class Initialized
INFO - 2017-06-19 17:32:45 --> URI Class Initialized
INFO - 2017-06-19 17:32:45 --> Router Class Initialized
INFO - 2017-06-19 17:32:45 --> Output Class Initialized
INFO - 2017-06-19 17:32:45 --> Security Class Initialized
DEBUG - 2017-06-19 17:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:32:45 --> Model Class Initialized
INFO - 2017-06-19 17:32:45 --> Input Class Initialized
INFO - 2017-06-19 17:32:45 --> Helper loaded: form_helper
INFO - 2017-06-19 17:32:45 --> Language Class Initialized
INFO - 2017-06-19 17:32:45 --> Helper loaded: url_helper
INFO - 2017-06-19 17:32:45 --> Upload Class Initialized
INFO - 2017-06-19 17:32:45 --> Final output sent to browser
DEBUG - 2017-06-19 17:32:45 --> Total execution time: 0.1430
INFO - 2017-06-19 17:32:45 --> Loader Class Initialized
INFO - 2017-06-19 17:32:45 --> Controller Class Initialized
INFO - 2017-06-19 17:32:45 --> Database Driver Class Initialized
INFO - 2017-06-19 17:32:45 --> Model Class Initialized
INFO - 2017-06-19 17:32:45 --> Helper loaded: form_helper
INFO - 2017-06-19 17:32:45 --> Helper loaded: url_helper
INFO - 2017-06-19 17:32:45 --> Upload Class Initialized
INFO - 2017-06-19 17:32:45 --> Final output sent to browser
DEBUG - 2017-06-19 17:32:45 --> Total execution time: 0.1110
ERROR - 2017-06-19 17:32:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:32:50 --> Config Class Initialized
INFO - 2017-06-19 17:32:50 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:32:50 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:32:50 --> Utf8 Class Initialized
INFO - 2017-06-19 17:32:50 --> URI Class Initialized
INFO - 2017-06-19 17:32:50 --> Router Class Initialized
INFO - 2017-06-19 17:32:50 --> Output Class Initialized
INFO - 2017-06-19 17:32:50 --> Security Class Initialized
DEBUG - 2017-06-19 17:32:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-06-19 17:32:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:32:50 --> Input Class Initialized
INFO - 2017-06-19 17:32:50 --> Language Class Initialized
INFO - 2017-06-19 17:32:50 --> Config Class Initialized
INFO - 2017-06-19 17:32:50 --> Hooks Class Initialized
INFO - 2017-06-19 17:32:50 --> Loader Class Initialized
DEBUG - 2017-06-19 17:32:50 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:32:50 --> Controller Class Initialized
INFO - 2017-06-19 17:32:50 --> Utf8 Class Initialized
INFO - 2017-06-19 17:32:50 --> URI Class Initialized
INFO - 2017-06-19 17:32:50 --> Database Driver Class Initialized
INFO - 2017-06-19 17:32:50 --> Router Class Initialized
INFO - 2017-06-19 17:32:50 --> Output Class Initialized
INFO - 2017-06-19 17:32:50 --> Model Class Initialized
INFO - 2017-06-19 17:32:50 --> Security Class Initialized
INFO - 2017-06-19 17:32:50 --> Helper loaded: form_helper
DEBUG - 2017-06-19 17:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:32:50 --> Helper loaded: url_helper
INFO - 2017-06-19 17:32:50 --> Input Class Initialized
INFO - 2017-06-19 17:32:50 --> Language Class Initialized
INFO - 2017-06-19 17:32:50 --> Upload Class Initialized
ERROR - 2017-06-19 17:32:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:32:50 --> Config Class Initialized
INFO - 2017-06-19 17:32:50 --> Hooks Class Initialized
INFO - 2017-06-19 17:32:50 --> Final output sent to browser
DEBUG - 2017-06-19 17:32:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-19 17:32:50 --> Total execution time: 0.1060
INFO - 2017-06-19 17:32:50 --> Utf8 Class Initialized
INFO - 2017-06-19 17:32:50 --> URI Class Initialized
INFO - 2017-06-19 17:32:50 --> Loader Class Initialized
INFO - 2017-06-19 17:32:50 --> Router Class Initialized
INFO - 2017-06-19 17:32:50 --> Controller Class Initialized
INFO - 2017-06-19 17:32:50 --> Output Class Initialized
INFO - 2017-06-19 17:32:50 --> Security Class Initialized
INFO - 2017-06-19 17:32:50 --> Database Driver Class Initialized
DEBUG - 2017-06-19 17:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:32:50 --> Input Class Initialized
INFO - 2017-06-19 17:32:50 --> Language Class Initialized
INFO - 2017-06-19 17:32:50 --> Model Class Initialized
INFO - 2017-06-19 17:32:50 --> Helper loaded: form_helper
INFO - 2017-06-19 17:32:50 --> Helper loaded: url_helper
INFO - 2017-06-19 17:32:50 --> Upload Class Initialized
INFO - 2017-06-19 17:32:50 --> Final output sent to browser
DEBUG - 2017-06-19 17:32:50 --> Total execution time: 0.1320
INFO - 2017-06-19 17:32:50 --> Loader Class Initialized
INFO - 2017-06-19 17:32:50 --> Controller Class Initialized
INFO - 2017-06-19 17:32:50 --> Database Driver Class Initialized
INFO - 2017-06-19 17:32:50 --> Model Class Initialized
INFO - 2017-06-19 17:32:50 --> Helper loaded: form_helper
INFO - 2017-06-19 17:32:50 --> Helper loaded: url_helper
INFO - 2017-06-19 17:32:50 --> Upload Class Initialized
INFO - 2017-06-19 17:32:50 --> Final output sent to browser
DEBUG - 2017-06-19 17:32:50 --> Total execution time: 0.2135
ERROR - 2017-06-19 17:32:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:32:50 --> Config Class Initialized
INFO - 2017-06-19 17:32:50 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:32:50 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:32:50 --> Utf8 Class Initialized
INFO - 2017-06-19 17:32:50 --> URI Class Initialized
INFO - 2017-06-19 17:32:50 --> Router Class Initialized
INFO - 2017-06-19 17:32:50 --> Output Class Initialized
INFO - 2017-06-19 17:32:50 --> Security Class Initialized
DEBUG - 2017-06-19 17:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:32:50 --> Input Class Initialized
INFO - 2017-06-19 17:32:50 --> Language Class Initialized
INFO - 2017-06-19 17:32:50 --> Loader Class Initialized
INFO - 2017-06-19 17:32:50 --> Controller Class Initialized
INFO - 2017-06-19 17:32:50 --> Database Driver Class Initialized
INFO - 2017-06-19 17:32:50 --> Model Class Initialized
INFO - 2017-06-19 17:32:50 --> Helper loaded: form_helper
INFO - 2017-06-19 17:32:50 --> Helper loaded: url_helper
INFO - 2017-06-19 17:32:50 --> Upload Class Initialized
INFO - 2017-06-19 17:32:50 --> Final output sent to browser
DEBUG - 2017-06-19 17:32:50 --> Total execution time: 0.0575
ERROR - 2017-06-19 17:33:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
ERROR - 2017-06-19 17:33:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:01 --> Config Class Initialized
INFO - 2017-06-19 17:33:01 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:01 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:01 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:01 --> Config Class Initialized
INFO - 2017-06-19 17:33:01 --> URI Class Initialized
INFO - 2017-06-19 17:33:01 --> Hooks Class Initialized
INFO - 2017-06-19 17:33:01 --> Router Class Initialized
DEBUG - 2017-06-19 17:33:01 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:01 --> Output Class Initialized
INFO - 2017-06-19 17:33:01 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:01 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:01 --> URI Class Initialized
INFO - 2017-06-19 17:33:01 --> Input Class Initialized
INFO - 2017-06-19 17:33:01 --> Language Class Initialized
INFO - 2017-06-19 17:33:01 --> Router Class Initialized
INFO - 2017-06-19 17:33:01 --> Output Class Initialized
INFO - 2017-06-19 17:33:01 --> Loader Class Initialized
INFO - 2017-06-19 17:33:01 --> Controller Class Initialized
INFO - 2017-06-19 17:33:01 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:01 --> Input Class Initialized
INFO - 2017-06-19 17:33:01 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:01 --> Language Class Initialized
INFO - 2017-06-19 17:33:01 --> Model Class Initialized
INFO - 2017-06-19 17:33:01 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:01 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:33:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:01 --> Upload Class Initialized
INFO - 2017-06-19 17:33:01 --> Config Class Initialized
INFO - 2017-06-19 17:33:01 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:01 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:01 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:01 --> URI Class Initialized
INFO - 2017-06-19 17:33:01 --> Router Class Initialized
INFO - 2017-06-19 17:33:01 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:01 --> Total execution time: 0.0530
INFO - 2017-06-19 17:33:01 --> Output Class Initialized
INFO - 2017-06-19 17:33:01 --> Security Class Initialized
INFO - 2017-06-19 17:33:01 --> Loader Class Initialized
DEBUG - 2017-06-19 17:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:01 --> Controller Class Initialized
INFO - 2017-06-19 17:33:01 --> Input Class Initialized
INFO - 2017-06-19 17:33:01 --> Language Class Initialized
INFO - 2017-06-19 17:33:01 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:01 --> Model Class Initialized
INFO - 2017-06-19 17:33:01 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:01 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:01 --> Upload Class Initialized
INFO - 2017-06-19 17:33:01 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:01 --> Total execution time: 0.1340
INFO - 2017-06-19 17:33:01 --> Loader Class Initialized
INFO - 2017-06-19 17:33:01 --> Controller Class Initialized
INFO - 2017-06-19 17:33:01 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:01 --> Model Class Initialized
INFO - 2017-06-19 17:33:01 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:01 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:01 --> Upload Class Initialized
INFO - 2017-06-19 17:33:01 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:01 --> Total execution time: 0.1110
ERROR - 2017-06-19 17:33:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:01 --> Config Class Initialized
INFO - 2017-06-19 17:33:01 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:01 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:01 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:01 --> URI Class Initialized
INFO - 2017-06-19 17:33:01 --> Router Class Initialized
INFO - 2017-06-19 17:33:01 --> Output Class Initialized
INFO - 2017-06-19 17:33:01 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:01 --> Input Class Initialized
INFO - 2017-06-19 17:33:01 --> Language Class Initialized
INFO - 2017-06-19 17:33:01 --> Loader Class Initialized
INFO - 2017-06-19 17:33:01 --> Controller Class Initialized
INFO - 2017-06-19 17:33:01 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:01 --> Model Class Initialized
INFO - 2017-06-19 17:33:01 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:01 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:01 --> Upload Class Initialized
INFO - 2017-06-19 17:33:01 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:01 --> Total execution time: 0.0600
ERROR - 2017-06-19 17:33:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:01 --> Config Class Initialized
INFO - 2017-06-19 17:33:01 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:01 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:01 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:01 --> URI Class Initialized
INFO - 2017-06-19 17:33:01 --> Router Class Initialized
INFO - 2017-06-19 17:33:01 --> Output Class Initialized
INFO - 2017-06-19 17:33:01 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:01 --> Input Class Initialized
INFO - 2017-06-19 17:33:01 --> Language Class Initialized
INFO - 2017-06-19 17:33:01 --> Loader Class Initialized
INFO - 2017-06-19 17:33:01 --> Controller Class Initialized
INFO - 2017-06-19 17:33:01 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:01 --> Model Class Initialized
INFO - 2017-06-19 17:33:01 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:01 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:01 --> Upload Class Initialized
INFO - 2017-06-19 17:33:01 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:01 --> Total execution time: 0.0680
ERROR - 2017-06-19 17:33:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:01 --> Config Class Initialized
INFO - 2017-06-19 17:33:01 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:01 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:01 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:01 --> URI Class Initialized
INFO - 2017-06-19 17:33:01 --> Router Class Initialized
INFO - 2017-06-19 17:33:01 --> Output Class Initialized
INFO - 2017-06-19 17:33:01 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:01 --> Input Class Initialized
INFO - 2017-06-19 17:33:01 --> Language Class Initialized
INFO - 2017-06-19 17:33:01 --> Loader Class Initialized
INFO - 2017-06-19 17:33:01 --> Controller Class Initialized
INFO - 2017-06-19 17:33:01 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:02 --> Model Class Initialized
INFO - 2017-06-19 17:33:02 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:02 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:02 --> Upload Class Initialized
INFO - 2017-06-19 17:33:02 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:02 --> Total execution time: 0.3315
ERROR - 2017-06-19 17:33:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:02 --> Config Class Initialized
INFO - 2017-06-19 17:33:02 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:02 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:02 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:02 --> URI Class Initialized
INFO - 2017-06-19 17:33:02 --> Router Class Initialized
INFO - 2017-06-19 17:33:02 --> Output Class Initialized
INFO - 2017-06-19 17:33:02 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:02 --> Input Class Initialized
INFO - 2017-06-19 17:33:02 --> Language Class Initialized
INFO - 2017-06-19 17:33:02 --> Loader Class Initialized
INFO - 2017-06-19 17:33:02 --> Controller Class Initialized
INFO - 2017-06-19 17:33:02 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:02 --> Model Class Initialized
INFO - 2017-06-19 17:33:02 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:02 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:02 --> Upload Class Initialized
ERROR - 2017-06-19 17:33:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:02 --> Config Class Initialized
INFO - 2017-06-19 17:33:02 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:02 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:02 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:02 --> URI Class Initialized
INFO - 2017-06-19 17:33:02 --> Router Class Initialized
INFO - 2017-06-19 17:33:02 --> Output Class Initialized
INFO - 2017-06-19 17:33:02 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:02 --> Input Class Initialized
INFO - 2017-06-19 17:33:02 --> Language Class Initialized
ERROR - 2017-06-19 17:33:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:02 --> Config Class Initialized
INFO - 2017-06-19 17:33:02 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:02 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:02 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:02 --> URI Class Initialized
INFO - 2017-06-19 17:33:02 --> Router Class Initialized
INFO - 2017-06-19 17:33:02 --> Output Class Initialized
INFO - 2017-06-19 17:33:02 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:02 --> Input Class Initialized
INFO - 2017-06-19 17:33:02 --> Language Class Initialized
INFO - 2017-06-19 17:33:02 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:02 --> Total execution time: 0.3765
INFO - 2017-06-19 17:33:02 --> Loader Class Initialized
INFO - 2017-06-19 17:33:02 --> Controller Class Initialized
INFO - 2017-06-19 17:33:02 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:02 --> Model Class Initialized
INFO - 2017-06-19 17:33:02 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:02 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:02 --> Upload Class Initialized
INFO - 2017-06-19 17:33:02 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:02 --> Total execution time: 0.2070
INFO - 2017-06-19 17:33:02 --> Loader Class Initialized
INFO - 2017-06-19 17:33:02 --> Controller Class Initialized
INFO - 2017-06-19 17:33:02 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:02 --> Model Class Initialized
INFO - 2017-06-19 17:33:02 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:02 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:02 --> Upload Class Initialized
INFO - 2017-06-19 17:33:02 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:02 --> Total execution time: 0.2235
ERROR - 2017-06-19 17:33:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:07 --> Config Class Initialized
INFO - 2017-06-19 17:33:07 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:07 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:07 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:07 --> URI Class Initialized
INFO - 2017-06-19 17:33:07 --> Router Class Initialized
INFO - 2017-06-19 17:33:07 --> Output Class Initialized
INFO - 2017-06-19 17:33:07 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:07 --> Input Class Initialized
INFO - 2017-06-19 17:33:07 --> Language Class Initialized
INFO - 2017-06-19 17:33:07 --> Loader Class Initialized
INFO - 2017-06-19 17:33:07 --> Controller Class Initialized
INFO - 2017-06-19 17:33:07 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:07 --> Model Class Initialized
INFO - 2017-06-19 17:33:07 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:07 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:33:07 --> Model Class Initialized
INFO - 2017-06-19 17:33:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:33:07 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:07 --> Total execution time: 0.0550
ERROR - 2017-06-19 17:33:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:12 --> Config Class Initialized
INFO - 2017-06-19 17:33:12 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:12 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:12 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:12 --> URI Class Initialized
INFO - 2017-06-19 17:33:12 --> Router Class Initialized
INFO - 2017-06-19 17:33:12 --> Output Class Initialized
INFO - 2017-06-19 17:33:12 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:12 --> Input Class Initialized
INFO - 2017-06-19 17:33:12 --> Language Class Initialized
INFO - 2017-06-19 17:33:12 --> Loader Class Initialized
INFO - 2017-06-19 17:33:12 --> Controller Class Initialized
INFO - 2017-06-19 17:33:12 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:12 --> Model Class Initialized
INFO - 2017-06-19 17:33:12 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:12 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:12 --> Upload Class Initialized
INFO - 2017-06-19 17:33:12 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:12 --> Total execution time: 0.0880
ERROR - 2017-06-19 17:33:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:12 --> Config Class Initialized
INFO - 2017-06-19 17:33:12 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:12 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:12 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:12 --> URI Class Initialized
INFO - 2017-06-19 17:33:12 --> Router Class Initialized
INFO - 2017-06-19 17:33:12 --> Output Class Initialized
INFO - 2017-06-19 17:33:12 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:12 --> Input Class Initialized
INFO - 2017-06-19 17:33:12 --> Language Class Initialized
INFO - 2017-06-19 17:33:12 --> Loader Class Initialized
INFO - 2017-06-19 17:33:12 --> Controller Class Initialized
INFO - 2017-06-19 17:33:12 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:12 --> Model Class Initialized
INFO - 2017-06-19 17:33:12 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:12 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:12 --> Upload Class Initialized
INFO - 2017-06-19 17:33:12 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:12 --> Total execution time: 0.1455
ERROR - 2017-06-19 17:33:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:12 --> Config Class Initialized
INFO - 2017-06-19 17:33:12 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:12 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:12 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:12 --> URI Class Initialized
INFO - 2017-06-19 17:33:12 --> Router Class Initialized
INFO - 2017-06-19 17:33:12 --> Output Class Initialized
INFO - 2017-06-19 17:33:12 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:12 --> Input Class Initialized
INFO - 2017-06-19 17:33:12 --> Language Class Initialized
INFO - 2017-06-19 17:33:12 --> Loader Class Initialized
INFO - 2017-06-19 17:33:12 --> Controller Class Initialized
INFO - 2017-06-19 17:33:12 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:12 --> Model Class Initialized
INFO - 2017-06-19 17:33:12 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:12 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:12 --> Upload Class Initialized
INFO - 2017-06-19 17:33:12 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:12 --> Total execution time: 0.0840
ERROR - 2017-06-19 17:33:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:12 --> Config Class Initialized
INFO - 2017-06-19 17:33:12 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:12 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:12 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:12 --> URI Class Initialized
INFO - 2017-06-19 17:33:12 --> Router Class Initialized
INFO - 2017-06-19 17:33:12 --> Output Class Initialized
INFO - 2017-06-19 17:33:12 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:12 --> Input Class Initialized
INFO - 2017-06-19 17:33:12 --> Language Class Initialized
INFO - 2017-06-19 17:33:12 --> Loader Class Initialized
INFO - 2017-06-19 17:33:12 --> Controller Class Initialized
INFO - 2017-06-19 17:33:12 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:12 --> Model Class Initialized
INFO - 2017-06-19 17:33:12 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:12 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:12 --> Upload Class Initialized
INFO - 2017-06-19 17:33:12 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:12 --> Total execution time: 0.1125
ERROR - 2017-06-19 17:33:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:12 --> Config Class Initialized
INFO - 2017-06-19 17:33:12 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:12 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:12 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:12 --> URI Class Initialized
INFO - 2017-06-19 17:33:12 --> Router Class Initialized
INFO - 2017-06-19 17:33:12 --> Output Class Initialized
INFO - 2017-06-19 17:33:12 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:12 --> Input Class Initialized
INFO - 2017-06-19 17:33:12 --> Language Class Initialized
INFO - 2017-06-19 17:33:12 --> Loader Class Initialized
INFO - 2017-06-19 17:33:12 --> Controller Class Initialized
INFO - 2017-06-19 17:33:12 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:12 --> Model Class Initialized
INFO - 2017-06-19 17:33:12 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:12 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:12 --> Upload Class Initialized
INFO - 2017-06-19 17:33:12 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:12 --> Total execution time: 0.0780
ERROR - 2017-06-19 17:33:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:12 --> Config Class Initialized
INFO - 2017-06-19 17:33:12 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:12 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:12 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:12 --> URI Class Initialized
INFO - 2017-06-19 17:33:12 --> Router Class Initialized
INFO - 2017-06-19 17:33:12 --> Output Class Initialized
INFO - 2017-06-19 17:33:12 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:12 --> Input Class Initialized
INFO - 2017-06-19 17:33:12 --> Language Class Initialized
INFO - 2017-06-19 17:33:12 --> Loader Class Initialized
INFO - 2017-06-19 17:33:12 --> Controller Class Initialized
INFO - 2017-06-19 17:33:12 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:12 --> Model Class Initialized
INFO - 2017-06-19 17:33:12 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:12 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:12 --> Upload Class Initialized
INFO - 2017-06-19 17:33:12 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:12 --> Total execution time: 0.0860
ERROR - 2017-06-19 17:33:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:13 --> Config Class Initialized
INFO - 2017-06-19 17:33:13 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:13 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:13 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:13 --> URI Class Initialized
INFO - 2017-06-19 17:33:13 --> Router Class Initialized
INFO - 2017-06-19 17:33:13 --> Output Class Initialized
INFO - 2017-06-19 17:33:13 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:13 --> Input Class Initialized
INFO - 2017-06-19 17:33:13 --> Language Class Initialized
INFO - 2017-06-19 17:33:13 --> Loader Class Initialized
INFO - 2017-06-19 17:33:13 --> Controller Class Initialized
INFO - 2017-06-19 17:33:13 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:13 --> Model Class Initialized
ERROR - 2017-06-19 17:33:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:13 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:13 --> Config Class Initialized
INFO - 2017-06-19 17:33:13 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:13 --> Hooks Class Initialized
INFO - 2017-06-19 17:33:13 --> Upload Class Initialized
DEBUG - 2017-06-19 17:33:13 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:13 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:13 --> URI Class Initialized
INFO - 2017-06-19 17:33:13 --> Router Class Initialized
INFO - 2017-06-19 17:33:13 --> Output Class Initialized
INFO - 2017-06-19 17:33:13 --> Final output sent to browser
INFO - 2017-06-19 17:33:13 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:13 --> Total execution time: 0.0790
DEBUG - 2017-06-19 17:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:13 --> Input Class Initialized
INFO - 2017-06-19 17:33:13 --> Language Class Initialized
INFO - 2017-06-19 17:33:13 --> Loader Class Initialized
INFO - 2017-06-19 17:33:13 --> Controller Class Initialized
INFO - 2017-06-19 17:33:13 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:13 --> Model Class Initialized
INFO - 2017-06-19 17:33:13 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:13 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:13 --> Upload Class Initialized
INFO - 2017-06-19 17:33:13 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:13 --> Total execution time: 0.0920
ERROR - 2017-06-19 17:33:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:13 --> Config Class Initialized
INFO - 2017-06-19 17:33:13 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:13 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:13 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:13 --> URI Class Initialized
INFO - 2017-06-19 17:33:13 --> Router Class Initialized
INFO - 2017-06-19 17:33:13 --> Output Class Initialized
INFO - 2017-06-19 17:33:13 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:13 --> Input Class Initialized
INFO - 2017-06-19 17:33:13 --> Language Class Initialized
INFO - 2017-06-19 17:33:13 --> Loader Class Initialized
INFO - 2017-06-19 17:33:13 --> Controller Class Initialized
INFO - 2017-06-19 17:33:13 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:13 --> Model Class Initialized
INFO - 2017-06-19 17:33:13 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:13 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:33:13 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:33:13 --> Upload Class Initialized
INFO - 2017-06-19 17:33:13 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:33:13 --> You did not select a file to upload.
INFO - 2017-06-19 17:33:13 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:13 --> Total execution time: 0.0820
ERROR - 2017-06-19 17:33:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:13 --> Config Class Initialized
INFO - 2017-06-19 17:33:13 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:13 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:13 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:13 --> URI Class Initialized
INFO - 2017-06-19 17:33:13 --> Router Class Initialized
INFO - 2017-06-19 17:33:13 --> Output Class Initialized
INFO - 2017-06-19 17:33:13 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:13 --> Input Class Initialized
INFO - 2017-06-19 17:33:13 --> Language Class Initialized
INFO - 2017-06-19 17:33:13 --> Loader Class Initialized
INFO - 2017-06-19 17:33:13 --> Controller Class Initialized
INFO - 2017-06-19 17:33:13 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:13 --> Model Class Initialized
INFO - 2017-06-19 17:33:13 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:13 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:13 --> Upload Class Initialized
INFO - 2017-06-19 17:33:13 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:13 --> Total execution time: 0.1190
ERROR - 2017-06-19 17:33:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:13 --> Config Class Initialized
INFO - 2017-06-19 17:33:13 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:13 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:13 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:13 --> URI Class Initialized
INFO - 2017-06-19 17:33:13 --> Router Class Initialized
INFO - 2017-06-19 17:33:13 --> Output Class Initialized
INFO - 2017-06-19 17:33:13 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:13 --> Input Class Initialized
INFO - 2017-06-19 17:33:13 --> Language Class Initialized
INFO - 2017-06-19 17:33:13 --> Loader Class Initialized
INFO - 2017-06-19 17:33:13 --> Controller Class Initialized
INFO - 2017-06-19 17:33:13 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:13 --> Model Class Initialized
INFO - 2017-06-19 17:33:13 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:13 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:33:13 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:33:13 --> Upload Class Initialized
INFO - 2017-06-19 17:33:13 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:33:13 --> You did not select a file to upload.
INFO - 2017-06-19 17:33:13 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:13 --> Total execution time: 0.0925
ERROR - 2017-06-19 17:33:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:14 --> Config Class Initialized
INFO - 2017-06-19 17:33:14 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:14 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:14 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:14 --> URI Class Initialized
INFO - 2017-06-19 17:33:14 --> Router Class Initialized
INFO - 2017-06-19 17:33:14 --> Output Class Initialized
INFO - 2017-06-19 17:33:14 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:14 --> Input Class Initialized
INFO - 2017-06-19 17:33:14 --> Language Class Initialized
INFO - 2017-06-19 17:33:14 --> Loader Class Initialized
INFO - 2017-06-19 17:33:14 --> Controller Class Initialized
INFO - 2017-06-19 17:33:14 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:14 --> Model Class Initialized
INFO - 2017-06-19 17:33:14 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:14 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:14 --> Upload Class Initialized
INFO - 2017-06-19 17:33:14 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:14 --> Total execution time: 0.0810
ERROR - 2017-06-19 17:33:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:14 --> Config Class Initialized
INFO - 2017-06-19 17:33:14 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:14 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:14 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:14 --> URI Class Initialized
INFO - 2017-06-19 17:33:14 --> Router Class Initialized
INFO - 2017-06-19 17:33:14 --> Output Class Initialized
INFO - 2017-06-19 17:33:14 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:14 --> Input Class Initialized
INFO - 2017-06-19 17:33:14 --> Language Class Initialized
INFO - 2017-06-19 17:33:14 --> Loader Class Initialized
INFO - 2017-06-19 17:33:14 --> Controller Class Initialized
INFO - 2017-06-19 17:33:14 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:14 --> Model Class Initialized
INFO - 2017-06-19 17:33:14 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:14 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:14 --> Upload Class Initialized
INFO - 2017-06-19 17:33:14 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:14 --> Total execution time: 0.1315
ERROR - 2017-06-19 17:33:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:14 --> Config Class Initialized
INFO - 2017-06-19 17:33:14 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:14 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:14 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:14 --> URI Class Initialized
INFO - 2017-06-19 17:33:14 --> Router Class Initialized
INFO - 2017-06-19 17:33:14 --> Output Class Initialized
INFO - 2017-06-19 17:33:14 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:14 --> Input Class Initialized
INFO - 2017-06-19 17:33:14 --> Language Class Initialized
INFO - 2017-06-19 17:33:14 --> Loader Class Initialized
INFO - 2017-06-19 17:33:14 --> Controller Class Initialized
INFO - 2017-06-19 17:33:14 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:14 --> Model Class Initialized
INFO - 2017-06-19 17:33:14 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:14 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:14 --> Upload Class Initialized
INFO - 2017-06-19 17:33:14 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:14 --> Total execution time: 0.0815
ERROR - 2017-06-19 17:33:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:33:15 --> Config Class Initialized
INFO - 2017-06-19 17:33:15 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:33:15 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:33:15 --> Utf8 Class Initialized
INFO - 2017-06-19 17:33:15 --> URI Class Initialized
INFO - 2017-06-19 17:33:15 --> Router Class Initialized
INFO - 2017-06-19 17:33:15 --> Output Class Initialized
INFO - 2017-06-19 17:33:15 --> Security Class Initialized
DEBUG - 2017-06-19 17:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:33:15 --> Input Class Initialized
INFO - 2017-06-19 17:33:15 --> Language Class Initialized
INFO - 2017-06-19 17:33:15 --> Loader Class Initialized
INFO - 2017-06-19 17:33:15 --> Controller Class Initialized
INFO - 2017-06-19 17:33:15 --> Database Driver Class Initialized
INFO - 2017-06-19 17:33:15 --> Model Class Initialized
INFO - 2017-06-19 17:33:15 --> Helper loaded: form_helper
INFO - 2017-06-19 17:33:15 --> Helper loaded: url_helper
INFO - 2017-06-19 17:33:15 --> Upload Class Initialized
INFO - 2017-06-19 17:33:15 --> Final output sent to browser
DEBUG - 2017-06-19 17:33:15 --> Total execution time: 0.0580
ERROR - 2017-06-19 17:34:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:34:08 --> Config Class Initialized
INFO - 2017-06-19 17:34:08 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:34:08 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:34:08 --> Utf8 Class Initialized
INFO - 2017-06-19 17:34:08 --> URI Class Initialized
INFO - 2017-06-19 17:34:08 --> Router Class Initialized
INFO - 2017-06-19 17:34:08 --> Output Class Initialized
INFO - 2017-06-19 17:34:08 --> Security Class Initialized
DEBUG - 2017-06-19 17:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:34:08 --> Input Class Initialized
INFO - 2017-06-19 17:34:08 --> Language Class Initialized
INFO - 2017-06-19 17:34:08 --> Loader Class Initialized
INFO - 2017-06-19 17:34:08 --> Controller Class Initialized
INFO - 2017-06-19 17:34:08 --> Database Driver Class Initialized
INFO - 2017-06-19 17:34:08 --> Model Class Initialized
INFO - 2017-06-19 17:34:08 --> Helper loaded: form_helper
INFO - 2017-06-19 17:34:08 --> Helper loaded: url_helper
INFO - 2017-06-19 17:34:08 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:34:08 --> Model Class Initialized
INFO - 2017-06-19 17:34:08 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:34:08 --> Final output sent to browser
DEBUG - 2017-06-19 17:34:08 --> Total execution time: 0.0580
ERROR - 2017-06-19 17:34:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:34:21 --> Config Class Initialized
INFO - 2017-06-19 17:34:21 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:34:21 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:34:21 --> Utf8 Class Initialized
INFO - 2017-06-19 17:34:21 --> URI Class Initialized
INFO - 2017-06-19 17:34:21 --> Router Class Initialized
INFO - 2017-06-19 17:34:22 --> Output Class Initialized
INFO - 2017-06-19 17:34:22 --> Security Class Initialized
DEBUG - 2017-06-19 17:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:34:22 --> Input Class Initialized
INFO - 2017-06-19 17:34:22 --> Language Class Initialized
INFO - 2017-06-19 17:34:22 --> Loader Class Initialized
INFO - 2017-06-19 17:34:22 --> Controller Class Initialized
INFO - 2017-06-19 17:34:22 --> Database Driver Class Initialized
INFO - 2017-06-19 17:34:22 --> Model Class Initialized
INFO - 2017-06-19 17:34:22 --> Helper loaded: form_helper
INFO - 2017-06-19 17:34:22 --> Helper loaded: url_helper
INFO - 2017-06-19 17:34:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:34:22 --> Model Class Initialized
INFO - 2017-06-19 17:34:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:34:22 --> Final output sent to browser
DEBUG - 2017-06-19 17:34:22 --> Total execution time: 0.0600
ERROR - 2017-06-19 17:34:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:34:30 --> Config Class Initialized
INFO - 2017-06-19 17:34:30 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:34:30 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:34:30 --> Utf8 Class Initialized
INFO - 2017-06-19 17:34:30 --> URI Class Initialized
INFO - 2017-06-19 17:34:30 --> Router Class Initialized
INFO - 2017-06-19 17:34:30 --> Output Class Initialized
INFO - 2017-06-19 17:34:30 --> Security Class Initialized
DEBUG - 2017-06-19 17:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:34:30 --> Input Class Initialized
INFO - 2017-06-19 17:34:30 --> Language Class Initialized
INFO - 2017-06-19 17:34:30 --> Loader Class Initialized
INFO - 2017-06-19 17:34:30 --> Controller Class Initialized
INFO - 2017-06-19 17:34:30 --> Database Driver Class Initialized
INFO - 2017-06-19 17:34:30 --> Model Class Initialized
INFO - 2017-06-19 17:34:30 --> Helper loaded: form_helper
INFO - 2017-06-19 17:34:30 --> Helper loaded: url_helper
INFO - 2017-06-19 17:34:30 --> Upload Class Initialized
INFO - 2017-06-19 17:34:30 --> Final output sent to browser
DEBUG - 2017-06-19 17:34:30 --> Total execution time: 0.1780
ERROR - 2017-06-19 17:34:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:34:30 --> Config Class Initialized
INFO - 2017-06-19 17:34:30 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:34:30 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:34:30 --> Utf8 Class Initialized
INFO - 2017-06-19 17:34:30 --> URI Class Initialized
INFO - 2017-06-19 17:34:30 --> Router Class Initialized
INFO - 2017-06-19 17:34:30 --> Output Class Initialized
INFO - 2017-06-19 17:34:30 --> Security Class Initialized
DEBUG - 2017-06-19 17:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:34:30 --> Input Class Initialized
INFO - 2017-06-19 17:34:30 --> Language Class Initialized
INFO - 2017-06-19 17:34:30 --> Loader Class Initialized
INFO - 2017-06-19 17:34:30 --> Controller Class Initialized
INFO - 2017-06-19 17:34:30 --> Database Driver Class Initialized
ERROR - 2017-06-19 17:34:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:34:30 --> Config Class Initialized
INFO - 2017-06-19 17:34:30 --> Hooks Class Initialized
INFO - 2017-06-19 17:34:30 --> Model Class Initialized
DEBUG - 2017-06-19 17:34:30 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:34:30 --> Helper loaded: form_helper
INFO - 2017-06-19 17:34:30 --> Utf8 Class Initialized
INFO - 2017-06-19 17:34:30 --> Helper loaded: url_helper
INFO - 2017-06-19 17:34:30 --> URI Class Initialized
INFO - 2017-06-19 17:34:30 --> Upload Class Initialized
INFO - 2017-06-19 17:34:30 --> Router Class Initialized
INFO - 2017-06-19 17:34:30 --> Output Class Initialized
INFO - 2017-06-19 17:34:30 --> Security Class Initialized
DEBUG - 2017-06-19 17:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:34:30 --> Input Class Initialized
INFO - 2017-06-19 17:34:30 --> Language Class Initialized
INFO - 2017-06-19 17:34:30 --> Final output sent to browser
DEBUG - 2017-06-19 17:34:30 --> Total execution time: 0.1175
INFO - 2017-06-19 17:34:30 --> Loader Class Initialized
INFO - 2017-06-19 17:34:30 --> Controller Class Initialized
INFO - 2017-06-19 17:34:30 --> Database Driver Class Initialized
INFO - 2017-06-19 17:34:30 --> Model Class Initialized
INFO - 2017-06-19 17:34:30 --> Helper loaded: form_helper
INFO - 2017-06-19 17:34:30 --> Helper loaded: url_helper
INFO - 2017-06-19 17:34:30 --> Upload Class Initialized
INFO - 2017-06-19 17:34:30 --> Final output sent to browser
DEBUG - 2017-06-19 17:34:30 --> Total execution time: 0.0910
ERROR - 2017-06-19 17:34:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:34:30 --> Config Class Initialized
INFO - 2017-06-19 17:34:30 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:34:30 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:34:30 --> Utf8 Class Initialized
INFO - 2017-06-19 17:34:30 --> URI Class Initialized
INFO - 2017-06-19 17:34:30 --> Router Class Initialized
INFO - 2017-06-19 17:34:30 --> Output Class Initialized
INFO - 2017-06-19 17:34:30 --> Security Class Initialized
DEBUG - 2017-06-19 17:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:34:30 --> Input Class Initialized
INFO - 2017-06-19 17:34:30 --> Language Class Initialized
INFO - 2017-06-19 17:34:30 --> Loader Class Initialized
INFO - 2017-06-19 17:34:30 --> Controller Class Initialized
INFO - 2017-06-19 17:34:30 --> Database Driver Class Initialized
INFO - 2017-06-19 17:34:30 --> Model Class Initialized
INFO - 2017-06-19 17:34:30 --> Helper loaded: form_helper
INFO - 2017-06-19 17:34:30 --> Helper loaded: url_helper
INFO - 2017-06-19 17:34:30 --> Upload Class Initialized
INFO - 2017-06-19 17:34:30 --> Final output sent to browser
DEBUG - 2017-06-19 17:34:30 --> Total execution time: 0.0835
ERROR - 2017-06-19 17:34:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:34:30 --> Config Class Initialized
INFO - 2017-06-19 17:34:30 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:34:30 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:34:30 --> Utf8 Class Initialized
INFO - 2017-06-19 17:34:30 --> URI Class Initialized
INFO - 2017-06-19 17:34:30 --> Router Class Initialized
INFO - 2017-06-19 17:34:30 --> Output Class Initialized
INFO - 2017-06-19 17:34:30 --> Security Class Initialized
DEBUG - 2017-06-19 17:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:34:30 --> Input Class Initialized
INFO - 2017-06-19 17:34:30 --> Language Class Initialized
INFO - 2017-06-19 17:34:30 --> Loader Class Initialized
INFO - 2017-06-19 17:34:30 --> Controller Class Initialized
INFO - 2017-06-19 17:34:30 --> Database Driver Class Initialized
INFO - 2017-06-19 17:34:30 --> Model Class Initialized
INFO - 2017-06-19 17:34:31 --> Helper loaded: form_helper
ERROR - 2017-06-19 17:34:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:34:31 --> Helper loaded: url_helper
INFO - 2017-06-19 17:34:31 --> Config Class Initialized
INFO - 2017-06-19 17:34:31 --> Upload Class Initialized
INFO - 2017-06-19 17:34:31 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:34:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:34:31 --> Utf8 Class Initialized
INFO - 2017-06-19 17:34:31 --> Final output sent to browser
DEBUG - 2017-06-19 17:34:31 --> Total execution time: 0.2820
INFO - 2017-06-19 17:34:31 --> URI Class Initialized
INFO - 2017-06-19 17:34:31 --> Router Class Initialized
INFO - 2017-06-19 17:34:31 --> Output Class Initialized
INFO - 2017-06-19 17:34:31 --> Security Class Initialized
DEBUG - 2017-06-19 17:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:34:31 --> Input Class Initialized
INFO - 2017-06-19 17:34:31 --> Language Class Initialized
INFO - 2017-06-19 17:34:31 --> Loader Class Initialized
INFO - 2017-06-19 17:34:31 --> Controller Class Initialized
INFO - 2017-06-19 17:34:31 --> Database Driver Class Initialized
INFO - 2017-06-19 17:34:31 --> Model Class Initialized
INFO - 2017-06-19 17:34:31 --> Helper loaded: form_helper
INFO - 2017-06-19 17:34:31 --> Helper loaded: url_helper
INFO - 2017-06-19 17:34:31 --> Upload Class Initialized
INFO - 2017-06-19 17:34:31 --> Final output sent to browser
DEBUG - 2017-06-19 17:34:31 --> Total execution time: 0.0940
ERROR - 2017-06-19 17:34:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:34:31 --> Config Class Initialized
INFO - 2017-06-19 17:34:31 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:34:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:34:31 --> Utf8 Class Initialized
INFO - 2017-06-19 17:34:31 --> URI Class Initialized
INFO - 2017-06-19 17:34:31 --> Router Class Initialized
INFO - 2017-06-19 17:34:31 --> Output Class Initialized
INFO - 2017-06-19 17:34:31 --> Security Class Initialized
DEBUG - 2017-06-19 17:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:34:31 --> Input Class Initialized
INFO - 2017-06-19 17:34:31 --> Language Class Initialized
INFO - 2017-06-19 17:34:31 --> Loader Class Initialized
INFO - 2017-06-19 17:34:31 --> Controller Class Initialized
INFO - 2017-06-19 17:34:31 --> Database Driver Class Initialized
INFO - 2017-06-19 17:34:31 --> Model Class Initialized
INFO - 2017-06-19 17:34:31 --> Helper loaded: form_helper
INFO - 2017-06-19 17:34:31 --> Helper loaded: url_helper
INFO - 2017-06-19 17:34:31 --> Upload Class Initialized
INFO - 2017-06-19 17:34:31 --> Final output sent to browser
DEBUG - 2017-06-19 17:34:31 --> Total execution time: 0.1000
ERROR - 2017-06-19 17:34:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:34:31 --> Config Class Initialized
INFO - 2017-06-19 17:34:31 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:34:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:34:31 --> Utf8 Class Initialized
INFO - 2017-06-19 17:34:31 --> URI Class Initialized
INFO - 2017-06-19 17:34:31 --> Router Class Initialized
INFO - 2017-06-19 17:34:31 --> Output Class Initialized
INFO - 2017-06-19 17:34:31 --> Security Class Initialized
DEBUG - 2017-06-19 17:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:34:31 --> Input Class Initialized
INFO - 2017-06-19 17:34:31 --> Language Class Initialized
INFO - 2017-06-19 17:34:31 --> Loader Class Initialized
INFO - 2017-06-19 17:34:31 --> Controller Class Initialized
INFO - 2017-06-19 17:34:31 --> Database Driver Class Initialized
INFO - 2017-06-19 17:34:31 --> Model Class Initialized
INFO - 2017-06-19 17:34:31 --> Helper loaded: form_helper
INFO - 2017-06-19 17:34:31 --> Helper loaded: url_helper
INFO - 2017-06-19 17:34:31 --> Upload Class Initialized
INFO - 2017-06-19 17:34:31 --> Final output sent to browser
DEBUG - 2017-06-19 17:34:31 --> Total execution time: 0.1030
ERROR - 2017-06-19 17:34:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:34:31 --> Config Class Initialized
INFO - 2017-06-19 17:34:31 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:34:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:34:31 --> Utf8 Class Initialized
INFO - 2017-06-19 17:34:31 --> URI Class Initialized
INFO - 2017-06-19 17:34:31 --> Router Class Initialized
INFO - 2017-06-19 17:34:31 --> Output Class Initialized
INFO - 2017-06-19 17:34:31 --> Security Class Initialized
DEBUG - 2017-06-19 17:34:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-06-19 17:34:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:34:31 --> Input Class Initialized
INFO - 2017-06-19 17:34:31 --> Language Class Initialized
INFO - 2017-06-19 17:34:31 --> Config Class Initialized
INFO - 2017-06-19 17:34:31 --> Loader Class Initialized
INFO - 2017-06-19 17:34:31 --> Hooks Class Initialized
INFO - 2017-06-19 17:34:31 --> Controller Class Initialized
INFO - 2017-06-19 17:34:31 --> Database Driver Class Initialized
DEBUG - 2017-06-19 17:34:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:34:31 --> Utf8 Class Initialized
INFO - 2017-06-19 17:34:31 --> URI Class Initialized
INFO - 2017-06-19 17:34:31 --> Router Class Initialized
INFO - 2017-06-19 17:34:31 --> Output Class Initialized
INFO - 2017-06-19 17:34:31 --> Security Class Initialized
DEBUG - 2017-06-19 17:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:34:31 --> Model Class Initialized
INFO - 2017-06-19 17:34:31 --> Input Class Initialized
INFO - 2017-06-19 17:34:31 --> Helper loaded: form_helper
INFO - 2017-06-19 17:34:31 --> Language Class Initialized
INFO - 2017-06-19 17:34:31 --> Helper loaded: url_helper
INFO - 2017-06-19 17:34:31 --> Upload Class Initialized
INFO - 2017-06-19 17:34:31 --> Final output sent to browser
DEBUG - 2017-06-19 17:34:31 --> Total execution time: 0.1025
INFO - 2017-06-19 17:34:31 --> Loader Class Initialized
INFO - 2017-06-19 17:34:31 --> Controller Class Initialized
INFO - 2017-06-19 17:34:31 --> Database Driver Class Initialized
INFO - 2017-06-19 17:34:31 --> Model Class Initialized
ERROR - 2017-06-19 17:34:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:34:31 --> Helper loaded: form_helper
INFO - 2017-06-19 17:34:31 --> Helper loaded: url_helper
INFO - 2017-06-19 17:34:31 --> Config Class Initialized
INFO - 2017-06-19 17:34:31 --> Hooks Class Initialized
ERROR - 2017-06-19 17:34:31 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
DEBUG - 2017-06-19 17:34:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:34:31 --> Upload Class Initialized
INFO - 2017-06-19 17:34:31 --> Utf8 Class Initialized
INFO - 2017-06-19 17:34:31 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-06-19 17:34:31 --> URI Class Initialized
DEBUG - 2017-06-19 17:34:31 --> You did not select a file to upload.
INFO - 2017-06-19 17:34:31 --> Router Class Initialized
INFO - 2017-06-19 17:34:31 --> Final output sent to browser
DEBUG - 2017-06-19 17:34:31 --> Total execution time: 0.1730
INFO - 2017-06-19 17:34:31 --> Output Class Initialized
INFO - 2017-06-19 17:34:31 --> Security Class Initialized
DEBUG - 2017-06-19 17:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:34:31 --> Input Class Initialized
ERROR - 2017-06-19 17:34:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:34:31 --> Language Class Initialized
INFO - 2017-06-19 17:34:31 --> Config Class Initialized
INFO - 2017-06-19 17:34:31 --> Loader Class Initialized
INFO - 2017-06-19 17:34:31 --> Hooks Class Initialized
INFO - 2017-06-19 17:34:31 --> Controller Class Initialized
INFO - 2017-06-19 17:34:31 --> Database Driver Class Initialized
DEBUG - 2017-06-19 17:34:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:34:31 --> Model Class Initialized
INFO - 2017-06-19 17:34:31 --> Utf8 Class Initialized
INFO - 2017-06-19 17:34:31 --> URI Class Initialized
INFO - 2017-06-19 17:34:31 --> Helper loaded: form_helper
INFO - 2017-06-19 17:34:31 --> Router Class Initialized
INFO - 2017-06-19 17:34:31 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:34:31 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:34:31 --> Output Class Initialized
INFO - 2017-06-19 17:34:31 --> Upload Class Initialized
INFO - 2017-06-19 17:34:31 --> Security Class Initialized
INFO - 2017-06-19 17:34:31 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:34:31 --> You did not select a file to upload.
DEBUG - 2017-06-19 17:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:34:31 --> Final output sent to browser
DEBUG - 2017-06-19 17:34:31 --> Total execution time: 0.0940
INFO - 2017-06-19 17:34:32 --> Input Class Initialized
INFO - 2017-06-19 17:34:32 --> Language Class Initialized
INFO - 2017-06-19 17:34:32 --> Loader Class Initialized
INFO - 2017-06-19 17:34:32 --> Controller Class Initialized
INFO - 2017-06-19 17:34:32 --> Database Driver Class Initialized
INFO - 2017-06-19 17:34:32 --> Model Class Initialized
INFO - 2017-06-19 17:34:32 --> Helper loaded: form_helper
INFO - 2017-06-19 17:34:32 --> Helper loaded: url_helper
INFO - 2017-06-19 17:34:32 --> Upload Class Initialized
INFO - 2017-06-19 17:34:32 --> Final output sent to browser
DEBUG - 2017-06-19 17:34:32 --> Total execution time: 0.0885
ERROR - 2017-06-19 17:34:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:34:32 --> Config Class Initialized
INFO - 2017-06-19 17:34:32 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:34:32 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:34:32 --> Utf8 Class Initialized
INFO - 2017-06-19 17:34:32 --> URI Class Initialized
INFO - 2017-06-19 17:34:32 --> Router Class Initialized
INFO - 2017-06-19 17:34:32 --> Output Class Initialized
INFO - 2017-06-19 17:34:32 --> Security Class Initialized
DEBUG - 2017-06-19 17:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:34:32 --> Input Class Initialized
INFO - 2017-06-19 17:34:32 --> Language Class Initialized
INFO - 2017-06-19 17:34:32 --> Loader Class Initialized
ERROR - 2017-06-19 17:34:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:34:32 --> Controller Class Initialized
INFO - 2017-06-19 17:34:32 --> Config Class Initialized
INFO - 2017-06-19 17:34:32 --> Hooks Class Initialized
INFO - 2017-06-19 17:34:32 --> Database Driver Class Initialized
DEBUG - 2017-06-19 17:34:32 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:34:32 --> Utf8 Class Initialized
INFO - 2017-06-19 17:34:32 --> Model Class Initialized
INFO - 2017-06-19 17:34:32 --> URI Class Initialized
INFO - 2017-06-19 17:34:32 --> Router Class Initialized
INFO - 2017-06-19 17:34:32 --> Helper loaded: form_helper
INFO - 2017-06-19 17:34:32 --> Output Class Initialized
INFO - 2017-06-19 17:34:32 --> Helper loaded: url_helper
INFO - 2017-06-19 17:34:32 --> Security Class Initialized
INFO - 2017-06-19 17:34:32 --> Upload Class Initialized
DEBUG - 2017-06-19 17:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:34:32 --> Input Class Initialized
INFO - 2017-06-19 17:34:32 --> Language Class Initialized
INFO - 2017-06-19 17:34:32 --> Final output sent to browser
DEBUG - 2017-06-19 17:34:32 --> Total execution time: 0.0820
INFO - 2017-06-19 17:34:32 --> Loader Class Initialized
INFO - 2017-06-19 17:34:32 --> Controller Class Initialized
INFO - 2017-06-19 17:34:32 --> Database Driver Class Initialized
INFO - 2017-06-19 17:34:32 --> Model Class Initialized
INFO - 2017-06-19 17:34:32 --> Helper loaded: form_helper
INFO - 2017-06-19 17:34:32 --> Helper loaded: url_helper
INFO - 2017-06-19 17:34:32 --> Upload Class Initialized
INFO - 2017-06-19 17:34:32 --> Final output sent to browser
DEBUG - 2017-06-19 17:34:32 --> Total execution time: 0.0930
ERROR - 2017-06-19 17:34:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:34:33 --> Config Class Initialized
INFO - 2017-06-19 17:34:33 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:34:33 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:34:33 --> Utf8 Class Initialized
INFO - 2017-06-19 17:34:33 --> URI Class Initialized
INFO - 2017-06-19 17:34:33 --> Router Class Initialized
INFO - 2017-06-19 17:34:33 --> Output Class Initialized
INFO - 2017-06-19 17:34:33 --> Security Class Initialized
DEBUG - 2017-06-19 17:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:34:33 --> Input Class Initialized
INFO - 2017-06-19 17:34:33 --> Language Class Initialized
INFO - 2017-06-19 17:34:33 --> Loader Class Initialized
INFO - 2017-06-19 17:34:33 --> Controller Class Initialized
INFO - 2017-06-19 17:34:33 --> Database Driver Class Initialized
INFO - 2017-06-19 17:34:33 --> Model Class Initialized
INFO - 2017-06-19 17:34:33 --> Helper loaded: form_helper
INFO - 2017-06-19 17:34:33 --> Helper loaded: url_helper
INFO - 2017-06-19 17:34:33 --> Upload Class Initialized
INFO - 2017-06-19 17:34:33 --> Final output sent to browser
DEBUG - 2017-06-19 17:34:33 --> Total execution time: 0.0580
ERROR - 2017-06-19 17:35:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:35:29 --> Config Class Initialized
INFO - 2017-06-19 17:35:29 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:35:29 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:35:29 --> Utf8 Class Initialized
INFO - 2017-06-19 17:35:29 --> URI Class Initialized
INFO - 2017-06-19 17:35:29 --> Router Class Initialized
INFO - 2017-06-19 17:35:29 --> Output Class Initialized
INFO - 2017-06-19 17:35:29 --> Security Class Initialized
DEBUG - 2017-06-19 17:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:35:29 --> Input Class Initialized
INFO - 2017-06-19 17:35:29 --> Language Class Initialized
INFO - 2017-06-19 17:35:29 --> Loader Class Initialized
INFO - 2017-06-19 17:35:29 --> Controller Class Initialized
INFO - 2017-06-19 17:35:29 --> Database Driver Class Initialized
INFO - 2017-06-19 17:35:29 --> Model Class Initialized
INFO - 2017-06-19 17:35:29 --> Helper loaded: form_helper
INFO - 2017-06-19 17:35:29 --> Helper loaded: url_helper
INFO - 2017-06-19 17:35:29 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:35:29 --> Model Class Initialized
INFO - 2017-06-19 17:35:29 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:35:29 --> Final output sent to browser
DEBUG - 2017-06-19 17:35:29 --> Total execution time: 0.0660
ERROR - 2017-06-19 17:35:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:35:32 --> Config Class Initialized
INFO - 2017-06-19 17:35:32 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:35:32 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:35:32 --> Utf8 Class Initialized
INFO - 2017-06-19 17:35:32 --> URI Class Initialized
INFO - 2017-06-19 17:35:32 --> Router Class Initialized
INFO - 2017-06-19 17:35:32 --> Output Class Initialized
INFO - 2017-06-19 17:35:32 --> Security Class Initialized
DEBUG - 2017-06-19 17:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:35:32 --> Input Class Initialized
INFO - 2017-06-19 17:35:32 --> Language Class Initialized
INFO - 2017-06-19 17:35:32 --> Loader Class Initialized
INFO - 2017-06-19 17:35:32 --> Controller Class Initialized
INFO - 2017-06-19 17:35:32 --> Database Driver Class Initialized
INFO - 2017-06-19 17:35:32 --> Model Class Initialized
INFO - 2017-06-19 17:35:32 --> Helper loaded: form_helper
INFO - 2017-06-19 17:35:32 --> Helper loaded: url_helper
INFO - 2017-06-19 17:35:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:35:32 --> Model Class Initialized
INFO - 2017-06-19 17:35:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:35:32 --> Final output sent to browser
DEBUG - 2017-06-19 17:35:32 --> Total execution time: 0.0480
ERROR - 2017-06-19 17:35:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:35:39 --> Config Class Initialized
INFO - 2017-06-19 17:35:39 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:35:39 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:35:39 --> Utf8 Class Initialized
INFO - 2017-06-19 17:35:39 --> URI Class Initialized
INFO - 2017-06-19 17:35:39 --> Router Class Initialized
INFO - 2017-06-19 17:35:39 --> Output Class Initialized
INFO - 2017-06-19 17:35:39 --> Security Class Initialized
DEBUG - 2017-06-19 17:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:35:39 --> Input Class Initialized
INFO - 2017-06-19 17:35:39 --> Language Class Initialized
INFO - 2017-06-19 17:35:39 --> Loader Class Initialized
INFO - 2017-06-19 17:35:39 --> Controller Class Initialized
INFO - 2017-06-19 17:35:39 --> Database Driver Class Initialized
INFO - 2017-06-19 17:35:39 --> Model Class Initialized
INFO - 2017-06-19 17:35:39 --> Helper loaded: form_helper
INFO - 2017-06-19 17:35:39 --> Helper loaded: url_helper
INFO - 2017-06-19 17:35:39 --> Upload Class Initialized
INFO - 2017-06-19 17:35:39 --> Final output sent to browser
DEBUG - 2017-06-19 17:35:39 --> Total execution time: 0.1050
ERROR - 2017-06-19 17:35:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:35:39 --> Config Class Initialized
INFO - 2017-06-19 17:35:39 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:35:39 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:35:39 --> Utf8 Class Initialized
INFO - 2017-06-19 17:35:39 --> URI Class Initialized
INFO - 2017-06-19 17:35:39 --> Router Class Initialized
INFO - 2017-06-19 17:35:39 --> Output Class Initialized
INFO - 2017-06-19 17:35:39 --> Security Class Initialized
DEBUG - 2017-06-19 17:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:35:39 --> Input Class Initialized
INFO - 2017-06-19 17:35:39 --> Language Class Initialized
INFO - 2017-06-19 17:35:39 --> Loader Class Initialized
INFO - 2017-06-19 17:35:39 --> Controller Class Initialized
INFO - 2017-06-19 17:35:39 --> Database Driver Class Initialized
INFO - 2017-06-19 17:35:39 --> Model Class Initialized
INFO - 2017-06-19 17:35:39 --> Helper loaded: form_helper
INFO - 2017-06-19 17:35:39 --> Helper loaded: url_helper
INFO - 2017-06-19 17:35:39 --> Upload Class Initialized
INFO - 2017-06-19 17:35:39 --> Final output sent to browser
DEBUG - 2017-06-19 17:35:39 --> Total execution time: 0.1265
ERROR - 2017-06-19 17:35:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:35:39 --> Config Class Initialized
INFO - 2017-06-19 17:35:39 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:35:39 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:35:39 --> Utf8 Class Initialized
INFO - 2017-06-19 17:35:39 --> URI Class Initialized
INFO - 2017-06-19 17:35:39 --> Router Class Initialized
INFO - 2017-06-19 17:35:39 --> Output Class Initialized
INFO - 2017-06-19 17:35:39 --> Security Class Initialized
DEBUG - 2017-06-19 17:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:35:39 --> Input Class Initialized
INFO - 2017-06-19 17:35:39 --> Language Class Initialized
INFO - 2017-06-19 17:35:39 --> Loader Class Initialized
INFO - 2017-06-19 17:35:39 --> Controller Class Initialized
INFO - 2017-06-19 17:35:39 --> Database Driver Class Initialized
INFO - 2017-06-19 17:35:39 --> Model Class Initialized
INFO - 2017-06-19 17:35:39 --> Helper loaded: form_helper
INFO - 2017-06-19 17:35:39 --> Helper loaded: url_helper
INFO - 2017-06-19 17:35:39 --> Upload Class Initialized
INFO - 2017-06-19 17:35:39 --> Final output sent to browser
DEBUG - 2017-06-19 17:35:39 --> Total execution time: 0.1050
ERROR - 2017-06-19 17:35:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:35:39 --> Config Class Initialized
INFO - 2017-06-19 17:35:39 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:35:39 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:35:39 --> Utf8 Class Initialized
INFO - 2017-06-19 17:35:39 --> URI Class Initialized
ERROR - 2017-06-19 17:35:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:35:39 --> Config Class Initialized
INFO - 2017-06-19 17:35:39 --> Router Class Initialized
INFO - 2017-06-19 17:35:39 --> Hooks Class Initialized
INFO - 2017-06-19 17:35:39 --> Output Class Initialized
DEBUG - 2017-06-19 17:35:39 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:35:39 --> Utf8 Class Initialized
INFO - 2017-06-19 17:35:39 --> Security Class Initialized
INFO - 2017-06-19 17:35:39 --> URI Class Initialized
DEBUG - 2017-06-19 17:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:35:39 --> Router Class Initialized
INFO - 2017-06-19 17:35:39 --> Input Class Initialized
INFO - 2017-06-19 17:35:39 --> Output Class Initialized
INFO - 2017-06-19 17:35:39 --> Language Class Initialized
INFO - 2017-06-19 17:35:39 --> Security Class Initialized
DEBUG - 2017-06-19 17:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:35:39 --> Loader Class Initialized
INFO - 2017-06-19 17:35:39 --> Input Class Initialized
INFO - 2017-06-19 17:35:39 --> Language Class Initialized
INFO - 2017-06-19 17:35:39 --> Controller Class Initialized
INFO - 2017-06-19 17:35:39 --> Database Driver Class Initialized
INFO - 2017-06-19 17:35:39 --> Model Class Initialized
INFO - 2017-06-19 17:35:39 --> Helper loaded: form_helper
INFO - 2017-06-19 17:35:39 --> Helper loaded: url_helper
INFO - 2017-06-19 17:35:39 --> Upload Class Initialized
INFO - 2017-06-19 17:35:39 --> Final output sent to browser
DEBUG - 2017-06-19 17:35:39 --> Total execution time: 0.0870
INFO - 2017-06-19 17:35:39 --> Loader Class Initialized
INFO - 2017-06-19 17:35:39 --> Controller Class Initialized
INFO - 2017-06-19 17:35:39 --> Database Driver Class Initialized
INFO - 2017-06-19 17:35:39 --> Model Class Initialized
INFO - 2017-06-19 17:35:39 --> Helper loaded: form_helper
INFO - 2017-06-19 17:35:39 --> Helper loaded: url_helper
INFO - 2017-06-19 17:35:39 --> Upload Class Initialized
ERROR - 2017-06-19 17:35:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:35:39 --> Final output sent to browser
DEBUG - 2017-06-19 17:35:39 --> Total execution time: 0.1060
INFO - 2017-06-19 17:35:39 --> Config Class Initialized
INFO - 2017-06-19 17:35:39 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:35:39 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:35:39 --> Utf8 Class Initialized
INFO - 2017-06-19 17:35:39 --> URI Class Initialized
INFO - 2017-06-19 17:35:39 --> Router Class Initialized
INFO - 2017-06-19 17:35:39 --> Output Class Initialized
INFO - 2017-06-19 17:35:39 --> Security Class Initialized
DEBUG - 2017-06-19 17:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:35:39 --> Input Class Initialized
INFO - 2017-06-19 17:35:39 --> Language Class Initialized
INFO - 2017-06-19 17:35:39 --> Loader Class Initialized
INFO - 2017-06-19 17:35:39 --> Controller Class Initialized
INFO - 2017-06-19 17:35:39 --> Database Driver Class Initialized
INFO - 2017-06-19 17:35:39 --> Model Class Initialized
INFO - 2017-06-19 17:35:39 --> Helper loaded: form_helper
INFO - 2017-06-19 17:35:39 --> Helper loaded: url_helper
INFO - 2017-06-19 17:35:39 --> Upload Class Initialized
INFO - 2017-06-19 17:35:39 --> Final output sent to browser
DEBUG - 2017-06-19 17:35:39 --> Total execution time: 0.0790
ERROR - 2017-06-19 17:35:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:35:40 --> Config Class Initialized
INFO - 2017-06-19 17:35:40 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:35:40 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:35:40 --> Utf8 Class Initialized
INFO - 2017-06-19 17:35:40 --> URI Class Initialized
INFO - 2017-06-19 17:35:40 --> Router Class Initialized
INFO - 2017-06-19 17:35:40 --> Output Class Initialized
INFO - 2017-06-19 17:35:40 --> Security Class Initialized
DEBUG - 2017-06-19 17:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:35:40 --> Input Class Initialized
INFO - 2017-06-19 17:35:40 --> Language Class Initialized
INFO - 2017-06-19 17:35:40 --> Loader Class Initialized
INFO - 2017-06-19 17:35:40 --> Controller Class Initialized
INFO - 2017-06-19 17:35:40 --> Database Driver Class Initialized
INFO - 2017-06-19 17:35:40 --> Model Class Initialized
INFO - 2017-06-19 17:35:40 --> Helper loaded: form_helper
INFO - 2017-06-19 17:35:40 --> Helper loaded: url_helper
INFO - 2017-06-19 17:35:40 --> Upload Class Initialized
INFO - 2017-06-19 17:35:40 --> Final output sent to browser
DEBUG - 2017-06-19 17:35:40 --> Total execution time: 0.1800
ERROR - 2017-06-19 17:35:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:35:40 --> Config Class Initialized
INFO - 2017-06-19 17:35:41 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:35:41 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:35:41 --> Utf8 Class Initialized
INFO - 2017-06-19 17:35:41 --> URI Class Initialized
INFO - 2017-06-19 17:35:41 --> Router Class Initialized
INFO - 2017-06-19 17:35:41 --> Output Class Initialized
INFO - 2017-06-19 17:35:41 --> Security Class Initialized
DEBUG - 2017-06-19 17:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:35:41 --> Input Class Initialized
INFO - 2017-06-19 17:35:41 --> Language Class Initialized
INFO - 2017-06-19 17:35:41 --> Loader Class Initialized
INFO - 2017-06-19 17:35:41 --> Controller Class Initialized
INFO - 2017-06-19 17:35:41 --> Database Driver Class Initialized
INFO - 2017-06-19 17:35:41 --> Model Class Initialized
INFO - 2017-06-19 17:35:41 --> Helper loaded: form_helper
INFO - 2017-06-19 17:35:41 --> Helper loaded: url_helper
INFO - 2017-06-19 17:35:41 --> Upload Class Initialized
INFO - 2017-06-19 17:35:41 --> Final output sent to browser
DEBUG - 2017-06-19 17:35:41 --> Total execution time: 0.0840
ERROR - 2017-06-19 17:35:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:35:41 --> Config Class Initialized
INFO - 2017-06-19 17:35:41 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:35:41 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:35:41 --> Utf8 Class Initialized
INFO - 2017-06-19 17:35:41 --> URI Class Initialized
INFO - 2017-06-19 17:35:41 --> Router Class Initialized
INFO - 2017-06-19 17:35:41 --> Output Class Initialized
INFO - 2017-06-19 17:35:41 --> Security Class Initialized
DEBUG - 2017-06-19 17:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:35:41 --> Input Class Initialized
INFO - 2017-06-19 17:35:41 --> Language Class Initialized
INFO - 2017-06-19 17:35:41 --> Loader Class Initialized
INFO - 2017-06-19 17:35:41 --> Controller Class Initialized
INFO - 2017-06-19 17:35:41 --> Database Driver Class Initialized
INFO - 2017-06-19 17:35:41 --> Model Class Initialized
INFO - 2017-06-19 17:35:41 --> Helper loaded: form_helper
INFO - 2017-06-19 17:35:41 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:35:41 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:35:41 --> Upload Class Initialized
INFO - 2017-06-19 17:35:41 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:35:41 --> You did not select a file to upload.
INFO - 2017-06-19 17:35:41 --> Final output sent to browser
DEBUG - 2017-06-19 17:35:41 --> Total execution time: 0.1090
ERROR - 2017-06-19 17:35:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:35:41 --> Config Class Initialized
INFO - 2017-06-19 17:35:41 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:35:41 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:35:41 --> Utf8 Class Initialized
INFO - 2017-06-19 17:35:41 --> URI Class Initialized
INFO - 2017-06-19 17:35:41 --> Router Class Initialized
INFO - 2017-06-19 17:35:41 --> Output Class Initialized
INFO - 2017-06-19 17:35:41 --> Security Class Initialized
DEBUG - 2017-06-19 17:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:35:41 --> Input Class Initialized
ERROR - 2017-06-19 17:35:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:35:41 --> Config Class Initialized
INFO - 2017-06-19 17:35:41 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:35:41 --> UTF-8 Support Enabled
ERROR - 2017-06-19 17:35:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:35:41 --> Utf8 Class Initialized
INFO - 2017-06-19 17:35:41 --> URI Class Initialized
INFO - 2017-06-19 17:35:41 --> Router Class Initialized
INFO - 2017-06-19 17:35:41 --> Output Class Initialized
INFO - 2017-06-19 17:35:41 --> Security Class Initialized
DEBUG - 2017-06-19 17:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:35:41 --> Input Class Initialized
INFO - 2017-06-19 17:35:41 --> Language Class Initialized
INFO - 2017-06-19 17:35:41 --> Loader Class Initialized
INFO - 2017-06-19 17:35:41 --> Config Class Initialized
INFO - 2017-06-19 17:35:41 --> Language Class Initialized
INFO - 2017-06-19 17:35:41 --> Controller Class Initialized
INFO - 2017-06-19 17:35:41 --> Hooks Class Initialized
ERROR - 2017-06-19 17:35:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:35:41 --> Config Class Initialized
DEBUG - 2017-06-19 17:35:41 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:35:41 --> Hooks Class Initialized
INFO - 2017-06-19 17:35:41 --> Utf8 Class Initialized
INFO - 2017-06-19 17:35:41 --> URI Class Initialized
DEBUG - 2017-06-19 17:35:41 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:35:41 --> Utf8 Class Initialized
INFO - 2017-06-19 17:35:41 --> Router Class Initialized
INFO - 2017-06-19 17:35:41 --> URI Class Initialized
INFO - 2017-06-19 17:35:41 --> Output Class Initialized
INFO - 2017-06-19 17:35:41 --> Router Class Initialized
INFO - 2017-06-19 17:35:41 --> Security Class Initialized
INFO - 2017-06-19 17:35:41 --> Output Class Initialized
INFO - 2017-06-19 17:35:41 --> Security Class Initialized
DEBUG - 2017-06-19 17:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:35:41 --> Input Class Initialized
DEBUG - 2017-06-19 17:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:35:41 --> Language Class Initialized
INFO - 2017-06-19 17:35:41 --> Input Class Initialized
INFO - 2017-06-19 17:35:41 --> Language Class Initialized
ERROR - 2017-06-19 17:35:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:35:41 --> Config Class Initialized
INFO - 2017-06-19 17:35:41 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:35:41 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:35:41 --> Utf8 Class Initialized
INFO - 2017-06-19 17:35:41 --> URI Class Initialized
INFO - 2017-06-19 17:35:41 --> Router Class Initialized
INFO - 2017-06-19 17:35:41 --> Output Class Initialized
INFO - 2017-06-19 17:35:41 --> Security Class Initialized
DEBUG - 2017-06-19 17:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:35:41 --> Input Class Initialized
INFO - 2017-06-19 17:35:41 --> Language Class Initialized
INFO - 2017-06-19 17:35:41 --> Database Driver Class Initialized
INFO - 2017-06-19 17:35:41 --> Model Class Initialized
INFO - 2017-06-19 17:35:41 --> Helper loaded: form_helper
INFO - 2017-06-19 17:35:41 --> Helper loaded: url_helper
INFO - 2017-06-19 17:35:41 --> Upload Class Initialized
INFO - 2017-06-19 17:35:41 --> Final output sent to browser
DEBUG - 2017-06-19 17:35:41 --> Total execution time: 0.3895
INFO - 2017-06-19 17:35:41 --> Loader Class Initialized
INFO - 2017-06-19 17:35:41 --> Controller Class Initialized
INFO - 2017-06-19 17:35:41 --> Database Driver Class Initialized
INFO - 2017-06-19 17:35:41 --> Model Class Initialized
INFO - 2017-06-19 17:35:41 --> Helper loaded: form_helper
INFO - 2017-06-19 17:35:41 --> Helper loaded: url_helper
INFO - 2017-06-19 17:35:41 --> Upload Class Initialized
ERROR - 2017-06-19 17:35:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:35:42 --> Final output sent to browser
DEBUG - 2017-06-19 17:35:42 --> Total execution time: 0.5490
INFO - 2017-06-19 17:35:42 --> Config Class Initialized
INFO - 2017-06-19 17:35:42 --> Hooks Class Initialized
INFO - 2017-06-19 17:35:42 --> Loader Class Initialized
INFO - 2017-06-19 17:35:42 --> Controller Class Initialized
DEBUG - 2017-06-19 17:35:42 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:35:42 --> Utf8 Class Initialized
INFO - 2017-06-19 17:35:42 --> Database Driver Class Initialized
INFO - 2017-06-19 17:35:42 --> URI Class Initialized
INFO - 2017-06-19 17:35:42 --> Router Class Initialized
INFO - 2017-06-19 17:35:42 --> Model Class Initialized
INFO - 2017-06-19 17:35:42 --> Helper loaded: form_helper
INFO - 2017-06-19 17:35:42 --> Output Class Initialized
INFO - 2017-06-19 17:35:42 --> Helper loaded: url_helper
INFO - 2017-06-19 17:35:42 --> Upload Class Initialized
INFO - 2017-06-19 17:35:42 --> Security Class Initialized
DEBUG - 2017-06-19 17:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:35:42 --> Input Class Initialized
INFO - 2017-06-19 17:35:42 --> Language Class Initialized
INFO - 2017-06-19 17:35:42 --> Final output sent to browser
DEBUG - 2017-06-19 17:35:42 --> Total execution time: 0.5040
INFO - 2017-06-19 17:35:42 --> Loader Class Initialized
INFO - 2017-06-19 17:35:42 --> Controller Class Initialized
INFO - 2017-06-19 17:35:42 --> Database Driver Class Initialized
INFO - 2017-06-19 17:35:42 --> Model Class Initialized
INFO - 2017-06-19 17:35:42 --> Helper loaded: form_helper
INFO - 2017-06-19 17:35:42 --> Helper loaded: url_helper
INFO - 2017-06-19 17:35:42 --> Upload Class Initialized
INFO - 2017-06-19 17:35:42 --> Final output sent to browser
DEBUG - 2017-06-19 17:35:42 --> Total execution time: 0.4430
INFO - 2017-06-19 17:35:42 --> Loader Class Initialized
INFO - 2017-06-19 17:35:42 --> Controller Class Initialized
INFO - 2017-06-19 17:35:42 --> Database Driver Class Initialized
INFO - 2017-06-19 17:35:42 --> Model Class Initialized
INFO - 2017-06-19 17:35:42 --> Helper loaded: form_helper
INFO - 2017-06-19 17:35:42 --> Helper loaded: url_helper
INFO - 2017-06-19 17:35:42 --> Upload Class Initialized
INFO - 2017-06-19 17:35:42 --> Final output sent to browser
DEBUG - 2017-06-19 17:35:42 --> Total execution time: 0.3260
INFO - 2017-06-19 17:35:42 --> Loader Class Initialized
INFO - 2017-06-19 17:35:42 --> Controller Class Initialized
INFO - 2017-06-19 17:35:42 --> Database Driver Class Initialized
INFO - 2017-06-19 17:35:42 --> Model Class Initialized
INFO - 2017-06-19 17:35:42 --> Helper loaded: form_helper
INFO - 2017-06-19 17:35:42 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:35:42 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:35:42 --> Upload Class Initialized
INFO - 2017-06-19 17:35:42 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:35:42 --> You did not select a file to upload.
INFO - 2017-06-19 17:35:42 --> Final output sent to browser
DEBUG - 2017-06-19 17:35:42 --> Total execution time: 0.1880
ERROR - 2017-06-19 17:36:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:36:38 --> Config Class Initialized
INFO - 2017-06-19 17:36:38 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:36:38 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:36:38 --> Utf8 Class Initialized
INFO - 2017-06-19 17:36:38 --> URI Class Initialized
INFO - 2017-06-19 17:36:38 --> Router Class Initialized
INFO - 2017-06-19 17:36:38 --> Output Class Initialized
INFO - 2017-06-19 17:36:38 --> Security Class Initialized
DEBUG - 2017-06-19 17:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:36:38 --> Input Class Initialized
INFO - 2017-06-19 17:36:38 --> Language Class Initialized
INFO - 2017-06-19 17:36:38 --> Loader Class Initialized
INFO - 2017-06-19 17:36:38 --> Controller Class Initialized
INFO - 2017-06-19 17:36:38 --> Database Driver Class Initialized
INFO - 2017-06-19 17:36:38 --> Model Class Initialized
INFO - 2017-06-19 17:36:38 --> Helper loaded: form_helper
INFO - 2017-06-19 17:36:38 --> Helper loaded: url_helper
INFO - 2017-06-19 17:36:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:36:38 --> Model Class Initialized
INFO - 2017-06-19 17:36:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:36:38 --> Final output sent to browser
DEBUG - 2017-06-19 17:36:38 --> Total execution time: 0.0800
ERROR - 2017-06-19 17:36:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:36:42 --> Config Class Initialized
INFO - 2017-06-19 17:36:42 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:36:42 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:36:42 --> Utf8 Class Initialized
INFO - 2017-06-19 17:36:42 --> URI Class Initialized
INFO - 2017-06-19 17:36:42 --> Router Class Initialized
INFO - 2017-06-19 17:36:42 --> Output Class Initialized
INFO - 2017-06-19 17:36:42 --> Security Class Initialized
DEBUG - 2017-06-19 17:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:36:42 --> Input Class Initialized
INFO - 2017-06-19 17:36:42 --> Language Class Initialized
INFO - 2017-06-19 17:36:42 --> Loader Class Initialized
INFO - 2017-06-19 17:36:42 --> Controller Class Initialized
INFO - 2017-06-19 17:36:42 --> Database Driver Class Initialized
INFO - 2017-06-19 17:36:42 --> Model Class Initialized
INFO - 2017-06-19 17:36:42 --> Helper loaded: form_helper
INFO - 2017-06-19 17:36:42 --> Helper loaded: url_helper
INFO - 2017-06-19 17:36:42 --> Upload Class Initialized
INFO - 2017-06-19 17:36:42 --> Final output sent to browser
DEBUG - 2017-06-19 17:36:42 --> Total execution time: 0.0820
ERROR - 2017-06-19 17:36:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:36:42 --> Config Class Initialized
INFO - 2017-06-19 17:36:42 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:36:42 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:36:42 --> Utf8 Class Initialized
INFO - 2017-06-19 17:36:42 --> URI Class Initialized
INFO - 2017-06-19 17:36:42 --> Router Class Initialized
INFO - 2017-06-19 17:36:42 --> Output Class Initialized
INFO - 2017-06-19 17:36:42 --> Security Class Initialized
DEBUG - 2017-06-19 17:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:36:42 --> Input Class Initialized
INFO - 2017-06-19 17:36:42 --> Language Class Initialized
INFO - 2017-06-19 17:36:42 --> Loader Class Initialized
INFO - 2017-06-19 17:36:42 --> Controller Class Initialized
INFO - 2017-06-19 17:36:42 --> Database Driver Class Initialized
INFO - 2017-06-19 17:36:42 --> Model Class Initialized
INFO - 2017-06-19 17:36:42 --> Helper loaded: form_helper
INFO - 2017-06-19 17:36:42 --> Helper loaded: url_helper
INFO - 2017-06-19 17:36:42 --> Upload Class Initialized
INFO - 2017-06-19 17:36:42 --> Final output sent to browser
DEBUG - 2017-06-19 17:36:42 --> Total execution time: 0.0690
ERROR - 2017-06-19 17:36:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:36:42 --> Config Class Initialized
INFO - 2017-06-19 17:36:42 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:36:42 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:36:42 --> Utf8 Class Initialized
INFO - 2017-06-19 17:36:42 --> URI Class Initialized
INFO - 2017-06-19 17:36:42 --> Router Class Initialized
INFO - 2017-06-19 17:36:42 --> Output Class Initialized
INFO - 2017-06-19 17:36:42 --> Security Class Initialized
DEBUG - 2017-06-19 17:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:36:42 --> Input Class Initialized
INFO - 2017-06-19 17:36:42 --> Language Class Initialized
INFO - 2017-06-19 17:36:42 --> Loader Class Initialized
INFO - 2017-06-19 17:36:42 --> Controller Class Initialized
INFO - 2017-06-19 17:36:42 --> Database Driver Class Initialized
INFO - 2017-06-19 17:36:42 --> Model Class Initialized
INFO - 2017-06-19 17:36:42 --> Helper loaded: form_helper
INFO - 2017-06-19 17:36:42 --> Helper loaded: url_helper
INFO - 2017-06-19 17:36:42 --> Upload Class Initialized
INFO - 2017-06-19 17:36:43 --> Final output sent to browser
DEBUG - 2017-06-19 17:36:43 --> Total execution time: 0.0770
ERROR - 2017-06-19 17:36:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:36:43 --> Config Class Initialized
INFO - 2017-06-19 17:36:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:36:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:36:43 --> Utf8 Class Initialized
INFO - 2017-06-19 17:36:43 --> URI Class Initialized
INFO - 2017-06-19 17:36:43 --> Router Class Initialized
INFO - 2017-06-19 17:36:43 --> Output Class Initialized
INFO - 2017-06-19 17:36:43 --> Security Class Initialized
DEBUG - 2017-06-19 17:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:36:43 --> Input Class Initialized
INFO - 2017-06-19 17:36:43 --> Language Class Initialized
INFO - 2017-06-19 17:36:43 --> Loader Class Initialized
INFO - 2017-06-19 17:36:43 --> Controller Class Initialized
INFO - 2017-06-19 17:36:43 --> Database Driver Class Initialized
INFO - 2017-06-19 17:36:43 --> Model Class Initialized
INFO - 2017-06-19 17:36:43 --> Helper loaded: form_helper
INFO - 2017-06-19 17:36:43 --> Helper loaded: url_helper
INFO - 2017-06-19 17:36:43 --> Upload Class Initialized
INFO - 2017-06-19 17:36:43 --> Final output sent to browser
DEBUG - 2017-06-19 17:36:43 --> Total execution time: 0.0830
ERROR - 2017-06-19 17:36:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:36:43 --> Config Class Initialized
INFO - 2017-06-19 17:36:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:36:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:36:43 --> Utf8 Class Initialized
INFO - 2017-06-19 17:36:43 --> URI Class Initialized
INFO - 2017-06-19 17:36:43 --> Router Class Initialized
INFO - 2017-06-19 17:36:43 --> Output Class Initialized
INFO - 2017-06-19 17:36:43 --> Security Class Initialized
DEBUG - 2017-06-19 17:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:36:43 --> Input Class Initialized
INFO - 2017-06-19 17:36:43 --> Language Class Initialized
INFO - 2017-06-19 17:36:43 --> Loader Class Initialized
INFO - 2017-06-19 17:36:43 --> Controller Class Initialized
INFO - 2017-06-19 17:36:43 --> Database Driver Class Initialized
INFO - 2017-06-19 17:36:43 --> Model Class Initialized
INFO - 2017-06-19 17:36:43 --> Helper loaded: form_helper
INFO - 2017-06-19 17:36:43 --> Helper loaded: url_helper
INFO - 2017-06-19 17:36:43 --> Upload Class Initialized
INFO - 2017-06-19 17:36:43 --> Final output sent to browser
DEBUG - 2017-06-19 17:36:43 --> Total execution time: 0.0800
ERROR - 2017-06-19 17:36:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:36:43 --> Config Class Initialized
INFO - 2017-06-19 17:36:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:36:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:36:43 --> Utf8 Class Initialized
INFO - 2017-06-19 17:36:43 --> URI Class Initialized
INFO - 2017-06-19 17:36:43 --> Router Class Initialized
INFO - 2017-06-19 17:36:43 --> Output Class Initialized
INFO - 2017-06-19 17:36:43 --> Security Class Initialized
DEBUG - 2017-06-19 17:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:36:43 --> Input Class Initialized
INFO - 2017-06-19 17:36:43 --> Language Class Initialized
INFO - 2017-06-19 17:36:43 --> Loader Class Initialized
INFO - 2017-06-19 17:36:43 --> Controller Class Initialized
INFO - 2017-06-19 17:36:43 --> Database Driver Class Initialized
INFO - 2017-06-19 17:36:43 --> Model Class Initialized
INFO - 2017-06-19 17:36:43 --> Helper loaded: form_helper
INFO - 2017-06-19 17:36:43 --> Helper loaded: url_helper
INFO - 2017-06-19 17:36:43 --> Upload Class Initialized
INFO - 2017-06-19 17:36:43 --> Final output sent to browser
DEBUG - 2017-06-19 17:36:43 --> Total execution time: 0.0800
ERROR - 2017-06-19 17:36:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:36:43 --> Config Class Initialized
INFO - 2017-06-19 17:36:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:36:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:36:43 --> Utf8 Class Initialized
INFO - 2017-06-19 17:36:43 --> URI Class Initialized
INFO - 2017-06-19 17:36:43 --> Router Class Initialized
INFO - 2017-06-19 17:36:43 --> Output Class Initialized
INFO - 2017-06-19 17:36:43 --> Security Class Initialized
DEBUG - 2017-06-19 17:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:36:43 --> Input Class Initialized
INFO - 2017-06-19 17:36:43 --> Language Class Initialized
INFO - 2017-06-19 17:36:43 --> Loader Class Initialized
INFO - 2017-06-19 17:36:43 --> Controller Class Initialized
INFO - 2017-06-19 17:36:43 --> Database Driver Class Initialized
INFO - 2017-06-19 17:36:43 --> Model Class Initialized
INFO - 2017-06-19 17:36:43 --> Helper loaded: form_helper
INFO - 2017-06-19 17:36:43 --> Helper loaded: url_helper
INFO - 2017-06-19 17:36:43 --> Upload Class Initialized
INFO - 2017-06-19 17:36:43 --> Final output sent to browser
DEBUG - 2017-06-19 17:36:43 --> Total execution time: 0.0730
ERROR - 2017-06-19 17:36:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:36:44 --> Config Class Initialized
INFO - 2017-06-19 17:36:44 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:36:44 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:36:44 --> Utf8 Class Initialized
INFO - 2017-06-19 17:36:44 --> URI Class Initialized
INFO - 2017-06-19 17:36:44 --> Router Class Initialized
INFO - 2017-06-19 17:36:44 --> Output Class Initialized
INFO - 2017-06-19 17:36:44 --> Security Class Initialized
DEBUG - 2017-06-19 17:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:36:44 --> Input Class Initialized
INFO - 2017-06-19 17:36:44 --> Language Class Initialized
INFO - 2017-06-19 17:36:44 --> Loader Class Initialized
INFO - 2017-06-19 17:36:44 --> Controller Class Initialized
INFO - 2017-06-19 17:36:44 --> Database Driver Class Initialized
INFO - 2017-06-19 17:36:44 --> Model Class Initialized
INFO - 2017-06-19 17:36:44 --> Helper loaded: form_helper
INFO - 2017-06-19 17:36:44 --> Helper loaded: url_helper
INFO - 2017-06-19 17:36:44 --> Upload Class Initialized
INFO - 2017-06-19 17:36:44 --> Final output sent to browser
DEBUG - 2017-06-19 17:36:44 --> Total execution time: 0.0740
ERROR - 2017-06-19 17:36:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:36:44 --> Config Class Initialized
INFO - 2017-06-19 17:36:44 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:36:44 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:36:44 --> Utf8 Class Initialized
INFO - 2017-06-19 17:36:44 --> URI Class Initialized
INFO - 2017-06-19 17:36:44 --> Router Class Initialized
INFO - 2017-06-19 17:36:44 --> Output Class Initialized
INFO - 2017-06-19 17:36:44 --> Security Class Initialized
DEBUG - 2017-06-19 17:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:36:44 --> Input Class Initialized
INFO - 2017-06-19 17:36:44 --> Language Class Initialized
INFO - 2017-06-19 17:36:44 --> Loader Class Initialized
INFO - 2017-06-19 17:36:44 --> Controller Class Initialized
INFO - 2017-06-19 17:36:44 --> Database Driver Class Initialized
INFO - 2017-06-19 17:36:44 --> Model Class Initialized
INFO - 2017-06-19 17:36:44 --> Helper loaded: form_helper
INFO - 2017-06-19 17:36:44 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:36:44 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:36:44 --> Upload Class Initialized
INFO - 2017-06-19 17:36:44 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:36:44 --> You did not select a file to upload.
INFO - 2017-06-19 17:36:44 --> Final output sent to browser
DEBUG - 2017-06-19 17:36:44 --> Total execution time: 0.0660
ERROR - 2017-06-19 17:36:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:36:44 --> Config Class Initialized
INFO - 2017-06-19 17:36:44 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:36:44 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:36:44 --> Utf8 Class Initialized
INFO - 2017-06-19 17:36:44 --> URI Class Initialized
INFO - 2017-06-19 17:36:44 --> Router Class Initialized
INFO - 2017-06-19 17:36:44 --> Output Class Initialized
INFO - 2017-06-19 17:36:44 --> Security Class Initialized
DEBUG - 2017-06-19 17:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:36:44 --> Input Class Initialized
INFO - 2017-06-19 17:36:44 --> Language Class Initialized
INFO - 2017-06-19 17:36:44 --> Loader Class Initialized
INFO - 2017-06-19 17:36:44 --> Controller Class Initialized
INFO - 2017-06-19 17:36:44 --> Database Driver Class Initialized
INFO - 2017-06-19 17:36:44 --> Model Class Initialized
INFO - 2017-06-19 17:36:44 --> Helper loaded: form_helper
INFO - 2017-06-19 17:36:44 --> Helper loaded: url_helper
INFO - 2017-06-19 17:36:44 --> Upload Class Initialized
INFO - 2017-06-19 17:36:44 --> Final output sent to browser
DEBUG - 2017-06-19 17:36:44 --> Total execution time: 0.0860
ERROR - 2017-06-19 17:36:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:36:44 --> Config Class Initialized
INFO - 2017-06-19 17:36:44 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:36:44 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:36:44 --> Utf8 Class Initialized
INFO - 2017-06-19 17:36:44 --> URI Class Initialized
INFO - 2017-06-19 17:36:44 --> Router Class Initialized
INFO - 2017-06-19 17:36:44 --> Output Class Initialized
INFO - 2017-06-19 17:36:44 --> Security Class Initialized
DEBUG - 2017-06-19 17:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:36:44 --> Input Class Initialized
INFO - 2017-06-19 17:36:44 --> Language Class Initialized
INFO - 2017-06-19 17:36:44 --> Loader Class Initialized
INFO - 2017-06-19 17:36:44 --> Controller Class Initialized
INFO - 2017-06-19 17:36:44 --> Database Driver Class Initialized
INFO - 2017-06-19 17:36:44 --> Model Class Initialized
INFO - 2017-06-19 17:36:44 --> Helper loaded: form_helper
INFO - 2017-06-19 17:36:44 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:36:44 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:36:44 --> Upload Class Initialized
INFO - 2017-06-19 17:36:44 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:36:44 --> You did not select a file to upload.
INFO - 2017-06-19 17:36:44 --> Final output sent to browser
DEBUG - 2017-06-19 17:36:44 --> Total execution time: 0.0630
ERROR - 2017-06-19 17:36:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:36:44 --> Config Class Initialized
INFO - 2017-06-19 17:36:44 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:36:44 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:36:44 --> Utf8 Class Initialized
INFO - 2017-06-19 17:36:44 --> URI Class Initialized
INFO - 2017-06-19 17:36:44 --> Router Class Initialized
INFO - 2017-06-19 17:36:44 --> Output Class Initialized
INFO - 2017-06-19 17:36:44 --> Security Class Initialized
DEBUG - 2017-06-19 17:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:36:44 --> Input Class Initialized
INFO - 2017-06-19 17:36:44 --> Language Class Initialized
INFO - 2017-06-19 17:36:44 --> Loader Class Initialized
INFO - 2017-06-19 17:36:44 --> Controller Class Initialized
INFO - 2017-06-19 17:36:44 --> Database Driver Class Initialized
INFO - 2017-06-19 17:36:44 --> Model Class Initialized
INFO - 2017-06-19 17:36:44 --> Helper loaded: form_helper
INFO - 2017-06-19 17:36:44 --> Helper loaded: url_helper
INFO - 2017-06-19 17:36:44 --> Upload Class Initialized
INFO - 2017-06-19 17:36:44 --> Final output sent to browser
DEBUG - 2017-06-19 17:36:44 --> Total execution time: 0.0710
ERROR - 2017-06-19 17:36:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:36:44 --> Config Class Initialized
INFO - 2017-06-19 17:36:44 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:36:44 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:36:44 --> Utf8 Class Initialized
INFO - 2017-06-19 17:36:44 --> URI Class Initialized
INFO - 2017-06-19 17:36:44 --> Router Class Initialized
INFO - 2017-06-19 17:36:44 --> Output Class Initialized
INFO - 2017-06-19 17:36:44 --> Security Class Initialized
DEBUG - 2017-06-19 17:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:36:44 --> Input Class Initialized
INFO - 2017-06-19 17:36:44 --> Language Class Initialized
INFO - 2017-06-19 17:36:44 --> Loader Class Initialized
INFO - 2017-06-19 17:36:44 --> Controller Class Initialized
INFO - 2017-06-19 17:36:44 --> Database Driver Class Initialized
INFO - 2017-06-19 17:36:44 --> Model Class Initialized
INFO - 2017-06-19 17:36:44 --> Helper loaded: form_helper
INFO - 2017-06-19 17:36:44 --> Helper loaded: url_helper
INFO - 2017-06-19 17:36:44 --> Upload Class Initialized
INFO - 2017-06-19 17:36:45 --> Final output sent to browser
DEBUG - 2017-06-19 17:36:45 --> Total execution time: 0.0800
ERROR - 2017-06-19 17:36:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:36:45 --> Config Class Initialized
INFO - 2017-06-19 17:36:45 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:36:45 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:36:45 --> Utf8 Class Initialized
INFO - 2017-06-19 17:36:45 --> URI Class Initialized
INFO - 2017-06-19 17:36:45 --> Router Class Initialized
INFO - 2017-06-19 17:36:45 --> Output Class Initialized
INFO - 2017-06-19 17:36:45 --> Security Class Initialized
DEBUG - 2017-06-19 17:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:36:45 --> Input Class Initialized
INFO - 2017-06-19 17:36:45 --> Language Class Initialized
INFO - 2017-06-19 17:36:45 --> Loader Class Initialized
INFO - 2017-06-19 17:36:45 --> Controller Class Initialized
INFO - 2017-06-19 17:36:45 --> Database Driver Class Initialized
INFO - 2017-06-19 17:36:45 --> Model Class Initialized
INFO - 2017-06-19 17:36:45 --> Helper loaded: form_helper
INFO - 2017-06-19 17:36:45 --> Helper loaded: url_helper
INFO - 2017-06-19 17:36:45 --> Upload Class Initialized
INFO - 2017-06-19 17:36:45 --> Final output sent to browser
DEBUG - 2017-06-19 17:36:45 --> Total execution time: 0.0715
ERROR - 2017-06-19 17:36:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:36:46 --> Config Class Initialized
INFO - 2017-06-19 17:36:46 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:36:46 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:36:46 --> Utf8 Class Initialized
INFO - 2017-06-19 17:36:46 --> URI Class Initialized
INFO - 2017-06-19 17:36:46 --> Router Class Initialized
INFO - 2017-06-19 17:36:46 --> Output Class Initialized
INFO - 2017-06-19 17:36:46 --> Security Class Initialized
DEBUG - 2017-06-19 17:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:36:46 --> Input Class Initialized
INFO - 2017-06-19 17:36:46 --> Language Class Initialized
INFO - 2017-06-19 17:36:46 --> Loader Class Initialized
INFO - 2017-06-19 17:36:46 --> Controller Class Initialized
INFO - 2017-06-19 17:36:46 --> Database Driver Class Initialized
INFO - 2017-06-19 17:36:46 --> Model Class Initialized
INFO - 2017-06-19 17:36:46 --> Helper loaded: form_helper
INFO - 2017-06-19 17:36:46 --> Helper loaded: url_helper
INFO - 2017-06-19 17:36:46 --> Upload Class Initialized
INFO - 2017-06-19 17:36:46 --> Final output sent to browser
DEBUG - 2017-06-19 17:36:46 --> Total execution time: 0.0510
ERROR - 2017-06-19 17:37:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:37:19 --> Config Class Initialized
INFO - 2017-06-19 17:37:19 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:37:19 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:37:19 --> Utf8 Class Initialized
INFO - 2017-06-19 17:37:19 --> URI Class Initialized
INFO - 2017-06-19 17:37:19 --> Router Class Initialized
INFO - 2017-06-19 17:37:19 --> Output Class Initialized
INFO - 2017-06-19 17:37:19 --> Security Class Initialized
DEBUG - 2017-06-19 17:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:37:19 --> Input Class Initialized
INFO - 2017-06-19 17:37:19 --> Language Class Initialized
INFO - 2017-06-19 17:37:19 --> Loader Class Initialized
INFO - 2017-06-19 17:37:19 --> Controller Class Initialized
INFO - 2017-06-19 17:37:19 --> Database Driver Class Initialized
INFO - 2017-06-19 17:37:19 --> Model Class Initialized
INFO - 2017-06-19 17:37:19 --> Helper loaded: form_helper
INFO - 2017-06-19 17:37:19 --> Helper loaded: url_helper
INFO - 2017-06-19 17:37:19 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:37:19 --> Model Class Initialized
INFO - 2017-06-19 17:37:19 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:37:19 --> Final output sent to browser
DEBUG - 2017-06-19 17:37:19 --> Total execution time: 0.0640
ERROR - 2017-06-19 17:37:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:37:25 --> Config Class Initialized
INFO - 2017-06-19 17:37:25 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:37:25 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:37:25 --> Utf8 Class Initialized
INFO - 2017-06-19 17:37:25 --> URI Class Initialized
INFO - 2017-06-19 17:37:25 --> Router Class Initialized
INFO - 2017-06-19 17:37:25 --> Output Class Initialized
INFO - 2017-06-19 17:37:25 --> Security Class Initialized
DEBUG - 2017-06-19 17:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:37:25 --> Input Class Initialized
INFO - 2017-06-19 17:37:25 --> Language Class Initialized
INFO - 2017-06-19 17:37:25 --> Loader Class Initialized
INFO - 2017-06-19 17:37:25 --> Controller Class Initialized
INFO - 2017-06-19 17:37:25 --> Database Driver Class Initialized
INFO - 2017-06-19 17:37:25 --> Model Class Initialized
INFO - 2017-06-19 17:37:25 --> Helper loaded: form_helper
INFO - 2017-06-19 17:37:25 --> Helper loaded: url_helper
INFO - 2017-06-19 17:37:25 --> Upload Class Initialized
INFO - 2017-06-19 17:37:25 --> Final output sent to browser
DEBUG - 2017-06-19 17:37:25 --> Total execution time: 0.0515
ERROR - 2017-06-19 17:37:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:37:29 --> Config Class Initialized
INFO - 2017-06-19 17:37:29 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:37:29 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:37:29 --> Utf8 Class Initialized
INFO - 2017-06-19 17:37:29 --> URI Class Initialized
INFO - 2017-06-19 17:37:29 --> Router Class Initialized
INFO - 2017-06-19 17:37:29 --> Output Class Initialized
INFO - 2017-06-19 17:37:29 --> Security Class Initialized
DEBUG - 2017-06-19 17:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:37:29 --> Input Class Initialized
INFO - 2017-06-19 17:37:29 --> Language Class Initialized
INFO - 2017-06-19 17:37:29 --> Loader Class Initialized
INFO - 2017-06-19 17:37:29 --> Controller Class Initialized
INFO - 2017-06-19 17:37:29 --> Database Driver Class Initialized
INFO - 2017-06-19 17:37:29 --> Model Class Initialized
INFO - 2017-06-19 17:37:29 --> Helper loaded: form_helper
INFO - 2017-06-19 17:37:29 --> Helper loaded: url_helper
INFO - 2017-06-19 17:37:29 --> Upload Class Initialized
INFO - 2017-06-19 17:37:29 --> Final output sent to browser
DEBUG - 2017-06-19 17:37:29 --> Total execution time: 0.0595
ERROR - 2017-06-19 17:37:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:37:33 --> Config Class Initialized
INFO - 2017-06-19 17:37:33 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:37:33 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:37:33 --> Utf8 Class Initialized
INFO - 2017-06-19 17:37:33 --> URI Class Initialized
INFO - 2017-06-19 17:37:33 --> Router Class Initialized
INFO - 2017-06-19 17:37:33 --> Output Class Initialized
INFO - 2017-06-19 17:37:33 --> Security Class Initialized
DEBUG - 2017-06-19 17:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:37:33 --> Input Class Initialized
INFO - 2017-06-19 17:37:33 --> Language Class Initialized
INFO - 2017-06-19 17:37:33 --> Loader Class Initialized
INFO - 2017-06-19 17:37:33 --> Controller Class Initialized
INFO - 2017-06-19 17:37:33 --> Database Driver Class Initialized
INFO - 2017-06-19 17:37:33 --> Model Class Initialized
INFO - 2017-06-19 17:37:33 --> Helper loaded: form_helper
INFO - 2017-06-19 17:37:33 --> Helper loaded: url_helper
INFO - 2017-06-19 17:37:33 --> Upload Class Initialized
INFO - 2017-06-19 17:37:33 --> Final output sent to browser
DEBUG - 2017-06-19 17:37:33 --> Total execution time: 0.0520
ERROR - 2017-06-19 17:37:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:37:36 --> Config Class Initialized
INFO - 2017-06-19 17:37:36 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:37:36 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:37:36 --> Utf8 Class Initialized
INFO - 2017-06-19 17:37:36 --> URI Class Initialized
INFO - 2017-06-19 17:37:36 --> Router Class Initialized
INFO - 2017-06-19 17:37:36 --> Output Class Initialized
INFO - 2017-06-19 17:37:36 --> Security Class Initialized
DEBUG - 2017-06-19 17:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:37:37 --> Input Class Initialized
INFO - 2017-06-19 17:37:37 --> Language Class Initialized
INFO - 2017-06-19 17:37:37 --> Loader Class Initialized
INFO - 2017-06-19 17:37:37 --> Controller Class Initialized
INFO - 2017-06-19 17:37:37 --> Database Driver Class Initialized
INFO - 2017-06-19 17:37:37 --> Model Class Initialized
INFO - 2017-06-19 17:37:37 --> Helper loaded: form_helper
INFO - 2017-06-19 17:37:37 --> Helper loaded: url_helper
INFO - 2017-06-19 17:37:37 --> Upload Class Initialized
INFO - 2017-06-19 17:37:37 --> Final output sent to browser
DEBUG - 2017-06-19 17:37:37 --> Total execution time: 0.0530
ERROR - 2017-06-19 17:37:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:37:41 --> Config Class Initialized
INFO - 2017-06-19 17:37:41 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:37:41 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:37:41 --> Utf8 Class Initialized
INFO - 2017-06-19 17:37:41 --> URI Class Initialized
INFO - 2017-06-19 17:37:41 --> Router Class Initialized
INFO - 2017-06-19 17:37:41 --> Output Class Initialized
INFO - 2017-06-19 17:37:41 --> Security Class Initialized
DEBUG - 2017-06-19 17:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:37:41 --> Input Class Initialized
INFO - 2017-06-19 17:37:41 --> Language Class Initialized
INFO - 2017-06-19 17:37:41 --> Loader Class Initialized
INFO - 2017-06-19 17:37:41 --> Controller Class Initialized
INFO - 2017-06-19 17:37:41 --> Database Driver Class Initialized
INFO - 2017-06-19 17:37:41 --> Model Class Initialized
INFO - 2017-06-19 17:37:41 --> Helper loaded: form_helper
INFO - 2017-06-19 17:37:41 --> Helper loaded: url_helper
INFO - 2017-06-19 17:37:41 --> Upload Class Initialized
INFO - 2017-06-19 17:37:41 --> Final output sent to browser
DEBUG - 2017-06-19 17:37:41 --> Total execution time: 0.0500
ERROR - 2017-06-19 17:37:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:37:56 --> Config Class Initialized
INFO - 2017-06-19 17:37:56 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:37:56 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:37:56 --> Utf8 Class Initialized
INFO - 2017-06-19 17:37:56 --> URI Class Initialized
INFO - 2017-06-19 17:37:56 --> Router Class Initialized
INFO - 2017-06-19 17:37:56 --> Output Class Initialized
INFO - 2017-06-19 17:37:56 --> Security Class Initialized
DEBUG - 2017-06-19 17:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:37:56 --> Input Class Initialized
INFO - 2017-06-19 17:37:56 --> Language Class Initialized
INFO - 2017-06-19 17:37:56 --> Loader Class Initialized
INFO - 2017-06-19 17:37:56 --> Controller Class Initialized
INFO - 2017-06-19 17:37:56 --> Database Driver Class Initialized
INFO - 2017-06-19 17:37:56 --> Model Class Initialized
INFO - 2017-06-19 17:37:56 --> Helper loaded: form_helper
INFO - 2017-06-19 17:37:56 --> Helper loaded: url_helper
INFO - 2017-06-19 17:37:56 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:37:56 --> Model Class Initialized
INFO - 2017-06-19 17:37:56 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:37:56 --> Final output sent to browser
DEBUG - 2017-06-19 17:37:56 --> Total execution time: 0.0590
ERROR - 2017-06-19 17:38:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:38:00 --> Config Class Initialized
INFO - 2017-06-19 17:38:00 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:38:00 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:38:00 --> Utf8 Class Initialized
INFO - 2017-06-19 17:38:00 --> URI Class Initialized
INFO - 2017-06-19 17:38:00 --> Router Class Initialized
INFO - 2017-06-19 17:38:00 --> Output Class Initialized
INFO - 2017-06-19 17:38:00 --> Security Class Initialized
ERROR - 2017-06-19 17:38:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
DEBUG - 2017-06-19 17:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:38:00 --> Input Class Initialized
INFO - 2017-06-19 17:38:00 --> Language Class Initialized
INFO - 2017-06-19 17:38:00 --> Config Class Initialized
INFO - 2017-06-19 17:38:00 --> Loader Class Initialized
INFO - 2017-06-19 17:38:00 --> Hooks Class Initialized
INFO - 2017-06-19 17:38:00 --> Controller Class Initialized
INFO - 2017-06-19 17:38:00 --> Database Driver Class Initialized
DEBUG - 2017-06-19 17:38:00 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:38:00 --> Utf8 Class Initialized
INFO - 2017-06-19 17:38:00 --> URI Class Initialized
INFO - 2017-06-19 17:38:00 --> Router Class Initialized
INFO - 2017-06-19 17:38:00 --> Output Class Initialized
INFO - 2017-06-19 17:38:00 --> Security Class Initialized
INFO - 2017-06-19 17:38:00 --> Model Class Initialized
INFO - 2017-06-19 17:38:00 --> Helper loaded: form_helper
DEBUG - 2017-06-19 17:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:38:00 --> Input Class Initialized
INFO - 2017-06-19 17:38:00 --> Helper loaded: url_helper
INFO - 2017-06-19 17:38:00 --> Language Class Initialized
INFO - 2017-06-19 17:38:00 --> Upload Class Initialized
INFO - 2017-06-19 17:38:00 --> Final output sent to browser
DEBUG - 2017-06-19 17:38:00 --> Total execution time: 0.1520
INFO - 2017-06-19 17:38:00 --> Loader Class Initialized
INFO - 2017-06-19 17:38:00 --> Controller Class Initialized
INFO - 2017-06-19 17:38:00 --> Database Driver Class Initialized
ERROR - 2017-06-19 17:38:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:38:00 --> Config Class Initialized
INFO - 2017-06-19 17:38:00 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:38:00 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:38:00 --> Utf8 Class Initialized
INFO - 2017-06-19 17:38:00 --> URI Class Initialized
INFO - 2017-06-19 17:38:00 --> Router Class Initialized
INFO - 2017-06-19 17:38:00 --> Output Class Initialized
INFO - 2017-06-19 17:38:00 --> Model Class Initialized
INFO - 2017-06-19 17:38:00 --> Helper loaded: form_helper
INFO - 2017-06-19 17:38:00 --> Security Class Initialized
DEBUG - 2017-06-19 17:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:38:00 --> Helper loaded: url_helper
INFO - 2017-06-19 17:38:00 --> Input Class Initialized
INFO - 2017-06-19 17:38:00 --> Upload Class Initialized
INFO - 2017-06-19 17:38:00 --> Language Class Initialized
INFO - 2017-06-19 17:38:00 --> Final output sent to browser
DEBUG - 2017-06-19 17:38:00 --> Total execution time: 0.2290
INFO - 2017-06-19 17:38:00 --> Loader Class Initialized
ERROR - 2017-06-19 17:38:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:38:00 --> Controller Class Initialized
INFO - 2017-06-19 17:38:00 --> Database Driver Class Initialized
INFO - 2017-06-19 17:38:00 --> Model Class Initialized
INFO - 2017-06-19 17:38:00 --> Helper loaded: form_helper
INFO - 2017-06-19 17:38:00 --> Helper loaded: url_helper
INFO - 2017-06-19 17:38:00 --> Upload Class Initialized
INFO - 2017-06-19 17:38:00 --> Config Class Initialized
INFO - 2017-06-19 17:38:00 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:38:00 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:38:00 --> Utf8 Class Initialized
INFO - 2017-06-19 17:38:00 --> URI Class Initialized
INFO - 2017-06-19 17:38:00 --> Final output sent to browser
INFO - 2017-06-19 17:38:00 --> Router Class Initialized
DEBUG - 2017-06-19 17:38:00 --> Total execution time: 0.1540
INFO - 2017-06-19 17:38:00 --> Output Class Initialized
INFO - 2017-06-19 17:38:00 --> Security Class Initialized
DEBUG - 2017-06-19 17:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:38:00 --> Input Class Initialized
INFO - 2017-06-19 17:38:00 --> Language Class Initialized
INFO - 2017-06-19 17:38:00 --> Loader Class Initialized
INFO - 2017-06-19 17:38:00 --> Controller Class Initialized
INFO - 2017-06-19 17:38:00 --> Database Driver Class Initialized
ERROR - 2017-06-19 17:38:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:38:00 --> Config Class Initialized
INFO - 2017-06-19 17:38:00 --> Model Class Initialized
INFO - 2017-06-19 17:38:00 --> Hooks Class Initialized
INFO - 2017-06-19 17:38:00 --> Helper loaded: form_helper
DEBUG - 2017-06-19 17:38:00 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:38:00 --> Helper loaded: url_helper
INFO - 2017-06-19 17:38:00 --> Utf8 Class Initialized
INFO - 2017-06-19 17:38:00 --> URI Class Initialized
INFO - 2017-06-19 17:38:00 --> Upload Class Initialized
INFO - 2017-06-19 17:38:00 --> Router Class Initialized
INFO - 2017-06-19 17:38:00 --> Output Class Initialized
INFO - 2017-06-19 17:38:00 --> Final output sent to browser
INFO - 2017-06-19 17:38:00 --> Security Class Initialized
DEBUG - 2017-06-19 17:38:00 --> Total execution time: 0.2045
DEBUG - 2017-06-19 17:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:38:00 --> Input Class Initialized
INFO - 2017-06-19 17:38:01 --> Language Class Initialized
INFO - 2017-06-19 17:38:01 --> Loader Class Initialized
INFO - 2017-06-19 17:38:01 --> Controller Class Initialized
INFO - 2017-06-19 17:38:01 --> Database Driver Class Initialized
INFO - 2017-06-19 17:38:01 --> Model Class Initialized
INFO - 2017-06-19 17:38:01 --> Helper loaded: form_helper
INFO - 2017-06-19 17:38:01 --> Helper loaded: url_helper
INFO - 2017-06-19 17:38:01 --> Upload Class Initialized
INFO - 2017-06-19 17:38:01 --> Final output sent to browser
DEBUG - 2017-06-19 17:38:01 --> Total execution time: 0.1025
ERROR - 2017-06-19 17:38:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:38:01 --> Config Class Initialized
INFO - 2017-06-19 17:38:01 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:38:01 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:38:01 --> Utf8 Class Initialized
INFO - 2017-06-19 17:38:01 --> URI Class Initialized
INFO - 2017-06-19 17:38:01 --> Router Class Initialized
INFO - 2017-06-19 17:38:01 --> Output Class Initialized
INFO - 2017-06-19 17:38:01 --> Security Class Initialized
DEBUG - 2017-06-19 17:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:38:01 --> Input Class Initialized
INFO - 2017-06-19 17:38:01 --> Language Class Initialized
INFO - 2017-06-19 17:38:01 --> Loader Class Initialized
INFO - 2017-06-19 17:38:01 --> Controller Class Initialized
INFO - 2017-06-19 17:38:01 --> Database Driver Class Initialized
INFO - 2017-06-19 17:38:01 --> Model Class Initialized
INFO - 2017-06-19 17:38:01 --> Helper loaded: form_helper
INFO - 2017-06-19 17:38:01 --> Helper loaded: url_helper
INFO - 2017-06-19 17:38:01 --> Upload Class Initialized
INFO - 2017-06-19 17:38:01 --> Final output sent to browser
DEBUG - 2017-06-19 17:38:01 --> Total execution time: 0.1890
ERROR - 2017-06-19 17:38:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:38:01 --> Config Class Initialized
INFO - 2017-06-19 17:38:01 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:38:01 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:38:01 --> Utf8 Class Initialized
INFO - 2017-06-19 17:38:01 --> URI Class Initialized
INFO - 2017-06-19 17:38:01 --> Router Class Initialized
INFO - 2017-06-19 17:38:01 --> Output Class Initialized
INFO - 2017-06-19 17:38:01 --> Security Class Initialized
DEBUG - 2017-06-19 17:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:38:01 --> Input Class Initialized
INFO - 2017-06-19 17:38:01 --> Language Class Initialized
INFO - 2017-06-19 17:38:01 --> Loader Class Initialized
INFO - 2017-06-19 17:38:01 --> Controller Class Initialized
INFO - 2017-06-19 17:38:01 --> Database Driver Class Initialized
INFO - 2017-06-19 17:38:01 --> Model Class Initialized
INFO - 2017-06-19 17:38:01 --> Helper loaded: form_helper
INFO - 2017-06-19 17:38:01 --> Helper loaded: url_helper
INFO - 2017-06-19 17:38:01 --> Upload Class Initialized
INFO - 2017-06-19 17:38:01 --> Final output sent to browser
DEBUG - 2017-06-19 17:38:01 --> Total execution time: 0.0730
ERROR - 2017-06-19 17:38:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:38:01 --> Config Class Initialized
INFO - 2017-06-19 17:38:01 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:38:01 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:38:01 --> Utf8 Class Initialized
INFO - 2017-06-19 17:38:01 --> URI Class Initialized
INFO - 2017-06-19 17:38:01 --> Router Class Initialized
INFO - 2017-06-19 17:38:01 --> Output Class Initialized
INFO - 2017-06-19 17:38:01 --> Security Class Initialized
DEBUG - 2017-06-19 17:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:38:01 --> Input Class Initialized
INFO - 2017-06-19 17:38:01 --> Language Class Initialized
INFO - 2017-06-19 17:38:01 --> Loader Class Initialized
INFO - 2017-06-19 17:38:02 --> Controller Class Initialized
INFO - 2017-06-19 17:38:02 --> Database Driver Class Initialized
INFO - 2017-06-19 17:38:02 --> Model Class Initialized
INFO - 2017-06-19 17:38:02 --> Helper loaded: form_helper
INFO - 2017-06-19 17:38:02 --> Helper loaded: url_helper
INFO - 2017-06-19 17:38:02 --> Upload Class Initialized
INFO - 2017-06-19 17:38:02 --> Final output sent to browser
DEBUG - 2017-06-19 17:38:02 --> Total execution time: 0.0960
ERROR - 2017-06-19 17:38:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:38:02 --> Config Class Initialized
INFO - 2017-06-19 17:38:02 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:38:02 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:38:02 --> Utf8 Class Initialized
INFO - 2017-06-19 17:38:02 --> URI Class Initialized
INFO - 2017-06-19 17:38:02 --> Router Class Initialized
INFO - 2017-06-19 17:38:02 --> Output Class Initialized
INFO - 2017-06-19 17:38:02 --> Security Class Initialized
DEBUG - 2017-06-19 17:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:38:02 --> Input Class Initialized
INFO - 2017-06-19 17:38:02 --> Language Class Initialized
INFO - 2017-06-19 17:38:02 --> Loader Class Initialized
INFO - 2017-06-19 17:38:02 --> Controller Class Initialized
INFO - 2017-06-19 17:38:02 --> Database Driver Class Initialized
INFO - 2017-06-19 17:38:02 --> Model Class Initialized
INFO - 2017-06-19 17:38:02 --> Helper loaded: form_helper
INFO - 2017-06-19 17:38:02 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:38:02 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:38:02 --> Upload Class Initialized
INFO - 2017-06-19 17:38:02 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:38:02 --> You did not select a file to upload.
INFO - 2017-06-19 17:38:02 --> Final output sent to browser
DEBUG - 2017-06-19 17:38:02 --> Total execution time: 0.0760
ERROR - 2017-06-19 17:38:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:38:02 --> Config Class Initialized
INFO - 2017-06-19 17:38:02 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:38:02 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:38:02 --> Utf8 Class Initialized
INFO - 2017-06-19 17:38:02 --> URI Class Initialized
INFO - 2017-06-19 17:38:02 --> Router Class Initialized
INFO - 2017-06-19 17:38:02 --> Output Class Initialized
INFO - 2017-06-19 17:38:02 --> Security Class Initialized
DEBUG - 2017-06-19 17:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:38:02 --> Input Class Initialized
INFO - 2017-06-19 17:38:02 --> Language Class Initialized
INFO - 2017-06-19 17:38:02 --> Loader Class Initialized
INFO - 2017-06-19 17:38:02 --> Controller Class Initialized
INFO - 2017-06-19 17:38:02 --> Database Driver Class Initialized
INFO - 2017-06-19 17:38:02 --> Model Class Initialized
INFO - 2017-06-19 17:38:02 --> Helper loaded: form_helper
INFO - 2017-06-19 17:38:02 --> Helper loaded: url_helper
INFO - 2017-06-19 17:38:02 --> Upload Class Initialized
INFO - 2017-06-19 17:38:02 --> Final output sent to browser
DEBUG - 2017-06-19 17:38:02 --> Total execution time: 0.0785
ERROR - 2017-06-19 17:38:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:38:02 --> Config Class Initialized
INFO - 2017-06-19 17:38:02 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:38:02 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:38:02 --> Utf8 Class Initialized
INFO - 2017-06-19 17:38:02 --> URI Class Initialized
INFO - 2017-06-19 17:38:02 --> Router Class Initialized
INFO - 2017-06-19 17:38:02 --> Output Class Initialized
INFO - 2017-06-19 17:38:02 --> Security Class Initialized
DEBUG - 2017-06-19 17:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:38:02 --> Input Class Initialized
INFO - 2017-06-19 17:38:02 --> Language Class Initialized
INFO - 2017-06-19 17:38:02 --> Loader Class Initialized
INFO - 2017-06-19 17:38:02 --> Controller Class Initialized
INFO - 2017-06-19 17:38:02 --> Database Driver Class Initialized
INFO - 2017-06-19 17:38:02 --> Model Class Initialized
INFO - 2017-06-19 17:38:02 --> Helper loaded: form_helper
INFO - 2017-06-19 17:38:02 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:38:02 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:38:02 --> Upload Class Initialized
INFO - 2017-06-19 17:38:02 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:38:02 --> You did not select a file to upload.
INFO - 2017-06-19 17:38:02 --> Final output sent to browser
DEBUG - 2017-06-19 17:38:02 --> Total execution time: 0.0895
ERROR - 2017-06-19 17:38:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:38:02 --> Config Class Initialized
INFO - 2017-06-19 17:38:02 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:38:02 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:38:02 --> Utf8 Class Initialized
INFO - 2017-06-19 17:38:02 --> URI Class Initialized
INFO - 2017-06-19 17:38:02 --> Router Class Initialized
INFO - 2017-06-19 17:38:02 --> Output Class Initialized
INFO - 2017-06-19 17:38:02 --> Security Class Initialized
DEBUG - 2017-06-19 17:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:38:02 --> Input Class Initialized
INFO - 2017-06-19 17:38:02 --> Language Class Initialized
INFO - 2017-06-19 17:38:02 --> Loader Class Initialized
INFO - 2017-06-19 17:38:02 --> Controller Class Initialized
ERROR - 2017-06-19 17:38:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:38:02 --> Config Class Initialized
INFO - 2017-06-19 17:38:02 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:38:02 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:38:02 --> Utf8 Class Initialized
INFO - 2017-06-19 17:38:02 --> URI Class Initialized
INFO - 2017-06-19 17:38:02 --> Database Driver Class Initialized
INFO - 2017-06-19 17:38:02 --> Router Class Initialized
INFO - 2017-06-19 17:38:02 --> Output Class Initialized
INFO - 2017-06-19 17:38:02 --> Security Class Initialized
INFO - 2017-06-19 17:38:02 --> Model Class Initialized
DEBUG - 2017-06-19 17:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:38:02 --> Input Class Initialized
INFO - 2017-06-19 17:38:02 --> Language Class Initialized
INFO - 2017-06-19 17:38:02 --> Helper loaded: form_helper
INFO - 2017-06-19 17:38:02 --> Helper loaded: url_helper
INFO - 2017-06-19 17:38:02 --> Upload Class Initialized
INFO - 2017-06-19 17:38:02 --> Final output sent to browser
DEBUG - 2017-06-19 17:38:02 --> Total execution time: 0.0970
INFO - 2017-06-19 17:38:02 --> Loader Class Initialized
INFO - 2017-06-19 17:38:02 --> Controller Class Initialized
INFO - 2017-06-19 17:38:02 --> Database Driver Class Initialized
INFO - 2017-06-19 17:38:02 --> Model Class Initialized
INFO - 2017-06-19 17:38:02 --> Helper loaded: form_helper
INFO - 2017-06-19 17:38:02 --> Helper loaded: url_helper
INFO - 2017-06-19 17:38:02 --> Upload Class Initialized
INFO - 2017-06-19 17:38:02 --> Final output sent to browser
DEBUG - 2017-06-19 17:38:02 --> Total execution time: 0.1110
ERROR - 2017-06-19 17:38:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:38:03 --> Config Class Initialized
INFO - 2017-06-19 17:38:03 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:38:03 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:38:03 --> Utf8 Class Initialized
INFO - 2017-06-19 17:38:03 --> URI Class Initialized
INFO - 2017-06-19 17:38:03 --> Router Class Initialized
INFO - 2017-06-19 17:38:03 --> Output Class Initialized
INFO - 2017-06-19 17:38:03 --> Security Class Initialized
DEBUG - 2017-06-19 17:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:38:03 --> Input Class Initialized
INFO - 2017-06-19 17:38:03 --> Language Class Initialized
INFO - 2017-06-19 17:38:03 --> Loader Class Initialized
INFO - 2017-06-19 17:38:03 --> Controller Class Initialized
INFO - 2017-06-19 17:38:03 --> Database Driver Class Initialized
INFO - 2017-06-19 17:38:03 --> Model Class Initialized
INFO - 2017-06-19 17:38:03 --> Helper loaded: form_helper
INFO - 2017-06-19 17:38:03 --> Helper loaded: url_helper
INFO - 2017-06-19 17:38:03 --> Upload Class Initialized
INFO - 2017-06-19 17:38:03 --> Final output sent to browser
DEBUG - 2017-06-19 17:38:03 --> Total execution time: 0.0600
ERROR - 2017-06-19 17:38:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:38:03 --> Config Class Initialized
INFO - 2017-06-19 17:38:03 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:38:03 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:38:03 --> Utf8 Class Initialized
INFO - 2017-06-19 17:38:03 --> URI Class Initialized
INFO - 2017-06-19 17:38:03 --> Router Class Initialized
INFO - 2017-06-19 17:38:03 --> Output Class Initialized
INFO - 2017-06-19 17:38:03 --> Security Class Initialized
DEBUG - 2017-06-19 17:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:38:03 --> Input Class Initialized
INFO - 2017-06-19 17:38:03 --> Language Class Initialized
INFO - 2017-06-19 17:38:03 --> Loader Class Initialized
INFO - 2017-06-19 17:38:03 --> Controller Class Initialized
INFO - 2017-06-19 17:38:03 --> Database Driver Class Initialized
INFO - 2017-06-19 17:38:03 --> Model Class Initialized
INFO - 2017-06-19 17:38:03 --> Helper loaded: form_helper
INFO - 2017-06-19 17:38:03 --> Helper loaded: url_helper
INFO - 2017-06-19 17:38:03 --> Upload Class Initialized
INFO - 2017-06-19 17:38:03 --> Final output sent to browser
DEBUG - 2017-06-19 17:38:03 --> Total execution time: 0.0740
ERROR - 2017-06-19 17:40:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:40:06 --> Config Class Initialized
INFO - 2017-06-19 17:40:06 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:40:06 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:40:06 --> Utf8 Class Initialized
INFO - 2017-06-19 17:40:06 --> URI Class Initialized
INFO - 2017-06-19 17:40:06 --> Router Class Initialized
INFO - 2017-06-19 17:40:06 --> Output Class Initialized
INFO - 2017-06-19 17:40:06 --> Security Class Initialized
DEBUG - 2017-06-19 17:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:40:06 --> Input Class Initialized
INFO - 2017-06-19 17:40:06 --> Language Class Initialized
INFO - 2017-06-19 17:40:06 --> Loader Class Initialized
INFO - 2017-06-19 17:40:06 --> Controller Class Initialized
INFO - 2017-06-19 17:40:06 --> Database Driver Class Initialized
INFO - 2017-06-19 17:40:06 --> Model Class Initialized
INFO - 2017-06-19 17:40:06 --> Helper loaded: form_helper
INFO - 2017-06-19 17:40:06 --> Helper loaded: url_helper
INFO - 2017-06-19 17:40:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:40:06 --> Model Class Initialized
INFO - 2017-06-19 17:40:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:40:06 --> Final output sent to browser
DEBUG - 2017-06-19 17:40:06 --> Total execution time: 0.0870
ERROR - 2017-06-19 17:40:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:40:10 --> Config Class Initialized
INFO - 2017-06-19 17:40:10 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:40:10 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:40:10 --> Utf8 Class Initialized
INFO - 2017-06-19 17:40:10 --> URI Class Initialized
INFO - 2017-06-19 17:40:10 --> Router Class Initialized
INFO - 2017-06-19 17:40:10 --> Output Class Initialized
INFO - 2017-06-19 17:40:10 --> Security Class Initialized
DEBUG - 2017-06-19 17:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:40:10 --> Input Class Initialized
INFO - 2017-06-19 17:40:10 --> Language Class Initialized
INFO - 2017-06-19 17:40:10 --> Loader Class Initialized
INFO - 2017-06-19 17:40:10 --> Controller Class Initialized
INFO - 2017-06-19 17:40:10 --> Database Driver Class Initialized
INFO - 2017-06-19 17:40:10 --> Model Class Initialized
INFO - 2017-06-19 17:40:10 --> Helper loaded: form_helper
ERROR - 2017-06-19 17:40:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:40:10 --> Helper loaded: url_helper
INFO - 2017-06-19 17:40:10 --> Config Class Initialized
INFO - 2017-06-19 17:40:10 --> Upload Class Initialized
INFO - 2017-06-19 17:40:10 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:40:10 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:40:10 --> Utf8 Class Initialized
INFO - 2017-06-19 17:40:10 --> URI Class Initialized
INFO - 2017-06-19 17:40:10 --> Router Class Initialized
INFO - 2017-06-19 17:40:10 --> Output Class Initialized
INFO - 2017-06-19 17:40:10 --> Final output sent to browser
INFO - 2017-06-19 17:40:10 --> Security Class Initialized
DEBUG - 2017-06-19 17:40:10 --> Total execution time: 0.1815
DEBUG - 2017-06-19 17:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:40:10 --> Input Class Initialized
INFO - 2017-06-19 17:40:10 --> Language Class Initialized
ERROR - 2017-06-19 17:40:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:40:10 --> Config Class Initialized
INFO - 2017-06-19 17:40:10 --> Loader Class Initialized
INFO - 2017-06-19 17:40:10 --> Hooks Class Initialized
INFO - 2017-06-19 17:40:10 --> Controller Class Initialized
DEBUG - 2017-06-19 17:40:10 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:40:10 --> Database Driver Class Initialized
INFO - 2017-06-19 17:40:10 --> Utf8 Class Initialized
INFO - 2017-06-19 17:40:10 --> URI Class Initialized
INFO - 2017-06-19 17:40:10 --> Router Class Initialized
INFO - 2017-06-19 17:40:10 --> Output Class Initialized
INFO - 2017-06-19 17:40:10 --> Security Class Initialized
DEBUG - 2017-06-19 17:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:40:10 --> Model Class Initialized
INFO - 2017-06-19 17:40:10 --> Input Class Initialized
INFO - 2017-06-19 17:40:10 --> Helper loaded: form_helper
INFO - 2017-06-19 17:40:10 --> Language Class Initialized
INFO - 2017-06-19 17:40:10 --> Helper loaded: url_helper
INFO - 2017-06-19 17:40:10 --> Upload Class Initialized
INFO - 2017-06-19 17:40:10 --> Final output sent to browser
DEBUG - 2017-06-19 17:40:10 --> Total execution time: 0.1265
INFO - 2017-06-19 17:40:10 --> Loader Class Initialized
INFO - 2017-06-19 17:40:10 --> Controller Class Initialized
INFO - 2017-06-19 17:40:10 --> Database Driver Class Initialized
INFO - 2017-06-19 17:40:10 --> Model Class Initialized
INFO - 2017-06-19 17:40:10 --> Helper loaded: form_helper
INFO - 2017-06-19 17:40:10 --> Helper loaded: url_helper
INFO - 2017-06-19 17:40:10 --> Upload Class Initialized
INFO - 2017-06-19 17:40:10 --> Final output sent to browser
DEBUG - 2017-06-19 17:40:10 --> Total execution time: 0.1490
ERROR - 2017-06-19 17:40:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:40:10 --> Config Class Initialized
INFO - 2017-06-19 17:40:10 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:40:10 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:40:10 --> Utf8 Class Initialized
INFO - 2017-06-19 17:40:10 --> URI Class Initialized
INFO - 2017-06-19 17:40:11 --> Router Class Initialized
INFO - 2017-06-19 17:40:11 --> Output Class Initialized
INFO - 2017-06-19 17:40:11 --> Security Class Initialized
DEBUG - 2017-06-19 17:40:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-06-19 17:40:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:40:11 --> Input Class Initialized
INFO - 2017-06-19 17:40:11 --> Config Class Initialized
INFO - 2017-06-19 17:40:11 --> Language Class Initialized
INFO - 2017-06-19 17:40:11 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:40:11 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:40:11 --> Utf8 Class Initialized
INFO - 2017-06-19 17:40:11 --> Loader Class Initialized
INFO - 2017-06-19 17:40:11 --> URI Class Initialized
INFO - 2017-06-19 17:40:11 --> Controller Class Initialized
INFO - 2017-06-19 17:40:11 --> Router Class Initialized
INFO - 2017-06-19 17:40:11 --> Output Class Initialized
INFO - 2017-06-19 17:40:11 --> Database Driver Class Initialized
INFO - 2017-06-19 17:40:11 --> Security Class Initialized
DEBUG - 2017-06-19 17:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:40:11 --> Input Class Initialized
INFO - 2017-06-19 17:40:11 --> Language Class Initialized
INFO - 2017-06-19 17:40:11 --> Model Class Initialized
INFO - 2017-06-19 17:40:11 --> Helper loaded: form_helper
INFO - 2017-06-19 17:40:11 --> Helper loaded: url_helper
INFO - 2017-06-19 17:40:11 --> Upload Class Initialized
INFO - 2017-06-19 17:40:11 --> Final output sent to browser
DEBUG - 2017-06-19 17:40:11 --> Total execution time: 0.1290
INFO - 2017-06-19 17:40:11 --> Loader Class Initialized
INFO - 2017-06-19 17:40:11 --> Controller Class Initialized
INFO - 2017-06-19 17:40:11 --> Database Driver Class Initialized
INFO - 2017-06-19 17:40:11 --> Model Class Initialized
INFO - 2017-06-19 17:40:11 --> Helper loaded: form_helper
INFO - 2017-06-19 17:40:11 --> Helper loaded: url_helper
INFO - 2017-06-19 17:40:11 --> Upload Class Initialized
INFO - 2017-06-19 17:40:11 --> Final output sent to browser
DEBUG - 2017-06-19 17:40:11 --> Total execution time: 0.1425
ERROR - 2017-06-19 17:40:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:40:11 --> Config Class Initialized
INFO - 2017-06-19 17:40:11 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:40:11 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:40:11 --> Utf8 Class Initialized
INFO - 2017-06-19 17:40:11 --> URI Class Initialized
INFO - 2017-06-19 17:40:11 --> Router Class Initialized
INFO - 2017-06-19 17:40:11 --> Output Class Initialized
INFO - 2017-06-19 17:40:11 --> Security Class Initialized
DEBUG - 2017-06-19 17:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:40:11 --> Input Class Initialized
INFO - 2017-06-19 17:40:11 --> Language Class Initialized
INFO - 2017-06-19 17:40:11 --> Loader Class Initialized
INFO - 2017-06-19 17:40:11 --> Controller Class Initialized
INFO - 2017-06-19 17:40:11 --> Database Driver Class Initialized
INFO - 2017-06-19 17:40:11 --> Model Class Initialized
INFO - 2017-06-19 17:40:11 --> Helper loaded: form_helper
INFO - 2017-06-19 17:40:11 --> Helper loaded: url_helper
INFO - 2017-06-19 17:40:11 --> Upload Class Initialized
ERROR - 2017-06-19 17:40:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:40:11 --> Config Class Initialized
INFO - 2017-06-19 17:40:11 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:40:11 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:40:11 --> Utf8 Class Initialized
INFO - 2017-06-19 17:40:11 --> URI Class Initialized
INFO - 2017-06-19 17:40:11 --> Router Class Initialized
INFO - 2017-06-19 17:40:11 --> Output Class Initialized
INFO - 2017-06-19 17:40:11 --> Security Class Initialized
DEBUG - 2017-06-19 17:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:40:11 --> Input Class Initialized
INFO - 2017-06-19 17:40:11 --> Language Class Initialized
INFO - 2017-06-19 17:40:11 --> Final output sent to browser
DEBUG - 2017-06-19 17:40:11 --> Total execution time: 0.5590
INFO - 2017-06-19 17:40:11 --> Loader Class Initialized
INFO - 2017-06-19 17:40:11 --> Controller Class Initialized
ERROR - 2017-06-19 17:40:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:40:12 --> Database Driver Class Initialized
INFO - 2017-06-19 17:40:12 --> Config Class Initialized
INFO - 2017-06-19 17:40:12 --> Hooks Class Initialized
INFO - 2017-06-19 17:40:12 --> Model Class Initialized
DEBUG - 2017-06-19 17:40:12 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:40:12 --> Utf8 Class Initialized
INFO - 2017-06-19 17:40:12 --> Helper loaded: form_helper
INFO - 2017-06-19 17:40:12 --> URI Class Initialized
INFO - 2017-06-19 17:40:12 --> Helper loaded: url_helper
INFO - 2017-06-19 17:40:12 --> Router Class Initialized
INFO - 2017-06-19 17:40:12 --> Output Class Initialized
INFO - 2017-06-19 17:40:12 --> Upload Class Initialized
INFO - 2017-06-19 17:40:12 --> Security Class Initialized
DEBUG - 2017-06-19 17:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:40:12 --> Input Class Initialized
INFO - 2017-06-19 17:40:12 --> Language Class Initialized
INFO - 2017-06-19 17:40:12 --> Final output sent to browser
DEBUG - 2017-06-19 17:40:12 --> Total execution time: 0.4530
INFO - 2017-06-19 17:40:12 --> Loader Class Initialized
INFO - 2017-06-19 17:40:12 --> Controller Class Initialized
INFO - 2017-06-19 17:40:12 --> Database Driver Class Initialized
INFO - 2017-06-19 17:40:12 --> Model Class Initialized
INFO - 2017-06-19 17:40:12 --> Helper loaded: form_helper
INFO - 2017-06-19 17:40:12 --> Helper loaded: url_helper
INFO - 2017-06-19 17:40:12 --> Upload Class Initialized
INFO - 2017-06-19 17:40:12 --> Final output sent to browser
DEBUG - 2017-06-19 17:40:12 --> Total execution time: 0.1195
ERROR - 2017-06-19 17:40:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:40:12 --> Config Class Initialized
INFO - 2017-06-19 17:40:12 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:40:12 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:40:12 --> Utf8 Class Initialized
INFO - 2017-06-19 17:40:12 --> URI Class Initialized
INFO - 2017-06-19 17:40:12 --> Router Class Initialized
INFO - 2017-06-19 17:40:12 --> Output Class Initialized
INFO - 2017-06-19 17:40:12 --> Security Class Initialized
DEBUG - 2017-06-19 17:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:40:12 --> Input Class Initialized
INFO - 2017-06-19 17:40:12 --> Language Class Initialized
INFO - 2017-06-19 17:40:12 --> Loader Class Initialized
INFO - 2017-06-19 17:40:12 --> Controller Class Initialized
INFO - 2017-06-19 17:40:12 --> Database Driver Class Initialized
ERROR - 2017-06-19 17:40:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:40:12 --> Config Class Initialized
INFO - 2017-06-19 17:40:12 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:40:12 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:40:12 --> Utf8 Class Initialized
INFO - 2017-06-19 17:40:12 --> URI Class Initialized
INFO - 2017-06-19 17:40:12 --> Router Class Initialized
INFO - 2017-06-19 17:40:12 --> Output Class Initialized
INFO - 2017-06-19 17:40:12 --> Security Class Initialized
DEBUG - 2017-06-19 17:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:40:12 --> Input Class Initialized
INFO - 2017-06-19 17:40:12 --> Model Class Initialized
INFO - 2017-06-19 17:40:12 --> Language Class Initialized
INFO - 2017-06-19 17:40:12 --> Helper loaded: form_helper
INFO - 2017-06-19 17:40:12 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:40:12 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:40:12 --> Upload Class Initialized
INFO - 2017-06-19 17:40:12 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:40:12 --> You did not select a file to upload.
INFO - 2017-06-19 17:40:12 --> Final output sent to browser
DEBUG - 2017-06-19 17:40:12 --> Total execution time: 0.1845
INFO - 2017-06-19 17:40:12 --> Loader Class Initialized
INFO - 2017-06-19 17:40:12 --> Controller Class Initialized
INFO - 2017-06-19 17:40:12 --> Database Driver Class Initialized
INFO - 2017-06-19 17:40:12 --> Model Class Initialized
INFO - 2017-06-19 17:40:12 --> Helper loaded: form_helper
INFO - 2017-06-19 17:40:12 --> Helper loaded: url_helper
INFO - 2017-06-19 17:40:12 --> Upload Class Initialized
INFO - 2017-06-19 17:40:12 --> Final output sent to browser
DEBUG - 2017-06-19 17:40:12 --> Total execution time: 0.1905
ERROR - 2017-06-19 17:40:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:40:12 --> Config Class Initialized
INFO - 2017-06-19 17:40:12 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:40:12 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:40:12 --> Utf8 Class Initialized
INFO - 2017-06-19 17:40:12 --> URI Class Initialized
INFO - 2017-06-19 17:40:12 --> Router Class Initialized
INFO - 2017-06-19 17:40:12 --> Output Class Initialized
INFO - 2017-06-19 17:40:12 --> Security Class Initialized
DEBUG - 2017-06-19 17:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:40:12 --> Input Class Initialized
INFO - 2017-06-19 17:40:12 --> Language Class Initialized
INFO - 2017-06-19 17:40:12 --> Loader Class Initialized
INFO - 2017-06-19 17:40:12 --> Controller Class Initialized
INFO - 2017-06-19 17:40:12 --> Database Driver Class Initialized
INFO - 2017-06-19 17:40:12 --> Model Class Initialized
INFO - 2017-06-19 17:40:12 --> Helper loaded: form_helper
INFO - 2017-06-19 17:40:12 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:40:12 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:40:12 --> Upload Class Initialized
INFO - 2017-06-19 17:40:12 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:40:12 --> You did not select a file to upload.
INFO - 2017-06-19 17:40:12 --> Final output sent to browser
DEBUG - 2017-06-19 17:40:12 --> Total execution time: 0.0955
ERROR - 2017-06-19 17:40:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:40:12 --> Config Class Initialized
INFO - 2017-06-19 17:40:12 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:40:12 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:40:12 --> Utf8 Class Initialized
INFO - 2017-06-19 17:40:12 --> URI Class Initialized
INFO - 2017-06-19 17:40:12 --> Router Class Initialized
INFO - 2017-06-19 17:40:12 --> Output Class Initialized
INFO - 2017-06-19 17:40:12 --> Security Class Initialized
DEBUG - 2017-06-19 17:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:40:12 --> Input Class Initialized
INFO - 2017-06-19 17:40:12 --> Language Class Initialized
INFO - 2017-06-19 17:40:12 --> Loader Class Initialized
INFO - 2017-06-19 17:40:12 --> Controller Class Initialized
INFO - 2017-06-19 17:40:12 --> Database Driver Class Initialized
INFO - 2017-06-19 17:40:12 --> Model Class Initialized
INFO - 2017-06-19 17:40:12 --> Helper loaded: form_helper
INFO - 2017-06-19 17:40:12 --> Helper loaded: url_helper
INFO - 2017-06-19 17:40:12 --> Upload Class Initialized
INFO - 2017-06-19 17:40:12 --> Final output sent to browser
DEBUG - 2017-06-19 17:40:12 --> Total execution time: 0.1100
ERROR - 2017-06-19 17:40:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:40:13 --> Config Class Initialized
INFO - 2017-06-19 17:40:13 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:40:13 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:40:13 --> Utf8 Class Initialized
INFO - 2017-06-19 17:40:13 --> URI Class Initialized
INFO - 2017-06-19 17:40:13 --> Router Class Initialized
INFO - 2017-06-19 17:40:13 --> Output Class Initialized
INFO - 2017-06-19 17:40:13 --> Security Class Initialized
DEBUG - 2017-06-19 17:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:40:13 --> Input Class Initialized
INFO - 2017-06-19 17:40:13 --> Language Class Initialized
INFO - 2017-06-19 17:40:13 --> Loader Class Initialized
INFO - 2017-06-19 17:40:13 --> Controller Class Initialized
INFO - 2017-06-19 17:40:13 --> Database Driver Class Initialized
INFO - 2017-06-19 17:40:13 --> Model Class Initialized
INFO - 2017-06-19 17:40:13 --> Helper loaded: form_helper
INFO - 2017-06-19 17:40:13 --> Helper loaded: url_helper
INFO - 2017-06-19 17:40:13 --> Upload Class Initialized
INFO - 2017-06-19 17:40:13 --> Final output sent to browser
DEBUG - 2017-06-19 17:40:13 --> Total execution time: 0.0650
ERROR - 2017-06-19 17:40:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:40:13 --> Config Class Initialized
INFO - 2017-06-19 17:40:13 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:40:13 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:40:13 --> Utf8 Class Initialized
INFO - 2017-06-19 17:40:13 --> URI Class Initialized
INFO - 2017-06-19 17:40:13 --> Router Class Initialized
INFO - 2017-06-19 17:40:13 --> Output Class Initialized
INFO - 2017-06-19 17:40:13 --> Security Class Initialized
DEBUG - 2017-06-19 17:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:40:13 --> Input Class Initialized
INFO - 2017-06-19 17:40:13 --> Language Class Initialized
INFO - 2017-06-19 17:40:13 --> Loader Class Initialized
INFO - 2017-06-19 17:40:13 --> Controller Class Initialized
INFO - 2017-06-19 17:40:13 --> Database Driver Class Initialized
INFO - 2017-06-19 17:40:13 --> Model Class Initialized
INFO - 2017-06-19 17:40:13 --> Helper loaded: form_helper
INFO - 2017-06-19 17:40:13 --> Helper loaded: url_helper
INFO - 2017-06-19 17:40:13 --> Upload Class Initialized
INFO - 2017-06-19 17:40:13 --> Final output sent to browser
DEBUG - 2017-06-19 17:40:13 --> Total execution time: 0.0690
ERROR - 2017-06-19 17:40:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:40:13 --> Config Class Initialized
INFO - 2017-06-19 17:40:13 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:40:13 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:40:13 --> Utf8 Class Initialized
INFO - 2017-06-19 17:40:13 --> URI Class Initialized
INFO - 2017-06-19 17:40:13 --> Router Class Initialized
INFO - 2017-06-19 17:40:13 --> Output Class Initialized
INFO - 2017-06-19 17:40:13 --> Security Class Initialized
DEBUG - 2017-06-19 17:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:40:13 --> Input Class Initialized
INFO - 2017-06-19 17:40:13 --> Language Class Initialized
INFO - 2017-06-19 17:40:13 --> Loader Class Initialized
INFO - 2017-06-19 17:40:13 --> Controller Class Initialized
INFO - 2017-06-19 17:40:13 --> Database Driver Class Initialized
INFO - 2017-06-19 17:40:13 --> Model Class Initialized
INFO - 2017-06-19 17:40:13 --> Helper loaded: form_helper
INFO - 2017-06-19 17:40:13 --> Helper loaded: url_helper
INFO - 2017-06-19 17:40:13 --> Upload Class Initialized
INFO - 2017-06-19 17:40:13 --> Final output sent to browser
DEBUG - 2017-06-19 17:40:13 --> Total execution time: 0.0630
ERROR - 2017-06-19 17:41:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:41:59 --> Config Class Initialized
INFO - 2017-06-19 17:41:59 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:41:59 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:41:59 --> Utf8 Class Initialized
INFO - 2017-06-19 17:41:59 --> URI Class Initialized
INFO - 2017-06-19 17:41:59 --> Router Class Initialized
INFO - 2017-06-19 17:41:59 --> Output Class Initialized
INFO - 2017-06-19 17:41:59 --> Security Class Initialized
DEBUG - 2017-06-19 17:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:41:59 --> Input Class Initialized
INFO - 2017-06-19 17:41:59 --> Language Class Initialized
INFO - 2017-06-19 17:41:59 --> Loader Class Initialized
INFO - 2017-06-19 17:41:59 --> Controller Class Initialized
INFO - 2017-06-19 17:41:59 --> Database Driver Class Initialized
INFO - 2017-06-19 17:41:59 --> Model Class Initialized
INFO - 2017-06-19 17:41:59 --> Helper loaded: form_helper
INFO - 2017-06-19 17:41:59 --> Helper loaded: url_helper
INFO - 2017-06-19 17:41:59 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:41:59 --> Model Class Initialized
INFO - 2017-06-19 17:41:59 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:41:59 --> Final output sent to browser
DEBUG - 2017-06-19 17:41:59 --> Total execution time: 0.0790
ERROR - 2017-06-19 17:42:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:02 --> Config Class Initialized
INFO - 2017-06-19 17:42:02 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:02 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:02 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:02 --> URI Class Initialized
INFO - 2017-06-19 17:42:02 --> Router Class Initialized
INFO - 2017-06-19 17:42:02 --> Output Class Initialized
INFO - 2017-06-19 17:42:02 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:02 --> Input Class Initialized
INFO - 2017-06-19 17:42:02 --> Language Class Initialized
INFO - 2017-06-19 17:42:02 --> Loader Class Initialized
INFO - 2017-06-19 17:42:02 --> Controller Class Initialized
INFO - 2017-06-19 17:42:02 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:02 --> Model Class Initialized
INFO - 2017-06-19 17:42:02 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:02 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:02 --> Upload Class Initialized
INFO - 2017-06-19 17:42:03 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:03 --> Total execution time: 0.0780
ERROR - 2017-06-19 17:42:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:03 --> Config Class Initialized
INFO - 2017-06-19 17:42:03 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:03 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:03 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:03 --> URI Class Initialized
INFO - 2017-06-19 17:42:03 --> Router Class Initialized
INFO - 2017-06-19 17:42:03 --> Output Class Initialized
INFO - 2017-06-19 17:42:03 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:03 --> Input Class Initialized
INFO - 2017-06-19 17:42:03 --> Language Class Initialized
INFO - 2017-06-19 17:42:03 --> Loader Class Initialized
INFO - 2017-06-19 17:42:03 --> Controller Class Initialized
INFO - 2017-06-19 17:42:03 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:03 --> Model Class Initialized
INFO - 2017-06-19 17:42:03 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:03 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:03 --> Upload Class Initialized
INFO - 2017-06-19 17:42:03 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:03 --> Total execution time: 0.1130
ERROR - 2017-06-19 17:42:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:03 --> Config Class Initialized
INFO - 2017-06-19 17:42:03 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:03 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:03 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:03 --> URI Class Initialized
INFO - 2017-06-19 17:42:03 --> Router Class Initialized
INFO - 2017-06-19 17:42:03 --> Output Class Initialized
INFO - 2017-06-19 17:42:03 --> Security Class Initialized
ERROR - 2017-06-19 17:42:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
DEBUG - 2017-06-19 17:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:03 --> Config Class Initialized
INFO - 2017-06-19 17:42:03 --> Input Class Initialized
INFO - 2017-06-19 17:42:03 --> Hooks Class Initialized
INFO - 2017-06-19 17:42:03 --> Language Class Initialized
DEBUG - 2017-06-19 17:42:03 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:03 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:03 --> Loader Class Initialized
INFO - 2017-06-19 17:42:03 --> URI Class Initialized
INFO - 2017-06-19 17:42:03 --> Controller Class Initialized
INFO - 2017-06-19 17:42:03 --> Router Class Initialized
INFO - 2017-06-19 17:42:03 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:03 --> Output Class Initialized
INFO - 2017-06-19 17:42:03 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:03 --> Input Class Initialized
INFO - 2017-06-19 17:42:03 --> Language Class Initialized
INFO - 2017-06-19 17:42:03 --> Model Class Initialized
INFO - 2017-06-19 17:42:03 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:03 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:03 --> Upload Class Initialized
INFO - 2017-06-19 17:42:03 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:03 --> Total execution time: 0.1460
INFO - 2017-06-19 17:42:03 --> Loader Class Initialized
INFO - 2017-06-19 17:42:03 --> Controller Class Initialized
INFO - 2017-06-19 17:42:03 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:03 --> Model Class Initialized
INFO - 2017-06-19 17:42:03 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:03 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:03 --> Upload Class Initialized
ERROR - 2017-06-19 17:42:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:03 --> Config Class Initialized
INFO - 2017-06-19 17:42:03 --> Final output sent to browser
INFO - 2017-06-19 17:42:03 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:03 --> Total execution time: 0.1715
DEBUG - 2017-06-19 17:42:03 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:03 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:03 --> URI Class Initialized
INFO - 2017-06-19 17:42:03 --> Router Class Initialized
INFO - 2017-06-19 17:42:03 --> Output Class Initialized
INFO - 2017-06-19 17:42:03 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:03 --> Input Class Initialized
INFO - 2017-06-19 17:42:03 --> Language Class Initialized
INFO - 2017-06-19 17:42:03 --> Loader Class Initialized
INFO - 2017-06-19 17:42:03 --> Controller Class Initialized
INFO - 2017-06-19 17:42:03 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:03 --> Model Class Initialized
INFO - 2017-06-19 17:42:03 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:03 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:03 --> Upload Class Initialized
INFO - 2017-06-19 17:42:03 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:03 --> Total execution time: 0.1695
ERROR - 2017-06-19 17:42:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:03 --> Config Class Initialized
INFO - 2017-06-19 17:42:03 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:03 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:03 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:03 --> URI Class Initialized
INFO - 2017-06-19 17:42:03 --> Router Class Initialized
INFO - 2017-06-19 17:42:04 --> Output Class Initialized
INFO - 2017-06-19 17:42:04 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:04 --> Input Class Initialized
INFO - 2017-06-19 17:42:04 --> Language Class Initialized
INFO - 2017-06-19 17:42:04 --> Loader Class Initialized
INFO - 2017-06-19 17:42:04 --> Controller Class Initialized
INFO - 2017-06-19 17:42:04 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:04 --> Model Class Initialized
INFO - 2017-06-19 17:42:04 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:04 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:42:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:04 --> Upload Class Initialized
INFO - 2017-06-19 17:42:04 --> Config Class Initialized
INFO - 2017-06-19 17:42:04 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:04 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:04 --> Final output sent to browser
INFO - 2017-06-19 17:42:04 --> Utf8 Class Initialized
DEBUG - 2017-06-19 17:42:04 --> Total execution time: 0.1100
INFO - 2017-06-19 17:42:04 --> URI Class Initialized
INFO - 2017-06-19 17:42:04 --> Router Class Initialized
INFO - 2017-06-19 17:42:04 --> Output Class Initialized
INFO - 2017-06-19 17:42:04 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:04 --> Input Class Initialized
INFO - 2017-06-19 17:42:04 --> Language Class Initialized
INFO - 2017-06-19 17:42:04 --> Loader Class Initialized
INFO - 2017-06-19 17:42:04 --> Controller Class Initialized
INFO - 2017-06-19 17:42:04 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:04 --> Model Class Initialized
INFO - 2017-06-19 17:42:04 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:04 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:04 --> Upload Class Initialized
INFO - 2017-06-19 17:42:04 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:04 --> Total execution time: 0.1595
ERROR - 2017-06-19 17:42:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:04 --> Config Class Initialized
INFO - 2017-06-19 17:42:04 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:04 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:04 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:04 --> URI Class Initialized
INFO - 2017-06-19 17:42:04 --> Router Class Initialized
INFO - 2017-06-19 17:42:04 --> Output Class Initialized
INFO - 2017-06-19 17:42:04 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:04 --> Input Class Initialized
INFO - 2017-06-19 17:42:04 --> Language Class Initialized
INFO - 2017-06-19 17:42:04 --> Loader Class Initialized
INFO - 2017-06-19 17:42:04 --> Controller Class Initialized
INFO - 2017-06-19 17:42:04 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:04 --> Model Class Initialized
INFO - 2017-06-19 17:42:04 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:04 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:04 --> Upload Class Initialized
INFO - 2017-06-19 17:42:04 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:04 --> Total execution time: 0.0850
ERROR - 2017-06-19 17:42:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:04 --> Config Class Initialized
INFO - 2017-06-19 17:42:04 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:04 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:04 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:04 --> URI Class Initialized
INFO - 2017-06-19 17:42:04 --> Router Class Initialized
INFO - 2017-06-19 17:42:04 --> Output Class Initialized
INFO - 2017-06-19 17:42:04 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:04 --> Input Class Initialized
INFO - 2017-06-19 17:42:04 --> Language Class Initialized
INFO - 2017-06-19 17:42:04 --> Loader Class Initialized
INFO - 2017-06-19 17:42:04 --> Controller Class Initialized
INFO - 2017-06-19 17:42:04 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:04 --> Model Class Initialized
INFO - 2017-06-19 17:42:04 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:04 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:42:04 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:42:04 --> Upload Class Initialized
INFO - 2017-06-19 17:42:04 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:42:04 --> You did not select a file to upload.
INFO - 2017-06-19 17:42:04 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:04 --> Total execution time: 0.1170
ERROR - 2017-06-19 17:42:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:04 --> Config Class Initialized
INFO - 2017-06-19 17:42:04 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:04 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:04 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:04 --> URI Class Initialized
INFO - 2017-06-19 17:42:04 --> Router Class Initialized
INFO - 2017-06-19 17:42:04 --> Output Class Initialized
INFO - 2017-06-19 17:42:04 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:04 --> Input Class Initialized
INFO - 2017-06-19 17:42:04 --> Language Class Initialized
ERROR - 2017-06-19 17:42:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:04 --> Loader Class Initialized
INFO - 2017-06-19 17:42:04 --> Config Class Initialized
INFO - 2017-06-19 17:42:04 --> Hooks Class Initialized
INFO - 2017-06-19 17:42:04 --> Controller Class Initialized
DEBUG - 2017-06-19 17:42:04 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:04 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:04 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:04 --> URI Class Initialized
INFO - 2017-06-19 17:42:04 --> Model Class Initialized
INFO - 2017-06-19 17:42:04 --> Router Class Initialized
INFO - 2017-06-19 17:42:04 --> Output Class Initialized
INFO - 2017-06-19 17:42:04 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:04 --> Security Class Initialized
INFO - 2017-06-19 17:42:04 --> Helper loaded: url_helper
DEBUG - 2017-06-19 17:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:04 --> Input Class Initialized
INFO - 2017-06-19 17:42:04 --> Upload Class Initialized
INFO - 2017-06-19 17:42:04 --> Language Class Initialized
ERROR - 2017-06-19 17:42:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:05 --> Config Class Initialized
INFO - 2017-06-19 17:42:05 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:05 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:05 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:05 --> URI Class Initialized
INFO - 2017-06-19 17:42:05 --> Router Class Initialized
INFO - 2017-06-19 17:42:05 --> Output Class Initialized
INFO - 2017-06-19 17:42:05 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:05 --> Input Class Initialized
INFO - 2017-06-19 17:42:05 --> Language Class Initialized
ERROR - 2017-06-19 17:42:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:05 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:05 --> Total execution time: 1.0381
INFO - 2017-06-19 17:42:05 --> Config Class Initialized
INFO - 2017-06-19 17:42:05 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:05 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:05 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:05 --> Loader Class Initialized
INFO - 2017-06-19 17:42:05 --> URI Class Initialized
INFO - 2017-06-19 17:42:05 --> Controller Class Initialized
INFO - 2017-06-19 17:42:05 --> Router Class Initialized
INFO - 2017-06-19 17:42:05 --> Output Class Initialized
INFO - 2017-06-19 17:42:05 --> Security Class Initialized
INFO - 2017-06-19 17:42:05 --> Database Driver Class Initialized
DEBUG - 2017-06-19 17:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:05 --> Input Class Initialized
INFO - 2017-06-19 17:42:05 --> Model Class Initialized
INFO - 2017-06-19 17:42:05 --> Language Class Initialized
INFO - 2017-06-19 17:42:05 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:05 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:05 --> Upload Class Initialized
INFO - 2017-06-19 17:42:05 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:05 --> Total execution time: 1.0881
INFO - 2017-06-19 17:42:05 --> Loader Class Initialized
INFO - 2017-06-19 17:42:05 --> Controller Class Initialized
INFO - 2017-06-19 17:42:05 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:06 --> Model Class Initialized
INFO - 2017-06-19 17:42:06 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:06 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:42:06 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:42:06 --> Upload Class Initialized
INFO - 2017-06-19 17:42:06 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:42:06 --> You did not select a file to upload.
INFO - 2017-06-19 17:42:06 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:06 --> Total execution time: 0.7011
INFO - 2017-06-19 17:42:06 --> Loader Class Initialized
INFO - 2017-06-19 17:42:06 --> Controller Class Initialized
INFO - 2017-06-19 17:42:06 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:06 --> Model Class Initialized
INFO - 2017-06-19 17:42:06 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:06 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:06 --> Upload Class Initialized
INFO - 2017-06-19 17:42:06 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:06 --> Total execution time: 0.2960
ERROR - 2017-06-19 17:42:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:06 --> Config Class Initialized
INFO - 2017-06-19 17:42:06 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:06 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:06 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:06 --> URI Class Initialized
INFO - 2017-06-19 17:42:06 --> Router Class Initialized
INFO - 2017-06-19 17:42:06 --> Output Class Initialized
INFO - 2017-06-19 17:42:06 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:06 --> Input Class Initialized
INFO - 2017-06-19 17:42:06 --> Language Class Initialized
INFO - 2017-06-19 17:42:06 --> Loader Class Initialized
INFO - 2017-06-19 17:42:06 --> Controller Class Initialized
INFO - 2017-06-19 17:42:06 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:06 --> Model Class Initialized
INFO - 2017-06-19 17:42:06 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:06 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:06 --> Upload Class Initialized
INFO - 2017-06-19 17:42:06 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:06 --> Total execution time: 0.0680
ERROR - 2017-06-19 17:42:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:06 --> Config Class Initialized
INFO - 2017-06-19 17:42:06 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:06 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:06 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:06 --> URI Class Initialized
INFO - 2017-06-19 17:42:06 --> Router Class Initialized
INFO - 2017-06-19 17:42:06 --> Output Class Initialized
INFO - 2017-06-19 17:42:06 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:06 --> Input Class Initialized
INFO - 2017-06-19 17:42:06 --> Language Class Initialized
INFO - 2017-06-19 17:42:06 --> Loader Class Initialized
INFO - 2017-06-19 17:42:06 --> Controller Class Initialized
INFO - 2017-06-19 17:42:06 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:06 --> Model Class Initialized
INFO - 2017-06-19 17:42:06 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:06 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:06 --> Upload Class Initialized
INFO - 2017-06-19 17:42:06 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:06 --> Total execution time: 0.1535
ERROR - 2017-06-19 17:42:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:36 --> Config Class Initialized
INFO - 2017-06-19 17:42:36 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:36 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:36 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:36 --> URI Class Initialized
INFO - 2017-06-19 17:42:36 --> Router Class Initialized
INFO - 2017-06-19 17:42:36 --> Output Class Initialized
INFO - 2017-06-19 17:42:36 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:36 --> Input Class Initialized
INFO - 2017-06-19 17:42:36 --> Language Class Initialized
INFO - 2017-06-19 17:42:36 --> Loader Class Initialized
INFO - 2017-06-19 17:42:36 --> Controller Class Initialized
INFO - 2017-06-19 17:42:36 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:36 --> Model Class Initialized
INFO - 2017-06-19 17:42:36 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:36 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:42:36 --> Model Class Initialized
INFO - 2017-06-19 17:42:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:42:36 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:36 --> Total execution time: 0.1190
ERROR - 2017-06-19 17:42:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:43 --> Config Class Initialized
INFO - 2017-06-19 17:42:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:43 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:43 --> URI Class Initialized
INFO - 2017-06-19 17:42:43 --> Router Class Initialized
INFO - 2017-06-19 17:42:43 --> Output Class Initialized
INFO - 2017-06-19 17:42:43 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:43 --> Input Class Initialized
INFO - 2017-06-19 17:42:43 --> Language Class Initialized
INFO - 2017-06-19 17:42:43 --> Loader Class Initialized
INFO - 2017-06-19 17:42:43 --> Controller Class Initialized
INFO - 2017-06-19 17:42:43 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:43 --> Model Class Initialized
INFO - 2017-06-19 17:42:43 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:43 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:43 --> Upload Class Initialized
INFO - 2017-06-19 17:42:43 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:43 --> Total execution time: 0.0960
ERROR - 2017-06-19 17:42:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:43 --> Config Class Initialized
INFO - 2017-06-19 17:42:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:43 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:43 --> URI Class Initialized
INFO - 2017-06-19 17:42:43 --> Router Class Initialized
INFO - 2017-06-19 17:42:43 --> Output Class Initialized
INFO - 2017-06-19 17:42:43 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:43 --> Input Class Initialized
INFO - 2017-06-19 17:42:43 --> Language Class Initialized
INFO - 2017-06-19 17:42:43 --> Loader Class Initialized
INFO - 2017-06-19 17:42:43 --> Controller Class Initialized
INFO - 2017-06-19 17:42:43 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:43 --> Model Class Initialized
INFO - 2017-06-19 17:42:43 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:43 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:43 --> Upload Class Initialized
INFO - 2017-06-19 17:42:43 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:43 --> Total execution time: 0.0980
ERROR - 2017-06-19 17:42:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:43 --> Config Class Initialized
INFO - 2017-06-19 17:42:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:43 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:43 --> URI Class Initialized
INFO - 2017-06-19 17:42:43 --> Router Class Initialized
INFO - 2017-06-19 17:42:43 --> Output Class Initialized
INFO - 2017-06-19 17:42:43 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:43 --> Input Class Initialized
INFO - 2017-06-19 17:42:43 --> Language Class Initialized
INFO - 2017-06-19 17:42:43 --> Loader Class Initialized
INFO - 2017-06-19 17:42:43 --> Controller Class Initialized
INFO - 2017-06-19 17:42:43 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:43 --> Model Class Initialized
INFO - 2017-06-19 17:42:43 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:43 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:43 --> Upload Class Initialized
INFO - 2017-06-19 17:42:43 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:43 --> Total execution time: 0.0840
ERROR - 2017-06-19 17:42:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:43 --> Config Class Initialized
INFO - 2017-06-19 17:42:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:43 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:43 --> URI Class Initialized
INFO - 2017-06-19 17:42:43 --> Router Class Initialized
INFO - 2017-06-19 17:42:43 --> Output Class Initialized
INFO - 2017-06-19 17:42:43 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:43 --> Input Class Initialized
INFO - 2017-06-19 17:42:43 --> Language Class Initialized
INFO - 2017-06-19 17:42:43 --> Loader Class Initialized
INFO - 2017-06-19 17:42:43 --> Controller Class Initialized
INFO - 2017-06-19 17:42:43 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:44 --> Model Class Initialized
INFO - 2017-06-19 17:42:44 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:44 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:44 --> Upload Class Initialized
INFO - 2017-06-19 17:42:44 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:44 --> Total execution time: 0.0710
ERROR - 2017-06-19 17:42:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:44 --> Config Class Initialized
INFO - 2017-06-19 17:42:44 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:44 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:44 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:44 --> URI Class Initialized
INFO - 2017-06-19 17:42:44 --> Router Class Initialized
INFO - 2017-06-19 17:42:44 --> Output Class Initialized
INFO - 2017-06-19 17:42:44 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:44 --> Input Class Initialized
INFO - 2017-06-19 17:42:44 --> Language Class Initialized
INFO - 2017-06-19 17:42:44 --> Loader Class Initialized
INFO - 2017-06-19 17:42:44 --> Controller Class Initialized
INFO - 2017-06-19 17:42:44 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:44 --> Model Class Initialized
INFO - 2017-06-19 17:42:44 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:44 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:44 --> Upload Class Initialized
INFO - 2017-06-19 17:42:44 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:44 --> Total execution time: 0.0790
ERROR - 2017-06-19 17:42:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:44 --> Config Class Initialized
INFO - 2017-06-19 17:42:44 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:44 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:44 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:44 --> URI Class Initialized
INFO - 2017-06-19 17:42:44 --> Router Class Initialized
INFO - 2017-06-19 17:42:44 --> Output Class Initialized
INFO - 2017-06-19 17:42:44 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:44 --> Input Class Initialized
INFO - 2017-06-19 17:42:44 --> Language Class Initialized
INFO - 2017-06-19 17:42:44 --> Loader Class Initialized
INFO - 2017-06-19 17:42:44 --> Controller Class Initialized
INFO - 2017-06-19 17:42:44 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:44 --> Model Class Initialized
INFO - 2017-06-19 17:42:44 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:44 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:44 --> Upload Class Initialized
INFO - 2017-06-19 17:42:44 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:44 --> Total execution time: 0.0790
ERROR - 2017-06-19 17:42:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:44 --> Config Class Initialized
INFO - 2017-06-19 17:42:44 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:44 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:44 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:44 --> URI Class Initialized
INFO - 2017-06-19 17:42:44 --> Router Class Initialized
INFO - 2017-06-19 17:42:44 --> Output Class Initialized
INFO - 2017-06-19 17:42:44 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:44 --> Input Class Initialized
INFO - 2017-06-19 17:42:44 --> Language Class Initialized
INFO - 2017-06-19 17:42:44 --> Loader Class Initialized
INFO - 2017-06-19 17:42:44 --> Controller Class Initialized
INFO - 2017-06-19 17:42:44 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:44 --> Model Class Initialized
INFO - 2017-06-19 17:42:44 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:44 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:44 --> Upload Class Initialized
INFO - 2017-06-19 17:42:44 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:44 --> Total execution time: 0.0720
ERROR - 2017-06-19 17:42:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:45 --> Config Class Initialized
INFO - 2017-06-19 17:42:45 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:45 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:45 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:45 --> URI Class Initialized
INFO - 2017-06-19 17:42:45 --> Router Class Initialized
INFO - 2017-06-19 17:42:45 --> Output Class Initialized
INFO - 2017-06-19 17:42:45 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:45 --> Input Class Initialized
INFO - 2017-06-19 17:42:45 --> Language Class Initialized
INFO - 2017-06-19 17:42:45 --> Loader Class Initialized
INFO - 2017-06-19 17:42:45 --> Controller Class Initialized
INFO - 2017-06-19 17:42:45 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:45 --> Model Class Initialized
INFO - 2017-06-19 17:42:45 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:45 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:45 --> Upload Class Initialized
ERROR - 2017-06-19 17:42:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:45 --> Config Class Initialized
INFO - 2017-06-19 17:42:45 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:45 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:45 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:45 --> URI Class Initialized
INFO - 2017-06-19 17:42:45 --> Router Class Initialized
INFO - 2017-06-19 17:42:45 --> Output Class Initialized
INFO - 2017-06-19 17:42:45 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:45 --> Input Class Initialized
INFO - 2017-06-19 17:42:45 --> Language Class Initialized
INFO - 2017-06-19 17:42:45 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:45 --> Total execution time: 0.2120
INFO - 2017-06-19 17:42:45 --> Loader Class Initialized
INFO - 2017-06-19 17:42:45 --> Controller Class Initialized
INFO - 2017-06-19 17:42:45 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:45 --> Model Class Initialized
INFO - 2017-06-19 17:42:45 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:45 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:45 --> Upload Class Initialized
ERROR - 2017-06-19 17:42:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:45 --> Config Class Initialized
INFO - 2017-06-19 17:42:45 --> Hooks Class Initialized
INFO - 2017-06-19 17:42:45 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:45 --> Total execution time: 0.1095
DEBUG - 2017-06-19 17:42:45 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:45 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:45 --> URI Class Initialized
INFO - 2017-06-19 17:42:45 --> Router Class Initialized
INFO - 2017-06-19 17:42:45 --> Output Class Initialized
INFO - 2017-06-19 17:42:45 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-06-19 17:42:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:45 --> Config Class Initialized
INFO - 2017-06-19 17:42:45 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:45 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:45 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:45 --> URI Class Initialized
INFO - 2017-06-19 17:42:45 --> Router Class Initialized
INFO - 2017-06-19 17:42:45 --> Output Class Initialized
INFO - 2017-06-19 17:42:45 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:45 --> Input Class Initialized
INFO - 2017-06-19 17:42:45 --> Language Class Initialized
INFO - 2017-06-19 17:42:45 --> Loader Class Initialized
INFO - 2017-06-19 17:42:45 --> Controller Class Initialized
INFO - 2017-06-19 17:42:45 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:45 --> Model Class Initialized
INFO - 2017-06-19 17:42:45 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:45 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:42:45 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:42:45 --> Upload Class Initialized
INFO - 2017-06-19 17:42:45 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:42:45 --> You did not select a file to upload.
INFO - 2017-06-19 17:42:45 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:45 --> Total execution time: 0.0670
ERROR - 2017-06-19 17:42:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:45 --> Config Class Initialized
INFO - 2017-06-19 17:42:45 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:45 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:45 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:45 --> URI Class Initialized
INFO - 2017-06-19 17:42:45 --> Router Class Initialized
INFO - 2017-06-19 17:42:45 --> Output Class Initialized
INFO - 2017-06-19 17:42:45 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:45 --> Input Class Initialized
INFO - 2017-06-19 17:42:45 --> Language Class Initialized
INFO - 2017-06-19 17:42:45 --> Loader Class Initialized
INFO - 2017-06-19 17:42:45 --> Controller Class Initialized
INFO - 2017-06-19 17:42:45 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:45 --> Model Class Initialized
INFO - 2017-06-19 17:42:45 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:45 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:45 --> Upload Class Initialized
INFO - 2017-06-19 17:42:45 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:45 --> Total execution time: 0.0770
INFO - 2017-06-19 17:42:45 --> Input Class Initialized
INFO - 2017-06-19 17:42:45 --> Language Class Initialized
INFO - 2017-06-19 17:42:47 --> Loader Class Initialized
ERROR - 2017-06-19 17:42:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:47 --> Controller Class Initialized
INFO - 2017-06-19 17:42:47 --> Config Class Initialized
INFO - 2017-06-19 17:42:47 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:47 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:47 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:47 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:47 --> URI Class Initialized
INFO - 2017-06-19 17:42:47 --> Model Class Initialized
INFO - 2017-06-19 17:42:47 --> Router Class Initialized
INFO - 2017-06-19 17:42:47 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:47 --> Output Class Initialized
INFO - 2017-06-19 17:42:47 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:42:47 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:42:47 --> Security Class Initialized
INFO - 2017-06-19 17:42:47 --> Upload Class Initialized
DEBUG - 2017-06-19 17:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:47 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-06-19 17:42:47 --> Input Class Initialized
DEBUG - 2017-06-19 17:42:47 --> You did not select a file to upload.
INFO - 2017-06-19 17:42:47 --> Language Class Initialized
INFO - 2017-06-19 17:42:47 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:47 --> Total execution time: 2.0991
INFO - 2017-06-19 17:42:47 --> Loader Class Initialized
INFO - 2017-06-19 17:42:47 --> Controller Class Initialized
INFO - 2017-06-19 17:42:47 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:47 --> Model Class Initialized
INFO - 2017-06-19 17:42:47 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:47 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:47 --> Upload Class Initialized
INFO - 2017-06-19 17:42:47 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:47 --> Total execution time: 0.0800
ERROR - 2017-06-19 17:42:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:47 --> Config Class Initialized
INFO - 2017-06-19 17:42:47 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:47 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:47 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:47 --> URI Class Initialized
INFO - 2017-06-19 17:42:47 --> Router Class Initialized
INFO - 2017-06-19 17:42:47 --> Output Class Initialized
INFO - 2017-06-19 17:42:47 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:47 --> Input Class Initialized
INFO - 2017-06-19 17:42:47 --> Language Class Initialized
INFO - 2017-06-19 17:42:47 --> Loader Class Initialized
INFO - 2017-06-19 17:42:47 --> Controller Class Initialized
INFO - 2017-06-19 17:42:47 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:47 --> Model Class Initialized
INFO - 2017-06-19 17:42:47 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:47 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:47 --> Upload Class Initialized
INFO - 2017-06-19 17:42:47 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:47 --> Total execution time: 0.0660
ERROR - 2017-06-19 17:42:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:42:47 --> Config Class Initialized
INFO - 2017-06-19 17:42:47 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:42:47 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:42:47 --> Utf8 Class Initialized
INFO - 2017-06-19 17:42:47 --> URI Class Initialized
INFO - 2017-06-19 17:42:47 --> Router Class Initialized
INFO - 2017-06-19 17:42:47 --> Output Class Initialized
INFO - 2017-06-19 17:42:47 --> Security Class Initialized
DEBUG - 2017-06-19 17:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:42:47 --> Input Class Initialized
INFO - 2017-06-19 17:42:47 --> Language Class Initialized
INFO - 2017-06-19 17:42:47 --> Loader Class Initialized
INFO - 2017-06-19 17:42:47 --> Controller Class Initialized
INFO - 2017-06-19 17:42:47 --> Database Driver Class Initialized
INFO - 2017-06-19 17:42:47 --> Model Class Initialized
INFO - 2017-06-19 17:42:47 --> Helper loaded: form_helper
INFO - 2017-06-19 17:42:47 --> Helper loaded: url_helper
INFO - 2017-06-19 17:42:47 --> Upload Class Initialized
INFO - 2017-06-19 17:42:47 --> Final output sent to browser
DEBUG - 2017-06-19 17:42:47 --> Total execution time: 0.3170
ERROR - 2017-06-19 17:44:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:44:17 --> Config Class Initialized
INFO - 2017-06-19 17:44:17 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:44:17 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:44:17 --> Utf8 Class Initialized
INFO - 2017-06-19 17:44:17 --> URI Class Initialized
INFO - 2017-06-19 17:44:17 --> Router Class Initialized
INFO - 2017-06-19 17:44:17 --> Output Class Initialized
INFO - 2017-06-19 17:44:17 --> Security Class Initialized
DEBUG - 2017-06-19 17:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:44:17 --> Input Class Initialized
INFO - 2017-06-19 17:44:17 --> Language Class Initialized
INFO - 2017-06-19 17:44:17 --> Loader Class Initialized
INFO - 2017-06-19 17:44:17 --> Controller Class Initialized
INFO - 2017-06-19 17:44:17 --> Database Driver Class Initialized
INFO - 2017-06-19 17:44:17 --> Model Class Initialized
INFO - 2017-06-19 17:44:17 --> Helper loaded: form_helper
INFO - 2017-06-19 17:44:17 --> Helper loaded: url_helper
INFO - 2017-06-19 17:44:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:44:17 --> Model Class Initialized
INFO - 2017-06-19 17:44:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:44:17 --> Final output sent to browser
DEBUG - 2017-06-19 17:44:17 --> Total execution time: 0.0640
ERROR - 2017-06-19 17:44:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:44:19 --> Config Class Initialized
INFO - 2017-06-19 17:44:19 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:44:19 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:44:19 --> Utf8 Class Initialized
INFO - 2017-06-19 17:44:19 --> URI Class Initialized
INFO - 2017-06-19 17:44:19 --> Router Class Initialized
INFO - 2017-06-19 17:44:19 --> Output Class Initialized
INFO - 2017-06-19 17:44:19 --> Security Class Initialized
DEBUG - 2017-06-19 17:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:44:19 --> Input Class Initialized
INFO - 2017-06-19 17:44:19 --> Language Class Initialized
INFO - 2017-06-19 17:44:19 --> Loader Class Initialized
INFO - 2017-06-19 17:44:19 --> Controller Class Initialized
INFO - 2017-06-19 17:44:19 --> Database Driver Class Initialized
INFO - 2017-06-19 17:44:19 --> Model Class Initialized
INFO - 2017-06-19 17:44:19 --> Helper loaded: form_helper
INFO - 2017-06-19 17:44:19 --> Helper loaded: url_helper
INFO - 2017-06-19 17:44:19 --> Upload Class Initialized
INFO - 2017-06-19 17:44:19 --> Final output sent to browser
DEBUG - 2017-06-19 17:44:19 --> Total execution time: 0.0550
ERROR - 2017-06-19 17:44:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:44:23 --> Config Class Initialized
INFO - 2017-06-19 17:44:23 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:44:23 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:44:23 --> Utf8 Class Initialized
INFO - 2017-06-19 17:44:23 --> URI Class Initialized
INFO - 2017-06-19 17:44:23 --> Router Class Initialized
INFO - 2017-06-19 17:44:23 --> Output Class Initialized
INFO - 2017-06-19 17:44:23 --> Security Class Initialized
DEBUG - 2017-06-19 17:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:44:23 --> Input Class Initialized
INFO - 2017-06-19 17:44:23 --> Language Class Initialized
INFO - 2017-06-19 17:44:23 --> Loader Class Initialized
INFO - 2017-06-19 17:44:23 --> Controller Class Initialized
INFO - 2017-06-19 17:44:23 --> Database Driver Class Initialized
INFO - 2017-06-19 17:44:23 --> Model Class Initialized
INFO - 2017-06-19 17:44:23 --> Helper loaded: form_helper
INFO - 2017-06-19 17:44:23 --> Helper loaded: url_helper
INFO - 2017-06-19 17:44:23 --> Upload Class Initialized
INFO - 2017-06-19 17:44:23 --> Final output sent to browser
DEBUG - 2017-06-19 17:44:23 --> Total execution time: 0.0620
ERROR - 2017-06-19 17:44:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:44:23 --> Config Class Initialized
INFO - 2017-06-19 17:44:23 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:44:23 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:44:23 --> Utf8 Class Initialized
INFO - 2017-06-19 17:44:23 --> URI Class Initialized
INFO - 2017-06-19 17:44:23 --> Router Class Initialized
INFO - 2017-06-19 17:44:23 --> Output Class Initialized
INFO - 2017-06-19 17:44:23 --> Security Class Initialized
DEBUG - 2017-06-19 17:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:44:23 --> Input Class Initialized
INFO - 2017-06-19 17:44:23 --> Language Class Initialized
INFO - 2017-06-19 17:44:23 --> Loader Class Initialized
INFO - 2017-06-19 17:44:23 --> Controller Class Initialized
INFO - 2017-06-19 17:44:23 --> Database Driver Class Initialized
INFO - 2017-06-19 17:44:23 --> Model Class Initialized
INFO - 2017-06-19 17:44:23 --> Helper loaded: form_helper
INFO - 2017-06-19 17:44:23 --> Helper loaded: url_helper
INFO - 2017-06-19 17:44:23 --> Upload Class Initialized
ERROR - 2017-06-19 17:44:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:44:23 --> Final output sent to browser
DEBUG - 2017-06-19 17:44:23 --> Total execution time: 0.0800
INFO - 2017-06-19 17:44:23 --> Config Class Initialized
INFO - 2017-06-19 17:44:23 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:44:23 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:44:23 --> Utf8 Class Initialized
INFO - 2017-06-19 17:44:23 --> URI Class Initialized
INFO - 2017-06-19 17:44:23 --> Router Class Initialized
INFO - 2017-06-19 17:44:23 --> Output Class Initialized
INFO - 2017-06-19 17:44:23 --> Security Class Initialized
DEBUG - 2017-06-19 17:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:44:23 --> Input Class Initialized
INFO - 2017-06-19 17:44:23 --> Language Class Initialized
INFO - 2017-06-19 17:44:23 --> Loader Class Initialized
INFO - 2017-06-19 17:44:23 --> Controller Class Initialized
INFO - 2017-06-19 17:44:23 --> Database Driver Class Initialized
INFO - 2017-06-19 17:44:23 --> Model Class Initialized
INFO - 2017-06-19 17:44:23 --> Helper loaded: form_helper
INFO - 2017-06-19 17:44:23 --> Helper loaded: url_helper
INFO - 2017-06-19 17:44:23 --> Upload Class Initialized
INFO - 2017-06-19 17:44:23 --> Final output sent to browser
DEBUG - 2017-06-19 17:44:23 --> Total execution time: 0.0730
ERROR - 2017-06-19 17:44:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:44:23 --> Config Class Initialized
INFO - 2017-06-19 17:44:23 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:44:23 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:44:23 --> Utf8 Class Initialized
INFO - 2017-06-19 17:44:23 --> URI Class Initialized
INFO - 2017-06-19 17:44:23 --> Router Class Initialized
INFO - 2017-06-19 17:44:23 --> Output Class Initialized
INFO - 2017-06-19 17:44:23 --> Security Class Initialized
DEBUG - 2017-06-19 17:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:44:23 --> Input Class Initialized
INFO - 2017-06-19 17:44:23 --> Language Class Initialized
INFO - 2017-06-19 17:44:23 --> Loader Class Initialized
INFO - 2017-06-19 17:44:23 --> Controller Class Initialized
INFO - 2017-06-19 17:44:23 --> Database Driver Class Initialized
INFO - 2017-06-19 17:44:23 --> Model Class Initialized
INFO - 2017-06-19 17:44:23 --> Helper loaded: form_helper
INFO - 2017-06-19 17:44:23 --> Helper loaded: url_helper
INFO - 2017-06-19 17:44:23 --> Upload Class Initialized
INFO - 2017-06-19 17:44:23 --> Final output sent to browser
DEBUG - 2017-06-19 17:44:23 --> Total execution time: 0.0810
ERROR - 2017-06-19 17:44:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:44:24 --> Config Class Initialized
INFO - 2017-06-19 17:44:24 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:44:24 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:44:24 --> Utf8 Class Initialized
INFO - 2017-06-19 17:44:24 --> URI Class Initialized
INFO - 2017-06-19 17:44:24 --> Router Class Initialized
INFO - 2017-06-19 17:44:24 --> Output Class Initialized
INFO - 2017-06-19 17:44:24 --> Security Class Initialized
DEBUG - 2017-06-19 17:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:44:24 --> Input Class Initialized
INFO - 2017-06-19 17:44:24 --> Language Class Initialized
INFO - 2017-06-19 17:44:24 --> Loader Class Initialized
INFO - 2017-06-19 17:44:24 --> Controller Class Initialized
INFO - 2017-06-19 17:44:24 --> Database Driver Class Initialized
INFO - 2017-06-19 17:44:24 --> Model Class Initialized
INFO - 2017-06-19 17:44:24 --> Helper loaded: form_helper
INFO - 2017-06-19 17:44:24 --> Helper loaded: url_helper
INFO - 2017-06-19 17:44:24 --> Upload Class Initialized
INFO - 2017-06-19 17:44:24 --> Final output sent to browser
DEBUG - 2017-06-19 17:44:24 --> Total execution time: 0.1065
ERROR - 2017-06-19 17:44:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:44:24 --> Config Class Initialized
INFO - 2017-06-19 17:44:24 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:44:24 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:44:24 --> Utf8 Class Initialized
INFO - 2017-06-19 17:44:24 --> URI Class Initialized
INFO - 2017-06-19 17:44:24 --> Router Class Initialized
INFO - 2017-06-19 17:44:24 --> Output Class Initialized
INFO - 2017-06-19 17:44:24 --> Security Class Initialized
DEBUG - 2017-06-19 17:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:44:24 --> Input Class Initialized
INFO - 2017-06-19 17:44:24 --> Language Class Initialized
INFO - 2017-06-19 17:44:24 --> Loader Class Initialized
INFO - 2017-06-19 17:44:24 --> Controller Class Initialized
INFO - 2017-06-19 17:44:24 --> Database Driver Class Initialized
INFO - 2017-06-19 17:44:24 --> Model Class Initialized
INFO - 2017-06-19 17:44:24 --> Helper loaded: form_helper
INFO - 2017-06-19 17:44:24 --> Helper loaded: url_helper
INFO - 2017-06-19 17:44:24 --> Upload Class Initialized
INFO - 2017-06-19 17:44:24 --> Final output sent to browser
DEBUG - 2017-06-19 17:44:24 --> Total execution time: 0.1070
ERROR - 2017-06-19 17:44:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:44:24 --> Config Class Initialized
INFO - 2017-06-19 17:44:24 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:44:24 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:44:24 --> Utf8 Class Initialized
INFO - 2017-06-19 17:44:24 --> URI Class Initialized
INFO - 2017-06-19 17:44:24 --> Router Class Initialized
INFO - 2017-06-19 17:44:24 --> Output Class Initialized
INFO - 2017-06-19 17:44:24 --> Security Class Initialized
DEBUG - 2017-06-19 17:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:44:24 --> Input Class Initialized
INFO - 2017-06-19 17:44:24 --> Language Class Initialized
INFO - 2017-06-19 17:44:24 --> Loader Class Initialized
INFO - 2017-06-19 17:44:24 --> Controller Class Initialized
INFO - 2017-06-19 17:44:24 --> Database Driver Class Initialized
INFO - 2017-06-19 17:44:24 --> Model Class Initialized
INFO - 2017-06-19 17:44:24 --> Helper loaded: form_helper
INFO - 2017-06-19 17:44:24 --> Helper loaded: url_helper
INFO - 2017-06-19 17:44:24 --> Upload Class Initialized
INFO - 2017-06-19 17:44:24 --> Final output sent to browser
DEBUG - 2017-06-19 17:44:24 --> Total execution time: 0.0880
ERROR - 2017-06-19 17:44:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:44:25 --> Config Class Initialized
INFO - 2017-06-19 17:44:25 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:44:25 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:44:25 --> Utf8 Class Initialized
INFO - 2017-06-19 17:44:25 --> URI Class Initialized
INFO - 2017-06-19 17:44:25 --> Router Class Initialized
INFO - 2017-06-19 17:44:25 --> Output Class Initialized
INFO - 2017-06-19 17:44:25 --> Security Class Initialized
DEBUG - 2017-06-19 17:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:44:25 --> Input Class Initialized
INFO - 2017-06-19 17:44:25 --> Language Class Initialized
INFO - 2017-06-19 17:44:25 --> Loader Class Initialized
INFO - 2017-06-19 17:44:25 --> Controller Class Initialized
INFO - 2017-06-19 17:44:25 --> Database Driver Class Initialized
INFO - 2017-06-19 17:44:25 --> Model Class Initialized
INFO - 2017-06-19 17:44:25 --> Helper loaded: form_helper
INFO - 2017-06-19 17:44:25 --> Helper loaded: url_helper
INFO - 2017-06-19 17:44:25 --> Upload Class Initialized
INFO - 2017-06-19 17:44:25 --> Final output sent to browser
DEBUG - 2017-06-19 17:44:25 --> Total execution time: 0.1280
ERROR - 2017-06-19 17:44:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:44:25 --> Config Class Initialized
INFO - 2017-06-19 17:44:25 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:44:25 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:44:25 --> Utf8 Class Initialized
INFO - 2017-06-19 17:44:25 --> URI Class Initialized
INFO - 2017-06-19 17:44:25 --> Router Class Initialized
INFO - 2017-06-19 17:44:25 --> Output Class Initialized
INFO - 2017-06-19 17:44:25 --> Security Class Initialized
DEBUG - 2017-06-19 17:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:44:25 --> Input Class Initialized
INFO - 2017-06-19 17:44:25 --> Language Class Initialized
INFO - 2017-06-19 17:44:25 --> Loader Class Initialized
INFO - 2017-06-19 17:44:25 --> Controller Class Initialized
INFO - 2017-06-19 17:44:25 --> Database Driver Class Initialized
INFO - 2017-06-19 17:44:25 --> Model Class Initialized
INFO - 2017-06-19 17:44:25 --> Helper loaded: form_helper
INFO - 2017-06-19 17:44:25 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:44:25 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:44:25 --> Upload Class Initialized
INFO - 2017-06-19 17:44:25 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-06-19 17:44:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
DEBUG - 2017-06-19 17:44:25 --> You did not select a file to upload.
INFO - 2017-06-19 17:44:25 --> Config Class Initialized
INFO - 2017-06-19 17:44:25 --> Final output sent to browser
INFO - 2017-06-19 17:44:25 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:44:25 --> Total execution time: 0.1125
DEBUG - 2017-06-19 17:44:25 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:44:25 --> Utf8 Class Initialized
INFO - 2017-06-19 17:44:25 --> URI Class Initialized
INFO - 2017-06-19 17:44:25 --> Router Class Initialized
INFO - 2017-06-19 17:44:25 --> Output Class Initialized
INFO - 2017-06-19 17:44:25 --> Security Class Initialized
DEBUG - 2017-06-19 17:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:44:25 --> Input Class Initialized
INFO - 2017-06-19 17:44:25 --> Language Class Initialized
INFO - 2017-06-19 17:44:25 --> Loader Class Initialized
INFO - 2017-06-19 17:44:25 --> Controller Class Initialized
INFO - 2017-06-19 17:44:25 --> Database Driver Class Initialized
INFO - 2017-06-19 17:44:25 --> Model Class Initialized
INFO - 2017-06-19 17:44:25 --> Helper loaded: form_helper
INFO - 2017-06-19 17:44:25 --> Helper loaded: url_helper
INFO - 2017-06-19 17:44:25 --> Upload Class Initialized
INFO - 2017-06-19 17:44:25 --> Final output sent to browser
DEBUG - 2017-06-19 17:44:25 --> Total execution time: 0.1040
ERROR - 2017-06-19 17:44:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:44:25 --> Config Class Initialized
INFO - 2017-06-19 17:44:25 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:44:25 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:44:25 --> Utf8 Class Initialized
INFO - 2017-06-19 17:44:25 --> URI Class Initialized
INFO - 2017-06-19 17:44:25 --> Router Class Initialized
INFO - 2017-06-19 17:44:25 --> Output Class Initialized
INFO - 2017-06-19 17:44:25 --> Security Class Initialized
DEBUG - 2017-06-19 17:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:44:25 --> Input Class Initialized
INFO - 2017-06-19 17:44:25 --> Language Class Initialized
INFO - 2017-06-19 17:44:26 --> Loader Class Initialized
INFO - 2017-06-19 17:44:26 --> Controller Class Initialized
INFO - 2017-06-19 17:44:26 --> Database Driver Class Initialized
INFO - 2017-06-19 17:44:26 --> Model Class Initialized
INFO - 2017-06-19 17:44:26 --> Helper loaded: form_helper
INFO - 2017-06-19 17:44:26 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:44:26 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:44:26 --> Upload Class Initialized
INFO - 2017-06-19 17:44:26 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:44:26 --> You did not select a file to upload.
INFO - 2017-06-19 17:44:26 --> Final output sent to browser
DEBUG - 2017-06-19 17:44:26 --> Total execution time: 0.0880
ERROR - 2017-06-19 17:44:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:44:26 --> Config Class Initialized
INFO - 2017-06-19 17:44:26 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:44:26 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:44:26 --> Utf8 Class Initialized
INFO - 2017-06-19 17:44:26 --> URI Class Initialized
INFO - 2017-06-19 17:44:26 --> Router Class Initialized
INFO - 2017-06-19 17:44:26 --> Output Class Initialized
INFO - 2017-06-19 17:44:26 --> Security Class Initialized
DEBUG - 2017-06-19 17:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:44:26 --> Input Class Initialized
INFO - 2017-06-19 17:44:26 --> Language Class Initialized
INFO - 2017-06-19 17:44:26 --> Loader Class Initialized
INFO - 2017-06-19 17:44:26 --> Controller Class Initialized
INFO - 2017-06-19 17:44:26 --> Database Driver Class Initialized
ERROR - 2017-06-19 17:44:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:44:26 --> Config Class Initialized
INFO - 2017-06-19 17:44:26 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:44:26 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:44:26 --> Utf8 Class Initialized
INFO - 2017-06-19 17:44:26 --> URI Class Initialized
INFO - 2017-06-19 17:44:26 --> Model Class Initialized
INFO - 2017-06-19 17:44:26 --> Router Class Initialized
INFO - 2017-06-19 17:44:26 --> Helper loaded: form_helper
INFO - 2017-06-19 17:44:26 --> Output Class Initialized
INFO - 2017-06-19 17:44:26 --> Helper loaded: url_helper
INFO - 2017-06-19 17:44:26 --> Security Class Initialized
INFO - 2017-06-19 17:44:26 --> Upload Class Initialized
DEBUG - 2017-06-19 17:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:44:26 --> Input Class Initialized
INFO - 2017-06-19 17:44:26 --> Language Class Initialized
INFO - 2017-06-19 17:44:26 --> Final output sent to browser
DEBUG - 2017-06-19 17:44:26 --> Total execution time: 0.0840
INFO - 2017-06-19 17:44:26 --> Loader Class Initialized
INFO - 2017-06-19 17:44:26 --> Controller Class Initialized
INFO - 2017-06-19 17:44:26 --> Database Driver Class Initialized
INFO - 2017-06-19 17:44:26 --> Model Class Initialized
INFO - 2017-06-19 17:44:26 --> Helper loaded: form_helper
INFO - 2017-06-19 17:44:26 --> Helper loaded: url_helper
INFO - 2017-06-19 17:44:26 --> Upload Class Initialized
INFO - 2017-06-19 17:44:26 --> Final output sent to browser
DEBUG - 2017-06-19 17:44:26 --> Total execution time: 0.0910
ERROR - 2017-06-19 17:44:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:44:26 --> Config Class Initialized
INFO - 2017-06-19 17:44:26 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:44:26 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:44:26 --> Utf8 Class Initialized
INFO - 2017-06-19 17:44:26 --> URI Class Initialized
INFO - 2017-06-19 17:44:26 --> Router Class Initialized
INFO - 2017-06-19 17:44:26 --> Output Class Initialized
INFO - 2017-06-19 17:44:26 --> Security Class Initialized
DEBUG - 2017-06-19 17:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:44:26 --> Input Class Initialized
INFO - 2017-06-19 17:44:26 --> Language Class Initialized
INFO - 2017-06-19 17:44:26 --> Loader Class Initialized
INFO - 2017-06-19 17:44:26 --> Controller Class Initialized
INFO - 2017-06-19 17:44:26 --> Database Driver Class Initialized
INFO - 2017-06-19 17:44:26 --> Model Class Initialized
INFO - 2017-06-19 17:44:26 --> Helper loaded: form_helper
INFO - 2017-06-19 17:44:26 --> Helper loaded: url_helper
INFO - 2017-06-19 17:44:26 --> Upload Class Initialized
INFO - 2017-06-19 17:44:26 --> Final output sent to browser
DEBUG - 2017-06-19 17:44:27 --> Total execution time: 0.0700
ERROR - 2017-06-19 17:44:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:44:27 --> Config Class Initialized
INFO - 2017-06-19 17:44:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:44:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:44:27 --> Utf8 Class Initialized
INFO - 2017-06-19 17:44:27 --> URI Class Initialized
INFO - 2017-06-19 17:44:27 --> Router Class Initialized
INFO - 2017-06-19 17:44:27 --> Output Class Initialized
INFO - 2017-06-19 17:44:27 --> Security Class Initialized
DEBUG - 2017-06-19 17:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:44:27 --> Input Class Initialized
INFO - 2017-06-19 17:44:27 --> Language Class Initialized
INFO - 2017-06-19 17:44:27 --> Loader Class Initialized
INFO - 2017-06-19 17:44:27 --> Controller Class Initialized
INFO - 2017-06-19 17:44:27 --> Database Driver Class Initialized
INFO - 2017-06-19 17:44:27 --> Model Class Initialized
INFO - 2017-06-19 17:44:27 --> Helper loaded: form_helper
INFO - 2017-06-19 17:44:27 --> Helper loaded: url_helper
INFO - 2017-06-19 17:44:27 --> Upload Class Initialized
INFO - 2017-06-19 17:44:27 --> Final output sent to browser
DEBUG - 2017-06-19 17:44:27 --> Total execution time: 0.0610
ERROR - 2017-06-19 17:44:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:44:39 --> Config Class Initialized
INFO - 2017-06-19 17:44:39 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:44:39 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:44:39 --> Utf8 Class Initialized
INFO - 2017-06-19 17:44:39 --> URI Class Initialized
INFO - 2017-06-19 17:44:39 --> Router Class Initialized
INFO - 2017-06-19 17:44:39 --> Output Class Initialized
INFO - 2017-06-19 17:44:39 --> Security Class Initialized
DEBUG - 2017-06-19 17:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:44:39 --> Input Class Initialized
INFO - 2017-06-19 17:44:39 --> Language Class Initialized
INFO - 2017-06-19 17:44:39 --> Loader Class Initialized
INFO - 2017-06-19 17:44:39 --> Controller Class Initialized
INFO - 2017-06-19 17:44:39 --> Database Driver Class Initialized
INFO - 2017-06-19 17:44:39 --> Model Class Initialized
INFO - 2017-06-19 17:44:39 --> Helper loaded: form_helper
INFO - 2017-06-19 17:44:39 --> Helper loaded: url_helper
INFO - 2017-06-19 17:44:39 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:44:39 --> Model Class Initialized
INFO - 2017-06-19 17:44:39 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:44:39 --> Final output sent to browser
DEBUG - 2017-06-19 17:44:39 --> Total execution time: 0.0660
ERROR - 2017-06-19 17:45:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:45:04 --> Config Class Initialized
INFO - 2017-06-19 17:45:04 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:45:04 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:45:04 --> Utf8 Class Initialized
INFO - 2017-06-19 17:45:04 --> URI Class Initialized
INFO - 2017-06-19 17:45:04 --> Router Class Initialized
INFO - 2017-06-19 17:45:04 --> Output Class Initialized
INFO - 2017-06-19 17:45:04 --> Security Class Initialized
DEBUG - 2017-06-19 17:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:45:04 --> Input Class Initialized
INFO - 2017-06-19 17:45:04 --> Language Class Initialized
INFO - 2017-06-19 17:45:04 --> Loader Class Initialized
INFO - 2017-06-19 17:45:04 --> Controller Class Initialized
INFO - 2017-06-19 17:45:04 --> Database Driver Class Initialized
INFO - 2017-06-19 17:45:04 --> Model Class Initialized
INFO - 2017-06-19 17:45:04 --> Helper loaded: form_helper
INFO - 2017-06-19 17:45:04 --> Helper loaded: url_helper
INFO - 2017-06-19 17:45:04 --> Upload Class Initialized
INFO - 2017-06-19 17:45:04 --> Final output sent to browser
DEBUG - 2017-06-19 17:45:04 --> Total execution time: 0.0975
ERROR - 2017-06-19 17:45:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:45:05 --> Config Class Initialized
INFO - 2017-06-19 17:45:05 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:45:05 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:45:05 --> Utf8 Class Initialized
INFO - 2017-06-19 17:45:05 --> URI Class Initialized
INFO - 2017-06-19 17:45:05 --> Router Class Initialized
INFO - 2017-06-19 17:45:05 --> Output Class Initialized
INFO - 2017-06-19 17:45:05 --> Security Class Initialized
DEBUG - 2017-06-19 17:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:45:05 --> Input Class Initialized
INFO - 2017-06-19 17:45:05 --> Language Class Initialized
INFO - 2017-06-19 17:45:05 --> Loader Class Initialized
INFO - 2017-06-19 17:45:05 --> Controller Class Initialized
INFO - 2017-06-19 17:45:05 --> Database Driver Class Initialized
INFO - 2017-06-19 17:45:05 --> Model Class Initialized
INFO - 2017-06-19 17:45:05 --> Helper loaded: form_helper
INFO - 2017-06-19 17:45:05 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:45:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:45:05 --> Upload Class Initialized
INFO - 2017-06-19 17:45:05 --> Config Class Initialized
INFO - 2017-06-19 17:45:05 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:45:05 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:45:05 --> Utf8 Class Initialized
INFO - 2017-06-19 17:45:05 --> Final output sent to browser
DEBUG - 2017-06-19 17:45:05 --> Total execution time: 0.0910
INFO - 2017-06-19 17:45:05 --> URI Class Initialized
INFO - 2017-06-19 17:45:05 --> Router Class Initialized
INFO - 2017-06-19 17:45:05 --> Output Class Initialized
INFO - 2017-06-19 17:45:05 --> Security Class Initialized
DEBUG - 2017-06-19 17:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:45:05 --> Input Class Initialized
INFO - 2017-06-19 17:45:05 --> Language Class Initialized
INFO - 2017-06-19 17:45:05 --> Loader Class Initialized
INFO - 2017-06-19 17:45:05 --> Controller Class Initialized
INFO - 2017-06-19 17:45:05 --> Database Driver Class Initialized
INFO - 2017-06-19 17:45:05 --> Model Class Initialized
INFO - 2017-06-19 17:45:05 --> Helper loaded: form_helper
INFO - 2017-06-19 17:45:05 --> Helper loaded: url_helper
INFO - 2017-06-19 17:45:05 --> Upload Class Initialized
INFO - 2017-06-19 17:45:05 --> Final output sent to browser
DEBUG - 2017-06-19 17:45:05 --> Total execution time: 0.0820
ERROR - 2017-06-19 17:45:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
ERROR - 2017-06-19 17:45:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:45:05 --> Config Class Initialized
INFO - 2017-06-19 17:45:05 --> Config Class Initialized
INFO - 2017-06-19 17:45:05 --> Hooks Class Initialized
INFO - 2017-06-19 17:45:05 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:45:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-19 17:45:05 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:45:05 --> Utf8 Class Initialized
INFO - 2017-06-19 17:45:05 --> Utf8 Class Initialized
INFO - 2017-06-19 17:45:05 --> URI Class Initialized
INFO - 2017-06-19 17:45:05 --> URI Class Initialized
INFO - 2017-06-19 17:45:05 --> Router Class Initialized
INFO - 2017-06-19 17:45:05 --> Router Class Initialized
INFO - 2017-06-19 17:45:05 --> Output Class Initialized
INFO - 2017-06-19 17:45:05 --> Output Class Initialized
INFO - 2017-06-19 17:45:05 --> Security Class Initialized
INFO - 2017-06-19 17:45:05 --> Security Class Initialized
DEBUG - 2017-06-19 17:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-19 17:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:45:05 --> Input Class Initialized
INFO - 2017-06-19 17:45:05 --> Input Class Initialized
INFO - 2017-06-19 17:45:05 --> Language Class Initialized
INFO - 2017-06-19 17:45:05 --> Language Class Initialized
INFO - 2017-06-19 17:45:05 --> Loader Class Initialized
INFO - 2017-06-19 17:45:05 --> Controller Class Initialized
INFO - 2017-06-19 17:45:05 --> Database Driver Class Initialized
INFO - 2017-06-19 17:45:05 --> Model Class Initialized
INFO - 2017-06-19 17:45:05 --> Helper loaded: form_helper
INFO - 2017-06-19 17:45:05 --> Helper loaded: url_helper
INFO - 2017-06-19 17:45:05 --> Upload Class Initialized
INFO - 2017-06-19 17:45:05 --> Final output sent to browser
DEBUG - 2017-06-19 17:45:05 --> Total execution time: 0.0865
INFO - 2017-06-19 17:45:05 --> Loader Class Initialized
INFO - 2017-06-19 17:45:05 --> Controller Class Initialized
INFO - 2017-06-19 17:45:05 --> Database Driver Class Initialized
INFO - 2017-06-19 17:45:05 --> Model Class Initialized
INFO - 2017-06-19 17:45:05 --> Helper loaded: form_helper
INFO - 2017-06-19 17:45:05 --> Helper loaded: url_helper
INFO - 2017-06-19 17:45:05 --> Upload Class Initialized
INFO - 2017-06-19 17:45:05 --> Final output sent to browser
DEBUG - 2017-06-19 17:45:05 --> Total execution time: 0.1200
ERROR - 2017-06-19 17:45:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:45:05 --> Config Class Initialized
INFO - 2017-06-19 17:45:05 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:45:05 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:45:05 --> Utf8 Class Initialized
INFO - 2017-06-19 17:45:05 --> URI Class Initialized
INFO - 2017-06-19 17:45:05 --> Router Class Initialized
INFO - 2017-06-19 17:45:05 --> Output Class Initialized
INFO - 2017-06-19 17:45:05 --> Security Class Initialized
DEBUG - 2017-06-19 17:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:45:05 --> Input Class Initialized
INFO - 2017-06-19 17:45:05 --> Language Class Initialized
INFO - 2017-06-19 17:45:05 --> Loader Class Initialized
INFO - 2017-06-19 17:45:05 --> Controller Class Initialized
INFO - 2017-06-19 17:45:05 --> Database Driver Class Initialized
INFO - 2017-06-19 17:45:05 --> Model Class Initialized
INFO - 2017-06-19 17:45:05 --> Helper loaded: form_helper
INFO - 2017-06-19 17:45:05 --> Helper loaded: url_helper
INFO - 2017-06-19 17:45:05 --> Upload Class Initialized
INFO - 2017-06-19 17:45:05 --> Final output sent to browser
DEBUG - 2017-06-19 17:45:05 --> Total execution time: 0.0640
ERROR - 2017-06-19 17:45:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:45:11 --> Config Class Initialized
INFO - 2017-06-19 17:45:11 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:45:11 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:45:11 --> Utf8 Class Initialized
INFO - 2017-06-19 17:45:11 --> URI Class Initialized
INFO - 2017-06-19 17:45:11 --> Router Class Initialized
INFO - 2017-06-19 17:45:11 --> Output Class Initialized
INFO - 2017-06-19 17:45:11 --> Security Class Initialized
DEBUG - 2017-06-19 17:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:45:11 --> Input Class Initialized
INFO - 2017-06-19 17:45:11 --> Language Class Initialized
INFO - 2017-06-19 17:45:11 --> Loader Class Initialized
INFO - 2017-06-19 17:45:11 --> Controller Class Initialized
INFO - 2017-06-19 17:45:11 --> Database Driver Class Initialized
INFO - 2017-06-19 17:45:11 --> Model Class Initialized
INFO - 2017-06-19 17:45:11 --> Helper loaded: form_helper
INFO - 2017-06-19 17:45:11 --> Helper loaded: url_helper
INFO - 2017-06-19 17:45:11 --> Upload Class Initialized
INFO - 2017-06-19 17:45:11 --> Final output sent to browser
DEBUG - 2017-06-19 17:45:11 --> Total execution time: 0.3060
ERROR - 2017-06-19 17:45:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:45:15 --> Config Class Initialized
INFO - 2017-06-19 17:45:15 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:45:15 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:45:15 --> Utf8 Class Initialized
INFO - 2017-06-19 17:45:15 --> URI Class Initialized
INFO - 2017-06-19 17:45:15 --> Router Class Initialized
INFO - 2017-06-19 17:45:15 --> Output Class Initialized
INFO - 2017-06-19 17:45:15 --> Security Class Initialized
DEBUG - 2017-06-19 17:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:45:15 --> Input Class Initialized
INFO - 2017-06-19 17:45:15 --> Language Class Initialized
INFO - 2017-06-19 17:45:15 --> Loader Class Initialized
INFO - 2017-06-19 17:45:15 --> Controller Class Initialized
INFO - 2017-06-19 17:45:15 --> Database Driver Class Initialized
INFO - 2017-06-19 17:45:15 --> Model Class Initialized
INFO - 2017-06-19 17:45:15 --> Helper loaded: form_helper
INFO - 2017-06-19 17:45:15 --> Helper loaded: url_helper
INFO - 2017-06-19 17:45:15 --> Upload Class Initialized
INFO - 2017-06-19 17:45:15 --> Final output sent to browser
DEBUG - 2017-06-19 17:45:15 --> Total execution time: 0.0710
ERROR - 2017-06-19 17:45:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:45:16 --> Config Class Initialized
INFO - 2017-06-19 17:45:16 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:45:16 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:45:16 --> Utf8 Class Initialized
INFO - 2017-06-19 17:45:16 --> URI Class Initialized
INFO - 2017-06-19 17:45:16 --> Router Class Initialized
INFO - 2017-06-19 17:45:16 --> Output Class Initialized
INFO - 2017-06-19 17:45:16 --> Security Class Initialized
DEBUG - 2017-06-19 17:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:45:16 --> Input Class Initialized
INFO - 2017-06-19 17:45:16 --> Language Class Initialized
INFO - 2017-06-19 17:45:16 --> Loader Class Initialized
INFO - 2017-06-19 17:45:16 --> Controller Class Initialized
INFO - 2017-06-19 17:45:16 --> Database Driver Class Initialized
INFO - 2017-06-19 17:45:16 --> Model Class Initialized
INFO - 2017-06-19 17:45:16 --> Helper loaded: form_helper
INFO - 2017-06-19 17:45:16 --> Helper loaded: url_helper
INFO - 2017-06-19 17:45:16 --> Upload Class Initialized
INFO - 2017-06-19 17:45:16 --> Final output sent to browser
DEBUG - 2017-06-19 17:45:16 --> Total execution time: 0.0580
ERROR - 2017-06-19 17:45:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:45:37 --> Config Class Initialized
INFO - 2017-06-19 17:45:37 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:45:37 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:45:37 --> Utf8 Class Initialized
INFO - 2017-06-19 17:45:37 --> URI Class Initialized
INFO - 2017-06-19 17:45:37 --> Router Class Initialized
INFO - 2017-06-19 17:45:37 --> Output Class Initialized
INFO - 2017-06-19 17:45:37 --> Security Class Initialized
DEBUG - 2017-06-19 17:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:45:37 --> Input Class Initialized
INFO - 2017-06-19 17:45:37 --> Language Class Initialized
INFO - 2017-06-19 17:45:37 --> Loader Class Initialized
INFO - 2017-06-19 17:45:37 --> Controller Class Initialized
INFO - 2017-06-19 17:45:37 --> Database Driver Class Initialized
INFO - 2017-06-19 17:45:37 --> Model Class Initialized
INFO - 2017-06-19 17:45:37 --> Helper loaded: form_helper
INFO - 2017-06-19 17:45:37 --> Helper loaded: url_helper
INFO - 2017-06-19 17:45:37 --> Upload Class Initialized
INFO - 2017-06-19 17:45:37 --> Final output sent to browser
DEBUG - 2017-06-19 17:45:37 --> Total execution time: 0.2500
ERROR - 2017-06-19 17:45:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:45:44 --> Config Class Initialized
INFO - 2017-06-19 17:45:44 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:45:44 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:45:44 --> Utf8 Class Initialized
INFO - 2017-06-19 17:45:44 --> URI Class Initialized
INFO - 2017-06-19 17:45:44 --> Router Class Initialized
INFO - 2017-06-19 17:45:44 --> Output Class Initialized
INFO - 2017-06-19 17:45:44 --> Security Class Initialized
DEBUG - 2017-06-19 17:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:45:44 --> Input Class Initialized
INFO - 2017-06-19 17:45:44 --> Language Class Initialized
INFO - 2017-06-19 17:45:44 --> Loader Class Initialized
INFO - 2017-06-19 17:45:44 --> Controller Class Initialized
INFO - 2017-06-19 17:45:44 --> Database Driver Class Initialized
INFO - 2017-06-19 17:45:44 --> Model Class Initialized
INFO - 2017-06-19 17:45:44 --> Helper loaded: form_helper
INFO - 2017-06-19 17:45:44 --> Helper loaded: url_helper
INFO - 2017-06-19 17:45:44 --> Upload Class Initialized
INFO - 2017-06-19 17:45:44 --> Final output sent to browser
DEBUG - 2017-06-19 17:45:44 --> Total execution time: 0.0590
ERROR - 2017-06-19 17:45:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:45:45 --> Config Class Initialized
INFO - 2017-06-19 17:45:45 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:45:45 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:45:45 --> Utf8 Class Initialized
INFO - 2017-06-19 17:45:45 --> URI Class Initialized
INFO - 2017-06-19 17:45:45 --> Router Class Initialized
INFO - 2017-06-19 17:45:45 --> Output Class Initialized
INFO - 2017-06-19 17:45:45 --> Security Class Initialized
DEBUG - 2017-06-19 17:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:45:45 --> Input Class Initialized
INFO - 2017-06-19 17:45:45 --> Language Class Initialized
INFO - 2017-06-19 17:45:45 --> Loader Class Initialized
INFO - 2017-06-19 17:45:45 --> Controller Class Initialized
INFO - 2017-06-19 17:45:45 --> Database Driver Class Initialized
INFO - 2017-06-19 17:45:45 --> Model Class Initialized
INFO - 2017-06-19 17:45:45 --> Helper loaded: form_helper
INFO - 2017-06-19 17:45:45 --> Helper loaded: url_helper
INFO - 2017-06-19 17:45:45 --> Upload Class Initialized
INFO - 2017-06-19 17:45:45 --> Final output sent to browser
DEBUG - 2017-06-19 17:45:45 --> Total execution time: 0.0670
ERROR - 2017-06-19 17:46:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:46:05 --> Config Class Initialized
INFO - 2017-06-19 17:46:06 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:46:06 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:46:06 --> Utf8 Class Initialized
INFO - 2017-06-19 17:46:06 --> URI Class Initialized
INFO - 2017-06-19 17:46:06 --> Router Class Initialized
INFO - 2017-06-19 17:46:06 --> Output Class Initialized
INFO - 2017-06-19 17:46:06 --> Security Class Initialized
DEBUG - 2017-06-19 17:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:46:06 --> Input Class Initialized
INFO - 2017-06-19 17:46:06 --> Language Class Initialized
INFO - 2017-06-19 17:46:06 --> Loader Class Initialized
INFO - 2017-06-19 17:46:06 --> Controller Class Initialized
INFO - 2017-06-19 17:46:06 --> Database Driver Class Initialized
INFO - 2017-06-19 17:46:06 --> Model Class Initialized
INFO - 2017-06-19 17:46:06 --> Helper loaded: form_helper
INFO - 2017-06-19 17:46:06 --> Helper loaded: url_helper
INFO - 2017-06-19 17:46:06 --> Upload Class Initialized
INFO - 2017-06-19 17:46:06 --> Final output sent to browser
DEBUG - 2017-06-19 17:46:06 --> Total execution time: 0.5300
ERROR - 2017-06-19 17:46:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:46:06 --> Config Class Initialized
INFO - 2017-06-19 17:46:06 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:46:06 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:46:06 --> Utf8 Class Initialized
INFO - 2017-06-19 17:46:06 --> URI Class Initialized
INFO - 2017-06-19 17:46:06 --> Router Class Initialized
INFO - 2017-06-19 17:46:06 --> Output Class Initialized
INFO - 2017-06-19 17:46:06 --> Security Class Initialized
DEBUG - 2017-06-19 17:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:46:06 --> Input Class Initialized
INFO - 2017-06-19 17:46:06 --> Language Class Initialized
INFO - 2017-06-19 17:46:06 --> Loader Class Initialized
INFO - 2017-06-19 17:46:06 --> Controller Class Initialized
INFO - 2017-06-19 17:46:06 --> Database Driver Class Initialized
INFO - 2017-06-19 17:46:06 --> Model Class Initialized
INFO - 2017-06-19 17:46:06 --> Helper loaded: form_helper
INFO - 2017-06-19 17:46:06 --> Helper loaded: url_helper
INFO - 2017-06-19 17:46:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:46:06 --> Model Class Initialized
INFO - 2017-06-19 17:46:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:46:06 --> Final output sent to browser
DEBUG - 2017-06-19 17:46:06 --> Total execution time: 0.1420
ERROR - 2017-06-19 17:46:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
ERROR - 2017-06-19 17:46:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
ERROR - 2017-06-19 17:46:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:46:06 --> Config Class Initialized
INFO - 2017-06-19 17:46:06 --> Hooks Class Initialized
INFO - 2017-06-19 17:46:06 --> Config Class Initialized
INFO - 2017-06-19 17:46:06 --> Config Class Initialized
INFO - 2017-06-19 17:46:06 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:46:06 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:46:06 --> Hooks Class Initialized
INFO - 2017-06-19 17:46:06 --> Utf8 Class Initialized
DEBUG - 2017-06-19 17:46:06 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:46:06 --> URI Class Initialized
DEBUG - 2017-06-19 17:46:06 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:46:06 --> Utf8 Class Initialized
INFO - 2017-06-19 17:46:06 --> Utf8 Class Initialized
INFO - 2017-06-19 17:46:06 --> Router Class Initialized
INFO - 2017-06-19 17:46:06 --> URI Class Initialized
INFO - 2017-06-19 17:46:06 --> URI Class Initialized
INFO - 2017-06-19 17:46:06 --> Output Class Initialized
INFO - 2017-06-19 17:46:06 --> Router Class Initialized
INFO - 2017-06-19 17:46:06 --> Router Class Initialized
INFO - 2017-06-19 17:46:06 --> Security Class Initialized
INFO - 2017-06-19 17:46:06 --> Output Class Initialized
INFO - 2017-06-19 17:46:06 --> Output Class Initialized
INFO - 2017-06-19 17:46:06 --> Security Class Initialized
DEBUG - 2017-06-19 17:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:46:06 --> Input Class Initialized
DEBUG - 2017-06-19 17:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:46:06 --> Security Class Initialized
INFO - 2017-06-19 17:46:06 --> Language Class Initialized
INFO - 2017-06-19 17:46:06 --> Input Class Initialized
DEBUG - 2017-06-19 17:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:46:06 --> Language Class Initialized
INFO - 2017-06-19 17:46:06 --> Input Class Initialized
INFO - 2017-06-19 17:46:06 --> Loader Class Initialized
INFO - 2017-06-19 17:46:06 --> Language Class Initialized
INFO - 2017-06-19 17:46:06 --> Controller Class Initialized
INFO - 2017-06-19 17:46:06 --> Database Driver Class Initialized
INFO - 2017-06-19 17:46:06 --> Model Class Initialized
INFO - 2017-06-19 17:46:06 --> Helper loaded: form_helper
INFO - 2017-06-19 17:46:06 --> Helper loaded: url_helper
INFO - 2017-06-19 17:46:06 --> Upload Class Initialized
INFO - 2017-06-19 17:46:06 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:46:06 --> The file was only partially uploaded.
INFO - 2017-06-19 17:46:06 --> Final output sent to browser
DEBUG - 2017-06-19 17:46:06 --> Total execution time: 0.0650
INFO - 2017-06-19 17:46:06 --> Loader Class Initialized
INFO - 2017-06-19 17:46:06 --> Controller Class Initialized
INFO - 2017-06-19 17:46:06 --> Database Driver Class Initialized
INFO - 2017-06-19 17:46:06 --> Model Class Initialized
INFO - 2017-06-19 17:46:06 --> Helper loaded: form_helper
INFO - 2017-06-19 17:46:06 --> Helper loaded: url_helper
INFO - 2017-06-19 17:46:06 --> Upload Class Initialized
INFO - 2017-06-19 17:46:06 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:46:06 --> The file was only partially uploaded.
INFO - 2017-06-19 17:46:06 --> Final output sent to browser
DEBUG - 2017-06-19 17:46:06 --> Total execution time: 0.0940
INFO - 2017-06-19 17:46:06 --> Loader Class Initialized
INFO - 2017-06-19 17:46:06 --> Controller Class Initialized
INFO - 2017-06-19 17:46:06 --> Database Driver Class Initialized
ERROR - 2017-06-19 17:46:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:46:07 --> Config Class Initialized
INFO - 2017-06-19 17:46:07 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:46:07 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:46:07 --> Utf8 Class Initialized
ERROR - 2017-06-19 17:46:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:46:07 --> Config Class Initialized
INFO - 2017-06-19 17:46:07 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:46:07 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:46:07 --> Utf8 Class Initialized
INFO - 2017-06-19 17:46:07 --> URI Class Initialized
INFO - 2017-06-19 17:46:07 --> Router Class Initialized
INFO - 2017-06-19 17:46:07 --> Model Class Initialized
INFO - 2017-06-19 17:46:07 --> Output Class Initialized
INFO - 2017-06-19 17:46:07 --> Security Class Initialized
INFO - 2017-06-19 17:46:07 --> Helper loaded: form_helper
DEBUG - 2017-06-19 17:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:46:07 --> Helper loaded: url_helper
INFO - 2017-06-19 17:46:07 --> Input Class Initialized
INFO - 2017-06-19 17:46:07 --> Upload Class Initialized
INFO - 2017-06-19 17:46:07 --> Language Class Initialized
INFO - 2017-06-19 17:46:07 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:46:07 --> The file was only partially uploaded.
INFO - 2017-06-19 17:46:07 --> Final output sent to browser
DEBUG - 2017-06-19 17:46:07 --> Total execution time: 0.1950
INFO - 2017-06-19 17:46:07 --> Loader Class Initialized
INFO - 2017-06-19 17:46:07 --> Controller Class Initialized
INFO - 2017-06-19 17:46:07 --> Database Driver Class Initialized
INFO - 2017-06-19 17:46:07 --> Model Class Initialized
INFO - 2017-06-19 17:46:07 --> Helper loaded: form_helper
INFO - 2017-06-19 17:46:07 --> Helper loaded: url_helper
INFO - 2017-06-19 17:46:07 --> Upload Class Initialized
INFO - 2017-06-19 17:46:07 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:46:07 --> The file was only partially uploaded.
INFO - 2017-06-19 17:46:07 --> Final output sent to browser
DEBUG - 2017-06-19 17:46:07 --> Total execution time: 0.0585
INFO - 2017-06-19 17:46:07 --> URI Class Initialized
INFO - 2017-06-19 17:46:07 --> Router Class Initialized
INFO - 2017-06-19 17:46:07 --> Output Class Initialized
INFO - 2017-06-19 17:46:07 --> Security Class Initialized
DEBUG - 2017-06-19 17:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:46:07 --> Input Class Initialized
INFO - 2017-06-19 17:46:07 --> Language Class Initialized
INFO - 2017-06-19 17:46:07 --> Loader Class Initialized
INFO - 2017-06-19 17:46:07 --> Controller Class Initialized
INFO - 2017-06-19 17:46:07 --> Database Driver Class Initialized
INFO - 2017-06-19 17:46:07 --> Model Class Initialized
INFO - 2017-06-19 17:46:07 --> Helper loaded: form_helper
INFO - 2017-06-19 17:46:07 --> Helper loaded: url_helper
INFO - 2017-06-19 17:46:07 --> Upload Class Initialized
INFO - 2017-06-19 17:46:07 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:46:07 --> The file was only partially uploaded.
INFO - 2017-06-19 17:46:07 --> Final output sent to browser
DEBUG - 2017-06-19 17:46:07 --> Total execution time: 0.2005
ERROR - 2017-06-19 17:56:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:56:55 --> Config Class Initialized
INFO - 2017-06-19 17:56:55 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:56:55 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:56:55 --> Utf8 Class Initialized
INFO - 2017-06-19 17:56:55 --> URI Class Initialized
INFO - 2017-06-19 17:56:55 --> Router Class Initialized
INFO - 2017-06-19 17:56:55 --> Output Class Initialized
INFO - 2017-06-19 17:56:55 --> Security Class Initialized
DEBUG - 2017-06-19 17:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:56:55 --> Input Class Initialized
INFO - 2017-06-19 17:56:55 --> Language Class Initialized
INFO - 2017-06-19 17:56:55 --> Loader Class Initialized
INFO - 2017-06-19 17:56:55 --> Controller Class Initialized
INFO - 2017-06-19 17:56:55 --> Database Driver Class Initialized
INFO - 2017-06-19 17:56:55 --> Model Class Initialized
INFO - 2017-06-19 17:56:55 --> Helper loaded: form_helper
INFO - 2017-06-19 17:56:55 --> Helper loaded: url_helper
INFO - 2017-06-19 17:56:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 17:56:55 --> Model Class Initialized
INFO - 2017-06-19 17:56:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 17:56:55 --> Final output sent to browser
DEBUG - 2017-06-19 17:56:55 --> Total execution time: 0.0550
ERROR - 2017-06-19 17:56:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:56:58 --> Config Class Initialized
INFO - 2017-06-19 17:56:58 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:56:58 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:56:58 --> Utf8 Class Initialized
INFO - 2017-06-19 17:56:58 --> URI Class Initialized
INFO - 2017-06-19 17:56:58 --> Router Class Initialized
INFO - 2017-06-19 17:56:58 --> Output Class Initialized
INFO - 2017-06-19 17:56:58 --> Security Class Initialized
DEBUG - 2017-06-19 17:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:56:58 --> Input Class Initialized
INFO - 2017-06-19 17:56:58 --> Language Class Initialized
INFO - 2017-06-19 17:56:58 --> Loader Class Initialized
INFO - 2017-06-19 17:56:58 --> Controller Class Initialized
INFO - 2017-06-19 17:56:58 --> Database Driver Class Initialized
INFO - 2017-06-19 17:56:58 --> Model Class Initialized
INFO - 2017-06-19 17:56:58 --> Helper loaded: form_helper
INFO - 2017-06-19 17:56:58 --> Helper loaded: url_helper
INFO - 2017-06-19 17:56:58 --> Upload Class Initialized
INFO - 2017-06-19 17:56:58 --> Final output sent to browser
DEBUG - 2017-06-19 17:56:58 --> Total execution time: 0.0520
ERROR - 2017-06-19 17:57:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:21 --> Config Class Initialized
INFO - 2017-06-19 17:57:21 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:21 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:21 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:21 --> URI Class Initialized
INFO - 2017-06-19 17:57:21 --> Router Class Initialized
INFO - 2017-06-19 17:57:21 --> Output Class Initialized
INFO - 2017-06-19 17:57:21 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:21 --> Input Class Initialized
INFO - 2017-06-19 17:57:21 --> Language Class Initialized
INFO - 2017-06-19 17:57:21 --> Loader Class Initialized
INFO - 2017-06-19 17:57:21 --> Controller Class Initialized
INFO - 2017-06-19 17:57:21 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:22 --> Model Class Initialized
INFO - 2017-06-19 17:57:22 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:22 --> Helper loaded: url_helper
INFO - 2017-06-19 17:57:22 --> Upload Class Initialized
INFO - 2017-06-19 17:57:22 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:22 --> Total execution time: 0.0520
ERROR - 2017-06-19 17:57:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:22 --> Config Class Initialized
INFO - 2017-06-19 17:57:22 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:22 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:22 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:22 --> URI Class Initialized
INFO - 2017-06-19 17:57:22 --> Router Class Initialized
INFO - 2017-06-19 17:57:22 --> Output Class Initialized
INFO - 2017-06-19 17:57:22 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:22 --> Input Class Initialized
INFO - 2017-06-19 17:57:22 --> Language Class Initialized
INFO - 2017-06-19 17:57:22 --> Loader Class Initialized
INFO - 2017-06-19 17:57:22 --> Controller Class Initialized
INFO - 2017-06-19 17:57:22 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:22 --> Model Class Initialized
INFO - 2017-06-19 17:57:22 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:22 --> Helper loaded: url_helper
INFO - 2017-06-19 17:57:22 --> Upload Class Initialized
INFO - 2017-06-19 17:57:22 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:22 --> Total execution time: 0.0480
ERROR - 2017-06-19 17:57:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:22 --> Config Class Initialized
INFO - 2017-06-19 17:57:22 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:22 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:22 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:22 --> URI Class Initialized
INFO - 2017-06-19 17:57:22 --> Router Class Initialized
INFO - 2017-06-19 17:57:22 --> Output Class Initialized
INFO - 2017-06-19 17:57:22 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:22 --> Input Class Initialized
INFO - 2017-06-19 17:57:22 --> Language Class Initialized
INFO - 2017-06-19 17:57:22 --> Loader Class Initialized
INFO - 2017-06-19 17:57:22 --> Controller Class Initialized
INFO - 2017-06-19 17:57:22 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:22 --> Model Class Initialized
INFO - 2017-06-19 17:57:22 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:22 --> Helper loaded: url_helper
INFO - 2017-06-19 17:57:22 --> Upload Class Initialized
INFO - 2017-06-19 17:57:22 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:22 --> Total execution time: 0.0470
ERROR - 2017-06-19 17:57:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:22 --> Config Class Initialized
INFO - 2017-06-19 17:57:22 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:22 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:22 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:22 --> URI Class Initialized
INFO - 2017-06-19 17:57:22 --> Router Class Initialized
INFO - 2017-06-19 17:57:22 --> Output Class Initialized
INFO - 2017-06-19 17:57:22 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:22 --> Input Class Initialized
INFO - 2017-06-19 17:57:22 --> Language Class Initialized
INFO - 2017-06-19 17:57:22 --> Loader Class Initialized
INFO - 2017-06-19 17:57:22 --> Controller Class Initialized
INFO - 2017-06-19 17:57:22 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:22 --> Model Class Initialized
INFO - 2017-06-19 17:57:22 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:22 --> Helper loaded: url_helper
INFO - 2017-06-19 17:57:22 --> Upload Class Initialized
INFO - 2017-06-19 17:57:22 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:22 --> Total execution time: 0.0460
ERROR - 2017-06-19 17:57:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:22 --> Config Class Initialized
INFO - 2017-06-19 17:57:22 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:22 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:22 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:22 --> URI Class Initialized
INFO - 2017-06-19 17:57:22 --> Router Class Initialized
INFO - 2017-06-19 17:57:22 --> Output Class Initialized
INFO - 2017-06-19 17:57:22 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:22 --> Input Class Initialized
INFO - 2017-06-19 17:57:22 --> Language Class Initialized
INFO - 2017-06-19 17:57:22 --> Loader Class Initialized
INFO - 2017-06-19 17:57:22 --> Controller Class Initialized
INFO - 2017-06-19 17:57:22 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:22 --> Model Class Initialized
INFO - 2017-06-19 17:57:22 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:22 --> Helper loaded: url_helper
INFO - 2017-06-19 17:57:22 --> Upload Class Initialized
INFO - 2017-06-19 17:57:22 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:22 --> Total execution time: 0.0470
ERROR - 2017-06-19 17:57:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:22 --> Config Class Initialized
INFO - 2017-06-19 17:57:22 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:22 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:22 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:22 --> URI Class Initialized
INFO - 2017-06-19 17:57:22 --> Router Class Initialized
INFO - 2017-06-19 17:57:22 --> Output Class Initialized
INFO - 2017-06-19 17:57:22 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:22 --> Input Class Initialized
INFO - 2017-06-19 17:57:22 --> Language Class Initialized
INFO - 2017-06-19 17:57:22 --> Loader Class Initialized
INFO - 2017-06-19 17:57:22 --> Controller Class Initialized
INFO - 2017-06-19 17:57:22 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:22 --> Model Class Initialized
INFO - 2017-06-19 17:57:22 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:22 --> Helper loaded: url_helper
INFO - 2017-06-19 17:57:22 --> Upload Class Initialized
INFO - 2017-06-19 17:57:22 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:22 --> Total execution time: 0.0560
ERROR - 2017-06-19 17:57:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:23 --> Config Class Initialized
INFO - 2017-06-19 17:57:23 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:23 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:23 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:23 --> URI Class Initialized
INFO - 2017-06-19 17:57:23 --> Router Class Initialized
INFO - 2017-06-19 17:57:23 --> Output Class Initialized
INFO - 2017-06-19 17:57:23 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:23 --> Input Class Initialized
INFO - 2017-06-19 17:57:23 --> Language Class Initialized
INFO - 2017-06-19 17:57:23 --> Loader Class Initialized
INFO - 2017-06-19 17:57:23 --> Controller Class Initialized
INFO - 2017-06-19 17:57:23 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:23 --> Model Class Initialized
INFO - 2017-06-19 17:57:23 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:23 --> Helper loaded: url_helper
INFO - 2017-06-19 17:57:23 --> Upload Class Initialized
INFO - 2017-06-19 17:57:23 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:23 --> Total execution time: 0.0470
ERROR - 2017-06-19 17:57:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:23 --> Config Class Initialized
INFO - 2017-06-19 17:57:23 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:23 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:23 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:23 --> URI Class Initialized
INFO - 2017-06-19 17:57:23 --> Router Class Initialized
INFO - 2017-06-19 17:57:23 --> Output Class Initialized
INFO - 2017-06-19 17:57:23 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:23 --> Input Class Initialized
INFO - 2017-06-19 17:57:23 --> Language Class Initialized
INFO - 2017-06-19 17:57:23 --> Loader Class Initialized
INFO - 2017-06-19 17:57:23 --> Controller Class Initialized
INFO - 2017-06-19 17:57:23 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:23 --> Model Class Initialized
INFO - 2017-06-19 17:57:23 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:23 --> Helper loaded: url_helper
INFO - 2017-06-19 17:57:23 --> Upload Class Initialized
INFO - 2017-06-19 17:57:23 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:23 --> Total execution time: 0.0470
ERROR - 2017-06-19 17:57:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:23 --> Config Class Initialized
INFO - 2017-06-19 17:57:23 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:23 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:23 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:23 --> URI Class Initialized
INFO - 2017-06-19 17:57:23 --> Router Class Initialized
INFO - 2017-06-19 17:57:23 --> Output Class Initialized
INFO - 2017-06-19 17:57:23 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:23 --> Input Class Initialized
INFO - 2017-06-19 17:57:23 --> Language Class Initialized
INFO - 2017-06-19 17:57:23 --> Loader Class Initialized
INFO - 2017-06-19 17:57:23 --> Controller Class Initialized
INFO - 2017-06-19 17:57:23 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:23 --> Model Class Initialized
INFO - 2017-06-19 17:57:23 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:23 --> Helper loaded: url_helper
INFO - 2017-06-19 17:57:23 --> Upload Class Initialized
INFO - 2017-06-19 17:57:23 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:23 --> Total execution time: 0.0630
ERROR - 2017-06-19 17:57:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:24 --> Config Class Initialized
INFO - 2017-06-19 17:57:24 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:24 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:24 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:24 --> URI Class Initialized
INFO - 2017-06-19 17:57:24 --> Router Class Initialized
INFO - 2017-06-19 17:57:24 --> Output Class Initialized
INFO - 2017-06-19 17:57:24 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:24 --> Input Class Initialized
INFO - 2017-06-19 17:57:24 --> Language Class Initialized
INFO - 2017-06-19 17:57:24 --> Loader Class Initialized
INFO - 2017-06-19 17:57:24 --> Controller Class Initialized
INFO - 2017-06-19 17:57:24 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:24 --> Model Class Initialized
INFO - 2017-06-19 17:57:24 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:24 --> Helper loaded: url_helper
INFO - 2017-06-19 17:57:24 --> Upload Class Initialized
INFO - 2017-06-19 17:57:24 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:24 --> Total execution time: 0.1010
ERROR - 2017-06-19 17:57:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:24 --> Config Class Initialized
INFO - 2017-06-19 17:57:24 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:24 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:24 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:24 --> URI Class Initialized
INFO - 2017-06-19 17:57:24 --> Router Class Initialized
INFO - 2017-06-19 17:57:24 --> Output Class Initialized
INFO - 2017-06-19 17:57:24 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:24 --> Input Class Initialized
INFO - 2017-06-19 17:57:24 --> Language Class Initialized
INFO - 2017-06-19 17:57:24 --> Loader Class Initialized
INFO - 2017-06-19 17:57:24 --> Controller Class Initialized
INFO - 2017-06-19 17:57:24 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:24 --> Model Class Initialized
INFO - 2017-06-19 17:57:24 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:24 --> Helper loaded: url_helper
INFO - 2017-06-19 17:57:24 --> Upload Class Initialized
INFO - 2017-06-19 17:57:24 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:24 --> Total execution time: 0.0460
ERROR - 2017-06-19 17:57:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:24 --> Config Class Initialized
INFO - 2017-06-19 17:57:24 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:24 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:24 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:24 --> URI Class Initialized
INFO - 2017-06-19 17:57:24 --> Router Class Initialized
INFO - 2017-06-19 17:57:24 --> Output Class Initialized
INFO - 2017-06-19 17:57:24 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:24 --> Input Class Initialized
INFO - 2017-06-19 17:57:24 --> Language Class Initialized
INFO - 2017-06-19 17:57:24 --> Loader Class Initialized
INFO - 2017-06-19 17:57:24 --> Controller Class Initialized
INFO - 2017-06-19 17:57:24 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:24 --> Model Class Initialized
INFO - 2017-06-19 17:57:24 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:24 --> Helper loaded: url_helper
INFO - 2017-06-19 17:57:24 --> Upload Class Initialized
INFO - 2017-06-19 17:57:24 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:24 --> Total execution time: 0.0450
ERROR - 2017-06-19 17:57:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:25 --> Config Class Initialized
INFO - 2017-06-19 17:57:25 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:25 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:25 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:25 --> URI Class Initialized
INFO - 2017-06-19 17:57:25 --> Router Class Initialized
INFO - 2017-06-19 17:57:25 --> Output Class Initialized
INFO - 2017-06-19 17:57:25 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:25 --> Input Class Initialized
INFO - 2017-06-19 17:57:25 --> Language Class Initialized
INFO - 2017-06-19 17:57:25 --> Loader Class Initialized
INFO - 2017-06-19 17:57:25 --> Controller Class Initialized
INFO - 2017-06-19 17:57:25 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:25 --> Model Class Initialized
INFO - 2017-06-19 17:57:25 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:25 --> Helper loaded: url_helper
INFO - 2017-06-19 17:57:25 --> Upload Class Initialized
INFO - 2017-06-19 17:57:25 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:25 --> Total execution time: 0.0650
ERROR - 2017-06-19 17:57:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:26 --> Config Class Initialized
INFO - 2017-06-19 17:57:26 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:26 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:26 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:26 --> URI Class Initialized
INFO - 2017-06-19 17:57:26 --> Router Class Initialized
INFO - 2017-06-19 17:57:26 --> Output Class Initialized
INFO - 2017-06-19 17:57:26 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:26 --> Input Class Initialized
INFO - 2017-06-19 17:57:26 --> Language Class Initialized
INFO - 2017-06-19 17:57:26 --> Loader Class Initialized
INFO - 2017-06-19 17:57:26 --> Controller Class Initialized
INFO - 2017-06-19 17:57:26 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:26 --> Model Class Initialized
INFO - 2017-06-19 17:57:26 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:26 --> Helper loaded: url_helper
INFO - 2017-06-19 17:57:26 --> Upload Class Initialized
INFO - 2017-06-19 17:57:26 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:26 --> Total execution time: 0.1130
ERROR - 2017-06-19 17:57:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:27 --> Config Class Initialized
INFO - 2017-06-19 17:57:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:27 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:27 --> URI Class Initialized
INFO - 2017-06-19 17:57:27 --> Router Class Initialized
INFO - 2017-06-19 17:57:27 --> Output Class Initialized
INFO - 2017-06-19 17:57:27 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:27 --> Input Class Initialized
INFO - 2017-06-19 17:57:27 --> Language Class Initialized
INFO - 2017-06-19 17:57:27 --> Loader Class Initialized
INFO - 2017-06-19 17:57:27 --> Controller Class Initialized
INFO - 2017-06-19 17:57:27 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:27 --> Model Class Initialized
INFO - 2017-06-19 17:57:27 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:27 --> Helper loaded: url_helper
INFO - 2017-06-19 17:57:27 --> Upload Class Initialized
INFO - 2017-06-19 17:57:27 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:27 --> Total execution time: 0.0480
ERROR - 2017-06-19 17:57:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:28 --> Config Class Initialized
INFO - 2017-06-19 17:57:28 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:28 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:28 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:28 --> URI Class Initialized
INFO - 2017-06-19 17:57:28 --> Router Class Initialized
INFO - 2017-06-19 17:57:28 --> Output Class Initialized
INFO - 2017-06-19 17:57:28 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:28 --> Input Class Initialized
INFO - 2017-06-19 17:57:28 --> Language Class Initialized
INFO - 2017-06-19 17:57:28 --> Loader Class Initialized
INFO - 2017-06-19 17:57:28 --> Controller Class Initialized
INFO - 2017-06-19 17:57:28 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:28 --> Model Class Initialized
INFO - 2017-06-19 17:57:28 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:28 --> Helper loaded: url_helper
INFO - 2017-06-19 17:57:28 --> Upload Class Initialized
INFO - 2017-06-19 17:57:28 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:28 --> Total execution time: 0.0600
ERROR - 2017-06-19 17:57:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:29 --> Config Class Initialized
INFO - 2017-06-19 17:57:29 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:29 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:29 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:29 --> URI Class Initialized
INFO - 2017-06-19 17:57:29 --> Router Class Initialized
INFO - 2017-06-19 17:57:29 --> Output Class Initialized
INFO - 2017-06-19 17:57:29 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:29 --> Input Class Initialized
INFO - 2017-06-19 17:57:29 --> Language Class Initialized
INFO - 2017-06-19 17:57:29 --> Loader Class Initialized
INFO - 2017-06-19 17:57:29 --> Controller Class Initialized
INFO - 2017-06-19 17:57:29 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:29 --> Model Class Initialized
INFO - 2017-06-19 17:57:29 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:29 --> Helper loaded: url_helper
INFO - 2017-06-19 17:57:29 --> Upload Class Initialized
INFO - 2017-06-19 17:57:29 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:29 --> Total execution time: 0.2020
ERROR - 2017-06-19 17:57:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:30 --> Config Class Initialized
INFO - 2017-06-19 17:57:30 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:30 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:30 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:30 --> URI Class Initialized
INFO - 2017-06-19 17:57:30 --> Router Class Initialized
INFO - 2017-06-19 17:57:30 --> Output Class Initialized
INFO - 2017-06-19 17:57:30 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:30 --> Input Class Initialized
INFO - 2017-06-19 17:57:30 --> Language Class Initialized
INFO - 2017-06-19 17:57:30 --> Loader Class Initialized
INFO - 2017-06-19 17:57:30 --> Controller Class Initialized
INFO - 2017-06-19 17:57:30 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:30 --> Model Class Initialized
INFO - 2017-06-19 17:57:30 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:30 --> Helper loaded: url_helper
INFO - 2017-06-19 17:57:30 --> Upload Class Initialized
INFO - 2017-06-19 17:57:30 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:30 --> Total execution time: 0.1000
ERROR - 2017-06-19 17:57:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:30 --> Config Class Initialized
INFO - 2017-06-19 17:57:30 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:30 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:30 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:30 --> URI Class Initialized
INFO - 2017-06-19 17:57:30 --> Router Class Initialized
INFO - 2017-06-19 17:57:30 --> Output Class Initialized
INFO - 2017-06-19 17:57:30 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:30 --> Input Class Initialized
INFO - 2017-06-19 17:57:30 --> Language Class Initialized
INFO - 2017-06-19 17:57:30 --> Loader Class Initialized
INFO - 2017-06-19 17:57:30 --> Controller Class Initialized
INFO - 2017-06-19 17:57:30 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:30 --> Model Class Initialized
INFO - 2017-06-19 17:57:30 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:30 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:30 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:30 --> Upload Class Initialized
INFO - 2017-06-19 17:57:30 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:30 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:30 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:30 --> Total execution time: 0.0560
ERROR - 2017-06-19 17:57:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:31 --> Config Class Initialized
INFO - 2017-06-19 17:57:31 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:31 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:31 --> URI Class Initialized
INFO - 2017-06-19 17:57:31 --> Router Class Initialized
INFO - 2017-06-19 17:57:31 --> Output Class Initialized
INFO - 2017-06-19 17:57:31 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:31 --> Input Class Initialized
INFO - 2017-06-19 17:57:31 --> Language Class Initialized
INFO - 2017-06-19 17:57:31 --> Loader Class Initialized
INFO - 2017-06-19 17:57:31 --> Controller Class Initialized
INFO - 2017-06-19 17:57:31 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:31 --> Model Class Initialized
INFO - 2017-06-19 17:57:31 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:31 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:31 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:31 --> Upload Class Initialized
INFO - 2017-06-19 17:57:31 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:31 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:31 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:31 --> Total execution time: 0.0600
ERROR - 2017-06-19 17:57:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:31 --> Config Class Initialized
INFO - 2017-06-19 17:57:31 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:31 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:31 --> URI Class Initialized
INFO - 2017-06-19 17:57:31 --> Router Class Initialized
INFO - 2017-06-19 17:57:31 --> Output Class Initialized
INFO - 2017-06-19 17:57:31 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:31 --> Input Class Initialized
INFO - 2017-06-19 17:57:31 --> Language Class Initialized
INFO - 2017-06-19 17:57:31 --> Loader Class Initialized
INFO - 2017-06-19 17:57:31 --> Controller Class Initialized
INFO - 2017-06-19 17:57:31 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:31 --> Model Class Initialized
INFO - 2017-06-19 17:57:31 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:31 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:31 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:31 --> Upload Class Initialized
INFO - 2017-06-19 17:57:31 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:31 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:31 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:31 --> Total execution time: 0.0590
ERROR - 2017-06-19 17:57:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:32 --> Config Class Initialized
INFO - 2017-06-19 17:57:32 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:32 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:32 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:32 --> URI Class Initialized
INFO - 2017-06-19 17:57:32 --> Router Class Initialized
INFO - 2017-06-19 17:57:32 --> Output Class Initialized
INFO - 2017-06-19 17:57:32 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:32 --> Input Class Initialized
INFO - 2017-06-19 17:57:32 --> Language Class Initialized
INFO - 2017-06-19 17:57:32 --> Loader Class Initialized
INFO - 2017-06-19 17:57:32 --> Controller Class Initialized
INFO - 2017-06-19 17:57:32 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:32 --> Model Class Initialized
INFO - 2017-06-19 17:57:32 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:32 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:32 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:32 --> Upload Class Initialized
INFO - 2017-06-19 17:57:32 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:32 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:32 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:32 --> Total execution time: 0.0450
ERROR - 2017-06-19 17:57:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:33 --> Config Class Initialized
INFO - 2017-06-19 17:57:33 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:33 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:33 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:33 --> URI Class Initialized
INFO - 2017-06-19 17:57:33 --> Router Class Initialized
INFO - 2017-06-19 17:57:33 --> Output Class Initialized
INFO - 2017-06-19 17:57:33 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:33 --> Input Class Initialized
INFO - 2017-06-19 17:57:33 --> Language Class Initialized
INFO - 2017-06-19 17:57:33 --> Loader Class Initialized
INFO - 2017-06-19 17:57:33 --> Controller Class Initialized
INFO - 2017-06-19 17:57:33 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:33 --> Model Class Initialized
INFO - 2017-06-19 17:57:33 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:33 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:33 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:33 --> Upload Class Initialized
INFO - 2017-06-19 17:57:33 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:33 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:33 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:33 --> Total execution time: 0.0470
ERROR - 2017-06-19 17:57:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:34 --> Config Class Initialized
INFO - 2017-06-19 17:57:34 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:34 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:34 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:34 --> URI Class Initialized
INFO - 2017-06-19 17:57:34 --> Router Class Initialized
INFO - 2017-06-19 17:57:34 --> Output Class Initialized
INFO - 2017-06-19 17:57:34 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:34 --> Input Class Initialized
INFO - 2017-06-19 17:57:34 --> Language Class Initialized
INFO - 2017-06-19 17:57:34 --> Loader Class Initialized
INFO - 2017-06-19 17:57:34 --> Controller Class Initialized
INFO - 2017-06-19 17:57:34 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:34 --> Model Class Initialized
INFO - 2017-06-19 17:57:34 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:34 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:34 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:34 --> Upload Class Initialized
INFO - 2017-06-19 17:57:34 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:34 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:34 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:34 --> Total execution time: 0.0540
ERROR - 2017-06-19 17:57:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:34 --> Config Class Initialized
INFO - 2017-06-19 17:57:34 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:34 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:34 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:34 --> URI Class Initialized
INFO - 2017-06-19 17:57:34 --> Router Class Initialized
INFO - 2017-06-19 17:57:34 --> Output Class Initialized
INFO - 2017-06-19 17:57:34 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:34 --> Input Class Initialized
INFO - 2017-06-19 17:57:34 --> Language Class Initialized
INFO - 2017-06-19 17:57:34 --> Loader Class Initialized
INFO - 2017-06-19 17:57:34 --> Controller Class Initialized
INFO - 2017-06-19 17:57:34 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:34 --> Model Class Initialized
INFO - 2017-06-19 17:57:34 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:34 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:34 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:34 --> Upload Class Initialized
INFO - 2017-06-19 17:57:34 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:34 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:34 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:34 --> Total execution time: 0.0450
ERROR - 2017-06-19 17:57:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:35 --> Config Class Initialized
INFO - 2017-06-19 17:57:35 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:35 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:35 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:35 --> URI Class Initialized
INFO - 2017-06-19 17:57:35 --> Router Class Initialized
INFO - 2017-06-19 17:57:35 --> Output Class Initialized
INFO - 2017-06-19 17:57:35 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:35 --> Input Class Initialized
INFO - 2017-06-19 17:57:35 --> Language Class Initialized
INFO - 2017-06-19 17:57:35 --> Loader Class Initialized
INFO - 2017-06-19 17:57:35 --> Controller Class Initialized
INFO - 2017-06-19 17:57:35 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:35 --> Model Class Initialized
INFO - 2017-06-19 17:57:35 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:35 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:35 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:35 --> Upload Class Initialized
INFO - 2017-06-19 17:57:35 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:35 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:35 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:35 --> Total execution time: 0.0450
ERROR - 2017-06-19 17:57:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:36 --> Config Class Initialized
INFO - 2017-06-19 17:57:36 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:36 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:36 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:36 --> URI Class Initialized
INFO - 2017-06-19 17:57:36 --> Router Class Initialized
INFO - 2017-06-19 17:57:36 --> Output Class Initialized
INFO - 2017-06-19 17:57:36 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:36 --> Input Class Initialized
INFO - 2017-06-19 17:57:36 --> Language Class Initialized
INFO - 2017-06-19 17:57:36 --> Loader Class Initialized
INFO - 2017-06-19 17:57:36 --> Controller Class Initialized
INFO - 2017-06-19 17:57:36 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:36 --> Model Class Initialized
INFO - 2017-06-19 17:57:36 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:36 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:36 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:36 --> Upload Class Initialized
INFO - 2017-06-19 17:57:36 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:36 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:36 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:36 --> Total execution time: 0.0470
ERROR - 2017-06-19 17:57:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:37 --> Config Class Initialized
INFO - 2017-06-19 17:57:37 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:37 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:37 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:37 --> URI Class Initialized
INFO - 2017-06-19 17:57:37 --> Router Class Initialized
INFO - 2017-06-19 17:57:37 --> Output Class Initialized
INFO - 2017-06-19 17:57:37 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:37 --> Input Class Initialized
INFO - 2017-06-19 17:57:37 --> Language Class Initialized
INFO - 2017-06-19 17:57:37 --> Loader Class Initialized
INFO - 2017-06-19 17:57:37 --> Controller Class Initialized
INFO - 2017-06-19 17:57:37 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:37 --> Model Class Initialized
INFO - 2017-06-19 17:57:37 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:37 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:37 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:37 --> Upload Class Initialized
INFO - 2017-06-19 17:57:37 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:37 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:37 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:37 --> Total execution time: 0.0470
ERROR - 2017-06-19 17:57:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:37 --> Config Class Initialized
INFO - 2017-06-19 17:57:37 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:37 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:37 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:37 --> URI Class Initialized
INFO - 2017-06-19 17:57:37 --> Router Class Initialized
INFO - 2017-06-19 17:57:37 --> Output Class Initialized
INFO - 2017-06-19 17:57:37 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:37 --> Input Class Initialized
INFO - 2017-06-19 17:57:37 --> Language Class Initialized
INFO - 2017-06-19 17:57:37 --> Loader Class Initialized
INFO - 2017-06-19 17:57:37 --> Controller Class Initialized
INFO - 2017-06-19 17:57:37 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:37 --> Model Class Initialized
INFO - 2017-06-19 17:57:37 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:37 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:37 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:37 --> Upload Class Initialized
INFO - 2017-06-19 17:57:37 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:37 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:37 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:37 --> Total execution time: 0.0650
ERROR - 2017-06-19 17:57:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:38 --> Config Class Initialized
INFO - 2017-06-19 17:57:38 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:38 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:38 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:38 --> URI Class Initialized
INFO - 2017-06-19 17:57:38 --> Router Class Initialized
INFO - 2017-06-19 17:57:38 --> Output Class Initialized
INFO - 2017-06-19 17:57:38 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:38 --> Input Class Initialized
INFO - 2017-06-19 17:57:38 --> Language Class Initialized
INFO - 2017-06-19 17:57:38 --> Loader Class Initialized
INFO - 2017-06-19 17:57:38 --> Controller Class Initialized
INFO - 2017-06-19 17:57:38 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:38 --> Model Class Initialized
INFO - 2017-06-19 17:57:38 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:38 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:38 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:38 --> Upload Class Initialized
INFO - 2017-06-19 17:57:38 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:38 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:38 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:38 --> Total execution time: 0.0460
ERROR - 2017-06-19 17:57:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:39 --> Config Class Initialized
INFO - 2017-06-19 17:57:39 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:39 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:39 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:39 --> URI Class Initialized
INFO - 2017-06-19 17:57:39 --> Router Class Initialized
INFO - 2017-06-19 17:57:39 --> Output Class Initialized
INFO - 2017-06-19 17:57:39 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:39 --> Input Class Initialized
INFO - 2017-06-19 17:57:39 --> Language Class Initialized
INFO - 2017-06-19 17:57:39 --> Loader Class Initialized
INFO - 2017-06-19 17:57:39 --> Controller Class Initialized
INFO - 2017-06-19 17:57:39 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:39 --> Model Class Initialized
INFO - 2017-06-19 17:57:39 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:39 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:39 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:39 --> Upload Class Initialized
INFO - 2017-06-19 17:57:39 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:39 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:39 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:39 --> Total execution time: 0.0480
ERROR - 2017-06-19 17:57:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:40 --> Config Class Initialized
INFO - 2017-06-19 17:57:40 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:40 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:40 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:40 --> URI Class Initialized
INFO - 2017-06-19 17:57:41 --> Router Class Initialized
INFO - 2017-06-19 17:57:41 --> Output Class Initialized
INFO - 2017-06-19 17:57:41 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:41 --> Input Class Initialized
INFO - 2017-06-19 17:57:41 --> Language Class Initialized
INFO - 2017-06-19 17:57:41 --> Loader Class Initialized
INFO - 2017-06-19 17:57:41 --> Controller Class Initialized
INFO - 2017-06-19 17:57:41 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:41 --> Model Class Initialized
INFO - 2017-06-19 17:57:41 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:41 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:41 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:41 --> Upload Class Initialized
INFO - 2017-06-19 17:57:41 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:41 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:41 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:41 --> Total execution time: 0.3020
ERROR - 2017-06-19 17:57:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:41 --> Config Class Initialized
INFO - 2017-06-19 17:57:41 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:41 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:41 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:41 --> URI Class Initialized
INFO - 2017-06-19 17:57:41 --> Router Class Initialized
INFO - 2017-06-19 17:57:41 --> Output Class Initialized
INFO - 2017-06-19 17:57:41 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:41 --> Input Class Initialized
INFO - 2017-06-19 17:57:41 --> Language Class Initialized
INFO - 2017-06-19 17:57:41 --> Loader Class Initialized
INFO - 2017-06-19 17:57:41 --> Controller Class Initialized
INFO - 2017-06-19 17:57:41 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:41 --> Model Class Initialized
INFO - 2017-06-19 17:57:41 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:41 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:41 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:41 --> Upload Class Initialized
INFO - 2017-06-19 17:57:41 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:41 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:41 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:41 --> Total execution time: 0.0550
ERROR - 2017-06-19 17:57:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:42 --> Config Class Initialized
INFO - 2017-06-19 17:57:42 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:42 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:42 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:42 --> URI Class Initialized
INFO - 2017-06-19 17:57:42 --> Router Class Initialized
INFO - 2017-06-19 17:57:42 --> Output Class Initialized
INFO - 2017-06-19 17:57:42 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:42 --> Input Class Initialized
INFO - 2017-06-19 17:57:42 --> Language Class Initialized
INFO - 2017-06-19 17:57:42 --> Loader Class Initialized
INFO - 2017-06-19 17:57:42 --> Controller Class Initialized
INFO - 2017-06-19 17:57:42 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:42 --> Model Class Initialized
INFO - 2017-06-19 17:57:42 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:42 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:42 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:42 --> Upload Class Initialized
INFO - 2017-06-19 17:57:42 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:42 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:42 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:42 --> Total execution time: 0.0490
ERROR - 2017-06-19 17:57:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:43 --> Config Class Initialized
INFO - 2017-06-19 17:57:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:43 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:43 --> URI Class Initialized
INFO - 2017-06-19 17:57:43 --> Router Class Initialized
INFO - 2017-06-19 17:57:43 --> Output Class Initialized
INFO - 2017-06-19 17:57:43 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:43 --> Input Class Initialized
INFO - 2017-06-19 17:57:43 --> Language Class Initialized
INFO - 2017-06-19 17:57:43 --> Loader Class Initialized
INFO - 2017-06-19 17:57:43 --> Controller Class Initialized
INFO - 2017-06-19 17:57:43 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:43 --> Model Class Initialized
INFO - 2017-06-19 17:57:43 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:43 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:43 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:43 --> Upload Class Initialized
INFO - 2017-06-19 17:57:43 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:43 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:43 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:43 --> Total execution time: 0.0480
ERROR - 2017-06-19 17:57:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:45 --> Config Class Initialized
INFO - 2017-06-19 17:57:45 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:45 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:45 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:45 --> URI Class Initialized
INFO - 2017-06-19 17:57:45 --> Router Class Initialized
INFO - 2017-06-19 17:57:45 --> Output Class Initialized
INFO - 2017-06-19 17:57:45 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:45 --> Input Class Initialized
INFO - 2017-06-19 17:57:45 --> Language Class Initialized
INFO - 2017-06-19 17:57:45 --> Loader Class Initialized
INFO - 2017-06-19 17:57:45 --> Controller Class Initialized
INFO - 2017-06-19 17:57:45 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:45 --> Model Class Initialized
INFO - 2017-06-19 17:57:45 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:45 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:45 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:45 --> Upload Class Initialized
INFO - 2017-06-19 17:57:45 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:45 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:45 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:45 --> Total execution time: 0.0640
ERROR - 2017-06-19 17:57:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:46 --> Config Class Initialized
INFO - 2017-06-19 17:57:46 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:46 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:46 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:46 --> URI Class Initialized
INFO - 2017-06-19 17:57:46 --> Router Class Initialized
INFO - 2017-06-19 17:57:46 --> Output Class Initialized
INFO - 2017-06-19 17:57:46 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:46 --> Input Class Initialized
INFO - 2017-06-19 17:57:46 --> Language Class Initialized
INFO - 2017-06-19 17:57:46 --> Loader Class Initialized
INFO - 2017-06-19 17:57:46 --> Controller Class Initialized
INFO - 2017-06-19 17:57:46 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:46 --> Model Class Initialized
INFO - 2017-06-19 17:57:46 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:46 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:46 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:46 --> Upload Class Initialized
INFO - 2017-06-19 17:57:46 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:46 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:46 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:46 --> Total execution time: 0.0470
ERROR - 2017-06-19 17:57:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:47 --> Config Class Initialized
INFO - 2017-06-19 17:57:47 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:47 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:47 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:47 --> URI Class Initialized
INFO - 2017-06-19 17:57:47 --> Router Class Initialized
INFO - 2017-06-19 17:57:47 --> Output Class Initialized
INFO - 2017-06-19 17:57:47 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:47 --> Input Class Initialized
INFO - 2017-06-19 17:57:47 --> Language Class Initialized
INFO - 2017-06-19 17:57:47 --> Loader Class Initialized
INFO - 2017-06-19 17:57:47 --> Controller Class Initialized
INFO - 2017-06-19 17:57:47 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:47 --> Model Class Initialized
INFO - 2017-06-19 17:57:47 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:47 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:47 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:47 --> Upload Class Initialized
INFO - 2017-06-19 17:57:47 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:47 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:47 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:47 --> Total execution time: 0.0450
ERROR - 2017-06-19 17:57:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:48 --> Config Class Initialized
INFO - 2017-06-19 17:57:48 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:48 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:48 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:48 --> URI Class Initialized
INFO - 2017-06-19 17:57:48 --> Router Class Initialized
INFO - 2017-06-19 17:57:48 --> Output Class Initialized
INFO - 2017-06-19 17:57:48 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:48 --> Input Class Initialized
INFO - 2017-06-19 17:57:48 --> Language Class Initialized
INFO - 2017-06-19 17:57:48 --> Loader Class Initialized
INFO - 2017-06-19 17:57:48 --> Controller Class Initialized
INFO - 2017-06-19 17:57:48 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:48 --> Model Class Initialized
INFO - 2017-06-19 17:57:48 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:48 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:48 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:48 --> Upload Class Initialized
INFO - 2017-06-19 17:57:48 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:48 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:48 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:48 --> Total execution time: 0.0740
ERROR - 2017-06-19 17:57:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:49 --> Config Class Initialized
INFO - 2017-06-19 17:57:49 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:49 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:49 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:49 --> URI Class Initialized
INFO - 2017-06-19 17:57:49 --> Router Class Initialized
INFO - 2017-06-19 17:57:49 --> Output Class Initialized
INFO - 2017-06-19 17:57:49 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:49 --> Input Class Initialized
INFO - 2017-06-19 17:57:49 --> Language Class Initialized
INFO - 2017-06-19 17:57:49 --> Loader Class Initialized
INFO - 2017-06-19 17:57:49 --> Controller Class Initialized
INFO - 2017-06-19 17:57:49 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:49 --> Model Class Initialized
INFO - 2017-06-19 17:57:49 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:49 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:49 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:49 --> Upload Class Initialized
INFO - 2017-06-19 17:57:49 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:49 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:49 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:49 --> Total execution time: 0.0460
ERROR - 2017-06-19 17:57:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:50 --> Config Class Initialized
INFO - 2017-06-19 17:57:50 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:50 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:50 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:50 --> URI Class Initialized
INFO - 2017-06-19 17:57:50 --> Router Class Initialized
INFO - 2017-06-19 17:57:50 --> Output Class Initialized
INFO - 2017-06-19 17:57:50 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:50 --> Input Class Initialized
INFO - 2017-06-19 17:57:50 --> Language Class Initialized
INFO - 2017-06-19 17:57:50 --> Loader Class Initialized
INFO - 2017-06-19 17:57:50 --> Controller Class Initialized
INFO - 2017-06-19 17:57:50 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:50 --> Model Class Initialized
INFO - 2017-06-19 17:57:50 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:50 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:50 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:50 --> Upload Class Initialized
INFO - 2017-06-19 17:57:50 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:50 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:50 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:50 --> Total execution time: 0.0450
ERROR - 2017-06-19 17:57:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:51 --> Config Class Initialized
INFO - 2017-06-19 17:57:51 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:51 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:51 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:51 --> URI Class Initialized
INFO - 2017-06-19 17:57:51 --> Router Class Initialized
INFO - 2017-06-19 17:57:51 --> Output Class Initialized
INFO - 2017-06-19 17:57:51 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:51 --> Input Class Initialized
INFO - 2017-06-19 17:57:51 --> Language Class Initialized
INFO - 2017-06-19 17:57:51 --> Loader Class Initialized
INFO - 2017-06-19 17:57:51 --> Controller Class Initialized
INFO - 2017-06-19 17:57:51 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:51 --> Model Class Initialized
INFO - 2017-06-19 17:57:51 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:51 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:51 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:51 --> Upload Class Initialized
INFO - 2017-06-19 17:57:51 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:51 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:51 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:51 --> Total execution time: 0.0590
ERROR - 2017-06-19 17:57:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:52 --> Config Class Initialized
INFO - 2017-06-19 17:57:52 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:52 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:52 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:52 --> URI Class Initialized
INFO - 2017-06-19 17:57:52 --> Router Class Initialized
INFO - 2017-06-19 17:57:52 --> Output Class Initialized
INFO - 2017-06-19 17:57:52 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:52 --> Input Class Initialized
INFO - 2017-06-19 17:57:52 --> Language Class Initialized
INFO - 2017-06-19 17:57:52 --> Loader Class Initialized
INFO - 2017-06-19 17:57:52 --> Controller Class Initialized
INFO - 2017-06-19 17:57:52 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:52 --> Model Class Initialized
INFO - 2017-06-19 17:57:52 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:52 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:52 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:52 --> Upload Class Initialized
INFO - 2017-06-19 17:57:52 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:52 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:52 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:52 --> Total execution time: 0.0540
ERROR - 2017-06-19 17:57:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:53 --> Config Class Initialized
INFO - 2017-06-19 17:57:53 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:53 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:53 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:53 --> URI Class Initialized
INFO - 2017-06-19 17:57:53 --> Router Class Initialized
INFO - 2017-06-19 17:57:53 --> Output Class Initialized
INFO - 2017-06-19 17:57:53 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:53 --> Input Class Initialized
INFO - 2017-06-19 17:57:53 --> Language Class Initialized
INFO - 2017-06-19 17:57:53 --> Loader Class Initialized
INFO - 2017-06-19 17:57:53 --> Controller Class Initialized
INFO - 2017-06-19 17:57:53 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:53 --> Model Class Initialized
INFO - 2017-06-19 17:57:53 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:53 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:53 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:53 --> Upload Class Initialized
INFO - 2017-06-19 17:57:53 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:53 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:53 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:53 --> Total execution time: 0.0440
ERROR - 2017-06-19 17:57:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:54 --> Config Class Initialized
INFO - 2017-06-19 17:57:54 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:54 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:54 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:54 --> URI Class Initialized
INFO - 2017-06-19 17:57:54 --> Router Class Initialized
INFO - 2017-06-19 17:57:54 --> Output Class Initialized
INFO - 2017-06-19 17:57:54 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:54 --> Input Class Initialized
INFO - 2017-06-19 17:57:54 --> Language Class Initialized
INFO - 2017-06-19 17:57:54 --> Loader Class Initialized
INFO - 2017-06-19 17:57:54 --> Controller Class Initialized
INFO - 2017-06-19 17:57:54 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:54 --> Model Class Initialized
INFO - 2017-06-19 17:57:54 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:54 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:54 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:54 --> Upload Class Initialized
INFO - 2017-06-19 17:57:54 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:54 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:54 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:54 --> Total execution time: 0.0640
ERROR - 2017-06-19 17:57:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:55 --> Config Class Initialized
INFO - 2017-06-19 17:57:55 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:55 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:55 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:55 --> URI Class Initialized
INFO - 2017-06-19 17:57:55 --> Router Class Initialized
INFO - 2017-06-19 17:57:55 --> Output Class Initialized
INFO - 2017-06-19 17:57:55 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:55 --> Input Class Initialized
INFO - 2017-06-19 17:57:55 --> Language Class Initialized
INFO - 2017-06-19 17:57:55 --> Loader Class Initialized
INFO - 2017-06-19 17:57:55 --> Controller Class Initialized
INFO - 2017-06-19 17:57:55 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:55 --> Model Class Initialized
INFO - 2017-06-19 17:57:55 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:55 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:55 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:55 --> Upload Class Initialized
INFO - 2017-06-19 17:57:55 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:55 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:55 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:55 --> Total execution time: 0.0510
ERROR - 2017-06-19 17:57:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:56 --> Config Class Initialized
INFO - 2017-06-19 17:57:56 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:56 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:56 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:56 --> URI Class Initialized
INFO - 2017-06-19 17:57:56 --> Router Class Initialized
INFO - 2017-06-19 17:57:56 --> Output Class Initialized
INFO - 2017-06-19 17:57:56 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:56 --> Input Class Initialized
INFO - 2017-06-19 17:57:56 --> Language Class Initialized
INFO - 2017-06-19 17:57:56 --> Loader Class Initialized
INFO - 2017-06-19 17:57:56 --> Controller Class Initialized
INFO - 2017-06-19 17:57:56 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:56 --> Model Class Initialized
INFO - 2017-06-19 17:57:56 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:56 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:56 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:56 --> Upload Class Initialized
INFO - 2017-06-19 17:57:56 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:56 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:56 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:56 --> Total execution time: 0.0490
ERROR - 2017-06-19 17:57:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:57 --> Config Class Initialized
INFO - 2017-06-19 17:57:57 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:57 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:57 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:57 --> URI Class Initialized
INFO - 2017-06-19 17:57:57 --> Router Class Initialized
INFO - 2017-06-19 17:57:57 --> Output Class Initialized
INFO - 2017-06-19 17:57:57 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:57 --> Input Class Initialized
INFO - 2017-06-19 17:57:57 --> Language Class Initialized
INFO - 2017-06-19 17:57:57 --> Loader Class Initialized
INFO - 2017-06-19 17:57:57 --> Controller Class Initialized
INFO - 2017-06-19 17:57:57 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:57 --> Model Class Initialized
INFO - 2017-06-19 17:57:57 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:57 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:57 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:57 --> Upload Class Initialized
INFO - 2017-06-19 17:57:57 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:57 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:57 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:57 --> Total execution time: 0.0440
ERROR - 2017-06-19 17:57:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:58 --> Config Class Initialized
INFO - 2017-06-19 17:57:58 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:58 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:58 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:58 --> URI Class Initialized
INFO - 2017-06-19 17:57:58 --> Router Class Initialized
INFO - 2017-06-19 17:57:58 --> Output Class Initialized
INFO - 2017-06-19 17:57:58 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:58 --> Input Class Initialized
INFO - 2017-06-19 17:57:58 --> Language Class Initialized
INFO - 2017-06-19 17:57:58 --> Loader Class Initialized
INFO - 2017-06-19 17:57:58 --> Controller Class Initialized
INFO - 2017-06-19 17:57:58 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:58 --> Model Class Initialized
INFO - 2017-06-19 17:57:58 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:58 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:58 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:58 --> Upload Class Initialized
INFO - 2017-06-19 17:57:58 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:58 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:58 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:58 --> Total execution time: 0.0450
ERROR - 2017-06-19 17:57:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:57:59 --> Config Class Initialized
INFO - 2017-06-19 17:57:59 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:57:59 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:57:59 --> Utf8 Class Initialized
INFO - 2017-06-19 17:57:59 --> URI Class Initialized
INFO - 2017-06-19 17:57:59 --> Router Class Initialized
INFO - 2017-06-19 17:57:59 --> Output Class Initialized
INFO - 2017-06-19 17:57:59 --> Security Class Initialized
DEBUG - 2017-06-19 17:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:57:59 --> Input Class Initialized
INFO - 2017-06-19 17:57:59 --> Language Class Initialized
INFO - 2017-06-19 17:57:59 --> Loader Class Initialized
INFO - 2017-06-19 17:57:59 --> Controller Class Initialized
INFO - 2017-06-19 17:57:59 --> Database Driver Class Initialized
INFO - 2017-06-19 17:57:59 --> Model Class Initialized
INFO - 2017-06-19 17:57:59 --> Helper loaded: form_helper
INFO - 2017-06-19 17:57:59 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:57:59 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:57:59 --> Upload Class Initialized
INFO - 2017-06-19 17:57:59 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:57:59 --> You did not select a file to upload.
INFO - 2017-06-19 17:57:59 --> Final output sent to browser
DEBUG - 2017-06-19 17:57:59 --> Total execution time: 0.0490
ERROR - 2017-06-19 17:58:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:00 --> Config Class Initialized
INFO - 2017-06-19 17:58:00 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:00 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:00 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:00 --> URI Class Initialized
INFO - 2017-06-19 17:58:00 --> Router Class Initialized
INFO - 2017-06-19 17:58:00 --> Output Class Initialized
INFO - 2017-06-19 17:58:00 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:00 --> Input Class Initialized
INFO - 2017-06-19 17:58:00 --> Language Class Initialized
INFO - 2017-06-19 17:58:00 --> Loader Class Initialized
INFO - 2017-06-19 17:58:00 --> Controller Class Initialized
INFO - 2017-06-19 17:58:00 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:00 --> Model Class Initialized
INFO - 2017-06-19 17:58:00 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:00 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:00 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:00 --> Upload Class Initialized
INFO - 2017-06-19 17:58:00 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:00 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:00 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:00 --> Total execution time: 0.0450
ERROR - 2017-06-19 17:58:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:01 --> Config Class Initialized
INFO - 2017-06-19 17:58:01 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:01 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:01 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:01 --> URI Class Initialized
INFO - 2017-06-19 17:58:01 --> Router Class Initialized
INFO - 2017-06-19 17:58:01 --> Output Class Initialized
INFO - 2017-06-19 17:58:01 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:01 --> Input Class Initialized
INFO - 2017-06-19 17:58:01 --> Language Class Initialized
INFO - 2017-06-19 17:58:01 --> Loader Class Initialized
INFO - 2017-06-19 17:58:01 --> Controller Class Initialized
INFO - 2017-06-19 17:58:01 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:01 --> Model Class Initialized
INFO - 2017-06-19 17:58:01 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:01 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:01 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:01 --> Upload Class Initialized
INFO - 2017-06-19 17:58:01 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:01 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:01 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:01 --> Total execution time: 0.0620
ERROR - 2017-06-19 17:58:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:02 --> Config Class Initialized
INFO - 2017-06-19 17:58:02 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:02 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:02 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:02 --> URI Class Initialized
INFO - 2017-06-19 17:58:02 --> Router Class Initialized
INFO - 2017-06-19 17:58:02 --> Output Class Initialized
INFO - 2017-06-19 17:58:02 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:02 --> Input Class Initialized
INFO - 2017-06-19 17:58:02 --> Language Class Initialized
INFO - 2017-06-19 17:58:02 --> Loader Class Initialized
INFO - 2017-06-19 17:58:02 --> Controller Class Initialized
INFO - 2017-06-19 17:58:02 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:02 --> Model Class Initialized
INFO - 2017-06-19 17:58:02 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:02 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:02 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:02 --> Upload Class Initialized
INFO - 2017-06-19 17:58:02 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:02 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:02 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:02 --> Total execution time: 0.0550
ERROR - 2017-06-19 17:58:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:03 --> Config Class Initialized
INFO - 2017-06-19 17:58:03 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:03 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:03 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:03 --> URI Class Initialized
INFO - 2017-06-19 17:58:03 --> Router Class Initialized
INFO - 2017-06-19 17:58:03 --> Output Class Initialized
INFO - 2017-06-19 17:58:03 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:03 --> Input Class Initialized
INFO - 2017-06-19 17:58:03 --> Language Class Initialized
INFO - 2017-06-19 17:58:03 --> Loader Class Initialized
INFO - 2017-06-19 17:58:03 --> Controller Class Initialized
INFO - 2017-06-19 17:58:03 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:03 --> Model Class Initialized
INFO - 2017-06-19 17:58:03 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:03 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:03 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:03 --> Upload Class Initialized
INFO - 2017-06-19 17:58:03 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:03 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:03 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:03 --> Total execution time: 0.0480
ERROR - 2017-06-19 17:58:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:04 --> Config Class Initialized
INFO - 2017-06-19 17:58:04 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:04 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:04 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:04 --> URI Class Initialized
INFO - 2017-06-19 17:58:04 --> Router Class Initialized
INFO - 2017-06-19 17:58:04 --> Output Class Initialized
INFO - 2017-06-19 17:58:04 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:04 --> Input Class Initialized
INFO - 2017-06-19 17:58:04 --> Language Class Initialized
INFO - 2017-06-19 17:58:04 --> Loader Class Initialized
INFO - 2017-06-19 17:58:04 --> Controller Class Initialized
INFO - 2017-06-19 17:58:04 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:04 --> Model Class Initialized
INFO - 2017-06-19 17:58:04 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:04 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:04 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:04 --> Upload Class Initialized
INFO - 2017-06-19 17:58:04 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:04 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:04 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:04 --> Total execution time: 0.0450
ERROR - 2017-06-19 17:58:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:05 --> Config Class Initialized
INFO - 2017-06-19 17:58:05 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:05 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:05 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:05 --> URI Class Initialized
INFO - 2017-06-19 17:58:05 --> Router Class Initialized
INFO - 2017-06-19 17:58:05 --> Output Class Initialized
INFO - 2017-06-19 17:58:05 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:05 --> Input Class Initialized
INFO - 2017-06-19 17:58:05 --> Language Class Initialized
INFO - 2017-06-19 17:58:05 --> Loader Class Initialized
INFO - 2017-06-19 17:58:05 --> Controller Class Initialized
INFO - 2017-06-19 17:58:05 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:05 --> Model Class Initialized
INFO - 2017-06-19 17:58:05 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:05 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:05 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:05 --> Upload Class Initialized
INFO - 2017-06-19 17:58:05 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:05 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:05 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:05 --> Total execution time: 0.0490
ERROR - 2017-06-19 17:58:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:06 --> Config Class Initialized
INFO - 2017-06-19 17:58:06 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:06 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:06 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:06 --> URI Class Initialized
INFO - 2017-06-19 17:58:06 --> Router Class Initialized
INFO - 2017-06-19 17:58:06 --> Output Class Initialized
INFO - 2017-06-19 17:58:06 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:06 --> Input Class Initialized
INFO - 2017-06-19 17:58:06 --> Language Class Initialized
INFO - 2017-06-19 17:58:06 --> Loader Class Initialized
INFO - 2017-06-19 17:58:06 --> Controller Class Initialized
INFO - 2017-06-19 17:58:06 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:06 --> Model Class Initialized
INFO - 2017-06-19 17:58:06 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:06 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:06 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:06 --> Upload Class Initialized
INFO - 2017-06-19 17:58:06 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:06 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:06 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:06 --> Total execution time: 0.0590
ERROR - 2017-06-19 17:58:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:07 --> Config Class Initialized
INFO - 2017-06-19 17:58:07 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:07 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:07 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:07 --> URI Class Initialized
INFO - 2017-06-19 17:58:07 --> Router Class Initialized
INFO - 2017-06-19 17:58:07 --> Output Class Initialized
INFO - 2017-06-19 17:58:07 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:07 --> Input Class Initialized
INFO - 2017-06-19 17:58:07 --> Language Class Initialized
INFO - 2017-06-19 17:58:07 --> Loader Class Initialized
INFO - 2017-06-19 17:58:07 --> Controller Class Initialized
INFO - 2017-06-19 17:58:07 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:07 --> Model Class Initialized
INFO - 2017-06-19 17:58:07 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:07 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:07 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:07 --> Upload Class Initialized
INFO - 2017-06-19 17:58:07 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:07 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:07 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:07 --> Total execution time: 0.0520
ERROR - 2017-06-19 17:58:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:08 --> Config Class Initialized
INFO - 2017-06-19 17:58:08 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:08 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:08 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:08 --> URI Class Initialized
INFO - 2017-06-19 17:58:08 --> Router Class Initialized
INFO - 2017-06-19 17:58:08 --> Output Class Initialized
INFO - 2017-06-19 17:58:08 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:08 --> Input Class Initialized
INFO - 2017-06-19 17:58:08 --> Language Class Initialized
INFO - 2017-06-19 17:58:08 --> Loader Class Initialized
INFO - 2017-06-19 17:58:08 --> Controller Class Initialized
INFO - 2017-06-19 17:58:08 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:08 --> Model Class Initialized
INFO - 2017-06-19 17:58:08 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:08 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:08 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:08 --> Upload Class Initialized
INFO - 2017-06-19 17:58:08 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:08 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:08 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:08 --> Total execution time: 0.0460
ERROR - 2017-06-19 17:58:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:09 --> Config Class Initialized
INFO - 2017-06-19 17:58:09 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:10 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:10 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:10 --> URI Class Initialized
INFO - 2017-06-19 17:58:10 --> Router Class Initialized
INFO - 2017-06-19 17:58:10 --> Output Class Initialized
INFO - 2017-06-19 17:58:10 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:10 --> Input Class Initialized
INFO - 2017-06-19 17:58:10 --> Language Class Initialized
INFO - 2017-06-19 17:58:10 --> Loader Class Initialized
INFO - 2017-06-19 17:58:10 --> Controller Class Initialized
INFO - 2017-06-19 17:58:10 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:10 --> Model Class Initialized
INFO - 2017-06-19 17:58:10 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:10 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:10 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:10 --> Upload Class Initialized
INFO - 2017-06-19 17:58:10 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:10 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:10 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:10 --> Total execution time: 0.0540
ERROR - 2017-06-19 17:58:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:11 --> Config Class Initialized
INFO - 2017-06-19 17:58:11 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:11 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:11 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:11 --> URI Class Initialized
INFO - 2017-06-19 17:58:11 --> Router Class Initialized
INFO - 2017-06-19 17:58:11 --> Output Class Initialized
INFO - 2017-06-19 17:58:11 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:11 --> Input Class Initialized
INFO - 2017-06-19 17:58:11 --> Language Class Initialized
INFO - 2017-06-19 17:58:11 --> Loader Class Initialized
INFO - 2017-06-19 17:58:11 --> Controller Class Initialized
INFO - 2017-06-19 17:58:11 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:11 --> Model Class Initialized
INFO - 2017-06-19 17:58:11 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:11 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:11 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:11 --> Upload Class Initialized
INFO - 2017-06-19 17:58:11 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:11 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:11 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:11 --> Total execution time: 0.0660
ERROR - 2017-06-19 17:58:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:12 --> Config Class Initialized
INFO - 2017-06-19 17:58:12 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:12 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:12 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:12 --> URI Class Initialized
INFO - 2017-06-19 17:58:12 --> Router Class Initialized
INFO - 2017-06-19 17:58:12 --> Output Class Initialized
INFO - 2017-06-19 17:58:12 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:12 --> Input Class Initialized
INFO - 2017-06-19 17:58:12 --> Language Class Initialized
INFO - 2017-06-19 17:58:12 --> Loader Class Initialized
INFO - 2017-06-19 17:58:12 --> Controller Class Initialized
INFO - 2017-06-19 17:58:12 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:12 --> Model Class Initialized
INFO - 2017-06-19 17:58:12 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:12 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:12 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:12 --> Upload Class Initialized
INFO - 2017-06-19 17:58:12 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:12 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:12 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:12 --> Total execution time: 0.0450
ERROR - 2017-06-19 17:58:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:13 --> Config Class Initialized
INFO - 2017-06-19 17:58:13 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:13 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:13 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:13 --> URI Class Initialized
INFO - 2017-06-19 17:58:13 --> Router Class Initialized
INFO - 2017-06-19 17:58:13 --> Output Class Initialized
INFO - 2017-06-19 17:58:13 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:13 --> Input Class Initialized
INFO - 2017-06-19 17:58:13 --> Language Class Initialized
INFO - 2017-06-19 17:58:13 --> Loader Class Initialized
INFO - 2017-06-19 17:58:13 --> Controller Class Initialized
INFO - 2017-06-19 17:58:13 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:13 --> Model Class Initialized
INFO - 2017-06-19 17:58:13 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:13 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:13 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:13 --> Upload Class Initialized
INFO - 2017-06-19 17:58:13 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:13 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:13 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:13 --> Total execution time: 0.0740
ERROR - 2017-06-19 17:58:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:14 --> Config Class Initialized
INFO - 2017-06-19 17:58:14 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:14 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:14 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:14 --> URI Class Initialized
INFO - 2017-06-19 17:58:14 --> Router Class Initialized
INFO - 2017-06-19 17:58:14 --> Output Class Initialized
INFO - 2017-06-19 17:58:14 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:14 --> Input Class Initialized
INFO - 2017-06-19 17:58:14 --> Language Class Initialized
INFO - 2017-06-19 17:58:14 --> Loader Class Initialized
INFO - 2017-06-19 17:58:14 --> Controller Class Initialized
INFO - 2017-06-19 17:58:14 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:14 --> Model Class Initialized
INFO - 2017-06-19 17:58:14 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:14 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:14 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:14 --> Upload Class Initialized
INFO - 2017-06-19 17:58:14 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:14 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:14 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:14 --> Total execution time: 0.0480
ERROR - 2017-06-19 17:58:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:15 --> Config Class Initialized
INFO - 2017-06-19 17:58:15 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:15 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:15 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:15 --> URI Class Initialized
INFO - 2017-06-19 17:58:15 --> Router Class Initialized
INFO - 2017-06-19 17:58:15 --> Output Class Initialized
INFO - 2017-06-19 17:58:15 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:15 --> Input Class Initialized
INFO - 2017-06-19 17:58:15 --> Language Class Initialized
INFO - 2017-06-19 17:58:15 --> Loader Class Initialized
INFO - 2017-06-19 17:58:15 --> Controller Class Initialized
INFO - 2017-06-19 17:58:15 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:15 --> Model Class Initialized
INFO - 2017-06-19 17:58:15 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:15 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:15 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:15 --> Upload Class Initialized
INFO - 2017-06-19 17:58:15 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:15 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:15 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:15 --> Total execution time: 0.0540
ERROR - 2017-06-19 17:58:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:17 --> Config Class Initialized
INFO - 2017-06-19 17:58:17 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:17 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:17 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:17 --> URI Class Initialized
INFO - 2017-06-19 17:58:17 --> Router Class Initialized
INFO - 2017-06-19 17:58:17 --> Output Class Initialized
INFO - 2017-06-19 17:58:17 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:17 --> Input Class Initialized
INFO - 2017-06-19 17:58:17 --> Language Class Initialized
INFO - 2017-06-19 17:58:17 --> Loader Class Initialized
INFO - 2017-06-19 17:58:17 --> Controller Class Initialized
INFO - 2017-06-19 17:58:17 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:17 --> Model Class Initialized
INFO - 2017-06-19 17:58:17 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:17 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:17 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:17 --> Upload Class Initialized
INFO - 2017-06-19 17:58:17 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:17 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:17 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:17 --> Total execution time: 0.0590
ERROR - 2017-06-19 17:58:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:19 --> Config Class Initialized
INFO - 2017-06-19 17:58:19 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:19 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:19 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:19 --> URI Class Initialized
INFO - 2017-06-19 17:58:19 --> Router Class Initialized
INFO - 2017-06-19 17:58:19 --> Output Class Initialized
INFO - 2017-06-19 17:58:19 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:19 --> Input Class Initialized
INFO - 2017-06-19 17:58:19 --> Language Class Initialized
INFO - 2017-06-19 17:58:19 --> Loader Class Initialized
INFO - 2017-06-19 17:58:19 --> Controller Class Initialized
INFO - 2017-06-19 17:58:19 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:19 --> Model Class Initialized
INFO - 2017-06-19 17:58:19 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:19 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:19 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:19 --> Upload Class Initialized
INFO - 2017-06-19 17:58:19 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:19 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:19 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:19 --> Total execution time: 0.0560
ERROR - 2017-06-19 17:58:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:20 --> Config Class Initialized
INFO - 2017-06-19 17:58:20 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:20 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:20 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:20 --> URI Class Initialized
INFO - 2017-06-19 17:58:20 --> Router Class Initialized
INFO - 2017-06-19 17:58:20 --> Output Class Initialized
INFO - 2017-06-19 17:58:20 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:20 --> Input Class Initialized
INFO - 2017-06-19 17:58:20 --> Language Class Initialized
INFO - 2017-06-19 17:58:20 --> Loader Class Initialized
INFO - 2017-06-19 17:58:20 --> Controller Class Initialized
INFO - 2017-06-19 17:58:20 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:20 --> Model Class Initialized
INFO - 2017-06-19 17:58:20 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:20 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:20 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:20 --> Upload Class Initialized
INFO - 2017-06-19 17:58:20 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:20 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:20 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:20 --> Total execution time: 0.0590
ERROR - 2017-06-19 17:58:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:21 --> Config Class Initialized
INFO - 2017-06-19 17:58:21 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:21 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:21 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:21 --> URI Class Initialized
INFO - 2017-06-19 17:58:21 --> Router Class Initialized
INFO - 2017-06-19 17:58:21 --> Output Class Initialized
INFO - 2017-06-19 17:58:21 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:21 --> Input Class Initialized
INFO - 2017-06-19 17:58:21 --> Language Class Initialized
INFO - 2017-06-19 17:58:21 --> Loader Class Initialized
INFO - 2017-06-19 17:58:21 --> Controller Class Initialized
INFO - 2017-06-19 17:58:21 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:21 --> Model Class Initialized
INFO - 2017-06-19 17:58:21 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:21 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:21 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:21 --> Upload Class Initialized
INFO - 2017-06-19 17:58:22 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:22 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:22 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:22 --> Total execution time: 0.0470
ERROR - 2017-06-19 17:58:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:23 --> Config Class Initialized
INFO - 2017-06-19 17:58:23 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:23 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:23 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:23 --> URI Class Initialized
INFO - 2017-06-19 17:58:23 --> Router Class Initialized
INFO - 2017-06-19 17:58:23 --> Output Class Initialized
INFO - 2017-06-19 17:58:23 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:23 --> Input Class Initialized
INFO - 2017-06-19 17:58:23 --> Language Class Initialized
INFO - 2017-06-19 17:58:23 --> Loader Class Initialized
INFO - 2017-06-19 17:58:23 --> Controller Class Initialized
INFO - 2017-06-19 17:58:23 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:23 --> Model Class Initialized
INFO - 2017-06-19 17:58:23 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:23 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:23 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:23 --> Upload Class Initialized
INFO - 2017-06-19 17:58:23 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:23 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:23 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:23 --> Total execution time: 0.0480
ERROR - 2017-06-19 17:58:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:24 --> Config Class Initialized
INFO - 2017-06-19 17:58:24 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:24 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:24 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:24 --> URI Class Initialized
INFO - 2017-06-19 17:58:24 --> Router Class Initialized
INFO - 2017-06-19 17:58:24 --> Output Class Initialized
INFO - 2017-06-19 17:58:24 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:24 --> Input Class Initialized
INFO - 2017-06-19 17:58:24 --> Language Class Initialized
INFO - 2017-06-19 17:58:24 --> Loader Class Initialized
INFO - 2017-06-19 17:58:24 --> Controller Class Initialized
INFO - 2017-06-19 17:58:24 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:24 --> Model Class Initialized
INFO - 2017-06-19 17:58:24 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:24 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:24 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:24 --> Upload Class Initialized
INFO - 2017-06-19 17:58:24 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:24 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:24 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:24 --> Total execution time: 0.0670
ERROR - 2017-06-19 17:58:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:26 --> Config Class Initialized
INFO - 2017-06-19 17:58:26 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:26 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:26 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:26 --> URI Class Initialized
INFO - 2017-06-19 17:58:26 --> Router Class Initialized
INFO - 2017-06-19 17:58:26 --> Output Class Initialized
INFO - 2017-06-19 17:58:26 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:26 --> Input Class Initialized
INFO - 2017-06-19 17:58:26 --> Language Class Initialized
INFO - 2017-06-19 17:58:26 --> Loader Class Initialized
INFO - 2017-06-19 17:58:26 --> Controller Class Initialized
INFO - 2017-06-19 17:58:26 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:26 --> Model Class Initialized
INFO - 2017-06-19 17:58:26 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:26 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:26 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:26 --> Upload Class Initialized
INFO - 2017-06-19 17:58:26 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:26 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:26 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:26 --> Total execution time: 0.0460
ERROR - 2017-06-19 17:58:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:27 --> Config Class Initialized
INFO - 2017-06-19 17:58:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:27 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:27 --> URI Class Initialized
INFO - 2017-06-19 17:58:27 --> Router Class Initialized
INFO - 2017-06-19 17:58:27 --> Output Class Initialized
INFO - 2017-06-19 17:58:27 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:27 --> Input Class Initialized
INFO - 2017-06-19 17:58:27 --> Language Class Initialized
INFO - 2017-06-19 17:58:27 --> Loader Class Initialized
INFO - 2017-06-19 17:58:27 --> Controller Class Initialized
INFO - 2017-06-19 17:58:27 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:27 --> Model Class Initialized
INFO - 2017-06-19 17:58:27 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:27 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:27 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:27 --> Upload Class Initialized
INFO - 2017-06-19 17:58:27 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:27 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:27 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:27 --> Total execution time: 0.0620
ERROR - 2017-06-19 17:58:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:28 --> Config Class Initialized
INFO - 2017-06-19 17:58:28 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:28 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:28 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:28 --> URI Class Initialized
INFO - 2017-06-19 17:58:28 --> Router Class Initialized
INFO - 2017-06-19 17:58:28 --> Output Class Initialized
INFO - 2017-06-19 17:58:28 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:28 --> Input Class Initialized
INFO - 2017-06-19 17:58:28 --> Language Class Initialized
INFO - 2017-06-19 17:58:28 --> Loader Class Initialized
INFO - 2017-06-19 17:58:28 --> Controller Class Initialized
INFO - 2017-06-19 17:58:28 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:28 --> Model Class Initialized
INFO - 2017-06-19 17:58:28 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:28 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:28 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:28 --> Upload Class Initialized
INFO - 2017-06-19 17:58:28 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:28 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:28 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:28 --> Total execution time: 0.0590
ERROR - 2017-06-19 17:58:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:30 --> Config Class Initialized
INFO - 2017-06-19 17:58:30 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:30 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:30 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:30 --> URI Class Initialized
INFO - 2017-06-19 17:58:30 --> Router Class Initialized
INFO - 2017-06-19 17:58:30 --> Output Class Initialized
INFO - 2017-06-19 17:58:30 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:30 --> Input Class Initialized
INFO - 2017-06-19 17:58:30 --> Language Class Initialized
INFO - 2017-06-19 17:58:30 --> Loader Class Initialized
INFO - 2017-06-19 17:58:30 --> Controller Class Initialized
INFO - 2017-06-19 17:58:30 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:30 --> Model Class Initialized
INFO - 2017-06-19 17:58:30 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:30 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:30 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:30 --> Upload Class Initialized
INFO - 2017-06-19 17:58:30 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:30 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:30 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:30 --> Total execution time: 0.0510
ERROR - 2017-06-19 17:58:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:31 --> Config Class Initialized
INFO - 2017-06-19 17:58:31 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:31 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:31 --> URI Class Initialized
INFO - 2017-06-19 17:58:31 --> Router Class Initialized
INFO - 2017-06-19 17:58:31 --> Output Class Initialized
INFO - 2017-06-19 17:58:31 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:31 --> Input Class Initialized
INFO - 2017-06-19 17:58:31 --> Language Class Initialized
INFO - 2017-06-19 17:58:31 --> Loader Class Initialized
INFO - 2017-06-19 17:58:31 --> Controller Class Initialized
INFO - 2017-06-19 17:58:31 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:31 --> Model Class Initialized
INFO - 2017-06-19 17:58:31 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:31 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:31 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:31 --> Upload Class Initialized
INFO - 2017-06-19 17:58:31 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:31 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:31 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:31 --> Total execution time: 0.0490
ERROR - 2017-06-19 17:58:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:32 --> Config Class Initialized
INFO - 2017-06-19 17:58:32 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:33 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:33 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:33 --> URI Class Initialized
INFO - 2017-06-19 17:58:33 --> Router Class Initialized
INFO - 2017-06-19 17:58:33 --> Output Class Initialized
INFO - 2017-06-19 17:58:33 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:33 --> Input Class Initialized
INFO - 2017-06-19 17:58:33 --> Language Class Initialized
INFO - 2017-06-19 17:58:33 --> Loader Class Initialized
INFO - 2017-06-19 17:58:33 --> Controller Class Initialized
INFO - 2017-06-19 17:58:33 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:33 --> Model Class Initialized
INFO - 2017-06-19 17:58:33 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:33 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:33 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:33 --> Upload Class Initialized
INFO - 2017-06-19 17:58:33 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:33 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:33 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:33 --> Total execution time: 0.0700
ERROR - 2017-06-19 17:58:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:34 --> Config Class Initialized
INFO - 2017-06-19 17:58:34 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:34 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:34 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:34 --> URI Class Initialized
INFO - 2017-06-19 17:58:34 --> Router Class Initialized
INFO - 2017-06-19 17:58:34 --> Output Class Initialized
INFO - 2017-06-19 17:58:34 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:34 --> Input Class Initialized
INFO - 2017-06-19 17:58:34 --> Language Class Initialized
INFO - 2017-06-19 17:58:34 --> Loader Class Initialized
INFO - 2017-06-19 17:58:34 --> Controller Class Initialized
INFO - 2017-06-19 17:58:34 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:34 --> Model Class Initialized
INFO - 2017-06-19 17:58:34 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:34 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:34 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:34 --> Upload Class Initialized
INFO - 2017-06-19 17:58:34 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:34 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:34 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:34 --> Total execution time: 0.0460
ERROR - 2017-06-19 17:58:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:35 --> Config Class Initialized
INFO - 2017-06-19 17:58:35 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:35 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:35 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:35 --> URI Class Initialized
INFO - 2017-06-19 17:58:35 --> Router Class Initialized
INFO - 2017-06-19 17:58:35 --> Output Class Initialized
INFO - 2017-06-19 17:58:35 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:35 --> Input Class Initialized
INFO - 2017-06-19 17:58:35 --> Language Class Initialized
INFO - 2017-06-19 17:58:35 --> Loader Class Initialized
INFO - 2017-06-19 17:58:35 --> Controller Class Initialized
INFO - 2017-06-19 17:58:35 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:35 --> Model Class Initialized
INFO - 2017-06-19 17:58:35 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:35 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:35 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:35 --> Upload Class Initialized
INFO - 2017-06-19 17:58:35 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:35 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:35 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:35 --> Total execution time: 0.0460
ERROR - 2017-06-19 17:58:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:37 --> Config Class Initialized
INFO - 2017-06-19 17:58:37 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:37 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:37 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:37 --> URI Class Initialized
INFO - 2017-06-19 17:58:37 --> Router Class Initialized
INFO - 2017-06-19 17:58:37 --> Output Class Initialized
INFO - 2017-06-19 17:58:37 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:37 --> Input Class Initialized
INFO - 2017-06-19 17:58:37 --> Language Class Initialized
INFO - 2017-06-19 17:58:37 --> Loader Class Initialized
INFO - 2017-06-19 17:58:37 --> Controller Class Initialized
INFO - 2017-06-19 17:58:37 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:37 --> Model Class Initialized
INFO - 2017-06-19 17:58:37 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:37 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:37 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:37 --> Upload Class Initialized
INFO - 2017-06-19 17:58:37 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:37 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:37 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:37 --> Total execution time: 0.0680
ERROR - 2017-06-19 17:58:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:38 --> Config Class Initialized
INFO - 2017-06-19 17:58:38 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:38 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:38 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:38 --> URI Class Initialized
INFO - 2017-06-19 17:58:38 --> Router Class Initialized
INFO - 2017-06-19 17:58:38 --> Output Class Initialized
INFO - 2017-06-19 17:58:38 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:38 --> Input Class Initialized
INFO - 2017-06-19 17:58:38 --> Language Class Initialized
INFO - 2017-06-19 17:58:38 --> Loader Class Initialized
INFO - 2017-06-19 17:58:38 --> Controller Class Initialized
INFO - 2017-06-19 17:58:38 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:38 --> Model Class Initialized
INFO - 2017-06-19 17:58:38 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:38 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:38 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:38 --> Upload Class Initialized
INFO - 2017-06-19 17:58:38 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:38 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:38 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:38 --> Total execution time: 0.0580
ERROR - 2017-06-19 17:58:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:40 --> Config Class Initialized
INFO - 2017-06-19 17:58:40 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:40 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:40 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:40 --> URI Class Initialized
INFO - 2017-06-19 17:58:40 --> Router Class Initialized
INFO - 2017-06-19 17:58:40 --> Output Class Initialized
INFO - 2017-06-19 17:58:40 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:40 --> Input Class Initialized
INFO - 2017-06-19 17:58:40 --> Language Class Initialized
INFO - 2017-06-19 17:58:40 --> Loader Class Initialized
INFO - 2017-06-19 17:58:40 --> Controller Class Initialized
INFO - 2017-06-19 17:58:40 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:40 --> Model Class Initialized
INFO - 2017-06-19 17:58:40 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:40 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:40 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:40 --> Upload Class Initialized
INFO - 2017-06-19 17:58:40 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:40 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:40 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:40 --> Total execution time: 0.0770
ERROR - 2017-06-19 17:58:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:42 --> Config Class Initialized
INFO - 2017-06-19 17:58:42 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:42 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:42 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:42 --> URI Class Initialized
INFO - 2017-06-19 17:58:42 --> Router Class Initialized
INFO - 2017-06-19 17:58:42 --> Output Class Initialized
INFO - 2017-06-19 17:58:42 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:42 --> Input Class Initialized
INFO - 2017-06-19 17:58:42 --> Language Class Initialized
INFO - 2017-06-19 17:58:42 --> Loader Class Initialized
INFO - 2017-06-19 17:58:42 --> Controller Class Initialized
INFO - 2017-06-19 17:58:42 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:42 --> Model Class Initialized
INFO - 2017-06-19 17:58:42 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:42 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:42 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:42 --> Upload Class Initialized
INFO - 2017-06-19 17:58:42 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:42 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:42 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:42 --> Total execution time: 0.0530
ERROR - 2017-06-19 17:58:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:43 --> Config Class Initialized
INFO - 2017-06-19 17:58:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:43 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:43 --> URI Class Initialized
INFO - 2017-06-19 17:58:43 --> Router Class Initialized
INFO - 2017-06-19 17:58:43 --> Output Class Initialized
INFO - 2017-06-19 17:58:43 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:43 --> Input Class Initialized
INFO - 2017-06-19 17:58:43 --> Language Class Initialized
INFO - 2017-06-19 17:58:43 --> Loader Class Initialized
INFO - 2017-06-19 17:58:43 --> Controller Class Initialized
INFO - 2017-06-19 17:58:43 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:43 --> Model Class Initialized
INFO - 2017-06-19 17:58:43 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:43 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:43 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:43 --> Upload Class Initialized
INFO - 2017-06-19 17:58:43 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:43 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:43 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:43 --> Total execution time: 0.0620
ERROR - 2017-06-19 17:58:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:45 --> Config Class Initialized
INFO - 2017-06-19 17:58:45 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:45 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:45 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:45 --> URI Class Initialized
INFO - 2017-06-19 17:58:45 --> Router Class Initialized
INFO - 2017-06-19 17:58:45 --> Output Class Initialized
INFO - 2017-06-19 17:58:45 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:45 --> Input Class Initialized
INFO - 2017-06-19 17:58:45 --> Language Class Initialized
INFO - 2017-06-19 17:58:45 --> Loader Class Initialized
INFO - 2017-06-19 17:58:45 --> Controller Class Initialized
INFO - 2017-06-19 17:58:45 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:45 --> Model Class Initialized
INFO - 2017-06-19 17:58:45 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:45 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:45 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:45 --> Upload Class Initialized
INFO - 2017-06-19 17:58:45 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:45 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:45 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:45 --> Total execution time: 0.0620
ERROR - 2017-06-19 17:58:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:46 --> Config Class Initialized
INFO - 2017-06-19 17:58:46 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:46 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:46 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:46 --> URI Class Initialized
INFO - 2017-06-19 17:58:46 --> Router Class Initialized
INFO - 2017-06-19 17:58:46 --> Output Class Initialized
INFO - 2017-06-19 17:58:46 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:46 --> Input Class Initialized
INFO - 2017-06-19 17:58:46 --> Language Class Initialized
INFO - 2017-06-19 17:58:46 --> Loader Class Initialized
INFO - 2017-06-19 17:58:46 --> Controller Class Initialized
INFO - 2017-06-19 17:58:46 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:46 --> Model Class Initialized
INFO - 2017-06-19 17:58:46 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:46 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:46 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:46 --> Upload Class Initialized
INFO - 2017-06-19 17:58:46 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:46 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:46 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:46 --> Total execution time: 0.0710
ERROR - 2017-06-19 17:58:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:49 --> Config Class Initialized
INFO - 2017-06-19 17:58:49 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:49 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:49 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:49 --> URI Class Initialized
INFO - 2017-06-19 17:58:49 --> Router Class Initialized
INFO - 2017-06-19 17:58:49 --> Output Class Initialized
INFO - 2017-06-19 17:58:50 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:50 --> Input Class Initialized
INFO - 2017-06-19 17:58:50 --> Language Class Initialized
INFO - 2017-06-19 17:58:50 --> Loader Class Initialized
INFO - 2017-06-19 17:58:50 --> Controller Class Initialized
INFO - 2017-06-19 17:58:50 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:50 --> Model Class Initialized
INFO - 2017-06-19 17:58:50 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:50 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:50 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:50 --> Upload Class Initialized
INFO - 2017-06-19 17:58:50 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:50 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:50 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:50 --> Total execution time: 0.0590
ERROR - 2017-06-19 17:58:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:51 --> Config Class Initialized
INFO - 2017-06-19 17:58:51 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:51 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:51 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:51 --> URI Class Initialized
INFO - 2017-06-19 17:58:51 --> Router Class Initialized
INFO - 2017-06-19 17:58:51 --> Output Class Initialized
INFO - 2017-06-19 17:58:51 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:51 --> Input Class Initialized
INFO - 2017-06-19 17:58:51 --> Language Class Initialized
INFO - 2017-06-19 17:58:51 --> Loader Class Initialized
INFO - 2017-06-19 17:58:51 --> Controller Class Initialized
INFO - 2017-06-19 17:58:51 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:51 --> Model Class Initialized
INFO - 2017-06-19 17:58:51 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:51 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:51 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:51 --> Upload Class Initialized
INFO - 2017-06-19 17:58:51 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:51 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:51 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:51 --> Total execution time: 0.0520
ERROR - 2017-06-19 17:58:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:53 --> Config Class Initialized
INFO - 2017-06-19 17:58:53 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:53 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:53 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:53 --> URI Class Initialized
INFO - 2017-06-19 17:58:53 --> Router Class Initialized
INFO - 2017-06-19 17:58:53 --> Output Class Initialized
INFO - 2017-06-19 17:58:53 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:53 --> Input Class Initialized
INFO - 2017-06-19 17:58:53 --> Language Class Initialized
INFO - 2017-06-19 17:58:53 --> Loader Class Initialized
INFO - 2017-06-19 17:58:53 --> Controller Class Initialized
INFO - 2017-06-19 17:58:53 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:53 --> Model Class Initialized
INFO - 2017-06-19 17:58:53 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:53 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:53 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:53 --> Upload Class Initialized
INFO - 2017-06-19 17:58:53 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:53 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:53 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:53 --> Total execution time: 0.0690
ERROR - 2017-06-19 17:58:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:55 --> Config Class Initialized
INFO - 2017-06-19 17:58:55 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:55 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:55 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:55 --> URI Class Initialized
INFO - 2017-06-19 17:58:55 --> Router Class Initialized
INFO - 2017-06-19 17:58:55 --> Output Class Initialized
INFO - 2017-06-19 17:58:55 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:55 --> Input Class Initialized
INFO - 2017-06-19 17:58:55 --> Language Class Initialized
INFO - 2017-06-19 17:58:55 --> Loader Class Initialized
INFO - 2017-06-19 17:58:55 --> Controller Class Initialized
INFO - 2017-06-19 17:58:55 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:55 --> Model Class Initialized
INFO - 2017-06-19 17:58:55 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:55 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:55 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:55 --> Upload Class Initialized
INFO - 2017-06-19 17:58:55 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:55 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:55 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:55 --> Total execution time: 0.0590
ERROR - 2017-06-19 17:58:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:57 --> Config Class Initialized
INFO - 2017-06-19 17:58:57 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:57 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:57 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:57 --> URI Class Initialized
INFO - 2017-06-19 17:58:57 --> Router Class Initialized
INFO - 2017-06-19 17:58:57 --> Output Class Initialized
INFO - 2017-06-19 17:58:57 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:57 --> Input Class Initialized
INFO - 2017-06-19 17:58:57 --> Language Class Initialized
INFO - 2017-06-19 17:58:57 --> Loader Class Initialized
INFO - 2017-06-19 17:58:57 --> Controller Class Initialized
INFO - 2017-06-19 17:58:57 --> Database Driver Class Initialized
INFO - 2017-06-19 17:58:57 --> Model Class Initialized
INFO - 2017-06-19 17:58:57 --> Helper loaded: form_helper
INFO - 2017-06-19 17:58:57 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:58:57 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:58:57 --> Upload Class Initialized
INFO - 2017-06-19 17:58:57 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:58:57 --> You did not select a file to upload.
INFO - 2017-06-19 17:58:57 --> Final output sent to browser
DEBUG - 2017-06-19 17:58:57 --> Total execution time: 0.0620
ERROR - 2017-06-19 17:58:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:58:59 --> Config Class Initialized
INFO - 2017-06-19 17:58:59 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:58:59 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:58:59 --> Utf8 Class Initialized
INFO - 2017-06-19 17:58:59 --> URI Class Initialized
INFO - 2017-06-19 17:58:59 --> Router Class Initialized
INFO - 2017-06-19 17:58:59 --> Output Class Initialized
INFO - 2017-06-19 17:58:59 --> Security Class Initialized
DEBUG - 2017-06-19 17:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:58:59 --> Input Class Initialized
INFO - 2017-06-19 17:58:59 --> Language Class Initialized
INFO - 2017-06-19 17:58:59 --> Loader Class Initialized
INFO - 2017-06-19 17:58:59 --> Controller Class Initialized
INFO - 2017-06-19 17:59:00 --> Database Driver Class Initialized
INFO - 2017-06-19 17:59:00 --> Model Class Initialized
INFO - 2017-06-19 17:59:00 --> Helper loaded: form_helper
INFO - 2017-06-19 17:59:00 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:59:00 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:59:00 --> Upload Class Initialized
INFO - 2017-06-19 17:59:00 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:59:00 --> You did not select a file to upload.
INFO - 2017-06-19 17:59:00 --> Final output sent to browser
DEBUG - 2017-06-19 17:59:00 --> Total execution time: 0.0610
ERROR - 2017-06-19 17:59:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:59:01 --> Config Class Initialized
INFO - 2017-06-19 17:59:01 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:59:01 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:59:01 --> Utf8 Class Initialized
INFO - 2017-06-19 17:59:01 --> URI Class Initialized
INFO - 2017-06-19 17:59:01 --> Router Class Initialized
INFO - 2017-06-19 17:59:01 --> Output Class Initialized
INFO - 2017-06-19 17:59:01 --> Security Class Initialized
DEBUG - 2017-06-19 17:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:59:01 --> Input Class Initialized
INFO - 2017-06-19 17:59:01 --> Language Class Initialized
INFO - 2017-06-19 17:59:01 --> Loader Class Initialized
INFO - 2017-06-19 17:59:01 --> Controller Class Initialized
INFO - 2017-06-19 17:59:01 --> Database Driver Class Initialized
INFO - 2017-06-19 17:59:01 --> Model Class Initialized
INFO - 2017-06-19 17:59:01 --> Helper loaded: form_helper
INFO - 2017-06-19 17:59:01 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:59:01 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:59:01 --> Upload Class Initialized
INFO - 2017-06-19 17:59:01 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:59:01 --> You did not select a file to upload.
INFO - 2017-06-19 17:59:01 --> Final output sent to browser
DEBUG - 2017-06-19 17:59:01 --> Total execution time: 0.0570
ERROR - 2017-06-19 17:59:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 17:59:03 --> Config Class Initialized
INFO - 2017-06-19 17:59:03 --> Hooks Class Initialized
DEBUG - 2017-06-19 17:59:03 --> UTF-8 Support Enabled
INFO - 2017-06-19 17:59:03 --> Utf8 Class Initialized
INFO - 2017-06-19 17:59:03 --> URI Class Initialized
INFO - 2017-06-19 17:59:03 --> Router Class Initialized
INFO - 2017-06-19 17:59:03 --> Output Class Initialized
INFO - 2017-06-19 17:59:03 --> Security Class Initialized
DEBUG - 2017-06-19 17:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 17:59:03 --> Input Class Initialized
INFO - 2017-06-19 17:59:03 --> Language Class Initialized
INFO - 2017-06-19 17:59:03 --> Loader Class Initialized
INFO - 2017-06-19 17:59:03 --> Controller Class Initialized
INFO - 2017-06-19 17:59:03 --> Database Driver Class Initialized
INFO - 2017-06-19 17:59:03 --> Model Class Initialized
INFO - 2017-06-19 17:59:03 --> Helper loaded: form_helper
INFO - 2017-06-19 17:59:03 --> Helper loaded: url_helper
ERROR - 2017-06-19 17:59:03 --> Severity: Notice --> Undefined index: index C:\xampp\htdocs\mystage\application\controllers\Services.php 267
INFO - 2017-06-19 17:59:03 --> Upload Class Initialized
INFO - 2017-06-19 17:59:03 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-19 17:59:03 --> You did not select a file to upload.
INFO - 2017-06-19 17:59:03 --> Final output sent to browser
DEBUG - 2017-06-19 17:59:03 --> Total execution time: 0.0510
ERROR - 2017-06-19 18:00:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:17 --> Config Class Initialized
INFO - 2017-06-19 18:00:17 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:17 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:17 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:17 --> URI Class Initialized
DEBUG - 2017-06-19 18:00:17 --> No URI present. Default controller set.
INFO - 2017-06-19 18:00:17 --> Router Class Initialized
INFO - 2017-06-19 18:00:17 --> Output Class Initialized
INFO - 2017-06-19 18:00:17 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:17 --> Input Class Initialized
INFO - 2017-06-19 18:00:17 --> Language Class Initialized
INFO - 2017-06-19 18:00:17 --> Loader Class Initialized
INFO - 2017-06-19 18:00:17 --> Controller Class Initialized
INFO - 2017-06-19 18:00:17 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:17 --> Model Class Initialized
INFO - 2017-06-19 18:00:17 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:17 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-06-19 18:00:17 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:17 --> Total execution time: 0.0520
ERROR - 2017-06-19 18:00:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:19 --> Config Class Initialized
INFO - 2017-06-19 18:00:19 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:19 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:19 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:19 --> URI Class Initialized
INFO - 2017-06-19 18:00:19 --> Router Class Initialized
INFO - 2017-06-19 18:00:19 --> Output Class Initialized
INFO - 2017-06-19 18:00:19 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:19 --> Input Class Initialized
INFO - 2017-06-19 18:00:19 --> Language Class Initialized
INFO - 2017-06-19 18:00:19 --> Loader Class Initialized
INFO - 2017-06-19 18:00:19 --> Controller Class Initialized
INFO - 2017-06-19 18:00:19 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:19 --> Model Class Initialized
INFO - 2017-06-19 18:00:19 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:19 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:19 --> Model Class Initialized
ERROR - 2017-06-19 18:00:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:19 --> Config Class Initialized
INFO - 2017-06-19 18:00:19 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:19 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:19 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:19 --> URI Class Initialized
INFO - 2017-06-19 18:00:19 --> Router Class Initialized
INFO - 2017-06-19 18:00:19 --> Output Class Initialized
INFO - 2017-06-19 18:00:19 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:19 --> Input Class Initialized
INFO - 2017-06-19 18:00:19 --> Language Class Initialized
INFO - 2017-06-19 18:00:19 --> Loader Class Initialized
INFO - 2017-06-19 18:00:19 --> Controller Class Initialized
INFO - 2017-06-19 18:00:19 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:19 --> Model Class Initialized
INFO - 2017-06-19 18:00:19 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:19 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:19 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:00:19 --> Model Class Initialized
INFO - 2017-06-19 18:00:19 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-19 18:00:19 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:19 --> Total execution time: 0.0740
ERROR - 2017-06-19 18:00:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:22 --> Config Class Initialized
INFO - 2017-06-19 18:00:22 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:22 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:22 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:22 --> URI Class Initialized
INFO - 2017-06-19 18:00:22 --> Router Class Initialized
INFO - 2017-06-19 18:00:22 --> Output Class Initialized
INFO - 2017-06-19 18:00:22 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:22 --> Input Class Initialized
INFO - 2017-06-19 18:00:22 --> Language Class Initialized
INFO - 2017-06-19 18:00:22 --> Loader Class Initialized
INFO - 2017-06-19 18:00:22 --> Controller Class Initialized
INFO - 2017-06-19 18:00:22 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:22 --> Model Class Initialized
INFO - 2017-06-19 18:00:22 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:22 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:00:22 --> Model Class Initialized
INFO - 2017-06-19 18:00:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 18:00:22 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:22 --> Total execution time: 0.0580
ERROR - 2017-06-19 18:00:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:27 --> Config Class Initialized
INFO - 2017-06-19 18:00:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:27 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:27 --> URI Class Initialized
INFO - 2017-06-19 18:00:27 --> Router Class Initialized
INFO - 2017-06-19 18:00:27 --> Output Class Initialized
INFO - 2017-06-19 18:00:27 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:27 --> Input Class Initialized
INFO - 2017-06-19 18:00:27 --> Language Class Initialized
INFO - 2017-06-19 18:00:27 --> Loader Class Initialized
INFO - 2017-06-19 18:00:27 --> Controller Class Initialized
INFO - 2017-06-19 18:00:27 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:27 --> Model Class Initialized
INFO - 2017-06-19 18:00:27 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:27 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:27 --> Upload Class Initialized
INFO - 2017-06-19 18:00:27 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:27 --> Total execution time: 0.0530
ERROR - 2017-06-19 18:00:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:27 --> Config Class Initialized
INFO - 2017-06-19 18:00:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:27 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:27 --> URI Class Initialized
INFO - 2017-06-19 18:00:27 --> Router Class Initialized
INFO - 2017-06-19 18:00:27 --> Output Class Initialized
INFO - 2017-06-19 18:00:27 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:27 --> Input Class Initialized
INFO - 2017-06-19 18:00:27 --> Language Class Initialized
INFO - 2017-06-19 18:00:27 --> Loader Class Initialized
INFO - 2017-06-19 18:00:27 --> Controller Class Initialized
INFO - 2017-06-19 18:00:27 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:27 --> Model Class Initialized
INFO - 2017-06-19 18:00:27 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:27 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:27 --> Upload Class Initialized
INFO - 2017-06-19 18:00:27 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:27 --> Total execution time: 0.0630
ERROR - 2017-06-19 18:00:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:35 --> Config Class Initialized
INFO - 2017-06-19 18:00:35 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:35 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:35 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:35 --> URI Class Initialized
INFO - 2017-06-19 18:00:35 --> Router Class Initialized
INFO - 2017-06-19 18:00:35 --> Output Class Initialized
INFO - 2017-06-19 18:00:35 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:35 --> Input Class Initialized
INFO - 2017-06-19 18:00:35 --> Language Class Initialized
INFO - 2017-06-19 18:00:35 --> Loader Class Initialized
INFO - 2017-06-19 18:00:35 --> Controller Class Initialized
INFO - 2017-06-19 18:00:35 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:35 --> Model Class Initialized
INFO - 2017-06-19 18:00:35 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:35 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:35 --> Upload Class Initialized
INFO - 2017-06-19 18:00:35 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:35 --> Total execution time: 0.0500
ERROR - 2017-06-19 18:00:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:35 --> Config Class Initialized
INFO - 2017-06-19 18:00:35 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:35 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:35 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:35 --> URI Class Initialized
INFO - 2017-06-19 18:00:35 --> Router Class Initialized
INFO - 2017-06-19 18:00:35 --> Output Class Initialized
INFO - 2017-06-19 18:00:35 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:35 --> Input Class Initialized
INFO - 2017-06-19 18:00:35 --> Language Class Initialized
INFO - 2017-06-19 18:00:35 --> Loader Class Initialized
INFO - 2017-06-19 18:00:35 --> Controller Class Initialized
INFO - 2017-06-19 18:00:35 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:35 --> Model Class Initialized
INFO - 2017-06-19 18:00:35 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:35 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:35 --> Upload Class Initialized
INFO - 2017-06-19 18:00:35 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:35 --> Total execution time: 0.0600
ERROR - 2017-06-19 18:00:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:36 --> Config Class Initialized
INFO - 2017-06-19 18:00:36 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:36 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:36 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:36 --> URI Class Initialized
INFO - 2017-06-19 18:00:36 --> Router Class Initialized
INFO - 2017-06-19 18:00:36 --> Output Class Initialized
INFO - 2017-06-19 18:00:36 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:36 --> Input Class Initialized
INFO - 2017-06-19 18:00:36 --> Language Class Initialized
INFO - 2017-06-19 18:00:36 --> Loader Class Initialized
INFO - 2017-06-19 18:00:36 --> Controller Class Initialized
INFO - 2017-06-19 18:00:36 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:36 --> Model Class Initialized
INFO - 2017-06-19 18:00:36 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:36 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:36 --> Upload Class Initialized
INFO - 2017-06-19 18:00:36 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:36 --> Total execution time: 0.0610
ERROR - 2017-06-19 18:00:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:36 --> Config Class Initialized
INFO - 2017-06-19 18:00:36 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:36 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:36 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:36 --> URI Class Initialized
INFO - 2017-06-19 18:00:36 --> Router Class Initialized
INFO - 2017-06-19 18:00:36 --> Output Class Initialized
INFO - 2017-06-19 18:00:36 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:36 --> Input Class Initialized
INFO - 2017-06-19 18:00:36 --> Language Class Initialized
INFO - 2017-06-19 18:00:36 --> Loader Class Initialized
INFO - 2017-06-19 18:00:36 --> Controller Class Initialized
INFO - 2017-06-19 18:00:36 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:36 --> Model Class Initialized
INFO - 2017-06-19 18:00:36 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:36 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:36 --> Upload Class Initialized
INFO - 2017-06-19 18:00:36 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:36 --> Total execution time: 0.0490
ERROR - 2017-06-19 18:00:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:36 --> Config Class Initialized
INFO - 2017-06-19 18:00:36 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:36 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:36 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:36 --> URI Class Initialized
INFO - 2017-06-19 18:00:36 --> Router Class Initialized
INFO - 2017-06-19 18:00:36 --> Output Class Initialized
INFO - 2017-06-19 18:00:36 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:36 --> Input Class Initialized
INFO - 2017-06-19 18:00:36 --> Language Class Initialized
INFO - 2017-06-19 18:00:36 --> Loader Class Initialized
INFO - 2017-06-19 18:00:36 --> Controller Class Initialized
INFO - 2017-06-19 18:00:36 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:36 --> Model Class Initialized
INFO - 2017-06-19 18:00:36 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:36 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:36 --> Upload Class Initialized
INFO - 2017-06-19 18:00:36 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:36 --> Total execution time: 0.0570
ERROR - 2017-06-19 18:00:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:36 --> Config Class Initialized
INFO - 2017-06-19 18:00:36 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:36 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:36 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:36 --> URI Class Initialized
INFO - 2017-06-19 18:00:36 --> Router Class Initialized
INFO - 2017-06-19 18:00:36 --> Output Class Initialized
INFO - 2017-06-19 18:00:36 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:36 --> Input Class Initialized
INFO - 2017-06-19 18:00:36 --> Language Class Initialized
INFO - 2017-06-19 18:00:36 --> Loader Class Initialized
INFO - 2017-06-19 18:00:36 --> Controller Class Initialized
INFO - 2017-06-19 18:00:36 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:36 --> Model Class Initialized
INFO - 2017-06-19 18:00:36 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:36 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:36 --> Upload Class Initialized
INFO - 2017-06-19 18:00:36 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:36 --> Total execution time: 0.0470
ERROR - 2017-06-19 18:00:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:36 --> Config Class Initialized
INFO - 2017-06-19 18:00:36 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:36 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:37 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:37 --> URI Class Initialized
INFO - 2017-06-19 18:00:37 --> Router Class Initialized
INFO - 2017-06-19 18:00:37 --> Output Class Initialized
INFO - 2017-06-19 18:00:37 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:37 --> Input Class Initialized
INFO - 2017-06-19 18:00:37 --> Language Class Initialized
INFO - 2017-06-19 18:00:37 --> Loader Class Initialized
INFO - 2017-06-19 18:00:37 --> Controller Class Initialized
INFO - 2017-06-19 18:00:37 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:37 --> Model Class Initialized
INFO - 2017-06-19 18:00:37 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:37 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:37 --> Upload Class Initialized
INFO - 2017-06-19 18:00:37 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:37 --> Total execution time: 0.2710
ERROR - 2017-06-19 18:00:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:37 --> Config Class Initialized
INFO - 2017-06-19 18:00:37 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:37 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:37 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:37 --> URI Class Initialized
INFO - 2017-06-19 18:00:37 --> Router Class Initialized
INFO - 2017-06-19 18:00:37 --> Output Class Initialized
INFO - 2017-06-19 18:00:37 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:37 --> Input Class Initialized
INFO - 2017-06-19 18:00:37 --> Language Class Initialized
INFO - 2017-06-19 18:00:37 --> Loader Class Initialized
INFO - 2017-06-19 18:00:37 --> Controller Class Initialized
INFO - 2017-06-19 18:00:37 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:37 --> Model Class Initialized
INFO - 2017-06-19 18:00:37 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:37 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:37 --> Upload Class Initialized
INFO - 2017-06-19 18:00:37 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:37 --> Total execution time: 0.0470
ERROR - 2017-06-19 18:00:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:37 --> Config Class Initialized
INFO - 2017-06-19 18:00:37 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:37 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:37 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:37 --> URI Class Initialized
INFO - 2017-06-19 18:00:37 --> Router Class Initialized
INFO - 2017-06-19 18:00:37 --> Output Class Initialized
INFO - 2017-06-19 18:00:37 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:37 --> Input Class Initialized
INFO - 2017-06-19 18:00:37 --> Language Class Initialized
INFO - 2017-06-19 18:00:37 --> Loader Class Initialized
INFO - 2017-06-19 18:00:37 --> Controller Class Initialized
INFO - 2017-06-19 18:00:37 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:37 --> Model Class Initialized
INFO - 2017-06-19 18:00:37 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:37 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:37 --> Upload Class Initialized
INFO - 2017-06-19 18:00:37 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:37 --> Total execution time: 0.0560
ERROR - 2017-06-19 18:00:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:38 --> Config Class Initialized
INFO - 2017-06-19 18:00:38 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:38 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:38 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:38 --> URI Class Initialized
INFO - 2017-06-19 18:00:38 --> Router Class Initialized
INFO - 2017-06-19 18:00:38 --> Output Class Initialized
INFO - 2017-06-19 18:00:38 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:38 --> Input Class Initialized
INFO - 2017-06-19 18:00:38 --> Language Class Initialized
INFO - 2017-06-19 18:00:38 --> Loader Class Initialized
INFO - 2017-06-19 18:00:38 --> Controller Class Initialized
INFO - 2017-06-19 18:00:38 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:38 --> Model Class Initialized
INFO - 2017-06-19 18:00:38 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:38 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:38 --> Upload Class Initialized
INFO - 2017-06-19 18:00:38 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:38 --> Total execution time: 0.0480
ERROR - 2017-06-19 18:00:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:38 --> Config Class Initialized
INFO - 2017-06-19 18:00:38 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:38 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:38 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:38 --> URI Class Initialized
INFO - 2017-06-19 18:00:38 --> Router Class Initialized
INFO - 2017-06-19 18:00:38 --> Output Class Initialized
INFO - 2017-06-19 18:00:38 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:38 --> Input Class Initialized
INFO - 2017-06-19 18:00:38 --> Language Class Initialized
INFO - 2017-06-19 18:00:38 --> Loader Class Initialized
INFO - 2017-06-19 18:00:38 --> Controller Class Initialized
INFO - 2017-06-19 18:00:38 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:38 --> Model Class Initialized
INFO - 2017-06-19 18:00:38 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:38 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:38 --> Upload Class Initialized
INFO - 2017-06-19 18:00:38 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:38 --> Total execution time: 0.0570
ERROR - 2017-06-19 18:00:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:38 --> Config Class Initialized
INFO - 2017-06-19 18:00:38 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:38 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:38 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:38 --> URI Class Initialized
INFO - 2017-06-19 18:00:38 --> Router Class Initialized
INFO - 2017-06-19 18:00:38 --> Output Class Initialized
INFO - 2017-06-19 18:00:38 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:38 --> Input Class Initialized
INFO - 2017-06-19 18:00:38 --> Language Class Initialized
INFO - 2017-06-19 18:00:38 --> Loader Class Initialized
INFO - 2017-06-19 18:00:38 --> Controller Class Initialized
INFO - 2017-06-19 18:00:38 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:38 --> Model Class Initialized
INFO - 2017-06-19 18:00:38 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:38 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:38 --> Upload Class Initialized
INFO - 2017-06-19 18:00:38 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:38 --> Total execution time: 0.0470
ERROR - 2017-06-19 18:00:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:39 --> Config Class Initialized
INFO - 2017-06-19 18:00:39 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:39 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:39 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:39 --> URI Class Initialized
INFO - 2017-06-19 18:00:39 --> Router Class Initialized
INFO - 2017-06-19 18:00:39 --> Output Class Initialized
INFO - 2017-06-19 18:00:39 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:39 --> Input Class Initialized
INFO - 2017-06-19 18:00:39 --> Language Class Initialized
INFO - 2017-06-19 18:00:39 --> Loader Class Initialized
INFO - 2017-06-19 18:00:39 --> Controller Class Initialized
INFO - 2017-06-19 18:00:39 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:39 --> Model Class Initialized
INFO - 2017-06-19 18:00:39 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:39 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:39 --> Upload Class Initialized
INFO - 2017-06-19 18:00:39 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:39 --> Total execution time: 0.0470
ERROR - 2017-06-19 18:00:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:39 --> Config Class Initialized
INFO - 2017-06-19 18:00:39 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:39 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:39 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:39 --> URI Class Initialized
INFO - 2017-06-19 18:00:39 --> Router Class Initialized
INFO - 2017-06-19 18:00:39 --> Output Class Initialized
INFO - 2017-06-19 18:00:39 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:39 --> Input Class Initialized
INFO - 2017-06-19 18:00:39 --> Language Class Initialized
INFO - 2017-06-19 18:00:39 --> Loader Class Initialized
INFO - 2017-06-19 18:00:39 --> Controller Class Initialized
INFO - 2017-06-19 18:00:39 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:39 --> Model Class Initialized
INFO - 2017-06-19 18:00:39 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:39 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:39 --> Upload Class Initialized
INFO - 2017-06-19 18:00:39 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:39 --> Total execution time: 0.0490
ERROR - 2017-06-19 18:00:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:00:40 --> Config Class Initialized
INFO - 2017-06-19 18:00:40 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:00:40 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:00:40 --> Utf8 Class Initialized
INFO - 2017-06-19 18:00:40 --> URI Class Initialized
INFO - 2017-06-19 18:00:40 --> Router Class Initialized
INFO - 2017-06-19 18:00:40 --> Output Class Initialized
INFO - 2017-06-19 18:00:40 --> Security Class Initialized
DEBUG - 2017-06-19 18:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:00:40 --> Input Class Initialized
INFO - 2017-06-19 18:00:40 --> Language Class Initialized
INFO - 2017-06-19 18:00:40 --> Loader Class Initialized
INFO - 2017-06-19 18:00:40 --> Controller Class Initialized
INFO - 2017-06-19 18:00:40 --> Database Driver Class Initialized
INFO - 2017-06-19 18:00:40 --> Model Class Initialized
INFO - 2017-06-19 18:00:40 --> Helper loaded: form_helper
INFO - 2017-06-19 18:00:40 --> Helper loaded: url_helper
INFO - 2017-06-19 18:00:40 --> Upload Class Initialized
INFO - 2017-06-19 18:00:40 --> Final output sent to browser
DEBUG - 2017-06-19 18:00:40 --> Total execution time: 0.0490
ERROR - 2017-06-19 18:09:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:09:37 --> Config Class Initialized
INFO - 2017-06-19 18:09:37 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:09:37 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:09:37 --> Utf8 Class Initialized
INFO - 2017-06-19 18:09:37 --> URI Class Initialized
DEBUG - 2017-06-19 18:09:37 --> No URI present. Default controller set.
INFO - 2017-06-19 18:09:37 --> Router Class Initialized
INFO - 2017-06-19 18:09:37 --> Output Class Initialized
INFO - 2017-06-19 18:09:37 --> Security Class Initialized
DEBUG - 2017-06-19 18:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:09:37 --> Input Class Initialized
INFO - 2017-06-19 18:09:37 --> Language Class Initialized
INFO - 2017-06-19 18:09:37 --> Loader Class Initialized
INFO - 2017-06-19 18:09:37 --> Controller Class Initialized
INFO - 2017-06-19 18:09:37 --> Database Driver Class Initialized
INFO - 2017-06-19 18:09:37 --> Model Class Initialized
INFO - 2017-06-19 18:09:37 --> Helper loaded: form_helper
INFO - 2017-06-19 18:09:37 --> Helper loaded: url_helper
INFO - 2017-06-19 18:09:37 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-06-19 18:09:37 --> Final output sent to browser
DEBUG - 2017-06-19 18:09:37 --> Total execution time: 0.0610
ERROR - 2017-06-19 18:09:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:09:38 --> Config Class Initialized
INFO - 2017-06-19 18:09:38 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:09:38 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:09:38 --> Utf8 Class Initialized
INFO - 2017-06-19 18:09:38 --> URI Class Initialized
INFO - 2017-06-19 18:09:38 --> Router Class Initialized
INFO - 2017-06-19 18:09:38 --> Output Class Initialized
INFO - 2017-06-19 18:09:38 --> Security Class Initialized
DEBUG - 2017-06-19 18:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:09:38 --> Input Class Initialized
INFO - 2017-06-19 18:09:38 --> Language Class Initialized
INFO - 2017-06-19 18:09:38 --> Loader Class Initialized
INFO - 2017-06-19 18:09:38 --> Controller Class Initialized
INFO - 2017-06-19 18:09:38 --> Database Driver Class Initialized
INFO - 2017-06-19 18:09:38 --> Model Class Initialized
INFO - 2017-06-19 18:09:38 --> Helper loaded: form_helper
INFO - 2017-06-19 18:09:38 --> Helper loaded: url_helper
INFO - 2017-06-19 18:09:38 --> Model Class Initialized
ERROR - 2017-06-19 18:09:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:09:38 --> Config Class Initialized
INFO - 2017-06-19 18:09:38 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:09:38 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:09:38 --> Utf8 Class Initialized
INFO - 2017-06-19 18:09:38 --> URI Class Initialized
INFO - 2017-06-19 18:09:38 --> Router Class Initialized
INFO - 2017-06-19 18:09:38 --> Output Class Initialized
INFO - 2017-06-19 18:09:38 --> Security Class Initialized
DEBUG - 2017-06-19 18:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:09:38 --> Input Class Initialized
INFO - 2017-06-19 18:09:38 --> Language Class Initialized
INFO - 2017-06-19 18:09:38 --> Loader Class Initialized
INFO - 2017-06-19 18:09:38 --> Controller Class Initialized
INFO - 2017-06-19 18:09:38 --> Database Driver Class Initialized
INFO - 2017-06-19 18:09:38 --> Model Class Initialized
INFO - 2017-06-19 18:09:38 --> Helper loaded: form_helper
INFO - 2017-06-19 18:09:38 --> Helper loaded: url_helper
INFO - 2017-06-19 18:09:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:09:38 --> Model Class Initialized
INFO - 2017-06-19 18:09:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-19 18:09:38 --> Final output sent to browser
DEBUG - 2017-06-19 18:09:38 --> Total execution time: 0.0680
ERROR - 2017-06-19 18:09:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:09:43 --> Config Class Initialized
INFO - 2017-06-19 18:09:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:09:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:09:43 --> Utf8 Class Initialized
INFO - 2017-06-19 18:09:43 --> URI Class Initialized
INFO - 2017-06-19 18:09:43 --> Router Class Initialized
INFO - 2017-06-19 18:09:43 --> Output Class Initialized
INFO - 2017-06-19 18:09:43 --> Security Class Initialized
DEBUG - 2017-06-19 18:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:09:43 --> Input Class Initialized
INFO - 2017-06-19 18:09:43 --> Language Class Initialized
INFO - 2017-06-19 18:09:43 --> Loader Class Initialized
INFO - 2017-06-19 18:09:43 --> Controller Class Initialized
INFO - 2017-06-19 18:09:43 --> Database Driver Class Initialized
INFO - 2017-06-19 18:09:43 --> Model Class Initialized
INFO - 2017-06-19 18:09:43 --> Helper loaded: form_helper
INFO - 2017-06-19 18:09:43 --> Helper loaded: url_helper
INFO - 2017-06-19 18:09:43 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:09:43 --> Model Class Initialized
INFO - 2017-06-19 18:09:43 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 18:09:43 --> Final output sent to browser
DEBUG - 2017-06-19 18:09:43 --> Total execution time: 0.1090
ERROR - 2017-06-19 18:10:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:10:17 --> Config Class Initialized
INFO - 2017-06-19 18:10:17 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:10:17 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:10:17 --> Utf8 Class Initialized
INFO - 2017-06-19 18:10:17 --> URI Class Initialized
INFO - 2017-06-19 18:10:17 --> Router Class Initialized
INFO - 2017-06-19 18:10:17 --> Output Class Initialized
INFO - 2017-06-19 18:10:17 --> Security Class Initialized
DEBUG - 2017-06-19 18:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:10:17 --> Input Class Initialized
INFO - 2017-06-19 18:10:17 --> Language Class Initialized
INFO - 2017-06-19 18:10:17 --> Loader Class Initialized
INFO - 2017-06-19 18:10:17 --> Controller Class Initialized
INFO - 2017-06-19 18:10:17 --> Database Driver Class Initialized
INFO - 2017-06-19 18:10:17 --> Model Class Initialized
INFO - 2017-06-19 18:10:17 --> Helper loaded: form_helper
INFO - 2017-06-19 18:10:17 --> Helper loaded: url_helper
INFO - 2017-06-19 18:10:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:10:17 --> Model Class Initialized
INFO - 2017-06-19 18:10:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 18:10:17 --> Final output sent to browser
DEBUG - 2017-06-19 18:10:17 --> Total execution time: 0.0490
ERROR - 2017-06-19 18:12:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:12:11 --> Config Class Initialized
INFO - 2017-06-19 18:12:11 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:12:11 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:12:11 --> Utf8 Class Initialized
INFO - 2017-06-19 18:12:11 --> URI Class Initialized
INFO - 2017-06-19 18:12:11 --> Router Class Initialized
INFO - 2017-06-19 18:12:11 --> Output Class Initialized
INFO - 2017-06-19 18:12:11 --> Security Class Initialized
DEBUG - 2017-06-19 18:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:12:11 --> Input Class Initialized
INFO - 2017-06-19 18:12:11 --> Language Class Initialized
INFO - 2017-06-19 18:12:11 --> Loader Class Initialized
INFO - 2017-06-19 18:12:11 --> Controller Class Initialized
INFO - 2017-06-19 18:12:11 --> Database Driver Class Initialized
INFO - 2017-06-19 18:12:11 --> Model Class Initialized
INFO - 2017-06-19 18:12:11 --> Helper loaded: form_helper
INFO - 2017-06-19 18:12:11 --> Helper loaded: url_helper
INFO - 2017-06-19 18:12:11 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:12:11 --> Model Class Initialized
INFO - 2017-06-19 18:12:11 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 18:12:11 --> Final output sent to browser
DEBUG - 2017-06-19 18:12:11 --> Total execution time: 0.0680
ERROR - 2017-06-19 18:12:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:12:32 --> Config Class Initialized
INFO - 2017-06-19 18:12:32 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:12:32 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:12:32 --> Utf8 Class Initialized
INFO - 2017-06-19 18:12:32 --> URI Class Initialized
INFO - 2017-06-19 18:12:32 --> Router Class Initialized
INFO - 2017-06-19 18:12:32 --> Output Class Initialized
INFO - 2017-06-19 18:12:32 --> Security Class Initialized
DEBUG - 2017-06-19 18:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:12:32 --> Input Class Initialized
INFO - 2017-06-19 18:12:32 --> Language Class Initialized
INFO - 2017-06-19 18:12:32 --> Loader Class Initialized
INFO - 2017-06-19 18:12:32 --> Controller Class Initialized
INFO - 2017-06-19 18:12:32 --> Database Driver Class Initialized
INFO - 2017-06-19 18:12:32 --> Model Class Initialized
INFO - 2017-06-19 18:12:32 --> Helper loaded: form_helper
INFO - 2017-06-19 18:12:32 --> Helper loaded: url_helper
INFO - 2017-06-19 18:12:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:12:32 --> Model Class Initialized
INFO - 2017-06-19 18:12:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 18:12:32 --> Final output sent to browser
DEBUG - 2017-06-19 18:12:32 --> Total execution time: 0.0755
ERROR - 2017-06-19 18:13:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:17 --> Config Class Initialized
INFO - 2017-06-19 18:13:17 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:17 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:17 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:17 --> URI Class Initialized
INFO - 2017-06-19 18:13:17 --> Router Class Initialized
INFO - 2017-06-19 18:13:17 --> Output Class Initialized
INFO - 2017-06-19 18:13:17 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:17 --> Input Class Initialized
INFO - 2017-06-19 18:13:17 --> Language Class Initialized
INFO - 2017-06-19 18:13:17 --> Loader Class Initialized
INFO - 2017-06-19 18:13:17 --> Controller Class Initialized
INFO - 2017-06-19 18:13:17 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:17 --> Model Class Initialized
INFO - 2017-06-19 18:13:17 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:17 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:13:17 --> Model Class Initialized
INFO - 2017-06-19 18:13:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 18:13:17 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:17 --> Total execution time: 0.0790
ERROR - 2017-06-19 18:13:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:20 --> Config Class Initialized
INFO - 2017-06-19 18:13:20 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:20 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:20 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:20 --> URI Class Initialized
INFO - 2017-06-19 18:13:20 --> Router Class Initialized
INFO - 2017-06-19 18:13:20 --> Output Class Initialized
INFO - 2017-06-19 18:13:20 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:20 --> Input Class Initialized
INFO - 2017-06-19 18:13:20 --> Language Class Initialized
INFO - 2017-06-19 18:13:20 --> Loader Class Initialized
INFO - 2017-06-19 18:13:20 --> Controller Class Initialized
INFO - 2017-06-19 18:13:20 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:20 --> Model Class Initialized
INFO - 2017-06-19 18:13:20 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:20 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:20 --> Upload Class Initialized
INFO - 2017-06-19 18:13:20 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:20 --> Total execution time: 0.0595
ERROR - 2017-06-19 18:13:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:27 --> Config Class Initialized
INFO - 2017-06-19 18:13:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:27 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:27 --> URI Class Initialized
INFO - 2017-06-19 18:13:27 --> Router Class Initialized
INFO - 2017-06-19 18:13:27 --> Output Class Initialized
INFO - 2017-06-19 18:13:27 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:27 --> Input Class Initialized
INFO - 2017-06-19 18:13:27 --> Language Class Initialized
INFO - 2017-06-19 18:13:27 --> Loader Class Initialized
INFO - 2017-06-19 18:13:27 --> Controller Class Initialized
INFO - 2017-06-19 18:13:27 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:27 --> Model Class Initialized
INFO - 2017-06-19 18:13:27 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:27 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:27 --> Upload Class Initialized
INFO - 2017-06-19 18:13:27 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:27 --> Total execution time: 0.0580
ERROR - 2017-06-19 18:13:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:27 --> Config Class Initialized
INFO - 2017-06-19 18:13:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:27 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:27 --> URI Class Initialized
INFO - 2017-06-19 18:13:27 --> Router Class Initialized
INFO - 2017-06-19 18:13:27 --> Output Class Initialized
INFO - 2017-06-19 18:13:27 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:27 --> Input Class Initialized
INFO - 2017-06-19 18:13:27 --> Language Class Initialized
INFO - 2017-06-19 18:13:27 --> Loader Class Initialized
INFO - 2017-06-19 18:13:27 --> Controller Class Initialized
INFO - 2017-06-19 18:13:27 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:27 --> Model Class Initialized
INFO - 2017-06-19 18:13:27 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:27 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:27 --> Upload Class Initialized
INFO - 2017-06-19 18:13:27 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:27 --> Total execution time: 0.0555
ERROR - 2017-06-19 18:13:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:36 --> Config Class Initialized
INFO - 2017-06-19 18:13:36 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:36 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:36 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:36 --> URI Class Initialized
INFO - 2017-06-19 18:13:36 --> Router Class Initialized
INFO - 2017-06-19 18:13:36 --> Output Class Initialized
INFO - 2017-06-19 18:13:36 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:36 --> Input Class Initialized
INFO - 2017-06-19 18:13:36 --> Language Class Initialized
INFO - 2017-06-19 18:13:36 --> Loader Class Initialized
INFO - 2017-06-19 18:13:36 --> Controller Class Initialized
INFO - 2017-06-19 18:13:36 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:36 --> Model Class Initialized
INFO - 2017-06-19 18:13:36 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:36 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:36 --> Upload Class Initialized
INFO - 2017-06-19 18:13:36 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:36 --> Total execution time: 0.0490
ERROR - 2017-06-19 18:13:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:36 --> Config Class Initialized
INFO - 2017-06-19 18:13:36 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:36 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:36 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:36 --> URI Class Initialized
INFO - 2017-06-19 18:13:36 --> Router Class Initialized
INFO - 2017-06-19 18:13:36 --> Output Class Initialized
INFO - 2017-06-19 18:13:36 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:36 --> Input Class Initialized
INFO - 2017-06-19 18:13:36 --> Language Class Initialized
INFO - 2017-06-19 18:13:36 --> Loader Class Initialized
INFO - 2017-06-19 18:13:36 --> Controller Class Initialized
INFO - 2017-06-19 18:13:36 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:36 --> Model Class Initialized
INFO - 2017-06-19 18:13:36 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:36 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:36 --> Upload Class Initialized
INFO - 2017-06-19 18:13:36 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:36 --> Total execution time: 0.0500
ERROR - 2017-06-19 18:13:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:36 --> Config Class Initialized
INFO - 2017-06-19 18:13:36 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:36 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:36 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:36 --> URI Class Initialized
INFO - 2017-06-19 18:13:36 --> Router Class Initialized
INFO - 2017-06-19 18:13:36 --> Output Class Initialized
INFO - 2017-06-19 18:13:36 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:36 --> Input Class Initialized
INFO - 2017-06-19 18:13:36 --> Language Class Initialized
INFO - 2017-06-19 18:13:36 --> Loader Class Initialized
INFO - 2017-06-19 18:13:36 --> Controller Class Initialized
INFO - 2017-06-19 18:13:36 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:36 --> Model Class Initialized
INFO - 2017-06-19 18:13:36 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:36 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:36 --> Upload Class Initialized
INFO - 2017-06-19 18:13:36 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:36 --> Total execution time: 0.0600
ERROR - 2017-06-19 18:13:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:37 --> Config Class Initialized
INFO - 2017-06-19 18:13:37 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:37 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:37 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:37 --> URI Class Initialized
INFO - 2017-06-19 18:13:37 --> Router Class Initialized
INFO - 2017-06-19 18:13:37 --> Output Class Initialized
INFO - 2017-06-19 18:13:37 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:37 --> Input Class Initialized
INFO - 2017-06-19 18:13:37 --> Language Class Initialized
INFO - 2017-06-19 18:13:37 --> Loader Class Initialized
INFO - 2017-06-19 18:13:37 --> Controller Class Initialized
INFO - 2017-06-19 18:13:37 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:37 --> Model Class Initialized
INFO - 2017-06-19 18:13:37 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:37 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:37 --> Upload Class Initialized
INFO - 2017-06-19 18:13:37 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:37 --> Total execution time: 0.0510
ERROR - 2017-06-19 18:13:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:37 --> Config Class Initialized
INFO - 2017-06-19 18:13:37 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:37 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:37 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:37 --> URI Class Initialized
INFO - 2017-06-19 18:13:37 --> Router Class Initialized
INFO - 2017-06-19 18:13:37 --> Output Class Initialized
INFO - 2017-06-19 18:13:37 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:37 --> Input Class Initialized
INFO - 2017-06-19 18:13:37 --> Language Class Initialized
INFO - 2017-06-19 18:13:37 --> Loader Class Initialized
INFO - 2017-06-19 18:13:37 --> Controller Class Initialized
INFO - 2017-06-19 18:13:37 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:37 --> Model Class Initialized
INFO - 2017-06-19 18:13:37 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:37 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:37 --> Upload Class Initialized
INFO - 2017-06-19 18:13:37 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:37 --> Total execution time: 0.0500
ERROR - 2017-06-19 18:13:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:37 --> Config Class Initialized
INFO - 2017-06-19 18:13:37 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:37 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:37 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:37 --> URI Class Initialized
INFO - 2017-06-19 18:13:37 --> Router Class Initialized
INFO - 2017-06-19 18:13:37 --> Output Class Initialized
INFO - 2017-06-19 18:13:37 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:37 --> Input Class Initialized
INFO - 2017-06-19 18:13:37 --> Language Class Initialized
INFO - 2017-06-19 18:13:37 --> Loader Class Initialized
INFO - 2017-06-19 18:13:37 --> Controller Class Initialized
INFO - 2017-06-19 18:13:37 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:37 --> Model Class Initialized
INFO - 2017-06-19 18:13:37 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:37 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:37 --> Upload Class Initialized
INFO - 2017-06-19 18:13:37 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:37 --> Total execution time: 0.0500
ERROR - 2017-06-19 18:13:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:37 --> Config Class Initialized
INFO - 2017-06-19 18:13:37 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:37 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:37 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:37 --> URI Class Initialized
INFO - 2017-06-19 18:13:37 --> Router Class Initialized
INFO - 2017-06-19 18:13:37 --> Output Class Initialized
INFO - 2017-06-19 18:13:37 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:37 --> Input Class Initialized
INFO - 2017-06-19 18:13:37 --> Language Class Initialized
INFO - 2017-06-19 18:13:37 --> Loader Class Initialized
INFO - 2017-06-19 18:13:37 --> Controller Class Initialized
INFO - 2017-06-19 18:13:37 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:37 --> Model Class Initialized
INFO - 2017-06-19 18:13:37 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:37 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:37 --> Upload Class Initialized
INFO - 2017-06-19 18:13:37 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:37 --> Total execution time: 0.0520
ERROR - 2017-06-19 18:13:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:37 --> Config Class Initialized
INFO - 2017-06-19 18:13:37 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:37 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:37 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:37 --> URI Class Initialized
INFO - 2017-06-19 18:13:37 --> Router Class Initialized
INFO - 2017-06-19 18:13:37 --> Output Class Initialized
INFO - 2017-06-19 18:13:37 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:37 --> Input Class Initialized
INFO - 2017-06-19 18:13:37 --> Language Class Initialized
INFO - 2017-06-19 18:13:37 --> Loader Class Initialized
INFO - 2017-06-19 18:13:37 --> Controller Class Initialized
INFO - 2017-06-19 18:13:37 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:37 --> Model Class Initialized
INFO - 2017-06-19 18:13:37 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:37 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:37 --> Upload Class Initialized
INFO - 2017-06-19 18:13:37 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:37 --> Total execution time: 0.0500
ERROR - 2017-06-19 18:13:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:52 --> Config Class Initialized
INFO - 2017-06-19 18:13:52 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:52 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:52 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:52 --> URI Class Initialized
INFO - 2017-06-19 18:13:52 --> Router Class Initialized
INFO - 2017-06-19 18:13:52 --> Output Class Initialized
INFO - 2017-06-19 18:13:52 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:52 --> Input Class Initialized
INFO - 2017-06-19 18:13:52 --> Language Class Initialized
INFO - 2017-06-19 18:13:52 --> Loader Class Initialized
INFO - 2017-06-19 18:13:52 --> Controller Class Initialized
INFO - 2017-06-19 18:13:52 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:52 --> Model Class Initialized
INFO - 2017-06-19 18:13:52 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:52 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:52 --> Upload Class Initialized
INFO - 2017-06-19 18:13:52 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:52 --> Total execution time: 0.0760
ERROR - 2017-06-19 18:13:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:52 --> Config Class Initialized
INFO - 2017-06-19 18:13:52 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:52 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:52 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:52 --> URI Class Initialized
INFO - 2017-06-19 18:13:52 --> Router Class Initialized
INFO - 2017-06-19 18:13:52 --> Output Class Initialized
INFO - 2017-06-19 18:13:52 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:52 --> Input Class Initialized
INFO - 2017-06-19 18:13:52 --> Language Class Initialized
INFO - 2017-06-19 18:13:52 --> Loader Class Initialized
INFO - 2017-06-19 18:13:52 --> Controller Class Initialized
INFO - 2017-06-19 18:13:52 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:52 --> Model Class Initialized
INFO - 2017-06-19 18:13:52 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:52 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:52 --> Upload Class Initialized
INFO - 2017-06-19 18:13:52 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:52 --> Total execution time: 0.0530
ERROR - 2017-06-19 18:13:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:52 --> Config Class Initialized
INFO - 2017-06-19 18:13:52 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:52 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:52 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:52 --> URI Class Initialized
INFO - 2017-06-19 18:13:52 --> Router Class Initialized
INFO - 2017-06-19 18:13:52 --> Output Class Initialized
INFO - 2017-06-19 18:13:52 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:52 --> Input Class Initialized
INFO - 2017-06-19 18:13:52 --> Language Class Initialized
INFO - 2017-06-19 18:13:52 --> Loader Class Initialized
INFO - 2017-06-19 18:13:52 --> Controller Class Initialized
INFO - 2017-06-19 18:13:52 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:52 --> Model Class Initialized
INFO - 2017-06-19 18:13:52 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:52 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:52 --> Upload Class Initialized
INFO - 2017-06-19 18:13:52 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:52 --> Total execution time: 0.0640
ERROR - 2017-06-19 18:13:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:53 --> Config Class Initialized
INFO - 2017-06-19 18:13:53 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:53 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:53 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:53 --> URI Class Initialized
INFO - 2017-06-19 18:13:53 --> Router Class Initialized
INFO - 2017-06-19 18:13:53 --> Output Class Initialized
INFO - 2017-06-19 18:13:53 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:53 --> Input Class Initialized
INFO - 2017-06-19 18:13:53 --> Language Class Initialized
INFO - 2017-06-19 18:13:53 --> Loader Class Initialized
INFO - 2017-06-19 18:13:53 --> Controller Class Initialized
INFO - 2017-06-19 18:13:53 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:53 --> Model Class Initialized
INFO - 2017-06-19 18:13:53 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:53 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:53 --> Upload Class Initialized
INFO - 2017-06-19 18:13:53 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:53 --> Total execution time: 0.0720
ERROR - 2017-06-19 18:13:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:53 --> Config Class Initialized
INFO - 2017-06-19 18:13:53 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:53 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:53 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:53 --> URI Class Initialized
INFO - 2017-06-19 18:13:53 --> Router Class Initialized
INFO - 2017-06-19 18:13:53 --> Output Class Initialized
INFO - 2017-06-19 18:13:53 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:53 --> Input Class Initialized
INFO - 2017-06-19 18:13:53 --> Language Class Initialized
INFO - 2017-06-19 18:13:53 --> Loader Class Initialized
INFO - 2017-06-19 18:13:53 --> Controller Class Initialized
INFO - 2017-06-19 18:13:53 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:53 --> Model Class Initialized
INFO - 2017-06-19 18:13:53 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:53 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:53 --> Upload Class Initialized
INFO - 2017-06-19 18:13:53 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:53 --> Total execution time: 0.0620
ERROR - 2017-06-19 18:13:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:53 --> Config Class Initialized
INFO - 2017-06-19 18:13:53 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:53 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:53 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:53 --> URI Class Initialized
INFO - 2017-06-19 18:13:53 --> Router Class Initialized
INFO - 2017-06-19 18:13:53 --> Output Class Initialized
INFO - 2017-06-19 18:13:53 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:53 --> Input Class Initialized
INFO - 2017-06-19 18:13:53 --> Language Class Initialized
INFO - 2017-06-19 18:13:53 --> Loader Class Initialized
INFO - 2017-06-19 18:13:53 --> Controller Class Initialized
INFO - 2017-06-19 18:13:53 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:53 --> Model Class Initialized
INFO - 2017-06-19 18:13:53 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:53 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:53 --> Upload Class Initialized
INFO - 2017-06-19 18:13:53 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:53 --> Total execution time: 0.0490
ERROR - 2017-06-19 18:13:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:53 --> Config Class Initialized
INFO - 2017-06-19 18:13:53 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:53 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:53 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:53 --> URI Class Initialized
INFO - 2017-06-19 18:13:53 --> Router Class Initialized
INFO - 2017-06-19 18:13:53 --> Output Class Initialized
INFO - 2017-06-19 18:13:53 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:53 --> Input Class Initialized
INFO - 2017-06-19 18:13:53 --> Language Class Initialized
INFO - 2017-06-19 18:13:53 --> Loader Class Initialized
INFO - 2017-06-19 18:13:53 --> Controller Class Initialized
INFO - 2017-06-19 18:13:53 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:53 --> Model Class Initialized
INFO - 2017-06-19 18:13:53 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:53 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:53 --> Upload Class Initialized
INFO - 2017-06-19 18:13:53 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:53 --> Total execution time: 0.0500
ERROR - 2017-06-19 18:13:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:13:53 --> Config Class Initialized
INFO - 2017-06-19 18:13:53 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:13:53 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:13:53 --> Utf8 Class Initialized
INFO - 2017-06-19 18:13:53 --> URI Class Initialized
INFO - 2017-06-19 18:13:53 --> Router Class Initialized
INFO - 2017-06-19 18:13:53 --> Output Class Initialized
INFO - 2017-06-19 18:13:53 --> Security Class Initialized
DEBUG - 2017-06-19 18:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:13:53 --> Input Class Initialized
INFO - 2017-06-19 18:13:53 --> Language Class Initialized
INFO - 2017-06-19 18:13:53 --> Loader Class Initialized
INFO - 2017-06-19 18:13:53 --> Controller Class Initialized
INFO - 2017-06-19 18:13:53 --> Database Driver Class Initialized
INFO - 2017-06-19 18:13:53 --> Model Class Initialized
INFO - 2017-06-19 18:13:53 --> Helper loaded: form_helper
INFO - 2017-06-19 18:13:53 --> Helper loaded: url_helper
INFO - 2017-06-19 18:13:53 --> Upload Class Initialized
INFO - 2017-06-19 18:13:53 --> Final output sent to browser
DEBUG - 2017-06-19 18:13:53 --> Total execution time: 0.0520
ERROR - 2017-06-19 18:14:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:14:10 --> Config Class Initialized
INFO - 2017-06-19 18:14:10 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:14:10 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:14:10 --> Utf8 Class Initialized
INFO - 2017-06-19 18:14:10 --> URI Class Initialized
DEBUG - 2017-06-19 18:14:10 --> No URI present. Default controller set.
INFO - 2017-06-19 18:14:10 --> Router Class Initialized
INFO - 2017-06-19 18:14:10 --> Output Class Initialized
INFO - 2017-06-19 18:14:10 --> Security Class Initialized
DEBUG - 2017-06-19 18:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:14:10 --> Input Class Initialized
INFO - 2017-06-19 18:14:10 --> Language Class Initialized
INFO - 2017-06-19 18:14:10 --> Loader Class Initialized
INFO - 2017-06-19 18:14:10 --> Controller Class Initialized
INFO - 2017-06-19 18:14:10 --> Database Driver Class Initialized
INFO - 2017-06-19 18:14:10 --> Model Class Initialized
INFO - 2017-06-19 18:14:10 --> Helper loaded: form_helper
INFO - 2017-06-19 18:14:10 --> Helper loaded: url_helper
INFO - 2017-06-19 18:14:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-06-19 18:14:10 --> Final output sent to browser
DEBUG - 2017-06-19 18:14:10 --> Total execution time: 0.0550
ERROR - 2017-06-19 18:14:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:14:11 --> Config Class Initialized
INFO - 2017-06-19 18:14:11 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:14:11 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:14:11 --> Utf8 Class Initialized
INFO - 2017-06-19 18:14:11 --> URI Class Initialized
INFO - 2017-06-19 18:14:11 --> Router Class Initialized
INFO - 2017-06-19 18:14:11 --> Output Class Initialized
INFO - 2017-06-19 18:14:11 --> Security Class Initialized
DEBUG - 2017-06-19 18:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:14:11 --> Input Class Initialized
INFO - 2017-06-19 18:14:11 --> Language Class Initialized
INFO - 2017-06-19 18:14:11 --> Loader Class Initialized
INFO - 2017-06-19 18:14:11 --> Controller Class Initialized
INFO - 2017-06-19 18:14:11 --> Database Driver Class Initialized
INFO - 2017-06-19 18:14:11 --> Model Class Initialized
INFO - 2017-06-19 18:14:11 --> Helper loaded: form_helper
INFO - 2017-06-19 18:14:11 --> Helper loaded: url_helper
INFO - 2017-06-19 18:14:11 --> Model Class Initialized
ERROR - 2017-06-19 18:14:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:14:11 --> Config Class Initialized
INFO - 2017-06-19 18:14:11 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:14:11 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:14:11 --> Utf8 Class Initialized
INFO - 2017-06-19 18:14:11 --> URI Class Initialized
INFO - 2017-06-19 18:14:11 --> Router Class Initialized
INFO - 2017-06-19 18:14:11 --> Output Class Initialized
INFO - 2017-06-19 18:14:11 --> Security Class Initialized
DEBUG - 2017-06-19 18:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:14:11 --> Input Class Initialized
INFO - 2017-06-19 18:14:11 --> Language Class Initialized
INFO - 2017-06-19 18:14:11 --> Loader Class Initialized
INFO - 2017-06-19 18:14:11 --> Controller Class Initialized
INFO - 2017-06-19 18:14:11 --> Database Driver Class Initialized
INFO - 2017-06-19 18:14:11 --> Model Class Initialized
INFO - 2017-06-19 18:14:11 --> Helper loaded: form_helper
INFO - 2017-06-19 18:14:11 --> Helper loaded: url_helper
INFO - 2017-06-19 18:14:11 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:14:11 --> Model Class Initialized
INFO - 2017-06-19 18:14:11 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-19 18:14:11 --> Final output sent to browser
DEBUG - 2017-06-19 18:14:11 --> Total execution time: 0.0640
ERROR - 2017-06-19 18:14:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:14:14 --> Config Class Initialized
INFO - 2017-06-19 18:14:14 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:14:14 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:14:14 --> Utf8 Class Initialized
INFO - 2017-06-19 18:14:14 --> URI Class Initialized
INFO - 2017-06-19 18:14:14 --> Router Class Initialized
INFO - 2017-06-19 18:14:14 --> Output Class Initialized
INFO - 2017-06-19 18:14:14 --> Security Class Initialized
DEBUG - 2017-06-19 18:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:14:14 --> Input Class Initialized
INFO - 2017-06-19 18:14:14 --> Language Class Initialized
INFO - 2017-06-19 18:14:14 --> Loader Class Initialized
INFO - 2017-06-19 18:14:14 --> Controller Class Initialized
INFO - 2017-06-19 18:14:14 --> Database Driver Class Initialized
INFO - 2017-06-19 18:14:14 --> Model Class Initialized
INFO - 2017-06-19 18:14:14 --> Helper loaded: form_helper
INFO - 2017-06-19 18:14:14 --> Helper loaded: url_helper
INFO - 2017-06-19 18:14:14 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:14:14 --> Model Class Initialized
INFO - 2017-06-19 18:14:14 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 18:14:14 --> Final output sent to browser
DEBUG - 2017-06-19 18:14:14 --> Total execution time: 0.0850
ERROR - 2017-06-19 18:14:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:14:27 --> Config Class Initialized
INFO - 2017-06-19 18:14:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:14:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:14:27 --> Utf8 Class Initialized
INFO - 2017-06-19 18:14:27 --> URI Class Initialized
INFO - 2017-06-19 18:14:27 --> Router Class Initialized
INFO - 2017-06-19 18:14:27 --> Output Class Initialized
INFO - 2017-06-19 18:14:27 --> Security Class Initialized
DEBUG - 2017-06-19 18:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:14:27 --> Input Class Initialized
INFO - 2017-06-19 18:14:27 --> Language Class Initialized
INFO - 2017-06-19 18:14:27 --> Loader Class Initialized
INFO - 2017-06-19 18:14:27 --> Controller Class Initialized
INFO - 2017-06-19 18:14:27 --> Database Driver Class Initialized
INFO - 2017-06-19 18:14:27 --> Model Class Initialized
INFO - 2017-06-19 18:14:27 --> Helper loaded: form_helper
INFO - 2017-06-19 18:14:27 --> Helper loaded: url_helper
INFO - 2017-06-19 18:14:27 --> Upload Class Initialized
INFO - 2017-06-19 18:14:27 --> Final output sent to browser
DEBUG - 2017-06-19 18:14:27 --> Total execution time: 0.0510
ERROR - 2017-06-19 18:14:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:14:27 --> Config Class Initialized
INFO - 2017-06-19 18:14:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:14:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:14:27 --> Utf8 Class Initialized
INFO - 2017-06-19 18:14:27 --> URI Class Initialized
INFO - 2017-06-19 18:14:27 --> Router Class Initialized
INFO - 2017-06-19 18:14:27 --> Output Class Initialized
INFO - 2017-06-19 18:14:27 --> Security Class Initialized
DEBUG - 2017-06-19 18:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:14:27 --> Input Class Initialized
INFO - 2017-06-19 18:14:27 --> Language Class Initialized
INFO - 2017-06-19 18:14:27 --> Loader Class Initialized
INFO - 2017-06-19 18:14:27 --> Controller Class Initialized
INFO - 2017-06-19 18:14:27 --> Database Driver Class Initialized
INFO - 2017-06-19 18:14:27 --> Model Class Initialized
INFO - 2017-06-19 18:14:27 --> Helper loaded: form_helper
INFO - 2017-06-19 18:14:27 --> Helper loaded: url_helper
INFO - 2017-06-19 18:14:27 --> Upload Class Initialized
INFO - 2017-06-19 18:14:27 --> Final output sent to browser
DEBUG - 2017-06-19 18:14:27 --> Total execution time: 0.0500
ERROR - 2017-06-19 18:14:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:14:27 --> Config Class Initialized
INFO - 2017-06-19 18:14:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:14:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:14:27 --> Utf8 Class Initialized
INFO - 2017-06-19 18:14:27 --> URI Class Initialized
INFO - 2017-06-19 18:14:27 --> Router Class Initialized
INFO - 2017-06-19 18:14:27 --> Output Class Initialized
INFO - 2017-06-19 18:14:27 --> Security Class Initialized
DEBUG - 2017-06-19 18:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:14:27 --> Input Class Initialized
INFO - 2017-06-19 18:14:27 --> Language Class Initialized
INFO - 2017-06-19 18:14:27 --> Loader Class Initialized
INFO - 2017-06-19 18:14:27 --> Controller Class Initialized
INFO - 2017-06-19 18:14:27 --> Database Driver Class Initialized
INFO - 2017-06-19 18:14:27 --> Model Class Initialized
INFO - 2017-06-19 18:14:27 --> Helper loaded: form_helper
INFO - 2017-06-19 18:14:27 --> Helper loaded: url_helper
INFO - 2017-06-19 18:14:27 --> Upload Class Initialized
INFO - 2017-06-19 18:14:27 --> Final output sent to browser
DEBUG - 2017-06-19 18:14:27 --> Total execution time: 0.0500
ERROR - 2017-06-19 18:14:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:14:27 --> Config Class Initialized
INFO - 2017-06-19 18:14:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:14:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:14:27 --> Utf8 Class Initialized
INFO - 2017-06-19 18:14:27 --> URI Class Initialized
INFO - 2017-06-19 18:14:27 --> Router Class Initialized
INFO - 2017-06-19 18:14:27 --> Output Class Initialized
INFO - 2017-06-19 18:14:27 --> Security Class Initialized
DEBUG - 2017-06-19 18:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:14:27 --> Input Class Initialized
INFO - 2017-06-19 18:14:27 --> Language Class Initialized
INFO - 2017-06-19 18:14:27 --> Loader Class Initialized
INFO - 2017-06-19 18:14:27 --> Controller Class Initialized
INFO - 2017-06-19 18:14:27 --> Database Driver Class Initialized
INFO - 2017-06-19 18:14:27 --> Model Class Initialized
INFO - 2017-06-19 18:14:27 --> Helper loaded: form_helper
INFO - 2017-06-19 18:14:27 --> Helper loaded: url_helper
INFO - 2017-06-19 18:14:27 --> Upload Class Initialized
INFO - 2017-06-19 18:14:27 --> Final output sent to browser
DEBUG - 2017-06-19 18:14:27 --> Total execution time: 0.0490
ERROR - 2017-06-19 18:14:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:14:27 --> Config Class Initialized
INFO - 2017-06-19 18:14:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:14:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:14:27 --> Utf8 Class Initialized
INFO - 2017-06-19 18:14:27 --> URI Class Initialized
INFO - 2017-06-19 18:14:27 --> Router Class Initialized
INFO - 2017-06-19 18:14:27 --> Output Class Initialized
INFO - 2017-06-19 18:14:27 --> Security Class Initialized
DEBUG - 2017-06-19 18:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:14:27 --> Input Class Initialized
INFO - 2017-06-19 18:14:27 --> Language Class Initialized
INFO - 2017-06-19 18:14:27 --> Loader Class Initialized
INFO - 2017-06-19 18:14:27 --> Controller Class Initialized
INFO - 2017-06-19 18:14:27 --> Database Driver Class Initialized
INFO - 2017-06-19 18:14:27 --> Model Class Initialized
INFO - 2017-06-19 18:14:27 --> Helper loaded: form_helper
INFO - 2017-06-19 18:14:27 --> Helper loaded: url_helper
INFO - 2017-06-19 18:14:27 --> Upload Class Initialized
INFO - 2017-06-19 18:14:27 --> Final output sent to browser
DEBUG - 2017-06-19 18:14:27 --> Total execution time: 0.0590
ERROR - 2017-06-19 18:14:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:14:27 --> Config Class Initialized
INFO - 2017-06-19 18:14:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:14:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:14:27 --> Utf8 Class Initialized
INFO - 2017-06-19 18:14:27 --> URI Class Initialized
INFO - 2017-06-19 18:14:27 --> Router Class Initialized
INFO - 2017-06-19 18:14:27 --> Output Class Initialized
INFO - 2017-06-19 18:14:27 --> Security Class Initialized
DEBUG - 2017-06-19 18:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:14:27 --> Input Class Initialized
INFO - 2017-06-19 18:14:27 --> Language Class Initialized
INFO - 2017-06-19 18:14:27 --> Loader Class Initialized
INFO - 2017-06-19 18:14:27 --> Controller Class Initialized
INFO - 2017-06-19 18:14:27 --> Database Driver Class Initialized
INFO - 2017-06-19 18:14:27 --> Model Class Initialized
INFO - 2017-06-19 18:14:27 --> Helper loaded: form_helper
INFO - 2017-06-19 18:14:27 --> Helper loaded: url_helper
INFO - 2017-06-19 18:14:28 --> Upload Class Initialized
INFO - 2017-06-19 18:14:28 --> Final output sent to browser
DEBUG - 2017-06-19 18:14:28 --> Total execution time: 0.0610
ERROR - 2017-06-19 18:14:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:14:28 --> Config Class Initialized
INFO - 2017-06-19 18:14:28 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:14:28 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:14:28 --> Utf8 Class Initialized
INFO - 2017-06-19 18:14:28 --> URI Class Initialized
INFO - 2017-06-19 18:14:28 --> Router Class Initialized
INFO - 2017-06-19 18:14:28 --> Output Class Initialized
INFO - 2017-06-19 18:14:28 --> Security Class Initialized
DEBUG - 2017-06-19 18:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:14:28 --> Input Class Initialized
INFO - 2017-06-19 18:14:28 --> Language Class Initialized
INFO - 2017-06-19 18:14:28 --> Loader Class Initialized
INFO - 2017-06-19 18:14:28 --> Controller Class Initialized
INFO - 2017-06-19 18:14:28 --> Database Driver Class Initialized
INFO - 2017-06-19 18:14:28 --> Model Class Initialized
INFO - 2017-06-19 18:14:28 --> Helper loaded: form_helper
INFO - 2017-06-19 18:14:28 --> Helper loaded: url_helper
INFO - 2017-06-19 18:14:28 --> Upload Class Initialized
INFO - 2017-06-19 18:14:28 --> Final output sent to browser
DEBUG - 2017-06-19 18:14:28 --> Total execution time: 0.0640
ERROR - 2017-06-19 18:14:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:14:43 --> Config Class Initialized
INFO - 2017-06-19 18:14:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:14:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:14:43 --> Utf8 Class Initialized
INFO - 2017-06-19 18:14:43 --> URI Class Initialized
INFO - 2017-06-19 18:14:43 --> Router Class Initialized
INFO - 2017-06-19 18:14:43 --> Output Class Initialized
INFO - 2017-06-19 18:14:43 --> Security Class Initialized
DEBUG - 2017-06-19 18:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:14:43 --> Input Class Initialized
INFO - 2017-06-19 18:14:43 --> Language Class Initialized
INFO - 2017-06-19 18:14:43 --> Loader Class Initialized
INFO - 2017-06-19 18:14:43 --> Controller Class Initialized
INFO - 2017-06-19 18:14:43 --> Database Driver Class Initialized
INFO - 2017-06-19 18:14:43 --> Model Class Initialized
INFO - 2017-06-19 18:14:43 --> Helper loaded: form_helper
INFO - 2017-06-19 18:14:43 --> Helper loaded: url_helper
INFO - 2017-06-19 18:14:43 --> Upload Class Initialized
INFO - 2017-06-19 18:14:43 --> Final output sent to browser
DEBUG - 2017-06-19 18:14:43 --> Total execution time: 0.0530
ERROR - 2017-06-19 18:14:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:14:43 --> Config Class Initialized
INFO - 2017-06-19 18:14:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:14:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:14:43 --> Utf8 Class Initialized
INFO - 2017-06-19 18:14:43 --> URI Class Initialized
INFO - 2017-06-19 18:14:43 --> Router Class Initialized
INFO - 2017-06-19 18:14:43 --> Output Class Initialized
INFO - 2017-06-19 18:14:43 --> Security Class Initialized
DEBUG - 2017-06-19 18:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:14:43 --> Input Class Initialized
INFO - 2017-06-19 18:14:43 --> Language Class Initialized
INFO - 2017-06-19 18:14:43 --> Loader Class Initialized
INFO - 2017-06-19 18:14:43 --> Controller Class Initialized
INFO - 2017-06-19 18:14:43 --> Database Driver Class Initialized
INFO - 2017-06-19 18:14:43 --> Model Class Initialized
INFO - 2017-06-19 18:14:43 --> Helper loaded: form_helper
INFO - 2017-06-19 18:14:43 --> Helper loaded: url_helper
INFO - 2017-06-19 18:14:43 --> Upload Class Initialized
INFO - 2017-06-19 18:14:43 --> Final output sent to browser
DEBUG - 2017-06-19 18:14:43 --> Total execution time: 0.0540
ERROR - 2017-06-19 18:14:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:14:43 --> Config Class Initialized
INFO - 2017-06-19 18:14:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:14:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:14:43 --> Utf8 Class Initialized
INFO - 2017-06-19 18:14:43 --> URI Class Initialized
INFO - 2017-06-19 18:14:43 --> Router Class Initialized
INFO - 2017-06-19 18:14:43 --> Output Class Initialized
INFO - 2017-06-19 18:14:43 --> Security Class Initialized
DEBUG - 2017-06-19 18:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:14:43 --> Input Class Initialized
INFO - 2017-06-19 18:14:43 --> Language Class Initialized
INFO - 2017-06-19 18:14:43 --> Loader Class Initialized
INFO - 2017-06-19 18:14:43 --> Controller Class Initialized
INFO - 2017-06-19 18:14:43 --> Database Driver Class Initialized
INFO - 2017-06-19 18:14:43 --> Model Class Initialized
INFO - 2017-06-19 18:14:43 --> Helper loaded: form_helper
INFO - 2017-06-19 18:14:43 --> Helper loaded: url_helper
INFO - 2017-06-19 18:14:43 --> Upload Class Initialized
INFO - 2017-06-19 18:14:43 --> Final output sent to browser
DEBUG - 2017-06-19 18:14:43 --> Total execution time: 0.0540
ERROR - 2017-06-19 18:14:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:14:43 --> Config Class Initialized
INFO - 2017-06-19 18:14:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:14:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:14:43 --> Utf8 Class Initialized
INFO - 2017-06-19 18:14:43 --> URI Class Initialized
INFO - 2017-06-19 18:14:43 --> Router Class Initialized
INFO - 2017-06-19 18:14:43 --> Output Class Initialized
INFO - 2017-06-19 18:14:43 --> Security Class Initialized
DEBUG - 2017-06-19 18:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:14:43 --> Input Class Initialized
INFO - 2017-06-19 18:14:43 --> Language Class Initialized
INFO - 2017-06-19 18:14:43 --> Loader Class Initialized
INFO - 2017-06-19 18:14:43 --> Controller Class Initialized
INFO - 2017-06-19 18:14:43 --> Database Driver Class Initialized
INFO - 2017-06-19 18:14:43 --> Model Class Initialized
INFO - 2017-06-19 18:14:43 --> Helper loaded: form_helper
INFO - 2017-06-19 18:14:43 --> Helper loaded: url_helper
INFO - 2017-06-19 18:14:43 --> Upload Class Initialized
INFO - 2017-06-19 18:14:43 --> Final output sent to browser
DEBUG - 2017-06-19 18:14:43 --> Total execution time: 0.0520
ERROR - 2017-06-19 18:14:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:14:43 --> Config Class Initialized
INFO - 2017-06-19 18:14:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:14:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:14:43 --> Utf8 Class Initialized
INFO - 2017-06-19 18:14:43 --> URI Class Initialized
INFO - 2017-06-19 18:14:43 --> Router Class Initialized
INFO - 2017-06-19 18:14:43 --> Output Class Initialized
INFO - 2017-06-19 18:14:43 --> Security Class Initialized
DEBUG - 2017-06-19 18:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:14:43 --> Input Class Initialized
INFO - 2017-06-19 18:14:43 --> Language Class Initialized
INFO - 2017-06-19 18:14:43 --> Loader Class Initialized
INFO - 2017-06-19 18:14:43 --> Controller Class Initialized
INFO - 2017-06-19 18:14:43 --> Database Driver Class Initialized
INFO - 2017-06-19 18:14:43 --> Model Class Initialized
INFO - 2017-06-19 18:14:43 --> Helper loaded: form_helper
INFO - 2017-06-19 18:14:43 --> Helper loaded: url_helper
INFO - 2017-06-19 18:14:43 --> Upload Class Initialized
INFO - 2017-06-19 18:14:43 --> Final output sent to browser
DEBUG - 2017-06-19 18:14:43 --> Total execution time: 0.0520
ERROR - 2017-06-19 18:14:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:14:43 --> Config Class Initialized
INFO - 2017-06-19 18:14:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:14:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:14:43 --> Utf8 Class Initialized
INFO - 2017-06-19 18:14:43 --> URI Class Initialized
INFO - 2017-06-19 18:14:43 --> Router Class Initialized
INFO - 2017-06-19 18:14:43 --> Output Class Initialized
INFO - 2017-06-19 18:14:43 --> Security Class Initialized
DEBUG - 2017-06-19 18:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:14:43 --> Input Class Initialized
INFO - 2017-06-19 18:14:43 --> Language Class Initialized
INFO - 2017-06-19 18:14:43 --> Loader Class Initialized
INFO - 2017-06-19 18:14:43 --> Controller Class Initialized
INFO - 2017-06-19 18:14:43 --> Database Driver Class Initialized
INFO - 2017-06-19 18:14:43 --> Model Class Initialized
INFO - 2017-06-19 18:14:43 --> Helper loaded: form_helper
INFO - 2017-06-19 18:14:43 --> Helper loaded: url_helper
INFO - 2017-06-19 18:14:43 --> Upload Class Initialized
INFO - 2017-06-19 18:14:43 --> Final output sent to browser
DEBUG - 2017-06-19 18:14:43 --> Total execution time: 0.0510
ERROR - 2017-06-19 18:14:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:14:43 --> Config Class Initialized
INFO - 2017-06-19 18:14:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:14:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:14:43 --> Utf8 Class Initialized
INFO - 2017-06-19 18:14:43 --> URI Class Initialized
INFO - 2017-06-19 18:14:43 --> Router Class Initialized
INFO - 2017-06-19 18:14:43 --> Output Class Initialized
INFO - 2017-06-19 18:14:43 --> Security Class Initialized
DEBUG - 2017-06-19 18:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:14:43 --> Input Class Initialized
INFO - 2017-06-19 18:14:43 --> Language Class Initialized
INFO - 2017-06-19 18:14:43 --> Loader Class Initialized
INFO - 2017-06-19 18:14:43 --> Controller Class Initialized
INFO - 2017-06-19 18:14:43 --> Database Driver Class Initialized
INFO - 2017-06-19 18:14:43 --> Model Class Initialized
INFO - 2017-06-19 18:14:43 --> Helper loaded: form_helper
INFO - 2017-06-19 18:14:43 --> Helper loaded: url_helper
INFO - 2017-06-19 18:14:43 --> Upload Class Initialized
INFO - 2017-06-19 18:14:43 --> Final output sent to browser
DEBUG - 2017-06-19 18:14:43 --> Total execution time: 0.0510
ERROR - 2017-06-19 18:14:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:14:59 --> Config Class Initialized
INFO - 2017-06-19 18:14:59 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:14:59 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:14:59 --> Utf8 Class Initialized
INFO - 2017-06-19 18:14:59 --> URI Class Initialized
INFO - 2017-06-19 18:14:59 --> Router Class Initialized
INFO - 2017-06-19 18:14:59 --> Output Class Initialized
INFO - 2017-06-19 18:14:59 --> Security Class Initialized
DEBUG - 2017-06-19 18:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:14:59 --> Input Class Initialized
INFO - 2017-06-19 18:14:59 --> Language Class Initialized
INFO - 2017-06-19 18:14:59 --> Loader Class Initialized
INFO - 2017-06-19 18:14:59 --> Controller Class Initialized
INFO - 2017-06-19 18:14:59 --> Database Driver Class Initialized
INFO - 2017-06-19 18:14:59 --> Model Class Initialized
INFO - 2017-06-19 18:14:59 --> Helper loaded: form_helper
INFO - 2017-06-19 18:14:59 --> Helper loaded: url_helper
INFO - 2017-06-19 18:14:59 --> Upload Class Initialized
INFO - 2017-06-19 18:14:59 --> Final output sent to browser
DEBUG - 2017-06-19 18:14:59 --> Total execution time: 0.0500
ERROR - 2017-06-19 18:15:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:15:36 --> Config Class Initialized
INFO - 2017-06-19 18:15:36 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:15:36 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:15:36 --> Utf8 Class Initialized
INFO - 2017-06-19 18:15:36 --> URI Class Initialized
INFO - 2017-06-19 18:15:36 --> Router Class Initialized
INFO - 2017-06-19 18:15:36 --> Output Class Initialized
INFO - 2017-06-19 18:15:36 --> Security Class Initialized
DEBUG - 2017-06-19 18:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:15:36 --> Input Class Initialized
INFO - 2017-06-19 18:15:36 --> Language Class Initialized
INFO - 2017-06-19 18:15:36 --> Loader Class Initialized
INFO - 2017-06-19 18:15:36 --> Controller Class Initialized
INFO - 2017-06-19 18:15:36 --> Database Driver Class Initialized
INFO - 2017-06-19 18:15:36 --> Model Class Initialized
INFO - 2017-06-19 18:15:36 --> Helper loaded: form_helper
INFO - 2017-06-19 18:15:36 --> Helper loaded: url_helper
INFO - 2017-06-19 18:15:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:15:36 --> Model Class Initialized
INFO - 2017-06-19 18:15:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 18:15:36 --> Final output sent to browser
DEBUG - 2017-06-19 18:15:36 --> Total execution time: 0.0610
ERROR - 2017-06-19 18:15:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:15:41 --> Config Class Initialized
INFO - 2017-06-19 18:15:41 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:15:41 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:15:41 --> Utf8 Class Initialized
INFO - 2017-06-19 18:15:41 --> URI Class Initialized
INFO - 2017-06-19 18:15:41 --> Router Class Initialized
INFO - 2017-06-19 18:15:41 --> Output Class Initialized
INFO - 2017-06-19 18:15:41 --> Security Class Initialized
DEBUG - 2017-06-19 18:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:15:41 --> Input Class Initialized
INFO - 2017-06-19 18:15:41 --> Language Class Initialized
INFO - 2017-06-19 18:15:41 --> Loader Class Initialized
INFO - 2017-06-19 18:15:41 --> Controller Class Initialized
INFO - 2017-06-19 18:15:41 --> Database Driver Class Initialized
INFO - 2017-06-19 18:15:41 --> Model Class Initialized
INFO - 2017-06-19 18:15:41 --> Helper loaded: form_helper
INFO - 2017-06-19 18:15:41 --> Helper loaded: url_helper
INFO - 2017-06-19 18:15:41 --> Upload Class Initialized
INFO - 2017-06-19 18:15:41 --> Final output sent to browser
DEBUG - 2017-06-19 18:15:41 --> Total execution time: 0.0550
ERROR - 2017-06-19 18:15:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:15:41 --> Config Class Initialized
INFO - 2017-06-19 18:15:41 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:15:41 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:15:41 --> Utf8 Class Initialized
INFO - 2017-06-19 18:15:41 --> URI Class Initialized
INFO - 2017-06-19 18:15:41 --> Router Class Initialized
INFO - 2017-06-19 18:15:41 --> Output Class Initialized
INFO - 2017-06-19 18:15:41 --> Security Class Initialized
DEBUG - 2017-06-19 18:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:15:41 --> Input Class Initialized
INFO - 2017-06-19 18:15:41 --> Language Class Initialized
INFO - 2017-06-19 18:15:41 --> Loader Class Initialized
INFO - 2017-06-19 18:15:41 --> Controller Class Initialized
INFO - 2017-06-19 18:15:41 --> Database Driver Class Initialized
INFO - 2017-06-19 18:15:41 --> Model Class Initialized
INFO - 2017-06-19 18:15:41 --> Helper loaded: form_helper
INFO - 2017-06-19 18:15:41 --> Helper loaded: url_helper
INFO - 2017-06-19 18:15:41 --> Upload Class Initialized
INFO - 2017-06-19 18:15:41 --> Final output sent to browser
DEBUG - 2017-06-19 18:15:41 --> Total execution time: 0.0520
ERROR - 2017-06-19 18:15:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:15:41 --> Config Class Initialized
INFO - 2017-06-19 18:15:41 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:15:41 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:15:41 --> Utf8 Class Initialized
INFO - 2017-06-19 18:15:41 --> URI Class Initialized
INFO - 2017-06-19 18:15:41 --> Router Class Initialized
INFO - 2017-06-19 18:15:41 --> Output Class Initialized
INFO - 2017-06-19 18:15:41 --> Security Class Initialized
DEBUG - 2017-06-19 18:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:15:41 --> Input Class Initialized
INFO - 2017-06-19 18:15:41 --> Language Class Initialized
INFO - 2017-06-19 18:15:41 --> Loader Class Initialized
INFO - 2017-06-19 18:15:41 --> Controller Class Initialized
INFO - 2017-06-19 18:15:41 --> Database Driver Class Initialized
INFO - 2017-06-19 18:15:41 --> Model Class Initialized
INFO - 2017-06-19 18:15:41 --> Helper loaded: form_helper
INFO - 2017-06-19 18:15:41 --> Helper loaded: url_helper
INFO - 2017-06-19 18:15:41 --> Upload Class Initialized
INFO - 2017-06-19 18:15:41 --> Final output sent to browser
DEBUG - 2017-06-19 18:15:41 --> Total execution time: 0.0540
ERROR - 2017-06-19 18:15:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:15:41 --> Config Class Initialized
INFO - 2017-06-19 18:15:41 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:15:41 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:15:41 --> Utf8 Class Initialized
INFO - 2017-06-19 18:15:41 --> URI Class Initialized
INFO - 2017-06-19 18:15:41 --> Router Class Initialized
INFO - 2017-06-19 18:15:41 --> Output Class Initialized
INFO - 2017-06-19 18:15:41 --> Security Class Initialized
DEBUG - 2017-06-19 18:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:15:41 --> Input Class Initialized
INFO - 2017-06-19 18:15:41 --> Language Class Initialized
INFO - 2017-06-19 18:15:41 --> Loader Class Initialized
INFO - 2017-06-19 18:15:41 --> Controller Class Initialized
INFO - 2017-06-19 18:15:41 --> Database Driver Class Initialized
INFO - 2017-06-19 18:15:41 --> Model Class Initialized
INFO - 2017-06-19 18:15:41 --> Helper loaded: form_helper
INFO - 2017-06-19 18:15:41 --> Helper loaded: url_helper
INFO - 2017-06-19 18:15:41 --> Upload Class Initialized
INFO - 2017-06-19 18:15:41 --> Final output sent to browser
DEBUG - 2017-06-19 18:15:41 --> Total execution time: 0.0545
ERROR - 2017-06-19 18:15:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:15:41 --> Config Class Initialized
INFO - 2017-06-19 18:15:41 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:15:41 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:15:41 --> Utf8 Class Initialized
INFO - 2017-06-19 18:15:41 --> URI Class Initialized
INFO - 2017-06-19 18:15:41 --> Router Class Initialized
INFO - 2017-06-19 18:15:41 --> Output Class Initialized
INFO - 2017-06-19 18:15:41 --> Security Class Initialized
DEBUG - 2017-06-19 18:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:15:41 --> Input Class Initialized
INFO - 2017-06-19 18:15:41 --> Language Class Initialized
INFO - 2017-06-19 18:15:41 --> Loader Class Initialized
INFO - 2017-06-19 18:15:41 --> Controller Class Initialized
INFO - 2017-06-19 18:15:41 --> Database Driver Class Initialized
INFO - 2017-06-19 18:15:41 --> Model Class Initialized
INFO - 2017-06-19 18:15:41 --> Helper loaded: form_helper
INFO - 2017-06-19 18:15:41 --> Helper loaded: url_helper
INFO - 2017-06-19 18:15:41 --> Upload Class Initialized
INFO - 2017-06-19 18:15:41 --> Final output sent to browser
DEBUG - 2017-06-19 18:15:41 --> Total execution time: 0.0520
ERROR - 2017-06-19 18:15:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:15:41 --> Config Class Initialized
INFO - 2017-06-19 18:15:41 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:15:41 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:15:41 --> Utf8 Class Initialized
INFO - 2017-06-19 18:15:41 --> URI Class Initialized
INFO - 2017-06-19 18:15:41 --> Router Class Initialized
INFO - 2017-06-19 18:15:41 --> Output Class Initialized
INFO - 2017-06-19 18:15:41 --> Security Class Initialized
DEBUG - 2017-06-19 18:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:15:41 --> Input Class Initialized
INFO - 2017-06-19 18:15:41 --> Language Class Initialized
INFO - 2017-06-19 18:15:41 --> Loader Class Initialized
INFO - 2017-06-19 18:15:41 --> Controller Class Initialized
INFO - 2017-06-19 18:15:41 --> Database Driver Class Initialized
INFO - 2017-06-19 18:15:41 --> Model Class Initialized
INFO - 2017-06-19 18:15:41 --> Helper loaded: form_helper
INFO - 2017-06-19 18:15:41 --> Helper loaded: url_helper
INFO - 2017-06-19 18:15:41 --> Upload Class Initialized
INFO - 2017-06-19 18:15:41 --> Final output sent to browser
DEBUG - 2017-06-19 18:15:41 --> Total execution time: 0.0510
ERROR - 2017-06-19 18:15:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:15:42 --> Config Class Initialized
INFO - 2017-06-19 18:15:42 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:15:42 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:15:42 --> Utf8 Class Initialized
INFO - 2017-06-19 18:15:42 --> URI Class Initialized
INFO - 2017-06-19 18:15:42 --> Router Class Initialized
INFO - 2017-06-19 18:15:42 --> Output Class Initialized
INFO - 2017-06-19 18:15:42 --> Security Class Initialized
DEBUG - 2017-06-19 18:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:15:42 --> Input Class Initialized
INFO - 2017-06-19 18:15:42 --> Language Class Initialized
INFO - 2017-06-19 18:15:42 --> Loader Class Initialized
INFO - 2017-06-19 18:15:42 --> Controller Class Initialized
INFO - 2017-06-19 18:15:42 --> Database Driver Class Initialized
INFO - 2017-06-19 18:15:42 --> Model Class Initialized
INFO - 2017-06-19 18:15:42 --> Helper loaded: form_helper
INFO - 2017-06-19 18:15:42 --> Helper loaded: url_helper
INFO - 2017-06-19 18:15:42 --> Upload Class Initialized
INFO - 2017-06-19 18:15:42 --> Final output sent to browser
DEBUG - 2017-06-19 18:15:42 --> Total execution time: 0.0500
ERROR - 2017-06-19 18:15:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:15:56 --> Config Class Initialized
INFO - 2017-06-19 18:15:56 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:15:56 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:15:56 --> Utf8 Class Initialized
INFO - 2017-06-19 18:15:56 --> URI Class Initialized
INFO - 2017-06-19 18:15:56 --> Router Class Initialized
INFO - 2017-06-19 18:15:56 --> Output Class Initialized
INFO - 2017-06-19 18:15:56 --> Security Class Initialized
DEBUG - 2017-06-19 18:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:15:56 --> Input Class Initialized
INFO - 2017-06-19 18:15:56 --> Language Class Initialized
INFO - 2017-06-19 18:15:56 --> Loader Class Initialized
INFO - 2017-06-19 18:15:56 --> Controller Class Initialized
INFO - 2017-06-19 18:15:56 --> Database Driver Class Initialized
INFO - 2017-06-19 18:15:56 --> Model Class Initialized
INFO - 2017-06-19 18:15:56 --> Helper loaded: form_helper
INFO - 2017-06-19 18:15:56 --> Helper loaded: url_helper
INFO - 2017-06-19 18:15:56 --> Upload Class Initialized
INFO - 2017-06-19 18:15:56 --> Final output sent to browser
DEBUG - 2017-06-19 18:15:56 --> Total execution time: 0.0560
ERROR - 2017-06-19 18:15:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:15:56 --> Config Class Initialized
INFO - 2017-06-19 18:15:56 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:15:56 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:15:56 --> Utf8 Class Initialized
INFO - 2017-06-19 18:15:56 --> URI Class Initialized
INFO - 2017-06-19 18:15:56 --> Router Class Initialized
INFO - 2017-06-19 18:15:56 --> Output Class Initialized
INFO - 2017-06-19 18:15:56 --> Security Class Initialized
DEBUG - 2017-06-19 18:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:15:56 --> Input Class Initialized
INFO - 2017-06-19 18:15:56 --> Language Class Initialized
INFO - 2017-06-19 18:15:56 --> Loader Class Initialized
INFO - 2017-06-19 18:15:56 --> Controller Class Initialized
INFO - 2017-06-19 18:15:56 --> Database Driver Class Initialized
INFO - 2017-06-19 18:15:56 --> Model Class Initialized
INFO - 2017-06-19 18:15:56 --> Helper loaded: form_helper
INFO - 2017-06-19 18:15:56 --> Helper loaded: url_helper
INFO - 2017-06-19 18:15:56 --> Upload Class Initialized
INFO - 2017-06-19 18:15:56 --> Final output sent to browser
DEBUG - 2017-06-19 18:15:56 --> Total execution time: 0.0510
ERROR - 2017-06-19 18:15:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:15:56 --> Config Class Initialized
INFO - 2017-06-19 18:15:56 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:15:56 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:15:56 --> Utf8 Class Initialized
INFO - 2017-06-19 18:15:56 --> URI Class Initialized
INFO - 2017-06-19 18:15:56 --> Router Class Initialized
INFO - 2017-06-19 18:15:56 --> Output Class Initialized
INFO - 2017-06-19 18:15:56 --> Security Class Initialized
DEBUG - 2017-06-19 18:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:15:56 --> Input Class Initialized
INFO - 2017-06-19 18:15:56 --> Language Class Initialized
INFO - 2017-06-19 18:15:56 --> Loader Class Initialized
INFO - 2017-06-19 18:15:56 --> Controller Class Initialized
INFO - 2017-06-19 18:15:56 --> Database Driver Class Initialized
INFO - 2017-06-19 18:15:56 --> Model Class Initialized
INFO - 2017-06-19 18:15:56 --> Helper loaded: form_helper
INFO - 2017-06-19 18:15:56 --> Helper loaded: url_helper
INFO - 2017-06-19 18:15:56 --> Upload Class Initialized
INFO - 2017-06-19 18:15:56 --> Final output sent to browser
DEBUG - 2017-06-19 18:15:56 --> Total execution time: 0.0480
ERROR - 2017-06-19 18:15:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:15:56 --> Config Class Initialized
INFO - 2017-06-19 18:15:56 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:15:56 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:15:56 --> Utf8 Class Initialized
INFO - 2017-06-19 18:15:56 --> URI Class Initialized
INFO - 2017-06-19 18:15:56 --> Router Class Initialized
INFO - 2017-06-19 18:15:56 --> Output Class Initialized
INFO - 2017-06-19 18:15:56 --> Security Class Initialized
DEBUG - 2017-06-19 18:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:15:56 --> Input Class Initialized
INFO - 2017-06-19 18:15:56 --> Language Class Initialized
INFO - 2017-06-19 18:15:56 --> Loader Class Initialized
INFO - 2017-06-19 18:15:56 --> Controller Class Initialized
INFO - 2017-06-19 18:15:56 --> Database Driver Class Initialized
INFO - 2017-06-19 18:15:56 --> Model Class Initialized
INFO - 2017-06-19 18:15:56 --> Helper loaded: form_helper
INFO - 2017-06-19 18:15:56 --> Helper loaded: url_helper
INFO - 2017-06-19 18:15:56 --> Upload Class Initialized
INFO - 2017-06-19 18:15:56 --> Final output sent to browser
DEBUG - 2017-06-19 18:15:56 --> Total execution time: 0.0600
ERROR - 2017-06-19 18:15:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:15:57 --> Config Class Initialized
INFO - 2017-06-19 18:15:57 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:15:57 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:15:57 --> Utf8 Class Initialized
INFO - 2017-06-19 18:15:57 --> URI Class Initialized
INFO - 2017-06-19 18:15:57 --> Router Class Initialized
INFO - 2017-06-19 18:15:57 --> Output Class Initialized
INFO - 2017-06-19 18:15:57 --> Security Class Initialized
DEBUG - 2017-06-19 18:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:15:57 --> Input Class Initialized
INFO - 2017-06-19 18:15:57 --> Language Class Initialized
INFO - 2017-06-19 18:15:57 --> Loader Class Initialized
INFO - 2017-06-19 18:15:57 --> Controller Class Initialized
INFO - 2017-06-19 18:15:57 --> Database Driver Class Initialized
INFO - 2017-06-19 18:15:57 --> Model Class Initialized
INFO - 2017-06-19 18:15:57 --> Helper loaded: form_helper
INFO - 2017-06-19 18:15:57 --> Helper loaded: url_helper
INFO - 2017-06-19 18:15:57 --> Upload Class Initialized
INFO - 2017-06-19 18:15:57 --> Final output sent to browser
DEBUG - 2017-06-19 18:15:57 --> Total execution time: 0.0480
ERROR - 2017-06-19 18:15:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:15:57 --> Config Class Initialized
INFO - 2017-06-19 18:15:57 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:15:57 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:15:57 --> Utf8 Class Initialized
INFO - 2017-06-19 18:15:57 --> URI Class Initialized
INFO - 2017-06-19 18:15:57 --> Router Class Initialized
INFO - 2017-06-19 18:15:57 --> Output Class Initialized
INFO - 2017-06-19 18:15:57 --> Security Class Initialized
DEBUG - 2017-06-19 18:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:15:57 --> Input Class Initialized
INFO - 2017-06-19 18:15:57 --> Language Class Initialized
INFO - 2017-06-19 18:15:57 --> Loader Class Initialized
INFO - 2017-06-19 18:15:57 --> Controller Class Initialized
INFO - 2017-06-19 18:15:57 --> Database Driver Class Initialized
INFO - 2017-06-19 18:15:57 --> Model Class Initialized
INFO - 2017-06-19 18:15:57 --> Helper loaded: form_helper
INFO - 2017-06-19 18:15:57 --> Helper loaded: url_helper
INFO - 2017-06-19 18:15:57 --> Upload Class Initialized
INFO - 2017-06-19 18:15:57 --> Final output sent to browser
DEBUG - 2017-06-19 18:15:57 --> Total execution time: 0.0590
ERROR - 2017-06-19 18:15:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:15:57 --> Config Class Initialized
INFO - 2017-06-19 18:15:57 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:15:57 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:15:57 --> Utf8 Class Initialized
INFO - 2017-06-19 18:15:57 --> URI Class Initialized
INFO - 2017-06-19 18:15:57 --> Router Class Initialized
INFO - 2017-06-19 18:15:57 --> Output Class Initialized
INFO - 2017-06-19 18:15:57 --> Security Class Initialized
DEBUG - 2017-06-19 18:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:15:57 --> Input Class Initialized
INFO - 2017-06-19 18:15:57 --> Language Class Initialized
INFO - 2017-06-19 18:15:57 --> Loader Class Initialized
INFO - 2017-06-19 18:15:57 --> Controller Class Initialized
INFO - 2017-06-19 18:15:57 --> Database Driver Class Initialized
INFO - 2017-06-19 18:15:57 --> Model Class Initialized
INFO - 2017-06-19 18:15:57 --> Helper loaded: form_helper
INFO - 2017-06-19 18:15:57 --> Helper loaded: url_helper
INFO - 2017-06-19 18:15:57 --> Upload Class Initialized
INFO - 2017-06-19 18:15:57 --> Final output sent to browser
DEBUG - 2017-06-19 18:15:57 --> Total execution time: 0.0490
ERROR - 2017-06-19 18:15:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:15:57 --> Config Class Initialized
INFO - 2017-06-19 18:15:57 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:15:57 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:15:57 --> Utf8 Class Initialized
INFO - 2017-06-19 18:15:57 --> URI Class Initialized
INFO - 2017-06-19 18:15:57 --> Router Class Initialized
INFO - 2017-06-19 18:15:57 --> Output Class Initialized
INFO - 2017-06-19 18:15:57 --> Security Class Initialized
DEBUG - 2017-06-19 18:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:15:57 --> Input Class Initialized
INFO - 2017-06-19 18:15:57 --> Language Class Initialized
INFO - 2017-06-19 18:15:57 --> Loader Class Initialized
INFO - 2017-06-19 18:15:57 --> Controller Class Initialized
INFO - 2017-06-19 18:15:57 --> Database Driver Class Initialized
INFO - 2017-06-19 18:15:57 --> Model Class Initialized
INFO - 2017-06-19 18:15:57 --> Helper loaded: form_helper
INFO - 2017-06-19 18:15:57 --> Helper loaded: url_helper
INFO - 2017-06-19 18:15:57 --> Upload Class Initialized
INFO - 2017-06-19 18:15:57 --> Final output sent to browser
DEBUG - 2017-06-19 18:15:57 --> Total execution time: 0.0530
ERROR - 2017-06-19 18:16:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:16:53 --> Config Class Initialized
INFO - 2017-06-19 18:16:53 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:16:53 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:16:53 --> Utf8 Class Initialized
INFO - 2017-06-19 18:16:53 --> URI Class Initialized
INFO - 2017-06-19 18:16:53 --> Router Class Initialized
INFO - 2017-06-19 18:16:53 --> Output Class Initialized
INFO - 2017-06-19 18:16:53 --> Security Class Initialized
DEBUG - 2017-06-19 18:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:16:53 --> Input Class Initialized
INFO - 2017-06-19 18:16:53 --> Language Class Initialized
INFO - 2017-06-19 18:16:53 --> Loader Class Initialized
INFO - 2017-06-19 18:16:53 --> Controller Class Initialized
INFO - 2017-06-19 18:16:53 --> Database Driver Class Initialized
INFO - 2017-06-19 18:16:53 --> Model Class Initialized
INFO - 2017-06-19 18:16:53 --> Helper loaded: form_helper
INFO - 2017-06-19 18:16:53 --> Helper loaded: url_helper
INFO - 2017-06-19 18:16:53 --> Upload Class Initialized
INFO - 2017-06-19 18:16:53 --> Final output sent to browser
DEBUG - 2017-06-19 18:16:53 --> Total execution time: 0.0750
ERROR - 2017-06-19 18:17:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:17:02 --> Config Class Initialized
INFO - 2017-06-19 18:17:02 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:17:02 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:17:02 --> Utf8 Class Initialized
INFO - 2017-06-19 18:17:02 --> URI Class Initialized
INFO - 2017-06-19 18:17:02 --> Router Class Initialized
INFO - 2017-06-19 18:17:02 --> Output Class Initialized
INFO - 2017-06-19 18:17:02 --> Security Class Initialized
DEBUG - 2017-06-19 18:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:17:02 --> Input Class Initialized
INFO - 2017-06-19 18:17:02 --> Language Class Initialized
INFO - 2017-06-19 18:17:02 --> Loader Class Initialized
INFO - 2017-06-19 18:17:02 --> Controller Class Initialized
INFO - 2017-06-19 18:17:02 --> Database Driver Class Initialized
INFO - 2017-06-19 18:17:02 --> Model Class Initialized
INFO - 2017-06-19 18:17:02 --> Helper loaded: form_helper
INFO - 2017-06-19 18:17:02 --> Helper loaded: url_helper
INFO - 2017-06-19 18:17:02 --> Upload Class Initialized
INFO - 2017-06-19 18:17:02 --> Final output sent to browser
DEBUG - 2017-06-19 18:17:02 --> Total execution time: 0.0450
ERROR - 2017-06-19 18:17:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:17:07 --> Config Class Initialized
INFO - 2017-06-19 18:17:07 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:17:07 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:17:07 --> Utf8 Class Initialized
INFO - 2017-06-19 18:17:07 --> URI Class Initialized
INFO - 2017-06-19 18:17:07 --> Router Class Initialized
INFO - 2017-06-19 18:17:07 --> Output Class Initialized
INFO - 2017-06-19 18:17:07 --> Security Class Initialized
DEBUG - 2017-06-19 18:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:17:07 --> Input Class Initialized
INFO - 2017-06-19 18:17:07 --> Language Class Initialized
INFO - 2017-06-19 18:17:07 --> Loader Class Initialized
INFO - 2017-06-19 18:17:07 --> Controller Class Initialized
INFO - 2017-06-19 18:17:07 --> Database Driver Class Initialized
INFO - 2017-06-19 18:17:07 --> Model Class Initialized
INFO - 2017-06-19 18:17:07 --> Helper loaded: form_helper
INFO - 2017-06-19 18:17:07 --> Helper loaded: url_helper
ERROR - 2017-06-19 18:17:07 --> Severity: Notice --> Undefined index: tkeys C:\xampp\htdocs\mystage\application\controllers\Services.php 125
ERROR - 2017-06-19 18:17:07 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\mystage\application\controllers\Services.php 126
INFO - 2017-06-19 18:17:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:17:07 --> Model Class Initialized
INFO - 2017-06-19 18:17:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 18:17:07 --> Final output sent to browser
DEBUG - 2017-06-19 18:17:07 --> Total execution time: 0.2940
ERROR - 2017-06-19 18:17:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:17:51 --> Config Class Initialized
INFO - 2017-06-19 18:17:51 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:17:51 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:17:51 --> Utf8 Class Initialized
INFO - 2017-06-19 18:17:51 --> URI Class Initialized
INFO - 2017-06-19 18:17:51 --> Router Class Initialized
INFO - 2017-06-19 18:17:51 --> Output Class Initialized
INFO - 2017-06-19 18:17:51 --> Security Class Initialized
DEBUG - 2017-06-19 18:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:17:51 --> Input Class Initialized
INFO - 2017-06-19 18:17:51 --> Language Class Initialized
INFO - 2017-06-19 18:17:51 --> Loader Class Initialized
INFO - 2017-06-19 18:17:51 --> Controller Class Initialized
INFO - 2017-06-19 18:17:51 --> Database Driver Class Initialized
INFO - 2017-06-19 18:17:51 --> Model Class Initialized
INFO - 2017-06-19 18:17:51 --> Helper loaded: form_helper
INFO - 2017-06-19 18:17:51 --> Helper loaded: url_helper
INFO - 2017-06-19 18:17:51 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:17:51 --> Model Class Initialized
INFO - 2017-06-19 18:17:51 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 18:17:51 --> Final output sent to browser
DEBUG - 2017-06-19 18:17:51 --> Total execution time: 0.0540
ERROR - 2017-06-19 18:18:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:18:12 --> Config Class Initialized
INFO - 2017-06-19 18:18:12 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:18:12 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:18:12 --> Utf8 Class Initialized
INFO - 2017-06-19 18:18:12 --> URI Class Initialized
INFO - 2017-06-19 18:18:12 --> Router Class Initialized
INFO - 2017-06-19 18:18:12 --> Output Class Initialized
INFO - 2017-06-19 18:18:12 --> Security Class Initialized
DEBUG - 2017-06-19 18:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:18:12 --> Input Class Initialized
INFO - 2017-06-19 18:18:12 --> Language Class Initialized
INFO - 2017-06-19 18:18:12 --> Loader Class Initialized
INFO - 2017-06-19 18:18:12 --> Controller Class Initialized
INFO - 2017-06-19 18:18:12 --> Database Driver Class Initialized
INFO - 2017-06-19 18:18:12 --> Model Class Initialized
INFO - 2017-06-19 18:18:12 --> Helper loaded: form_helper
INFO - 2017-06-19 18:18:12 --> Helper loaded: url_helper
ERROR - 2017-06-19 18:18:12 --> Severity: Notice --> Undefined index: tkeys C:\xampp\htdocs\mystage\application\controllers\Services.php 125
ERROR - 2017-06-19 18:18:12 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\mystage\application\controllers\Services.php 126
INFO - 2017-06-19 18:18:12 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:18:12 --> Model Class Initialized
INFO - 2017-06-19 18:18:12 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 18:18:12 --> Final output sent to browser
DEBUG - 2017-06-19 18:18:12 --> Total execution time: 0.0740
ERROR - 2017-06-19 18:19:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:19:24 --> Config Class Initialized
INFO - 2017-06-19 18:19:24 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:19:24 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:19:24 --> Utf8 Class Initialized
INFO - 2017-06-19 18:19:24 --> URI Class Initialized
INFO - 2017-06-19 18:19:24 --> Router Class Initialized
INFO - 2017-06-19 18:19:24 --> Output Class Initialized
INFO - 2017-06-19 18:19:24 --> Security Class Initialized
DEBUG - 2017-06-19 18:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:19:24 --> Input Class Initialized
INFO - 2017-06-19 18:19:24 --> Language Class Initialized
INFO - 2017-06-19 18:19:24 --> Loader Class Initialized
INFO - 2017-06-19 18:19:24 --> Controller Class Initialized
INFO - 2017-06-19 18:19:24 --> Database Driver Class Initialized
INFO - 2017-06-19 18:19:24 --> Model Class Initialized
INFO - 2017-06-19 18:19:24 --> Helper loaded: form_helper
INFO - 2017-06-19 18:19:24 --> Helper loaded: url_helper
ERROR - 2017-06-19 18:19:24 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\mystage\application\controllers\Services.php 130
INFO - 2017-06-19 18:19:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:19:24 --> Model Class Initialized
INFO - 2017-06-19 18:19:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 18:19:24 --> Final output sent to browser
DEBUG - 2017-06-19 18:19:24 --> Total execution time: 0.0580
ERROR - 2017-06-19 18:19:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:19:40 --> Config Class Initialized
INFO - 2017-06-19 18:19:40 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:19:40 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:19:40 --> Utf8 Class Initialized
INFO - 2017-06-19 18:19:40 --> URI Class Initialized
INFO - 2017-06-19 18:19:40 --> Router Class Initialized
INFO - 2017-06-19 18:19:40 --> Output Class Initialized
INFO - 2017-06-19 18:19:40 --> Security Class Initialized
DEBUG - 2017-06-19 18:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:19:40 --> Input Class Initialized
INFO - 2017-06-19 18:19:40 --> Language Class Initialized
INFO - 2017-06-19 18:19:40 --> Loader Class Initialized
INFO - 2017-06-19 18:19:40 --> Controller Class Initialized
INFO - 2017-06-19 18:19:40 --> Database Driver Class Initialized
INFO - 2017-06-19 18:19:40 --> Model Class Initialized
INFO - 2017-06-19 18:19:41 --> Helper loaded: form_helper
INFO - 2017-06-19 18:19:41 --> Helper loaded: url_helper
INFO - 2017-06-19 18:19:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:19:41 --> Model Class Initialized
INFO - 2017-06-19 18:19:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 18:19:41 --> Final output sent to browser
DEBUG - 2017-06-19 18:19:41 --> Total execution time: 0.0820
ERROR - 2017-06-19 18:19:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:19:43 --> Config Class Initialized
INFO - 2017-06-19 18:19:43 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:19:43 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:19:43 --> Utf8 Class Initialized
INFO - 2017-06-19 18:19:43 --> URI Class Initialized
INFO - 2017-06-19 18:19:43 --> Router Class Initialized
INFO - 2017-06-19 18:19:43 --> Output Class Initialized
INFO - 2017-06-19 18:19:43 --> Security Class Initialized
DEBUG - 2017-06-19 18:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:19:43 --> Input Class Initialized
INFO - 2017-06-19 18:19:43 --> Language Class Initialized
INFO - 2017-06-19 18:19:43 --> Loader Class Initialized
INFO - 2017-06-19 18:19:43 --> Controller Class Initialized
INFO - 2017-06-19 18:19:43 --> Database Driver Class Initialized
INFO - 2017-06-19 18:19:43 --> Model Class Initialized
INFO - 2017-06-19 18:19:43 --> Helper loaded: form_helper
INFO - 2017-06-19 18:19:43 --> Helper loaded: url_helper
INFO - 2017-06-19 18:19:43 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:19:43 --> Model Class Initialized
INFO - 2017-06-19 18:19:43 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 18:19:43 --> Final output sent to browser
DEBUG - 2017-06-19 18:19:43 --> Total execution time: 0.0620
ERROR - 2017-06-19 18:19:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:19:52 --> Config Class Initialized
INFO - 2017-06-19 18:19:52 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:19:52 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:19:52 --> Utf8 Class Initialized
INFO - 2017-06-19 18:19:52 --> URI Class Initialized
INFO - 2017-06-19 18:19:52 --> Router Class Initialized
INFO - 2017-06-19 18:19:52 --> Output Class Initialized
INFO - 2017-06-19 18:19:52 --> Security Class Initialized
DEBUG - 2017-06-19 18:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:19:52 --> Input Class Initialized
INFO - 2017-06-19 18:19:52 --> Language Class Initialized
INFO - 2017-06-19 18:19:52 --> Loader Class Initialized
INFO - 2017-06-19 18:19:52 --> Controller Class Initialized
INFO - 2017-06-19 18:19:52 --> Database Driver Class Initialized
INFO - 2017-06-19 18:19:52 --> Model Class Initialized
INFO - 2017-06-19 18:19:52 --> Helper loaded: form_helper
INFO - 2017-06-19 18:19:52 --> Helper loaded: url_helper
ERROR - 2017-06-19 18:19:52 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\mystage\application\controllers\Services.php 130
INFO - 2017-06-19 18:19:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:19:52 --> Model Class Initialized
INFO - 2017-06-19 18:19:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 18:19:52 --> Final output sent to browser
DEBUG - 2017-06-19 18:19:52 --> Total execution time: 0.0760
ERROR - 2017-06-19 18:21:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:21:24 --> Config Class Initialized
INFO - 2017-06-19 18:21:24 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:21:24 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:21:24 --> Utf8 Class Initialized
INFO - 2017-06-19 18:21:24 --> URI Class Initialized
INFO - 2017-06-19 18:21:24 --> Router Class Initialized
INFO - 2017-06-19 18:21:24 --> Output Class Initialized
INFO - 2017-06-19 18:21:24 --> Security Class Initialized
DEBUG - 2017-06-19 18:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:21:24 --> Input Class Initialized
INFO - 2017-06-19 18:21:24 --> Language Class Initialized
INFO - 2017-06-19 18:21:24 --> Loader Class Initialized
INFO - 2017-06-19 18:21:24 --> Controller Class Initialized
INFO - 2017-06-19 18:21:24 --> Database Driver Class Initialized
INFO - 2017-06-19 18:21:24 --> Model Class Initialized
INFO - 2017-06-19 18:21:24 --> Helper loaded: form_helper
INFO - 2017-06-19 18:21:24 --> Helper loaded: url_helper
INFO - 2017-06-19 18:21:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:21:24 --> Model Class Initialized
INFO - 2017-06-19 18:21:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 18:21:24 --> Final output sent to browser
DEBUG - 2017-06-19 18:21:24 --> Total execution time: 0.0520
ERROR - 2017-06-19 18:21:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:21:47 --> Config Class Initialized
INFO - 2017-06-19 18:21:47 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:21:47 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:21:47 --> Utf8 Class Initialized
INFO - 2017-06-19 18:21:47 --> URI Class Initialized
INFO - 2017-06-19 18:21:47 --> Router Class Initialized
INFO - 2017-06-19 18:21:47 --> Output Class Initialized
INFO - 2017-06-19 18:21:47 --> Security Class Initialized
DEBUG - 2017-06-19 18:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:21:47 --> Input Class Initialized
INFO - 2017-06-19 18:21:47 --> Language Class Initialized
INFO - 2017-06-19 18:21:47 --> Loader Class Initialized
INFO - 2017-06-19 18:21:47 --> Controller Class Initialized
INFO - 2017-06-19 18:21:47 --> Database Driver Class Initialized
INFO - 2017-06-19 18:21:47 --> Model Class Initialized
INFO - 2017-06-19 18:21:47 --> Helper loaded: form_helper
INFO - 2017-06-19 18:21:47 --> Helper loaded: url_helper
INFO - 2017-06-19 18:21:47 --> Upload Class Initialized
INFO - 2017-06-19 18:21:47 --> Final output sent to browser
DEBUG - 2017-06-19 18:21:47 --> Total execution time: 0.0670
ERROR - 2017-06-19 18:21:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:21:51 --> Config Class Initialized
INFO - 2017-06-19 18:21:51 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:21:51 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:21:51 --> Utf8 Class Initialized
INFO - 2017-06-19 18:21:51 --> URI Class Initialized
INFO - 2017-06-19 18:21:51 --> Router Class Initialized
INFO - 2017-06-19 18:21:51 --> Output Class Initialized
INFO - 2017-06-19 18:21:51 --> Security Class Initialized
DEBUG - 2017-06-19 18:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:21:51 --> Input Class Initialized
INFO - 2017-06-19 18:21:51 --> Language Class Initialized
INFO - 2017-06-19 18:21:51 --> Loader Class Initialized
INFO - 2017-06-19 18:21:51 --> Controller Class Initialized
INFO - 2017-06-19 18:21:51 --> Database Driver Class Initialized
INFO - 2017-06-19 18:21:51 --> Model Class Initialized
INFO - 2017-06-19 18:21:51 --> Helper loaded: form_helper
INFO - 2017-06-19 18:21:51 --> Helper loaded: url_helper
INFO - 2017-06-19 18:21:51 --> Upload Class Initialized
INFO - 2017-06-19 18:21:51 --> Final output sent to browser
DEBUG - 2017-06-19 18:21:51 --> Total execution time: 0.0530
ERROR - 2017-06-19 18:22:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:22:02 --> Config Class Initialized
INFO - 2017-06-19 18:22:02 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:22:02 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:22:02 --> Utf8 Class Initialized
INFO - 2017-06-19 18:22:02 --> URI Class Initialized
INFO - 2017-06-19 18:22:02 --> Router Class Initialized
INFO - 2017-06-19 18:22:02 --> Output Class Initialized
INFO - 2017-06-19 18:22:02 --> Security Class Initialized
DEBUG - 2017-06-19 18:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:22:02 --> Input Class Initialized
INFO - 2017-06-19 18:22:02 --> Language Class Initialized
INFO - 2017-06-19 18:22:02 --> Loader Class Initialized
INFO - 2017-06-19 18:22:02 --> Controller Class Initialized
INFO - 2017-06-19 18:22:02 --> Database Driver Class Initialized
INFO - 2017-06-19 18:22:02 --> Model Class Initialized
INFO - 2017-06-19 18:22:02 --> Helper loaded: form_helper
INFO - 2017-06-19 18:22:02 --> Helper loaded: url_helper
INFO - 2017-06-19 18:22:02 --> Upload Class Initialized
INFO - 2017-06-19 18:22:02 --> Final output sent to browser
DEBUG - 2017-06-19 18:22:02 --> Total execution time: 0.0560
ERROR - 2017-06-19 18:22:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:22:02 --> Config Class Initialized
INFO - 2017-06-19 18:22:02 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:22:02 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:22:02 --> Utf8 Class Initialized
INFO - 2017-06-19 18:22:02 --> URI Class Initialized
INFO - 2017-06-19 18:22:02 --> Router Class Initialized
INFO - 2017-06-19 18:22:02 --> Output Class Initialized
INFO - 2017-06-19 18:22:02 --> Security Class Initialized
DEBUG - 2017-06-19 18:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:22:02 --> Input Class Initialized
INFO - 2017-06-19 18:22:02 --> Language Class Initialized
INFO - 2017-06-19 18:22:02 --> Loader Class Initialized
INFO - 2017-06-19 18:22:02 --> Controller Class Initialized
INFO - 2017-06-19 18:22:02 --> Database Driver Class Initialized
INFO - 2017-06-19 18:22:02 --> Model Class Initialized
INFO - 2017-06-19 18:22:02 --> Helper loaded: form_helper
INFO - 2017-06-19 18:22:02 --> Helper loaded: url_helper
INFO - 2017-06-19 18:22:02 --> Upload Class Initialized
INFO - 2017-06-19 18:22:02 --> Final output sent to browser
DEBUG - 2017-06-19 18:22:02 --> Total execution time: 0.0540
ERROR - 2017-06-19 18:22:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:22:02 --> Config Class Initialized
INFO - 2017-06-19 18:22:02 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:22:02 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:22:02 --> Utf8 Class Initialized
INFO - 2017-06-19 18:22:02 --> URI Class Initialized
INFO - 2017-06-19 18:22:02 --> Router Class Initialized
INFO - 2017-06-19 18:22:02 --> Output Class Initialized
INFO - 2017-06-19 18:22:02 --> Security Class Initialized
DEBUG - 2017-06-19 18:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:22:02 --> Input Class Initialized
INFO - 2017-06-19 18:22:02 --> Language Class Initialized
INFO - 2017-06-19 18:22:02 --> Loader Class Initialized
INFO - 2017-06-19 18:22:02 --> Controller Class Initialized
INFO - 2017-06-19 18:22:02 --> Database Driver Class Initialized
INFO - 2017-06-19 18:22:02 --> Model Class Initialized
INFO - 2017-06-19 18:22:02 --> Helper loaded: form_helper
INFO - 2017-06-19 18:22:02 --> Helper loaded: url_helper
INFO - 2017-06-19 18:22:02 --> Upload Class Initialized
INFO - 2017-06-19 18:22:02 --> Final output sent to browser
DEBUG - 2017-06-19 18:22:02 --> Total execution time: 0.0550
ERROR - 2017-06-19 18:22:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:22:02 --> Config Class Initialized
INFO - 2017-06-19 18:22:02 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:22:02 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:22:02 --> Utf8 Class Initialized
INFO - 2017-06-19 18:22:02 --> URI Class Initialized
INFO - 2017-06-19 18:22:02 --> Router Class Initialized
INFO - 2017-06-19 18:22:02 --> Output Class Initialized
INFO - 2017-06-19 18:22:02 --> Security Class Initialized
DEBUG - 2017-06-19 18:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:22:02 --> Input Class Initialized
INFO - 2017-06-19 18:22:02 --> Language Class Initialized
INFO - 2017-06-19 18:22:02 --> Loader Class Initialized
INFO - 2017-06-19 18:22:02 --> Controller Class Initialized
INFO - 2017-06-19 18:22:02 --> Database Driver Class Initialized
INFO - 2017-06-19 18:22:02 --> Model Class Initialized
INFO - 2017-06-19 18:22:02 --> Helper loaded: form_helper
INFO - 2017-06-19 18:22:02 --> Helper loaded: url_helper
INFO - 2017-06-19 18:22:02 --> Upload Class Initialized
INFO - 2017-06-19 18:22:02 --> Final output sent to browser
DEBUG - 2017-06-19 18:22:02 --> Total execution time: 0.0530
ERROR - 2017-06-19 18:22:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:22:03 --> Config Class Initialized
INFO - 2017-06-19 18:22:03 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:22:03 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:22:03 --> Utf8 Class Initialized
INFO - 2017-06-19 18:22:03 --> URI Class Initialized
INFO - 2017-06-19 18:22:03 --> Router Class Initialized
INFO - 2017-06-19 18:22:03 --> Output Class Initialized
INFO - 2017-06-19 18:22:03 --> Security Class Initialized
DEBUG - 2017-06-19 18:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:22:03 --> Input Class Initialized
INFO - 2017-06-19 18:22:03 --> Language Class Initialized
INFO - 2017-06-19 18:22:03 --> Loader Class Initialized
INFO - 2017-06-19 18:22:03 --> Controller Class Initialized
INFO - 2017-06-19 18:22:03 --> Database Driver Class Initialized
INFO - 2017-06-19 18:22:03 --> Model Class Initialized
INFO - 2017-06-19 18:22:03 --> Helper loaded: form_helper
INFO - 2017-06-19 18:22:03 --> Helper loaded: url_helper
INFO - 2017-06-19 18:22:03 --> Upload Class Initialized
INFO - 2017-06-19 18:22:03 --> Final output sent to browser
DEBUG - 2017-06-19 18:22:03 --> Total execution time: 0.0520
ERROR - 2017-06-19 18:22:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:22:03 --> Config Class Initialized
INFO - 2017-06-19 18:22:03 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:22:03 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:22:03 --> Utf8 Class Initialized
INFO - 2017-06-19 18:22:03 --> URI Class Initialized
INFO - 2017-06-19 18:22:03 --> Router Class Initialized
INFO - 2017-06-19 18:22:03 --> Output Class Initialized
INFO - 2017-06-19 18:22:03 --> Security Class Initialized
DEBUG - 2017-06-19 18:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:22:03 --> Input Class Initialized
INFO - 2017-06-19 18:22:03 --> Language Class Initialized
INFO - 2017-06-19 18:22:03 --> Loader Class Initialized
INFO - 2017-06-19 18:22:03 --> Controller Class Initialized
INFO - 2017-06-19 18:22:03 --> Database Driver Class Initialized
INFO - 2017-06-19 18:22:03 --> Model Class Initialized
INFO - 2017-06-19 18:22:03 --> Helper loaded: form_helper
INFO - 2017-06-19 18:22:03 --> Helper loaded: url_helper
INFO - 2017-06-19 18:22:03 --> Upload Class Initialized
INFO - 2017-06-19 18:22:03 --> Final output sent to browser
DEBUG - 2017-06-19 18:22:03 --> Total execution time: 0.0610
ERROR - 2017-06-19 18:22:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:22:03 --> Config Class Initialized
INFO - 2017-06-19 18:22:03 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:22:03 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:22:03 --> Utf8 Class Initialized
INFO - 2017-06-19 18:22:03 --> URI Class Initialized
INFO - 2017-06-19 18:22:03 --> Router Class Initialized
INFO - 2017-06-19 18:22:03 --> Output Class Initialized
INFO - 2017-06-19 18:22:03 --> Security Class Initialized
DEBUG - 2017-06-19 18:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:22:03 --> Input Class Initialized
INFO - 2017-06-19 18:22:03 --> Language Class Initialized
INFO - 2017-06-19 18:22:03 --> Loader Class Initialized
INFO - 2017-06-19 18:22:03 --> Controller Class Initialized
INFO - 2017-06-19 18:22:03 --> Database Driver Class Initialized
INFO - 2017-06-19 18:22:03 --> Model Class Initialized
INFO - 2017-06-19 18:22:03 --> Helper loaded: form_helper
INFO - 2017-06-19 18:22:03 --> Helper loaded: url_helper
INFO - 2017-06-19 18:22:03 --> Upload Class Initialized
INFO - 2017-06-19 18:22:03 --> Final output sent to browser
DEBUG - 2017-06-19 18:22:03 --> Total execution time: 0.0510
ERROR - 2017-06-19 18:22:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:22:18 --> Config Class Initialized
INFO - 2017-06-19 18:22:18 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:22:18 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:22:18 --> Utf8 Class Initialized
INFO - 2017-06-19 18:22:18 --> URI Class Initialized
INFO - 2017-06-19 18:22:18 --> Router Class Initialized
INFO - 2017-06-19 18:22:18 --> Output Class Initialized
INFO - 2017-06-19 18:22:18 --> Security Class Initialized
DEBUG - 2017-06-19 18:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:22:18 --> Input Class Initialized
INFO - 2017-06-19 18:22:18 --> Language Class Initialized
INFO - 2017-06-19 18:22:18 --> Loader Class Initialized
INFO - 2017-06-19 18:22:18 --> Controller Class Initialized
INFO - 2017-06-19 18:22:18 --> Database Driver Class Initialized
INFO - 2017-06-19 18:22:18 --> Model Class Initialized
INFO - 2017-06-19 18:22:18 --> Helper loaded: form_helper
INFO - 2017-06-19 18:22:18 --> Helper loaded: url_helper
INFO - 2017-06-19 18:22:18 --> Upload Class Initialized
INFO - 2017-06-19 18:22:18 --> Final output sent to browser
DEBUG - 2017-06-19 18:22:18 --> Total execution time: 0.0490
ERROR - 2017-06-19 18:22:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:22:18 --> Config Class Initialized
INFO - 2017-06-19 18:22:18 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:22:18 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:22:18 --> Utf8 Class Initialized
INFO - 2017-06-19 18:22:18 --> URI Class Initialized
INFO - 2017-06-19 18:22:18 --> Router Class Initialized
INFO - 2017-06-19 18:22:18 --> Output Class Initialized
INFO - 2017-06-19 18:22:18 --> Security Class Initialized
DEBUG - 2017-06-19 18:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:22:18 --> Input Class Initialized
INFO - 2017-06-19 18:22:18 --> Language Class Initialized
INFO - 2017-06-19 18:22:18 --> Loader Class Initialized
INFO - 2017-06-19 18:22:18 --> Controller Class Initialized
INFO - 2017-06-19 18:22:18 --> Database Driver Class Initialized
INFO - 2017-06-19 18:22:18 --> Model Class Initialized
INFO - 2017-06-19 18:22:18 --> Helper loaded: form_helper
INFO - 2017-06-19 18:22:18 --> Helper loaded: url_helper
INFO - 2017-06-19 18:22:18 --> Upload Class Initialized
INFO - 2017-06-19 18:22:18 --> Final output sent to browser
DEBUG - 2017-06-19 18:22:18 --> Total execution time: 0.0520
ERROR - 2017-06-19 18:22:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:22:18 --> Config Class Initialized
INFO - 2017-06-19 18:22:18 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:22:18 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:22:18 --> Utf8 Class Initialized
INFO - 2017-06-19 18:22:18 --> URI Class Initialized
INFO - 2017-06-19 18:22:18 --> Router Class Initialized
INFO - 2017-06-19 18:22:18 --> Output Class Initialized
INFO - 2017-06-19 18:22:18 --> Security Class Initialized
DEBUG - 2017-06-19 18:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:22:18 --> Input Class Initialized
INFO - 2017-06-19 18:22:18 --> Language Class Initialized
INFO - 2017-06-19 18:22:18 --> Loader Class Initialized
INFO - 2017-06-19 18:22:18 --> Controller Class Initialized
INFO - 2017-06-19 18:22:18 --> Database Driver Class Initialized
INFO - 2017-06-19 18:22:18 --> Model Class Initialized
INFO - 2017-06-19 18:22:18 --> Helper loaded: form_helper
INFO - 2017-06-19 18:22:18 --> Helper loaded: url_helper
INFO - 2017-06-19 18:22:18 --> Upload Class Initialized
INFO - 2017-06-19 18:22:18 --> Final output sent to browser
DEBUG - 2017-06-19 18:22:18 --> Total execution time: 0.0535
ERROR - 2017-06-19 18:22:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:22:22 --> Config Class Initialized
INFO - 2017-06-19 18:22:22 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:22:22 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:22:22 --> Utf8 Class Initialized
INFO - 2017-06-19 18:22:22 --> URI Class Initialized
INFO - 2017-06-19 18:22:22 --> Router Class Initialized
INFO - 2017-06-19 18:22:22 --> Output Class Initialized
INFO - 2017-06-19 18:22:22 --> Security Class Initialized
DEBUG - 2017-06-19 18:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:22:22 --> Input Class Initialized
INFO - 2017-06-19 18:22:22 --> Language Class Initialized
INFO - 2017-06-19 18:22:22 --> Loader Class Initialized
INFO - 2017-06-19 18:22:22 --> Controller Class Initialized
INFO - 2017-06-19 18:22:22 --> Database Driver Class Initialized
INFO - 2017-06-19 18:22:22 --> Model Class Initialized
INFO - 2017-06-19 18:22:22 --> Helper loaded: form_helper
INFO - 2017-06-19 18:22:22 --> Helper loaded: url_helper
INFO - 2017-06-19 18:22:22 --> Model Class Initialized
INFO - 2017-06-19 18:22:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:22:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 18:22:22 --> Final output sent to browser
DEBUG - 2017-06-19 18:22:22 --> Total execution time: 0.5330
ERROR - 2017-06-19 18:22:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:22:24 --> Config Class Initialized
INFO - 2017-06-19 18:22:24 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:22:24 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:22:24 --> Utf8 Class Initialized
INFO - 2017-06-19 18:22:24 --> URI Class Initialized
INFO - 2017-06-19 18:22:24 --> Router Class Initialized
INFO - 2017-06-19 18:22:24 --> Output Class Initialized
INFO - 2017-06-19 18:22:24 --> Security Class Initialized
DEBUG - 2017-06-19 18:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:22:24 --> Input Class Initialized
INFO - 2017-06-19 18:22:24 --> Language Class Initialized
INFO - 2017-06-19 18:22:24 --> Loader Class Initialized
INFO - 2017-06-19 18:22:24 --> Controller Class Initialized
INFO - 2017-06-19 18:22:24 --> Database Driver Class Initialized
INFO - 2017-06-19 18:22:24 --> Model Class Initialized
INFO - 2017-06-19 18:22:24 --> Helper loaded: form_helper
INFO - 2017-06-19 18:22:24 --> Helper loaded: url_helper
INFO - 2017-06-19 18:22:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:22:24 --> Model Class Initialized
INFO - 2017-06-19 18:22:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-19 18:22:24 --> Final output sent to browser
DEBUG - 2017-06-19 18:22:24 --> Total execution time: 0.0950
ERROR - 2017-06-19 18:22:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 18:22:27 --> Config Class Initialized
INFO - 2017-06-19 18:22:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 18:22:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 18:22:27 --> Utf8 Class Initialized
INFO - 2017-06-19 18:22:27 --> URI Class Initialized
INFO - 2017-06-19 18:22:27 --> Router Class Initialized
INFO - 2017-06-19 18:22:27 --> Output Class Initialized
INFO - 2017-06-19 18:22:27 --> Security Class Initialized
DEBUG - 2017-06-19 18:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 18:22:27 --> Input Class Initialized
INFO - 2017-06-19 18:22:27 --> Language Class Initialized
INFO - 2017-06-19 18:22:27 --> Loader Class Initialized
INFO - 2017-06-19 18:22:27 --> Controller Class Initialized
INFO - 2017-06-19 18:22:27 --> Database Driver Class Initialized
INFO - 2017-06-19 18:22:27 --> Model Class Initialized
INFO - 2017-06-19 18:22:27 --> Helper loaded: form_helper
INFO - 2017-06-19 18:22:27 --> Helper loaded: url_helper
INFO - 2017-06-19 18:22:27 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 18:22:27 --> Model Class Initialized
INFO - 2017-06-19 18:22:27 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 18:22:27 --> Final output sent to browser
DEBUG - 2017-06-19 18:22:27 --> Total execution time: 0.0550
ERROR - 2017-06-19 19:05:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:05:56 --> Config Class Initialized
INFO - 2017-06-19 19:05:56 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:05:56 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:05:56 --> Utf8 Class Initialized
INFO - 2017-06-19 19:05:56 --> URI Class Initialized
INFO - 2017-06-19 19:05:56 --> Router Class Initialized
INFO - 2017-06-19 19:05:56 --> Output Class Initialized
INFO - 2017-06-19 19:05:56 --> Security Class Initialized
DEBUG - 2017-06-19 19:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:05:56 --> Input Class Initialized
INFO - 2017-06-19 19:05:56 --> Language Class Initialized
ERROR - 2017-06-19 19:05:56 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\mystage\application\controllers\Services.php 147
ERROR - 2017-06-19 19:06:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:06:14 --> Config Class Initialized
INFO - 2017-06-19 19:06:14 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:06:14 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:06:14 --> Utf8 Class Initialized
INFO - 2017-06-19 19:06:14 --> URI Class Initialized
INFO - 2017-06-19 19:06:14 --> Router Class Initialized
INFO - 2017-06-19 19:06:14 --> Output Class Initialized
INFO - 2017-06-19 19:06:14 --> Security Class Initialized
DEBUG - 2017-06-19 19:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:06:14 --> Input Class Initialized
INFO - 2017-06-19 19:06:14 --> Language Class Initialized
INFO - 2017-06-19 19:06:14 --> Loader Class Initialized
INFO - 2017-06-19 19:06:14 --> Controller Class Initialized
INFO - 2017-06-19 19:06:14 --> Database Driver Class Initialized
INFO - 2017-06-19 19:06:14 --> Model Class Initialized
INFO - 2017-06-19 19:06:14 --> Helper loaded: form_helper
INFO - 2017-06-19 19:06:14 --> Helper loaded: url_helper
INFO - 2017-06-19 19:06:14 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:06:14 --> Model Class Initialized
INFO - 2017-06-19 19:06:14 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 19:06:14 --> Final output sent to browser
DEBUG - 2017-06-19 19:06:14 --> Total execution time: 0.0810
ERROR - 2017-06-19 19:06:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:06:16 --> Config Class Initialized
INFO - 2017-06-19 19:06:16 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:06:16 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:06:16 --> Utf8 Class Initialized
INFO - 2017-06-19 19:06:16 --> URI Class Initialized
INFO - 2017-06-19 19:06:16 --> Router Class Initialized
INFO - 2017-06-19 19:06:16 --> Output Class Initialized
INFO - 2017-06-19 19:06:16 --> Security Class Initialized
DEBUG - 2017-06-19 19:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:06:16 --> Input Class Initialized
INFO - 2017-06-19 19:06:16 --> Language Class Initialized
INFO - 2017-06-19 19:06:16 --> Loader Class Initialized
INFO - 2017-06-19 19:06:16 --> Controller Class Initialized
INFO - 2017-06-19 19:06:16 --> Database Driver Class Initialized
INFO - 2017-06-19 19:06:16 --> Model Class Initialized
INFO - 2017-06-19 19:06:16 --> Helper loaded: form_helper
INFO - 2017-06-19 19:06:16 --> Helper loaded: url_helper
INFO - 2017-06-19 19:06:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:06:16 --> Model Class Initialized
INFO - 2017-06-19 19:06:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-19 19:06:16 --> Final output sent to browser
DEBUG - 2017-06-19 19:06:16 --> Total execution time: 0.0610
ERROR - 2017-06-19 19:06:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:06:20 --> Config Class Initialized
INFO - 2017-06-19 19:06:20 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:06:20 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:06:20 --> Utf8 Class Initialized
INFO - 2017-06-19 19:06:20 --> URI Class Initialized
INFO - 2017-06-19 19:06:20 --> Router Class Initialized
INFO - 2017-06-19 19:06:20 --> Output Class Initialized
INFO - 2017-06-19 19:06:20 --> Security Class Initialized
DEBUG - 2017-06-19 19:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:06:20 --> Input Class Initialized
INFO - 2017-06-19 19:06:20 --> Language Class Initialized
INFO - 2017-06-19 19:06:20 --> Loader Class Initialized
INFO - 2017-06-19 19:06:20 --> Controller Class Initialized
INFO - 2017-06-19 19:06:20 --> Database Driver Class Initialized
INFO - 2017-06-19 19:06:20 --> Model Class Initialized
INFO - 2017-06-19 19:06:20 --> Helper loaded: form_helper
INFO - 2017-06-19 19:06:20 --> Helper loaded: url_helper
INFO - 2017-06-19 19:06:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:06:20 --> Model Class Initialized
INFO - 2017-06-19 19:06:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 19:06:20 --> Final output sent to browser
DEBUG - 2017-06-19 19:06:20 --> Total execution time: 0.0630
ERROR - 2017-06-19 19:06:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:06:30 --> Config Class Initialized
INFO - 2017-06-19 19:06:30 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:06:30 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:06:30 --> Utf8 Class Initialized
INFO - 2017-06-19 19:06:30 --> URI Class Initialized
INFO - 2017-06-19 19:06:30 --> Router Class Initialized
INFO - 2017-06-19 19:06:30 --> Output Class Initialized
INFO - 2017-06-19 19:06:30 --> Security Class Initialized
DEBUG - 2017-06-19 19:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:06:30 --> Input Class Initialized
INFO - 2017-06-19 19:06:30 --> Language Class Initialized
INFO - 2017-06-19 19:06:30 --> Loader Class Initialized
INFO - 2017-06-19 19:06:30 --> Controller Class Initialized
INFO - 2017-06-19 19:06:30 --> Database Driver Class Initialized
INFO - 2017-06-19 19:06:30 --> Model Class Initialized
INFO - 2017-06-19 19:06:30 --> Helper loaded: form_helper
INFO - 2017-06-19 19:06:30 --> Helper loaded: url_helper
INFO - 2017-06-19 19:06:30 --> Upload Class Initialized
INFO - 2017-06-19 19:06:30 --> Final output sent to browser
DEBUG - 2017-06-19 19:06:30 --> Total execution time: 0.0790
ERROR - 2017-06-19 19:06:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:06:32 --> Config Class Initialized
INFO - 2017-06-19 19:06:32 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:06:33 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:06:33 --> Utf8 Class Initialized
INFO - 2017-06-19 19:06:33 --> URI Class Initialized
INFO - 2017-06-19 19:06:33 --> Router Class Initialized
INFO - 2017-06-19 19:06:33 --> Output Class Initialized
INFO - 2017-06-19 19:06:33 --> Security Class Initialized
DEBUG - 2017-06-19 19:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:06:33 --> Input Class Initialized
INFO - 2017-06-19 19:06:33 --> Language Class Initialized
INFO - 2017-06-19 19:06:33 --> Loader Class Initialized
INFO - 2017-06-19 19:06:33 --> Controller Class Initialized
INFO - 2017-06-19 19:06:33 --> Database Driver Class Initialized
INFO - 2017-06-19 19:06:33 --> Model Class Initialized
INFO - 2017-06-19 19:06:33 --> Helper loaded: form_helper
INFO - 2017-06-19 19:06:33 --> Helper loaded: url_helper
ERROR - 2017-06-19 19:06:33 --> Severity: Notice --> Undefined variable: active C:\xampp\htdocs\mystage\application\controllers\Services.php 145
INFO - 2017-06-19 19:06:33 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:06:33 --> Model Class Initialized
INFO - 2017-06-19 19:06:33 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 19:06:33 --> Final output sent to browser
DEBUG - 2017-06-19 19:06:33 --> Total execution time: 0.0760
ERROR - 2017-06-19 19:07:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:07:16 --> Config Class Initialized
INFO - 2017-06-19 19:07:16 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:07:16 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:07:16 --> Utf8 Class Initialized
INFO - 2017-06-19 19:07:16 --> URI Class Initialized
INFO - 2017-06-19 19:07:16 --> Router Class Initialized
INFO - 2017-06-19 19:07:16 --> Output Class Initialized
INFO - 2017-06-19 19:07:16 --> Security Class Initialized
DEBUG - 2017-06-19 19:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:07:16 --> Input Class Initialized
INFO - 2017-06-19 19:07:16 --> Language Class Initialized
INFO - 2017-06-19 19:07:16 --> Loader Class Initialized
INFO - 2017-06-19 19:07:16 --> Controller Class Initialized
INFO - 2017-06-19 19:07:16 --> Database Driver Class Initialized
INFO - 2017-06-19 19:07:16 --> Model Class Initialized
INFO - 2017-06-19 19:07:16 --> Helper loaded: form_helper
INFO - 2017-06-19 19:07:16 --> Helper loaded: url_helper
INFO - 2017-06-19 19:07:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:07:16 --> Model Class Initialized
INFO - 2017-06-19 19:07:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 19:07:16 --> Final output sent to browser
DEBUG - 2017-06-19 19:07:16 --> Total execution time: 0.0640
ERROR - 2017-06-19 19:07:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:07:30 --> Config Class Initialized
INFO - 2017-06-19 19:07:30 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:07:30 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:07:30 --> Utf8 Class Initialized
INFO - 2017-06-19 19:07:30 --> URI Class Initialized
INFO - 2017-06-19 19:07:30 --> Router Class Initialized
INFO - 2017-06-19 19:07:30 --> Output Class Initialized
INFO - 2017-06-19 19:07:30 --> Security Class Initialized
DEBUG - 2017-06-19 19:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:07:30 --> Input Class Initialized
INFO - 2017-06-19 19:07:30 --> Language Class Initialized
INFO - 2017-06-19 19:07:30 --> Loader Class Initialized
INFO - 2017-06-19 19:07:30 --> Controller Class Initialized
INFO - 2017-06-19 19:07:30 --> Database Driver Class Initialized
INFO - 2017-06-19 19:07:30 --> Model Class Initialized
INFO - 2017-06-19 19:07:30 --> Helper loaded: form_helper
INFO - 2017-06-19 19:07:30 --> Helper loaded: url_helper
INFO - 2017-06-19 19:07:30 --> Upload Class Initialized
INFO - 2017-06-19 19:07:30 --> Final output sent to browser
DEBUG - 2017-06-19 19:07:30 --> Total execution time: 0.0530
ERROR - 2017-06-19 19:07:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:07:33 --> Config Class Initialized
INFO - 2017-06-19 19:07:33 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:07:33 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:07:33 --> Utf8 Class Initialized
INFO - 2017-06-19 19:07:33 --> URI Class Initialized
INFO - 2017-06-19 19:07:33 --> Router Class Initialized
INFO - 2017-06-19 19:07:33 --> Output Class Initialized
INFO - 2017-06-19 19:07:33 --> Security Class Initialized
DEBUG - 2017-06-19 19:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:07:33 --> Input Class Initialized
INFO - 2017-06-19 19:07:33 --> Language Class Initialized
INFO - 2017-06-19 19:07:33 --> Loader Class Initialized
INFO - 2017-06-19 19:07:33 --> Controller Class Initialized
INFO - 2017-06-19 19:07:33 --> Database Driver Class Initialized
INFO - 2017-06-19 19:07:33 --> Model Class Initialized
INFO - 2017-06-19 19:07:33 --> Helper loaded: form_helper
INFO - 2017-06-19 19:07:33 --> Helper loaded: url_helper
INFO - 2017-06-19 19:07:33 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:07:33 --> Model Class Initialized
INFO - 2017-06-19 19:07:33 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 19:07:33 --> Final output sent to browser
DEBUG - 2017-06-19 19:07:33 --> Total execution time: 0.0490
ERROR - 2017-06-19 19:10:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:10:10 --> Config Class Initialized
INFO - 2017-06-19 19:10:10 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:10:10 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:10:10 --> Utf8 Class Initialized
INFO - 2017-06-19 19:10:10 --> URI Class Initialized
INFO - 2017-06-19 19:10:10 --> Router Class Initialized
INFO - 2017-06-19 19:10:10 --> Output Class Initialized
INFO - 2017-06-19 19:10:10 --> Security Class Initialized
DEBUG - 2017-06-19 19:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:10:10 --> Input Class Initialized
INFO - 2017-06-19 19:10:10 --> Language Class Initialized
INFO - 2017-06-19 19:10:10 --> Loader Class Initialized
INFO - 2017-06-19 19:10:10 --> Controller Class Initialized
INFO - 2017-06-19 19:10:10 --> Database Driver Class Initialized
INFO - 2017-06-19 19:10:10 --> Model Class Initialized
INFO - 2017-06-19 19:10:10 --> Helper loaded: form_helper
INFO - 2017-06-19 19:10:10 --> Helper loaded: url_helper
INFO - 2017-06-19 19:10:10 --> Upload Class Initialized
INFO - 2017-06-19 19:10:10 --> Final output sent to browser
DEBUG - 2017-06-19 19:10:10 --> Total execution time: 0.0650
ERROR - 2017-06-19 19:10:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:10:27 --> Config Class Initialized
INFO - 2017-06-19 19:10:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:10:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:10:27 --> Utf8 Class Initialized
INFO - 2017-06-19 19:10:27 --> URI Class Initialized
INFO - 2017-06-19 19:10:27 --> Router Class Initialized
INFO - 2017-06-19 19:10:27 --> Output Class Initialized
INFO - 2017-06-19 19:10:27 --> Security Class Initialized
DEBUG - 2017-06-19 19:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:10:27 --> Input Class Initialized
INFO - 2017-06-19 19:10:27 --> Language Class Initialized
INFO - 2017-06-19 19:10:27 --> Loader Class Initialized
INFO - 2017-06-19 19:10:27 --> Controller Class Initialized
INFO - 2017-06-19 19:10:27 --> Database Driver Class Initialized
INFO - 2017-06-19 19:10:27 --> Model Class Initialized
INFO - 2017-06-19 19:10:27 --> Helper loaded: form_helper
INFO - 2017-06-19 19:10:27 --> Helper loaded: url_helper
INFO - 2017-06-19 19:10:27 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:10:27 --> Model Class Initialized
INFO - 2017-06-19 19:10:27 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 19:10:27 --> Final output sent to browser
DEBUG - 2017-06-19 19:10:27 --> Total execution time: 0.0500
ERROR - 2017-06-19 19:10:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:10:45 --> Config Class Initialized
INFO - 2017-06-19 19:10:45 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:10:45 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:10:45 --> Utf8 Class Initialized
INFO - 2017-06-19 19:10:45 --> URI Class Initialized
INFO - 2017-06-19 19:10:45 --> Router Class Initialized
INFO - 2017-06-19 19:10:45 --> Output Class Initialized
INFO - 2017-06-19 19:10:45 --> Security Class Initialized
DEBUG - 2017-06-19 19:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:10:45 --> Input Class Initialized
INFO - 2017-06-19 19:10:45 --> Language Class Initialized
INFO - 2017-06-19 19:10:45 --> Loader Class Initialized
INFO - 2017-06-19 19:10:45 --> Controller Class Initialized
INFO - 2017-06-19 19:10:45 --> Database Driver Class Initialized
INFO - 2017-06-19 19:10:45 --> Model Class Initialized
INFO - 2017-06-19 19:10:45 --> Helper loaded: form_helper
INFO - 2017-06-19 19:10:45 --> Helper loaded: url_helper
INFO - 2017-06-19 19:10:45 --> Upload Class Initialized
INFO - 2017-06-19 19:10:45 --> Final output sent to browser
DEBUG - 2017-06-19 19:10:45 --> Total execution time: 0.0530
ERROR - 2017-06-19 19:10:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:10:57 --> Config Class Initialized
INFO - 2017-06-19 19:10:57 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:10:57 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:10:57 --> Utf8 Class Initialized
INFO - 2017-06-19 19:10:57 --> URI Class Initialized
INFO - 2017-06-19 19:10:57 --> Router Class Initialized
INFO - 2017-06-19 19:10:57 --> Output Class Initialized
INFO - 2017-06-19 19:10:57 --> Security Class Initialized
DEBUG - 2017-06-19 19:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:10:57 --> Input Class Initialized
INFO - 2017-06-19 19:10:57 --> Language Class Initialized
INFO - 2017-06-19 19:10:57 --> Loader Class Initialized
INFO - 2017-06-19 19:10:57 --> Controller Class Initialized
INFO - 2017-06-19 19:10:57 --> Database Driver Class Initialized
INFO - 2017-06-19 19:10:57 --> Model Class Initialized
INFO - 2017-06-19 19:10:57 --> Helper loaded: form_helper
INFO - 2017-06-19 19:10:57 --> Helper loaded: url_helper
INFO - 2017-06-19 19:10:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:10:57 --> Model Class Initialized
INFO - 2017-06-19 19:10:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 19:10:57 --> Final output sent to browser
DEBUG - 2017-06-19 19:10:57 --> Total execution time: 0.0620
ERROR - 2017-06-19 19:11:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:11:00 --> Config Class Initialized
INFO - 2017-06-19 19:11:00 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:11:00 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:11:00 --> Utf8 Class Initialized
INFO - 2017-06-19 19:11:00 --> URI Class Initialized
INFO - 2017-06-19 19:11:00 --> Router Class Initialized
INFO - 2017-06-19 19:11:00 --> Output Class Initialized
INFO - 2017-06-19 19:11:00 --> Security Class Initialized
DEBUG - 2017-06-19 19:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:11:00 --> Input Class Initialized
INFO - 2017-06-19 19:11:00 --> Language Class Initialized
INFO - 2017-06-19 19:11:00 --> Loader Class Initialized
INFO - 2017-06-19 19:11:00 --> Controller Class Initialized
INFO - 2017-06-19 19:11:00 --> Database Driver Class Initialized
INFO - 2017-06-19 19:11:00 --> Model Class Initialized
INFO - 2017-06-19 19:11:00 --> Helper loaded: form_helper
INFO - 2017-06-19 19:11:00 --> Helper loaded: url_helper
INFO - 2017-06-19 19:11:00 --> Upload Class Initialized
INFO - 2017-06-19 19:11:00 --> Final output sent to browser
DEBUG - 2017-06-19 19:11:00 --> Total execution time: 0.0560
ERROR - 2017-06-19 19:11:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:11:56 --> Config Class Initialized
INFO - 2017-06-19 19:11:56 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:11:56 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:11:56 --> Utf8 Class Initialized
INFO - 2017-06-19 19:11:56 --> URI Class Initialized
INFO - 2017-06-19 19:11:56 --> Router Class Initialized
INFO - 2017-06-19 19:11:56 --> Output Class Initialized
INFO - 2017-06-19 19:11:56 --> Security Class Initialized
DEBUG - 2017-06-19 19:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:11:56 --> Input Class Initialized
INFO - 2017-06-19 19:11:56 --> Language Class Initialized
INFO - 2017-06-19 19:11:56 --> Loader Class Initialized
INFO - 2017-06-19 19:11:56 --> Controller Class Initialized
INFO - 2017-06-19 19:11:56 --> Database Driver Class Initialized
INFO - 2017-06-19 19:11:56 --> Model Class Initialized
INFO - 2017-06-19 19:11:56 --> Helper loaded: form_helper
INFO - 2017-06-19 19:11:56 --> Helper loaded: url_helper
INFO - 2017-06-19 19:11:56 --> Upload Class Initialized
INFO - 2017-06-19 19:11:56 --> Final output sent to browser
DEBUG - 2017-06-19 19:11:56 --> Total execution time: 0.0530
ERROR - 2017-06-19 19:12:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:12:18 --> Config Class Initialized
INFO - 2017-06-19 19:12:18 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:12:18 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:12:18 --> Utf8 Class Initialized
INFO - 2017-06-19 19:12:18 --> URI Class Initialized
INFO - 2017-06-19 19:12:18 --> Router Class Initialized
INFO - 2017-06-19 19:12:18 --> Output Class Initialized
INFO - 2017-06-19 19:12:18 --> Security Class Initialized
DEBUG - 2017-06-19 19:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:12:18 --> Input Class Initialized
INFO - 2017-06-19 19:12:18 --> Language Class Initialized
INFO - 2017-06-19 19:12:18 --> Loader Class Initialized
INFO - 2017-06-19 19:12:18 --> Controller Class Initialized
INFO - 2017-06-19 19:12:18 --> Database Driver Class Initialized
INFO - 2017-06-19 19:12:18 --> Model Class Initialized
INFO - 2017-06-19 19:12:18 --> Helper loaded: form_helper
INFO - 2017-06-19 19:12:18 --> Helper loaded: url_helper
INFO - 2017-06-19 19:12:18 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:12:18 --> Model Class Initialized
INFO - 2017-06-19 19:12:18 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-19 19:12:18 --> Final output sent to browser
DEBUG - 2017-06-19 19:12:18 --> Total execution time: 0.0530
ERROR - 2017-06-19 19:12:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:12:20 --> Config Class Initialized
INFO - 2017-06-19 19:12:20 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:12:20 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:12:20 --> Utf8 Class Initialized
INFO - 2017-06-19 19:12:20 --> URI Class Initialized
INFO - 2017-06-19 19:12:20 --> Router Class Initialized
INFO - 2017-06-19 19:12:20 --> Output Class Initialized
INFO - 2017-06-19 19:12:20 --> Security Class Initialized
DEBUG - 2017-06-19 19:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:12:20 --> Input Class Initialized
INFO - 2017-06-19 19:12:20 --> Language Class Initialized
INFO - 2017-06-19 19:12:20 --> Loader Class Initialized
INFO - 2017-06-19 19:12:20 --> Controller Class Initialized
INFO - 2017-06-19 19:12:20 --> Database Driver Class Initialized
INFO - 2017-06-19 19:12:20 --> Model Class Initialized
INFO - 2017-06-19 19:12:20 --> Helper loaded: form_helper
INFO - 2017-06-19 19:12:20 --> Helper loaded: url_helper
INFO - 2017-06-19 19:12:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:12:20 --> Model Class Initialized
INFO - 2017-06-19 19:12:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 19:12:20 --> Final output sent to browser
DEBUG - 2017-06-19 19:12:20 --> Total execution time: 0.0560
ERROR - 2017-06-19 19:13:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:13:24 --> Config Class Initialized
INFO - 2017-06-19 19:13:24 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:13:24 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:13:24 --> Utf8 Class Initialized
INFO - 2017-06-19 19:13:24 --> URI Class Initialized
INFO - 2017-06-19 19:13:24 --> Router Class Initialized
INFO - 2017-06-19 19:13:24 --> Output Class Initialized
INFO - 2017-06-19 19:13:24 --> Security Class Initialized
DEBUG - 2017-06-19 19:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:13:24 --> Input Class Initialized
INFO - 2017-06-19 19:13:24 --> Language Class Initialized
INFO - 2017-06-19 19:13:24 --> Loader Class Initialized
INFO - 2017-06-19 19:13:24 --> Controller Class Initialized
INFO - 2017-06-19 19:13:24 --> Database Driver Class Initialized
INFO - 2017-06-19 19:13:24 --> Model Class Initialized
INFO - 2017-06-19 19:13:24 --> Helper loaded: form_helper
INFO - 2017-06-19 19:13:24 --> Helper loaded: url_helper
INFO - 2017-06-19 19:13:24 --> Upload Class Initialized
INFO - 2017-06-19 19:13:24 --> Final output sent to browser
DEBUG - 2017-06-19 19:13:24 --> Total execution time: 0.1150
ERROR - 2017-06-19 19:13:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:13:53 --> Config Class Initialized
INFO - 2017-06-19 19:13:53 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:13:53 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:13:53 --> Utf8 Class Initialized
INFO - 2017-06-19 19:13:53 --> URI Class Initialized
INFO - 2017-06-19 19:13:53 --> Router Class Initialized
INFO - 2017-06-19 19:13:53 --> Output Class Initialized
INFO - 2017-06-19 19:13:53 --> Security Class Initialized
DEBUG - 2017-06-19 19:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:13:53 --> Input Class Initialized
INFO - 2017-06-19 19:13:53 --> Language Class Initialized
INFO - 2017-06-19 19:13:53 --> Loader Class Initialized
INFO - 2017-06-19 19:13:53 --> Controller Class Initialized
INFO - 2017-06-19 19:13:53 --> Database Driver Class Initialized
INFO - 2017-06-19 19:13:53 --> Model Class Initialized
INFO - 2017-06-19 19:13:53 --> Helper loaded: form_helper
INFO - 2017-06-19 19:13:53 --> Helper loaded: url_helper
INFO - 2017-06-19 19:13:53 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:13:53 --> Model Class Initialized
INFO - 2017-06-19 19:13:53 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-19 19:13:53 --> Final output sent to browser
DEBUG - 2017-06-19 19:13:53 --> Total execution time: 0.0780
ERROR - 2017-06-19 19:13:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:13:55 --> Config Class Initialized
INFO - 2017-06-19 19:13:55 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:13:55 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:13:55 --> Utf8 Class Initialized
INFO - 2017-06-19 19:13:55 --> URI Class Initialized
INFO - 2017-06-19 19:13:55 --> Router Class Initialized
INFO - 2017-06-19 19:13:55 --> Output Class Initialized
INFO - 2017-06-19 19:13:55 --> Security Class Initialized
DEBUG - 2017-06-19 19:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:13:55 --> Input Class Initialized
INFO - 2017-06-19 19:13:55 --> Language Class Initialized
INFO - 2017-06-19 19:13:55 --> Loader Class Initialized
INFO - 2017-06-19 19:13:55 --> Controller Class Initialized
INFO - 2017-06-19 19:13:55 --> Database Driver Class Initialized
INFO - 2017-06-19 19:13:55 --> Model Class Initialized
INFO - 2017-06-19 19:13:55 --> Helper loaded: form_helper
INFO - 2017-06-19 19:13:55 --> Helper loaded: url_helper
INFO - 2017-06-19 19:13:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:13:55 --> Model Class Initialized
INFO - 2017-06-19 19:13:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 19:13:55 --> Final output sent to browser
DEBUG - 2017-06-19 19:13:55 --> Total execution time: 0.0560
ERROR - 2017-06-19 19:14:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:14:09 --> Config Class Initialized
INFO - 2017-06-19 19:14:09 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:14:09 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:14:09 --> Utf8 Class Initialized
INFO - 2017-06-19 19:14:09 --> URI Class Initialized
INFO - 2017-06-19 19:14:09 --> Router Class Initialized
INFO - 2017-06-19 19:14:09 --> Output Class Initialized
INFO - 2017-06-19 19:14:09 --> Security Class Initialized
DEBUG - 2017-06-19 19:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:14:09 --> Input Class Initialized
INFO - 2017-06-19 19:14:09 --> Language Class Initialized
INFO - 2017-06-19 19:14:09 --> Loader Class Initialized
INFO - 2017-06-19 19:14:09 --> Controller Class Initialized
INFO - 2017-06-19 19:14:09 --> Database Driver Class Initialized
INFO - 2017-06-19 19:14:09 --> Model Class Initialized
INFO - 2017-06-19 19:14:09 --> Helper loaded: form_helper
INFO - 2017-06-19 19:14:09 --> Helper loaded: url_helper
INFO - 2017-06-19 19:14:09 --> Upload Class Initialized
INFO - 2017-06-19 19:14:09 --> Final output sent to browser
DEBUG - 2017-06-19 19:14:09 --> Total execution time: 0.0630
ERROR - 2017-06-19 19:14:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:14:10 --> Config Class Initialized
INFO - 2017-06-19 19:14:10 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:14:10 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:14:10 --> Utf8 Class Initialized
INFO - 2017-06-19 19:14:10 --> URI Class Initialized
INFO - 2017-06-19 19:14:10 --> Router Class Initialized
INFO - 2017-06-19 19:14:10 --> Output Class Initialized
INFO - 2017-06-19 19:14:10 --> Security Class Initialized
DEBUG - 2017-06-19 19:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:14:10 --> Input Class Initialized
INFO - 2017-06-19 19:14:10 --> Language Class Initialized
INFO - 2017-06-19 19:14:10 --> Loader Class Initialized
INFO - 2017-06-19 19:14:10 --> Controller Class Initialized
INFO - 2017-06-19 19:14:10 --> Database Driver Class Initialized
INFO - 2017-06-19 19:14:10 --> Model Class Initialized
INFO - 2017-06-19 19:14:10 --> Helper loaded: form_helper
INFO - 2017-06-19 19:14:10 --> Helper loaded: url_helper
INFO - 2017-06-19 19:14:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:14:10 --> Model Class Initialized
INFO - 2017-06-19 19:14:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 19:14:10 --> Final output sent to browser
DEBUG - 2017-06-19 19:14:10 --> Total execution time: 0.0660
ERROR - 2017-06-19 19:14:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:14:27 --> Config Class Initialized
INFO - 2017-06-19 19:14:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:14:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:14:27 --> Utf8 Class Initialized
INFO - 2017-06-19 19:14:27 --> URI Class Initialized
INFO - 2017-06-19 19:14:27 --> Router Class Initialized
INFO - 2017-06-19 19:14:27 --> Output Class Initialized
INFO - 2017-06-19 19:14:27 --> Security Class Initialized
DEBUG - 2017-06-19 19:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:14:27 --> Input Class Initialized
INFO - 2017-06-19 19:14:27 --> Language Class Initialized
INFO - 2017-06-19 19:14:27 --> Loader Class Initialized
INFO - 2017-06-19 19:14:27 --> Controller Class Initialized
INFO - 2017-06-19 19:14:27 --> Database Driver Class Initialized
INFO - 2017-06-19 19:14:27 --> Model Class Initialized
INFO - 2017-06-19 19:14:27 --> Helper loaded: form_helper
INFO - 2017-06-19 19:14:27 --> Helper loaded: url_helper
INFO - 2017-06-19 19:14:27 --> Upload Class Initialized
INFO - 2017-06-19 19:14:27 --> Final output sent to browser
DEBUG - 2017-06-19 19:14:27 --> Total execution time: 0.0575
ERROR - 2017-06-19 19:14:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:14:27 --> Config Class Initialized
INFO - 2017-06-19 19:14:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:14:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:14:27 --> Utf8 Class Initialized
INFO - 2017-06-19 19:14:27 --> URI Class Initialized
INFO - 2017-06-19 19:14:27 --> Router Class Initialized
INFO - 2017-06-19 19:14:27 --> Output Class Initialized
INFO - 2017-06-19 19:14:27 --> Security Class Initialized
DEBUG - 2017-06-19 19:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:14:27 --> Input Class Initialized
INFO - 2017-06-19 19:14:27 --> Language Class Initialized
INFO - 2017-06-19 19:14:27 --> Loader Class Initialized
INFO - 2017-06-19 19:14:27 --> Controller Class Initialized
INFO - 2017-06-19 19:14:27 --> Database Driver Class Initialized
INFO - 2017-06-19 19:14:27 --> Model Class Initialized
INFO - 2017-06-19 19:14:27 --> Helper loaded: form_helper
INFO - 2017-06-19 19:14:27 --> Helper loaded: url_helper
INFO - 2017-06-19 19:14:27 --> Upload Class Initialized
INFO - 2017-06-19 19:14:27 --> Final output sent to browser
DEBUG - 2017-06-19 19:14:27 --> Total execution time: 0.0530
ERROR - 2017-06-19 19:14:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:14:28 --> Config Class Initialized
INFO - 2017-06-19 19:14:28 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:14:28 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:14:28 --> Utf8 Class Initialized
INFO - 2017-06-19 19:14:28 --> URI Class Initialized
INFO - 2017-06-19 19:14:28 --> Router Class Initialized
INFO - 2017-06-19 19:14:28 --> Output Class Initialized
INFO - 2017-06-19 19:14:28 --> Security Class Initialized
DEBUG - 2017-06-19 19:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:14:28 --> Input Class Initialized
INFO - 2017-06-19 19:14:28 --> Language Class Initialized
INFO - 2017-06-19 19:14:28 --> Loader Class Initialized
INFO - 2017-06-19 19:14:28 --> Controller Class Initialized
INFO - 2017-06-19 19:14:28 --> Database Driver Class Initialized
INFO - 2017-06-19 19:14:28 --> Model Class Initialized
INFO - 2017-06-19 19:14:28 --> Helper loaded: form_helper
INFO - 2017-06-19 19:14:28 --> Helper loaded: url_helper
INFO - 2017-06-19 19:14:28 --> Upload Class Initialized
INFO - 2017-06-19 19:14:28 --> Final output sent to browser
DEBUG - 2017-06-19 19:14:28 --> Total execution time: 0.0540
ERROR - 2017-06-19 19:14:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:14:28 --> Config Class Initialized
INFO - 2017-06-19 19:14:28 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:14:28 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:14:28 --> Utf8 Class Initialized
INFO - 2017-06-19 19:14:28 --> URI Class Initialized
INFO - 2017-06-19 19:14:28 --> Router Class Initialized
INFO - 2017-06-19 19:14:28 --> Output Class Initialized
INFO - 2017-06-19 19:14:28 --> Security Class Initialized
DEBUG - 2017-06-19 19:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:14:28 --> Input Class Initialized
INFO - 2017-06-19 19:14:28 --> Language Class Initialized
INFO - 2017-06-19 19:14:28 --> Loader Class Initialized
INFO - 2017-06-19 19:14:28 --> Controller Class Initialized
INFO - 2017-06-19 19:14:28 --> Database Driver Class Initialized
INFO - 2017-06-19 19:14:28 --> Model Class Initialized
INFO - 2017-06-19 19:14:28 --> Helper loaded: form_helper
INFO - 2017-06-19 19:14:28 --> Helper loaded: url_helper
INFO - 2017-06-19 19:14:28 --> Upload Class Initialized
INFO - 2017-06-19 19:14:28 --> Final output sent to browser
DEBUG - 2017-06-19 19:14:28 --> Total execution time: 0.0540
ERROR - 2017-06-19 19:14:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:14:28 --> Config Class Initialized
INFO - 2017-06-19 19:14:28 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:14:28 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:14:28 --> Utf8 Class Initialized
INFO - 2017-06-19 19:14:28 --> URI Class Initialized
INFO - 2017-06-19 19:14:28 --> Router Class Initialized
INFO - 2017-06-19 19:14:28 --> Output Class Initialized
INFO - 2017-06-19 19:14:28 --> Security Class Initialized
DEBUG - 2017-06-19 19:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:14:28 --> Input Class Initialized
INFO - 2017-06-19 19:14:28 --> Language Class Initialized
INFO - 2017-06-19 19:14:28 --> Loader Class Initialized
INFO - 2017-06-19 19:14:28 --> Controller Class Initialized
INFO - 2017-06-19 19:14:28 --> Database Driver Class Initialized
INFO - 2017-06-19 19:14:28 --> Model Class Initialized
INFO - 2017-06-19 19:14:28 --> Helper loaded: form_helper
INFO - 2017-06-19 19:14:28 --> Helper loaded: url_helper
INFO - 2017-06-19 19:14:28 --> Upload Class Initialized
INFO - 2017-06-19 19:14:28 --> Final output sent to browser
DEBUG - 2017-06-19 19:14:28 --> Total execution time: 0.0530
ERROR - 2017-06-19 19:14:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:14:31 --> Config Class Initialized
INFO - 2017-06-19 19:14:31 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:14:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:14:31 --> Utf8 Class Initialized
INFO - 2017-06-19 19:14:31 --> URI Class Initialized
INFO - 2017-06-19 19:14:31 --> Router Class Initialized
INFO - 2017-06-19 19:14:31 --> Output Class Initialized
INFO - 2017-06-19 19:14:31 --> Security Class Initialized
DEBUG - 2017-06-19 19:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:14:31 --> Input Class Initialized
INFO - 2017-06-19 19:14:31 --> Language Class Initialized
INFO - 2017-06-19 19:14:31 --> Loader Class Initialized
INFO - 2017-06-19 19:14:31 --> Controller Class Initialized
INFO - 2017-06-19 19:14:31 --> Database Driver Class Initialized
INFO - 2017-06-19 19:14:31 --> Model Class Initialized
INFO - 2017-06-19 19:14:31 --> Helper loaded: form_helper
INFO - 2017-06-19 19:14:31 --> Helper loaded: url_helper
INFO - 2017-06-19 19:14:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:14:31 --> Model Class Initialized
ERROR - 2017-06-19 19:14:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\mystage\application\views\song_detail.php 107
ERROR - 2017-06-19 19:14:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\mystage\application\views\song_detail.php 107
ERROR - 2017-06-19 19:14:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\mystage\application\views\song_detail.php 107
ERROR - 2017-06-19 19:14:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\mystage\application\views\song_detail.php 107
ERROR - 2017-06-19 19:14:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\mystage\application\views\song_detail.php 107
ERROR - 2017-06-19 19:14:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\mystage\application\views\song_detail.php 107
ERROR - 2017-06-19 19:14:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\mystage\application\views\song_detail.php 107
ERROR - 2017-06-19 19:14:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\mystage\application\views\song_detail.php 107
ERROR - 2017-06-19 19:14:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\mystage\application\views\song_detail.php 107
ERROR - 2017-06-19 19:14:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\mystage\application\views\song_detail.php 107
ERROR - 2017-06-19 19:14:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\mystage\application\views\song_detail.php 107
ERROR - 2017-06-19 19:14:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\mystage\application\views\song_detail.php 107
ERROR - 2017-06-19 19:14:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\mystage\application\views\song_detail.php 107
ERROR - 2017-06-19 19:14:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\mystage\application\views\song_detail.php 107
ERROR - 2017-06-19 19:14:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\mystage\application\views\song_detail.php 107
ERROR - 2017-06-19 19:14:31 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\mystage\application\views\song_detail.php 107
ERROR - 2017-06-19 19:14:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 129
ERROR - 2017-06-19 19:14:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 129
ERROR - 2017-06-19 19:14:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 133
ERROR - 2017-06-19 19:14:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 135
ERROR - 2017-06-19 19:14:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 136
ERROR - 2017-06-19 19:14:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 137
INFO - 2017-06-19 19:14:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 19:14:31 --> Final output sent to browser
DEBUG - 2017-06-19 19:14:31 --> Total execution time: 0.1380
ERROR - 2017-06-19 19:14:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:14:31 --> Config Class Initialized
INFO - 2017-06-19 19:14:31 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:14:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:14:31 --> Utf8 Class Initialized
ERROR - 2017-06-19 19:20:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:20:12 --> Config Class Initialized
INFO - 2017-06-19 19:20:12 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:20:12 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:20:12 --> Utf8 Class Initialized
INFO - 2017-06-19 19:20:12 --> URI Class Initialized
DEBUG - 2017-06-19 19:20:12 --> No URI present. Default controller set.
INFO - 2017-06-19 19:20:12 --> Router Class Initialized
INFO - 2017-06-19 19:20:12 --> Output Class Initialized
INFO - 2017-06-19 19:20:12 --> Security Class Initialized
DEBUG - 2017-06-19 19:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:20:12 --> Input Class Initialized
INFO - 2017-06-19 19:20:12 --> Language Class Initialized
INFO - 2017-06-19 19:20:12 --> Loader Class Initialized
INFO - 2017-06-19 19:20:12 --> Controller Class Initialized
INFO - 2017-06-19 19:20:12 --> Database Driver Class Initialized
INFO - 2017-06-19 19:20:12 --> Model Class Initialized
INFO - 2017-06-19 19:20:12 --> Helper loaded: form_helper
INFO - 2017-06-19 19:20:12 --> Helper loaded: url_helper
INFO - 2017-06-19 19:20:12 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-06-19 19:20:12 --> Final output sent to browser
DEBUG - 2017-06-19 19:20:12 --> Total execution time: 0.0610
ERROR - 2017-06-19 19:20:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:20:13 --> Config Class Initialized
INFO - 2017-06-19 19:20:13 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:20:13 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:20:13 --> Utf8 Class Initialized
INFO - 2017-06-19 19:20:13 --> URI Class Initialized
INFO - 2017-06-19 19:20:13 --> Router Class Initialized
INFO - 2017-06-19 19:20:13 --> Output Class Initialized
INFO - 2017-06-19 19:20:13 --> Security Class Initialized
DEBUG - 2017-06-19 19:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:20:13 --> Input Class Initialized
INFO - 2017-06-19 19:20:13 --> Language Class Initialized
INFO - 2017-06-19 19:20:13 --> Loader Class Initialized
INFO - 2017-06-19 19:20:13 --> Controller Class Initialized
INFO - 2017-06-19 19:20:13 --> Database Driver Class Initialized
INFO - 2017-06-19 19:20:13 --> Model Class Initialized
INFO - 2017-06-19 19:20:13 --> Helper loaded: form_helper
INFO - 2017-06-19 19:20:13 --> Helper loaded: url_helper
INFO - 2017-06-19 19:20:13 --> Model Class Initialized
ERROR - 2017-06-19 19:20:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:20:13 --> Config Class Initialized
INFO - 2017-06-19 19:20:13 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:20:13 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:20:13 --> Utf8 Class Initialized
INFO - 2017-06-19 19:20:13 --> URI Class Initialized
INFO - 2017-06-19 19:20:13 --> Router Class Initialized
INFO - 2017-06-19 19:20:13 --> Output Class Initialized
INFO - 2017-06-19 19:20:13 --> Security Class Initialized
DEBUG - 2017-06-19 19:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:20:13 --> Input Class Initialized
INFO - 2017-06-19 19:20:13 --> Language Class Initialized
INFO - 2017-06-19 19:20:13 --> Loader Class Initialized
INFO - 2017-06-19 19:20:13 --> Controller Class Initialized
INFO - 2017-06-19 19:20:13 --> Database Driver Class Initialized
INFO - 2017-06-19 19:20:13 --> Model Class Initialized
INFO - 2017-06-19 19:20:13 --> Helper loaded: form_helper
INFO - 2017-06-19 19:20:13 --> Helper loaded: url_helper
INFO - 2017-06-19 19:20:13 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:20:13 --> Model Class Initialized
INFO - 2017-06-19 19:20:13 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-19 19:20:13 --> Final output sent to browser
DEBUG - 2017-06-19 19:20:13 --> Total execution time: 0.0650
ERROR - 2017-06-19 19:20:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:20:17 --> Config Class Initialized
INFO - 2017-06-19 19:20:17 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:20:17 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:20:17 --> Utf8 Class Initialized
INFO - 2017-06-19 19:20:17 --> URI Class Initialized
INFO - 2017-06-19 19:20:17 --> Router Class Initialized
INFO - 2017-06-19 19:20:17 --> Output Class Initialized
INFO - 2017-06-19 19:20:17 --> Security Class Initialized
DEBUG - 2017-06-19 19:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:20:17 --> Input Class Initialized
INFO - 2017-06-19 19:20:17 --> Language Class Initialized
INFO - 2017-06-19 19:20:17 --> Loader Class Initialized
INFO - 2017-06-19 19:20:17 --> Controller Class Initialized
INFO - 2017-06-19 19:20:17 --> Database Driver Class Initialized
INFO - 2017-06-19 19:20:17 --> Model Class Initialized
INFO - 2017-06-19 19:20:17 --> Helper loaded: form_helper
INFO - 2017-06-19 19:20:17 --> Helper loaded: url_helper
INFO - 2017-06-19 19:20:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:20:17 --> Model Class Initialized
INFO - 2017-06-19 19:20:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 19:20:17 --> Final output sent to browser
DEBUG - 2017-06-19 19:20:17 --> Total execution time: 0.0620
ERROR - 2017-06-19 19:20:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:20:22 --> Config Class Initialized
INFO - 2017-06-19 19:20:22 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:20:22 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:20:22 --> Utf8 Class Initialized
INFO - 2017-06-19 19:20:22 --> URI Class Initialized
INFO - 2017-06-19 19:20:22 --> Router Class Initialized
INFO - 2017-06-19 19:20:22 --> Output Class Initialized
INFO - 2017-06-19 19:20:22 --> Security Class Initialized
DEBUG - 2017-06-19 19:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:20:22 --> Input Class Initialized
INFO - 2017-06-19 19:20:22 --> Language Class Initialized
INFO - 2017-06-19 19:20:22 --> Loader Class Initialized
INFO - 2017-06-19 19:20:22 --> Controller Class Initialized
INFO - 2017-06-19 19:20:22 --> Database Driver Class Initialized
INFO - 2017-06-19 19:20:22 --> Model Class Initialized
INFO - 2017-06-19 19:20:22 --> Helper loaded: form_helper
INFO - 2017-06-19 19:20:22 --> Helper loaded: url_helper
INFO - 2017-06-19 19:20:22 --> Upload Class Initialized
INFO - 2017-06-19 19:20:22 --> Final output sent to browser
DEBUG - 2017-06-19 19:20:22 --> Total execution time: 0.0605
ERROR - 2017-06-19 19:20:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:20:27 --> Config Class Initialized
INFO - 2017-06-19 19:20:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:20:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:20:27 --> Utf8 Class Initialized
INFO - 2017-06-19 19:20:27 --> URI Class Initialized
INFO - 2017-06-19 19:20:27 --> Router Class Initialized
INFO - 2017-06-19 19:20:27 --> Output Class Initialized
INFO - 2017-06-19 19:20:27 --> Security Class Initialized
DEBUG - 2017-06-19 19:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:20:27 --> Input Class Initialized
INFO - 2017-06-19 19:20:27 --> Language Class Initialized
INFO - 2017-06-19 19:20:27 --> Loader Class Initialized
INFO - 2017-06-19 19:20:27 --> Controller Class Initialized
INFO - 2017-06-19 19:20:27 --> Database Driver Class Initialized
INFO - 2017-06-19 19:20:27 --> Model Class Initialized
INFO - 2017-06-19 19:20:27 --> Helper loaded: form_helper
INFO - 2017-06-19 19:20:27 --> Helper loaded: url_helper
INFO - 2017-06-19 19:20:27 --> Upload Class Initialized
INFO - 2017-06-19 19:20:27 --> Final output sent to browser
DEBUG - 2017-06-19 19:20:27 --> Total execution time: 0.0680
ERROR - 2017-06-19 19:20:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:20:41 --> Config Class Initialized
INFO - 2017-06-19 19:20:41 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:20:41 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:20:41 --> Utf8 Class Initialized
INFO - 2017-06-19 19:20:41 --> URI Class Initialized
INFO - 2017-06-19 19:20:41 --> Router Class Initialized
INFO - 2017-06-19 19:20:41 --> Output Class Initialized
INFO - 2017-06-19 19:20:41 --> Security Class Initialized
DEBUG - 2017-06-19 19:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:20:41 --> Input Class Initialized
INFO - 2017-06-19 19:20:41 --> Language Class Initialized
INFO - 2017-06-19 19:20:41 --> Loader Class Initialized
INFO - 2017-06-19 19:20:41 --> Controller Class Initialized
INFO - 2017-06-19 19:20:41 --> Database Driver Class Initialized
INFO - 2017-06-19 19:20:41 --> Model Class Initialized
INFO - 2017-06-19 19:20:41 --> Helper loaded: form_helper
INFO - 2017-06-19 19:20:41 --> Helper loaded: url_helper
INFO - 2017-06-19 19:20:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:20:41 --> Model Class Initialized
INFO - 2017-06-19 19:20:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 19:20:41 --> Final output sent to browser
DEBUG - 2017-06-19 19:20:41 --> Total execution time: 0.0800
ERROR - 2017-06-19 19:20:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:20:48 --> Config Class Initialized
INFO - 2017-06-19 19:20:48 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:20:48 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:20:48 --> Utf8 Class Initialized
INFO - 2017-06-19 19:20:48 --> URI Class Initialized
INFO - 2017-06-19 19:20:48 --> Router Class Initialized
INFO - 2017-06-19 19:20:48 --> Output Class Initialized
INFO - 2017-06-19 19:20:48 --> Security Class Initialized
DEBUG - 2017-06-19 19:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:20:48 --> Input Class Initialized
INFO - 2017-06-19 19:20:48 --> Language Class Initialized
INFO - 2017-06-19 19:20:48 --> Loader Class Initialized
INFO - 2017-06-19 19:20:48 --> Controller Class Initialized
INFO - 2017-06-19 19:20:48 --> Database Driver Class Initialized
INFO - 2017-06-19 19:20:48 --> Model Class Initialized
INFO - 2017-06-19 19:20:48 --> Helper loaded: form_helper
INFO - 2017-06-19 19:20:48 --> Helper loaded: url_helper
INFO - 2017-06-19 19:20:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:20:48 --> Model Class Initialized
INFO - 2017-06-19 19:20:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 19:20:48 --> Final output sent to browser
DEBUG - 2017-06-19 19:20:48 --> Total execution time: 0.0550
ERROR - 2017-06-19 19:21:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:21:03 --> Config Class Initialized
INFO - 2017-06-19 19:21:03 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:21:03 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:21:03 --> Utf8 Class Initialized
INFO - 2017-06-19 19:21:03 --> URI Class Initialized
INFO - 2017-06-19 19:21:03 --> Router Class Initialized
INFO - 2017-06-19 19:21:03 --> Output Class Initialized
INFO - 2017-06-19 19:21:03 --> Security Class Initialized
DEBUG - 2017-06-19 19:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:21:03 --> Input Class Initialized
INFO - 2017-06-19 19:21:03 --> Language Class Initialized
INFO - 2017-06-19 19:21:03 --> Loader Class Initialized
INFO - 2017-06-19 19:21:03 --> Controller Class Initialized
INFO - 2017-06-19 19:21:03 --> Database Driver Class Initialized
INFO - 2017-06-19 19:21:03 --> Model Class Initialized
INFO - 2017-06-19 19:21:03 --> Helper loaded: form_helper
INFO - 2017-06-19 19:21:03 --> Helper loaded: url_helper
INFO - 2017-06-19 19:21:03 --> Upload Class Initialized
INFO - 2017-06-19 19:21:03 --> Final output sent to browser
DEBUG - 2017-06-19 19:21:03 --> Total execution time: 0.0540
ERROR - 2017-06-19 19:24:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:24:28 --> Config Class Initialized
INFO - 2017-06-19 19:24:28 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:24:28 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:24:28 --> Utf8 Class Initialized
INFO - 2017-06-19 19:24:28 --> URI Class Initialized
DEBUG - 2017-06-19 19:24:28 --> No URI present. Default controller set.
INFO - 2017-06-19 19:24:28 --> Router Class Initialized
INFO - 2017-06-19 19:24:28 --> Output Class Initialized
INFO - 2017-06-19 19:24:28 --> Security Class Initialized
DEBUG - 2017-06-19 19:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:24:28 --> Input Class Initialized
INFO - 2017-06-19 19:24:28 --> Language Class Initialized
INFO - 2017-06-19 19:24:28 --> Loader Class Initialized
INFO - 2017-06-19 19:24:28 --> Controller Class Initialized
INFO - 2017-06-19 19:24:28 --> Database Driver Class Initialized
INFO - 2017-06-19 19:24:28 --> Model Class Initialized
INFO - 2017-06-19 19:24:28 --> Helper loaded: form_helper
INFO - 2017-06-19 19:24:28 --> Helper loaded: url_helper
INFO - 2017-06-19 19:24:28 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-06-19 19:24:28 --> Final output sent to browser
DEBUG - 2017-06-19 19:24:28 --> Total execution time: 0.0700
ERROR - 2017-06-19 19:26:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:26:48 --> Config Class Initialized
INFO - 2017-06-19 19:26:48 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:26:48 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:26:48 --> Utf8 Class Initialized
INFO - 2017-06-19 19:26:48 --> URI Class Initialized
INFO - 2017-06-19 19:26:48 --> Router Class Initialized
INFO - 2017-06-19 19:26:48 --> Output Class Initialized
INFO - 2017-06-19 19:26:48 --> Security Class Initialized
DEBUG - 2017-06-19 19:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:26:48 --> Input Class Initialized
INFO - 2017-06-19 19:26:48 --> Language Class Initialized
INFO - 2017-06-19 19:26:48 --> Loader Class Initialized
INFO - 2017-06-19 19:26:48 --> Controller Class Initialized
INFO - 2017-06-19 19:26:48 --> Database Driver Class Initialized
INFO - 2017-06-19 19:26:48 --> Model Class Initialized
INFO - 2017-06-19 19:26:48 --> Helper loaded: form_helper
INFO - 2017-06-19 19:26:48 --> Helper loaded: url_helper
INFO - 2017-06-19 19:26:48 --> Model Class Initialized
ERROR - 2017-06-19 19:26:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:26:48 --> Config Class Initialized
INFO - 2017-06-19 19:26:48 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:26:48 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:26:48 --> Utf8 Class Initialized
INFO - 2017-06-19 19:26:48 --> URI Class Initialized
INFO - 2017-06-19 19:26:48 --> Router Class Initialized
INFO - 2017-06-19 19:26:48 --> Output Class Initialized
INFO - 2017-06-19 19:26:48 --> Security Class Initialized
DEBUG - 2017-06-19 19:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:26:48 --> Input Class Initialized
INFO - 2017-06-19 19:26:48 --> Language Class Initialized
INFO - 2017-06-19 19:26:48 --> Loader Class Initialized
INFO - 2017-06-19 19:26:48 --> Controller Class Initialized
INFO - 2017-06-19 19:26:48 --> Database Driver Class Initialized
INFO - 2017-06-19 19:26:48 --> Model Class Initialized
INFO - 2017-06-19 19:26:48 --> Helper loaded: form_helper
INFO - 2017-06-19 19:26:48 --> Helper loaded: url_helper
INFO - 2017-06-19 19:26:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:26:48 --> Model Class Initialized
INFO - 2017-06-19 19:26:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-19 19:26:48 --> Final output sent to browser
DEBUG - 2017-06-19 19:26:48 --> Total execution time: 0.0550
ERROR - 2017-06-19 19:26:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:26:50 --> Config Class Initialized
INFO - 2017-06-19 19:26:50 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:26:50 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:26:50 --> Utf8 Class Initialized
INFO - 2017-06-19 19:26:50 --> URI Class Initialized
INFO - 2017-06-19 19:26:50 --> Router Class Initialized
INFO - 2017-06-19 19:26:50 --> Output Class Initialized
INFO - 2017-06-19 19:26:50 --> Security Class Initialized
DEBUG - 2017-06-19 19:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:26:50 --> Input Class Initialized
INFO - 2017-06-19 19:26:50 --> Language Class Initialized
INFO - 2017-06-19 19:26:50 --> Loader Class Initialized
INFO - 2017-06-19 19:26:50 --> Controller Class Initialized
INFO - 2017-06-19 19:26:50 --> Database Driver Class Initialized
INFO - 2017-06-19 19:26:50 --> Model Class Initialized
INFO - 2017-06-19 19:26:50 --> Helper loaded: form_helper
INFO - 2017-06-19 19:26:50 --> Helper loaded: url_helper
INFO - 2017-06-19 19:26:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:26:50 --> Model Class Initialized
INFO - 2017-06-19 19:26:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 19:26:51 --> Final output sent to browser
DEBUG - 2017-06-19 19:26:51 --> Total execution time: 0.0620
ERROR - 2017-06-19 19:27:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:27:00 --> Config Class Initialized
INFO - 2017-06-19 19:27:00 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:27:00 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:27:00 --> Utf8 Class Initialized
INFO - 2017-06-19 19:27:00 --> URI Class Initialized
INFO - 2017-06-19 19:27:00 --> Router Class Initialized
INFO - 2017-06-19 19:27:00 --> Output Class Initialized
INFO - 2017-06-19 19:27:00 --> Security Class Initialized
DEBUG - 2017-06-19 19:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:27:00 --> Input Class Initialized
INFO - 2017-06-19 19:27:00 --> Language Class Initialized
INFO - 2017-06-19 19:27:00 --> Loader Class Initialized
INFO - 2017-06-19 19:27:00 --> Controller Class Initialized
INFO - 2017-06-19 19:27:00 --> Database Driver Class Initialized
INFO - 2017-06-19 19:27:00 --> Model Class Initialized
INFO - 2017-06-19 19:27:00 --> Helper loaded: form_helper
INFO - 2017-06-19 19:27:00 --> Helper loaded: url_helper
INFO - 2017-06-19 19:27:00 --> Upload Class Initialized
INFO - 2017-06-19 19:27:00 --> Final output sent to browser
DEBUG - 2017-06-19 19:27:00 --> Total execution time: 0.0660
ERROR - 2017-06-19 19:27:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:27:02 --> Config Class Initialized
INFO - 2017-06-19 19:27:02 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:27:02 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:27:02 --> Utf8 Class Initialized
INFO - 2017-06-19 19:27:02 --> URI Class Initialized
INFO - 2017-06-19 19:27:02 --> Router Class Initialized
INFO - 2017-06-19 19:27:02 --> Output Class Initialized
INFO - 2017-06-19 19:27:02 --> Security Class Initialized
DEBUG - 2017-06-19 19:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:27:02 --> Input Class Initialized
INFO - 2017-06-19 19:27:02 --> Language Class Initialized
INFO - 2017-06-19 19:27:02 --> Loader Class Initialized
INFO - 2017-06-19 19:27:02 --> Controller Class Initialized
INFO - 2017-06-19 19:27:02 --> Database Driver Class Initialized
INFO - 2017-06-19 19:27:02 --> Model Class Initialized
INFO - 2017-06-19 19:27:02 --> Helper loaded: form_helper
INFO - 2017-06-19 19:27:02 --> Helper loaded: url_helper
INFO - 2017-06-19 19:27:02 --> Upload Class Initialized
INFO - 2017-06-19 19:27:02 --> Final output sent to browser
DEBUG - 2017-06-19 19:27:02 --> Total execution time: 0.0600
ERROR - 2017-06-19 19:27:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:27:12 --> Config Class Initialized
INFO - 2017-06-19 19:27:12 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:27:12 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:27:12 --> Utf8 Class Initialized
INFO - 2017-06-19 19:27:12 --> URI Class Initialized
INFO - 2017-06-19 19:27:12 --> Router Class Initialized
INFO - 2017-06-19 19:27:12 --> Output Class Initialized
INFO - 2017-06-19 19:27:12 --> Security Class Initialized
DEBUG - 2017-06-19 19:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:27:12 --> Input Class Initialized
INFO - 2017-06-19 19:27:12 --> Language Class Initialized
INFO - 2017-06-19 19:27:12 --> Loader Class Initialized
INFO - 2017-06-19 19:27:12 --> Controller Class Initialized
INFO - 2017-06-19 19:27:12 --> Database Driver Class Initialized
INFO - 2017-06-19 19:27:12 --> Model Class Initialized
INFO - 2017-06-19 19:27:12 --> Helper loaded: form_helper
INFO - 2017-06-19 19:27:12 --> Helper loaded: url_helper
INFO - 2017-06-19 19:27:12 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:27:12 --> Model Class Initialized
ERROR - 2017-06-19 19:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 129
ERROR - 2017-06-19 19:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 129
ERROR - 2017-06-19 19:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 133
ERROR - 2017-06-19 19:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 135
ERROR - 2017-06-19 19:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 136
ERROR - 2017-06-19 19:27:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 137
INFO - 2017-06-19 19:27:12 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 19:27:12 --> Final output sent to browser
DEBUG - 2017-06-19 19:27:12 --> Total execution time: 0.0840
ERROR - 2017-06-19 19:27:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:27:12 --> Config Class Initialized
INFO - 2017-06-19 19:27:12 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:27:12 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:27:12 --> Utf8 Class Initialized
ERROR - 2017-06-19 19:35:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:35:50 --> Config Class Initialized
INFO - 2017-06-19 19:35:50 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:35:50 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:35:50 --> Utf8 Class Initialized
INFO - 2017-06-19 19:35:50 --> URI Class Initialized
DEBUG - 2017-06-19 19:35:50 --> No URI present. Default controller set.
INFO - 2017-06-19 19:35:50 --> Router Class Initialized
INFO - 2017-06-19 19:35:50 --> Output Class Initialized
INFO - 2017-06-19 19:35:50 --> Security Class Initialized
DEBUG - 2017-06-19 19:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:35:50 --> Input Class Initialized
INFO - 2017-06-19 19:35:50 --> Language Class Initialized
INFO - 2017-06-19 19:35:50 --> Loader Class Initialized
INFO - 2017-06-19 19:35:50 --> Controller Class Initialized
INFO - 2017-06-19 19:35:50 --> Database Driver Class Initialized
INFO - 2017-06-19 19:35:50 --> Model Class Initialized
INFO - 2017-06-19 19:35:50 --> Helper loaded: form_helper
INFO - 2017-06-19 19:35:50 --> Helper loaded: url_helper
INFO - 2017-06-19 19:35:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-06-19 19:35:50 --> Final output sent to browser
DEBUG - 2017-06-19 19:35:50 --> Total execution time: 0.0590
ERROR - 2017-06-19 19:35:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:35:51 --> Config Class Initialized
INFO - 2017-06-19 19:35:51 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:35:51 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:35:51 --> Utf8 Class Initialized
INFO - 2017-06-19 19:35:51 --> URI Class Initialized
INFO - 2017-06-19 19:35:51 --> Router Class Initialized
INFO - 2017-06-19 19:35:51 --> Output Class Initialized
INFO - 2017-06-19 19:35:51 --> Security Class Initialized
DEBUG - 2017-06-19 19:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:35:51 --> Input Class Initialized
INFO - 2017-06-19 19:35:51 --> Language Class Initialized
INFO - 2017-06-19 19:35:51 --> Loader Class Initialized
INFO - 2017-06-19 19:35:51 --> Controller Class Initialized
INFO - 2017-06-19 19:35:51 --> Database Driver Class Initialized
INFO - 2017-06-19 19:35:51 --> Model Class Initialized
INFO - 2017-06-19 19:35:51 --> Helper loaded: form_helper
INFO - 2017-06-19 19:35:51 --> Helper loaded: url_helper
INFO - 2017-06-19 19:35:51 --> Model Class Initialized
ERROR - 2017-06-19 19:35:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:35:51 --> Config Class Initialized
INFO - 2017-06-19 19:35:51 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:35:51 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:35:51 --> Utf8 Class Initialized
INFO - 2017-06-19 19:35:51 --> URI Class Initialized
INFO - 2017-06-19 19:35:51 --> Router Class Initialized
INFO - 2017-06-19 19:35:51 --> Output Class Initialized
INFO - 2017-06-19 19:35:51 --> Security Class Initialized
DEBUG - 2017-06-19 19:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:35:51 --> Input Class Initialized
INFO - 2017-06-19 19:35:51 --> Language Class Initialized
INFO - 2017-06-19 19:35:51 --> Loader Class Initialized
INFO - 2017-06-19 19:35:51 --> Controller Class Initialized
INFO - 2017-06-19 19:35:51 --> Database Driver Class Initialized
INFO - 2017-06-19 19:35:51 --> Model Class Initialized
INFO - 2017-06-19 19:35:51 --> Helper loaded: form_helper
INFO - 2017-06-19 19:35:51 --> Helper loaded: url_helper
INFO - 2017-06-19 19:35:51 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:35:51 --> Model Class Initialized
INFO - 2017-06-19 19:35:51 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-19 19:35:51 --> Final output sent to browser
DEBUG - 2017-06-19 19:35:51 --> Total execution time: 0.0560
ERROR - 2017-06-19 19:35:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:35:55 --> Config Class Initialized
INFO - 2017-06-19 19:35:55 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:35:55 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:35:55 --> Utf8 Class Initialized
INFO - 2017-06-19 19:35:55 --> URI Class Initialized
INFO - 2017-06-19 19:35:55 --> Router Class Initialized
INFO - 2017-06-19 19:35:55 --> Output Class Initialized
INFO - 2017-06-19 19:35:55 --> Security Class Initialized
DEBUG - 2017-06-19 19:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:35:55 --> Input Class Initialized
INFO - 2017-06-19 19:35:55 --> Language Class Initialized
INFO - 2017-06-19 19:35:55 --> Loader Class Initialized
INFO - 2017-06-19 19:35:55 --> Controller Class Initialized
INFO - 2017-06-19 19:35:55 --> Database Driver Class Initialized
INFO - 2017-06-19 19:35:55 --> Model Class Initialized
INFO - 2017-06-19 19:35:55 --> Helper loaded: form_helper
INFO - 2017-06-19 19:35:55 --> Helper loaded: url_helper
INFO - 2017-06-19 19:35:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:35:55 --> Model Class Initialized
INFO - 2017-06-19 19:35:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 19:35:55 --> Final output sent to browser
DEBUG - 2017-06-19 19:35:55 --> Total execution time: 0.0700
ERROR - 2017-06-19 19:35:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:35:59 --> Config Class Initialized
INFO - 2017-06-19 19:35:59 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:35:59 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:35:59 --> Utf8 Class Initialized
INFO - 2017-06-19 19:35:59 --> URI Class Initialized
INFO - 2017-06-19 19:35:59 --> Router Class Initialized
INFO - 2017-06-19 19:35:59 --> Output Class Initialized
INFO - 2017-06-19 19:35:59 --> Security Class Initialized
DEBUG - 2017-06-19 19:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:35:59 --> Input Class Initialized
INFO - 2017-06-19 19:35:59 --> Language Class Initialized
INFO - 2017-06-19 19:35:59 --> Loader Class Initialized
INFO - 2017-06-19 19:35:59 --> Controller Class Initialized
INFO - 2017-06-19 19:35:59 --> Database Driver Class Initialized
INFO - 2017-06-19 19:35:59 --> Model Class Initialized
INFO - 2017-06-19 19:35:59 --> Helper loaded: form_helper
INFO - 2017-06-19 19:35:59 --> Helper loaded: url_helper
INFO - 2017-06-19 19:35:59 --> Upload Class Initialized
INFO - 2017-06-19 19:35:59 --> Final output sent to browser
DEBUG - 2017-06-19 19:35:59 --> Total execution time: 0.0670
ERROR - 2017-06-19 19:35:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:35:59 --> Config Class Initialized
INFO - 2017-06-19 19:35:59 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:35:59 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:35:59 --> Utf8 Class Initialized
INFO - 2017-06-19 19:35:59 --> URI Class Initialized
INFO - 2017-06-19 19:35:59 --> Router Class Initialized
INFO - 2017-06-19 19:35:59 --> Output Class Initialized
INFO - 2017-06-19 19:35:59 --> Security Class Initialized
DEBUG - 2017-06-19 19:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:35:59 --> Input Class Initialized
INFO - 2017-06-19 19:35:59 --> Language Class Initialized
INFO - 2017-06-19 19:35:59 --> Loader Class Initialized
INFO - 2017-06-19 19:35:59 --> Controller Class Initialized
INFO - 2017-06-19 19:35:59 --> Database Driver Class Initialized
INFO - 2017-06-19 19:35:59 --> Model Class Initialized
INFO - 2017-06-19 19:35:59 --> Helper loaded: form_helper
INFO - 2017-06-19 19:35:59 --> Helper loaded: url_helper
INFO - 2017-06-19 19:35:59 --> Upload Class Initialized
INFO - 2017-06-19 19:35:59 --> Final output sent to browser
DEBUG - 2017-06-19 19:35:59 --> Total execution time: 0.0530
ERROR - 2017-06-19 19:36:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:36:00 --> Config Class Initialized
INFO - 2017-06-19 19:36:00 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:36:00 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:36:00 --> Utf8 Class Initialized
INFO - 2017-06-19 19:36:00 --> URI Class Initialized
INFO - 2017-06-19 19:36:00 --> Router Class Initialized
INFO - 2017-06-19 19:36:00 --> Output Class Initialized
INFO - 2017-06-19 19:36:00 --> Security Class Initialized
DEBUG - 2017-06-19 19:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:36:00 --> Input Class Initialized
INFO - 2017-06-19 19:36:00 --> Language Class Initialized
INFO - 2017-06-19 19:36:00 --> Loader Class Initialized
INFO - 2017-06-19 19:36:00 --> Controller Class Initialized
INFO - 2017-06-19 19:36:00 --> Database Driver Class Initialized
INFO - 2017-06-19 19:36:00 --> Model Class Initialized
INFO - 2017-06-19 19:36:00 --> Helper loaded: form_helper
INFO - 2017-06-19 19:36:00 --> Helper loaded: url_helper
INFO - 2017-06-19 19:36:00 --> Upload Class Initialized
INFO - 2017-06-19 19:36:00 --> Final output sent to browser
DEBUG - 2017-06-19 19:36:00 --> Total execution time: 0.0500
ERROR - 2017-06-19 19:36:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:36:06 --> Config Class Initialized
INFO - 2017-06-19 19:36:06 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:36:06 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:36:06 --> Utf8 Class Initialized
INFO - 2017-06-19 19:36:06 --> URI Class Initialized
INFO - 2017-06-19 19:36:06 --> Router Class Initialized
INFO - 2017-06-19 19:36:06 --> Output Class Initialized
INFO - 2017-06-19 19:36:06 --> Security Class Initialized
DEBUG - 2017-06-19 19:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:36:06 --> Input Class Initialized
INFO - 2017-06-19 19:36:06 --> Language Class Initialized
INFO - 2017-06-19 19:36:06 --> Loader Class Initialized
INFO - 2017-06-19 19:36:06 --> Controller Class Initialized
INFO - 2017-06-19 19:36:06 --> Database Driver Class Initialized
INFO - 2017-06-19 19:36:06 --> Model Class Initialized
INFO - 2017-06-19 19:36:06 --> Helper loaded: form_helper
INFO - 2017-06-19 19:36:06 --> Helper loaded: url_helper
INFO - 2017-06-19 19:36:06 --> Upload Class Initialized
INFO - 2017-06-19 19:36:06 --> Final output sent to browser
DEBUG - 2017-06-19 19:36:06 --> Total execution time: 0.0650
ERROR - 2017-06-19 19:36:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:36:18 --> Config Class Initialized
INFO - 2017-06-19 19:36:18 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:36:18 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:36:18 --> Utf8 Class Initialized
INFO - 2017-06-19 19:36:18 --> URI Class Initialized
INFO - 2017-06-19 19:36:18 --> Router Class Initialized
INFO - 2017-06-19 19:36:18 --> Output Class Initialized
INFO - 2017-06-19 19:36:18 --> Security Class Initialized
DEBUG - 2017-06-19 19:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:36:18 --> Input Class Initialized
INFO - 2017-06-19 19:36:18 --> Language Class Initialized
INFO - 2017-06-19 19:36:18 --> Loader Class Initialized
INFO - 2017-06-19 19:36:18 --> Controller Class Initialized
INFO - 2017-06-19 19:36:18 --> Database Driver Class Initialized
INFO - 2017-06-19 19:36:18 --> Model Class Initialized
INFO - 2017-06-19 19:36:18 --> Helper loaded: form_helper
INFO - 2017-06-19 19:36:18 --> Helper loaded: url_helper
INFO - 2017-06-19 19:36:18 --> Upload Class Initialized
INFO - 2017-06-19 19:36:18 --> Final output sent to browser
DEBUG - 2017-06-19 19:36:18 --> Total execution time: 0.0690
ERROR - 2017-06-19 19:36:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:36:27 --> Config Class Initialized
INFO - 2017-06-19 19:36:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:36:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:36:27 --> Utf8 Class Initialized
INFO - 2017-06-19 19:36:27 --> URI Class Initialized
INFO - 2017-06-19 19:36:27 --> Router Class Initialized
INFO - 2017-06-19 19:36:27 --> Output Class Initialized
INFO - 2017-06-19 19:36:27 --> Security Class Initialized
DEBUG - 2017-06-19 19:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:36:27 --> Input Class Initialized
INFO - 2017-06-19 19:36:27 --> Language Class Initialized
INFO - 2017-06-19 19:36:27 --> Loader Class Initialized
INFO - 2017-06-19 19:36:27 --> Controller Class Initialized
INFO - 2017-06-19 19:36:27 --> Database Driver Class Initialized
INFO - 2017-06-19 19:36:27 --> Model Class Initialized
INFO - 2017-06-19 19:36:27 --> Helper loaded: form_helper
INFO - 2017-06-19 19:36:27 --> Helper loaded: url_helper
INFO - 2017-06-19 19:36:27 --> Upload Class Initialized
INFO - 2017-06-19 19:36:27 --> Final output sent to browser
DEBUG - 2017-06-19 19:36:27 --> Total execution time: 0.0560
ERROR - 2017-06-19 19:36:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:36:35 --> Config Class Initialized
INFO - 2017-06-19 19:36:35 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:36:35 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:36:35 --> Utf8 Class Initialized
INFO - 2017-06-19 19:36:35 --> URI Class Initialized
INFO - 2017-06-19 19:36:35 --> Router Class Initialized
INFO - 2017-06-19 19:36:35 --> Output Class Initialized
INFO - 2017-06-19 19:36:35 --> Security Class Initialized
DEBUG - 2017-06-19 19:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:36:35 --> Input Class Initialized
INFO - 2017-06-19 19:36:35 --> Language Class Initialized
INFO - 2017-06-19 19:36:35 --> Loader Class Initialized
INFO - 2017-06-19 19:36:35 --> Controller Class Initialized
INFO - 2017-06-19 19:36:35 --> Database Driver Class Initialized
INFO - 2017-06-19 19:36:35 --> Model Class Initialized
INFO - 2017-06-19 19:36:35 --> Helper loaded: form_helper
INFO - 2017-06-19 19:36:35 --> Helper loaded: url_helper
INFO - 2017-06-19 19:36:35 --> Upload Class Initialized
INFO - 2017-06-19 19:36:35 --> Final output sent to browser
DEBUG - 2017-06-19 19:36:35 --> Total execution time: 0.0550
ERROR - 2017-06-19 19:36:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:36:44 --> Config Class Initialized
INFO - 2017-06-19 19:36:44 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:36:44 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:36:44 --> Utf8 Class Initialized
INFO - 2017-06-19 19:36:44 --> URI Class Initialized
INFO - 2017-06-19 19:36:44 --> Router Class Initialized
INFO - 2017-06-19 19:36:44 --> Output Class Initialized
INFO - 2017-06-19 19:36:44 --> Security Class Initialized
DEBUG - 2017-06-19 19:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:36:44 --> Input Class Initialized
INFO - 2017-06-19 19:36:44 --> Language Class Initialized
INFO - 2017-06-19 19:36:44 --> Loader Class Initialized
INFO - 2017-06-19 19:36:44 --> Controller Class Initialized
INFO - 2017-06-19 19:36:44 --> Database Driver Class Initialized
INFO - 2017-06-19 19:36:44 --> Model Class Initialized
INFO - 2017-06-19 19:36:44 --> Helper loaded: form_helper
INFO - 2017-06-19 19:36:44 --> Helper loaded: url_helper
INFO - 2017-06-19 19:36:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:36:44 --> Model Class Initialized
ERROR - 2017-06-19 19:36:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 129
ERROR - 2017-06-19 19:36:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 129
ERROR - 2017-06-19 19:36:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 133
ERROR - 2017-06-19 19:36:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 135
ERROR - 2017-06-19 19:36:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 136
ERROR - 2017-06-19 19:36:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 137
ERROR - 2017-06-19 19:36:44 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\mystage\application\views\song_detail.php 129
ERROR - 2017-06-19 19:36:44 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\mystage\application\views\song_detail.php 129
ERROR - 2017-06-19 19:36:44 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\mystage\application\views\song_detail.php 133
ERROR - 2017-06-19 19:36:44 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\mystage\application\views\song_detail.php 135
ERROR - 2017-06-19 19:36:44 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\mystage\application\views\song_detail.php 136
ERROR - 2017-06-19 19:36:44 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\mystage\application\views\song_detail.php 137
INFO - 2017-06-19 19:36:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 19:36:44 --> Final output sent to browser
DEBUG - 2017-06-19 19:36:44 --> Total execution time: 0.0880
ERROR - 2017-06-19 19:36:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:36:45 --> Config Class Initialized
INFO - 2017-06-19 19:36:45 --> Hooks Class Initialized
ERROR - 2017-06-19 19:36:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
DEBUG - 2017-06-19 19:36:45 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:36:45 --> Config Class Initialized
INFO - 2017-06-19 19:36:45 --> Utf8 Class Initialized
INFO - 2017-06-19 19:36:45 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:36:45 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:36:45 --> Utf8 Class Initialized
ERROR - 2017-06-19 19:42:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:42:46 --> Config Class Initialized
INFO - 2017-06-19 19:42:46 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:42:46 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:42:46 --> Utf8 Class Initialized
INFO - 2017-06-19 19:42:46 --> URI Class Initialized
INFO - 2017-06-19 19:42:46 --> Router Class Initialized
INFO - 2017-06-19 19:42:46 --> Output Class Initialized
INFO - 2017-06-19 19:42:46 --> Security Class Initialized
DEBUG - 2017-06-19 19:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 19:42:46 --> Input Class Initialized
INFO - 2017-06-19 19:42:46 --> Language Class Initialized
INFO - 2017-06-19 19:42:46 --> Loader Class Initialized
INFO - 2017-06-19 19:42:46 --> Controller Class Initialized
INFO - 2017-06-19 19:42:46 --> Database Driver Class Initialized
INFO - 2017-06-19 19:42:46 --> Model Class Initialized
INFO - 2017-06-19 19:42:46 --> Helper loaded: form_helper
INFO - 2017-06-19 19:42:46 --> Helper loaded: url_helper
INFO - 2017-06-19 19:42:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 19:42:46 --> Model Class Initialized
ERROR - 2017-06-19 19:42:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 129
ERROR - 2017-06-19 19:42:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 129
ERROR - 2017-06-19 19:42:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 133
ERROR - 2017-06-19 19:42:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 135
ERROR - 2017-06-19 19:42:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 136
ERROR - 2017-06-19 19:42:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mystage\application\views\song_detail.php 137
ERROR - 2017-06-19 19:42:46 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\mystage\application\views\song_detail.php 129
ERROR - 2017-06-19 19:42:46 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\mystage\application\views\song_detail.php 129
ERROR - 2017-06-19 19:42:46 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\mystage\application\views\song_detail.php 133
ERROR - 2017-06-19 19:42:46 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\mystage\application\views\song_detail.php 135
ERROR - 2017-06-19 19:42:46 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\mystage\application\views\song_detail.php 136
ERROR - 2017-06-19 19:42:46 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\mystage\application\views\song_detail.php 137
INFO - 2017-06-19 19:42:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 19:42:46 --> Final output sent to browser
DEBUG - 2017-06-19 19:42:46 --> Total execution time: 0.0900
ERROR - 2017-06-19 19:42:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
ERROR - 2017-06-19 19:42:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 19:42:47 --> Config Class Initialized
INFO - 2017-06-19 19:42:47 --> Config Class Initialized
INFO - 2017-06-19 19:42:47 --> Hooks Class Initialized
INFO - 2017-06-19 19:42:47 --> Hooks Class Initialized
DEBUG - 2017-06-19 19:42:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-19 19:42:47 --> UTF-8 Support Enabled
INFO - 2017-06-19 19:42:47 --> Utf8 Class Initialized
INFO - 2017-06-19 19:42:47 --> Utf8 Class Initialized
ERROR - 2017-06-19 20:04:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 20:04:50 --> Config Class Initialized
INFO - 2017-06-19 20:04:50 --> Hooks Class Initialized
DEBUG - 2017-06-19 20:04:50 --> UTF-8 Support Enabled
INFO - 2017-06-19 20:04:50 --> Utf8 Class Initialized
INFO - 2017-06-19 20:04:50 --> URI Class Initialized
INFO - 2017-06-19 20:04:50 --> Router Class Initialized
INFO - 2017-06-19 20:04:50 --> Output Class Initialized
INFO - 2017-06-19 20:04:50 --> Security Class Initialized
DEBUG - 2017-06-19 20:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 20:04:50 --> Input Class Initialized
INFO - 2017-06-19 20:04:50 --> Language Class Initialized
INFO - 2017-06-19 20:04:50 --> Loader Class Initialized
INFO - 2017-06-19 20:04:50 --> Controller Class Initialized
INFO - 2017-06-19 20:04:50 --> Database Driver Class Initialized
INFO - 2017-06-19 20:04:50 --> Model Class Initialized
INFO - 2017-06-19 20:04:50 --> Helper loaded: form_helper
INFO - 2017-06-19 20:04:50 --> Helper loaded: url_helper
INFO - 2017-06-19 20:04:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 20:04:50 --> Model Class Initialized
INFO - 2017-06-19 20:04:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 20:04:50 --> Final output sent to browser
DEBUG - 2017-06-19 20:04:50 --> Total execution time: 0.0620
ERROR - 2017-06-19 20:06:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 20:06:32 --> Config Class Initialized
INFO - 2017-06-19 20:06:32 --> Hooks Class Initialized
DEBUG - 2017-06-19 20:06:32 --> UTF-8 Support Enabled
INFO - 2017-06-19 20:06:32 --> Utf8 Class Initialized
INFO - 2017-06-19 20:06:32 --> URI Class Initialized
INFO - 2017-06-19 20:06:32 --> Router Class Initialized
INFO - 2017-06-19 20:06:32 --> Output Class Initialized
INFO - 2017-06-19 20:06:32 --> Security Class Initialized
DEBUG - 2017-06-19 20:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 20:06:32 --> Input Class Initialized
INFO - 2017-06-19 20:06:32 --> Language Class Initialized
INFO - 2017-06-19 20:06:32 --> Loader Class Initialized
INFO - 2017-06-19 20:06:32 --> Controller Class Initialized
INFO - 2017-06-19 20:06:32 --> Database Driver Class Initialized
INFO - 2017-06-19 20:06:32 --> Model Class Initialized
INFO - 2017-06-19 20:06:32 --> Helper loaded: form_helper
INFO - 2017-06-19 20:06:32 --> Helper loaded: url_helper
INFO - 2017-06-19 20:06:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 20:06:32 --> Model Class Initialized
INFO - 2017-06-19 20:06:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 20:06:32 --> Final output sent to browser
DEBUG - 2017-06-19 20:06:32 --> Total execution time: 0.0570
ERROR - 2017-06-19 20:46:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 20:46:07 --> Config Class Initialized
INFO - 2017-06-19 20:46:07 --> Hooks Class Initialized
DEBUG - 2017-06-19 20:46:07 --> UTF-8 Support Enabled
INFO - 2017-06-19 20:46:07 --> Utf8 Class Initialized
INFO - 2017-06-19 20:46:07 --> URI Class Initialized
INFO - 2017-06-19 20:46:07 --> Router Class Initialized
INFO - 2017-06-19 20:46:07 --> Output Class Initialized
INFO - 2017-06-19 20:46:07 --> Security Class Initialized
DEBUG - 2017-06-19 20:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 20:46:07 --> Input Class Initialized
INFO - 2017-06-19 20:46:07 --> Language Class Initialized
INFO - 2017-06-19 20:46:07 --> Loader Class Initialized
INFO - 2017-06-19 20:46:07 --> Controller Class Initialized
INFO - 2017-06-19 20:46:07 --> Database Driver Class Initialized
INFO - 2017-06-19 20:46:07 --> Model Class Initialized
INFO - 2017-06-19 20:46:07 --> Helper loaded: form_helper
INFO - 2017-06-19 20:46:07 --> Helper loaded: url_helper
INFO - 2017-06-19 20:46:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 20:46:07 --> Model Class Initialized
INFO - 2017-06-19 20:46:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-19 20:46:07 --> Final output sent to browser
DEBUG - 2017-06-19 20:46:07 --> Total execution time: 0.0680
ERROR - 2017-06-19 20:46:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 20:46:12 --> Config Class Initialized
INFO - 2017-06-19 20:46:12 --> Hooks Class Initialized
DEBUG - 2017-06-19 20:46:12 --> UTF-8 Support Enabled
INFO - 2017-06-19 20:46:12 --> Utf8 Class Initialized
INFO - 2017-06-19 20:46:12 --> URI Class Initialized
INFO - 2017-06-19 20:46:12 --> Router Class Initialized
INFO - 2017-06-19 20:46:12 --> Output Class Initialized
INFO - 2017-06-19 20:46:12 --> Security Class Initialized
DEBUG - 2017-06-19 20:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 20:46:12 --> Input Class Initialized
INFO - 2017-06-19 20:46:12 --> Language Class Initialized
INFO - 2017-06-19 20:46:12 --> Loader Class Initialized
INFO - 2017-06-19 20:46:12 --> Controller Class Initialized
INFO - 2017-06-19 20:46:12 --> Database Driver Class Initialized
INFO - 2017-06-19 20:46:12 --> Model Class Initialized
INFO - 2017-06-19 20:46:12 --> Helper loaded: form_helper
INFO - 2017-06-19 20:46:12 --> Helper loaded: url_helper
INFO - 2017-06-19 20:46:12 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 20:46:12 --> Model Class Initialized
INFO - 2017-06-19 20:46:12 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 20:46:12 --> Final output sent to browser
DEBUG - 2017-06-19 20:46:12 --> Total execution time: 0.0780
ERROR - 2017-06-19 20:46:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 20:46:16 --> Config Class Initialized
INFO - 2017-06-19 20:46:16 --> Hooks Class Initialized
DEBUG - 2017-06-19 20:46:16 --> UTF-8 Support Enabled
INFO - 2017-06-19 20:46:16 --> Utf8 Class Initialized
INFO - 2017-06-19 20:46:16 --> URI Class Initialized
INFO - 2017-06-19 20:46:16 --> Router Class Initialized
INFO - 2017-06-19 20:46:16 --> Output Class Initialized
INFO - 2017-06-19 20:46:16 --> Security Class Initialized
DEBUG - 2017-06-19 20:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 20:46:16 --> Input Class Initialized
INFO - 2017-06-19 20:46:16 --> Language Class Initialized
INFO - 2017-06-19 20:46:16 --> Loader Class Initialized
INFO - 2017-06-19 20:46:16 --> Controller Class Initialized
INFO - 2017-06-19 20:46:16 --> Database Driver Class Initialized
INFO - 2017-06-19 20:46:16 --> Model Class Initialized
INFO - 2017-06-19 20:46:16 --> Helper loaded: form_helper
INFO - 2017-06-19 20:46:16 --> Helper loaded: url_helper
INFO - 2017-06-19 20:46:16 --> Upload Class Initialized
INFO - 2017-06-19 20:46:16 --> Final output sent to browser
DEBUG - 2017-06-19 20:46:16 --> Total execution time: 0.0630
ERROR - 2017-06-19 20:46:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 20:46:21 --> Config Class Initialized
INFO - 2017-06-19 20:46:21 --> Hooks Class Initialized
DEBUG - 2017-06-19 20:46:21 --> UTF-8 Support Enabled
INFO - 2017-06-19 20:46:21 --> Utf8 Class Initialized
INFO - 2017-06-19 20:46:21 --> URI Class Initialized
INFO - 2017-06-19 20:46:22 --> Router Class Initialized
INFO - 2017-06-19 20:46:22 --> Output Class Initialized
INFO - 2017-06-19 20:46:22 --> Security Class Initialized
DEBUG - 2017-06-19 20:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 20:46:22 --> Input Class Initialized
INFO - 2017-06-19 20:46:22 --> Language Class Initialized
INFO - 2017-06-19 20:46:22 --> Loader Class Initialized
INFO - 2017-06-19 20:46:22 --> Controller Class Initialized
INFO - 2017-06-19 20:46:22 --> Database Driver Class Initialized
INFO - 2017-06-19 20:46:22 --> Model Class Initialized
INFO - 2017-06-19 20:46:22 --> Helper loaded: form_helper
INFO - 2017-06-19 20:46:22 --> Helper loaded: url_helper
INFO - 2017-06-19 20:46:22 --> Model Class Initialized
INFO - 2017-06-19 20:46:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 20:46:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 20:46:22 --> Final output sent to browser
DEBUG - 2017-06-19 20:46:22 --> Total execution time: 0.1680
ERROR - 2017-06-19 20:46:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 20:46:25 --> Config Class Initialized
INFO - 2017-06-19 20:46:25 --> Hooks Class Initialized
DEBUG - 2017-06-19 20:46:25 --> UTF-8 Support Enabled
INFO - 2017-06-19 20:46:25 --> Utf8 Class Initialized
INFO - 2017-06-19 20:46:25 --> URI Class Initialized
INFO - 2017-06-19 20:46:25 --> Router Class Initialized
INFO - 2017-06-19 20:46:25 --> Output Class Initialized
INFO - 2017-06-19 20:46:25 --> Security Class Initialized
DEBUG - 2017-06-19 20:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 20:46:25 --> Input Class Initialized
INFO - 2017-06-19 20:46:25 --> Language Class Initialized
INFO - 2017-06-19 20:46:25 --> Loader Class Initialized
INFO - 2017-06-19 20:46:25 --> Controller Class Initialized
INFO - 2017-06-19 20:46:25 --> Database Driver Class Initialized
INFO - 2017-06-19 20:46:25 --> Model Class Initialized
INFO - 2017-06-19 20:46:25 --> Helper loaded: form_helper
INFO - 2017-06-19 20:46:25 --> Helper loaded: url_helper
INFO - 2017-06-19 20:46:25 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 20:46:25 --> Model Class Initialized
INFO - 2017-06-19 20:46:25 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-19 20:46:25 --> Final output sent to browser
DEBUG - 2017-06-19 20:46:25 --> Total execution time: 0.0800
ERROR - 2017-06-19 20:46:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 20:46:27 --> Config Class Initialized
INFO - 2017-06-19 20:46:27 --> Hooks Class Initialized
DEBUG - 2017-06-19 20:46:27 --> UTF-8 Support Enabled
INFO - 2017-06-19 20:46:27 --> Utf8 Class Initialized
INFO - 2017-06-19 20:46:27 --> URI Class Initialized
INFO - 2017-06-19 20:46:27 --> Router Class Initialized
INFO - 2017-06-19 20:46:27 --> Output Class Initialized
INFO - 2017-06-19 20:46:27 --> Security Class Initialized
DEBUG - 2017-06-19 20:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 20:46:27 --> Input Class Initialized
INFO - 2017-06-19 20:46:27 --> Language Class Initialized
INFO - 2017-06-19 20:46:27 --> Loader Class Initialized
INFO - 2017-06-19 20:46:27 --> Controller Class Initialized
INFO - 2017-06-19 20:46:27 --> Database Driver Class Initialized
INFO - 2017-06-19 20:46:27 --> Model Class Initialized
INFO - 2017-06-19 20:46:27 --> Helper loaded: form_helper
INFO - 2017-06-19 20:46:27 --> Helper loaded: url_helper
INFO - 2017-06-19 20:46:27 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 20:46:27 --> Model Class Initialized
INFO - 2017-06-19 20:46:27 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-19 20:46:27 --> Final output sent to browser
DEBUG - 2017-06-19 20:46:27 --> Total execution time: 0.0640
ERROR - 2017-06-19 20:46:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-19 20:46:31 --> Config Class Initialized
INFO - 2017-06-19 20:46:31 --> Hooks Class Initialized
DEBUG - 2017-06-19 20:46:31 --> UTF-8 Support Enabled
INFO - 2017-06-19 20:46:31 --> Utf8 Class Initialized
INFO - 2017-06-19 20:46:31 --> URI Class Initialized
INFO - 2017-06-19 20:46:31 --> Router Class Initialized
INFO - 2017-06-19 20:46:31 --> Output Class Initialized
INFO - 2017-06-19 20:46:31 --> Security Class Initialized
DEBUG - 2017-06-19 20:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-19 20:46:31 --> Input Class Initialized
INFO - 2017-06-19 20:46:31 --> Language Class Initialized
INFO - 2017-06-19 20:46:31 --> Loader Class Initialized
INFO - 2017-06-19 20:46:31 --> Controller Class Initialized
INFO - 2017-06-19 20:46:31 --> Database Driver Class Initialized
INFO - 2017-06-19 20:46:31 --> Model Class Initialized
INFO - 2017-06-19 20:46:31 --> Helper loaded: form_helper
INFO - 2017-06-19 20:46:31 --> Helper loaded: url_helper
INFO - 2017-06-19 20:46:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-19 20:46:31 --> Model Class Initialized
INFO - 2017-06-19 20:46:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-19 20:46:31 --> Final output sent to browser
DEBUG - 2017-06-19 20:46:31 --> Total execution time: 0.0860
