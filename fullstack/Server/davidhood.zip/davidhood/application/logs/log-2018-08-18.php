<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-18 06:00:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:00:19 --> Config Class Initialized
INFO - 2018-08-18 06:00:19 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:00:19 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:00:19 --> Utf8 Class Initialized
INFO - 2018-08-18 06:00:19 --> URI Class Initialized
DEBUG - 2018-08-18 06:00:19 --> No URI present. Default controller set.
INFO - 2018-08-18 06:00:19 --> Router Class Initialized
INFO - 2018-08-18 06:00:19 --> Output Class Initialized
INFO - 2018-08-18 06:00:19 --> Security Class Initialized
DEBUG - 2018-08-18 06:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:00:19 --> Input Class Initialized
INFO - 2018-08-18 06:00:19 --> Language Class Initialized
INFO - 2018-08-18 06:00:19 --> Loader Class Initialized
INFO - 2018-08-18 06:00:19 --> Controller Class Initialized
INFO - 2018-08-18 06:00:20 --> Database Driver Class Initialized
INFO - 2018-08-18 06:00:20 --> Model Class Initialized
INFO - 2018-08-18 06:00:20 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:00:20 --> Model Class Initialized
INFO - 2018-08-18 06:00:20 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-18 06:00:20 --> Final output sent to browser
DEBUG - 2018-08-18 06:00:20 --> Total execution time: 0.9014
ERROR - 2018-08-18 06:00:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:00:22 --> Config Class Initialized
INFO - 2018-08-18 06:00:22 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:00:22 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:00:22 --> Utf8 Class Initialized
INFO - 2018-08-18 06:00:22 --> URI Class Initialized
INFO - 2018-08-18 06:00:22 --> Router Class Initialized
INFO - 2018-08-18 06:00:22 --> Output Class Initialized
INFO - 2018-08-18 06:00:22 --> Security Class Initialized
DEBUG - 2018-08-18 06:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:00:22 --> Input Class Initialized
INFO - 2018-08-18 06:00:22 --> Language Class Initialized
INFO - 2018-08-18 06:00:22 --> Loader Class Initialized
INFO - 2018-08-18 06:00:22 --> Controller Class Initialized
INFO - 2018-08-18 06:00:22 --> Database Driver Class Initialized
INFO - 2018-08-18 06:00:22 --> Model Class Initialized
INFO - 2018-08-18 06:00:22 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:00:22 --> Model Class Initialized
ERROR - 2018-08-18 06:00:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:00:22 --> Config Class Initialized
INFO - 2018-08-18 06:00:22 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:00:22 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:00:22 --> Utf8 Class Initialized
INFO - 2018-08-18 06:00:22 --> URI Class Initialized
INFO - 2018-08-18 06:00:22 --> Router Class Initialized
INFO - 2018-08-18 06:00:22 --> Output Class Initialized
INFO - 2018-08-18 06:00:22 --> Security Class Initialized
DEBUG - 2018-08-18 06:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:00:22 --> Input Class Initialized
INFO - 2018-08-18 06:00:22 --> Language Class Initialized
INFO - 2018-08-18 06:00:22 --> Loader Class Initialized
INFO - 2018-08-18 06:00:22 --> Controller Class Initialized
INFO - 2018-08-18 06:00:22 --> Database Driver Class Initialized
INFO - 2018-08-18 06:00:22 --> Model Class Initialized
INFO - 2018-08-18 06:00:22 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:00:22 --> Model Class Initialized
INFO - 2018-08-18 06:00:22 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:00:22 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-18 06:00:22 --> Final output sent to browser
DEBUG - 2018-08-18 06:00:22 --> Total execution time: 0.3804
ERROR - 2018-08-18 06:00:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:00:25 --> Config Class Initialized
INFO - 2018-08-18 06:00:25 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:00:25 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:00:25 --> Utf8 Class Initialized
INFO - 2018-08-18 06:00:25 --> URI Class Initialized
INFO - 2018-08-18 06:00:25 --> Router Class Initialized
INFO - 2018-08-18 06:00:25 --> Output Class Initialized
INFO - 2018-08-18 06:00:25 --> Security Class Initialized
DEBUG - 2018-08-18 06:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:00:25 --> Input Class Initialized
INFO - 2018-08-18 06:00:25 --> Language Class Initialized
INFO - 2018-08-18 06:00:25 --> Loader Class Initialized
INFO - 2018-08-18 06:00:25 --> Controller Class Initialized
INFO - 2018-08-18 06:00:25 --> Database Driver Class Initialized
INFO - 2018-08-18 06:00:25 --> Model Class Initialized
INFO - 2018-08-18 06:00:25 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:00:26 --> Model Class Initialized
INFO - 2018-08-18 06:00:26 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-18 06:00:26 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 179
INFO - 2018-08-18 06:00:26 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-18 06:00:26 --> Final output sent to browser
DEBUG - 2018-08-18 06:00:26 --> Total execution time: 0.3081
ERROR - 2018-08-18 06:01:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:01:50 --> Config Class Initialized
INFO - 2018-08-18 06:01:50 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:01:50 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:01:50 --> Utf8 Class Initialized
INFO - 2018-08-18 06:01:50 --> URI Class Initialized
INFO - 2018-08-18 06:01:50 --> Router Class Initialized
INFO - 2018-08-18 06:01:50 --> Output Class Initialized
INFO - 2018-08-18 06:01:50 --> Security Class Initialized
DEBUG - 2018-08-18 06:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:01:50 --> Input Class Initialized
INFO - 2018-08-18 06:01:50 --> Language Class Initialized
INFO - 2018-08-18 06:01:50 --> Loader Class Initialized
INFO - 2018-08-18 06:01:50 --> Controller Class Initialized
INFO - 2018-08-18 06:01:50 --> Database Driver Class Initialized
INFO - 2018-08-18 06:01:50 --> Model Class Initialized
INFO - 2018-08-18 06:01:50 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:01:50 --> Model Class Initialized
INFO - 2018-08-18 06:01:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-18 06:01:50 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 179
INFO - 2018-08-18 06:01:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-18 06:01:50 --> Final output sent to browser
DEBUG - 2018-08-18 06:01:50 --> Total execution time: 0.1574
ERROR - 2018-08-18 06:02:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:02:53 --> Config Class Initialized
INFO - 2018-08-18 06:02:53 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:02:53 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:02:53 --> Utf8 Class Initialized
INFO - 2018-08-18 06:02:54 --> URI Class Initialized
INFO - 2018-08-18 06:02:54 --> Router Class Initialized
INFO - 2018-08-18 06:02:54 --> Output Class Initialized
INFO - 2018-08-18 06:02:54 --> Security Class Initialized
DEBUG - 2018-08-18 06:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:02:54 --> Input Class Initialized
INFO - 2018-08-18 06:02:54 --> Language Class Initialized
INFO - 2018-08-18 06:02:54 --> Loader Class Initialized
INFO - 2018-08-18 06:02:54 --> Controller Class Initialized
INFO - 2018-08-18 06:02:54 --> Database Driver Class Initialized
INFO - 2018-08-18 06:02:54 --> Model Class Initialized
INFO - 2018-08-18 06:02:54 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:02:54 --> Model Class Initialized
INFO - 2018-08-18 06:02:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-18 06:02:54 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 186
INFO - 2018-08-18 06:02:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-18 06:02:54 --> Final output sent to browser
DEBUG - 2018-08-18 06:02:54 --> Total execution time: 0.1832
ERROR - 2018-08-18 06:05:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:05:01 --> Config Class Initialized
INFO - 2018-08-18 06:05:01 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:05:01 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:05:01 --> Utf8 Class Initialized
INFO - 2018-08-18 06:05:01 --> URI Class Initialized
INFO - 2018-08-18 06:05:01 --> Router Class Initialized
INFO - 2018-08-18 06:05:01 --> Output Class Initialized
INFO - 2018-08-18 06:05:02 --> Security Class Initialized
DEBUG - 2018-08-18 06:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:05:02 --> Input Class Initialized
INFO - 2018-08-18 06:05:02 --> Language Class Initialized
INFO - 2018-08-18 06:05:02 --> Loader Class Initialized
INFO - 2018-08-18 06:05:02 --> Controller Class Initialized
INFO - 2018-08-18 06:05:02 --> Database Driver Class Initialized
INFO - 2018-08-18 06:05:02 --> Model Class Initialized
INFO - 2018-08-18 06:05:02 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:05:02 --> Model Class Initialized
INFO - 2018-08-18 06:05:02 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-18 06:05:02 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 186
INFO - 2018-08-18 06:05:02 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-18 06:05:02 --> Final output sent to browser
DEBUG - 2018-08-18 06:05:02 --> Total execution time: 0.1816
ERROR - 2018-08-18 06:06:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:06:52 --> Config Class Initialized
INFO - 2018-08-18 06:06:52 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:06:52 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:06:52 --> Utf8 Class Initialized
INFO - 2018-08-18 06:06:52 --> URI Class Initialized
INFO - 2018-08-18 06:06:52 --> Router Class Initialized
INFO - 2018-08-18 06:06:52 --> Output Class Initialized
INFO - 2018-08-18 06:06:52 --> Security Class Initialized
DEBUG - 2018-08-18 06:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:06:52 --> Input Class Initialized
INFO - 2018-08-18 06:06:52 --> Language Class Initialized
INFO - 2018-08-18 06:06:52 --> Loader Class Initialized
INFO - 2018-08-18 06:06:52 --> Controller Class Initialized
INFO - 2018-08-18 06:06:52 --> Database Driver Class Initialized
INFO - 2018-08-18 06:06:52 --> Model Class Initialized
INFO - 2018-08-18 06:06:52 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:06:52 --> Model Class Initialized
INFO - 2018-08-18 06:06:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-18 06:06:52 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 186
INFO - 2018-08-18 06:06:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-18 06:06:52 --> Final output sent to browser
DEBUG - 2018-08-18 06:06:52 --> Total execution time: 0.1910
ERROR - 2018-08-18 06:07:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:07:15 --> Config Class Initialized
INFO - 2018-08-18 06:07:15 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:07:15 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:07:15 --> Utf8 Class Initialized
INFO - 2018-08-18 06:07:15 --> URI Class Initialized
INFO - 2018-08-18 06:07:15 --> Router Class Initialized
INFO - 2018-08-18 06:07:15 --> Output Class Initialized
INFO - 2018-08-18 06:07:15 --> Security Class Initialized
DEBUG - 2018-08-18 06:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:07:15 --> Input Class Initialized
INFO - 2018-08-18 06:07:15 --> Language Class Initialized
INFO - 2018-08-18 06:07:15 --> Loader Class Initialized
INFO - 2018-08-18 06:07:15 --> Controller Class Initialized
INFO - 2018-08-18 06:07:15 --> Database Driver Class Initialized
INFO - 2018-08-18 06:07:15 --> Model Class Initialized
INFO - 2018-08-18 06:07:15 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:07:15 --> Model Class Initialized
INFO - 2018-08-18 06:07:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-18 06:07:15 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 187
INFO - 2018-08-18 06:07:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-18 06:07:15 --> Final output sent to browser
DEBUG - 2018-08-18 06:07:15 --> Total execution time: 0.1943
ERROR - 2018-08-18 06:10:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:10:09 --> Config Class Initialized
INFO - 2018-08-18 06:10:09 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:10:09 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:10:09 --> Utf8 Class Initialized
INFO - 2018-08-18 06:10:09 --> URI Class Initialized
INFO - 2018-08-18 06:10:09 --> Router Class Initialized
INFO - 2018-08-18 06:10:09 --> Output Class Initialized
INFO - 2018-08-18 06:10:09 --> Security Class Initialized
DEBUG - 2018-08-18 06:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:10:09 --> Input Class Initialized
INFO - 2018-08-18 06:10:09 --> Language Class Initialized
INFO - 2018-08-18 06:10:09 --> Loader Class Initialized
INFO - 2018-08-18 06:10:09 --> Controller Class Initialized
INFO - 2018-08-18 06:10:09 --> Database Driver Class Initialized
INFO - 2018-08-18 06:10:09 --> Model Class Initialized
INFO - 2018-08-18 06:10:09 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:10:09 --> Model Class Initialized
INFO - 2018-08-18 06:10:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-18 06:10:09 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 219
INFO - 2018-08-18 06:10:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-18 06:10:09 --> Final output sent to browser
DEBUG - 2018-08-18 06:10:09 --> Total execution time: 0.1868
ERROR - 2018-08-18 06:10:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:10:44 --> Config Class Initialized
INFO - 2018-08-18 06:10:44 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:10:44 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:10:44 --> Utf8 Class Initialized
INFO - 2018-08-18 06:10:44 --> URI Class Initialized
INFO - 2018-08-18 06:10:44 --> Router Class Initialized
INFO - 2018-08-18 06:10:44 --> Output Class Initialized
INFO - 2018-08-18 06:10:44 --> Security Class Initialized
DEBUG - 2018-08-18 06:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:10:44 --> Input Class Initialized
INFO - 2018-08-18 06:10:44 --> Language Class Initialized
INFO - 2018-08-18 06:10:44 --> Loader Class Initialized
INFO - 2018-08-18 06:10:44 --> Controller Class Initialized
INFO - 2018-08-18 06:10:44 --> Database Driver Class Initialized
INFO - 2018-08-18 06:10:45 --> Model Class Initialized
INFO - 2018-08-18 06:10:45 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:10:45 --> Model Class Initialized
INFO - 2018-08-18 06:10:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-18 06:10:45 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 219
INFO - 2018-08-18 06:10:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-18 06:10:45 --> Final output sent to browser
DEBUG - 2018-08-18 06:10:45 --> Total execution time: 0.2214
ERROR - 2018-08-18 06:11:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:11:52 --> Config Class Initialized
INFO - 2018-08-18 06:11:52 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:11:52 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:11:52 --> Utf8 Class Initialized
INFO - 2018-08-18 06:11:52 --> URI Class Initialized
INFO - 2018-08-18 06:11:52 --> Router Class Initialized
INFO - 2018-08-18 06:11:52 --> Output Class Initialized
INFO - 2018-08-18 06:11:52 --> Security Class Initialized
DEBUG - 2018-08-18 06:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:11:52 --> Input Class Initialized
INFO - 2018-08-18 06:11:52 --> Language Class Initialized
INFO - 2018-08-18 06:11:52 --> Loader Class Initialized
INFO - 2018-08-18 06:11:52 --> Controller Class Initialized
INFO - 2018-08-18 06:11:52 --> Database Driver Class Initialized
INFO - 2018-08-18 06:11:52 --> Model Class Initialized
INFO - 2018-08-18 06:11:52 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:11:52 --> Model Class Initialized
INFO - 2018-08-18 06:11:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-18 06:11:52 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 221
INFO - 2018-08-18 06:11:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-18 06:11:52 --> Final output sent to browser
DEBUG - 2018-08-18 06:11:52 --> Total execution time: 0.1812
ERROR - 2018-08-18 06:12:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:12:04 --> Config Class Initialized
INFO - 2018-08-18 06:12:04 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:12:04 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:12:04 --> Utf8 Class Initialized
INFO - 2018-08-18 06:12:04 --> URI Class Initialized
INFO - 2018-08-18 06:12:04 --> Router Class Initialized
INFO - 2018-08-18 06:12:04 --> Output Class Initialized
INFO - 2018-08-18 06:12:04 --> Security Class Initialized
DEBUG - 2018-08-18 06:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:12:04 --> Input Class Initialized
INFO - 2018-08-18 06:12:04 --> Language Class Initialized
INFO - 2018-08-18 06:12:04 --> Loader Class Initialized
INFO - 2018-08-18 06:12:04 --> Controller Class Initialized
INFO - 2018-08-18 06:12:04 --> Database Driver Class Initialized
INFO - 2018-08-18 06:12:04 --> Model Class Initialized
INFO - 2018-08-18 06:12:04 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:12:04 --> Model Class Initialized
INFO - 2018-08-18 06:12:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-18 06:12:04 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 221
INFO - 2018-08-18 06:12:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-18 06:12:04 --> Final output sent to browser
DEBUG - 2018-08-18 06:12:04 --> Total execution time: 0.2046
ERROR - 2018-08-18 06:12:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:12:10 --> Config Class Initialized
INFO - 2018-08-18 06:12:10 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:12:10 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:12:10 --> Utf8 Class Initialized
INFO - 2018-08-18 06:12:10 --> URI Class Initialized
INFO - 2018-08-18 06:12:10 --> Router Class Initialized
INFO - 2018-08-18 06:12:10 --> Output Class Initialized
INFO - 2018-08-18 06:12:10 --> Security Class Initialized
DEBUG - 2018-08-18 06:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:12:10 --> Input Class Initialized
INFO - 2018-08-18 06:12:10 --> Language Class Initialized
INFO - 2018-08-18 06:12:10 --> Loader Class Initialized
INFO - 2018-08-18 06:12:10 --> Controller Class Initialized
INFO - 2018-08-18 06:12:10 --> Database Driver Class Initialized
INFO - 2018-08-18 06:12:10 --> Model Class Initialized
INFO - 2018-08-18 06:12:10 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:12:10 --> Model Class Initialized
INFO - 2018-08-18 06:12:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-18 06:12:10 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 221
INFO - 2018-08-18 06:12:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-18 06:12:10 --> Final output sent to browser
DEBUG - 2018-08-18 06:12:10 --> Total execution time: 0.2029
ERROR - 2018-08-18 06:15:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:15:26 --> Config Class Initialized
INFO - 2018-08-18 06:15:26 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:15:26 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:15:26 --> Utf8 Class Initialized
INFO - 2018-08-18 06:15:26 --> URI Class Initialized
INFO - 2018-08-18 06:15:26 --> Router Class Initialized
INFO - 2018-08-18 06:15:26 --> Output Class Initialized
INFO - 2018-08-18 06:15:26 --> Security Class Initialized
DEBUG - 2018-08-18 06:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:15:26 --> Input Class Initialized
INFO - 2018-08-18 06:15:26 --> Language Class Initialized
INFO - 2018-08-18 06:15:26 --> Loader Class Initialized
INFO - 2018-08-18 06:15:26 --> Controller Class Initialized
INFO - 2018-08-18 06:15:26 --> Database Driver Class Initialized
INFO - 2018-08-18 06:15:26 --> Model Class Initialized
INFO - 2018-08-18 06:15:26 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:15:26 --> Model Class Initialized
INFO - 2018-08-18 06:15:26 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-18 06:15:26 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 221
INFO - 2018-08-18 06:15:26 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-18 06:15:26 --> Final output sent to browser
DEBUG - 2018-08-18 06:15:26 --> Total execution time: 0.1722
ERROR - 2018-08-18 06:15:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:15:29 --> Config Class Initialized
INFO - 2018-08-18 06:15:29 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:15:29 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:15:29 --> Utf8 Class Initialized
INFO - 2018-08-18 06:15:29 --> URI Class Initialized
INFO - 2018-08-18 06:15:29 --> Router Class Initialized
INFO - 2018-08-18 06:15:29 --> Output Class Initialized
INFO - 2018-08-18 06:15:29 --> Security Class Initialized
DEBUG - 2018-08-18 06:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:15:29 --> Input Class Initialized
INFO - 2018-08-18 06:15:29 --> Language Class Initialized
INFO - 2018-08-18 06:15:29 --> Loader Class Initialized
INFO - 2018-08-18 06:15:29 --> Controller Class Initialized
INFO - 2018-08-18 06:15:29 --> Database Driver Class Initialized
INFO - 2018-08-18 06:15:29 --> Model Class Initialized
INFO - 2018-08-18 06:15:29 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:15:29 --> Model Class Initialized
INFO - 2018-08-18 06:15:29 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-18 06:15:29 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 221
INFO - 2018-08-18 06:15:29 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-18 06:15:29 --> Final output sent to browser
DEBUG - 2018-08-18 06:15:29 --> Total execution time: 0.2788
ERROR - 2018-08-18 06:15:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:15:37 --> Config Class Initialized
INFO - 2018-08-18 06:15:37 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:15:37 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:15:37 --> Utf8 Class Initialized
INFO - 2018-08-18 06:15:37 --> URI Class Initialized
INFO - 2018-08-18 06:15:37 --> Router Class Initialized
INFO - 2018-08-18 06:15:37 --> Output Class Initialized
INFO - 2018-08-18 06:15:38 --> Security Class Initialized
DEBUG - 2018-08-18 06:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:15:38 --> Input Class Initialized
INFO - 2018-08-18 06:15:38 --> Language Class Initialized
INFO - 2018-08-18 06:15:38 --> Loader Class Initialized
INFO - 2018-08-18 06:15:38 --> Controller Class Initialized
INFO - 2018-08-18 06:15:38 --> Database Driver Class Initialized
INFO - 2018-08-18 06:15:38 --> Model Class Initialized
INFO - 2018-08-18 06:15:38 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:15:38 --> Model Class Initialized
INFO - 2018-08-18 06:15:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-18 06:15:38 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 221
INFO - 2018-08-18 06:15:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-18 06:15:38 --> Final output sent to browser
DEBUG - 2018-08-18 06:15:38 --> Total execution time: 0.2036
ERROR - 2018-08-18 06:16:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:16:04 --> Config Class Initialized
INFO - 2018-08-18 06:16:04 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:16:04 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:16:04 --> Utf8 Class Initialized
INFO - 2018-08-18 06:16:04 --> URI Class Initialized
INFO - 2018-08-18 06:16:04 --> Router Class Initialized
INFO - 2018-08-18 06:16:04 --> Output Class Initialized
INFO - 2018-08-18 06:16:04 --> Security Class Initialized
DEBUG - 2018-08-18 06:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:16:04 --> Input Class Initialized
INFO - 2018-08-18 06:16:04 --> Language Class Initialized
INFO - 2018-08-18 06:16:04 --> Loader Class Initialized
INFO - 2018-08-18 06:16:04 --> Controller Class Initialized
INFO - 2018-08-18 06:16:04 --> Database Driver Class Initialized
INFO - 2018-08-18 06:16:04 --> Model Class Initialized
INFO - 2018-08-18 06:16:04 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:16:04 --> Model Class Initialized
INFO - 2018-08-18 06:16:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-18 06:16:04 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 221
INFO - 2018-08-18 06:16:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-18 06:16:04 --> Final output sent to browser
DEBUG - 2018-08-18 06:16:05 --> Total execution time: 0.2647
ERROR - 2018-08-18 06:17:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:17:25 --> Config Class Initialized
INFO - 2018-08-18 06:17:25 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:17:25 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:17:25 --> Utf8 Class Initialized
INFO - 2018-08-18 06:17:25 --> URI Class Initialized
INFO - 2018-08-18 06:17:25 --> Router Class Initialized
INFO - 2018-08-18 06:17:25 --> Output Class Initialized
INFO - 2018-08-18 06:17:25 --> Security Class Initialized
DEBUG - 2018-08-18 06:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:17:25 --> Input Class Initialized
INFO - 2018-08-18 06:17:25 --> Language Class Initialized
INFO - 2018-08-18 06:17:25 --> Loader Class Initialized
INFO - 2018-08-18 06:17:25 --> Controller Class Initialized
INFO - 2018-08-18 06:17:25 --> Database Driver Class Initialized
INFO - 2018-08-18 06:17:25 --> Model Class Initialized
INFO - 2018-08-18 06:17:25 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:17:25 --> Model Class Initialized
INFO - 2018-08-18 06:17:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:17:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\question.php
INFO - 2018-08-18 06:17:25 --> Final output sent to browser
DEBUG - 2018-08-18 06:17:25 --> Total execution time: 0.2405
ERROR - 2018-08-18 06:17:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:17:26 --> Config Class Initialized
INFO - 2018-08-18 06:17:26 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:17:26 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:17:26 --> Utf8 Class Initialized
INFO - 2018-08-18 06:17:26 --> URI Class Initialized
INFO - 2018-08-18 06:17:26 --> Router Class Initialized
INFO - 2018-08-18 06:17:26 --> Output Class Initialized
INFO - 2018-08-18 06:17:26 --> Security Class Initialized
DEBUG - 2018-08-18 06:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:17:26 --> Input Class Initialized
INFO - 2018-08-18 06:17:26 --> Language Class Initialized
INFO - 2018-08-18 06:17:26 --> Loader Class Initialized
INFO - 2018-08-18 06:17:26 --> Controller Class Initialized
INFO - 2018-08-18 06:17:26 --> Database Driver Class Initialized
INFO - 2018-08-18 06:17:26 --> Model Class Initialized
INFO - 2018-08-18 06:17:26 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:17:26 --> Model Class Initialized
INFO - 2018-08-18 06:17:26 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:17:26 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-08-18 06:17:26 --> Final output sent to browser
DEBUG - 2018-08-18 06:17:26 --> Total execution time: 0.2051
ERROR - 2018-08-18 06:19:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:19:46 --> Config Class Initialized
INFO - 2018-08-18 06:19:46 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:19:46 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:19:46 --> Utf8 Class Initialized
INFO - 2018-08-18 06:19:46 --> URI Class Initialized
INFO - 2018-08-18 06:19:46 --> Router Class Initialized
INFO - 2018-08-18 06:19:46 --> Output Class Initialized
INFO - 2018-08-18 06:19:46 --> Security Class Initialized
DEBUG - 2018-08-18 06:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:19:46 --> Input Class Initialized
INFO - 2018-08-18 06:19:46 --> Language Class Initialized
INFO - 2018-08-18 06:19:46 --> Loader Class Initialized
INFO - 2018-08-18 06:19:46 --> Controller Class Initialized
INFO - 2018-08-18 06:19:47 --> Database Driver Class Initialized
INFO - 2018-08-18 06:19:47 --> Model Class Initialized
INFO - 2018-08-18 06:19:47 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:19:47 --> Model Class Initialized
INFO - 2018-08-18 06:19:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:19:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-08-18 06:19:47 --> Final output sent to browser
DEBUG - 2018-08-18 06:19:47 --> Total execution time: 0.1562
ERROR - 2018-08-18 06:19:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:19:48 --> Config Class Initialized
INFO - 2018-08-18 06:19:48 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:19:48 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:19:48 --> Utf8 Class Initialized
INFO - 2018-08-18 06:19:48 --> URI Class Initialized
INFO - 2018-08-18 06:19:48 --> Router Class Initialized
INFO - 2018-08-18 06:19:48 --> Output Class Initialized
INFO - 2018-08-18 06:19:48 --> Security Class Initialized
DEBUG - 2018-08-18 06:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:19:48 --> Input Class Initialized
INFO - 2018-08-18 06:19:48 --> Language Class Initialized
INFO - 2018-08-18 06:19:48 --> Loader Class Initialized
INFO - 2018-08-18 06:19:48 --> Controller Class Initialized
INFO - 2018-08-18 06:19:48 --> Database Driver Class Initialized
INFO - 2018-08-18 06:19:48 --> Model Class Initialized
INFO - 2018-08-18 06:19:48 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:19:48 --> Model Class Initialized
INFO - 2018-08-18 06:19:48 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:19:48 --> File loaded: C:\xampp\htdocs\davidhood\application\views\payment_made.php
INFO - 2018-08-18 06:19:48 --> Final output sent to browser
DEBUG - 2018-08-18 06:19:48 --> Total execution time: 0.1483
ERROR - 2018-08-18 06:19:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:19:50 --> Config Class Initialized
INFO - 2018-08-18 06:19:50 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:19:50 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:19:50 --> Utf8 Class Initialized
INFO - 2018-08-18 06:19:50 --> URI Class Initialized
INFO - 2018-08-18 06:19:50 --> Router Class Initialized
INFO - 2018-08-18 06:19:50 --> Output Class Initialized
INFO - 2018-08-18 06:19:50 --> Security Class Initialized
DEBUG - 2018-08-18 06:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:19:50 --> Input Class Initialized
INFO - 2018-08-18 06:19:50 --> Language Class Initialized
INFO - 2018-08-18 06:19:50 --> Loader Class Initialized
INFO - 2018-08-18 06:19:50 --> Controller Class Initialized
INFO - 2018-08-18 06:19:50 --> Database Driver Class Initialized
INFO - 2018-08-18 06:19:50 --> Model Class Initialized
INFO - 2018-08-18 06:19:50 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:19:50 --> Model Class Initialized
INFO - 2018-08-18 06:19:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:19:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-08-18 06:19:50 --> Final output sent to browser
DEBUG - 2018-08-18 06:19:50 --> Total execution time: 0.1798
ERROR - 2018-08-18 06:19:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:19:51 --> Config Class Initialized
INFO - 2018-08-18 06:19:51 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:19:51 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:19:51 --> Utf8 Class Initialized
INFO - 2018-08-18 06:19:51 --> URI Class Initialized
INFO - 2018-08-18 06:19:51 --> Router Class Initialized
INFO - 2018-08-18 06:19:51 --> Output Class Initialized
INFO - 2018-08-18 06:19:51 --> Security Class Initialized
DEBUG - 2018-08-18 06:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:19:51 --> Input Class Initialized
INFO - 2018-08-18 06:19:51 --> Language Class Initialized
INFO - 2018-08-18 06:19:51 --> Loader Class Initialized
INFO - 2018-08-18 06:19:51 --> Controller Class Initialized
INFO - 2018-08-18 06:19:51 --> Database Driver Class Initialized
INFO - 2018-08-18 06:19:51 --> Model Class Initialized
INFO - 2018-08-18 06:19:51 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:19:51 --> Model Class Initialized
INFO - 2018-08-18 06:19:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:19:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\payment_made.php
INFO - 2018-08-18 06:19:51 --> Final output sent to browser
DEBUG - 2018-08-18 06:19:51 --> Total execution time: 0.1580
ERROR - 2018-08-18 06:21:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:21:18 --> Config Class Initialized
INFO - 2018-08-18 06:21:18 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:21:18 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:21:18 --> Utf8 Class Initialized
INFO - 2018-08-18 06:21:18 --> URI Class Initialized
INFO - 2018-08-18 06:21:18 --> Router Class Initialized
INFO - 2018-08-18 06:21:18 --> Output Class Initialized
INFO - 2018-08-18 06:21:18 --> Security Class Initialized
DEBUG - 2018-08-18 06:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:21:18 --> Input Class Initialized
INFO - 2018-08-18 06:21:18 --> Language Class Initialized
INFO - 2018-08-18 06:21:18 --> Loader Class Initialized
INFO - 2018-08-18 06:21:18 --> Controller Class Initialized
INFO - 2018-08-18 06:21:18 --> Database Driver Class Initialized
INFO - 2018-08-18 06:21:18 --> Model Class Initialized
INFO - 2018-08-18 06:21:18 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:21:18 --> Model Class Initialized
INFO - 2018-08-18 06:21:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-18 06:21:18 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\davidhood\application\views\payment_made.php 58
ERROR - 2018-08-18 06:21:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:21:34 --> Config Class Initialized
INFO - 2018-08-18 06:21:34 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:21:34 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:21:34 --> Utf8 Class Initialized
INFO - 2018-08-18 06:21:34 --> URI Class Initialized
INFO - 2018-08-18 06:21:34 --> Router Class Initialized
INFO - 2018-08-18 06:21:34 --> Output Class Initialized
INFO - 2018-08-18 06:21:34 --> Security Class Initialized
DEBUG - 2018-08-18 06:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:21:34 --> Input Class Initialized
INFO - 2018-08-18 06:21:34 --> Language Class Initialized
INFO - 2018-08-18 06:21:34 --> Loader Class Initialized
INFO - 2018-08-18 06:21:34 --> Controller Class Initialized
INFO - 2018-08-18 06:21:34 --> Database Driver Class Initialized
INFO - 2018-08-18 06:21:34 --> Model Class Initialized
INFO - 2018-08-18 06:21:34 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:21:34 --> Model Class Initialized
INFO - 2018-08-18 06:21:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:21:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\payment_made.php
INFO - 2018-08-18 06:21:34 --> Final output sent to browser
DEBUG - 2018-08-18 06:21:34 --> Total execution time: 0.1666
ERROR - 2018-08-18 06:21:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:21:54 --> Config Class Initialized
INFO - 2018-08-18 06:21:54 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:21:54 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:21:54 --> Utf8 Class Initialized
INFO - 2018-08-18 06:21:54 --> URI Class Initialized
INFO - 2018-08-18 06:21:54 --> Router Class Initialized
INFO - 2018-08-18 06:21:54 --> Output Class Initialized
INFO - 2018-08-18 06:21:54 --> Security Class Initialized
DEBUG - 2018-08-18 06:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:21:54 --> Input Class Initialized
INFO - 2018-08-18 06:21:54 --> Language Class Initialized
INFO - 2018-08-18 06:21:54 --> Loader Class Initialized
INFO - 2018-08-18 06:21:54 --> Controller Class Initialized
INFO - 2018-08-18 06:21:54 --> Database Driver Class Initialized
INFO - 2018-08-18 06:21:54 --> Model Class Initialized
INFO - 2018-08-18 06:21:55 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:21:55 --> Model Class Initialized
INFO - 2018-08-18 06:21:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:21:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\payment_made.php
INFO - 2018-08-18 06:21:55 --> Final output sent to browser
DEBUG - 2018-08-18 06:21:55 --> Total execution time: 0.1862
ERROR - 2018-08-18 06:22:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:22:14 --> Config Class Initialized
INFO - 2018-08-18 06:22:14 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:22:14 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:22:14 --> Utf8 Class Initialized
INFO - 2018-08-18 06:22:14 --> URI Class Initialized
INFO - 2018-08-18 06:22:14 --> Router Class Initialized
INFO - 2018-08-18 06:22:14 --> Output Class Initialized
INFO - 2018-08-18 06:22:14 --> Security Class Initialized
DEBUG - 2018-08-18 06:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:22:14 --> Input Class Initialized
INFO - 2018-08-18 06:22:14 --> Language Class Initialized
INFO - 2018-08-18 06:22:14 --> Loader Class Initialized
INFO - 2018-08-18 06:22:14 --> Controller Class Initialized
INFO - 2018-08-18 06:22:14 --> Database Driver Class Initialized
INFO - 2018-08-18 06:22:14 --> Model Class Initialized
INFO - 2018-08-18 06:22:14 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:22:14 --> Model Class Initialized
INFO - 2018-08-18 06:22:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:22:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\payment_made.php
INFO - 2018-08-18 06:22:14 --> Final output sent to browser
DEBUG - 2018-08-18 06:22:14 --> Total execution time: 0.1677
ERROR - 2018-08-18 06:22:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:22:18 --> Config Class Initialized
INFO - 2018-08-18 06:22:18 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:22:18 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:22:18 --> Utf8 Class Initialized
INFO - 2018-08-18 06:22:18 --> URI Class Initialized
INFO - 2018-08-18 06:22:18 --> Router Class Initialized
INFO - 2018-08-18 06:22:18 --> Output Class Initialized
INFO - 2018-08-18 06:22:18 --> Security Class Initialized
DEBUG - 2018-08-18 06:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:22:18 --> Input Class Initialized
INFO - 2018-08-18 06:22:18 --> Language Class Initialized
INFO - 2018-08-18 06:22:18 --> Loader Class Initialized
INFO - 2018-08-18 06:22:18 --> Controller Class Initialized
INFO - 2018-08-18 06:22:18 --> Database Driver Class Initialized
INFO - 2018-08-18 06:22:18 --> Model Class Initialized
INFO - 2018-08-18 06:22:18 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:22:18 --> Model Class Initialized
INFO - 2018-08-18 06:22:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:22:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-08-18 06:22:18 --> Final output sent to browser
DEBUG - 2018-08-18 06:22:18 --> Total execution time: 0.1632
ERROR - 2018-08-18 06:23:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:23:08 --> Config Class Initialized
INFO - 2018-08-18 06:23:08 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:23:08 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:23:08 --> Utf8 Class Initialized
INFO - 2018-08-18 06:23:08 --> URI Class Initialized
INFO - 2018-08-18 06:23:08 --> Router Class Initialized
INFO - 2018-08-18 06:23:08 --> Output Class Initialized
INFO - 2018-08-18 06:23:08 --> Security Class Initialized
DEBUG - 2018-08-18 06:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:23:08 --> Input Class Initialized
INFO - 2018-08-18 06:23:08 --> Language Class Initialized
INFO - 2018-08-18 06:23:08 --> Loader Class Initialized
INFO - 2018-08-18 06:23:08 --> Controller Class Initialized
INFO - 2018-08-18 06:23:08 --> Database Driver Class Initialized
INFO - 2018-08-18 06:23:08 --> Model Class Initialized
INFO - 2018-08-18 06:23:08 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:23:08 --> Model Class Initialized
INFO - 2018-08-18 06:23:08 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:23:08 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-08-18 06:23:08 --> Final output sent to browser
DEBUG - 2018-08-18 06:23:08 --> Total execution time: 0.1564
ERROR - 2018-08-18 06:23:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:23:09 --> Config Class Initialized
INFO - 2018-08-18 06:23:09 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:23:09 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:23:09 --> Utf8 Class Initialized
INFO - 2018-08-18 06:23:09 --> URI Class Initialized
INFO - 2018-08-18 06:23:09 --> Router Class Initialized
INFO - 2018-08-18 06:23:09 --> Output Class Initialized
INFO - 2018-08-18 06:23:09 --> Security Class Initialized
DEBUG - 2018-08-18 06:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:23:09 --> Input Class Initialized
INFO - 2018-08-18 06:23:09 --> Language Class Initialized
INFO - 2018-08-18 06:23:09 --> Loader Class Initialized
INFO - 2018-08-18 06:23:09 --> Controller Class Initialized
INFO - 2018-08-18 06:23:09 --> Database Driver Class Initialized
INFO - 2018-08-18 06:23:09 --> Model Class Initialized
INFO - 2018-08-18 06:23:09 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:23:09 --> Model Class Initialized
INFO - 2018-08-18 06:23:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:23:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\payment_made.php
INFO - 2018-08-18 06:23:09 --> Final output sent to browser
DEBUG - 2018-08-18 06:23:09 --> Total execution time: 0.1678
ERROR - 2018-08-18 06:23:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:23:11 --> Config Class Initialized
INFO - 2018-08-18 06:23:11 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:23:11 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:23:11 --> Utf8 Class Initialized
INFO - 2018-08-18 06:23:11 --> URI Class Initialized
INFO - 2018-08-18 06:23:11 --> Router Class Initialized
INFO - 2018-08-18 06:23:11 --> Output Class Initialized
INFO - 2018-08-18 06:23:11 --> Security Class Initialized
DEBUG - 2018-08-18 06:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:23:11 --> Input Class Initialized
INFO - 2018-08-18 06:23:11 --> Language Class Initialized
INFO - 2018-08-18 06:23:11 --> Loader Class Initialized
INFO - 2018-08-18 06:23:11 --> Controller Class Initialized
INFO - 2018-08-18 06:23:11 --> Database Driver Class Initialized
INFO - 2018-08-18 06:23:11 --> Model Class Initialized
INFO - 2018-08-18 06:23:11 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:23:11 --> Model Class Initialized
INFO - 2018-08-18 06:23:11 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:23:11 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-08-18 06:23:11 --> Final output sent to browser
DEBUG - 2018-08-18 06:23:11 --> Total execution time: 0.1660
ERROR - 2018-08-18 06:23:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:23:14 --> Config Class Initialized
INFO - 2018-08-18 06:23:14 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:23:14 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:23:14 --> Utf8 Class Initialized
INFO - 2018-08-18 06:23:14 --> URI Class Initialized
INFO - 2018-08-18 06:23:14 --> Router Class Initialized
INFO - 2018-08-18 06:23:14 --> Output Class Initialized
INFO - 2018-08-18 06:23:14 --> Security Class Initialized
DEBUG - 2018-08-18 06:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:23:14 --> Input Class Initialized
INFO - 2018-08-18 06:23:14 --> Language Class Initialized
INFO - 2018-08-18 06:23:14 --> Loader Class Initialized
INFO - 2018-08-18 06:23:14 --> Controller Class Initialized
INFO - 2018-08-18 06:23:14 --> Database Driver Class Initialized
INFO - 2018-08-18 06:23:14 --> Model Class Initialized
INFO - 2018-08-18 06:23:14 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:23:14 --> Model Class Initialized
INFO - 2018-08-18 06:23:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:23:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\payment_made.php
INFO - 2018-08-18 06:23:14 --> Final output sent to browser
DEBUG - 2018-08-18 06:23:14 --> Total execution time: 0.1872
ERROR - 2018-08-18 06:23:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:23:17 --> Config Class Initialized
INFO - 2018-08-18 06:23:17 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:23:17 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:23:17 --> Utf8 Class Initialized
INFO - 2018-08-18 06:23:17 --> URI Class Initialized
INFO - 2018-08-18 06:23:17 --> Router Class Initialized
INFO - 2018-08-18 06:23:17 --> Output Class Initialized
INFO - 2018-08-18 06:23:17 --> Security Class Initialized
DEBUG - 2018-08-18 06:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:23:17 --> Input Class Initialized
INFO - 2018-08-18 06:23:17 --> Language Class Initialized
INFO - 2018-08-18 06:23:17 --> Loader Class Initialized
INFO - 2018-08-18 06:23:17 --> Controller Class Initialized
INFO - 2018-08-18 06:23:17 --> Database Driver Class Initialized
INFO - 2018-08-18 06:23:17 --> Model Class Initialized
INFO - 2018-08-18 06:23:17 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:23:17 --> Model Class Initialized
INFO - 2018-08-18 06:23:17 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:23:17 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-08-18 06:23:17 --> Final output sent to browser
DEBUG - 2018-08-18 06:23:17 --> Total execution time: 0.1827
ERROR - 2018-08-18 06:23:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:23:18 --> Config Class Initialized
INFO - 2018-08-18 06:23:18 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:23:18 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:23:18 --> Utf8 Class Initialized
INFO - 2018-08-18 06:23:18 --> URI Class Initialized
INFO - 2018-08-18 06:23:18 --> Router Class Initialized
INFO - 2018-08-18 06:23:19 --> Output Class Initialized
INFO - 2018-08-18 06:23:19 --> Security Class Initialized
DEBUG - 2018-08-18 06:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:23:19 --> Input Class Initialized
INFO - 2018-08-18 06:23:19 --> Language Class Initialized
INFO - 2018-08-18 06:23:19 --> Loader Class Initialized
INFO - 2018-08-18 06:23:19 --> Controller Class Initialized
INFO - 2018-08-18 06:23:19 --> Database Driver Class Initialized
INFO - 2018-08-18 06:23:19 --> Model Class Initialized
INFO - 2018-08-18 06:23:19 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:23:19 --> Model Class Initialized
ERROR - 2018-08-18 06:23:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:23:19 --> Config Class Initialized
INFO - 2018-08-18 06:23:19 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:23:19 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:23:19 --> Utf8 Class Initialized
INFO - 2018-08-18 06:23:19 --> URI Class Initialized
INFO - 2018-08-18 06:23:19 --> Router Class Initialized
INFO - 2018-08-18 06:23:19 --> Output Class Initialized
INFO - 2018-08-18 06:23:19 --> Security Class Initialized
DEBUG - 2018-08-18 06:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:23:19 --> Input Class Initialized
INFO - 2018-08-18 06:23:19 --> Language Class Initialized
INFO - 2018-08-18 06:23:19 --> Loader Class Initialized
INFO - 2018-08-18 06:23:19 --> Controller Class Initialized
INFO - 2018-08-18 06:23:19 --> Database Driver Class Initialized
INFO - 2018-08-18 06:23:19 --> Model Class Initialized
INFO - 2018-08-18 06:23:19 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:23:19 --> Model Class Initialized
INFO - 2018-08-18 06:23:19 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:23:19 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-08-18 06:23:19 --> Final output sent to browser
DEBUG - 2018-08-18 06:23:19 --> Total execution time: 0.2072
ERROR - 2018-08-18 06:23:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:23:22 --> Config Class Initialized
INFO - 2018-08-18 06:23:22 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:23:22 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:23:22 --> Utf8 Class Initialized
INFO - 2018-08-18 06:23:22 --> URI Class Initialized
INFO - 2018-08-18 06:23:22 --> Router Class Initialized
INFO - 2018-08-18 06:23:22 --> Output Class Initialized
INFO - 2018-08-18 06:23:22 --> Security Class Initialized
DEBUG - 2018-08-18 06:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:23:22 --> Input Class Initialized
INFO - 2018-08-18 06:23:22 --> Language Class Initialized
INFO - 2018-08-18 06:23:22 --> Loader Class Initialized
INFO - 2018-08-18 06:23:22 --> Controller Class Initialized
INFO - 2018-08-18 06:23:22 --> Database Driver Class Initialized
INFO - 2018-08-18 06:23:22 --> Model Class Initialized
INFO - 2018-08-18 06:23:22 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:23:22 --> Model Class Initialized
INFO - 2018-08-18 06:23:22 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:23:22 --> File loaded: C:\xampp\htdocs\davidhood\application\views\payment_made.php
INFO - 2018-08-18 06:23:22 --> Final output sent to browser
DEBUG - 2018-08-18 06:23:22 --> Total execution time: 0.1669
ERROR - 2018-08-18 06:23:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:23:27 --> Config Class Initialized
INFO - 2018-08-18 06:23:27 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:23:27 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:23:27 --> Utf8 Class Initialized
INFO - 2018-08-18 06:23:27 --> URI Class Initialized
INFO - 2018-08-18 06:23:27 --> Router Class Initialized
INFO - 2018-08-18 06:23:27 --> Output Class Initialized
INFO - 2018-08-18 06:23:27 --> Security Class Initialized
DEBUG - 2018-08-18 06:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:23:27 --> Input Class Initialized
INFO - 2018-08-18 06:23:27 --> Language Class Initialized
INFO - 2018-08-18 06:23:27 --> Loader Class Initialized
INFO - 2018-08-18 06:23:27 --> Controller Class Initialized
INFO - 2018-08-18 06:23:27 --> Database Driver Class Initialized
INFO - 2018-08-18 06:23:27 --> Model Class Initialized
INFO - 2018-08-18 06:23:27 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:23:27 --> Model Class Initialized
INFO - 2018-08-18 06:23:27 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:23:27 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-08-18 06:23:27 --> Final output sent to browser
DEBUG - 2018-08-18 06:23:27 --> Total execution time: 0.1608
ERROR - 2018-08-18 06:23:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:23:35 --> Config Class Initialized
INFO - 2018-08-18 06:23:35 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:23:35 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:23:35 --> Utf8 Class Initialized
INFO - 2018-08-18 06:23:35 --> URI Class Initialized
INFO - 2018-08-18 06:23:35 --> Router Class Initialized
INFO - 2018-08-18 06:23:35 --> Output Class Initialized
INFO - 2018-08-18 06:23:35 --> Security Class Initialized
DEBUG - 2018-08-18 06:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:23:35 --> Input Class Initialized
INFO - 2018-08-18 06:23:35 --> Language Class Initialized
INFO - 2018-08-18 06:23:35 --> Loader Class Initialized
INFO - 2018-08-18 06:23:35 --> Controller Class Initialized
INFO - 2018-08-18 06:23:35 --> Database Driver Class Initialized
INFO - 2018-08-18 06:23:35 --> Model Class Initialized
INFO - 2018-08-18 06:23:35 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:23:35 --> Model Class Initialized
INFO - 2018-08-18 06:23:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:23:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\payment_made.php
INFO - 2018-08-18 06:23:35 --> Final output sent to browser
DEBUG - 2018-08-18 06:23:35 --> Total execution time: 0.1652
ERROR - 2018-08-18 06:23:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:23:39 --> Config Class Initialized
INFO - 2018-08-18 06:23:39 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:23:39 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:23:39 --> Utf8 Class Initialized
INFO - 2018-08-18 06:23:39 --> URI Class Initialized
INFO - 2018-08-18 06:23:39 --> Router Class Initialized
INFO - 2018-08-18 06:23:39 --> Output Class Initialized
INFO - 2018-08-18 06:23:39 --> Security Class Initialized
DEBUG - 2018-08-18 06:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:23:39 --> Input Class Initialized
INFO - 2018-08-18 06:23:39 --> Language Class Initialized
INFO - 2018-08-18 06:23:39 --> Loader Class Initialized
INFO - 2018-08-18 06:23:39 --> Controller Class Initialized
INFO - 2018-08-18 06:23:39 --> Database Driver Class Initialized
INFO - 2018-08-18 06:23:39 --> Model Class Initialized
INFO - 2018-08-18 06:23:39 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:23:39 --> Model Class Initialized
INFO - 2018-08-18 06:23:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:23:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-08-18 06:23:39 --> Final output sent to browser
DEBUG - 2018-08-18 06:23:39 --> Total execution time: 0.2172
ERROR - 2018-08-18 06:23:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:23:47 --> Config Class Initialized
INFO - 2018-08-18 06:23:47 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:23:47 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:23:47 --> Utf8 Class Initialized
INFO - 2018-08-18 06:23:47 --> URI Class Initialized
INFO - 2018-08-18 06:23:47 --> Router Class Initialized
INFO - 2018-08-18 06:23:47 --> Output Class Initialized
INFO - 2018-08-18 06:23:47 --> Security Class Initialized
DEBUG - 2018-08-18 06:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:23:47 --> Input Class Initialized
INFO - 2018-08-18 06:23:47 --> Language Class Initialized
INFO - 2018-08-18 06:23:47 --> Loader Class Initialized
INFO - 2018-08-18 06:23:47 --> Controller Class Initialized
INFO - 2018-08-18 06:23:47 --> Database Driver Class Initialized
INFO - 2018-08-18 06:23:47 --> Model Class Initialized
INFO - 2018-08-18 06:23:47 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:23:47 --> Model Class Initialized
INFO - 2018-08-18 06:23:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:23:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\payment_made.php
INFO - 2018-08-18 06:23:47 --> Final output sent to browser
DEBUG - 2018-08-18 06:23:47 --> Total execution time: 0.1668
ERROR - 2018-08-18 06:23:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:23:50 --> Config Class Initialized
INFO - 2018-08-18 06:23:50 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:23:50 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:23:50 --> Utf8 Class Initialized
INFO - 2018-08-18 06:23:50 --> URI Class Initialized
INFO - 2018-08-18 06:23:50 --> Router Class Initialized
INFO - 2018-08-18 06:23:50 --> Output Class Initialized
INFO - 2018-08-18 06:23:50 --> Security Class Initialized
DEBUG - 2018-08-18 06:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:23:50 --> Input Class Initialized
INFO - 2018-08-18 06:23:50 --> Language Class Initialized
INFO - 2018-08-18 06:23:50 --> Loader Class Initialized
INFO - 2018-08-18 06:23:50 --> Controller Class Initialized
INFO - 2018-08-18 06:23:50 --> Database Driver Class Initialized
INFO - 2018-08-18 06:23:50 --> Model Class Initialized
INFO - 2018-08-18 06:23:50 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:23:50 --> Model Class Initialized
INFO - 2018-08-18 06:23:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:23:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\question.php
INFO - 2018-08-18 06:23:50 --> Final output sent to browser
DEBUG - 2018-08-18 06:23:50 --> Total execution time: 0.1582
ERROR - 2018-08-18 06:23:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:23:51 --> Config Class Initialized
INFO - 2018-08-18 06:23:51 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:23:51 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:23:51 --> Utf8 Class Initialized
INFO - 2018-08-18 06:23:51 --> URI Class Initialized
INFO - 2018-08-18 06:23:51 --> Router Class Initialized
INFO - 2018-08-18 06:23:51 --> Output Class Initialized
INFO - 2018-08-18 06:23:51 --> Security Class Initialized
DEBUG - 2018-08-18 06:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:23:51 --> Input Class Initialized
INFO - 2018-08-18 06:23:51 --> Language Class Initialized
INFO - 2018-08-18 06:23:51 --> Loader Class Initialized
INFO - 2018-08-18 06:23:51 --> Controller Class Initialized
INFO - 2018-08-18 06:23:51 --> Database Driver Class Initialized
INFO - 2018-08-18 06:23:51 --> Model Class Initialized
INFO - 2018-08-18 06:23:51 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:23:51 --> Model Class Initialized
INFO - 2018-08-18 06:23:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:23:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-08-18 06:23:51 --> Final output sent to browser
DEBUG - 2018-08-18 06:23:51 --> Total execution time: 0.1689
ERROR - 2018-08-18 06:23:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 06:23:52 --> Config Class Initialized
INFO - 2018-08-18 06:23:52 --> Hooks Class Initialized
DEBUG - 2018-08-18 06:23:52 --> UTF-8 Support Enabled
INFO - 2018-08-18 06:23:52 --> Utf8 Class Initialized
INFO - 2018-08-18 06:23:53 --> URI Class Initialized
INFO - 2018-08-18 06:23:53 --> Router Class Initialized
INFO - 2018-08-18 06:23:53 --> Output Class Initialized
INFO - 2018-08-18 06:23:53 --> Security Class Initialized
DEBUG - 2018-08-18 06:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 06:23:53 --> Input Class Initialized
INFO - 2018-08-18 06:23:53 --> Language Class Initialized
INFO - 2018-08-18 06:23:53 --> Loader Class Initialized
INFO - 2018-08-18 06:23:53 --> Controller Class Initialized
INFO - 2018-08-18 06:23:53 --> Database Driver Class Initialized
INFO - 2018-08-18 06:23:53 --> Model Class Initialized
INFO - 2018-08-18 06:23:53 --> Helper loaded: url_helper
DEBUG - 2018-08-18 06:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 06:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 06:23:53 --> Model Class Initialized
INFO - 2018-08-18 06:23:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 06:23:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\payment_made.php
INFO - 2018-08-18 06:23:53 --> Final output sent to browser
DEBUG - 2018-08-18 06:23:53 --> Total execution time: 0.1795
ERROR - 2018-08-18 13:46:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 13:46:48 --> Config Class Initialized
INFO - 2018-08-18 13:46:48 --> Hooks Class Initialized
DEBUG - 2018-08-18 13:46:48 --> UTF-8 Support Enabled
INFO - 2018-08-18 13:46:48 --> Utf8 Class Initialized
INFO - 2018-08-18 13:46:48 --> URI Class Initialized
DEBUG - 2018-08-18 13:46:48 --> No URI present. Default controller set.
INFO - 2018-08-18 13:46:49 --> Router Class Initialized
INFO - 2018-08-18 13:46:49 --> Output Class Initialized
INFO - 2018-08-18 13:46:49 --> Security Class Initialized
DEBUG - 2018-08-18 13:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 13:46:49 --> Input Class Initialized
INFO - 2018-08-18 13:46:49 --> Language Class Initialized
INFO - 2018-08-18 13:46:49 --> Loader Class Initialized
INFO - 2018-08-18 13:46:49 --> Controller Class Initialized
INFO - 2018-08-18 13:46:49 --> Database Driver Class Initialized
INFO - 2018-08-18 13:46:49 --> Model Class Initialized
INFO - 2018-08-18 13:46:49 --> Helper loaded: url_helper
DEBUG - 2018-08-18 13:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 13:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 13:46:49 --> Model Class Initialized
INFO - 2018-08-18 13:46:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-18 13:46:49 --> Final output sent to browser
DEBUG - 2018-08-18 13:46:49 --> Total execution time: 0.6191
ERROR - 2018-08-18 13:46:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 13:46:51 --> Config Class Initialized
INFO - 2018-08-18 13:46:51 --> Hooks Class Initialized
DEBUG - 2018-08-18 13:46:51 --> UTF-8 Support Enabled
INFO - 2018-08-18 13:46:51 --> Utf8 Class Initialized
INFO - 2018-08-18 13:46:51 --> URI Class Initialized
INFO - 2018-08-18 13:46:51 --> Router Class Initialized
INFO - 2018-08-18 13:46:51 --> Output Class Initialized
INFO - 2018-08-18 13:46:51 --> Security Class Initialized
DEBUG - 2018-08-18 13:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 13:46:51 --> Input Class Initialized
INFO - 2018-08-18 13:46:51 --> Language Class Initialized
INFO - 2018-08-18 13:46:51 --> Loader Class Initialized
INFO - 2018-08-18 13:46:51 --> Controller Class Initialized
INFO - 2018-08-18 13:46:51 --> Database Driver Class Initialized
INFO - 2018-08-18 13:46:51 --> Model Class Initialized
INFO - 2018-08-18 13:46:51 --> Helper loaded: url_helper
DEBUG - 2018-08-18 13:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 13:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 13:46:51 --> Model Class Initialized
ERROR - 2018-08-18 13:46:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 13:46:51 --> Config Class Initialized
INFO - 2018-08-18 13:46:51 --> Hooks Class Initialized
DEBUG - 2018-08-18 13:46:51 --> UTF-8 Support Enabled
INFO - 2018-08-18 13:46:51 --> Utf8 Class Initialized
INFO - 2018-08-18 13:46:51 --> URI Class Initialized
INFO - 2018-08-18 13:46:51 --> Router Class Initialized
INFO - 2018-08-18 13:46:51 --> Output Class Initialized
INFO - 2018-08-18 13:46:51 --> Security Class Initialized
DEBUG - 2018-08-18 13:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 13:46:51 --> Input Class Initialized
INFO - 2018-08-18 13:46:51 --> Language Class Initialized
INFO - 2018-08-18 13:46:51 --> Loader Class Initialized
INFO - 2018-08-18 13:46:51 --> Controller Class Initialized
INFO - 2018-08-18 13:46:51 --> Database Driver Class Initialized
INFO - 2018-08-18 13:46:51 --> Model Class Initialized
INFO - 2018-08-18 13:46:51 --> Helper loaded: url_helper
DEBUG - 2018-08-18 13:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 13:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 13:46:51 --> Model Class Initialized
INFO - 2018-08-18 13:46:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 13:46:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-18 13:46:51 --> Final output sent to browser
DEBUG - 2018-08-18 13:46:51 --> Total execution time: 0.1781
ERROR - 2018-08-18 13:46:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 13:46:53 --> Config Class Initialized
INFO - 2018-08-18 13:46:53 --> Hooks Class Initialized
DEBUG - 2018-08-18 13:46:53 --> UTF-8 Support Enabled
INFO - 2018-08-18 13:46:53 --> Utf8 Class Initialized
INFO - 2018-08-18 13:46:53 --> URI Class Initialized
INFO - 2018-08-18 13:46:53 --> Router Class Initialized
INFO - 2018-08-18 13:46:53 --> Output Class Initialized
INFO - 2018-08-18 13:46:53 --> Security Class Initialized
DEBUG - 2018-08-18 13:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 13:46:53 --> Input Class Initialized
INFO - 2018-08-18 13:46:53 --> Language Class Initialized
INFO - 2018-08-18 13:46:53 --> Loader Class Initialized
INFO - 2018-08-18 13:46:53 --> Controller Class Initialized
INFO - 2018-08-18 13:46:53 --> Database Driver Class Initialized
INFO - 2018-08-18 13:46:53 --> Model Class Initialized
INFO - 2018-08-18 13:46:53 --> Helper loaded: url_helper
DEBUG - 2018-08-18 13:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 13:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 13:46:53 --> Model Class Initialized
INFO - 2018-08-18 13:46:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 13:46:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\payment_made.php
INFO - 2018-08-18 13:46:53 --> Final output sent to browser
DEBUG - 2018-08-18 13:46:53 --> Total execution time: 0.2179
ERROR - 2018-08-18 13:46:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 13:46:56 --> Config Class Initialized
INFO - 2018-08-18 13:46:56 --> Hooks Class Initialized
DEBUG - 2018-08-18 13:46:56 --> UTF-8 Support Enabled
INFO - 2018-08-18 13:46:56 --> Utf8 Class Initialized
INFO - 2018-08-18 13:46:56 --> URI Class Initialized
INFO - 2018-08-18 13:46:56 --> Router Class Initialized
INFO - 2018-08-18 13:46:56 --> Output Class Initialized
INFO - 2018-08-18 13:46:56 --> Security Class Initialized
DEBUG - 2018-08-18 13:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 13:46:56 --> Input Class Initialized
INFO - 2018-08-18 13:46:56 --> Language Class Initialized
INFO - 2018-08-18 13:46:56 --> Loader Class Initialized
INFO - 2018-08-18 13:46:56 --> Controller Class Initialized
INFO - 2018-08-18 13:46:56 --> Database Driver Class Initialized
INFO - 2018-08-18 13:46:56 --> Model Class Initialized
INFO - 2018-08-18 13:46:56 --> Helper loaded: url_helper
DEBUG - 2018-08-18 13:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 13:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 13:46:56 --> Model Class Initialized
ERROR - 2018-08-18 13:46:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 13:46:56 --> Config Class Initialized
INFO - 2018-08-18 13:46:56 --> Hooks Class Initialized
DEBUG - 2018-08-18 13:46:56 --> UTF-8 Support Enabled
INFO - 2018-08-18 13:46:56 --> Utf8 Class Initialized
INFO - 2018-08-18 13:46:56 --> URI Class Initialized
INFO - 2018-08-18 13:46:56 --> Router Class Initialized
INFO - 2018-08-18 13:46:56 --> Output Class Initialized
INFO - 2018-08-18 13:46:56 --> Security Class Initialized
DEBUG - 2018-08-18 13:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 13:46:56 --> Input Class Initialized
INFO - 2018-08-18 13:46:56 --> Language Class Initialized
INFO - 2018-08-18 13:46:56 --> Loader Class Initialized
INFO - 2018-08-18 13:46:56 --> Controller Class Initialized
INFO - 2018-08-18 13:46:56 --> Database Driver Class Initialized
INFO - 2018-08-18 13:46:56 --> Model Class Initialized
INFO - 2018-08-18 13:46:56 --> Helper loaded: url_helper
DEBUG - 2018-08-18 13:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 13:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 13:46:56 --> Model Class Initialized
INFO - 2018-08-18 13:46:56 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 13:46:56 --> File loaded: C:\xampp\htdocs\davidhood\application\views\payment_made.php
INFO - 2018-08-18 13:46:56 --> Final output sent to browser
DEBUG - 2018-08-18 13:46:56 --> Total execution time: 0.1609
ERROR - 2018-08-18 13:47:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 13:47:03 --> Config Class Initialized
INFO - 2018-08-18 13:47:03 --> Hooks Class Initialized
DEBUG - 2018-08-18 13:47:03 --> UTF-8 Support Enabled
INFO - 2018-08-18 13:47:03 --> Utf8 Class Initialized
INFO - 2018-08-18 13:47:03 --> URI Class Initialized
INFO - 2018-08-18 13:47:03 --> Router Class Initialized
INFO - 2018-08-18 13:47:03 --> Output Class Initialized
INFO - 2018-08-18 13:47:03 --> Security Class Initialized
DEBUG - 2018-08-18 13:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 13:47:03 --> Input Class Initialized
INFO - 2018-08-18 13:47:03 --> Language Class Initialized
INFO - 2018-08-18 13:47:03 --> Loader Class Initialized
INFO - 2018-08-18 13:47:03 --> Controller Class Initialized
INFO - 2018-08-18 13:47:03 --> Database Driver Class Initialized
INFO - 2018-08-18 13:47:03 --> Model Class Initialized
INFO - 2018-08-18 13:47:03 --> Helper loaded: url_helper
DEBUG - 2018-08-18 13:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 13:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 13:47:03 --> Model Class Initialized
ERROR - 2018-08-18 13:47:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 13:47:03 --> Config Class Initialized
INFO - 2018-08-18 13:47:03 --> Hooks Class Initialized
DEBUG - 2018-08-18 13:47:03 --> UTF-8 Support Enabled
INFO - 2018-08-18 13:47:03 --> Utf8 Class Initialized
INFO - 2018-08-18 13:47:03 --> URI Class Initialized
INFO - 2018-08-18 13:47:03 --> Router Class Initialized
INFO - 2018-08-18 13:47:03 --> Output Class Initialized
INFO - 2018-08-18 13:47:03 --> Security Class Initialized
DEBUG - 2018-08-18 13:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 13:47:03 --> Input Class Initialized
INFO - 2018-08-18 13:47:03 --> Language Class Initialized
INFO - 2018-08-18 13:47:03 --> Loader Class Initialized
INFO - 2018-08-18 13:47:03 --> Controller Class Initialized
INFO - 2018-08-18 13:47:03 --> Database Driver Class Initialized
INFO - 2018-08-18 13:47:03 --> Model Class Initialized
INFO - 2018-08-18 13:47:04 --> Helper loaded: url_helper
DEBUG - 2018-08-18 13:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 13:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 13:47:04 --> Model Class Initialized
INFO - 2018-08-18 13:47:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 13:47:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\payment_made.php
INFO - 2018-08-18 13:47:04 --> Final output sent to browser
DEBUG - 2018-08-18 13:47:04 --> Total execution time: 0.1688
ERROR - 2018-08-18 13:47:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 13:47:09 --> Config Class Initialized
INFO - 2018-08-18 13:47:09 --> Hooks Class Initialized
DEBUG - 2018-08-18 13:47:09 --> UTF-8 Support Enabled
INFO - 2018-08-18 13:47:09 --> Utf8 Class Initialized
INFO - 2018-08-18 13:47:09 --> URI Class Initialized
INFO - 2018-08-18 13:47:09 --> Router Class Initialized
INFO - 2018-08-18 13:47:09 --> Output Class Initialized
INFO - 2018-08-18 13:47:09 --> Security Class Initialized
DEBUG - 2018-08-18 13:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 13:47:09 --> Input Class Initialized
INFO - 2018-08-18 13:47:09 --> Language Class Initialized
INFO - 2018-08-18 13:47:09 --> Loader Class Initialized
INFO - 2018-08-18 13:47:09 --> Controller Class Initialized
INFO - 2018-08-18 13:47:09 --> Database Driver Class Initialized
INFO - 2018-08-18 13:47:09 --> Model Class Initialized
INFO - 2018-08-18 13:47:09 --> Helper loaded: url_helper
DEBUG - 2018-08-18 13:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 13:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 13:47:09 --> Model Class Initialized
ERROR - 2018-08-18 13:47:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-18 13:47:09 --> Config Class Initialized
INFO - 2018-08-18 13:47:09 --> Hooks Class Initialized
DEBUG - 2018-08-18 13:47:09 --> UTF-8 Support Enabled
INFO - 2018-08-18 13:47:09 --> Utf8 Class Initialized
INFO - 2018-08-18 13:47:09 --> URI Class Initialized
INFO - 2018-08-18 13:47:09 --> Router Class Initialized
INFO - 2018-08-18 13:47:09 --> Output Class Initialized
INFO - 2018-08-18 13:47:09 --> Security Class Initialized
DEBUG - 2018-08-18 13:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-18 13:47:09 --> Input Class Initialized
INFO - 2018-08-18 13:47:09 --> Language Class Initialized
INFO - 2018-08-18 13:47:09 --> Loader Class Initialized
INFO - 2018-08-18 13:47:09 --> Controller Class Initialized
INFO - 2018-08-18 13:47:09 --> Database Driver Class Initialized
INFO - 2018-08-18 13:47:09 --> Model Class Initialized
INFO - 2018-08-18 13:47:09 --> Helper loaded: url_helper
DEBUG - 2018-08-18 13:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-18 13:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-18 13:47:09 --> Model Class Initialized
INFO - 2018-08-18 13:47:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-18 13:47:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\payment_made.php
INFO - 2018-08-18 13:47:09 --> Final output sent to browser
DEBUG - 2018-08-18 13:47:09 --> Total execution time: 0.1636
