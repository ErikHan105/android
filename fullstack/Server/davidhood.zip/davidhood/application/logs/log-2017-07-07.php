<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-07 08:28:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:28:25 --> Config Class Initialized
INFO - 2017-07-07 08:28:25 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:28:25 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:28:25 --> Utf8 Class Initialized
INFO - 2017-07-07 08:28:25 --> URI Class Initialized
INFO - 2017-07-07 08:28:25 --> Router Class Initialized
INFO - 2017-07-07 08:28:25 --> Output Class Initialized
INFO - 2017-07-07 08:28:25 --> Security Class Initialized
DEBUG - 2017-07-07 08:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:28:25 --> Input Class Initialized
INFO - 2017-07-07 08:28:25 --> Language Class Initialized
INFO - 2017-07-07 08:28:25 --> Loader Class Initialized
INFO - 2017-07-07 08:28:25 --> Controller Class Initialized
INFO - 2017-07-07 08:28:25 --> Database Driver Class Initialized
INFO - 2017-07-07 08:28:25 --> Model Class Initialized
INFO - 2017-07-07 08:28:25 --> Helper loaded: form_helper
INFO - 2017-07-07 08:28:25 --> Helper loaded: url_helper
INFO - 2017-07-07 08:28:25 --> Model Class Initialized
INFO - 2017-07-07 08:28:25 --> Final output sent to browser
DEBUG - 2017-07-07 08:28:25 --> Total execution time: 0.8240
ERROR - 2017-07-07 08:28:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:28:26 --> Config Class Initialized
INFO - 2017-07-07 08:28:27 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:28:27 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:28:27 --> Utf8 Class Initialized
INFO - 2017-07-07 08:28:27 --> URI Class Initialized
INFO - 2017-07-07 08:28:27 --> Router Class Initialized
INFO - 2017-07-07 08:28:27 --> Output Class Initialized
INFO - 2017-07-07 08:28:27 --> Security Class Initialized
DEBUG - 2017-07-07 08:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:28:27 --> Input Class Initialized
INFO - 2017-07-07 08:28:27 --> Language Class Initialized
INFO - 2017-07-07 08:28:27 --> Loader Class Initialized
INFO - 2017-07-07 08:28:27 --> Controller Class Initialized
INFO - 2017-07-07 08:28:27 --> Database Driver Class Initialized
INFO - 2017-07-07 08:28:27 --> Model Class Initialized
INFO - 2017-07-07 08:28:27 --> Helper loaded: form_helper
INFO - 2017-07-07 08:28:27 --> Helper loaded: url_helper
INFO - 2017-07-07 08:28:27 --> Model Class Initialized
INFO - 2017-07-07 08:28:28 --> Final output sent to browser
DEBUG - 2017-07-07 08:28:28 --> Total execution time: 0.9680
ERROR - 2017-07-07 08:28:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:28:31 --> Config Class Initialized
INFO - 2017-07-07 08:28:31 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:28:31 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:28:31 --> Utf8 Class Initialized
INFO - 2017-07-07 08:28:31 --> URI Class Initialized
INFO - 2017-07-07 08:28:31 --> Router Class Initialized
INFO - 2017-07-07 08:28:31 --> Output Class Initialized
INFO - 2017-07-07 08:28:31 --> Security Class Initialized
DEBUG - 2017-07-07 08:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:28:31 --> Input Class Initialized
INFO - 2017-07-07 08:28:31 --> Language Class Initialized
INFO - 2017-07-07 08:28:31 --> Loader Class Initialized
INFO - 2017-07-07 08:28:31 --> Controller Class Initialized
INFO - 2017-07-07 08:28:31 --> Database Driver Class Initialized
INFO - 2017-07-07 08:28:31 --> Model Class Initialized
INFO - 2017-07-07 08:28:31 --> Helper loaded: form_helper
INFO - 2017-07-07 08:28:31 --> Helper loaded: url_helper
INFO - 2017-07-07 08:28:31 --> Model Class Initialized
INFO - 2017-07-07 08:28:31 --> Final output sent to browser
DEBUG - 2017-07-07 08:28:31 --> Total execution time: 0.0825
ERROR - 2017-07-07 08:30:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:30:15 --> Config Class Initialized
INFO - 2017-07-07 08:30:15 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:30:15 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:30:15 --> Utf8 Class Initialized
INFO - 2017-07-07 08:30:15 --> URI Class Initialized
INFO - 2017-07-07 08:30:15 --> Router Class Initialized
INFO - 2017-07-07 08:30:15 --> Output Class Initialized
INFO - 2017-07-07 08:30:15 --> Security Class Initialized
DEBUG - 2017-07-07 08:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:30:15 --> Input Class Initialized
INFO - 2017-07-07 08:30:15 --> Language Class Initialized
INFO - 2017-07-07 08:30:15 --> Loader Class Initialized
INFO - 2017-07-07 08:30:15 --> Controller Class Initialized
INFO - 2017-07-07 08:30:15 --> Database Driver Class Initialized
INFO - 2017-07-07 08:30:15 --> Model Class Initialized
INFO - 2017-07-07 08:30:15 --> Helper loaded: form_helper
INFO - 2017-07-07 08:30:15 --> Helper loaded: url_helper
INFO - 2017-07-07 08:30:15 --> Model Class Initialized
INFO - 2017-07-07 08:30:15 --> Final output sent to browser
DEBUG - 2017-07-07 08:30:15 --> Total execution time: 0.0725
ERROR - 2017-07-07 08:30:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:30:16 --> Config Class Initialized
INFO - 2017-07-07 08:30:16 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:30:16 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:30:16 --> Utf8 Class Initialized
INFO - 2017-07-07 08:30:16 --> URI Class Initialized
INFO - 2017-07-07 08:30:16 --> Router Class Initialized
INFO - 2017-07-07 08:30:16 --> Output Class Initialized
INFO - 2017-07-07 08:30:16 --> Security Class Initialized
DEBUG - 2017-07-07 08:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:30:16 --> Input Class Initialized
INFO - 2017-07-07 08:30:16 --> Language Class Initialized
INFO - 2017-07-07 08:30:16 --> Loader Class Initialized
INFO - 2017-07-07 08:30:16 --> Controller Class Initialized
INFO - 2017-07-07 08:30:16 --> Database Driver Class Initialized
INFO - 2017-07-07 08:30:16 --> Model Class Initialized
INFO - 2017-07-07 08:30:16 --> Helper loaded: form_helper
INFO - 2017-07-07 08:30:16 --> Helper loaded: url_helper
INFO - 2017-07-07 08:30:16 --> Model Class Initialized
INFO - 2017-07-07 08:30:16 --> Final output sent to browser
DEBUG - 2017-07-07 08:30:16 --> Total execution time: 0.0700
ERROR - 2017-07-07 08:30:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:30:40 --> Config Class Initialized
INFO - 2017-07-07 08:30:40 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:30:40 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:30:40 --> Utf8 Class Initialized
INFO - 2017-07-07 08:30:40 --> URI Class Initialized
DEBUG - 2017-07-07 08:30:40 --> No URI present. Default controller set.
INFO - 2017-07-07 08:30:40 --> Router Class Initialized
INFO - 2017-07-07 08:30:40 --> Output Class Initialized
INFO - 2017-07-07 08:30:40 --> Security Class Initialized
DEBUG - 2017-07-07 08:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:30:40 --> Input Class Initialized
INFO - 2017-07-07 08:30:40 --> Language Class Initialized
INFO - 2017-07-07 08:30:40 --> Loader Class Initialized
INFO - 2017-07-07 08:30:40 --> Controller Class Initialized
INFO - 2017-07-07 08:30:40 --> Database Driver Class Initialized
INFO - 2017-07-07 08:30:40 --> Model Class Initialized
INFO - 2017-07-07 08:30:40 --> Helper loaded: form_helper
INFO - 2017-07-07 08:30:40 --> Helper loaded: url_helper
INFO - 2017-07-07 08:30:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-07 08:30:40 --> Final output sent to browser
DEBUG - 2017-07-07 08:30:40 --> Total execution time: 0.0640
ERROR - 2017-07-07 08:30:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:30:43 --> Config Class Initialized
INFO - 2017-07-07 08:30:43 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:30:43 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:30:43 --> Utf8 Class Initialized
INFO - 2017-07-07 08:30:43 --> URI Class Initialized
INFO - 2017-07-07 08:30:43 --> Router Class Initialized
INFO - 2017-07-07 08:30:43 --> Output Class Initialized
INFO - 2017-07-07 08:30:43 --> Security Class Initialized
DEBUG - 2017-07-07 08:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:30:43 --> Input Class Initialized
INFO - 2017-07-07 08:30:43 --> Language Class Initialized
INFO - 2017-07-07 08:30:43 --> Loader Class Initialized
INFO - 2017-07-07 08:30:43 --> Controller Class Initialized
INFO - 2017-07-07 08:30:43 --> Database Driver Class Initialized
INFO - 2017-07-07 08:30:43 --> Model Class Initialized
INFO - 2017-07-07 08:30:43 --> Helper loaded: form_helper
INFO - 2017-07-07 08:30:43 --> Helper loaded: url_helper
INFO - 2017-07-07 08:30:43 --> Model Class Initialized
ERROR - 2017-07-07 08:30:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:30:43 --> Config Class Initialized
INFO - 2017-07-07 08:30:43 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:30:43 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:30:43 --> Utf8 Class Initialized
INFO - 2017-07-07 08:30:43 --> URI Class Initialized
INFO - 2017-07-07 08:30:43 --> Router Class Initialized
INFO - 2017-07-07 08:30:43 --> Output Class Initialized
INFO - 2017-07-07 08:30:43 --> Security Class Initialized
DEBUG - 2017-07-07 08:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:30:43 --> Input Class Initialized
INFO - 2017-07-07 08:30:43 --> Language Class Initialized
INFO - 2017-07-07 08:30:43 --> Loader Class Initialized
INFO - 2017-07-07 08:30:43 --> Controller Class Initialized
INFO - 2017-07-07 08:30:43 --> Database Driver Class Initialized
INFO - 2017-07-07 08:30:43 --> Model Class Initialized
INFO - 2017-07-07 08:30:43 --> Helper loaded: form_helper
INFO - 2017-07-07 08:30:43 --> Helper loaded: url_helper
INFO - 2017-07-07 08:30:43 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 08:30:43 --> Model Class Initialized
INFO - 2017-07-07 08:30:43 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-07 08:30:43 --> Final output sent to browser
DEBUG - 2017-07-07 08:30:43 --> Total execution time: 0.0510
ERROR - 2017-07-07 08:30:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:30:50 --> Config Class Initialized
INFO - 2017-07-07 08:30:50 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:30:50 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:30:50 --> Utf8 Class Initialized
INFO - 2017-07-07 08:30:50 --> URI Class Initialized
INFO - 2017-07-07 08:30:50 --> Router Class Initialized
INFO - 2017-07-07 08:30:50 --> Output Class Initialized
INFO - 2017-07-07 08:30:50 --> Security Class Initialized
DEBUG - 2017-07-07 08:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:30:50 --> Input Class Initialized
INFO - 2017-07-07 08:30:50 --> Language Class Initialized
INFO - 2017-07-07 08:30:50 --> Loader Class Initialized
INFO - 2017-07-07 08:30:50 --> Controller Class Initialized
INFO - 2017-07-07 08:30:50 --> Database Driver Class Initialized
INFO - 2017-07-07 08:30:50 --> Model Class Initialized
INFO - 2017-07-07 08:30:50 --> Helper loaded: form_helper
INFO - 2017-07-07 08:30:50 --> Helper loaded: url_helper
INFO - 2017-07-07 08:30:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 08:30:50 --> Model Class Initialized
INFO - 2017-07-07 08:30:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-07 08:30:50 --> Final output sent to browser
DEBUG - 2017-07-07 08:30:50 --> Total execution time: 0.1980
ERROR - 2017-07-07 08:30:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:30:53 --> Config Class Initialized
INFO - 2017-07-07 08:30:53 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:30:53 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:30:53 --> Utf8 Class Initialized
INFO - 2017-07-07 08:30:53 --> URI Class Initialized
INFO - 2017-07-07 08:30:53 --> Router Class Initialized
INFO - 2017-07-07 08:30:53 --> Output Class Initialized
INFO - 2017-07-07 08:30:53 --> Security Class Initialized
DEBUG - 2017-07-07 08:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:30:53 --> Input Class Initialized
INFO - 2017-07-07 08:30:53 --> Language Class Initialized
INFO - 2017-07-07 08:30:53 --> Loader Class Initialized
INFO - 2017-07-07 08:30:53 --> Controller Class Initialized
INFO - 2017-07-07 08:30:53 --> Database Driver Class Initialized
INFO - 2017-07-07 08:30:53 --> Model Class Initialized
INFO - 2017-07-07 08:30:53 --> Helper loaded: form_helper
INFO - 2017-07-07 08:30:53 --> Helper loaded: url_helper
INFO - 2017-07-07 08:30:53 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 08:30:53 --> Model Class Initialized
INFO - 2017-07-07 08:30:53 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 08:30:53 --> Final output sent to browser
DEBUG - 2017-07-07 08:30:53 --> Total execution time: 0.0960
ERROR - 2017-07-07 08:30:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:30:58 --> Config Class Initialized
INFO - 2017-07-07 08:30:58 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:30:58 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:30:58 --> Utf8 Class Initialized
INFO - 2017-07-07 08:30:58 --> URI Class Initialized
INFO - 2017-07-07 08:30:58 --> Router Class Initialized
INFO - 2017-07-07 08:30:58 --> Output Class Initialized
INFO - 2017-07-07 08:30:58 --> Security Class Initialized
DEBUG - 2017-07-07 08:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:30:58 --> Input Class Initialized
INFO - 2017-07-07 08:30:58 --> Language Class Initialized
INFO - 2017-07-07 08:30:58 --> Loader Class Initialized
INFO - 2017-07-07 08:30:58 --> Controller Class Initialized
INFO - 2017-07-07 08:30:58 --> Database Driver Class Initialized
INFO - 2017-07-07 08:30:58 --> Model Class Initialized
INFO - 2017-07-07 08:30:58 --> Helper loaded: form_helper
INFO - 2017-07-07 08:30:58 --> Helper loaded: url_helper
INFO - 2017-07-07 08:30:58 --> Model Class Initialized
INFO - 2017-07-07 08:30:59 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 08:30:59 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 08:30:59 --> Final output sent to browser
DEBUG - 2017-07-07 08:30:59 --> Total execution time: 0.4590
ERROR - 2017-07-07 08:31:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:31:03 --> Config Class Initialized
INFO - 2017-07-07 08:31:03 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:31:03 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:31:03 --> Utf8 Class Initialized
INFO - 2017-07-07 08:31:03 --> URI Class Initialized
INFO - 2017-07-07 08:31:03 --> Router Class Initialized
INFO - 2017-07-07 08:31:03 --> Output Class Initialized
INFO - 2017-07-07 08:31:03 --> Security Class Initialized
DEBUG - 2017-07-07 08:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:31:03 --> Input Class Initialized
INFO - 2017-07-07 08:31:03 --> Language Class Initialized
INFO - 2017-07-07 08:31:03 --> Loader Class Initialized
INFO - 2017-07-07 08:31:03 --> Controller Class Initialized
INFO - 2017-07-07 08:31:03 --> Database Driver Class Initialized
INFO - 2017-07-07 08:31:03 --> Model Class Initialized
INFO - 2017-07-07 08:31:03 --> Helper loaded: form_helper
INFO - 2017-07-07 08:31:03 --> Helper loaded: url_helper
INFO - 2017-07-07 08:31:03 --> Model Class Initialized
INFO - 2017-07-07 08:31:03 --> Final output sent to browser
DEBUG - 2017-07-07 08:31:03 --> Total execution time: 0.3200
ERROR - 2017-07-07 08:31:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:31:05 --> Config Class Initialized
INFO - 2017-07-07 08:31:05 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:31:05 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:31:05 --> Utf8 Class Initialized
INFO - 2017-07-07 08:31:05 --> URI Class Initialized
INFO - 2017-07-07 08:31:05 --> Router Class Initialized
INFO - 2017-07-07 08:31:05 --> Output Class Initialized
INFO - 2017-07-07 08:31:05 --> Security Class Initialized
DEBUG - 2017-07-07 08:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:31:05 --> Input Class Initialized
INFO - 2017-07-07 08:31:05 --> Language Class Initialized
INFO - 2017-07-07 08:31:05 --> Loader Class Initialized
INFO - 2017-07-07 08:31:05 --> Controller Class Initialized
INFO - 2017-07-07 08:31:05 --> Database Driver Class Initialized
INFO - 2017-07-07 08:31:05 --> Model Class Initialized
INFO - 2017-07-07 08:31:05 --> Helper loaded: form_helper
INFO - 2017-07-07 08:31:05 --> Helper loaded: url_helper
INFO - 2017-07-07 08:31:05 --> Model Class Initialized
INFO - 2017-07-07 08:31:05 --> Final output sent to browser
DEBUG - 2017-07-07 08:31:05 --> Total execution time: 0.0950
ERROR - 2017-07-07 08:31:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:31:06 --> Config Class Initialized
INFO - 2017-07-07 08:31:06 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:31:06 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:31:06 --> Utf8 Class Initialized
INFO - 2017-07-07 08:31:06 --> URI Class Initialized
INFO - 2017-07-07 08:31:06 --> Router Class Initialized
INFO - 2017-07-07 08:31:06 --> Output Class Initialized
INFO - 2017-07-07 08:31:06 --> Security Class Initialized
DEBUG - 2017-07-07 08:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:31:06 --> Input Class Initialized
INFO - 2017-07-07 08:31:06 --> Language Class Initialized
INFO - 2017-07-07 08:31:06 --> Loader Class Initialized
INFO - 2017-07-07 08:31:06 --> Controller Class Initialized
INFO - 2017-07-07 08:31:06 --> Database Driver Class Initialized
INFO - 2017-07-07 08:31:06 --> Model Class Initialized
INFO - 2017-07-07 08:31:06 --> Helper loaded: form_helper
INFO - 2017-07-07 08:31:06 --> Helper loaded: url_helper
INFO - 2017-07-07 08:31:06 --> Model Class Initialized
INFO - 2017-07-07 08:31:06 --> Final output sent to browser
DEBUG - 2017-07-07 08:31:06 --> Total execution time: 0.0475
ERROR - 2017-07-07 08:31:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:31:07 --> Config Class Initialized
INFO - 2017-07-07 08:31:07 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:31:07 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:31:07 --> Utf8 Class Initialized
INFO - 2017-07-07 08:31:07 --> URI Class Initialized
INFO - 2017-07-07 08:31:07 --> Router Class Initialized
INFO - 2017-07-07 08:31:07 --> Output Class Initialized
INFO - 2017-07-07 08:31:07 --> Security Class Initialized
DEBUG - 2017-07-07 08:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:31:07 --> Input Class Initialized
INFO - 2017-07-07 08:31:07 --> Language Class Initialized
INFO - 2017-07-07 08:31:07 --> Loader Class Initialized
INFO - 2017-07-07 08:31:07 --> Controller Class Initialized
INFO - 2017-07-07 08:31:07 --> Database Driver Class Initialized
INFO - 2017-07-07 08:31:07 --> Model Class Initialized
INFO - 2017-07-07 08:31:07 --> Helper loaded: form_helper
INFO - 2017-07-07 08:31:07 --> Helper loaded: url_helper
INFO - 2017-07-07 08:31:07 --> Model Class Initialized
INFO - 2017-07-07 08:31:07 --> Final output sent to browser
DEBUG - 2017-07-07 08:31:07 --> Total execution time: 0.0730
ERROR - 2017-07-07 08:31:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:31:10 --> Config Class Initialized
INFO - 2017-07-07 08:31:10 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:31:10 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:31:10 --> Utf8 Class Initialized
INFO - 2017-07-07 08:31:10 --> URI Class Initialized
INFO - 2017-07-07 08:31:10 --> Router Class Initialized
INFO - 2017-07-07 08:31:10 --> Output Class Initialized
INFO - 2017-07-07 08:31:10 --> Security Class Initialized
DEBUG - 2017-07-07 08:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:31:10 --> Input Class Initialized
INFO - 2017-07-07 08:31:10 --> Language Class Initialized
INFO - 2017-07-07 08:31:10 --> Loader Class Initialized
INFO - 2017-07-07 08:31:10 --> Controller Class Initialized
INFO - 2017-07-07 08:31:10 --> Database Driver Class Initialized
INFO - 2017-07-07 08:31:10 --> Model Class Initialized
INFO - 2017-07-07 08:31:10 --> Helper loaded: form_helper
INFO - 2017-07-07 08:31:10 --> Helper loaded: url_helper
INFO - 2017-07-07 08:31:10 --> Model Class Initialized
INFO - 2017-07-07 08:31:10 --> Final output sent to browser
DEBUG - 2017-07-07 08:31:10 --> Total execution time: 0.0850
ERROR - 2017-07-07 08:56:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:56:21 --> Config Class Initialized
INFO - 2017-07-07 08:56:21 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:56:21 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:56:21 --> Utf8 Class Initialized
INFO - 2017-07-07 08:56:21 --> URI Class Initialized
INFO - 2017-07-07 08:56:21 --> Router Class Initialized
INFO - 2017-07-07 08:56:21 --> Output Class Initialized
INFO - 2017-07-07 08:56:21 --> Security Class Initialized
DEBUG - 2017-07-07 08:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:56:21 --> Input Class Initialized
INFO - 2017-07-07 08:56:21 --> Language Class Initialized
INFO - 2017-07-07 08:56:21 --> Loader Class Initialized
INFO - 2017-07-07 08:56:21 --> Controller Class Initialized
INFO - 2017-07-07 08:56:21 --> Database Driver Class Initialized
INFO - 2017-07-07 08:56:21 --> Model Class Initialized
INFO - 2017-07-07 08:56:21 --> Helper loaded: form_helper
INFO - 2017-07-07 08:56:21 --> Helper loaded: url_helper
INFO - 2017-07-07 08:56:21 --> Model Class Initialized
INFO - 2017-07-07 08:56:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 08:56:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 08:56:21 --> Final output sent to browser
DEBUG - 2017-07-07 08:56:21 --> Total execution time: 0.2160
ERROR - 2017-07-07 08:56:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:56:33 --> Config Class Initialized
INFO - 2017-07-07 08:56:33 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:56:33 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:56:33 --> Utf8 Class Initialized
INFO - 2017-07-07 08:56:33 --> URI Class Initialized
INFO - 2017-07-07 08:56:33 --> Router Class Initialized
INFO - 2017-07-07 08:56:33 --> Output Class Initialized
INFO - 2017-07-07 08:56:33 --> Security Class Initialized
DEBUG - 2017-07-07 08:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:56:33 --> Input Class Initialized
INFO - 2017-07-07 08:56:33 --> Language Class Initialized
INFO - 2017-07-07 08:56:33 --> Loader Class Initialized
INFO - 2017-07-07 08:56:33 --> Controller Class Initialized
INFO - 2017-07-07 08:56:33 --> Database Driver Class Initialized
INFO - 2017-07-07 08:56:33 --> Model Class Initialized
INFO - 2017-07-07 08:56:33 --> Helper loaded: form_helper
INFO - 2017-07-07 08:56:33 --> Helper loaded: url_helper
INFO - 2017-07-07 08:56:33 --> Model Class Initialized
INFO - 2017-07-07 08:56:33 --> Final output sent to browser
DEBUG - 2017-07-07 08:56:33 --> Total execution time: 0.0675
ERROR - 2017-07-07 08:56:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:56:34 --> Config Class Initialized
INFO - 2017-07-07 08:56:34 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:56:34 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:56:34 --> Utf8 Class Initialized
INFO - 2017-07-07 08:56:34 --> URI Class Initialized
INFO - 2017-07-07 08:56:34 --> Router Class Initialized
INFO - 2017-07-07 08:56:34 --> Output Class Initialized
INFO - 2017-07-07 08:56:34 --> Security Class Initialized
DEBUG - 2017-07-07 08:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:56:34 --> Input Class Initialized
INFO - 2017-07-07 08:56:34 --> Language Class Initialized
INFO - 2017-07-07 08:56:34 --> Loader Class Initialized
INFO - 2017-07-07 08:56:34 --> Controller Class Initialized
INFO - 2017-07-07 08:56:34 --> Database Driver Class Initialized
INFO - 2017-07-07 08:56:34 --> Model Class Initialized
INFO - 2017-07-07 08:56:34 --> Helper loaded: form_helper
INFO - 2017-07-07 08:56:34 --> Helper loaded: url_helper
INFO - 2017-07-07 08:56:34 --> Model Class Initialized
INFO - 2017-07-07 08:56:34 --> Final output sent to browser
DEBUG - 2017-07-07 08:56:34 --> Total execution time: 0.1000
ERROR - 2017-07-07 08:56:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:56:55 --> Config Class Initialized
INFO - 2017-07-07 08:56:55 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:56:55 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:56:55 --> Utf8 Class Initialized
INFO - 2017-07-07 08:56:55 --> URI Class Initialized
INFO - 2017-07-07 08:56:55 --> Router Class Initialized
INFO - 2017-07-07 08:56:55 --> Output Class Initialized
INFO - 2017-07-07 08:56:55 --> Security Class Initialized
DEBUG - 2017-07-07 08:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:56:55 --> Input Class Initialized
INFO - 2017-07-07 08:56:55 --> Language Class Initialized
INFO - 2017-07-07 08:56:55 --> Loader Class Initialized
INFO - 2017-07-07 08:56:55 --> Controller Class Initialized
INFO - 2017-07-07 08:56:55 --> Database Driver Class Initialized
INFO - 2017-07-07 08:56:55 --> Model Class Initialized
INFO - 2017-07-07 08:56:55 --> Helper loaded: form_helper
INFO - 2017-07-07 08:56:55 --> Helper loaded: url_helper
INFO - 2017-07-07 08:56:55 --> Model Class Initialized
INFO - 2017-07-07 08:56:55 --> Final output sent to browser
DEBUG - 2017-07-07 08:56:55 --> Total execution time: 0.0810
ERROR - 2017-07-07 08:56:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:56:57 --> Config Class Initialized
INFO - 2017-07-07 08:56:57 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:56:57 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:56:57 --> Utf8 Class Initialized
INFO - 2017-07-07 08:56:57 --> URI Class Initialized
INFO - 2017-07-07 08:56:57 --> Router Class Initialized
INFO - 2017-07-07 08:56:57 --> Output Class Initialized
INFO - 2017-07-07 08:56:57 --> Security Class Initialized
DEBUG - 2017-07-07 08:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:56:57 --> Input Class Initialized
INFO - 2017-07-07 08:56:57 --> Language Class Initialized
INFO - 2017-07-07 08:56:57 --> Loader Class Initialized
INFO - 2017-07-07 08:56:57 --> Controller Class Initialized
INFO - 2017-07-07 08:56:57 --> Database Driver Class Initialized
INFO - 2017-07-07 08:56:57 --> Model Class Initialized
INFO - 2017-07-07 08:56:57 --> Helper loaded: form_helper
INFO - 2017-07-07 08:56:57 --> Helper loaded: url_helper
INFO - 2017-07-07 08:56:58 --> Model Class Initialized
INFO - 2017-07-07 08:56:58 --> Final output sent to browser
DEBUG - 2017-07-07 08:56:58 --> Total execution time: 0.0700
ERROR - 2017-07-07 08:57:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:57:41 --> Config Class Initialized
INFO - 2017-07-07 08:57:41 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:57:41 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:57:41 --> Utf8 Class Initialized
INFO - 2017-07-07 08:57:41 --> URI Class Initialized
INFO - 2017-07-07 08:57:41 --> Router Class Initialized
INFO - 2017-07-07 08:57:41 --> Output Class Initialized
INFO - 2017-07-07 08:57:41 --> Security Class Initialized
DEBUG - 2017-07-07 08:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:57:41 --> Input Class Initialized
INFO - 2017-07-07 08:57:41 --> Language Class Initialized
INFO - 2017-07-07 08:57:41 --> Loader Class Initialized
INFO - 2017-07-07 08:57:41 --> Controller Class Initialized
INFO - 2017-07-07 08:57:41 --> Database Driver Class Initialized
INFO - 2017-07-07 08:57:41 --> Model Class Initialized
INFO - 2017-07-07 08:57:41 --> Helper loaded: form_helper
INFO - 2017-07-07 08:57:41 --> Helper loaded: url_helper
INFO - 2017-07-07 08:57:41 --> Model Class Initialized
INFO - 2017-07-07 08:57:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 08:57:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 08:57:41 --> Final output sent to browser
DEBUG - 2017-07-07 08:57:41 --> Total execution time: 0.1140
ERROR - 2017-07-07 08:57:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:57:50 --> Config Class Initialized
INFO - 2017-07-07 08:57:50 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:57:50 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:57:50 --> Utf8 Class Initialized
INFO - 2017-07-07 08:57:50 --> URI Class Initialized
INFO - 2017-07-07 08:57:50 --> Router Class Initialized
INFO - 2017-07-07 08:57:50 --> Output Class Initialized
INFO - 2017-07-07 08:57:50 --> Security Class Initialized
DEBUG - 2017-07-07 08:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:57:50 --> Input Class Initialized
INFO - 2017-07-07 08:57:50 --> Language Class Initialized
INFO - 2017-07-07 08:57:50 --> Loader Class Initialized
INFO - 2017-07-07 08:57:50 --> Controller Class Initialized
INFO - 2017-07-07 08:57:50 --> Database Driver Class Initialized
INFO - 2017-07-07 08:57:50 --> Model Class Initialized
INFO - 2017-07-07 08:57:50 --> Helper loaded: form_helper
INFO - 2017-07-07 08:57:50 --> Helper loaded: url_helper
INFO - 2017-07-07 08:57:50 --> Model Class Initialized
INFO - 2017-07-07 08:57:50 --> Final output sent to browser
DEBUG - 2017-07-07 08:57:50 --> Total execution time: 0.0750
ERROR - 2017-07-07 08:57:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:57:51 --> Config Class Initialized
INFO - 2017-07-07 08:57:51 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:57:51 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:57:51 --> Utf8 Class Initialized
INFO - 2017-07-07 08:57:51 --> URI Class Initialized
INFO - 2017-07-07 08:57:51 --> Router Class Initialized
INFO - 2017-07-07 08:57:51 --> Output Class Initialized
INFO - 2017-07-07 08:57:51 --> Security Class Initialized
DEBUG - 2017-07-07 08:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:57:51 --> Input Class Initialized
INFO - 2017-07-07 08:57:51 --> Language Class Initialized
INFO - 2017-07-07 08:57:51 --> Loader Class Initialized
INFO - 2017-07-07 08:57:51 --> Controller Class Initialized
INFO - 2017-07-07 08:57:51 --> Database Driver Class Initialized
INFO - 2017-07-07 08:57:51 --> Model Class Initialized
INFO - 2017-07-07 08:57:51 --> Helper loaded: form_helper
INFO - 2017-07-07 08:57:51 --> Helper loaded: url_helper
INFO - 2017-07-07 08:57:51 --> Model Class Initialized
INFO - 2017-07-07 08:57:51 --> Final output sent to browser
DEBUG - 2017-07-07 08:57:51 --> Total execution time: 0.0475
ERROR - 2017-07-07 08:57:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:57:53 --> Config Class Initialized
INFO - 2017-07-07 08:57:53 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:57:53 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:57:53 --> Utf8 Class Initialized
INFO - 2017-07-07 08:57:53 --> URI Class Initialized
INFO - 2017-07-07 08:57:53 --> Router Class Initialized
INFO - 2017-07-07 08:57:53 --> Output Class Initialized
INFO - 2017-07-07 08:57:53 --> Security Class Initialized
DEBUG - 2017-07-07 08:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:57:53 --> Input Class Initialized
INFO - 2017-07-07 08:57:54 --> Language Class Initialized
INFO - 2017-07-07 08:57:54 --> Loader Class Initialized
INFO - 2017-07-07 08:57:54 --> Controller Class Initialized
INFO - 2017-07-07 08:57:54 --> Database Driver Class Initialized
INFO - 2017-07-07 08:57:54 --> Model Class Initialized
INFO - 2017-07-07 08:57:54 --> Helper loaded: form_helper
INFO - 2017-07-07 08:57:54 --> Helper loaded: url_helper
INFO - 2017-07-07 08:57:54 --> Model Class Initialized
INFO - 2017-07-07 08:57:54 --> Final output sent to browser
DEBUG - 2017-07-07 08:57:54 --> Total execution time: 0.1000
ERROR - 2017-07-07 08:57:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 08:57:56 --> Config Class Initialized
INFO - 2017-07-07 08:57:56 --> Hooks Class Initialized
DEBUG - 2017-07-07 08:57:56 --> UTF-8 Support Enabled
INFO - 2017-07-07 08:57:56 --> Utf8 Class Initialized
INFO - 2017-07-07 08:57:56 --> URI Class Initialized
INFO - 2017-07-07 08:57:56 --> Router Class Initialized
INFO - 2017-07-07 08:57:56 --> Output Class Initialized
INFO - 2017-07-07 08:57:56 --> Security Class Initialized
DEBUG - 2017-07-07 08:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 08:57:56 --> Input Class Initialized
INFO - 2017-07-07 08:57:56 --> Language Class Initialized
INFO - 2017-07-07 08:57:56 --> Loader Class Initialized
INFO - 2017-07-07 08:57:56 --> Controller Class Initialized
INFO - 2017-07-07 08:57:56 --> Database Driver Class Initialized
INFO - 2017-07-07 08:57:56 --> Model Class Initialized
INFO - 2017-07-07 08:57:56 --> Helper loaded: form_helper
INFO - 2017-07-07 08:57:56 --> Helper loaded: url_helper
INFO - 2017-07-07 08:57:56 --> Model Class Initialized
INFO - 2017-07-07 08:57:56 --> Final output sent to browser
DEBUG - 2017-07-07 08:57:56 --> Total execution time: 0.0925
ERROR - 2017-07-07 09:00:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:00:56 --> Config Class Initialized
INFO - 2017-07-07 09:00:56 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:00:56 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:00:56 --> Utf8 Class Initialized
INFO - 2017-07-07 09:00:56 --> URI Class Initialized
INFO - 2017-07-07 09:00:56 --> Router Class Initialized
INFO - 2017-07-07 09:00:56 --> Output Class Initialized
INFO - 2017-07-07 09:00:56 --> Security Class Initialized
DEBUG - 2017-07-07 09:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:00:56 --> Input Class Initialized
INFO - 2017-07-07 09:00:56 --> Language Class Initialized
INFO - 2017-07-07 09:00:56 --> Loader Class Initialized
INFO - 2017-07-07 09:00:56 --> Controller Class Initialized
INFO - 2017-07-07 09:00:56 --> Database Driver Class Initialized
INFO - 2017-07-07 09:00:56 --> Model Class Initialized
INFO - 2017-07-07 09:00:56 --> Helper loaded: form_helper
INFO - 2017-07-07 09:00:56 --> Helper loaded: url_helper
INFO - 2017-07-07 09:00:56 --> Model Class Initialized
INFO - 2017-07-07 09:00:56 --> Final output sent to browser
DEBUG - 2017-07-07 09:00:56 --> Total execution time: 0.0590
ERROR - 2017-07-07 09:00:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:00:57 --> Config Class Initialized
INFO - 2017-07-07 09:00:57 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:00:57 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:00:57 --> Utf8 Class Initialized
INFO - 2017-07-07 09:00:57 --> URI Class Initialized
INFO - 2017-07-07 09:00:57 --> Router Class Initialized
INFO - 2017-07-07 09:00:57 --> Output Class Initialized
INFO - 2017-07-07 09:00:57 --> Security Class Initialized
DEBUG - 2017-07-07 09:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:00:57 --> Input Class Initialized
INFO - 2017-07-07 09:00:57 --> Language Class Initialized
INFO - 2017-07-07 09:00:57 --> Loader Class Initialized
INFO - 2017-07-07 09:00:57 --> Controller Class Initialized
INFO - 2017-07-07 09:00:57 --> Database Driver Class Initialized
INFO - 2017-07-07 09:00:57 --> Model Class Initialized
INFO - 2017-07-07 09:00:57 --> Helper loaded: form_helper
INFO - 2017-07-07 09:00:57 --> Helper loaded: url_helper
INFO - 2017-07-07 09:00:57 --> Model Class Initialized
INFO - 2017-07-07 09:00:57 --> Final output sent to browser
DEBUG - 2017-07-07 09:00:57 --> Total execution time: 0.0670
ERROR - 2017-07-07 09:00:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:00:58 --> Config Class Initialized
INFO - 2017-07-07 09:00:58 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:00:58 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:00:58 --> Utf8 Class Initialized
INFO - 2017-07-07 09:00:58 --> URI Class Initialized
INFO - 2017-07-07 09:00:58 --> Router Class Initialized
INFO - 2017-07-07 09:00:58 --> Output Class Initialized
INFO - 2017-07-07 09:00:58 --> Security Class Initialized
DEBUG - 2017-07-07 09:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:00:58 --> Input Class Initialized
INFO - 2017-07-07 09:00:58 --> Language Class Initialized
INFO - 2017-07-07 09:00:58 --> Loader Class Initialized
INFO - 2017-07-07 09:00:58 --> Controller Class Initialized
INFO - 2017-07-07 09:00:58 --> Database Driver Class Initialized
INFO - 2017-07-07 09:00:58 --> Model Class Initialized
INFO - 2017-07-07 09:00:58 --> Helper loaded: form_helper
INFO - 2017-07-07 09:00:58 --> Helper loaded: url_helper
INFO - 2017-07-07 09:00:58 --> Model Class Initialized
INFO - 2017-07-07 09:00:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 09:00:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 09:00:58 --> Final output sent to browser
DEBUG - 2017-07-07 09:00:58 --> Total execution time: 0.2210
ERROR - 2017-07-07 09:01:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:01:02 --> Config Class Initialized
INFO - 2017-07-07 09:01:02 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:01:02 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:01:02 --> Utf8 Class Initialized
INFO - 2017-07-07 09:01:02 --> URI Class Initialized
INFO - 2017-07-07 09:01:02 --> Router Class Initialized
INFO - 2017-07-07 09:01:02 --> Output Class Initialized
INFO - 2017-07-07 09:01:02 --> Security Class Initialized
DEBUG - 2017-07-07 09:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:01:02 --> Input Class Initialized
INFO - 2017-07-07 09:01:02 --> Language Class Initialized
INFO - 2017-07-07 09:01:02 --> Loader Class Initialized
INFO - 2017-07-07 09:01:02 --> Controller Class Initialized
INFO - 2017-07-07 09:01:02 --> Database Driver Class Initialized
INFO - 2017-07-07 09:01:02 --> Model Class Initialized
INFO - 2017-07-07 09:01:02 --> Helper loaded: form_helper
INFO - 2017-07-07 09:01:02 --> Helper loaded: url_helper
INFO - 2017-07-07 09:01:02 --> Model Class Initialized
INFO - 2017-07-07 09:01:02 --> Final output sent to browser
DEBUG - 2017-07-07 09:01:02 --> Total execution time: 0.0575
ERROR - 2017-07-07 09:01:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:01:03 --> Config Class Initialized
INFO - 2017-07-07 09:01:03 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:01:03 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:01:03 --> Utf8 Class Initialized
INFO - 2017-07-07 09:01:03 --> URI Class Initialized
INFO - 2017-07-07 09:01:03 --> Router Class Initialized
INFO - 2017-07-07 09:01:03 --> Output Class Initialized
INFO - 2017-07-07 09:01:03 --> Security Class Initialized
DEBUG - 2017-07-07 09:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:01:03 --> Input Class Initialized
INFO - 2017-07-07 09:01:03 --> Language Class Initialized
INFO - 2017-07-07 09:01:03 --> Loader Class Initialized
INFO - 2017-07-07 09:01:03 --> Controller Class Initialized
INFO - 2017-07-07 09:01:03 --> Database Driver Class Initialized
INFO - 2017-07-07 09:01:03 --> Model Class Initialized
INFO - 2017-07-07 09:01:03 --> Helper loaded: form_helper
INFO - 2017-07-07 09:01:03 --> Helper loaded: url_helper
INFO - 2017-07-07 09:01:03 --> Model Class Initialized
INFO - 2017-07-07 09:01:03 --> Final output sent to browser
DEBUG - 2017-07-07 09:01:03 --> Total execution time: 0.0575
ERROR - 2017-07-07 09:01:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:01:04 --> Config Class Initialized
INFO - 2017-07-07 09:01:04 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:01:04 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:01:04 --> Utf8 Class Initialized
INFO - 2017-07-07 09:01:04 --> URI Class Initialized
INFO - 2017-07-07 09:01:04 --> Router Class Initialized
INFO - 2017-07-07 09:01:04 --> Output Class Initialized
INFO - 2017-07-07 09:01:04 --> Security Class Initialized
DEBUG - 2017-07-07 09:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:01:04 --> Input Class Initialized
INFO - 2017-07-07 09:01:04 --> Language Class Initialized
INFO - 2017-07-07 09:01:04 --> Loader Class Initialized
INFO - 2017-07-07 09:01:04 --> Controller Class Initialized
INFO - 2017-07-07 09:01:04 --> Database Driver Class Initialized
INFO - 2017-07-07 09:01:04 --> Model Class Initialized
INFO - 2017-07-07 09:01:04 --> Helper loaded: form_helper
INFO - 2017-07-07 09:01:04 --> Helper loaded: url_helper
INFO - 2017-07-07 09:01:04 --> Model Class Initialized
INFO - 2017-07-07 09:01:04 --> Final output sent to browser
DEBUG - 2017-07-07 09:01:04 --> Total execution time: 0.0575
ERROR - 2017-07-07 09:01:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:01:06 --> Config Class Initialized
INFO - 2017-07-07 09:01:06 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:01:06 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:01:06 --> Utf8 Class Initialized
INFO - 2017-07-07 09:01:06 --> URI Class Initialized
INFO - 2017-07-07 09:01:06 --> Router Class Initialized
INFO - 2017-07-07 09:01:06 --> Output Class Initialized
INFO - 2017-07-07 09:01:06 --> Security Class Initialized
DEBUG - 2017-07-07 09:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:01:06 --> Input Class Initialized
INFO - 2017-07-07 09:01:06 --> Language Class Initialized
INFO - 2017-07-07 09:01:06 --> Loader Class Initialized
INFO - 2017-07-07 09:01:06 --> Controller Class Initialized
INFO - 2017-07-07 09:01:06 --> Database Driver Class Initialized
INFO - 2017-07-07 09:01:06 --> Model Class Initialized
INFO - 2017-07-07 09:01:06 --> Helper loaded: form_helper
INFO - 2017-07-07 09:01:06 --> Helper loaded: url_helper
INFO - 2017-07-07 09:01:06 --> Model Class Initialized
INFO - 2017-07-07 09:01:06 --> Final output sent to browser
DEBUG - 2017-07-07 09:01:06 --> Total execution time: 0.0650
ERROR - 2017-07-07 09:01:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:01:08 --> Config Class Initialized
INFO - 2017-07-07 09:01:08 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:01:08 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:01:08 --> Utf8 Class Initialized
INFO - 2017-07-07 09:01:08 --> URI Class Initialized
INFO - 2017-07-07 09:01:08 --> Router Class Initialized
INFO - 2017-07-07 09:01:08 --> Output Class Initialized
INFO - 2017-07-07 09:01:08 --> Security Class Initialized
DEBUG - 2017-07-07 09:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:01:08 --> Input Class Initialized
INFO - 2017-07-07 09:01:08 --> Language Class Initialized
INFO - 2017-07-07 09:01:08 --> Loader Class Initialized
INFO - 2017-07-07 09:01:08 --> Controller Class Initialized
INFO - 2017-07-07 09:01:08 --> Database Driver Class Initialized
INFO - 2017-07-07 09:01:08 --> Model Class Initialized
INFO - 2017-07-07 09:01:08 --> Helper loaded: form_helper
INFO - 2017-07-07 09:01:08 --> Helper loaded: url_helper
INFO - 2017-07-07 09:01:08 --> Model Class Initialized
INFO - 2017-07-07 09:01:08 --> Final output sent to browser
DEBUG - 2017-07-07 09:01:08 --> Total execution time: 0.0550
ERROR - 2017-07-07 09:05:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:05:58 --> Config Class Initialized
INFO - 2017-07-07 09:05:58 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:05:58 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:05:58 --> Utf8 Class Initialized
INFO - 2017-07-07 09:05:58 --> URI Class Initialized
INFO - 2017-07-07 09:05:58 --> Router Class Initialized
INFO - 2017-07-07 09:05:58 --> Output Class Initialized
INFO - 2017-07-07 09:05:58 --> Security Class Initialized
DEBUG - 2017-07-07 09:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:05:58 --> Input Class Initialized
INFO - 2017-07-07 09:05:58 --> Language Class Initialized
INFO - 2017-07-07 09:05:58 --> Loader Class Initialized
INFO - 2017-07-07 09:05:58 --> Controller Class Initialized
INFO - 2017-07-07 09:05:58 --> Database Driver Class Initialized
INFO - 2017-07-07 09:05:58 --> Model Class Initialized
INFO - 2017-07-07 09:05:58 --> Helper loaded: form_helper
INFO - 2017-07-07 09:05:58 --> Helper loaded: url_helper
INFO - 2017-07-07 09:05:58 --> Model Class Initialized
INFO - 2017-07-07 09:05:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 09:05:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 09:05:58 --> Final output sent to browser
DEBUG - 2017-07-07 09:05:58 --> Total execution time: 0.1880
ERROR - 2017-07-07 09:06:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:06:04 --> Config Class Initialized
INFO - 2017-07-07 09:06:04 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:06:04 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:06:04 --> Utf8 Class Initialized
INFO - 2017-07-07 09:06:04 --> URI Class Initialized
INFO - 2017-07-07 09:06:04 --> Router Class Initialized
INFO - 2017-07-07 09:06:04 --> Output Class Initialized
INFO - 2017-07-07 09:06:04 --> Security Class Initialized
DEBUG - 2017-07-07 09:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:06:04 --> Input Class Initialized
INFO - 2017-07-07 09:06:04 --> Language Class Initialized
INFO - 2017-07-07 09:06:04 --> Loader Class Initialized
INFO - 2017-07-07 09:06:04 --> Controller Class Initialized
INFO - 2017-07-07 09:06:04 --> Database Driver Class Initialized
INFO - 2017-07-07 09:06:04 --> Model Class Initialized
INFO - 2017-07-07 09:06:04 --> Helper loaded: form_helper
INFO - 2017-07-07 09:06:04 --> Helper loaded: url_helper
INFO - 2017-07-07 09:06:04 --> Model Class Initialized
INFO - 2017-07-07 09:06:04 --> Final output sent to browser
DEBUG - 2017-07-07 09:06:04 --> Total execution time: 0.0975
ERROR - 2017-07-07 09:06:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:06:05 --> Config Class Initialized
INFO - 2017-07-07 09:06:05 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:06:05 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:06:05 --> Utf8 Class Initialized
INFO - 2017-07-07 09:06:05 --> URI Class Initialized
INFO - 2017-07-07 09:06:05 --> Router Class Initialized
INFO - 2017-07-07 09:06:05 --> Output Class Initialized
INFO - 2017-07-07 09:06:05 --> Security Class Initialized
DEBUG - 2017-07-07 09:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:06:05 --> Input Class Initialized
INFO - 2017-07-07 09:06:05 --> Language Class Initialized
INFO - 2017-07-07 09:06:05 --> Loader Class Initialized
INFO - 2017-07-07 09:06:05 --> Controller Class Initialized
INFO - 2017-07-07 09:06:05 --> Database Driver Class Initialized
INFO - 2017-07-07 09:06:05 --> Model Class Initialized
INFO - 2017-07-07 09:06:05 --> Helper loaded: form_helper
INFO - 2017-07-07 09:06:05 --> Helper loaded: url_helper
INFO - 2017-07-07 09:06:05 --> Model Class Initialized
INFO - 2017-07-07 09:06:05 --> Final output sent to browser
DEBUG - 2017-07-07 09:06:05 --> Total execution time: 0.0600
ERROR - 2017-07-07 09:06:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:06:06 --> Config Class Initialized
INFO - 2017-07-07 09:06:06 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:06:06 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:06:06 --> Utf8 Class Initialized
INFO - 2017-07-07 09:06:06 --> URI Class Initialized
INFO - 2017-07-07 09:06:06 --> Router Class Initialized
INFO - 2017-07-07 09:06:06 --> Output Class Initialized
INFO - 2017-07-07 09:06:06 --> Security Class Initialized
DEBUG - 2017-07-07 09:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:06:06 --> Input Class Initialized
INFO - 2017-07-07 09:06:06 --> Language Class Initialized
INFO - 2017-07-07 09:06:06 --> Loader Class Initialized
INFO - 2017-07-07 09:06:06 --> Controller Class Initialized
INFO - 2017-07-07 09:06:06 --> Database Driver Class Initialized
INFO - 2017-07-07 09:06:06 --> Model Class Initialized
INFO - 2017-07-07 09:06:06 --> Helper loaded: form_helper
INFO - 2017-07-07 09:06:06 --> Helper loaded: url_helper
INFO - 2017-07-07 09:06:06 --> Model Class Initialized
INFO - 2017-07-07 09:06:06 --> Final output sent to browser
DEBUG - 2017-07-07 09:06:06 --> Total execution time: 0.1000
ERROR - 2017-07-07 09:06:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:06:09 --> Config Class Initialized
INFO - 2017-07-07 09:06:09 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:06:09 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:06:09 --> Utf8 Class Initialized
INFO - 2017-07-07 09:06:09 --> URI Class Initialized
INFO - 2017-07-07 09:06:09 --> Router Class Initialized
INFO - 2017-07-07 09:06:09 --> Output Class Initialized
INFO - 2017-07-07 09:06:09 --> Security Class Initialized
DEBUG - 2017-07-07 09:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:06:09 --> Input Class Initialized
INFO - 2017-07-07 09:06:09 --> Language Class Initialized
INFO - 2017-07-07 09:06:09 --> Loader Class Initialized
INFO - 2017-07-07 09:06:09 --> Controller Class Initialized
INFO - 2017-07-07 09:06:09 --> Database Driver Class Initialized
INFO - 2017-07-07 09:06:09 --> Model Class Initialized
INFO - 2017-07-07 09:06:09 --> Helper loaded: form_helper
INFO - 2017-07-07 09:06:09 --> Helper loaded: url_helper
INFO - 2017-07-07 09:06:09 --> Model Class Initialized
INFO - 2017-07-07 09:06:09 --> Final output sent to browser
DEBUG - 2017-07-07 09:06:09 --> Total execution time: 0.0550
ERROR - 2017-07-07 09:09:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:09:07 --> Config Class Initialized
INFO - 2017-07-07 09:09:07 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:09:07 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:09:07 --> Utf8 Class Initialized
INFO - 2017-07-07 09:09:07 --> URI Class Initialized
INFO - 2017-07-07 09:09:07 --> Router Class Initialized
INFO - 2017-07-07 09:09:07 --> Output Class Initialized
INFO - 2017-07-07 09:09:07 --> Security Class Initialized
DEBUG - 2017-07-07 09:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:09:07 --> Input Class Initialized
INFO - 2017-07-07 09:09:07 --> Language Class Initialized
INFO - 2017-07-07 09:09:07 --> Loader Class Initialized
INFO - 2017-07-07 09:09:07 --> Controller Class Initialized
INFO - 2017-07-07 09:09:07 --> Database Driver Class Initialized
INFO - 2017-07-07 09:09:07 --> Model Class Initialized
INFO - 2017-07-07 09:09:07 --> Helper loaded: form_helper
INFO - 2017-07-07 09:09:07 --> Helper loaded: url_helper
INFO - 2017-07-07 09:09:07 --> Model Class Initialized
INFO - 2017-07-07 09:09:07 --> Final output sent to browser
DEBUG - 2017-07-07 09:09:07 --> Total execution time: 0.0575
ERROR - 2017-07-07 09:09:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:09:08 --> Config Class Initialized
INFO - 2017-07-07 09:09:08 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:09:08 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:09:08 --> Utf8 Class Initialized
INFO - 2017-07-07 09:09:08 --> URI Class Initialized
INFO - 2017-07-07 09:09:08 --> Router Class Initialized
INFO - 2017-07-07 09:09:08 --> Output Class Initialized
INFO - 2017-07-07 09:09:08 --> Security Class Initialized
DEBUG - 2017-07-07 09:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:09:08 --> Input Class Initialized
INFO - 2017-07-07 09:09:08 --> Language Class Initialized
INFO - 2017-07-07 09:09:08 --> Loader Class Initialized
INFO - 2017-07-07 09:09:08 --> Controller Class Initialized
INFO - 2017-07-07 09:09:08 --> Database Driver Class Initialized
INFO - 2017-07-07 09:09:08 --> Model Class Initialized
INFO - 2017-07-07 09:09:08 --> Helper loaded: form_helper
INFO - 2017-07-07 09:09:08 --> Helper loaded: url_helper
INFO - 2017-07-07 09:09:08 --> Model Class Initialized
INFO - 2017-07-07 09:09:08 --> Final output sent to browser
DEBUG - 2017-07-07 09:09:08 --> Total execution time: 0.0650
ERROR - 2017-07-07 09:09:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:09:18 --> Config Class Initialized
INFO - 2017-07-07 09:09:18 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:09:18 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:09:18 --> Utf8 Class Initialized
INFO - 2017-07-07 09:09:18 --> URI Class Initialized
INFO - 2017-07-07 09:09:18 --> Router Class Initialized
INFO - 2017-07-07 09:09:18 --> Output Class Initialized
INFO - 2017-07-07 09:09:18 --> Security Class Initialized
DEBUG - 2017-07-07 09:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:09:18 --> Input Class Initialized
INFO - 2017-07-07 09:09:18 --> Language Class Initialized
INFO - 2017-07-07 09:09:18 --> Loader Class Initialized
INFO - 2017-07-07 09:09:18 --> Controller Class Initialized
INFO - 2017-07-07 09:09:18 --> Database Driver Class Initialized
INFO - 2017-07-07 09:09:18 --> Model Class Initialized
INFO - 2017-07-07 09:09:18 --> Helper loaded: form_helper
INFO - 2017-07-07 09:09:18 --> Helper loaded: url_helper
INFO - 2017-07-07 09:09:18 --> Model Class Initialized
INFO - 2017-07-07 09:09:18 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 09:09:18 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 09:09:18 --> Final output sent to browser
DEBUG - 2017-07-07 09:09:18 --> Total execution time: 0.1030
ERROR - 2017-07-07 09:09:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:09:22 --> Config Class Initialized
INFO - 2017-07-07 09:09:22 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:09:22 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:09:22 --> Utf8 Class Initialized
INFO - 2017-07-07 09:09:22 --> URI Class Initialized
INFO - 2017-07-07 09:09:22 --> Router Class Initialized
INFO - 2017-07-07 09:09:22 --> Output Class Initialized
INFO - 2017-07-07 09:09:22 --> Security Class Initialized
DEBUG - 2017-07-07 09:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:09:22 --> Input Class Initialized
INFO - 2017-07-07 09:09:22 --> Language Class Initialized
INFO - 2017-07-07 09:09:22 --> Loader Class Initialized
INFO - 2017-07-07 09:09:22 --> Controller Class Initialized
INFO - 2017-07-07 09:09:22 --> Database Driver Class Initialized
INFO - 2017-07-07 09:09:22 --> Model Class Initialized
INFO - 2017-07-07 09:09:22 --> Helper loaded: form_helper
INFO - 2017-07-07 09:09:22 --> Helper loaded: url_helper
INFO - 2017-07-07 09:09:22 --> Model Class Initialized
INFO - 2017-07-07 09:09:22 --> Final output sent to browser
DEBUG - 2017-07-07 09:09:22 --> Total execution time: 0.3510
ERROR - 2017-07-07 09:09:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:09:24 --> Config Class Initialized
INFO - 2017-07-07 09:09:24 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:09:24 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:09:24 --> Utf8 Class Initialized
INFO - 2017-07-07 09:09:24 --> URI Class Initialized
INFO - 2017-07-07 09:09:24 --> Router Class Initialized
INFO - 2017-07-07 09:09:24 --> Output Class Initialized
INFO - 2017-07-07 09:09:24 --> Security Class Initialized
DEBUG - 2017-07-07 09:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:09:24 --> Input Class Initialized
INFO - 2017-07-07 09:09:24 --> Language Class Initialized
INFO - 2017-07-07 09:09:24 --> Loader Class Initialized
INFO - 2017-07-07 09:09:24 --> Controller Class Initialized
INFO - 2017-07-07 09:09:24 --> Database Driver Class Initialized
INFO - 2017-07-07 09:09:24 --> Model Class Initialized
INFO - 2017-07-07 09:09:24 --> Helper loaded: form_helper
INFO - 2017-07-07 09:09:24 --> Helper loaded: url_helper
INFO - 2017-07-07 09:09:24 --> Model Class Initialized
INFO - 2017-07-07 09:09:24 --> Final output sent to browser
DEBUG - 2017-07-07 09:09:24 --> Total execution time: 0.2600
ERROR - 2017-07-07 09:09:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:09:24 --> Config Class Initialized
INFO - 2017-07-07 09:09:24 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:09:24 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:09:24 --> Utf8 Class Initialized
INFO - 2017-07-07 09:09:24 --> URI Class Initialized
INFO - 2017-07-07 09:09:24 --> Router Class Initialized
INFO - 2017-07-07 09:09:24 --> Output Class Initialized
INFO - 2017-07-07 09:09:24 --> Security Class Initialized
DEBUG - 2017-07-07 09:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:09:24 --> Input Class Initialized
INFO - 2017-07-07 09:09:24 --> Language Class Initialized
INFO - 2017-07-07 09:09:24 --> Loader Class Initialized
INFO - 2017-07-07 09:09:24 --> Controller Class Initialized
INFO - 2017-07-07 09:09:24 --> Database Driver Class Initialized
INFO - 2017-07-07 09:09:24 --> Model Class Initialized
INFO - 2017-07-07 09:09:24 --> Helper loaded: form_helper
INFO - 2017-07-07 09:09:24 --> Helper loaded: url_helper
INFO - 2017-07-07 09:09:24 --> Model Class Initialized
INFO - 2017-07-07 09:09:24 --> Final output sent to browser
DEBUG - 2017-07-07 09:09:24 --> Total execution time: 0.0700
ERROR - 2017-07-07 09:09:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:09:27 --> Config Class Initialized
INFO - 2017-07-07 09:09:27 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:09:27 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:09:27 --> Utf8 Class Initialized
INFO - 2017-07-07 09:09:27 --> URI Class Initialized
INFO - 2017-07-07 09:09:27 --> Router Class Initialized
INFO - 2017-07-07 09:09:27 --> Output Class Initialized
INFO - 2017-07-07 09:09:27 --> Security Class Initialized
DEBUG - 2017-07-07 09:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:09:27 --> Input Class Initialized
INFO - 2017-07-07 09:09:27 --> Language Class Initialized
INFO - 2017-07-07 09:09:27 --> Loader Class Initialized
INFO - 2017-07-07 09:09:27 --> Controller Class Initialized
INFO - 2017-07-07 09:09:27 --> Database Driver Class Initialized
INFO - 2017-07-07 09:09:27 --> Model Class Initialized
INFO - 2017-07-07 09:09:27 --> Helper loaded: form_helper
INFO - 2017-07-07 09:09:27 --> Helper loaded: url_helper
INFO - 2017-07-07 09:09:27 --> Model Class Initialized
INFO - 2017-07-07 09:09:27 --> Final output sent to browser
DEBUG - 2017-07-07 09:09:27 --> Total execution time: 0.0910
ERROR - 2017-07-07 09:09:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:09:29 --> Config Class Initialized
INFO - 2017-07-07 09:09:29 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:09:29 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:09:29 --> Utf8 Class Initialized
INFO - 2017-07-07 09:09:29 --> URI Class Initialized
INFO - 2017-07-07 09:09:29 --> Router Class Initialized
INFO - 2017-07-07 09:09:29 --> Output Class Initialized
INFO - 2017-07-07 09:09:29 --> Security Class Initialized
DEBUG - 2017-07-07 09:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:09:29 --> Input Class Initialized
INFO - 2017-07-07 09:09:29 --> Language Class Initialized
INFO - 2017-07-07 09:09:29 --> Loader Class Initialized
INFO - 2017-07-07 09:09:29 --> Controller Class Initialized
INFO - 2017-07-07 09:09:29 --> Database Driver Class Initialized
INFO - 2017-07-07 09:09:29 --> Model Class Initialized
INFO - 2017-07-07 09:09:29 --> Helper loaded: form_helper
INFO - 2017-07-07 09:09:29 --> Helper loaded: url_helper
INFO - 2017-07-07 09:09:29 --> Model Class Initialized
INFO - 2017-07-07 09:09:29 --> Final output sent to browser
DEBUG - 2017-07-07 09:09:29 --> Total execution time: 0.0875
ERROR - 2017-07-07 09:10:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:10:48 --> Config Class Initialized
INFO - 2017-07-07 09:10:48 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:10:48 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:10:48 --> Utf8 Class Initialized
INFO - 2017-07-07 09:10:48 --> URI Class Initialized
INFO - 2017-07-07 09:10:48 --> Router Class Initialized
INFO - 2017-07-07 09:10:48 --> Output Class Initialized
INFO - 2017-07-07 09:10:48 --> Security Class Initialized
DEBUG - 2017-07-07 09:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:10:48 --> Input Class Initialized
INFO - 2017-07-07 09:10:48 --> Language Class Initialized
INFO - 2017-07-07 09:10:48 --> Loader Class Initialized
INFO - 2017-07-07 09:10:48 --> Controller Class Initialized
INFO - 2017-07-07 09:10:48 --> Database Driver Class Initialized
INFO - 2017-07-07 09:10:48 --> Model Class Initialized
INFO - 2017-07-07 09:10:48 --> Helper loaded: form_helper
INFO - 2017-07-07 09:10:48 --> Helper loaded: url_helper
INFO - 2017-07-07 09:10:48 --> Model Class Initialized
INFO - 2017-07-07 09:10:48 --> Final output sent to browser
DEBUG - 2017-07-07 09:10:48 --> Total execution time: 0.0800
ERROR - 2017-07-07 09:10:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:10:49 --> Config Class Initialized
INFO - 2017-07-07 09:10:49 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:10:49 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:10:49 --> Utf8 Class Initialized
INFO - 2017-07-07 09:10:49 --> URI Class Initialized
INFO - 2017-07-07 09:10:49 --> Router Class Initialized
INFO - 2017-07-07 09:10:49 --> Output Class Initialized
INFO - 2017-07-07 09:10:49 --> Security Class Initialized
DEBUG - 2017-07-07 09:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:10:49 --> Input Class Initialized
INFO - 2017-07-07 09:10:49 --> Language Class Initialized
INFO - 2017-07-07 09:10:49 --> Loader Class Initialized
INFO - 2017-07-07 09:10:49 --> Controller Class Initialized
INFO - 2017-07-07 09:10:49 --> Database Driver Class Initialized
INFO - 2017-07-07 09:10:49 --> Model Class Initialized
INFO - 2017-07-07 09:10:49 --> Helper loaded: form_helper
INFO - 2017-07-07 09:10:49 --> Helper loaded: url_helper
INFO - 2017-07-07 09:10:49 --> Model Class Initialized
INFO - 2017-07-07 09:10:49 --> Final output sent to browser
DEBUG - 2017-07-07 09:10:49 --> Total execution time: 0.0800
ERROR - 2017-07-07 09:10:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:10:53 --> Config Class Initialized
INFO - 2017-07-07 09:10:53 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:10:53 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:10:53 --> Utf8 Class Initialized
INFO - 2017-07-07 09:10:53 --> URI Class Initialized
INFO - 2017-07-07 09:10:53 --> Router Class Initialized
INFO - 2017-07-07 09:10:53 --> Output Class Initialized
INFO - 2017-07-07 09:10:53 --> Security Class Initialized
DEBUG - 2017-07-07 09:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:10:53 --> Input Class Initialized
INFO - 2017-07-07 09:10:53 --> Language Class Initialized
INFO - 2017-07-07 09:10:53 --> Loader Class Initialized
INFO - 2017-07-07 09:10:53 --> Controller Class Initialized
INFO - 2017-07-07 09:10:53 --> Database Driver Class Initialized
INFO - 2017-07-07 09:10:54 --> Model Class Initialized
INFO - 2017-07-07 09:10:54 --> Helper loaded: form_helper
INFO - 2017-07-07 09:10:54 --> Helper loaded: url_helper
INFO - 2017-07-07 09:10:54 --> Model Class Initialized
INFO - 2017-07-07 09:10:54 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 09:10:54 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 09:10:54 --> Final output sent to browser
DEBUG - 2017-07-07 09:10:54 --> Total execution time: 0.1600
ERROR - 2017-07-07 09:10:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:10:57 --> Config Class Initialized
INFO - 2017-07-07 09:10:57 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:10:57 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:10:57 --> Utf8 Class Initialized
INFO - 2017-07-07 09:10:57 --> URI Class Initialized
INFO - 2017-07-07 09:10:57 --> Router Class Initialized
INFO - 2017-07-07 09:10:57 --> Output Class Initialized
INFO - 2017-07-07 09:10:57 --> Security Class Initialized
DEBUG - 2017-07-07 09:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:10:57 --> Input Class Initialized
INFO - 2017-07-07 09:10:57 --> Language Class Initialized
INFO - 2017-07-07 09:10:57 --> Loader Class Initialized
INFO - 2017-07-07 09:10:57 --> Controller Class Initialized
INFO - 2017-07-07 09:10:57 --> Database Driver Class Initialized
INFO - 2017-07-07 09:10:57 --> Model Class Initialized
INFO - 2017-07-07 09:10:57 --> Helper loaded: form_helper
INFO - 2017-07-07 09:10:57 --> Helper loaded: url_helper
INFO - 2017-07-07 09:10:57 --> Model Class Initialized
INFO - 2017-07-07 09:10:57 --> Final output sent to browser
DEBUG - 2017-07-07 09:10:57 --> Total execution time: 0.0950
ERROR - 2017-07-07 09:10:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:10:58 --> Config Class Initialized
INFO - 2017-07-07 09:10:58 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:10:58 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:10:58 --> Utf8 Class Initialized
INFO - 2017-07-07 09:10:58 --> URI Class Initialized
INFO - 2017-07-07 09:10:58 --> Router Class Initialized
INFO - 2017-07-07 09:10:58 --> Output Class Initialized
INFO - 2017-07-07 09:10:58 --> Security Class Initialized
DEBUG - 2017-07-07 09:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:10:58 --> Input Class Initialized
INFO - 2017-07-07 09:10:58 --> Language Class Initialized
INFO - 2017-07-07 09:10:58 --> Loader Class Initialized
INFO - 2017-07-07 09:10:58 --> Controller Class Initialized
INFO - 2017-07-07 09:10:58 --> Database Driver Class Initialized
INFO - 2017-07-07 09:10:58 --> Model Class Initialized
INFO - 2017-07-07 09:10:58 --> Helper loaded: form_helper
INFO - 2017-07-07 09:10:58 --> Helper loaded: url_helper
INFO - 2017-07-07 09:10:58 --> Model Class Initialized
INFO - 2017-07-07 09:10:58 --> Final output sent to browser
DEBUG - 2017-07-07 09:10:58 --> Total execution time: 0.1025
ERROR - 2017-07-07 09:10:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:10:59 --> Config Class Initialized
INFO - 2017-07-07 09:10:59 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:10:59 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:10:59 --> Utf8 Class Initialized
INFO - 2017-07-07 09:10:59 --> URI Class Initialized
INFO - 2017-07-07 09:10:59 --> Router Class Initialized
INFO - 2017-07-07 09:10:59 --> Output Class Initialized
INFO - 2017-07-07 09:10:59 --> Security Class Initialized
DEBUG - 2017-07-07 09:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:10:59 --> Input Class Initialized
INFO - 2017-07-07 09:10:59 --> Language Class Initialized
INFO - 2017-07-07 09:10:59 --> Loader Class Initialized
INFO - 2017-07-07 09:10:59 --> Controller Class Initialized
INFO - 2017-07-07 09:10:59 --> Database Driver Class Initialized
INFO - 2017-07-07 09:10:59 --> Model Class Initialized
INFO - 2017-07-07 09:10:59 --> Helper loaded: form_helper
INFO - 2017-07-07 09:10:59 --> Helper loaded: url_helper
INFO - 2017-07-07 09:10:59 --> Model Class Initialized
INFO - 2017-07-07 09:10:59 --> Final output sent to browser
DEBUG - 2017-07-07 09:10:59 --> Total execution time: 0.0575
ERROR - 2017-07-07 09:11:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:11:01 --> Config Class Initialized
INFO - 2017-07-07 09:11:01 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:11:01 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:11:01 --> Utf8 Class Initialized
INFO - 2017-07-07 09:11:01 --> URI Class Initialized
INFO - 2017-07-07 09:11:01 --> Router Class Initialized
INFO - 2017-07-07 09:11:01 --> Output Class Initialized
INFO - 2017-07-07 09:11:01 --> Security Class Initialized
DEBUG - 2017-07-07 09:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:11:01 --> Input Class Initialized
INFO - 2017-07-07 09:11:01 --> Language Class Initialized
INFO - 2017-07-07 09:11:01 --> Loader Class Initialized
INFO - 2017-07-07 09:11:01 --> Controller Class Initialized
INFO - 2017-07-07 09:11:01 --> Database Driver Class Initialized
INFO - 2017-07-07 09:11:01 --> Model Class Initialized
INFO - 2017-07-07 09:11:01 --> Helper loaded: form_helper
INFO - 2017-07-07 09:11:01 --> Helper loaded: url_helper
INFO - 2017-07-07 09:11:01 --> Model Class Initialized
INFO - 2017-07-07 09:11:01 --> Final output sent to browser
DEBUG - 2017-07-07 09:11:01 --> Total execution time: 0.0525
ERROR - 2017-07-07 09:11:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:11:03 --> Config Class Initialized
INFO - 2017-07-07 09:11:03 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:11:03 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:11:03 --> Utf8 Class Initialized
INFO - 2017-07-07 09:11:03 --> URI Class Initialized
INFO - 2017-07-07 09:11:03 --> Router Class Initialized
INFO - 2017-07-07 09:11:03 --> Output Class Initialized
INFO - 2017-07-07 09:11:03 --> Security Class Initialized
DEBUG - 2017-07-07 09:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:11:03 --> Input Class Initialized
INFO - 2017-07-07 09:11:03 --> Language Class Initialized
INFO - 2017-07-07 09:11:03 --> Loader Class Initialized
INFO - 2017-07-07 09:11:03 --> Controller Class Initialized
INFO - 2017-07-07 09:11:03 --> Database Driver Class Initialized
INFO - 2017-07-07 09:11:03 --> Model Class Initialized
INFO - 2017-07-07 09:11:03 --> Helper loaded: form_helper
INFO - 2017-07-07 09:11:03 --> Helper loaded: url_helper
INFO - 2017-07-07 09:11:03 --> Model Class Initialized
INFO - 2017-07-07 09:11:03 --> Final output sent to browser
DEBUG - 2017-07-07 09:11:03 --> Total execution time: 0.0865
ERROR - 2017-07-07 09:15:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:15:10 --> Config Class Initialized
INFO - 2017-07-07 09:15:10 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:15:10 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:15:10 --> Utf8 Class Initialized
INFO - 2017-07-07 09:15:10 --> URI Class Initialized
INFO - 2017-07-07 09:15:10 --> Router Class Initialized
INFO - 2017-07-07 09:15:10 --> Output Class Initialized
INFO - 2017-07-07 09:15:10 --> Security Class Initialized
DEBUG - 2017-07-07 09:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:15:10 --> Input Class Initialized
INFO - 2017-07-07 09:15:10 --> Language Class Initialized
INFO - 2017-07-07 09:15:10 --> Loader Class Initialized
INFO - 2017-07-07 09:15:10 --> Controller Class Initialized
INFO - 2017-07-07 09:15:10 --> Database Driver Class Initialized
INFO - 2017-07-07 09:15:10 --> Model Class Initialized
INFO - 2017-07-07 09:15:10 --> Helper loaded: form_helper
INFO - 2017-07-07 09:15:10 --> Helper loaded: url_helper
INFO - 2017-07-07 09:15:10 --> Model Class Initialized
INFO - 2017-07-07 09:15:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 09:15:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 09:15:10 --> Final output sent to browser
DEBUG - 2017-07-07 09:15:10 --> Total execution time: 0.1420
ERROR - 2017-07-07 09:15:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:15:21 --> Config Class Initialized
INFO - 2017-07-07 09:15:21 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:15:21 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:15:21 --> Utf8 Class Initialized
INFO - 2017-07-07 09:15:21 --> URI Class Initialized
INFO - 2017-07-07 09:15:21 --> Router Class Initialized
INFO - 2017-07-07 09:15:21 --> Output Class Initialized
INFO - 2017-07-07 09:15:21 --> Security Class Initialized
DEBUG - 2017-07-07 09:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:15:21 --> Input Class Initialized
INFO - 2017-07-07 09:15:21 --> Language Class Initialized
INFO - 2017-07-07 09:15:21 --> Loader Class Initialized
INFO - 2017-07-07 09:15:21 --> Controller Class Initialized
INFO - 2017-07-07 09:15:21 --> Database Driver Class Initialized
INFO - 2017-07-07 09:15:21 --> Model Class Initialized
INFO - 2017-07-07 09:15:21 --> Helper loaded: form_helper
INFO - 2017-07-07 09:15:21 --> Helper loaded: url_helper
INFO - 2017-07-07 09:15:21 --> Model Class Initialized
INFO - 2017-07-07 09:15:21 --> Final output sent to browser
DEBUG - 2017-07-07 09:15:21 --> Total execution time: 0.0850
ERROR - 2017-07-07 09:15:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:15:22 --> Config Class Initialized
INFO - 2017-07-07 09:15:22 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:15:22 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:15:22 --> Utf8 Class Initialized
INFO - 2017-07-07 09:15:22 --> URI Class Initialized
INFO - 2017-07-07 09:15:22 --> Router Class Initialized
INFO - 2017-07-07 09:15:22 --> Output Class Initialized
INFO - 2017-07-07 09:15:22 --> Security Class Initialized
DEBUG - 2017-07-07 09:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:15:22 --> Input Class Initialized
INFO - 2017-07-07 09:15:22 --> Language Class Initialized
INFO - 2017-07-07 09:15:22 --> Loader Class Initialized
INFO - 2017-07-07 09:15:22 --> Controller Class Initialized
INFO - 2017-07-07 09:15:22 --> Database Driver Class Initialized
INFO - 2017-07-07 09:15:22 --> Model Class Initialized
INFO - 2017-07-07 09:15:22 --> Helper loaded: form_helper
INFO - 2017-07-07 09:15:22 --> Helper loaded: url_helper
INFO - 2017-07-07 09:15:22 --> Model Class Initialized
INFO - 2017-07-07 09:15:22 --> Final output sent to browser
DEBUG - 2017-07-07 09:15:22 --> Total execution time: 0.0500
ERROR - 2017-07-07 09:15:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:15:23 --> Config Class Initialized
INFO - 2017-07-07 09:15:23 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:15:23 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:15:23 --> Utf8 Class Initialized
INFO - 2017-07-07 09:15:23 --> URI Class Initialized
INFO - 2017-07-07 09:15:23 --> Router Class Initialized
INFO - 2017-07-07 09:15:23 --> Output Class Initialized
INFO - 2017-07-07 09:15:23 --> Security Class Initialized
DEBUG - 2017-07-07 09:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:15:23 --> Input Class Initialized
INFO - 2017-07-07 09:15:23 --> Language Class Initialized
INFO - 2017-07-07 09:15:23 --> Loader Class Initialized
INFO - 2017-07-07 09:15:23 --> Controller Class Initialized
INFO - 2017-07-07 09:15:23 --> Database Driver Class Initialized
INFO - 2017-07-07 09:15:23 --> Model Class Initialized
INFO - 2017-07-07 09:15:23 --> Helper loaded: form_helper
INFO - 2017-07-07 09:15:23 --> Helper loaded: url_helper
INFO - 2017-07-07 09:15:23 --> Model Class Initialized
INFO - 2017-07-07 09:15:23 --> Final output sent to browser
DEBUG - 2017-07-07 09:15:23 --> Total execution time: 0.0625
ERROR - 2017-07-07 09:15:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:15:25 --> Config Class Initialized
INFO - 2017-07-07 09:15:25 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:15:25 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:15:25 --> Utf8 Class Initialized
INFO - 2017-07-07 09:15:25 --> URI Class Initialized
INFO - 2017-07-07 09:15:25 --> Router Class Initialized
INFO - 2017-07-07 09:15:25 --> Output Class Initialized
INFO - 2017-07-07 09:15:25 --> Security Class Initialized
DEBUG - 2017-07-07 09:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:15:25 --> Input Class Initialized
INFO - 2017-07-07 09:15:25 --> Language Class Initialized
INFO - 2017-07-07 09:15:25 --> Loader Class Initialized
INFO - 2017-07-07 09:15:25 --> Controller Class Initialized
INFO - 2017-07-07 09:15:25 --> Database Driver Class Initialized
INFO - 2017-07-07 09:15:25 --> Model Class Initialized
INFO - 2017-07-07 09:15:25 --> Helper loaded: form_helper
INFO - 2017-07-07 09:15:25 --> Helper loaded: url_helper
INFO - 2017-07-07 09:15:25 --> Model Class Initialized
INFO - 2017-07-07 09:15:25 --> Final output sent to browser
DEBUG - 2017-07-07 09:15:25 --> Total execution time: 0.0550
ERROR - 2017-07-07 09:15:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:15:48 --> Config Class Initialized
INFO - 2017-07-07 09:15:48 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:15:48 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:15:48 --> Utf8 Class Initialized
INFO - 2017-07-07 09:15:48 --> URI Class Initialized
INFO - 2017-07-07 09:15:48 --> Router Class Initialized
INFO - 2017-07-07 09:15:48 --> Output Class Initialized
INFO - 2017-07-07 09:15:48 --> Security Class Initialized
DEBUG - 2017-07-07 09:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:15:48 --> Input Class Initialized
INFO - 2017-07-07 09:15:48 --> Language Class Initialized
INFO - 2017-07-07 09:15:48 --> Loader Class Initialized
INFO - 2017-07-07 09:15:48 --> Controller Class Initialized
INFO - 2017-07-07 09:15:48 --> Database Driver Class Initialized
INFO - 2017-07-07 09:15:48 --> Model Class Initialized
INFO - 2017-07-07 09:15:48 --> Helper loaded: form_helper
INFO - 2017-07-07 09:15:48 --> Helper loaded: url_helper
INFO - 2017-07-07 09:15:48 --> Model Class Initialized
INFO - 2017-07-07 09:15:48 --> Final output sent to browser
DEBUG - 2017-07-07 09:15:48 --> Total execution time: 0.0495
ERROR - 2017-07-07 09:17:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:17:10 --> Config Class Initialized
INFO - 2017-07-07 09:17:10 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:17:10 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:17:10 --> Utf8 Class Initialized
INFO - 2017-07-07 09:17:10 --> URI Class Initialized
INFO - 2017-07-07 09:17:10 --> Router Class Initialized
INFO - 2017-07-07 09:17:10 --> Output Class Initialized
INFO - 2017-07-07 09:17:10 --> Security Class Initialized
DEBUG - 2017-07-07 09:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:17:10 --> Input Class Initialized
INFO - 2017-07-07 09:17:10 --> Language Class Initialized
INFO - 2017-07-07 09:17:10 --> Loader Class Initialized
INFO - 2017-07-07 09:17:10 --> Controller Class Initialized
INFO - 2017-07-07 09:17:10 --> Database Driver Class Initialized
INFO - 2017-07-07 09:17:10 --> Model Class Initialized
INFO - 2017-07-07 09:17:10 --> Helper loaded: form_helper
INFO - 2017-07-07 09:17:10 --> Helper loaded: url_helper
INFO - 2017-07-07 09:17:10 --> Model Class Initialized
INFO - 2017-07-07 09:17:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 09:17:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 09:17:10 --> Final output sent to browser
DEBUG - 2017-07-07 09:17:10 --> Total execution time: 0.1940
ERROR - 2017-07-07 09:17:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:17:28 --> Config Class Initialized
INFO - 2017-07-07 09:17:28 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:17:28 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:17:28 --> Utf8 Class Initialized
INFO - 2017-07-07 09:17:28 --> URI Class Initialized
INFO - 2017-07-07 09:17:28 --> Router Class Initialized
INFO - 2017-07-07 09:17:28 --> Output Class Initialized
INFO - 2017-07-07 09:17:28 --> Security Class Initialized
DEBUG - 2017-07-07 09:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:17:28 --> Input Class Initialized
INFO - 2017-07-07 09:17:28 --> Language Class Initialized
INFO - 2017-07-07 09:17:28 --> Loader Class Initialized
INFO - 2017-07-07 09:17:28 --> Controller Class Initialized
INFO - 2017-07-07 09:17:28 --> Database Driver Class Initialized
INFO - 2017-07-07 09:17:29 --> Model Class Initialized
INFO - 2017-07-07 09:17:29 --> Helper loaded: form_helper
INFO - 2017-07-07 09:17:29 --> Helper loaded: url_helper
INFO - 2017-07-07 09:17:29 --> Model Class Initialized
INFO - 2017-07-07 09:17:29 --> Final output sent to browser
DEBUG - 2017-07-07 09:17:29 --> Total execution time: 0.0900
ERROR - 2017-07-07 09:17:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:17:29 --> Config Class Initialized
INFO - 2017-07-07 09:17:29 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:17:29 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:17:29 --> Utf8 Class Initialized
INFO - 2017-07-07 09:17:29 --> URI Class Initialized
INFO - 2017-07-07 09:17:29 --> Router Class Initialized
INFO - 2017-07-07 09:17:29 --> Output Class Initialized
INFO - 2017-07-07 09:17:29 --> Security Class Initialized
DEBUG - 2017-07-07 09:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:17:30 --> Input Class Initialized
INFO - 2017-07-07 09:17:30 --> Language Class Initialized
INFO - 2017-07-07 09:17:30 --> Loader Class Initialized
INFO - 2017-07-07 09:17:30 --> Controller Class Initialized
INFO - 2017-07-07 09:17:30 --> Database Driver Class Initialized
INFO - 2017-07-07 09:17:30 --> Model Class Initialized
INFO - 2017-07-07 09:17:30 --> Helper loaded: form_helper
INFO - 2017-07-07 09:17:30 --> Helper loaded: url_helper
INFO - 2017-07-07 09:17:30 --> Model Class Initialized
INFO - 2017-07-07 09:17:30 --> Final output sent to browser
DEBUG - 2017-07-07 09:17:30 --> Total execution time: 0.0500
ERROR - 2017-07-07 09:17:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:17:31 --> Config Class Initialized
INFO - 2017-07-07 09:17:31 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:17:31 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:17:31 --> Utf8 Class Initialized
INFO - 2017-07-07 09:17:31 --> URI Class Initialized
INFO - 2017-07-07 09:17:31 --> Router Class Initialized
INFO - 2017-07-07 09:17:31 --> Output Class Initialized
INFO - 2017-07-07 09:17:31 --> Security Class Initialized
DEBUG - 2017-07-07 09:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:17:31 --> Input Class Initialized
INFO - 2017-07-07 09:17:31 --> Language Class Initialized
INFO - 2017-07-07 09:17:31 --> Loader Class Initialized
INFO - 2017-07-07 09:17:31 --> Controller Class Initialized
INFO - 2017-07-07 09:17:31 --> Database Driver Class Initialized
INFO - 2017-07-07 09:17:31 --> Model Class Initialized
INFO - 2017-07-07 09:17:31 --> Helper loaded: form_helper
INFO - 2017-07-07 09:17:31 --> Helper loaded: url_helper
INFO - 2017-07-07 09:17:31 --> Model Class Initialized
INFO - 2017-07-07 09:17:31 --> Final output sent to browser
DEBUG - 2017-07-07 09:17:31 --> Total execution time: 0.0750
ERROR - 2017-07-07 09:17:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:17:34 --> Config Class Initialized
INFO - 2017-07-07 09:17:34 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:17:34 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:17:34 --> Utf8 Class Initialized
INFO - 2017-07-07 09:17:34 --> URI Class Initialized
INFO - 2017-07-07 09:17:34 --> Router Class Initialized
INFO - 2017-07-07 09:17:34 --> Output Class Initialized
INFO - 2017-07-07 09:17:34 --> Security Class Initialized
DEBUG - 2017-07-07 09:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:17:34 --> Input Class Initialized
INFO - 2017-07-07 09:17:34 --> Language Class Initialized
INFO - 2017-07-07 09:17:34 --> Loader Class Initialized
INFO - 2017-07-07 09:17:34 --> Controller Class Initialized
INFO - 2017-07-07 09:17:34 --> Database Driver Class Initialized
INFO - 2017-07-07 09:17:34 --> Model Class Initialized
INFO - 2017-07-07 09:17:34 --> Helper loaded: form_helper
INFO - 2017-07-07 09:17:34 --> Helper loaded: url_helper
INFO - 2017-07-07 09:17:34 --> Model Class Initialized
INFO - 2017-07-07 09:17:34 --> Final output sent to browser
DEBUG - 2017-07-07 09:17:34 --> Total execution time: 0.0950
ERROR - 2017-07-07 09:28:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:28:42 --> Config Class Initialized
INFO - 2017-07-07 09:28:42 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:28:42 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:28:42 --> Utf8 Class Initialized
INFO - 2017-07-07 09:28:42 --> URI Class Initialized
INFO - 2017-07-07 09:28:42 --> Router Class Initialized
INFO - 2017-07-07 09:28:42 --> Output Class Initialized
INFO - 2017-07-07 09:28:42 --> Security Class Initialized
DEBUG - 2017-07-07 09:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:28:42 --> Input Class Initialized
INFO - 2017-07-07 09:28:42 --> Language Class Initialized
INFO - 2017-07-07 09:28:42 --> Loader Class Initialized
INFO - 2017-07-07 09:28:42 --> Controller Class Initialized
INFO - 2017-07-07 09:28:42 --> Database Driver Class Initialized
INFO - 2017-07-07 09:28:42 --> Model Class Initialized
INFO - 2017-07-07 09:28:42 --> Helper loaded: form_helper
INFO - 2017-07-07 09:28:42 --> Helper loaded: url_helper
INFO - 2017-07-07 09:28:42 --> Model Class Initialized
INFO - 2017-07-07 09:28:42 --> Final output sent to browser
DEBUG - 2017-07-07 09:28:42 --> Total execution time: 0.0488
ERROR - 2017-07-07 09:28:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:28:43 --> Config Class Initialized
INFO - 2017-07-07 09:28:43 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:28:43 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:28:43 --> Utf8 Class Initialized
INFO - 2017-07-07 09:28:43 --> URI Class Initialized
INFO - 2017-07-07 09:28:43 --> Router Class Initialized
INFO - 2017-07-07 09:28:43 --> Output Class Initialized
INFO - 2017-07-07 09:28:43 --> Security Class Initialized
DEBUG - 2017-07-07 09:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:28:43 --> Input Class Initialized
INFO - 2017-07-07 09:28:43 --> Language Class Initialized
INFO - 2017-07-07 09:28:43 --> Loader Class Initialized
INFO - 2017-07-07 09:28:43 --> Controller Class Initialized
INFO - 2017-07-07 09:28:43 --> Database Driver Class Initialized
INFO - 2017-07-07 09:28:43 --> Model Class Initialized
INFO - 2017-07-07 09:28:43 --> Helper loaded: form_helper
INFO - 2017-07-07 09:28:43 --> Helper loaded: url_helper
INFO - 2017-07-07 09:28:43 --> Model Class Initialized
INFO - 2017-07-07 09:28:43 --> Final output sent to browser
DEBUG - 2017-07-07 09:28:43 --> Total execution time: 0.0475
ERROR - 2017-07-07 09:28:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:28:44 --> Config Class Initialized
INFO - 2017-07-07 09:28:44 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:28:44 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:28:44 --> Utf8 Class Initialized
INFO - 2017-07-07 09:28:44 --> URI Class Initialized
INFO - 2017-07-07 09:28:44 --> Router Class Initialized
INFO - 2017-07-07 09:28:44 --> Output Class Initialized
INFO - 2017-07-07 09:28:44 --> Security Class Initialized
DEBUG - 2017-07-07 09:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:28:45 --> Input Class Initialized
INFO - 2017-07-07 09:28:45 --> Language Class Initialized
INFO - 2017-07-07 09:28:45 --> Loader Class Initialized
INFO - 2017-07-07 09:28:45 --> Controller Class Initialized
INFO - 2017-07-07 09:28:45 --> Database Driver Class Initialized
INFO - 2017-07-07 09:28:45 --> Model Class Initialized
INFO - 2017-07-07 09:28:45 --> Helper loaded: form_helper
INFO - 2017-07-07 09:28:45 --> Helper loaded: url_helper
INFO - 2017-07-07 09:28:45 --> Model Class Initialized
INFO - 2017-07-07 09:28:45 --> Final output sent to browser
DEBUG - 2017-07-07 09:28:45 --> Total execution time: 0.0663
ERROR - 2017-07-07 09:28:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:28:47 --> Config Class Initialized
INFO - 2017-07-07 09:28:47 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:28:47 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:28:47 --> Utf8 Class Initialized
INFO - 2017-07-07 09:28:47 --> URI Class Initialized
INFO - 2017-07-07 09:28:47 --> Router Class Initialized
INFO - 2017-07-07 09:28:47 --> Output Class Initialized
INFO - 2017-07-07 09:28:47 --> Security Class Initialized
DEBUG - 2017-07-07 09:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:28:47 --> Input Class Initialized
INFO - 2017-07-07 09:28:47 --> Language Class Initialized
INFO - 2017-07-07 09:28:47 --> Loader Class Initialized
INFO - 2017-07-07 09:28:47 --> Controller Class Initialized
INFO - 2017-07-07 09:28:47 --> Database Driver Class Initialized
INFO - 2017-07-07 09:28:47 --> Model Class Initialized
INFO - 2017-07-07 09:28:47 --> Helper loaded: form_helper
INFO - 2017-07-07 09:28:47 --> Helper loaded: url_helper
INFO - 2017-07-07 09:28:47 --> Model Class Initialized
INFO - 2017-07-07 09:28:47 --> Final output sent to browser
DEBUG - 2017-07-07 09:28:47 --> Total execution time: 0.0525
ERROR - 2017-07-07 09:35:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:35:23 --> Config Class Initialized
INFO - 2017-07-07 09:35:23 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:35:23 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:35:23 --> Utf8 Class Initialized
INFO - 2017-07-07 09:35:23 --> URI Class Initialized
INFO - 2017-07-07 09:35:23 --> Router Class Initialized
INFO - 2017-07-07 09:35:23 --> Output Class Initialized
INFO - 2017-07-07 09:35:23 --> Security Class Initialized
DEBUG - 2017-07-07 09:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:35:23 --> Input Class Initialized
INFO - 2017-07-07 09:35:23 --> Language Class Initialized
INFO - 2017-07-07 09:35:23 --> Loader Class Initialized
INFO - 2017-07-07 09:35:23 --> Controller Class Initialized
INFO - 2017-07-07 09:35:23 --> Database Driver Class Initialized
INFO - 2017-07-07 09:35:23 --> Model Class Initialized
INFO - 2017-07-07 09:35:23 --> Helper loaded: form_helper
INFO - 2017-07-07 09:35:23 --> Helper loaded: url_helper
INFO - 2017-07-07 09:35:23 --> Model Class Initialized
INFO - 2017-07-07 09:35:23 --> Final output sent to browser
DEBUG - 2017-07-07 09:35:23 --> Total execution time: 0.1525
ERROR - 2017-07-07 09:35:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:35:37 --> Config Class Initialized
INFO - 2017-07-07 09:35:37 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:35:37 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:35:37 --> Utf8 Class Initialized
INFO - 2017-07-07 09:35:37 --> URI Class Initialized
INFO - 2017-07-07 09:35:37 --> Router Class Initialized
INFO - 2017-07-07 09:35:37 --> Output Class Initialized
INFO - 2017-07-07 09:35:37 --> Security Class Initialized
DEBUG - 2017-07-07 09:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:35:37 --> Input Class Initialized
INFO - 2017-07-07 09:35:37 --> Language Class Initialized
INFO - 2017-07-07 09:35:37 --> Loader Class Initialized
INFO - 2017-07-07 09:35:37 --> Controller Class Initialized
INFO - 2017-07-07 09:35:37 --> Database Driver Class Initialized
INFO - 2017-07-07 09:35:37 --> Model Class Initialized
INFO - 2017-07-07 09:35:37 --> Helper loaded: form_helper
INFO - 2017-07-07 09:35:37 --> Helper loaded: url_helper
INFO - 2017-07-07 09:35:37 --> Model Class Initialized
INFO - 2017-07-07 09:35:37 --> Final output sent to browser
DEBUG - 2017-07-07 09:35:37 --> Total execution time: 0.0520
ERROR - 2017-07-07 09:35:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:35:38 --> Config Class Initialized
INFO - 2017-07-07 09:35:38 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:35:38 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:35:38 --> Utf8 Class Initialized
INFO - 2017-07-07 09:35:38 --> URI Class Initialized
INFO - 2017-07-07 09:35:38 --> Router Class Initialized
INFO - 2017-07-07 09:35:38 --> Output Class Initialized
INFO - 2017-07-07 09:35:38 --> Security Class Initialized
DEBUG - 2017-07-07 09:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:35:38 --> Input Class Initialized
INFO - 2017-07-07 09:35:38 --> Language Class Initialized
INFO - 2017-07-07 09:35:38 --> Loader Class Initialized
INFO - 2017-07-07 09:35:38 --> Controller Class Initialized
INFO - 2017-07-07 09:35:38 --> Database Driver Class Initialized
INFO - 2017-07-07 09:35:38 --> Model Class Initialized
INFO - 2017-07-07 09:35:38 --> Helper loaded: form_helper
INFO - 2017-07-07 09:35:38 --> Helper loaded: url_helper
INFO - 2017-07-07 09:35:38 --> Model Class Initialized
INFO - 2017-07-07 09:35:38 --> Final output sent to browser
DEBUG - 2017-07-07 09:35:38 --> Total execution time: 0.0575
ERROR - 2017-07-07 09:35:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:35:40 --> Config Class Initialized
INFO - 2017-07-07 09:35:40 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:35:40 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:35:40 --> Utf8 Class Initialized
INFO - 2017-07-07 09:35:40 --> URI Class Initialized
INFO - 2017-07-07 09:35:40 --> Router Class Initialized
INFO - 2017-07-07 09:35:40 --> Output Class Initialized
INFO - 2017-07-07 09:35:40 --> Security Class Initialized
DEBUG - 2017-07-07 09:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:35:40 --> Input Class Initialized
INFO - 2017-07-07 09:35:40 --> Language Class Initialized
INFO - 2017-07-07 09:35:40 --> Loader Class Initialized
INFO - 2017-07-07 09:35:40 --> Controller Class Initialized
INFO - 2017-07-07 09:35:40 --> Database Driver Class Initialized
INFO - 2017-07-07 09:35:40 --> Model Class Initialized
INFO - 2017-07-07 09:35:40 --> Helper loaded: form_helper
INFO - 2017-07-07 09:35:40 --> Helper loaded: url_helper
INFO - 2017-07-07 09:35:40 --> Model Class Initialized
INFO - 2017-07-07 09:35:40 --> Final output sent to browser
DEBUG - 2017-07-07 09:35:40 --> Total execution time: 0.1750
ERROR - 2017-07-07 09:35:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:35:44 --> Config Class Initialized
INFO - 2017-07-07 09:35:44 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:35:44 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:35:44 --> Utf8 Class Initialized
INFO - 2017-07-07 09:35:44 --> URI Class Initialized
INFO - 2017-07-07 09:35:44 --> Router Class Initialized
INFO - 2017-07-07 09:35:44 --> Output Class Initialized
INFO - 2017-07-07 09:35:44 --> Security Class Initialized
DEBUG - 2017-07-07 09:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:35:44 --> Input Class Initialized
INFO - 2017-07-07 09:35:44 --> Language Class Initialized
INFO - 2017-07-07 09:35:44 --> Loader Class Initialized
INFO - 2017-07-07 09:35:44 --> Controller Class Initialized
INFO - 2017-07-07 09:35:44 --> Database Driver Class Initialized
INFO - 2017-07-07 09:35:44 --> Model Class Initialized
INFO - 2017-07-07 09:35:44 --> Helper loaded: form_helper
INFO - 2017-07-07 09:35:44 --> Helper loaded: url_helper
INFO - 2017-07-07 09:35:44 --> Model Class Initialized
INFO - 2017-07-07 09:35:44 --> Final output sent to browser
DEBUG - 2017-07-07 09:35:44 --> Total execution time: 0.0775
ERROR - 2017-07-07 09:35:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:35:45 --> Config Class Initialized
INFO - 2017-07-07 09:35:45 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:35:45 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:35:45 --> Utf8 Class Initialized
INFO - 2017-07-07 09:35:45 --> URI Class Initialized
INFO - 2017-07-07 09:35:45 --> Router Class Initialized
INFO - 2017-07-07 09:35:45 --> Output Class Initialized
INFO - 2017-07-07 09:35:45 --> Security Class Initialized
DEBUG - 2017-07-07 09:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:35:45 --> Input Class Initialized
INFO - 2017-07-07 09:35:45 --> Language Class Initialized
INFO - 2017-07-07 09:35:45 --> Loader Class Initialized
INFO - 2017-07-07 09:35:45 --> Controller Class Initialized
INFO - 2017-07-07 09:35:45 --> Database Driver Class Initialized
INFO - 2017-07-07 09:35:45 --> Model Class Initialized
INFO - 2017-07-07 09:35:45 --> Helper loaded: form_helper
INFO - 2017-07-07 09:35:45 --> Helper loaded: url_helper
INFO - 2017-07-07 09:35:45 --> Model Class Initialized
INFO - 2017-07-07 09:35:45 --> Final output sent to browser
DEBUG - 2017-07-07 09:35:45 --> Total execution time: 0.0475
ERROR - 2017-07-07 09:35:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:35:47 --> Config Class Initialized
INFO - 2017-07-07 09:35:47 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:35:47 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:35:47 --> Utf8 Class Initialized
INFO - 2017-07-07 09:35:47 --> URI Class Initialized
INFO - 2017-07-07 09:35:47 --> Router Class Initialized
INFO - 2017-07-07 09:35:47 --> Output Class Initialized
INFO - 2017-07-07 09:35:47 --> Security Class Initialized
DEBUG - 2017-07-07 09:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:35:47 --> Input Class Initialized
INFO - 2017-07-07 09:35:47 --> Language Class Initialized
INFO - 2017-07-07 09:35:47 --> Loader Class Initialized
INFO - 2017-07-07 09:35:47 --> Controller Class Initialized
INFO - 2017-07-07 09:35:47 --> Database Driver Class Initialized
INFO - 2017-07-07 09:35:47 --> Model Class Initialized
INFO - 2017-07-07 09:35:47 --> Helper loaded: form_helper
INFO - 2017-07-07 09:35:47 --> Helper loaded: url_helper
INFO - 2017-07-07 09:35:47 --> Model Class Initialized
INFO - 2017-07-07 09:35:47 --> Final output sent to browser
DEBUG - 2017-07-07 09:35:47 --> Total execution time: 0.1275
ERROR - 2017-07-07 09:37:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:37:05 --> Config Class Initialized
INFO - 2017-07-07 09:37:05 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:37:05 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:37:05 --> Utf8 Class Initialized
INFO - 2017-07-07 09:37:05 --> URI Class Initialized
INFO - 2017-07-07 09:37:05 --> Router Class Initialized
INFO - 2017-07-07 09:37:05 --> Output Class Initialized
INFO - 2017-07-07 09:37:05 --> Security Class Initialized
DEBUG - 2017-07-07 09:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:37:05 --> Input Class Initialized
INFO - 2017-07-07 09:37:05 --> Language Class Initialized
INFO - 2017-07-07 09:37:05 --> Loader Class Initialized
INFO - 2017-07-07 09:37:05 --> Controller Class Initialized
INFO - 2017-07-07 09:37:05 --> Database Driver Class Initialized
INFO - 2017-07-07 09:37:05 --> Model Class Initialized
INFO - 2017-07-07 09:37:05 --> Helper loaded: form_helper
INFO - 2017-07-07 09:37:05 --> Helper loaded: url_helper
INFO - 2017-07-07 09:37:05 --> Model Class Initialized
INFO - 2017-07-07 09:37:05 --> Final output sent to browser
DEBUG - 2017-07-07 09:37:05 --> Total execution time: 0.0725
ERROR - 2017-07-07 09:37:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:37:07 --> Config Class Initialized
INFO - 2017-07-07 09:37:07 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:37:07 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:37:07 --> Utf8 Class Initialized
INFO - 2017-07-07 09:37:07 --> URI Class Initialized
INFO - 2017-07-07 09:37:07 --> Router Class Initialized
INFO - 2017-07-07 09:37:07 --> Output Class Initialized
INFO - 2017-07-07 09:37:07 --> Security Class Initialized
DEBUG - 2017-07-07 09:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:37:07 --> Input Class Initialized
INFO - 2017-07-07 09:37:07 --> Language Class Initialized
INFO - 2017-07-07 09:37:07 --> Loader Class Initialized
INFO - 2017-07-07 09:37:07 --> Controller Class Initialized
INFO - 2017-07-07 09:37:07 --> Database Driver Class Initialized
INFO - 2017-07-07 09:37:07 --> Model Class Initialized
INFO - 2017-07-07 09:37:07 --> Helper loaded: form_helper
INFO - 2017-07-07 09:37:07 --> Helper loaded: url_helper
INFO - 2017-07-07 09:37:07 --> Model Class Initialized
INFO - 2017-07-07 09:37:07 --> Final output sent to browser
DEBUG - 2017-07-07 09:37:07 --> Total execution time: 0.1450
ERROR - 2017-07-07 09:38:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:38:17 --> Config Class Initialized
INFO - 2017-07-07 09:38:17 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:38:17 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:38:17 --> Utf8 Class Initialized
INFO - 2017-07-07 09:38:17 --> URI Class Initialized
INFO - 2017-07-07 09:38:17 --> Router Class Initialized
INFO - 2017-07-07 09:38:17 --> Output Class Initialized
INFO - 2017-07-07 09:38:17 --> Security Class Initialized
DEBUG - 2017-07-07 09:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:38:17 --> Input Class Initialized
INFO - 2017-07-07 09:38:17 --> Language Class Initialized
INFO - 2017-07-07 09:38:17 --> Loader Class Initialized
INFO - 2017-07-07 09:38:17 --> Controller Class Initialized
INFO - 2017-07-07 09:38:17 --> Database Driver Class Initialized
INFO - 2017-07-07 09:38:17 --> Model Class Initialized
INFO - 2017-07-07 09:38:17 --> Helper loaded: form_helper
INFO - 2017-07-07 09:38:17 --> Helper loaded: url_helper
INFO - 2017-07-07 09:38:17 --> Model Class Initialized
INFO - 2017-07-07 09:38:17 --> Final output sent to browser
DEBUG - 2017-07-07 09:38:17 --> Total execution time: 0.1700
ERROR - 2017-07-07 09:38:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:38:18 --> Config Class Initialized
INFO - 2017-07-07 09:38:18 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:38:18 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:38:18 --> Utf8 Class Initialized
INFO - 2017-07-07 09:38:18 --> URI Class Initialized
INFO - 2017-07-07 09:38:18 --> Router Class Initialized
INFO - 2017-07-07 09:38:18 --> Output Class Initialized
INFO - 2017-07-07 09:38:18 --> Security Class Initialized
DEBUG - 2017-07-07 09:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:38:18 --> Input Class Initialized
INFO - 2017-07-07 09:38:18 --> Language Class Initialized
INFO - 2017-07-07 09:38:19 --> Loader Class Initialized
INFO - 2017-07-07 09:38:19 --> Controller Class Initialized
INFO - 2017-07-07 09:38:19 --> Database Driver Class Initialized
INFO - 2017-07-07 09:38:19 --> Model Class Initialized
INFO - 2017-07-07 09:38:19 --> Helper loaded: form_helper
INFO - 2017-07-07 09:38:19 --> Helper loaded: url_helper
INFO - 2017-07-07 09:38:19 --> Model Class Initialized
INFO - 2017-07-07 09:38:19 --> Final output sent to browser
DEBUG - 2017-07-07 09:38:19 --> Total execution time: 0.1200
ERROR - 2017-07-07 09:38:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:38:53 --> Config Class Initialized
INFO - 2017-07-07 09:38:53 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:38:53 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:38:53 --> Utf8 Class Initialized
INFO - 2017-07-07 09:38:53 --> URI Class Initialized
INFO - 2017-07-07 09:38:53 --> Router Class Initialized
INFO - 2017-07-07 09:38:53 --> Output Class Initialized
INFO - 2017-07-07 09:38:53 --> Security Class Initialized
DEBUG - 2017-07-07 09:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:38:53 --> Input Class Initialized
INFO - 2017-07-07 09:38:53 --> Language Class Initialized
INFO - 2017-07-07 09:38:53 --> Loader Class Initialized
INFO - 2017-07-07 09:38:53 --> Controller Class Initialized
INFO - 2017-07-07 09:38:53 --> Database Driver Class Initialized
INFO - 2017-07-07 09:38:53 --> Model Class Initialized
INFO - 2017-07-07 09:38:53 --> Helper loaded: form_helper
INFO - 2017-07-07 09:38:53 --> Helper loaded: url_helper
INFO - 2017-07-07 09:38:53 --> Model Class Initialized
INFO - 2017-07-07 09:38:53 --> Final output sent to browser
DEBUG - 2017-07-07 09:38:53 --> Total execution time: 0.1700
ERROR - 2017-07-07 09:38:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:38:54 --> Config Class Initialized
INFO - 2017-07-07 09:38:54 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:38:54 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:38:54 --> Utf8 Class Initialized
INFO - 2017-07-07 09:38:54 --> URI Class Initialized
INFO - 2017-07-07 09:38:54 --> Router Class Initialized
INFO - 2017-07-07 09:38:54 --> Output Class Initialized
INFO - 2017-07-07 09:38:54 --> Security Class Initialized
DEBUG - 2017-07-07 09:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:38:54 --> Input Class Initialized
INFO - 2017-07-07 09:38:54 --> Language Class Initialized
INFO - 2017-07-07 09:38:54 --> Loader Class Initialized
INFO - 2017-07-07 09:38:54 --> Controller Class Initialized
INFO - 2017-07-07 09:38:54 --> Database Driver Class Initialized
INFO - 2017-07-07 09:38:54 --> Model Class Initialized
INFO - 2017-07-07 09:38:54 --> Helper loaded: form_helper
INFO - 2017-07-07 09:38:54 --> Helper loaded: url_helper
INFO - 2017-07-07 09:38:54 --> Model Class Initialized
INFO - 2017-07-07 09:38:54 --> Final output sent to browser
DEBUG - 2017-07-07 09:38:54 --> Total execution time: 0.1000
ERROR - 2017-07-07 09:38:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:38:55 --> Config Class Initialized
INFO - 2017-07-07 09:38:55 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:38:55 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:38:55 --> Utf8 Class Initialized
INFO - 2017-07-07 09:38:55 --> URI Class Initialized
INFO - 2017-07-07 09:38:55 --> Router Class Initialized
INFO - 2017-07-07 09:38:55 --> Output Class Initialized
INFO - 2017-07-07 09:38:55 --> Security Class Initialized
DEBUG - 2017-07-07 09:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:38:55 --> Input Class Initialized
INFO - 2017-07-07 09:38:55 --> Language Class Initialized
INFO - 2017-07-07 09:38:55 --> Loader Class Initialized
INFO - 2017-07-07 09:38:55 --> Controller Class Initialized
INFO - 2017-07-07 09:38:55 --> Database Driver Class Initialized
INFO - 2017-07-07 09:38:55 --> Model Class Initialized
INFO - 2017-07-07 09:38:55 --> Helper loaded: form_helper
INFO - 2017-07-07 09:38:55 --> Helper loaded: url_helper
INFO - 2017-07-07 09:38:55 --> Model Class Initialized
INFO - 2017-07-07 09:38:55 --> Final output sent to browser
DEBUG - 2017-07-07 09:38:55 --> Total execution time: 0.1600
ERROR - 2017-07-07 09:39:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:39:30 --> Config Class Initialized
INFO - 2017-07-07 09:39:30 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:39:30 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:39:30 --> Utf8 Class Initialized
INFO - 2017-07-07 09:39:30 --> URI Class Initialized
INFO - 2017-07-07 09:39:30 --> Router Class Initialized
INFO - 2017-07-07 09:39:30 --> Output Class Initialized
INFO - 2017-07-07 09:39:30 --> Security Class Initialized
DEBUG - 2017-07-07 09:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:39:30 --> Input Class Initialized
INFO - 2017-07-07 09:39:30 --> Language Class Initialized
INFO - 2017-07-07 09:39:30 --> Loader Class Initialized
INFO - 2017-07-07 09:39:30 --> Controller Class Initialized
INFO - 2017-07-07 09:39:30 --> Database Driver Class Initialized
INFO - 2017-07-07 09:39:30 --> Model Class Initialized
INFO - 2017-07-07 09:39:30 --> Helper loaded: form_helper
INFO - 2017-07-07 09:39:30 --> Helper loaded: url_helper
INFO - 2017-07-07 09:39:30 --> Model Class Initialized
INFO - 2017-07-07 09:39:30 --> Final output sent to browser
DEBUG - 2017-07-07 09:39:30 --> Total execution time: 0.1600
ERROR - 2017-07-07 09:39:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:39:37 --> Config Class Initialized
INFO - 2017-07-07 09:39:37 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:39:37 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:39:37 --> Utf8 Class Initialized
INFO - 2017-07-07 09:39:37 --> URI Class Initialized
INFO - 2017-07-07 09:39:37 --> Router Class Initialized
INFO - 2017-07-07 09:39:37 --> Output Class Initialized
INFO - 2017-07-07 09:39:37 --> Security Class Initialized
DEBUG - 2017-07-07 09:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:39:37 --> Input Class Initialized
INFO - 2017-07-07 09:39:37 --> Language Class Initialized
INFO - 2017-07-07 09:39:37 --> Loader Class Initialized
INFO - 2017-07-07 09:39:37 --> Controller Class Initialized
INFO - 2017-07-07 09:39:37 --> Database Driver Class Initialized
INFO - 2017-07-07 09:39:37 --> Model Class Initialized
INFO - 2017-07-07 09:39:37 --> Helper loaded: form_helper
INFO - 2017-07-07 09:39:37 --> Helper loaded: url_helper
INFO - 2017-07-07 09:39:37 --> Model Class Initialized
INFO - 2017-07-07 09:39:37 --> Final output sent to browser
DEBUG - 2017-07-07 09:39:37 --> Total execution time: 0.1400
ERROR - 2017-07-07 09:39:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:39:39 --> Config Class Initialized
INFO - 2017-07-07 09:39:39 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:39:39 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:39:39 --> Utf8 Class Initialized
INFO - 2017-07-07 09:39:39 --> URI Class Initialized
INFO - 2017-07-07 09:39:39 --> Router Class Initialized
INFO - 2017-07-07 09:39:39 --> Output Class Initialized
INFO - 2017-07-07 09:39:39 --> Security Class Initialized
DEBUG - 2017-07-07 09:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:39:39 --> Input Class Initialized
INFO - 2017-07-07 09:39:39 --> Language Class Initialized
INFO - 2017-07-07 09:39:39 --> Loader Class Initialized
INFO - 2017-07-07 09:39:39 --> Controller Class Initialized
INFO - 2017-07-07 09:39:39 --> Database Driver Class Initialized
INFO - 2017-07-07 09:39:39 --> Model Class Initialized
INFO - 2017-07-07 09:39:39 --> Helper loaded: form_helper
INFO - 2017-07-07 09:39:39 --> Helper loaded: url_helper
INFO - 2017-07-07 09:39:39 --> Model Class Initialized
INFO - 2017-07-07 09:39:39 --> Final output sent to browser
DEBUG - 2017-07-07 09:39:39 --> Total execution time: 0.1310
ERROR - 2017-07-07 09:40:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:40:47 --> Config Class Initialized
INFO - 2017-07-07 09:40:47 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:40:47 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:40:47 --> Utf8 Class Initialized
INFO - 2017-07-07 09:40:47 --> URI Class Initialized
INFO - 2017-07-07 09:40:47 --> Router Class Initialized
INFO - 2017-07-07 09:40:48 --> Output Class Initialized
INFO - 2017-07-07 09:40:48 --> Security Class Initialized
DEBUG - 2017-07-07 09:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:40:48 --> Input Class Initialized
INFO - 2017-07-07 09:40:48 --> Language Class Initialized
INFO - 2017-07-07 09:40:48 --> Loader Class Initialized
INFO - 2017-07-07 09:40:48 --> Controller Class Initialized
INFO - 2017-07-07 09:40:48 --> Database Driver Class Initialized
INFO - 2017-07-07 09:40:48 --> Model Class Initialized
INFO - 2017-07-07 09:40:48 --> Helper loaded: form_helper
INFO - 2017-07-07 09:40:48 --> Helper loaded: url_helper
INFO - 2017-07-07 09:40:48 --> Model Class Initialized
INFO - 2017-07-07 09:40:48 --> Final output sent to browser
DEBUG - 2017-07-07 09:40:48 --> Total execution time: 0.1890
ERROR - 2017-07-07 09:40:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:40:55 --> Config Class Initialized
INFO - 2017-07-07 09:40:55 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:40:55 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:40:55 --> Utf8 Class Initialized
INFO - 2017-07-07 09:40:55 --> URI Class Initialized
INFO - 2017-07-07 09:40:55 --> Router Class Initialized
INFO - 2017-07-07 09:40:55 --> Output Class Initialized
INFO - 2017-07-07 09:40:55 --> Security Class Initialized
DEBUG - 2017-07-07 09:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:40:55 --> Input Class Initialized
INFO - 2017-07-07 09:40:55 --> Language Class Initialized
INFO - 2017-07-07 09:40:55 --> Loader Class Initialized
INFO - 2017-07-07 09:40:55 --> Controller Class Initialized
INFO - 2017-07-07 09:40:55 --> Database Driver Class Initialized
INFO - 2017-07-07 09:40:55 --> Model Class Initialized
INFO - 2017-07-07 09:40:55 --> Helper loaded: form_helper
INFO - 2017-07-07 09:40:55 --> Helper loaded: url_helper
INFO - 2017-07-07 09:40:55 --> Model Class Initialized
INFO - 2017-07-07 09:40:55 --> Final output sent to browser
DEBUG - 2017-07-07 09:40:55 --> Total execution time: 0.1000
ERROR - 2017-07-07 09:42:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:42:00 --> Config Class Initialized
INFO - 2017-07-07 09:42:00 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:42:00 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:42:00 --> Utf8 Class Initialized
INFO - 2017-07-07 09:42:00 --> URI Class Initialized
INFO - 2017-07-07 09:42:00 --> Router Class Initialized
INFO - 2017-07-07 09:42:00 --> Output Class Initialized
INFO - 2017-07-07 09:42:00 --> Security Class Initialized
DEBUG - 2017-07-07 09:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:42:00 --> Input Class Initialized
INFO - 2017-07-07 09:42:00 --> Language Class Initialized
INFO - 2017-07-07 09:42:00 --> Loader Class Initialized
INFO - 2017-07-07 09:42:00 --> Controller Class Initialized
INFO - 2017-07-07 09:42:00 --> Database Driver Class Initialized
INFO - 2017-07-07 09:42:01 --> Model Class Initialized
INFO - 2017-07-07 09:42:01 --> Helper loaded: form_helper
INFO - 2017-07-07 09:42:01 --> Helper loaded: url_helper
INFO - 2017-07-07 09:42:01 --> Model Class Initialized
INFO - 2017-07-07 09:42:01 --> Final output sent to browser
DEBUG - 2017-07-07 09:42:01 --> Total execution time: 0.1500
ERROR - 2017-07-07 09:44:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:44:39 --> Config Class Initialized
INFO - 2017-07-07 09:44:39 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:44:39 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:44:39 --> Utf8 Class Initialized
INFO - 2017-07-07 09:44:39 --> URI Class Initialized
INFO - 2017-07-07 09:44:39 --> Router Class Initialized
INFO - 2017-07-07 09:44:39 --> Output Class Initialized
INFO - 2017-07-07 09:44:39 --> Security Class Initialized
DEBUG - 2017-07-07 09:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:44:39 --> Input Class Initialized
INFO - 2017-07-07 09:44:39 --> Language Class Initialized
INFO - 2017-07-07 09:44:39 --> Loader Class Initialized
INFO - 2017-07-07 09:44:39 --> Controller Class Initialized
INFO - 2017-07-07 09:44:39 --> Database Driver Class Initialized
INFO - 2017-07-07 09:44:39 --> Model Class Initialized
INFO - 2017-07-07 09:44:39 --> Helper loaded: form_helper
INFO - 2017-07-07 09:44:39 --> Helper loaded: url_helper
INFO - 2017-07-07 09:44:39 --> Model Class Initialized
INFO - 2017-07-07 09:44:39 --> Final output sent to browser
DEBUG - 2017-07-07 09:44:39 --> Total execution time: 0.1600
ERROR - 2017-07-07 09:44:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:44:47 --> Config Class Initialized
INFO - 2017-07-07 09:44:47 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:44:47 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:44:47 --> Utf8 Class Initialized
INFO - 2017-07-07 09:44:47 --> URI Class Initialized
INFO - 2017-07-07 09:44:47 --> Router Class Initialized
INFO - 2017-07-07 09:44:47 --> Output Class Initialized
INFO - 2017-07-07 09:44:47 --> Security Class Initialized
DEBUG - 2017-07-07 09:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:44:47 --> Input Class Initialized
INFO - 2017-07-07 09:44:47 --> Language Class Initialized
INFO - 2017-07-07 09:44:47 --> Loader Class Initialized
INFO - 2017-07-07 09:44:47 --> Controller Class Initialized
INFO - 2017-07-07 09:44:47 --> Database Driver Class Initialized
INFO - 2017-07-07 09:44:47 --> Model Class Initialized
INFO - 2017-07-07 09:44:47 --> Helper loaded: form_helper
INFO - 2017-07-07 09:44:47 --> Helper loaded: url_helper
INFO - 2017-07-07 09:44:47 --> Model Class Initialized
INFO - 2017-07-07 09:44:47 --> Final output sent to browser
DEBUG - 2017-07-07 09:44:47 --> Total execution time: 0.0900
ERROR - 2017-07-07 09:44:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:44:53 --> Config Class Initialized
INFO - 2017-07-07 09:44:53 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:44:53 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:44:53 --> Utf8 Class Initialized
INFO - 2017-07-07 09:44:53 --> URI Class Initialized
INFO - 2017-07-07 09:44:53 --> Router Class Initialized
INFO - 2017-07-07 09:44:53 --> Output Class Initialized
INFO - 2017-07-07 09:44:53 --> Security Class Initialized
DEBUG - 2017-07-07 09:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:44:53 --> Input Class Initialized
INFO - 2017-07-07 09:44:53 --> Language Class Initialized
INFO - 2017-07-07 09:44:53 --> Loader Class Initialized
INFO - 2017-07-07 09:44:53 --> Controller Class Initialized
INFO - 2017-07-07 09:44:53 --> Database Driver Class Initialized
INFO - 2017-07-07 09:44:53 --> Model Class Initialized
INFO - 2017-07-07 09:44:53 --> Helper loaded: form_helper
INFO - 2017-07-07 09:44:53 --> Helper loaded: url_helper
INFO - 2017-07-07 09:44:53 --> Model Class Initialized
INFO - 2017-07-07 09:44:53 --> Final output sent to browser
DEBUG - 2017-07-07 09:44:53 --> Total execution time: 0.0800
ERROR - 2017-07-07 09:44:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:44:57 --> Config Class Initialized
INFO - 2017-07-07 09:44:57 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:44:57 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:44:57 --> Utf8 Class Initialized
INFO - 2017-07-07 09:44:57 --> URI Class Initialized
INFO - 2017-07-07 09:44:58 --> Router Class Initialized
INFO - 2017-07-07 09:44:58 --> Output Class Initialized
INFO - 2017-07-07 09:44:58 --> Security Class Initialized
DEBUG - 2017-07-07 09:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:44:58 --> Input Class Initialized
INFO - 2017-07-07 09:44:58 --> Language Class Initialized
INFO - 2017-07-07 09:44:58 --> Loader Class Initialized
INFO - 2017-07-07 09:44:58 --> Controller Class Initialized
INFO - 2017-07-07 09:44:58 --> Database Driver Class Initialized
INFO - 2017-07-07 09:44:58 --> Model Class Initialized
INFO - 2017-07-07 09:44:58 --> Helper loaded: form_helper
INFO - 2017-07-07 09:44:58 --> Helper loaded: url_helper
INFO - 2017-07-07 09:44:58 --> Model Class Initialized
INFO - 2017-07-07 09:44:58 --> Final output sent to browser
DEBUG - 2017-07-07 09:44:58 --> Total execution time: 0.1500
ERROR - 2017-07-07 09:45:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:45:16 --> Config Class Initialized
INFO - 2017-07-07 09:45:16 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:45:16 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:45:16 --> Utf8 Class Initialized
INFO - 2017-07-07 09:45:16 --> URI Class Initialized
INFO - 2017-07-07 09:45:16 --> Router Class Initialized
INFO - 2017-07-07 09:45:16 --> Output Class Initialized
INFO - 2017-07-07 09:45:16 --> Security Class Initialized
DEBUG - 2017-07-07 09:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:45:16 --> Input Class Initialized
INFO - 2017-07-07 09:45:16 --> Language Class Initialized
INFO - 2017-07-07 09:45:16 --> Loader Class Initialized
INFO - 2017-07-07 09:45:16 --> Controller Class Initialized
INFO - 2017-07-07 09:45:16 --> Database Driver Class Initialized
INFO - 2017-07-07 09:45:16 --> Model Class Initialized
INFO - 2017-07-07 09:45:16 --> Helper loaded: form_helper
INFO - 2017-07-07 09:45:16 --> Helper loaded: url_helper
INFO - 2017-07-07 09:45:16 --> Model Class Initialized
INFO - 2017-07-07 09:45:16 --> Final output sent to browser
DEBUG - 2017-07-07 09:45:16 --> Total execution time: 0.1600
ERROR - 2017-07-07 09:45:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:45:23 --> Config Class Initialized
INFO - 2017-07-07 09:45:23 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:45:23 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:45:23 --> Utf8 Class Initialized
INFO - 2017-07-07 09:45:23 --> URI Class Initialized
INFO - 2017-07-07 09:45:23 --> Router Class Initialized
INFO - 2017-07-07 09:45:23 --> Output Class Initialized
INFO - 2017-07-07 09:45:23 --> Security Class Initialized
DEBUG - 2017-07-07 09:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:45:23 --> Input Class Initialized
INFO - 2017-07-07 09:45:23 --> Language Class Initialized
INFO - 2017-07-07 09:45:23 --> Loader Class Initialized
INFO - 2017-07-07 09:45:23 --> Controller Class Initialized
INFO - 2017-07-07 09:45:23 --> Database Driver Class Initialized
INFO - 2017-07-07 09:45:23 --> Model Class Initialized
INFO - 2017-07-07 09:45:23 --> Helper loaded: form_helper
INFO - 2017-07-07 09:45:23 --> Helper loaded: url_helper
INFO - 2017-07-07 09:45:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 09:45:23 --> Model Class Initialized
INFO - 2017-07-07 09:45:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-07 09:45:23 --> Final output sent to browser
DEBUG - 2017-07-07 09:45:23 --> Total execution time: 0.0850
ERROR - 2017-07-07 09:45:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:45:35 --> Config Class Initialized
INFO - 2017-07-07 09:45:35 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:45:35 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:45:35 --> Utf8 Class Initialized
INFO - 2017-07-07 09:45:35 --> URI Class Initialized
INFO - 2017-07-07 09:45:35 --> Router Class Initialized
INFO - 2017-07-07 09:45:35 --> Output Class Initialized
INFO - 2017-07-07 09:45:35 --> Security Class Initialized
DEBUG - 2017-07-07 09:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:45:35 --> Input Class Initialized
INFO - 2017-07-07 09:45:35 --> Language Class Initialized
INFO - 2017-07-07 09:45:35 --> Loader Class Initialized
INFO - 2017-07-07 09:45:35 --> Controller Class Initialized
INFO - 2017-07-07 09:45:35 --> Database Driver Class Initialized
INFO - 2017-07-07 09:45:36 --> Model Class Initialized
INFO - 2017-07-07 09:45:36 --> Helper loaded: form_helper
INFO - 2017-07-07 09:45:36 --> Helper loaded: url_helper
INFO - 2017-07-07 09:45:36 --> Model Class Initialized
INFO - 2017-07-07 09:45:36 --> Final output sent to browser
DEBUG - 2017-07-07 09:45:36 --> Total execution time: 0.0800
ERROR - 2017-07-07 09:45:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:45:37 --> Config Class Initialized
INFO - 2017-07-07 09:45:37 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:45:37 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:45:37 --> Utf8 Class Initialized
INFO - 2017-07-07 09:45:37 --> URI Class Initialized
INFO - 2017-07-07 09:45:37 --> Router Class Initialized
INFO - 2017-07-07 09:45:37 --> Output Class Initialized
INFO - 2017-07-07 09:45:37 --> Security Class Initialized
DEBUG - 2017-07-07 09:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:45:37 --> Input Class Initialized
INFO - 2017-07-07 09:45:37 --> Language Class Initialized
INFO - 2017-07-07 09:45:37 --> Loader Class Initialized
INFO - 2017-07-07 09:45:37 --> Controller Class Initialized
INFO - 2017-07-07 09:45:37 --> Database Driver Class Initialized
INFO - 2017-07-07 09:45:37 --> Model Class Initialized
INFO - 2017-07-07 09:45:37 --> Helper loaded: form_helper
INFO - 2017-07-07 09:45:37 --> Helper loaded: url_helper
INFO - 2017-07-07 09:45:37 --> Model Class Initialized
INFO - 2017-07-07 09:45:37 --> Final output sent to browser
DEBUG - 2017-07-07 09:45:37 --> Total execution time: 0.0900
ERROR - 2017-07-07 09:56:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:56:22 --> Config Class Initialized
INFO - 2017-07-07 09:56:22 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:56:22 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:56:22 --> Utf8 Class Initialized
INFO - 2017-07-07 09:56:22 --> URI Class Initialized
INFO - 2017-07-07 09:56:22 --> Router Class Initialized
INFO - 2017-07-07 09:56:22 --> Output Class Initialized
INFO - 2017-07-07 09:56:22 --> Security Class Initialized
DEBUG - 2017-07-07 09:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:56:22 --> Input Class Initialized
INFO - 2017-07-07 09:56:22 --> Language Class Initialized
INFO - 2017-07-07 09:56:22 --> Loader Class Initialized
INFO - 2017-07-07 09:56:22 --> Controller Class Initialized
INFO - 2017-07-07 09:56:22 --> Database Driver Class Initialized
INFO - 2017-07-07 09:56:22 --> Model Class Initialized
INFO - 2017-07-07 09:56:22 --> Helper loaded: form_helper
INFO - 2017-07-07 09:56:22 --> Helper loaded: url_helper
INFO - 2017-07-07 09:56:22 --> Model Class Initialized
INFO - 2017-07-07 09:56:22 --> Final output sent to browser
DEBUG - 2017-07-07 09:56:22 --> Total execution time: 0.0900
ERROR - 2017-07-07 09:57:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:57:09 --> Config Class Initialized
INFO - 2017-07-07 09:57:09 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:57:09 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:57:09 --> Utf8 Class Initialized
INFO - 2017-07-07 09:57:09 --> URI Class Initialized
INFO - 2017-07-07 09:57:09 --> Router Class Initialized
INFO - 2017-07-07 09:57:09 --> Output Class Initialized
INFO - 2017-07-07 09:57:09 --> Security Class Initialized
DEBUG - 2017-07-07 09:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:57:09 --> Input Class Initialized
INFO - 2017-07-07 09:57:09 --> Language Class Initialized
INFO - 2017-07-07 09:57:09 --> Loader Class Initialized
INFO - 2017-07-07 09:57:09 --> Controller Class Initialized
INFO - 2017-07-07 09:57:09 --> Database Driver Class Initialized
INFO - 2017-07-07 09:57:09 --> Model Class Initialized
INFO - 2017-07-07 09:57:09 --> Helper loaded: form_helper
INFO - 2017-07-07 09:57:09 --> Helper loaded: url_helper
INFO - 2017-07-07 09:57:09 --> Model Class Initialized
INFO - 2017-07-07 09:57:09 --> Final output sent to browser
DEBUG - 2017-07-07 09:57:09 --> Total execution time: 0.1000
ERROR - 2017-07-07 09:58:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:58:18 --> Config Class Initialized
INFO - 2017-07-07 09:58:19 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:58:19 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:58:19 --> Utf8 Class Initialized
INFO - 2017-07-07 09:58:19 --> URI Class Initialized
INFO - 2017-07-07 09:58:19 --> Router Class Initialized
INFO - 2017-07-07 09:58:19 --> Output Class Initialized
INFO - 2017-07-07 09:58:19 --> Security Class Initialized
DEBUG - 2017-07-07 09:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:58:19 --> Input Class Initialized
INFO - 2017-07-07 09:58:19 --> Language Class Initialized
INFO - 2017-07-07 09:58:19 --> Loader Class Initialized
INFO - 2017-07-07 09:58:19 --> Controller Class Initialized
INFO - 2017-07-07 09:58:19 --> Database Driver Class Initialized
INFO - 2017-07-07 09:58:19 --> Model Class Initialized
INFO - 2017-07-07 09:58:19 --> Helper loaded: form_helper
INFO - 2017-07-07 09:58:19 --> Helper loaded: url_helper
INFO - 2017-07-07 09:58:19 --> Model Class Initialized
INFO - 2017-07-07 09:58:19 --> Final output sent to browser
DEBUG - 2017-07-07 09:58:19 --> Total execution time: 0.5115
ERROR - 2017-07-07 09:58:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:58:24 --> Config Class Initialized
INFO - 2017-07-07 09:58:24 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:58:24 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:58:24 --> Utf8 Class Initialized
INFO - 2017-07-07 09:58:24 --> URI Class Initialized
INFO - 2017-07-07 09:58:24 --> Router Class Initialized
INFO - 2017-07-07 09:58:24 --> Output Class Initialized
INFO - 2017-07-07 09:58:24 --> Security Class Initialized
DEBUG - 2017-07-07 09:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:58:24 --> Input Class Initialized
INFO - 2017-07-07 09:58:24 --> Language Class Initialized
INFO - 2017-07-07 09:58:24 --> Loader Class Initialized
INFO - 2017-07-07 09:58:24 --> Controller Class Initialized
INFO - 2017-07-07 09:58:24 --> Database Driver Class Initialized
INFO - 2017-07-07 09:58:24 --> Model Class Initialized
INFO - 2017-07-07 09:58:24 --> Helper loaded: form_helper
INFO - 2017-07-07 09:58:24 --> Helper loaded: url_helper
INFO - 2017-07-07 09:58:24 --> Model Class Initialized
INFO - 2017-07-07 09:58:24 --> Final output sent to browser
DEBUG - 2017-07-07 09:58:24 --> Total execution time: 0.0800
ERROR - 2017-07-07 09:58:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 09:58:26 --> Config Class Initialized
INFO - 2017-07-07 09:58:26 --> Hooks Class Initialized
DEBUG - 2017-07-07 09:58:26 --> UTF-8 Support Enabled
INFO - 2017-07-07 09:58:26 --> Utf8 Class Initialized
INFO - 2017-07-07 09:58:26 --> URI Class Initialized
INFO - 2017-07-07 09:58:26 --> Router Class Initialized
INFO - 2017-07-07 09:58:26 --> Output Class Initialized
INFO - 2017-07-07 09:58:26 --> Security Class Initialized
DEBUG - 2017-07-07 09:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 09:58:26 --> Input Class Initialized
INFO - 2017-07-07 09:58:26 --> Language Class Initialized
INFO - 2017-07-07 09:58:26 --> Loader Class Initialized
INFO - 2017-07-07 09:58:26 --> Controller Class Initialized
INFO - 2017-07-07 09:58:26 --> Database Driver Class Initialized
INFO - 2017-07-07 09:58:26 --> Model Class Initialized
INFO - 2017-07-07 09:58:26 --> Helper loaded: form_helper
INFO - 2017-07-07 09:58:26 --> Helper loaded: url_helper
INFO - 2017-07-07 09:58:26 --> Model Class Initialized
INFO - 2017-07-07 09:58:26 --> Final output sent to browser
DEBUG - 2017-07-07 09:58:26 --> Total execution time: 0.1000
ERROR - 2017-07-07 16:56:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 16:56:49 --> Config Class Initialized
INFO - 2017-07-07 16:56:49 --> Hooks Class Initialized
DEBUG - 2017-07-07 16:56:49 --> UTF-8 Support Enabled
INFO - 2017-07-07 16:56:49 --> Utf8 Class Initialized
INFO - 2017-07-07 16:56:49 --> URI Class Initialized
INFO - 2017-07-07 16:56:49 --> Router Class Initialized
INFO - 2017-07-07 16:56:49 --> Output Class Initialized
INFO - 2017-07-07 16:56:49 --> Security Class Initialized
DEBUG - 2017-07-07 16:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 16:56:49 --> Input Class Initialized
INFO - 2017-07-07 16:56:49 --> Language Class Initialized
INFO - 2017-07-07 16:56:49 --> Loader Class Initialized
INFO - 2017-07-07 16:56:49 --> Controller Class Initialized
INFO - 2017-07-07 16:56:49 --> Database Driver Class Initialized
INFO - 2017-07-07 16:56:49 --> Model Class Initialized
INFO - 2017-07-07 16:56:49 --> Helper loaded: form_helper
INFO - 2017-07-07 16:56:49 --> Helper loaded: url_helper
INFO - 2017-07-07 16:56:49 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 16:56:49 --> Model Class Initialized
INFO - 2017-07-07 16:56:49 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-07 16:56:49 --> Final output sent to browser
DEBUG - 2017-07-07 16:56:49 --> Total execution time: 0.0670
ERROR - 2017-07-07 16:56:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 16:56:50 --> Config Class Initialized
INFO - 2017-07-07 16:56:50 --> Hooks Class Initialized
DEBUG - 2017-07-07 16:56:50 --> UTF-8 Support Enabled
INFO - 2017-07-07 16:56:50 --> Utf8 Class Initialized
INFO - 2017-07-07 16:56:50 --> URI Class Initialized
INFO - 2017-07-07 16:56:50 --> Router Class Initialized
INFO - 2017-07-07 16:56:50 --> Output Class Initialized
INFO - 2017-07-07 16:56:50 --> Security Class Initialized
DEBUG - 2017-07-07 16:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 16:56:50 --> Input Class Initialized
INFO - 2017-07-07 16:56:50 --> Language Class Initialized
INFO - 2017-07-07 16:56:50 --> Loader Class Initialized
INFO - 2017-07-07 16:56:50 --> Controller Class Initialized
INFO - 2017-07-07 16:56:50 --> Database Driver Class Initialized
INFO - 2017-07-07 16:56:50 --> Model Class Initialized
INFO - 2017-07-07 16:56:50 --> Helper loaded: form_helper
INFO - 2017-07-07 16:56:50 --> Helper loaded: url_helper
INFO - 2017-07-07 16:56:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 16:56:50 --> Model Class Initialized
INFO - 2017-07-07 16:56:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 16:56:50 --> Final output sent to browser
DEBUG - 2017-07-07 16:56:50 --> Total execution time: 0.0670
ERROR - 2017-07-07 16:57:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 16:57:03 --> Config Class Initialized
INFO - 2017-07-07 16:57:03 --> Hooks Class Initialized
DEBUG - 2017-07-07 16:57:03 --> UTF-8 Support Enabled
INFO - 2017-07-07 16:57:03 --> Utf8 Class Initialized
INFO - 2017-07-07 16:57:03 --> URI Class Initialized
INFO - 2017-07-07 16:57:03 --> Router Class Initialized
INFO - 2017-07-07 16:57:03 --> Output Class Initialized
INFO - 2017-07-07 16:57:03 --> Security Class Initialized
DEBUG - 2017-07-07 16:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 16:57:03 --> Input Class Initialized
INFO - 2017-07-07 16:57:03 --> Language Class Initialized
INFO - 2017-07-07 16:57:03 --> Loader Class Initialized
INFO - 2017-07-07 16:57:03 --> Controller Class Initialized
INFO - 2017-07-07 16:57:03 --> Database Driver Class Initialized
INFO - 2017-07-07 16:57:03 --> Model Class Initialized
INFO - 2017-07-07 16:57:03 --> Helper loaded: form_helper
INFO - 2017-07-07 16:57:03 --> Helper loaded: url_helper
INFO - 2017-07-07 16:57:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 16:57:03 --> Model Class Initialized
INFO - 2017-07-07 16:57:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-07 16:57:03 --> Final output sent to browser
DEBUG - 2017-07-07 16:57:03 --> Total execution time: 0.0580
ERROR - 2017-07-07 16:57:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 16:57:05 --> Config Class Initialized
INFO - 2017-07-07 16:57:05 --> Hooks Class Initialized
DEBUG - 2017-07-07 16:57:05 --> UTF-8 Support Enabled
INFO - 2017-07-07 16:57:05 --> Utf8 Class Initialized
INFO - 2017-07-07 16:57:05 --> URI Class Initialized
INFO - 2017-07-07 16:57:05 --> Router Class Initialized
INFO - 2017-07-07 16:57:05 --> Output Class Initialized
INFO - 2017-07-07 16:57:05 --> Security Class Initialized
DEBUG - 2017-07-07 16:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 16:57:05 --> Input Class Initialized
INFO - 2017-07-07 16:57:05 --> Language Class Initialized
INFO - 2017-07-07 16:57:05 --> Loader Class Initialized
INFO - 2017-07-07 16:57:05 --> Controller Class Initialized
INFO - 2017-07-07 16:57:05 --> Database Driver Class Initialized
INFO - 2017-07-07 16:57:05 --> Model Class Initialized
INFO - 2017-07-07 16:57:05 --> Helper loaded: form_helper
INFO - 2017-07-07 16:57:05 --> Helper loaded: url_helper
INFO - 2017-07-07 16:57:05 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 16:57:05 --> Model Class Initialized
INFO - 2017-07-07 16:57:05 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 16:57:05 --> Final output sent to browser
DEBUG - 2017-07-07 16:57:05 --> Total execution time: 0.1070
ERROR - 2017-07-07 16:57:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 16:57:51 --> Config Class Initialized
INFO - 2017-07-07 16:57:51 --> Hooks Class Initialized
DEBUG - 2017-07-07 16:57:51 --> UTF-8 Support Enabled
INFO - 2017-07-07 16:57:51 --> Utf8 Class Initialized
INFO - 2017-07-07 16:57:51 --> URI Class Initialized
INFO - 2017-07-07 16:57:51 --> Router Class Initialized
INFO - 2017-07-07 16:57:51 --> Output Class Initialized
INFO - 2017-07-07 16:57:51 --> Security Class Initialized
DEBUG - 2017-07-07 16:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 16:57:51 --> Input Class Initialized
INFO - 2017-07-07 16:57:51 --> Language Class Initialized
INFO - 2017-07-07 16:57:51 --> Loader Class Initialized
INFO - 2017-07-07 16:57:51 --> Controller Class Initialized
INFO - 2017-07-07 16:57:51 --> Database Driver Class Initialized
INFO - 2017-07-07 16:57:51 --> Model Class Initialized
INFO - 2017-07-07 16:57:51 --> Helper loaded: form_helper
INFO - 2017-07-07 16:57:51 --> Helper loaded: url_helper
INFO - 2017-07-07 16:57:51 --> Model Class Initialized
INFO - 2017-07-07 16:57:51 --> Final output sent to browser
DEBUG - 2017-07-07 16:57:51 --> Total execution time: 0.0900
ERROR - 2017-07-07 16:58:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 16:58:23 --> Config Class Initialized
INFO - 2017-07-07 16:58:23 --> Hooks Class Initialized
DEBUG - 2017-07-07 16:58:23 --> UTF-8 Support Enabled
INFO - 2017-07-07 16:58:23 --> Utf8 Class Initialized
INFO - 2017-07-07 16:58:23 --> URI Class Initialized
INFO - 2017-07-07 16:58:23 --> Router Class Initialized
INFO - 2017-07-07 16:58:23 --> Output Class Initialized
INFO - 2017-07-07 16:58:23 --> Security Class Initialized
DEBUG - 2017-07-07 16:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 16:58:23 --> Input Class Initialized
INFO - 2017-07-07 16:58:23 --> Language Class Initialized
INFO - 2017-07-07 16:58:23 --> Loader Class Initialized
INFO - 2017-07-07 16:58:23 --> Controller Class Initialized
INFO - 2017-07-07 16:58:23 --> Database Driver Class Initialized
INFO - 2017-07-07 16:58:23 --> Model Class Initialized
INFO - 2017-07-07 16:58:23 --> Helper loaded: form_helper
INFO - 2017-07-07 16:58:23 --> Helper loaded: url_helper
INFO - 2017-07-07 16:58:23 --> Model Class Initialized
INFO - 2017-07-07 16:58:23 --> Final output sent to browser
DEBUG - 2017-07-07 16:58:23 --> Total execution time: 0.0740
ERROR - 2017-07-07 16:59:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 16:59:41 --> Config Class Initialized
INFO - 2017-07-07 16:59:41 --> Hooks Class Initialized
DEBUG - 2017-07-07 16:59:41 --> UTF-8 Support Enabled
INFO - 2017-07-07 16:59:42 --> Utf8 Class Initialized
INFO - 2017-07-07 16:59:42 --> URI Class Initialized
INFO - 2017-07-07 16:59:42 --> Router Class Initialized
INFO - 2017-07-07 16:59:42 --> Output Class Initialized
INFO - 2017-07-07 16:59:42 --> Security Class Initialized
DEBUG - 2017-07-07 16:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 16:59:42 --> Input Class Initialized
INFO - 2017-07-07 16:59:42 --> Language Class Initialized
INFO - 2017-07-07 16:59:42 --> Loader Class Initialized
INFO - 2017-07-07 16:59:42 --> Controller Class Initialized
INFO - 2017-07-07 16:59:42 --> Database Driver Class Initialized
INFO - 2017-07-07 16:59:42 --> Model Class Initialized
INFO - 2017-07-07 16:59:42 --> Helper loaded: form_helper
INFO - 2017-07-07 16:59:42 --> Helper loaded: url_helper
INFO - 2017-07-07 16:59:42 --> Model Class Initialized
INFO - 2017-07-07 16:59:42 --> Final output sent to browser
DEBUG - 2017-07-07 16:59:42 --> Total execution time: 0.1000
ERROR - 2017-07-07 17:00:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:00:00 --> Config Class Initialized
INFO - 2017-07-07 17:00:00 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:00:00 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:00:00 --> Utf8 Class Initialized
INFO - 2017-07-07 17:00:00 --> URI Class Initialized
INFO - 2017-07-07 17:00:00 --> Router Class Initialized
INFO - 2017-07-07 17:00:00 --> Output Class Initialized
INFO - 2017-07-07 17:00:00 --> Security Class Initialized
DEBUG - 2017-07-07 17:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:00:00 --> Input Class Initialized
INFO - 2017-07-07 17:00:00 --> Language Class Initialized
INFO - 2017-07-07 17:00:00 --> Loader Class Initialized
INFO - 2017-07-07 17:00:00 --> Controller Class Initialized
INFO - 2017-07-07 17:00:00 --> Database Driver Class Initialized
INFO - 2017-07-07 17:00:00 --> Model Class Initialized
INFO - 2017-07-07 17:00:00 --> Helper loaded: form_helper
INFO - 2017-07-07 17:00:00 --> Helper loaded: url_helper
INFO - 2017-07-07 17:00:00 --> Model Class Initialized
INFO - 2017-07-07 17:00:01 --> Final output sent to browser
DEBUG - 2017-07-07 17:00:01 --> Total execution time: 0.4680
ERROR - 2017-07-07 17:00:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:00:07 --> Config Class Initialized
INFO - 2017-07-07 17:00:07 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:00:07 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:00:07 --> Utf8 Class Initialized
INFO - 2017-07-07 17:00:07 --> URI Class Initialized
INFO - 2017-07-07 17:00:07 --> Router Class Initialized
INFO - 2017-07-07 17:00:07 --> Output Class Initialized
INFO - 2017-07-07 17:00:07 --> Security Class Initialized
DEBUG - 2017-07-07 17:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:00:07 --> Input Class Initialized
INFO - 2017-07-07 17:00:07 --> Language Class Initialized
INFO - 2017-07-07 17:00:07 --> Loader Class Initialized
INFO - 2017-07-07 17:00:07 --> Controller Class Initialized
INFO - 2017-07-07 17:00:07 --> Database Driver Class Initialized
INFO - 2017-07-07 17:00:07 --> Model Class Initialized
INFO - 2017-07-07 17:00:07 --> Helper loaded: form_helper
INFO - 2017-07-07 17:00:07 --> Helper loaded: url_helper
INFO - 2017-07-07 17:00:07 --> Model Class Initialized
INFO - 2017-07-07 17:00:07 --> Final output sent to browser
DEBUG - 2017-07-07 17:00:07 --> Total execution time: 0.0940
ERROR - 2017-07-07 17:00:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:00:08 --> Config Class Initialized
INFO - 2017-07-07 17:00:08 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:00:08 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:00:08 --> Utf8 Class Initialized
INFO - 2017-07-07 17:00:08 --> URI Class Initialized
INFO - 2017-07-07 17:00:08 --> Router Class Initialized
INFO - 2017-07-07 17:00:08 --> Output Class Initialized
INFO - 2017-07-07 17:00:08 --> Security Class Initialized
DEBUG - 2017-07-07 17:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:00:08 --> Input Class Initialized
INFO - 2017-07-07 17:00:08 --> Language Class Initialized
INFO - 2017-07-07 17:00:08 --> Loader Class Initialized
INFO - 2017-07-07 17:00:08 --> Controller Class Initialized
INFO - 2017-07-07 17:00:08 --> Database Driver Class Initialized
INFO - 2017-07-07 17:00:08 --> Model Class Initialized
INFO - 2017-07-07 17:00:08 --> Helper loaded: form_helper
INFO - 2017-07-07 17:00:08 --> Helper loaded: url_helper
INFO - 2017-07-07 17:00:08 --> Model Class Initialized
INFO - 2017-07-07 17:00:08 --> Final output sent to browser
DEBUG - 2017-07-07 17:00:08 --> Total execution time: 0.1320
ERROR - 2017-07-07 17:02:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:02:16 --> Config Class Initialized
INFO - 2017-07-07 17:02:16 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:02:16 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:02:16 --> Utf8 Class Initialized
INFO - 2017-07-07 17:02:16 --> URI Class Initialized
INFO - 2017-07-07 17:02:16 --> Router Class Initialized
INFO - 2017-07-07 17:02:16 --> Output Class Initialized
INFO - 2017-07-07 17:02:16 --> Security Class Initialized
DEBUG - 2017-07-07 17:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:02:16 --> Input Class Initialized
INFO - 2017-07-07 17:02:16 --> Language Class Initialized
INFO - 2017-07-07 17:02:16 --> Loader Class Initialized
INFO - 2017-07-07 17:02:16 --> Controller Class Initialized
INFO - 2017-07-07 17:02:16 --> Database Driver Class Initialized
INFO - 2017-07-07 17:02:16 --> Model Class Initialized
INFO - 2017-07-07 17:02:16 --> Helper loaded: form_helper
INFO - 2017-07-07 17:02:16 --> Helper loaded: url_helper
INFO - 2017-07-07 17:02:16 --> Model Class Initialized
INFO - 2017-07-07 17:02:16 --> Final output sent to browser
DEBUG - 2017-07-07 17:02:16 --> Total execution time: 0.1290
ERROR - 2017-07-07 17:02:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:02:17 --> Config Class Initialized
INFO - 2017-07-07 17:02:17 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:02:17 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:02:17 --> Utf8 Class Initialized
INFO - 2017-07-07 17:02:17 --> URI Class Initialized
INFO - 2017-07-07 17:02:17 --> Router Class Initialized
INFO - 2017-07-07 17:02:17 --> Output Class Initialized
INFO - 2017-07-07 17:02:17 --> Security Class Initialized
DEBUG - 2017-07-07 17:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:02:17 --> Input Class Initialized
INFO - 2017-07-07 17:02:17 --> Language Class Initialized
INFO - 2017-07-07 17:02:17 --> Loader Class Initialized
INFO - 2017-07-07 17:02:17 --> Controller Class Initialized
INFO - 2017-07-07 17:02:17 --> Database Driver Class Initialized
INFO - 2017-07-07 17:02:17 --> Model Class Initialized
INFO - 2017-07-07 17:02:17 --> Helper loaded: form_helper
INFO - 2017-07-07 17:02:17 --> Helper loaded: url_helper
INFO - 2017-07-07 17:02:17 --> Model Class Initialized
INFO - 2017-07-07 17:02:17 --> Final output sent to browser
DEBUG - 2017-07-07 17:02:17 --> Total execution time: 0.0500
ERROR - 2017-07-07 17:04:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:04:00 --> Config Class Initialized
INFO - 2017-07-07 17:04:00 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:04:00 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:04:00 --> Utf8 Class Initialized
INFO - 2017-07-07 17:04:00 --> URI Class Initialized
INFO - 2017-07-07 17:04:00 --> Router Class Initialized
INFO - 2017-07-07 17:04:00 --> Output Class Initialized
INFO - 2017-07-07 17:04:00 --> Security Class Initialized
DEBUG - 2017-07-07 17:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:04:00 --> Input Class Initialized
INFO - 2017-07-07 17:04:00 --> Language Class Initialized
INFO - 2017-07-07 17:04:00 --> Loader Class Initialized
INFO - 2017-07-07 17:04:00 --> Controller Class Initialized
INFO - 2017-07-07 17:04:00 --> Database Driver Class Initialized
INFO - 2017-07-07 17:04:00 --> Model Class Initialized
INFO - 2017-07-07 17:04:00 --> Helper loaded: form_helper
INFO - 2017-07-07 17:04:00 --> Helper loaded: url_helper
INFO - 2017-07-07 17:04:00 --> Model Class Initialized
INFO - 2017-07-07 17:04:00 --> Final output sent to browser
DEBUG - 2017-07-07 17:04:00 --> Total execution time: 0.0610
ERROR - 2017-07-07 17:04:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:04:11 --> Config Class Initialized
INFO - 2017-07-07 17:04:11 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:04:11 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:04:11 --> Utf8 Class Initialized
INFO - 2017-07-07 17:04:11 --> URI Class Initialized
INFO - 2017-07-07 17:04:11 --> Router Class Initialized
INFO - 2017-07-07 17:04:11 --> Output Class Initialized
INFO - 2017-07-07 17:04:11 --> Security Class Initialized
DEBUG - 2017-07-07 17:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:04:11 --> Input Class Initialized
INFO - 2017-07-07 17:04:11 --> Language Class Initialized
INFO - 2017-07-07 17:04:11 --> Loader Class Initialized
INFO - 2017-07-07 17:04:11 --> Controller Class Initialized
INFO - 2017-07-07 17:04:11 --> Database Driver Class Initialized
INFO - 2017-07-07 17:04:11 --> Model Class Initialized
INFO - 2017-07-07 17:04:11 --> Helper loaded: form_helper
INFO - 2017-07-07 17:04:11 --> Helper loaded: url_helper
INFO - 2017-07-07 17:04:11 --> Model Class Initialized
INFO - 2017-07-07 17:04:11 --> Final output sent to browser
DEBUG - 2017-07-07 17:04:11 --> Total execution time: 0.1440
ERROR - 2017-07-07 17:04:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:04:23 --> Config Class Initialized
INFO - 2017-07-07 17:04:23 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:04:23 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:04:23 --> Utf8 Class Initialized
INFO - 2017-07-07 17:04:23 --> URI Class Initialized
INFO - 2017-07-07 17:04:23 --> Router Class Initialized
INFO - 2017-07-07 17:04:23 --> Output Class Initialized
INFO - 2017-07-07 17:04:23 --> Security Class Initialized
DEBUG - 2017-07-07 17:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:04:23 --> Input Class Initialized
INFO - 2017-07-07 17:04:23 --> Language Class Initialized
INFO - 2017-07-07 17:04:23 --> Loader Class Initialized
INFO - 2017-07-07 17:04:23 --> Controller Class Initialized
INFO - 2017-07-07 17:04:24 --> Database Driver Class Initialized
INFO - 2017-07-07 17:04:24 --> Model Class Initialized
INFO - 2017-07-07 17:04:24 --> Helper loaded: form_helper
INFO - 2017-07-07 17:04:24 --> Helper loaded: url_helper
INFO - 2017-07-07 17:04:24 --> Model Class Initialized
INFO - 2017-07-07 17:04:24 --> Final output sent to browser
DEBUG - 2017-07-07 17:04:24 --> Total execution time: 0.0590
ERROR - 2017-07-07 17:04:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:04:25 --> Config Class Initialized
INFO - 2017-07-07 17:04:25 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:04:25 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:04:25 --> Utf8 Class Initialized
INFO - 2017-07-07 17:04:25 --> URI Class Initialized
INFO - 2017-07-07 17:04:25 --> Router Class Initialized
INFO - 2017-07-07 17:04:25 --> Output Class Initialized
INFO - 2017-07-07 17:04:25 --> Security Class Initialized
DEBUG - 2017-07-07 17:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:04:25 --> Input Class Initialized
INFO - 2017-07-07 17:04:25 --> Language Class Initialized
INFO - 2017-07-07 17:04:25 --> Loader Class Initialized
INFO - 2017-07-07 17:04:25 --> Controller Class Initialized
INFO - 2017-07-07 17:04:25 --> Database Driver Class Initialized
INFO - 2017-07-07 17:04:25 --> Model Class Initialized
INFO - 2017-07-07 17:04:25 --> Helper loaded: form_helper
INFO - 2017-07-07 17:04:25 --> Helper loaded: url_helper
INFO - 2017-07-07 17:04:25 --> Model Class Initialized
INFO - 2017-07-07 17:04:25 --> Final output sent to browser
DEBUG - 2017-07-07 17:04:25 --> Total execution time: 0.1500
ERROR - 2017-07-07 17:05:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:05:45 --> Config Class Initialized
INFO - 2017-07-07 17:05:45 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:05:45 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:05:45 --> Utf8 Class Initialized
INFO - 2017-07-07 17:05:45 --> URI Class Initialized
INFO - 2017-07-07 17:05:45 --> Router Class Initialized
INFO - 2017-07-07 17:05:45 --> Output Class Initialized
INFO - 2017-07-07 17:05:45 --> Security Class Initialized
DEBUG - 2017-07-07 17:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:05:45 --> Input Class Initialized
INFO - 2017-07-07 17:05:45 --> Language Class Initialized
INFO - 2017-07-07 17:05:45 --> Loader Class Initialized
INFO - 2017-07-07 17:05:45 --> Controller Class Initialized
INFO - 2017-07-07 17:05:45 --> Database Driver Class Initialized
INFO - 2017-07-07 17:05:45 --> Model Class Initialized
INFO - 2017-07-07 17:05:45 --> Helper loaded: form_helper
INFO - 2017-07-07 17:05:45 --> Helper loaded: url_helper
INFO - 2017-07-07 17:05:45 --> Model Class Initialized
INFO - 2017-07-07 17:05:45 --> Final output sent to browser
DEBUG - 2017-07-07 17:05:45 --> Total execution time: 0.1280
ERROR - 2017-07-07 17:05:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:05:56 --> Config Class Initialized
INFO - 2017-07-07 17:05:56 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:05:56 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:05:56 --> Utf8 Class Initialized
INFO - 2017-07-07 17:05:56 --> URI Class Initialized
INFO - 2017-07-07 17:05:56 --> Router Class Initialized
INFO - 2017-07-07 17:05:56 --> Output Class Initialized
INFO - 2017-07-07 17:05:56 --> Security Class Initialized
DEBUG - 2017-07-07 17:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:05:56 --> Input Class Initialized
INFO - 2017-07-07 17:05:56 --> Language Class Initialized
INFO - 2017-07-07 17:05:56 --> Loader Class Initialized
INFO - 2017-07-07 17:05:56 --> Controller Class Initialized
INFO - 2017-07-07 17:05:56 --> Database Driver Class Initialized
INFO - 2017-07-07 17:05:56 --> Model Class Initialized
INFO - 2017-07-07 17:05:56 --> Helper loaded: form_helper
INFO - 2017-07-07 17:05:56 --> Helper loaded: url_helper
INFO - 2017-07-07 17:05:56 --> Model Class Initialized
INFO - 2017-07-07 17:05:56 --> Final output sent to browser
DEBUG - 2017-07-07 17:05:56 --> Total execution time: 0.1090
ERROR - 2017-07-07 17:06:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:06:50 --> Config Class Initialized
INFO - 2017-07-07 17:06:50 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:06:50 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:06:50 --> Utf8 Class Initialized
INFO - 2017-07-07 17:06:50 --> URI Class Initialized
INFO - 2017-07-07 17:06:50 --> Router Class Initialized
INFO - 2017-07-07 17:06:50 --> Output Class Initialized
INFO - 2017-07-07 17:06:50 --> Security Class Initialized
DEBUG - 2017-07-07 17:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:06:50 --> Input Class Initialized
INFO - 2017-07-07 17:06:50 --> Language Class Initialized
INFO - 2017-07-07 17:06:50 --> Loader Class Initialized
INFO - 2017-07-07 17:06:50 --> Controller Class Initialized
INFO - 2017-07-07 17:06:50 --> Database Driver Class Initialized
INFO - 2017-07-07 17:06:50 --> Model Class Initialized
INFO - 2017-07-07 17:06:50 --> Helper loaded: form_helper
INFO - 2017-07-07 17:06:50 --> Helper loaded: url_helper
INFO - 2017-07-07 17:06:50 --> Model Class Initialized
INFO - 2017-07-07 17:06:50 --> Final output sent to browser
DEBUG - 2017-07-07 17:06:50 --> Total execution time: 0.1120
ERROR - 2017-07-07 17:06:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:06:55 --> Config Class Initialized
INFO - 2017-07-07 17:06:55 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:06:55 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:06:55 --> Utf8 Class Initialized
INFO - 2017-07-07 17:06:55 --> URI Class Initialized
INFO - 2017-07-07 17:06:55 --> Router Class Initialized
INFO - 2017-07-07 17:06:55 --> Output Class Initialized
INFO - 2017-07-07 17:06:55 --> Security Class Initialized
DEBUG - 2017-07-07 17:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:06:55 --> Input Class Initialized
INFO - 2017-07-07 17:06:55 --> Language Class Initialized
INFO - 2017-07-07 17:06:55 --> Loader Class Initialized
INFO - 2017-07-07 17:06:55 --> Controller Class Initialized
INFO - 2017-07-07 17:06:55 --> Database Driver Class Initialized
INFO - 2017-07-07 17:06:55 --> Model Class Initialized
INFO - 2017-07-07 17:06:55 --> Helper loaded: form_helper
INFO - 2017-07-07 17:06:55 --> Helper loaded: url_helper
INFO - 2017-07-07 17:06:55 --> Model Class Initialized
INFO - 2017-07-07 17:06:55 --> Final output sent to browser
DEBUG - 2017-07-07 17:06:55 --> Total execution time: 0.1100
ERROR - 2017-07-07 17:06:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:06:57 --> Config Class Initialized
INFO - 2017-07-07 17:06:57 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:06:57 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:06:57 --> Utf8 Class Initialized
INFO - 2017-07-07 17:06:57 --> URI Class Initialized
INFO - 2017-07-07 17:06:57 --> Router Class Initialized
INFO - 2017-07-07 17:06:57 --> Output Class Initialized
INFO - 2017-07-07 17:06:57 --> Security Class Initialized
DEBUG - 2017-07-07 17:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:06:57 --> Input Class Initialized
INFO - 2017-07-07 17:06:57 --> Language Class Initialized
INFO - 2017-07-07 17:06:57 --> Loader Class Initialized
INFO - 2017-07-07 17:06:57 --> Controller Class Initialized
INFO - 2017-07-07 17:06:57 --> Database Driver Class Initialized
INFO - 2017-07-07 17:06:58 --> Model Class Initialized
INFO - 2017-07-07 17:06:58 --> Helper loaded: form_helper
INFO - 2017-07-07 17:06:58 --> Helper loaded: url_helper
INFO - 2017-07-07 17:06:58 --> Model Class Initialized
INFO - 2017-07-07 17:06:58 --> Final output sent to browser
DEBUG - 2017-07-07 17:06:58 --> Total execution time: 0.0640
ERROR - 2017-07-07 17:18:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:18:02 --> Config Class Initialized
INFO - 2017-07-07 17:18:02 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:18:02 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:18:02 --> Utf8 Class Initialized
INFO - 2017-07-07 17:18:02 --> URI Class Initialized
INFO - 2017-07-07 17:18:02 --> Router Class Initialized
INFO - 2017-07-07 17:18:02 --> Output Class Initialized
INFO - 2017-07-07 17:18:02 --> Security Class Initialized
DEBUG - 2017-07-07 17:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:18:02 --> Input Class Initialized
INFO - 2017-07-07 17:18:02 --> Language Class Initialized
INFO - 2017-07-07 17:18:02 --> Loader Class Initialized
INFO - 2017-07-07 17:18:02 --> Controller Class Initialized
INFO - 2017-07-07 17:18:02 --> Database Driver Class Initialized
INFO - 2017-07-07 17:18:02 --> Model Class Initialized
INFO - 2017-07-07 17:18:02 --> Helper loaded: form_helper
INFO - 2017-07-07 17:18:02 --> Helper loaded: url_helper
INFO - 2017-07-07 17:18:02 --> Model Class Initialized
INFO - 2017-07-07 17:18:02 --> Final output sent to browser
DEBUG - 2017-07-07 17:18:02 --> Total execution time: 0.1565
ERROR - 2017-07-07 17:21:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:21:10 --> Config Class Initialized
INFO - 2017-07-07 17:21:10 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:21:10 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:21:10 --> Utf8 Class Initialized
INFO - 2017-07-07 17:21:10 --> URI Class Initialized
INFO - 2017-07-07 17:21:10 --> Router Class Initialized
INFO - 2017-07-07 17:21:10 --> Output Class Initialized
INFO - 2017-07-07 17:21:10 --> Security Class Initialized
DEBUG - 2017-07-07 17:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:21:10 --> Input Class Initialized
INFO - 2017-07-07 17:21:10 --> Language Class Initialized
INFO - 2017-07-07 17:21:10 --> Loader Class Initialized
INFO - 2017-07-07 17:21:10 --> Controller Class Initialized
INFO - 2017-07-07 17:21:10 --> Database Driver Class Initialized
INFO - 2017-07-07 17:21:10 --> Model Class Initialized
INFO - 2017-07-07 17:21:10 --> Helper loaded: form_helper
INFO - 2017-07-07 17:21:10 --> Helper loaded: url_helper
INFO - 2017-07-07 17:21:10 --> Model Class Initialized
INFO - 2017-07-07 17:21:10 --> Final output sent to browser
DEBUG - 2017-07-07 17:21:10 --> Total execution time: 0.1990
ERROR - 2017-07-07 17:22:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:22:03 --> Config Class Initialized
INFO - 2017-07-07 17:22:03 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:22:03 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:22:03 --> Utf8 Class Initialized
INFO - 2017-07-07 17:22:03 --> URI Class Initialized
INFO - 2017-07-07 17:22:03 --> Router Class Initialized
INFO - 2017-07-07 17:22:03 --> Output Class Initialized
INFO - 2017-07-07 17:22:03 --> Security Class Initialized
DEBUG - 2017-07-07 17:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:22:03 --> Input Class Initialized
INFO - 2017-07-07 17:22:03 --> Language Class Initialized
INFO - 2017-07-07 17:22:03 --> Loader Class Initialized
INFO - 2017-07-07 17:22:03 --> Controller Class Initialized
INFO - 2017-07-07 17:22:03 --> Database Driver Class Initialized
INFO - 2017-07-07 17:22:03 --> Model Class Initialized
INFO - 2017-07-07 17:22:03 --> Helper loaded: form_helper
INFO - 2017-07-07 17:22:03 --> Helper loaded: url_helper
INFO - 2017-07-07 17:22:03 --> Model Class Initialized
INFO - 2017-07-07 17:22:03 --> Final output sent to browser
DEBUG - 2017-07-07 17:22:03 --> Total execution time: 0.1200
ERROR - 2017-07-07 17:22:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:22:52 --> Config Class Initialized
INFO - 2017-07-07 17:22:52 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:22:52 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:22:52 --> Utf8 Class Initialized
INFO - 2017-07-07 17:22:52 --> URI Class Initialized
INFO - 2017-07-07 17:22:52 --> Router Class Initialized
INFO - 2017-07-07 17:22:52 --> Output Class Initialized
INFO - 2017-07-07 17:22:52 --> Security Class Initialized
DEBUG - 2017-07-07 17:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:22:52 --> Input Class Initialized
INFO - 2017-07-07 17:22:52 --> Language Class Initialized
INFO - 2017-07-07 17:22:52 --> Loader Class Initialized
INFO - 2017-07-07 17:22:52 --> Controller Class Initialized
INFO - 2017-07-07 17:22:52 --> Database Driver Class Initialized
INFO - 2017-07-07 17:22:52 --> Model Class Initialized
INFO - 2017-07-07 17:22:52 --> Helper loaded: form_helper
INFO - 2017-07-07 17:22:52 --> Helper loaded: url_helper
INFO - 2017-07-07 17:22:52 --> Model Class Initialized
INFO - 2017-07-07 17:22:52 --> Final output sent to browser
DEBUG - 2017-07-07 17:22:52 --> Total execution time: 0.0665
ERROR - 2017-07-07 17:23:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:23:05 --> Config Class Initialized
INFO - 2017-07-07 17:23:05 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:23:05 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:23:05 --> Utf8 Class Initialized
INFO - 2017-07-07 17:23:05 --> URI Class Initialized
INFO - 2017-07-07 17:23:05 --> Router Class Initialized
INFO - 2017-07-07 17:23:05 --> Output Class Initialized
INFO - 2017-07-07 17:23:05 --> Security Class Initialized
DEBUG - 2017-07-07 17:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:23:05 --> Input Class Initialized
INFO - 2017-07-07 17:23:05 --> Language Class Initialized
INFO - 2017-07-07 17:23:05 --> Loader Class Initialized
INFO - 2017-07-07 17:23:05 --> Controller Class Initialized
INFO - 2017-07-07 17:23:05 --> Database Driver Class Initialized
INFO - 2017-07-07 17:23:05 --> Model Class Initialized
INFO - 2017-07-07 17:23:05 --> Helper loaded: form_helper
INFO - 2017-07-07 17:23:05 --> Helper loaded: url_helper
INFO - 2017-07-07 17:23:05 --> Model Class Initialized
INFO - 2017-07-07 17:23:05 --> Final output sent to browser
DEBUG - 2017-07-07 17:23:05 --> Total execution time: 0.3380
ERROR - 2017-07-07 17:23:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:23:12 --> Config Class Initialized
INFO - 2017-07-07 17:23:12 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:23:12 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:23:12 --> Utf8 Class Initialized
INFO - 2017-07-07 17:23:12 --> URI Class Initialized
INFO - 2017-07-07 17:23:12 --> Router Class Initialized
INFO - 2017-07-07 17:23:12 --> Output Class Initialized
INFO - 2017-07-07 17:23:12 --> Security Class Initialized
DEBUG - 2017-07-07 17:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:23:12 --> Input Class Initialized
INFO - 2017-07-07 17:23:12 --> Language Class Initialized
INFO - 2017-07-07 17:23:12 --> Loader Class Initialized
INFO - 2017-07-07 17:23:12 --> Controller Class Initialized
INFO - 2017-07-07 17:23:12 --> Database Driver Class Initialized
INFO - 2017-07-07 17:23:12 --> Model Class Initialized
INFO - 2017-07-07 17:23:12 --> Helper loaded: form_helper
INFO - 2017-07-07 17:23:12 --> Helper loaded: url_helper
INFO - 2017-07-07 17:23:12 --> Model Class Initialized
INFO - 2017-07-07 17:23:13 --> Final output sent to browser
DEBUG - 2017-07-07 17:23:13 --> Total execution time: 0.3840
ERROR - 2017-07-07 17:34:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:34:07 --> Config Class Initialized
INFO - 2017-07-07 17:34:07 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:34:07 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:34:07 --> Utf8 Class Initialized
INFO - 2017-07-07 17:34:07 --> URI Class Initialized
INFO - 2017-07-07 17:34:07 --> Router Class Initialized
INFO - 2017-07-07 17:34:07 --> Output Class Initialized
INFO - 2017-07-07 17:34:07 --> Security Class Initialized
DEBUG - 2017-07-07 17:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:34:07 --> Input Class Initialized
INFO - 2017-07-07 17:34:07 --> Language Class Initialized
INFO - 2017-07-07 17:34:07 --> Loader Class Initialized
INFO - 2017-07-07 17:34:07 --> Controller Class Initialized
INFO - 2017-07-07 17:34:07 --> Database Driver Class Initialized
INFO - 2017-07-07 17:34:07 --> Model Class Initialized
INFO - 2017-07-07 17:34:07 --> Helper loaded: form_helper
INFO - 2017-07-07 17:34:07 --> Helper loaded: url_helper
INFO - 2017-07-07 17:34:07 --> Model Class Initialized
INFO - 2017-07-07 17:34:07 --> Final output sent to browser
DEBUG - 2017-07-07 17:34:07 --> Total execution time: 0.1240
ERROR - 2017-07-07 17:34:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:34:56 --> Config Class Initialized
INFO - 2017-07-07 17:34:56 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:34:56 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:34:56 --> Utf8 Class Initialized
INFO - 2017-07-07 17:34:56 --> URI Class Initialized
INFO - 2017-07-07 17:34:56 --> Router Class Initialized
INFO - 2017-07-07 17:34:56 --> Output Class Initialized
INFO - 2017-07-07 17:34:56 --> Security Class Initialized
DEBUG - 2017-07-07 17:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:34:56 --> Input Class Initialized
INFO - 2017-07-07 17:34:56 --> Language Class Initialized
INFO - 2017-07-07 17:34:56 --> Loader Class Initialized
INFO - 2017-07-07 17:34:56 --> Controller Class Initialized
INFO - 2017-07-07 17:34:56 --> Database Driver Class Initialized
INFO - 2017-07-07 17:34:56 --> Model Class Initialized
INFO - 2017-07-07 17:34:56 --> Helper loaded: form_helper
INFO - 2017-07-07 17:34:56 --> Helper loaded: url_helper
INFO - 2017-07-07 17:34:56 --> Model Class Initialized
INFO - 2017-07-07 17:34:56 --> Final output sent to browser
DEBUG - 2017-07-07 17:34:56 --> Total execution time: 0.0700
ERROR - 2017-07-07 17:36:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:36:46 --> Config Class Initialized
INFO - 2017-07-07 17:36:46 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:36:46 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:36:46 --> Utf8 Class Initialized
INFO - 2017-07-07 17:36:46 --> URI Class Initialized
INFO - 2017-07-07 17:36:46 --> Router Class Initialized
INFO - 2017-07-07 17:36:46 --> Output Class Initialized
INFO - 2017-07-07 17:36:46 --> Security Class Initialized
DEBUG - 2017-07-07 17:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:36:46 --> Input Class Initialized
INFO - 2017-07-07 17:36:46 --> Language Class Initialized
INFO - 2017-07-07 17:36:46 --> Loader Class Initialized
INFO - 2017-07-07 17:36:46 --> Controller Class Initialized
INFO - 2017-07-07 17:36:46 --> Database Driver Class Initialized
INFO - 2017-07-07 17:36:46 --> Model Class Initialized
INFO - 2017-07-07 17:36:46 --> Helper loaded: form_helper
INFO - 2017-07-07 17:36:46 --> Helper loaded: url_helper
INFO - 2017-07-07 17:36:46 --> Model Class Initialized
INFO - 2017-07-07 17:36:46 --> Final output sent to browser
DEBUG - 2017-07-07 17:36:46 --> Total execution time: 0.2110
ERROR - 2017-07-07 17:36:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:36:47 --> Config Class Initialized
INFO - 2017-07-07 17:36:47 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:36:47 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:36:47 --> Utf8 Class Initialized
INFO - 2017-07-07 17:36:47 --> URI Class Initialized
INFO - 2017-07-07 17:36:47 --> Router Class Initialized
INFO - 2017-07-07 17:36:47 --> Output Class Initialized
INFO - 2017-07-07 17:36:47 --> Security Class Initialized
DEBUG - 2017-07-07 17:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:36:47 --> Input Class Initialized
INFO - 2017-07-07 17:36:47 --> Language Class Initialized
INFO - 2017-07-07 17:36:47 --> Loader Class Initialized
INFO - 2017-07-07 17:36:47 --> Controller Class Initialized
INFO - 2017-07-07 17:36:47 --> Database Driver Class Initialized
INFO - 2017-07-07 17:36:47 --> Model Class Initialized
INFO - 2017-07-07 17:36:47 --> Helper loaded: form_helper
INFO - 2017-07-07 17:36:47 --> Helper loaded: url_helper
INFO - 2017-07-07 17:36:47 --> Model Class Initialized
INFO - 2017-07-07 17:36:47 --> Final output sent to browser
DEBUG - 2017-07-07 17:36:47 --> Total execution time: 0.0910
ERROR - 2017-07-07 17:38:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:38:05 --> Config Class Initialized
INFO - 2017-07-07 17:38:05 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:38:05 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:38:05 --> Utf8 Class Initialized
INFO - 2017-07-07 17:38:05 --> URI Class Initialized
INFO - 2017-07-07 17:38:05 --> Router Class Initialized
INFO - 2017-07-07 17:38:05 --> Output Class Initialized
INFO - 2017-07-07 17:38:05 --> Security Class Initialized
DEBUG - 2017-07-07 17:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:38:05 --> Input Class Initialized
INFO - 2017-07-07 17:38:05 --> Language Class Initialized
INFO - 2017-07-07 17:38:05 --> Loader Class Initialized
INFO - 2017-07-07 17:38:05 --> Controller Class Initialized
INFO - 2017-07-07 17:38:05 --> Database Driver Class Initialized
INFO - 2017-07-07 17:38:05 --> Model Class Initialized
INFO - 2017-07-07 17:38:05 --> Helper loaded: form_helper
INFO - 2017-07-07 17:38:05 --> Helper loaded: url_helper
INFO - 2017-07-07 17:38:05 --> Model Class Initialized
INFO - 2017-07-07 17:38:05 --> Final output sent to browser
DEBUG - 2017-07-07 17:38:05 --> Total execution time: 0.0970
ERROR - 2017-07-07 17:38:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:38:18 --> Config Class Initialized
INFO - 2017-07-07 17:38:18 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:38:18 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:38:18 --> Utf8 Class Initialized
INFO - 2017-07-07 17:38:18 --> URI Class Initialized
INFO - 2017-07-07 17:38:18 --> Router Class Initialized
INFO - 2017-07-07 17:38:18 --> Output Class Initialized
INFO - 2017-07-07 17:38:18 --> Security Class Initialized
DEBUG - 2017-07-07 17:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:38:18 --> Input Class Initialized
INFO - 2017-07-07 17:38:18 --> Language Class Initialized
INFO - 2017-07-07 17:38:18 --> Loader Class Initialized
INFO - 2017-07-07 17:38:18 --> Controller Class Initialized
INFO - 2017-07-07 17:38:18 --> Database Driver Class Initialized
INFO - 2017-07-07 17:38:18 --> Model Class Initialized
INFO - 2017-07-07 17:38:18 --> Helper loaded: form_helper
INFO - 2017-07-07 17:38:18 --> Helper loaded: url_helper
INFO - 2017-07-07 17:38:18 --> Model Class Initialized
INFO - 2017-07-07 17:38:18 --> Final output sent to browser
DEBUG - 2017-07-07 17:38:18 --> Total execution time: 0.0895
ERROR - 2017-07-07 17:39:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:39:39 --> Config Class Initialized
INFO - 2017-07-07 17:39:39 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:39:39 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:39:39 --> Utf8 Class Initialized
INFO - 2017-07-07 17:39:39 --> URI Class Initialized
INFO - 2017-07-07 17:39:39 --> Router Class Initialized
INFO - 2017-07-07 17:39:39 --> Output Class Initialized
INFO - 2017-07-07 17:39:39 --> Security Class Initialized
DEBUG - 2017-07-07 17:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:39:39 --> Input Class Initialized
INFO - 2017-07-07 17:39:39 --> Language Class Initialized
INFO - 2017-07-07 17:39:39 --> Loader Class Initialized
INFO - 2017-07-07 17:39:39 --> Controller Class Initialized
INFO - 2017-07-07 17:39:39 --> Database Driver Class Initialized
INFO - 2017-07-07 17:39:39 --> Model Class Initialized
INFO - 2017-07-07 17:39:39 --> Helper loaded: form_helper
INFO - 2017-07-07 17:39:39 --> Helper loaded: url_helper
INFO - 2017-07-07 17:39:39 --> Model Class Initialized
INFO - 2017-07-07 17:39:39 --> Final output sent to browser
DEBUG - 2017-07-07 17:39:39 --> Total execution time: 0.1130
ERROR - 2017-07-07 17:39:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:39:53 --> Config Class Initialized
INFO - 2017-07-07 17:39:53 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:39:53 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:39:53 --> Utf8 Class Initialized
INFO - 2017-07-07 17:39:53 --> URI Class Initialized
INFO - 2017-07-07 17:39:53 --> Router Class Initialized
INFO - 2017-07-07 17:39:53 --> Output Class Initialized
INFO - 2017-07-07 17:39:53 --> Security Class Initialized
DEBUG - 2017-07-07 17:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:39:53 --> Input Class Initialized
INFO - 2017-07-07 17:39:53 --> Language Class Initialized
INFO - 2017-07-07 17:39:53 --> Loader Class Initialized
INFO - 2017-07-07 17:39:53 --> Controller Class Initialized
INFO - 2017-07-07 17:39:53 --> Database Driver Class Initialized
INFO - 2017-07-07 17:39:53 --> Model Class Initialized
INFO - 2017-07-07 17:39:53 --> Helper loaded: form_helper
INFO - 2017-07-07 17:39:53 --> Helper loaded: url_helper
INFO - 2017-07-07 17:39:53 --> Model Class Initialized
INFO - 2017-07-07 17:39:53 --> Final output sent to browser
DEBUG - 2017-07-07 17:39:53 --> Total execution time: 0.0500
ERROR - 2017-07-07 17:40:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:40:09 --> Config Class Initialized
INFO - 2017-07-07 17:40:09 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:40:09 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:40:09 --> Utf8 Class Initialized
INFO - 2017-07-07 17:40:09 --> URI Class Initialized
INFO - 2017-07-07 17:40:09 --> Router Class Initialized
INFO - 2017-07-07 17:40:09 --> Output Class Initialized
INFO - 2017-07-07 17:40:09 --> Security Class Initialized
DEBUG - 2017-07-07 17:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:40:09 --> Input Class Initialized
INFO - 2017-07-07 17:40:09 --> Language Class Initialized
INFO - 2017-07-07 17:40:09 --> Loader Class Initialized
INFO - 2017-07-07 17:40:09 --> Controller Class Initialized
INFO - 2017-07-07 17:40:09 --> Database Driver Class Initialized
INFO - 2017-07-07 17:40:09 --> Model Class Initialized
INFO - 2017-07-07 17:40:09 --> Helper loaded: form_helper
INFO - 2017-07-07 17:40:09 --> Helper loaded: url_helper
INFO - 2017-07-07 17:40:09 --> Model Class Initialized
INFO - 2017-07-07 17:40:09 --> Final output sent to browser
DEBUG - 2017-07-07 17:40:09 --> Total execution time: 0.0510
ERROR - 2017-07-07 17:40:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:40:10 --> Config Class Initialized
INFO - 2017-07-07 17:40:10 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:40:10 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:40:10 --> Utf8 Class Initialized
INFO - 2017-07-07 17:40:10 --> URI Class Initialized
INFO - 2017-07-07 17:40:10 --> Router Class Initialized
INFO - 2017-07-07 17:40:10 --> Output Class Initialized
INFO - 2017-07-07 17:40:10 --> Security Class Initialized
DEBUG - 2017-07-07 17:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:40:10 --> Input Class Initialized
INFO - 2017-07-07 17:40:10 --> Language Class Initialized
INFO - 2017-07-07 17:40:10 --> Loader Class Initialized
INFO - 2017-07-07 17:40:10 --> Controller Class Initialized
INFO - 2017-07-07 17:40:10 --> Database Driver Class Initialized
INFO - 2017-07-07 17:40:10 --> Model Class Initialized
INFO - 2017-07-07 17:40:10 --> Helper loaded: form_helper
INFO - 2017-07-07 17:40:10 --> Helper loaded: url_helper
INFO - 2017-07-07 17:40:10 --> Model Class Initialized
INFO - 2017-07-07 17:40:10 --> Final output sent to browser
DEBUG - 2017-07-07 17:40:10 --> Total execution time: 0.0500
ERROR - 2017-07-07 17:41:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:41:57 --> Config Class Initialized
INFO - 2017-07-07 17:41:57 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:41:57 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:41:57 --> Utf8 Class Initialized
INFO - 2017-07-07 17:41:57 --> URI Class Initialized
INFO - 2017-07-07 17:41:57 --> Router Class Initialized
INFO - 2017-07-07 17:41:57 --> Output Class Initialized
INFO - 2017-07-07 17:41:57 --> Security Class Initialized
DEBUG - 2017-07-07 17:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:41:57 --> Input Class Initialized
INFO - 2017-07-07 17:41:57 --> Language Class Initialized
INFO - 2017-07-07 17:41:57 --> Loader Class Initialized
INFO - 2017-07-07 17:41:57 --> Controller Class Initialized
INFO - 2017-07-07 17:41:57 --> Database Driver Class Initialized
INFO - 2017-07-07 17:41:57 --> Model Class Initialized
INFO - 2017-07-07 17:41:57 --> Helper loaded: form_helper
INFO - 2017-07-07 17:41:57 --> Helper loaded: url_helper
INFO - 2017-07-07 17:41:57 --> Model Class Initialized
INFO - 2017-07-07 17:41:58 --> Final output sent to browser
DEBUG - 2017-07-07 17:41:58 --> Total execution time: 0.1220
ERROR - 2017-07-07 17:42:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:42:03 --> Config Class Initialized
INFO - 2017-07-07 17:42:03 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:42:03 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:42:03 --> Utf8 Class Initialized
INFO - 2017-07-07 17:42:03 --> URI Class Initialized
INFO - 2017-07-07 17:42:03 --> Router Class Initialized
INFO - 2017-07-07 17:42:03 --> Output Class Initialized
INFO - 2017-07-07 17:42:03 --> Security Class Initialized
DEBUG - 2017-07-07 17:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:42:03 --> Input Class Initialized
INFO - 2017-07-07 17:42:03 --> Language Class Initialized
INFO - 2017-07-07 17:42:03 --> Loader Class Initialized
INFO - 2017-07-07 17:42:03 --> Controller Class Initialized
INFO - 2017-07-07 17:42:03 --> Database Driver Class Initialized
INFO - 2017-07-07 17:42:03 --> Model Class Initialized
INFO - 2017-07-07 17:42:03 --> Helper loaded: form_helper
INFO - 2017-07-07 17:42:03 --> Helper loaded: url_helper
INFO - 2017-07-07 17:42:03 --> Model Class Initialized
INFO - 2017-07-07 17:42:03 --> Final output sent to browser
DEBUG - 2017-07-07 17:42:03 --> Total execution time: 0.1115
ERROR - 2017-07-07 17:42:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:42:04 --> Config Class Initialized
INFO - 2017-07-07 17:42:04 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:42:04 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:42:04 --> Utf8 Class Initialized
INFO - 2017-07-07 17:42:04 --> URI Class Initialized
INFO - 2017-07-07 17:42:04 --> Router Class Initialized
INFO - 2017-07-07 17:42:04 --> Output Class Initialized
INFO - 2017-07-07 17:42:04 --> Security Class Initialized
DEBUG - 2017-07-07 17:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:42:04 --> Input Class Initialized
INFO - 2017-07-07 17:42:04 --> Language Class Initialized
INFO - 2017-07-07 17:42:04 --> Loader Class Initialized
INFO - 2017-07-07 17:42:04 --> Controller Class Initialized
INFO - 2017-07-07 17:42:04 --> Database Driver Class Initialized
INFO - 2017-07-07 17:42:04 --> Model Class Initialized
INFO - 2017-07-07 17:42:04 --> Helper loaded: form_helper
INFO - 2017-07-07 17:42:04 --> Helper loaded: url_helper
INFO - 2017-07-07 17:42:04 --> Model Class Initialized
INFO - 2017-07-07 17:42:04 --> Final output sent to browser
DEBUG - 2017-07-07 17:42:04 --> Total execution time: 0.1510
ERROR - 2017-07-07 17:44:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:44:48 --> Config Class Initialized
INFO - 2017-07-07 17:44:48 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:44:48 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:44:48 --> Utf8 Class Initialized
INFO - 2017-07-07 17:44:48 --> URI Class Initialized
INFO - 2017-07-07 17:44:48 --> Router Class Initialized
INFO - 2017-07-07 17:44:48 --> Output Class Initialized
INFO - 2017-07-07 17:44:48 --> Security Class Initialized
DEBUG - 2017-07-07 17:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:44:48 --> Input Class Initialized
INFO - 2017-07-07 17:44:48 --> Language Class Initialized
INFO - 2017-07-07 17:44:48 --> Loader Class Initialized
INFO - 2017-07-07 17:44:48 --> Controller Class Initialized
INFO - 2017-07-07 17:44:48 --> Database Driver Class Initialized
INFO - 2017-07-07 17:44:48 --> Model Class Initialized
INFO - 2017-07-07 17:44:48 --> Helper loaded: form_helper
INFO - 2017-07-07 17:44:48 --> Helper loaded: url_helper
INFO - 2017-07-07 17:44:48 --> Model Class Initialized
INFO - 2017-07-07 17:44:48 --> Final output sent to browser
DEBUG - 2017-07-07 17:44:48 --> Total execution time: 0.1140
ERROR - 2017-07-07 17:44:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:44:52 --> Config Class Initialized
INFO - 2017-07-07 17:44:52 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:44:52 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:44:52 --> Utf8 Class Initialized
INFO - 2017-07-07 17:44:52 --> URI Class Initialized
INFO - 2017-07-07 17:44:52 --> Router Class Initialized
INFO - 2017-07-07 17:44:52 --> Output Class Initialized
INFO - 2017-07-07 17:44:52 --> Security Class Initialized
DEBUG - 2017-07-07 17:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:44:52 --> Input Class Initialized
INFO - 2017-07-07 17:44:52 --> Language Class Initialized
INFO - 2017-07-07 17:44:52 --> Loader Class Initialized
INFO - 2017-07-07 17:44:52 --> Controller Class Initialized
INFO - 2017-07-07 17:44:52 --> Database Driver Class Initialized
INFO - 2017-07-07 17:44:52 --> Model Class Initialized
INFO - 2017-07-07 17:44:52 --> Helper loaded: form_helper
INFO - 2017-07-07 17:44:52 --> Helper loaded: url_helper
INFO - 2017-07-07 17:44:52 --> Model Class Initialized
INFO - 2017-07-07 17:44:53 --> Final output sent to browser
DEBUG - 2017-07-07 17:44:53 --> Total execution time: 0.6225
ERROR - 2017-07-07 17:45:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:45:17 --> Config Class Initialized
INFO - 2017-07-07 17:45:17 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:45:17 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:45:17 --> Utf8 Class Initialized
INFO - 2017-07-07 17:45:17 --> URI Class Initialized
INFO - 2017-07-07 17:45:17 --> Router Class Initialized
INFO - 2017-07-07 17:45:17 --> Output Class Initialized
INFO - 2017-07-07 17:45:17 --> Security Class Initialized
DEBUG - 2017-07-07 17:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:45:17 --> Input Class Initialized
INFO - 2017-07-07 17:45:17 --> Language Class Initialized
INFO - 2017-07-07 17:45:17 --> Loader Class Initialized
INFO - 2017-07-07 17:45:17 --> Controller Class Initialized
INFO - 2017-07-07 17:45:17 --> Database Driver Class Initialized
INFO - 2017-07-07 17:45:17 --> Model Class Initialized
INFO - 2017-07-07 17:45:17 --> Helper loaded: form_helper
INFO - 2017-07-07 17:45:17 --> Helper loaded: url_helper
INFO - 2017-07-07 17:45:17 --> Model Class Initialized
INFO - 2017-07-07 17:45:17 --> Final output sent to browser
DEBUG - 2017-07-07 17:45:17 --> Total execution time: 0.1760
ERROR - 2017-07-07 17:45:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:45:18 --> Config Class Initialized
INFO - 2017-07-07 17:45:18 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:45:18 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:45:18 --> Utf8 Class Initialized
INFO - 2017-07-07 17:45:18 --> URI Class Initialized
INFO - 2017-07-07 17:45:18 --> Router Class Initialized
INFO - 2017-07-07 17:45:18 --> Output Class Initialized
INFO - 2017-07-07 17:45:18 --> Security Class Initialized
DEBUG - 2017-07-07 17:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:45:18 --> Input Class Initialized
INFO - 2017-07-07 17:45:18 --> Language Class Initialized
INFO - 2017-07-07 17:45:18 --> Loader Class Initialized
INFO - 2017-07-07 17:45:18 --> Controller Class Initialized
INFO - 2017-07-07 17:45:18 --> Database Driver Class Initialized
INFO - 2017-07-07 17:45:18 --> Model Class Initialized
INFO - 2017-07-07 17:45:18 --> Helper loaded: form_helper
INFO - 2017-07-07 17:45:18 --> Helper loaded: url_helper
INFO - 2017-07-07 17:45:18 --> Model Class Initialized
INFO - 2017-07-07 17:45:18 --> Final output sent to browser
DEBUG - 2017-07-07 17:45:18 --> Total execution time: 0.0890
ERROR - 2017-07-07 17:45:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:45:20 --> Config Class Initialized
INFO - 2017-07-07 17:45:20 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:45:20 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:45:20 --> Utf8 Class Initialized
INFO - 2017-07-07 17:45:20 --> URI Class Initialized
INFO - 2017-07-07 17:45:20 --> Router Class Initialized
INFO - 2017-07-07 17:45:20 --> Output Class Initialized
INFO - 2017-07-07 17:45:20 --> Security Class Initialized
DEBUG - 2017-07-07 17:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:45:20 --> Input Class Initialized
INFO - 2017-07-07 17:45:20 --> Language Class Initialized
INFO - 2017-07-07 17:45:20 --> Loader Class Initialized
INFO - 2017-07-07 17:45:20 --> Controller Class Initialized
INFO - 2017-07-07 17:45:20 --> Database Driver Class Initialized
INFO - 2017-07-07 17:45:20 --> Model Class Initialized
INFO - 2017-07-07 17:45:20 --> Helper loaded: form_helper
INFO - 2017-07-07 17:45:20 --> Helper loaded: url_helper
INFO - 2017-07-07 17:45:20 --> Model Class Initialized
INFO - 2017-07-07 17:45:20 --> Final output sent to browser
DEBUG - 2017-07-07 17:45:20 --> Total execution time: 0.1120
ERROR - 2017-07-07 17:48:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:48:21 --> Config Class Initialized
INFO - 2017-07-07 17:48:21 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:48:21 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:48:21 --> Utf8 Class Initialized
INFO - 2017-07-07 17:48:21 --> URI Class Initialized
INFO - 2017-07-07 17:48:21 --> Router Class Initialized
INFO - 2017-07-07 17:48:21 --> Output Class Initialized
INFO - 2017-07-07 17:48:21 --> Security Class Initialized
DEBUG - 2017-07-07 17:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:48:21 --> Input Class Initialized
INFO - 2017-07-07 17:48:21 --> Language Class Initialized
INFO - 2017-07-07 17:48:21 --> Loader Class Initialized
INFO - 2017-07-07 17:48:21 --> Controller Class Initialized
INFO - 2017-07-07 17:48:21 --> Database Driver Class Initialized
INFO - 2017-07-07 17:48:21 --> Model Class Initialized
INFO - 2017-07-07 17:48:21 --> Helper loaded: form_helper
INFO - 2017-07-07 17:48:21 --> Helper loaded: url_helper
INFO - 2017-07-07 17:48:21 --> Model Class Initialized
INFO - 2017-07-07 17:48:21 --> Final output sent to browser
DEBUG - 2017-07-07 17:48:21 --> Total execution time: 0.2040
ERROR - 2017-07-07 17:48:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:48:23 --> Config Class Initialized
INFO - 2017-07-07 17:48:23 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:48:23 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:48:23 --> Utf8 Class Initialized
INFO - 2017-07-07 17:48:23 --> URI Class Initialized
INFO - 2017-07-07 17:48:23 --> Router Class Initialized
INFO - 2017-07-07 17:48:23 --> Output Class Initialized
INFO - 2017-07-07 17:48:23 --> Security Class Initialized
DEBUG - 2017-07-07 17:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:48:23 --> Input Class Initialized
INFO - 2017-07-07 17:48:23 --> Language Class Initialized
INFO - 2017-07-07 17:48:23 --> Loader Class Initialized
INFO - 2017-07-07 17:48:23 --> Controller Class Initialized
INFO - 2017-07-07 17:48:23 --> Database Driver Class Initialized
INFO - 2017-07-07 17:48:23 --> Model Class Initialized
INFO - 2017-07-07 17:48:23 --> Helper loaded: form_helper
INFO - 2017-07-07 17:48:23 --> Helper loaded: url_helper
INFO - 2017-07-07 17:48:23 --> Model Class Initialized
INFO - 2017-07-07 17:48:23 --> Final output sent to browser
DEBUG - 2017-07-07 17:48:23 --> Total execution time: 0.0650
ERROR - 2017-07-07 17:48:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:48:30 --> Config Class Initialized
INFO - 2017-07-07 17:48:30 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:48:30 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:48:30 --> Utf8 Class Initialized
INFO - 2017-07-07 17:48:30 --> URI Class Initialized
INFO - 2017-07-07 17:48:30 --> Router Class Initialized
INFO - 2017-07-07 17:48:30 --> Output Class Initialized
INFO - 2017-07-07 17:48:30 --> Security Class Initialized
DEBUG - 2017-07-07 17:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:48:30 --> Input Class Initialized
INFO - 2017-07-07 17:48:30 --> Language Class Initialized
INFO - 2017-07-07 17:48:30 --> Loader Class Initialized
INFO - 2017-07-07 17:48:30 --> Controller Class Initialized
INFO - 2017-07-07 17:48:30 --> Database Driver Class Initialized
INFO - 2017-07-07 17:48:30 --> Model Class Initialized
INFO - 2017-07-07 17:48:30 --> Helper loaded: form_helper
INFO - 2017-07-07 17:48:30 --> Helper loaded: url_helper
INFO - 2017-07-07 17:48:30 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 17:48:30 --> Model Class Initialized
INFO - 2017-07-07 17:48:30 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-07 17:48:30 --> Final output sent to browser
DEBUG - 2017-07-07 17:48:30 --> Total execution time: 0.0820
ERROR - 2017-07-07 17:48:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:48:32 --> Config Class Initialized
INFO - 2017-07-07 17:48:32 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:48:32 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:48:32 --> Utf8 Class Initialized
INFO - 2017-07-07 17:48:32 --> URI Class Initialized
INFO - 2017-07-07 17:48:32 --> Router Class Initialized
INFO - 2017-07-07 17:48:32 --> Output Class Initialized
INFO - 2017-07-07 17:48:32 --> Security Class Initialized
DEBUG - 2017-07-07 17:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:48:32 --> Input Class Initialized
INFO - 2017-07-07 17:48:32 --> Language Class Initialized
INFO - 2017-07-07 17:48:32 --> Loader Class Initialized
INFO - 2017-07-07 17:48:32 --> Controller Class Initialized
INFO - 2017-07-07 17:48:32 --> Database Driver Class Initialized
INFO - 2017-07-07 17:48:32 --> Model Class Initialized
INFO - 2017-07-07 17:48:32 --> Helper loaded: form_helper
INFO - 2017-07-07 17:48:32 --> Helper loaded: url_helper
INFO - 2017-07-07 17:48:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 17:48:32 --> Model Class Initialized
INFO - 2017-07-07 17:48:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 17:48:32 --> Final output sent to browser
DEBUG - 2017-07-07 17:48:32 --> Total execution time: 0.0990
ERROR - 2017-07-07 17:48:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:48:35 --> Config Class Initialized
INFO - 2017-07-07 17:48:35 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:48:35 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:48:35 --> Utf8 Class Initialized
INFO - 2017-07-07 17:48:35 --> URI Class Initialized
INFO - 2017-07-07 17:48:35 --> Router Class Initialized
INFO - 2017-07-07 17:48:35 --> Output Class Initialized
INFO - 2017-07-07 17:48:35 --> Security Class Initialized
DEBUG - 2017-07-07 17:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:48:35 --> Input Class Initialized
INFO - 2017-07-07 17:48:35 --> Language Class Initialized
INFO - 2017-07-07 17:48:35 --> Loader Class Initialized
INFO - 2017-07-07 17:48:35 --> Controller Class Initialized
INFO - 2017-07-07 17:48:35 --> Database Driver Class Initialized
INFO - 2017-07-07 17:48:35 --> Model Class Initialized
INFO - 2017-07-07 17:48:35 --> Helper loaded: form_helper
INFO - 2017-07-07 17:48:35 --> Helper loaded: url_helper
INFO - 2017-07-07 17:48:35 --> Model Class Initialized
INFO - 2017-07-07 17:48:35 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 17:48:35 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 17:48:35 --> Final output sent to browser
DEBUG - 2017-07-07 17:48:35 --> Total execution time: 0.1310
ERROR - 2017-07-07 17:48:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:48:38 --> Config Class Initialized
INFO - 2017-07-07 17:48:38 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:48:38 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:48:38 --> Utf8 Class Initialized
INFO - 2017-07-07 17:48:38 --> URI Class Initialized
INFO - 2017-07-07 17:48:38 --> Router Class Initialized
INFO - 2017-07-07 17:48:38 --> Output Class Initialized
INFO - 2017-07-07 17:48:38 --> Security Class Initialized
DEBUG - 2017-07-07 17:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:48:38 --> Input Class Initialized
INFO - 2017-07-07 17:48:38 --> Language Class Initialized
INFO - 2017-07-07 17:48:38 --> Loader Class Initialized
INFO - 2017-07-07 17:48:38 --> Controller Class Initialized
INFO - 2017-07-07 17:48:38 --> Database Driver Class Initialized
INFO - 2017-07-07 17:48:38 --> Model Class Initialized
INFO - 2017-07-07 17:48:38 --> Helper loaded: form_helper
INFO - 2017-07-07 17:48:38 --> Helper loaded: url_helper
INFO - 2017-07-07 17:48:38 --> Model Class Initialized
INFO - 2017-07-07 17:48:38 --> Final output sent to browser
DEBUG - 2017-07-07 17:48:38 --> Total execution time: 0.1925
ERROR - 2017-07-07 17:48:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:48:39 --> Config Class Initialized
INFO - 2017-07-07 17:48:39 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:48:39 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:48:39 --> Utf8 Class Initialized
INFO - 2017-07-07 17:48:39 --> URI Class Initialized
INFO - 2017-07-07 17:48:39 --> Router Class Initialized
INFO - 2017-07-07 17:48:39 --> Output Class Initialized
INFO - 2017-07-07 17:48:39 --> Security Class Initialized
DEBUG - 2017-07-07 17:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:48:39 --> Input Class Initialized
INFO - 2017-07-07 17:48:39 --> Language Class Initialized
INFO - 2017-07-07 17:48:39 --> Loader Class Initialized
INFO - 2017-07-07 17:48:39 --> Controller Class Initialized
INFO - 2017-07-07 17:48:39 --> Database Driver Class Initialized
INFO - 2017-07-07 17:48:39 --> Model Class Initialized
INFO - 2017-07-07 17:48:39 --> Helper loaded: form_helper
INFO - 2017-07-07 17:48:39 --> Helper loaded: url_helper
INFO - 2017-07-07 17:48:39 --> Model Class Initialized
INFO - 2017-07-07 17:48:39 --> Final output sent to browser
DEBUG - 2017-07-07 17:48:39 --> Total execution time: 0.1700
ERROR - 2017-07-07 17:48:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:48:40 --> Config Class Initialized
INFO - 2017-07-07 17:48:40 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:48:40 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:48:40 --> Utf8 Class Initialized
INFO - 2017-07-07 17:48:40 --> URI Class Initialized
INFO - 2017-07-07 17:48:40 --> Router Class Initialized
INFO - 2017-07-07 17:48:40 --> Output Class Initialized
INFO - 2017-07-07 17:48:40 --> Security Class Initialized
DEBUG - 2017-07-07 17:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:48:40 --> Input Class Initialized
INFO - 2017-07-07 17:48:40 --> Language Class Initialized
INFO - 2017-07-07 17:48:40 --> Loader Class Initialized
INFO - 2017-07-07 17:48:40 --> Controller Class Initialized
INFO - 2017-07-07 17:48:40 --> Database Driver Class Initialized
INFO - 2017-07-07 17:48:40 --> Model Class Initialized
INFO - 2017-07-07 17:48:40 --> Helper loaded: form_helper
INFO - 2017-07-07 17:48:40 --> Helper loaded: url_helper
INFO - 2017-07-07 17:48:40 --> Model Class Initialized
INFO - 2017-07-07 17:48:40 --> Final output sent to browser
DEBUG - 2017-07-07 17:48:40 --> Total execution time: 0.1475
ERROR - 2017-07-07 17:48:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:48:42 --> Config Class Initialized
INFO - 2017-07-07 17:48:42 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:48:42 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:48:42 --> Utf8 Class Initialized
INFO - 2017-07-07 17:48:42 --> URI Class Initialized
INFO - 2017-07-07 17:48:42 --> Router Class Initialized
INFO - 2017-07-07 17:48:42 --> Output Class Initialized
INFO - 2017-07-07 17:48:42 --> Security Class Initialized
DEBUG - 2017-07-07 17:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:48:42 --> Input Class Initialized
INFO - 2017-07-07 17:48:42 --> Language Class Initialized
INFO - 2017-07-07 17:48:42 --> Loader Class Initialized
INFO - 2017-07-07 17:48:42 --> Controller Class Initialized
INFO - 2017-07-07 17:48:42 --> Database Driver Class Initialized
INFO - 2017-07-07 17:48:42 --> Model Class Initialized
INFO - 2017-07-07 17:48:42 --> Helper loaded: form_helper
INFO - 2017-07-07 17:48:42 --> Helper loaded: url_helper
INFO - 2017-07-07 17:48:42 --> Model Class Initialized
INFO - 2017-07-07 17:48:42 --> Final output sent to browser
DEBUG - 2017-07-07 17:48:42 --> Total execution time: 0.0800
ERROR - 2017-07-07 17:49:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:49:17 --> Config Class Initialized
INFO - 2017-07-07 17:49:17 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:49:17 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:49:17 --> Utf8 Class Initialized
INFO - 2017-07-07 17:49:17 --> URI Class Initialized
INFO - 2017-07-07 17:49:17 --> Router Class Initialized
INFO - 2017-07-07 17:49:17 --> Output Class Initialized
INFO - 2017-07-07 17:49:17 --> Security Class Initialized
DEBUG - 2017-07-07 17:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:49:17 --> Input Class Initialized
INFO - 2017-07-07 17:49:17 --> Language Class Initialized
INFO - 2017-07-07 17:49:17 --> Loader Class Initialized
INFO - 2017-07-07 17:49:17 --> Controller Class Initialized
INFO - 2017-07-07 17:49:17 --> Database Driver Class Initialized
INFO - 2017-07-07 17:49:17 --> Model Class Initialized
INFO - 2017-07-07 17:49:17 --> Helper loaded: form_helper
INFO - 2017-07-07 17:49:17 --> Helper loaded: url_helper
INFO - 2017-07-07 17:49:17 --> Model Class Initialized
INFO - 2017-07-07 17:49:17 --> Final output sent to browser
DEBUG - 2017-07-07 17:49:17 --> Total execution time: 0.1125
ERROR - 2017-07-07 17:51:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:51:20 --> Config Class Initialized
INFO - 2017-07-07 17:51:20 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:51:20 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:51:20 --> Utf8 Class Initialized
INFO - 2017-07-07 17:51:20 --> URI Class Initialized
INFO - 2017-07-07 17:51:20 --> Router Class Initialized
INFO - 2017-07-07 17:51:20 --> Output Class Initialized
INFO - 2017-07-07 17:51:20 --> Security Class Initialized
DEBUG - 2017-07-07 17:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:51:20 --> Input Class Initialized
INFO - 2017-07-07 17:51:20 --> Language Class Initialized
INFO - 2017-07-07 17:51:20 --> Loader Class Initialized
INFO - 2017-07-07 17:51:20 --> Controller Class Initialized
INFO - 2017-07-07 17:51:20 --> Database Driver Class Initialized
INFO - 2017-07-07 17:51:20 --> Model Class Initialized
INFO - 2017-07-07 17:51:20 --> Helper loaded: form_helper
INFO - 2017-07-07 17:51:20 --> Helper loaded: url_helper
INFO - 2017-07-07 17:51:20 --> Model Class Initialized
INFO - 2017-07-07 17:51:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 17:51:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 17:51:20 --> Final output sent to browser
DEBUG - 2017-07-07 17:51:20 --> Total execution time: 0.1420
ERROR - 2017-07-07 17:53:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:53:05 --> Config Class Initialized
INFO - 2017-07-07 17:53:05 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:53:05 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:53:05 --> Utf8 Class Initialized
INFO - 2017-07-07 17:53:05 --> URI Class Initialized
INFO - 2017-07-07 17:53:05 --> Router Class Initialized
INFO - 2017-07-07 17:53:05 --> Output Class Initialized
INFO - 2017-07-07 17:53:05 --> Security Class Initialized
DEBUG - 2017-07-07 17:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:53:05 --> Input Class Initialized
INFO - 2017-07-07 17:53:05 --> Language Class Initialized
INFO - 2017-07-07 17:53:05 --> Loader Class Initialized
INFO - 2017-07-07 17:53:05 --> Controller Class Initialized
INFO - 2017-07-07 17:53:05 --> Database Driver Class Initialized
INFO - 2017-07-07 17:53:05 --> Model Class Initialized
INFO - 2017-07-07 17:53:05 --> Helper loaded: form_helper
INFO - 2017-07-07 17:53:05 --> Helper loaded: url_helper
INFO - 2017-07-07 17:53:05 --> Model Class Initialized
INFO - 2017-07-07 17:53:05 --> Final output sent to browser
DEBUG - 2017-07-07 17:53:05 --> Total execution time: 0.1450
ERROR - 2017-07-07 17:53:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:53:06 --> Config Class Initialized
INFO - 2017-07-07 17:53:06 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:53:06 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:53:06 --> Utf8 Class Initialized
INFO - 2017-07-07 17:53:06 --> URI Class Initialized
INFO - 2017-07-07 17:53:06 --> Router Class Initialized
INFO - 2017-07-07 17:53:06 --> Output Class Initialized
INFO - 2017-07-07 17:53:07 --> Security Class Initialized
DEBUG - 2017-07-07 17:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:53:07 --> Input Class Initialized
INFO - 2017-07-07 17:53:07 --> Language Class Initialized
INFO - 2017-07-07 17:53:07 --> Loader Class Initialized
INFO - 2017-07-07 17:53:07 --> Controller Class Initialized
INFO - 2017-07-07 17:53:07 --> Database Driver Class Initialized
INFO - 2017-07-07 17:53:07 --> Model Class Initialized
INFO - 2017-07-07 17:53:07 --> Helper loaded: form_helper
INFO - 2017-07-07 17:53:07 --> Helper loaded: url_helper
INFO - 2017-07-07 17:53:07 --> Model Class Initialized
INFO - 2017-07-07 17:53:07 --> Final output sent to browser
DEBUG - 2017-07-07 17:53:07 --> Total execution time: 0.0500
ERROR - 2017-07-07 17:53:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:53:09 --> Config Class Initialized
INFO - 2017-07-07 17:53:09 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:53:09 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:53:09 --> Utf8 Class Initialized
INFO - 2017-07-07 17:53:09 --> URI Class Initialized
INFO - 2017-07-07 17:53:09 --> Router Class Initialized
INFO - 2017-07-07 17:53:09 --> Output Class Initialized
INFO - 2017-07-07 17:53:09 --> Security Class Initialized
DEBUG - 2017-07-07 17:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:53:09 --> Input Class Initialized
INFO - 2017-07-07 17:53:09 --> Language Class Initialized
INFO - 2017-07-07 17:53:09 --> Loader Class Initialized
INFO - 2017-07-07 17:53:09 --> Controller Class Initialized
INFO - 2017-07-07 17:53:09 --> Database Driver Class Initialized
INFO - 2017-07-07 17:53:09 --> Model Class Initialized
INFO - 2017-07-07 17:53:09 --> Helper loaded: form_helper
INFO - 2017-07-07 17:53:09 --> Helper loaded: url_helper
INFO - 2017-07-07 17:53:09 --> Model Class Initialized
INFO - 2017-07-07 17:53:09 --> Final output sent to browser
DEBUG - 2017-07-07 17:53:09 --> Total execution time: 0.0800
ERROR - 2017-07-07 17:53:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:53:43 --> Config Class Initialized
INFO - 2017-07-07 17:53:43 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:53:43 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:53:43 --> Utf8 Class Initialized
INFO - 2017-07-07 17:53:43 --> URI Class Initialized
INFO - 2017-07-07 17:53:43 --> Router Class Initialized
INFO - 2017-07-07 17:53:43 --> Output Class Initialized
INFO - 2017-07-07 17:53:43 --> Security Class Initialized
DEBUG - 2017-07-07 17:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:53:43 --> Input Class Initialized
INFO - 2017-07-07 17:53:43 --> Language Class Initialized
INFO - 2017-07-07 17:53:43 --> Loader Class Initialized
INFO - 2017-07-07 17:53:43 --> Controller Class Initialized
INFO - 2017-07-07 17:53:43 --> Database Driver Class Initialized
INFO - 2017-07-07 17:53:43 --> Model Class Initialized
INFO - 2017-07-07 17:53:43 --> Helper loaded: form_helper
INFO - 2017-07-07 17:53:43 --> Helper loaded: url_helper
INFO - 2017-07-07 17:53:43 --> Model Class Initialized
INFO - 2017-07-07 17:53:43 --> Final output sent to browser
DEBUG - 2017-07-07 17:53:43 --> Total execution time: 0.0975
ERROR - 2017-07-07 17:56:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:56:17 --> Config Class Initialized
INFO - 2017-07-07 17:56:17 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:56:17 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:56:17 --> Utf8 Class Initialized
INFO - 2017-07-07 17:56:17 --> URI Class Initialized
INFO - 2017-07-07 17:56:17 --> Router Class Initialized
INFO - 2017-07-07 17:56:17 --> Output Class Initialized
INFO - 2017-07-07 17:56:17 --> Security Class Initialized
DEBUG - 2017-07-07 17:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:56:17 --> Input Class Initialized
INFO - 2017-07-07 17:56:17 --> Language Class Initialized
INFO - 2017-07-07 17:56:17 --> Loader Class Initialized
INFO - 2017-07-07 17:56:17 --> Controller Class Initialized
INFO - 2017-07-07 17:56:17 --> Database Driver Class Initialized
INFO - 2017-07-07 17:56:17 --> Model Class Initialized
INFO - 2017-07-07 17:56:17 --> Helper loaded: form_helper
INFO - 2017-07-07 17:56:17 --> Helper loaded: url_helper
INFO - 2017-07-07 17:56:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 17:56:17 --> Model Class Initialized
INFO - 2017-07-07 17:56:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-07 17:56:17 --> Final output sent to browser
DEBUG - 2017-07-07 17:56:17 --> Total execution time: 0.0670
ERROR - 2017-07-07 17:56:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:56:21 --> Config Class Initialized
INFO - 2017-07-07 17:56:21 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:56:21 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:56:21 --> Utf8 Class Initialized
INFO - 2017-07-07 17:56:21 --> URI Class Initialized
INFO - 2017-07-07 17:56:21 --> Router Class Initialized
INFO - 2017-07-07 17:56:21 --> Output Class Initialized
INFO - 2017-07-07 17:56:21 --> Security Class Initialized
DEBUG - 2017-07-07 17:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:56:21 --> Input Class Initialized
INFO - 2017-07-07 17:56:21 --> Language Class Initialized
INFO - 2017-07-07 17:56:21 --> Loader Class Initialized
INFO - 2017-07-07 17:56:21 --> Controller Class Initialized
INFO - 2017-07-07 17:56:21 --> Database Driver Class Initialized
INFO - 2017-07-07 17:56:21 --> Model Class Initialized
INFO - 2017-07-07 17:56:21 --> Helper loaded: form_helper
INFO - 2017-07-07 17:56:21 --> Helper loaded: url_helper
INFO - 2017-07-07 17:56:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 17:56:21 --> Model Class Initialized
INFO - 2017-07-07 17:56:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 17:56:21 --> Final output sent to browser
DEBUG - 2017-07-07 17:56:21 --> Total execution time: 0.0600
ERROR - 2017-07-07 17:56:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:56:31 --> Config Class Initialized
INFO - 2017-07-07 17:56:31 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:56:31 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:56:31 --> Utf8 Class Initialized
INFO - 2017-07-07 17:56:31 --> URI Class Initialized
INFO - 2017-07-07 17:56:31 --> Router Class Initialized
INFO - 2017-07-07 17:56:31 --> Output Class Initialized
INFO - 2017-07-07 17:56:31 --> Security Class Initialized
DEBUG - 2017-07-07 17:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:56:31 --> Input Class Initialized
INFO - 2017-07-07 17:56:31 --> Language Class Initialized
INFO - 2017-07-07 17:56:31 --> Loader Class Initialized
INFO - 2017-07-07 17:56:31 --> Controller Class Initialized
INFO - 2017-07-07 17:56:31 --> Database Driver Class Initialized
INFO - 2017-07-07 17:56:31 --> Model Class Initialized
INFO - 2017-07-07 17:56:31 --> Helper loaded: form_helper
INFO - 2017-07-07 17:56:31 --> Helper loaded: url_helper
INFO - 2017-07-07 17:56:31 --> Model Class Initialized
INFO - 2017-07-07 17:56:31 --> Final output sent to browser
DEBUG - 2017-07-07 17:56:31 --> Total execution time: 0.1675
ERROR - 2017-07-07 17:56:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:56:33 --> Config Class Initialized
INFO - 2017-07-07 17:56:33 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:56:33 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:56:33 --> Utf8 Class Initialized
INFO - 2017-07-07 17:56:33 --> URI Class Initialized
INFO - 2017-07-07 17:56:33 --> Router Class Initialized
INFO - 2017-07-07 17:56:33 --> Output Class Initialized
INFO - 2017-07-07 17:56:33 --> Security Class Initialized
DEBUG - 2017-07-07 17:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:56:33 --> Input Class Initialized
INFO - 2017-07-07 17:56:33 --> Language Class Initialized
INFO - 2017-07-07 17:56:33 --> Loader Class Initialized
INFO - 2017-07-07 17:56:33 --> Controller Class Initialized
INFO - 2017-07-07 17:56:33 --> Database Driver Class Initialized
INFO - 2017-07-07 17:56:33 --> Model Class Initialized
INFO - 2017-07-07 17:56:33 --> Helper loaded: form_helper
INFO - 2017-07-07 17:56:33 --> Helper loaded: url_helper
INFO - 2017-07-07 17:56:33 --> Model Class Initialized
INFO - 2017-07-07 17:56:33 --> Final output sent to browser
DEBUG - 2017-07-07 17:56:33 --> Total execution time: 0.1000
ERROR - 2017-07-07 17:56:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:56:37 --> Config Class Initialized
INFO - 2017-07-07 17:56:37 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:56:37 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:56:37 --> Utf8 Class Initialized
INFO - 2017-07-07 17:56:37 --> URI Class Initialized
INFO - 2017-07-07 17:56:37 --> Router Class Initialized
INFO - 2017-07-07 17:56:37 --> Output Class Initialized
INFO - 2017-07-07 17:56:37 --> Security Class Initialized
DEBUG - 2017-07-07 17:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:56:37 --> Input Class Initialized
INFO - 2017-07-07 17:56:37 --> Language Class Initialized
INFO - 2017-07-07 17:56:37 --> Loader Class Initialized
INFO - 2017-07-07 17:56:37 --> Controller Class Initialized
INFO - 2017-07-07 17:56:37 --> Database Driver Class Initialized
INFO - 2017-07-07 17:56:37 --> Model Class Initialized
INFO - 2017-07-07 17:56:37 --> Helper loaded: form_helper
INFO - 2017-07-07 17:56:37 --> Helper loaded: url_helper
INFO - 2017-07-07 17:56:37 --> Model Class Initialized
INFO - 2017-07-07 17:56:37 --> Final output sent to browser
DEBUG - 2017-07-07 17:56:37 --> Total execution time: 0.1700
ERROR - 2017-07-07 17:57:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 17:57:09 --> Config Class Initialized
INFO - 2017-07-07 17:57:09 --> Hooks Class Initialized
DEBUG - 2017-07-07 17:57:09 --> UTF-8 Support Enabled
INFO - 2017-07-07 17:57:09 --> Utf8 Class Initialized
INFO - 2017-07-07 17:57:09 --> URI Class Initialized
INFO - 2017-07-07 17:57:09 --> Router Class Initialized
INFO - 2017-07-07 17:57:09 --> Output Class Initialized
INFO - 2017-07-07 17:57:09 --> Security Class Initialized
DEBUG - 2017-07-07 17:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 17:57:09 --> Input Class Initialized
INFO - 2017-07-07 17:57:09 --> Language Class Initialized
INFO - 2017-07-07 17:57:09 --> Loader Class Initialized
INFO - 2017-07-07 17:57:09 --> Controller Class Initialized
INFO - 2017-07-07 17:57:09 --> Database Driver Class Initialized
INFO - 2017-07-07 17:57:09 --> Model Class Initialized
INFO - 2017-07-07 17:57:09 --> Helper loaded: form_helper
INFO - 2017-07-07 17:57:09 --> Helper loaded: url_helper
INFO - 2017-07-07 17:57:09 --> Model Class Initialized
INFO - 2017-07-07 17:57:09 --> Final output sent to browser
DEBUG - 2017-07-07 17:57:09 --> Total execution time: 0.0700
ERROR - 2017-07-07 18:02:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:02:47 --> Config Class Initialized
INFO - 2017-07-07 18:02:47 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:02:47 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:02:47 --> Utf8 Class Initialized
INFO - 2017-07-07 18:02:47 --> URI Class Initialized
INFO - 2017-07-07 18:02:47 --> Router Class Initialized
INFO - 2017-07-07 18:02:47 --> Output Class Initialized
INFO - 2017-07-07 18:02:47 --> Security Class Initialized
DEBUG - 2017-07-07 18:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:02:47 --> Input Class Initialized
INFO - 2017-07-07 18:02:47 --> Language Class Initialized
INFO - 2017-07-07 18:02:47 --> Loader Class Initialized
INFO - 2017-07-07 18:02:47 --> Controller Class Initialized
INFO - 2017-07-07 18:02:47 --> Database Driver Class Initialized
INFO - 2017-07-07 18:02:47 --> Model Class Initialized
INFO - 2017-07-07 18:02:47 --> Helper loaded: form_helper
INFO - 2017-07-07 18:02:47 --> Helper loaded: url_helper
INFO - 2017-07-07 18:02:47 --> Model Class Initialized
INFO - 2017-07-07 18:02:47 --> Final output sent to browser
DEBUG - 2017-07-07 18:02:47 --> Total execution time: 0.0920
ERROR - 2017-07-07 18:02:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:02:49 --> Config Class Initialized
INFO - 2017-07-07 18:02:49 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:02:49 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:02:49 --> Utf8 Class Initialized
INFO - 2017-07-07 18:02:49 --> URI Class Initialized
INFO - 2017-07-07 18:02:49 --> Router Class Initialized
INFO - 2017-07-07 18:02:49 --> Output Class Initialized
INFO - 2017-07-07 18:02:49 --> Security Class Initialized
DEBUG - 2017-07-07 18:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:02:49 --> Input Class Initialized
INFO - 2017-07-07 18:02:49 --> Language Class Initialized
INFO - 2017-07-07 18:02:49 --> Loader Class Initialized
INFO - 2017-07-07 18:02:49 --> Controller Class Initialized
INFO - 2017-07-07 18:02:49 --> Database Driver Class Initialized
INFO - 2017-07-07 18:02:49 --> Model Class Initialized
INFO - 2017-07-07 18:02:49 --> Helper loaded: form_helper
INFO - 2017-07-07 18:02:49 --> Helper loaded: url_helper
INFO - 2017-07-07 18:02:49 --> Model Class Initialized
INFO - 2017-07-07 18:02:49 --> Final output sent to browser
DEBUG - 2017-07-07 18:02:49 --> Total execution time: 0.0530
ERROR - 2017-07-07 18:02:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:02:50 --> Config Class Initialized
INFO - 2017-07-07 18:02:50 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:02:50 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:02:50 --> Utf8 Class Initialized
INFO - 2017-07-07 18:02:50 --> URI Class Initialized
INFO - 2017-07-07 18:02:50 --> Router Class Initialized
INFO - 2017-07-07 18:02:50 --> Output Class Initialized
INFO - 2017-07-07 18:02:50 --> Security Class Initialized
DEBUG - 2017-07-07 18:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:02:50 --> Input Class Initialized
INFO - 2017-07-07 18:02:50 --> Language Class Initialized
INFO - 2017-07-07 18:02:50 --> Loader Class Initialized
INFO - 2017-07-07 18:02:50 --> Controller Class Initialized
INFO - 2017-07-07 18:02:51 --> Database Driver Class Initialized
INFO - 2017-07-07 18:02:51 --> Model Class Initialized
INFO - 2017-07-07 18:02:51 --> Helper loaded: form_helper
INFO - 2017-07-07 18:02:51 --> Helper loaded: url_helper
INFO - 2017-07-07 18:02:51 --> Model Class Initialized
INFO - 2017-07-07 18:02:51 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 18:02:51 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 18:02:51 --> Final output sent to browser
DEBUG - 2017-07-07 18:02:51 --> Total execution time: 0.1660
ERROR - 2017-07-07 18:02:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:02:53 --> Config Class Initialized
INFO - 2017-07-07 18:02:53 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:02:53 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:02:53 --> Utf8 Class Initialized
INFO - 2017-07-07 18:02:53 --> URI Class Initialized
INFO - 2017-07-07 18:02:53 --> Router Class Initialized
INFO - 2017-07-07 18:02:53 --> Output Class Initialized
INFO - 2017-07-07 18:02:53 --> Security Class Initialized
DEBUG - 2017-07-07 18:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:02:53 --> Input Class Initialized
INFO - 2017-07-07 18:02:53 --> Language Class Initialized
INFO - 2017-07-07 18:02:53 --> Loader Class Initialized
INFO - 2017-07-07 18:02:53 --> Controller Class Initialized
INFO - 2017-07-07 18:02:53 --> Database Driver Class Initialized
INFO - 2017-07-07 18:02:53 --> Model Class Initialized
INFO - 2017-07-07 18:02:53 --> Helper loaded: form_helper
INFO - 2017-07-07 18:02:53 --> Helper loaded: url_helper
INFO - 2017-07-07 18:02:53 --> Model Class Initialized
INFO - 2017-07-07 18:02:53 --> Final output sent to browser
DEBUG - 2017-07-07 18:02:53 --> Total execution time: 0.1325
ERROR - 2017-07-07 18:02:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:02:54 --> Config Class Initialized
INFO - 2017-07-07 18:02:54 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:02:54 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:02:54 --> Utf8 Class Initialized
INFO - 2017-07-07 18:02:54 --> URI Class Initialized
INFO - 2017-07-07 18:02:54 --> Router Class Initialized
INFO - 2017-07-07 18:02:54 --> Output Class Initialized
INFO - 2017-07-07 18:02:54 --> Security Class Initialized
DEBUG - 2017-07-07 18:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:02:54 --> Input Class Initialized
INFO - 2017-07-07 18:02:54 --> Language Class Initialized
INFO - 2017-07-07 18:02:54 --> Loader Class Initialized
INFO - 2017-07-07 18:02:54 --> Controller Class Initialized
INFO - 2017-07-07 18:02:54 --> Database Driver Class Initialized
INFO - 2017-07-07 18:02:54 --> Model Class Initialized
INFO - 2017-07-07 18:02:54 --> Helper loaded: form_helper
INFO - 2017-07-07 18:02:54 --> Helper loaded: url_helper
INFO - 2017-07-07 18:02:54 --> Model Class Initialized
INFO - 2017-07-07 18:02:54 --> Final output sent to browser
DEBUG - 2017-07-07 18:02:54 --> Total execution time: 0.1650
ERROR - 2017-07-07 18:02:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:02:55 --> Config Class Initialized
INFO - 2017-07-07 18:02:55 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:02:55 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:02:55 --> Utf8 Class Initialized
INFO - 2017-07-07 18:02:55 --> URI Class Initialized
INFO - 2017-07-07 18:02:55 --> Router Class Initialized
INFO - 2017-07-07 18:02:55 --> Output Class Initialized
INFO - 2017-07-07 18:02:55 --> Security Class Initialized
DEBUG - 2017-07-07 18:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:02:55 --> Input Class Initialized
INFO - 2017-07-07 18:02:55 --> Language Class Initialized
INFO - 2017-07-07 18:02:55 --> Loader Class Initialized
INFO - 2017-07-07 18:02:55 --> Controller Class Initialized
INFO - 2017-07-07 18:02:55 --> Database Driver Class Initialized
INFO - 2017-07-07 18:02:55 --> Model Class Initialized
INFO - 2017-07-07 18:02:55 --> Helper loaded: form_helper
INFO - 2017-07-07 18:02:55 --> Helper loaded: url_helper
INFO - 2017-07-07 18:02:55 --> Model Class Initialized
INFO - 2017-07-07 18:02:55 --> Final output sent to browser
DEBUG - 2017-07-07 18:02:55 --> Total execution time: 0.1675
ERROR - 2017-07-07 18:02:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:02:56 --> Config Class Initialized
INFO - 2017-07-07 18:02:56 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:02:56 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:02:56 --> Utf8 Class Initialized
INFO - 2017-07-07 18:02:56 --> URI Class Initialized
INFO - 2017-07-07 18:02:56 --> Router Class Initialized
INFO - 2017-07-07 18:02:57 --> Output Class Initialized
INFO - 2017-07-07 18:02:57 --> Security Class Initialized
DEBUG - 2017-07-07 18:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:02:57 --> Input Class Initialized
INFO - 2017-07-07 18:02:57 --> Language Class Initialized
INFO - 2017-07-07 18:02:57 --> Loader Class Initialized
INFO - 2017-07-07 18:02:57 --> Controller Class Initialized
INFO - 2017-07-07 18:02:57 --> Database Driver Class Initialized
INFO - 2017-07-07 18:02:57 --> Model Class Initialized
INFO - 2017-07-07 18:02:57 --> Helper loaded: form_helper
INFO - 2017-07-07 18:02:57 --> Helper loaded: url_helper
INFO - 2017-07-07 18:02:57 --> Model Class Initialized
INFO - 2017-07-07 18:02:57 --> Final output sent to browser
DEBUG - 2017-07-07 18:02:57 --> Total execution time: 0.1175
ERROR - 2017-07-07 18:03:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:03:28 --> Config Class Initialized
INFO - 2017-07-07 18:03:28 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:03:28 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:03:28 --> Utf8 Class Initialized
INFO - 2017-07-07 18:03:28 --> URI Class Initialized
INFO - 2017-07-07 18:03:28 --> Router Class Initialized
INFO - 2017-07-07 18:03:28 --> Output Class Initialized
INFO - 2017-07-07 18:03:28 --> Security Class Initialized
DEBUG - 2017-07-07 18:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:03:28 --> Input Class Initialized
INFO - 2017-07-07 18:03:28 --> Language Class Initialized
INFO - 2017-07-07 18:03:28 --> Loader Class Initialized
INFO - 2017-07-07 18:03:28 --> Controller Class Initialized
INFO - 2017-07-07 18:03:28 --> Database Driver Class Initialized
INFO - 2017-07-07 18:03:28 --> Model Class Initialized
INFO - 2017-07-07 18:03:28 --> Helper loaded: form_helper
INFO - 2017-07-07 18:03:28 --> Helper loaded: url_helper
INFO - 2017-07-07 18:03:28 --> Model Class Initialized
INFO - 2017-07-07 18:03:28 --> Final output sent to browser
DEBUG - 2017-07-07 18:03:28 --> Total execution time: 0.1675
ERROR - 2017-07-07 18:05:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:05:05 --> Config Class Initialized
INFO - 2017-07-07 18:05:05 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:05:05 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:05:05 --> Utf8 Class Initialized
INFO - 2017-07-07 18:05:05 --> URI Class Initialized
INFO - 2017-07-07 18:05:05 --> Router Class Initialized
INFO - 2017-07-07 18:05:05 --> Output Class Initialized
INFO - 2017-07-07 18:05:05 --> Security Class Initialized
DEBUG - 2017-07-07 18:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:05:05 --> Input Class Initialized
INFO - 2017-07-07 18:05:05 --> Language Class Initialized
INFO - 2017-07-07 18:05:05 --> Loader Class Initialized
INFO - 2017-07-07 18:05:05 --> Controller Class Initialized
INFO - 2017-07-07 18:05:05 --> Database Driver Class Initialized
INFO - 2017-07-07 18:05:05 --> Model Class Initialized
INFO - 2017-07-07 18:05:05 --> Helper loaded: form_helper
INFO - 2017-07-07 18:05:05 --> Helper loaded: url_helper
INFO - 2017-07-07 18:05:05 --> Model Class Initialized
INFO - 2017-07-07 18:05:05 --> Final output sent to browser
DEBUG - 2017-07-07 18:05:05 --> Total execution time: 0.1150
ERROR - 2017-07-07 18:05:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:05:07 --> Config Class Initialized
INFO - 2017-07-07 18:05:07 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:05:07 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:05:07 --> Utf8 Class Initialized
INFO - 2017-07-07 18:05:07 --> URI Class Initialized
INFO - 2017-07-07 18:05:07 --> Router Class Initialized
INFO - 2017-07-07 18:05:07 --> Output Class Initialized
INFO - 2017-07-07 18:05:07 --> Security Class Initialized
DEBUG - 2017-07-07 18:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:05:07 --> Input Class Initialized
INFO - 2017-07-07 18:05:07 --> Language Class Initialized
INFO - 2017-07-07 18:05:07 --> Loader Class Initialized
INFO - 2017-07-07 18:05:07 --> Controller Class Initialized
INFO - 2017-07-07 18:05:07 --> Database Driver Class Initialized
INFO - 2017-07-07 18:05:07 --> Model Class Initialized
INFO - 2017-07-07 18:05:07 --> Helper loaded: form_helper
INFO - 2017-07-07 18:05:07 --> Helper loaded: url_helper
INFO - 2017-07-07 18:05:07 --> Model Class Initialized
INFO - 2017-07-07 18:05:07 --> Final output sent to browser
DEBUG - 2017-07-07 18:05:07 --> Total execution time: 0.0850
ERROR - 2017-07-07 18:05:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:05:10 --> Config Class Initialized
INFO - 2017-07-07 18:05:10 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:05:10 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:05:10 --> Utf8 Class Initialized
INFO - 2017-07-07 18:05:10 --> URI Class Initialized
INFO - 2017-07-07 18:05:10 --> Router Class Initialized
INFO - 2017-07-07 18:05:10 --> Output Class Initialized
INFO - 2017-07-07 18:05:10 --> Security Class Initialized
DEBUG - 2017-07-07 18:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:05:10 --> Input Class Initialized
INFO - 2017-07-07 18:05:10 --> Language Class Initialized
INFO - 2017-07-07 18:05:10 --> Loader Class Initialized
INFO - 2017-07-07 18:05:10 --> Controller Class Initialized
INFO - 2017-07-07 18:05:10 --> Database Driver Class Initialized
INFO - 2017-07-07 18:05:10 --> Model Class Initialized
INFO - 2017-07-07 18:05:10 --> Helper loaded: form_helper
INFO - 2017-07-07 18:05:10 --> Helper loaded: url_helper
INFO - 2017-07-07 18:05:10 --> Model Class Initialized
INFO - 2017-07-07 18:05:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 18:05:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 18:05:10 --> Final output sent to browser
DEBUG - 2017-07-07 18:05:10 --> Total execution time: 0.1220
ERROR - 2017-07-07 18:05:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:05:11 --> Config Class Initialized
INFO - 2017-07-07 18:05:11 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:05:11 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:05:11 --> Utf8 Class Initialized
INFO - 2017-07-07 18:05:11 --> URI Class Initialized
INFO - 2017-07-07 18:05:11 --> Router Class Initialized
INFO - 2017-07-07 18:05:11 --> Output Class Initialized
INFO - 2017-07-07 18:05:11 --> Security Class Initialized
DEBUG - 2017-07-07 18:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:05:11 --> Input Class Initialized
INFO - 2017-07-07 18:05:11 --> Language Class Initialized
INFO - 2017-07-07 18:05:11 --> Loader Class Initialized
INFO - 2017-07-07 18:05:11 --> Controller Class Initialized
INFO - 2017-07-07 18:05:11 --> Database Driver Class Initialized
INFO - 2017-07-07 18:05:11 --> Model Class Initialized
INFO - 2017-07-07 18:05:11 --> Helper loaded: form_helper
INFO - 2017-07-07 18:05:11 --> Helper loaded: url_helper
INFO - 2017-07-07 18:05:11 --> Model Class Initialized
INFO - 2017-07-07 18:05:11 --> Final output sent to browser
DEBUG - 2017-07-07 18:05:11 --> Total execution time: 0.1200
ERROR - 2017-07-07 18:05:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:05:13 --> Config Class Initialized
INFO - 2017-07-07 18:05:13 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:05:13 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:05:13 --> Utf8 Class Initialized
INFO - 2017-07-07 18:05:13 --> URI Class Initialized
INFO - 2017-07-07 18:05:13 --> Router Class Initialized
INFO - 2017-07-07 18:05:13 --> Output Class Initialized
INFO - 2017-07-07 18:05:13 --> Security Class Initialized
DEBUG - 2017-07-07 18:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:05:13 --> Input Class Initialized
INFO - 2017-07-07 18:05:13 --> Language Class Initialized
INFO - 2017-07-07 18:05:13 --> Loader Class Initialized
INFO - 2017-07-07 18:05:13 --> Controller Class Initialized
INFO - 2017-07-07 18:05:13 --> Database Driver Class Initialized
INFO - 2017-07-07 18:05:13 --> Model Class Initialized
INFO - 2017-07-07 18:05:13 --> Helper loaded: form_helper
INFO - 2017-07-07 18:05:13 --> Helper loaded: url_helper
INFO - 2017-07-07 18:05:13 --> Model Class Initialized
INFO - 2017-07-07 18:05:13 --> Final output sent to browser
DEBUG - 2017-07-07 18:05:13 --> Total execution time: 0.0750
ERROR - 2017-07-07 18:05:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:05:13 --> Config Class Initialized
INFO - 2017-07-07 18:05:13 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:05:13 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:05:13 --> Utf8 Class Initialized
INFO - 2017-07-07 18:05:13 --> URI Class Initialized
INFO - 2017-07-07 18:05:13 --> Router Class Initialized
INFO - 2017-07-07 18:05:13 --> Output Class Initialized
INFO - 2017-07-07 18:05:13 --> Security Class Initialized
DEBUG - 2017-07-07 18:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:05:13 --> Input Class Initialized
INFO - 2017-07-07 18:05:13 --> Language Class Initialized
INFO - 2017-07-07 18:05:13 --> Loader Class Initialized
INFO - 2017-07-07 18:05:13 --> Controller Class Initialized
INFO - 2017-07-07 18:05:13 --> Database Driver Class Initialized
INFO - 2017-07-07 18:05:13 --> Model Class Initialized
INFO - 2017-07-07 18:05:13 --> Helper loaded: form_helper
INFO - 2017-07-07 18:05:13 --> Helper loaded: url_helper
INFO - 2017-07-07 18:05:13 --> Model Class Initialized
INFO - 2017-07-07 18:05:13 --> Final output sent to browser
DEBUG - 2017-07-07 18:05:13 --> Total execution time: 0.1225
ERROR - 2017-07-07 18:05:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:05:20 --> Config Class Initialized
INFO - 2017-07-07 18:05:20 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:05:20 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:05:20 --> Utf8 Class Initialized
INFO - 2017-07-07 18:05:20 --> URI Class Initialized
INFO - 2017-07-07 18:05:20 --> Router Class Initialized
INFO - 2017-07-07 18:05:20 --> Output Class Initialized
INFO - 2017-07-07 18:05:20 --> Security Class Initialized
DEBUG - 2017-07-07 18:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:05:20 --> Input Class Initialized
INFO - 2017-07-07 18:05:20 --> Language Class Initialized
INFO - 2017-07-07 18:05:20 --> Loader Class Initialized
INFO - 2017-07-07 18:05:20 --> Controller Class Initialized
INFO - 2017-07-07 18:05:20 --> Database Driver Class Initialized
INFO - 2017-07-07 18:05:20 --> Model Class Initialized
INFO - 2017-07-07 18:05:20 --> Helper loaded: form_helper
INFO - 2017-07-07 18:05:20 --> Helper loaded: url_helper
INFO - 2017-07-07 18:05:20 --> Model Class Initialized
INFO - 2017-07-07 18:05:20 --> Final output sent to browser
DEBUG - 2017-07-07 18:05:20 --> Total execution time: 0.1325
ERROR - 2017-07-07 18:05:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:05:55 --> Config Class Initialized
INFO - 2017-07-07 18:05:55 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:05:55 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:05:55 --> Utf8 Class Initialized
INFO - 2017-07-07 18:05:55 --> URI Class Initialized
INFO - 2017-07-07 18:05:55 --> Router Class Initialized
INFO - 2017-07-07 18:05:55 --> Output Class Initialized
INFO - 2017-07-07 18:05:55 --> Security Class Initialized
DEBUG - 2017-07-07 18:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:05:55 --> Input Class Initialized
INFO - 2017-07-07 18:05:55 --> Language Class Initialized
INFO - 2017-07-07 18:05:55 --> Loader Class Initialized
INFO - 2017-07-07 18:05:55 --> Controller Class Initialized
INFO - 2017-07-07 18:05:55 --> Database Driver Class Initialized
INFO - 2017-07-07 18:05:55 --> Model Class Initialized
INFO - 2017-07-07 18:05:55 --> Helper loaded: form_helper
INFO - 2017-07-07 18:05:55 --> Helper loaded: url_helper
INFO - 2017-07-07 18:05:55 --> Model Class Initialized
INFO - 2017-07-07 18:05:55 --> Final output sent to browser
DEBUG - 2017-07-07 18:05:55 --> Total execution time: 0.0800
ERROR - 2017-07-07 18:08:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:08:57 --> Config Class Initialized
INFO - 2017-07-07 18:08:57 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:08:57 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:08:57 --> Utf8 Class Initialized
INFO - 2017-07-07 18:08:57 --> URI Class Initialized
INFO - 2017-07-07 18:08:57 --> Router Class Initialized
INFO - 2017-07-07 18:08:57 --> Output Class Initialized
INFO - 2017-07-07 18:08:57 --> Security Class Initialized
DEBUG - 2017-07-07 18:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:08:57 --> Input Class Initialized
INFO - 2017-07-07 18:08:57 --> Language Class Initialized
INFO - 2017-07-07 18:08:57 --> Loader Class Initialized
INFO - 2017-07-07 18:08:57 --> Controller Class Initialized
INFO - 2017-07-07 18:08:57 --> Database Driver Class Initialized
INFO - 2017-07-07 18:08:57 --> Model Class Initialized
INFO - 2017-07-07 18:08:57 --> Helper loaded: form_helper
INFO - 2017-07-07 18:08:57 --> Helper loaded: url_helper
INFO - 2017-07-07 18:08:57 --> Model Class Initialized
INFO - 2017-07-07 18:08:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 18:08:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 18:08:57 --> Final output sent to browser
DEBUG - 2017-07-07 18:08:57 --> Total execution time: 0.1380
ERROR - 2017-07-07 18:09:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:09:13 --> Config Class Initialized
INFO - 2017-07-07 18:09:13 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:09:13 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:09:13 --> Utf8 Class Initialized
INFO - 2017-07-07 18:09:13 --> URI Class Initialized
INFO - 2017-07-07 18:09:13 --> Router Class Initialized
INFO - 2017-07-07 18:09:13 --> Output Class Initialized
INFO - 2017-07-07 18:09:13 --> Security Class Initialized
DEBUG - 2017-07-07 18:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:09:13 --> Input Class Initialized
INFO - 2017-07-07 18:09:13 --> Language Class Initialized
INFO - 2017-07-07 18:09:13 --> Loader Class Initialized
INFO - 2017-07-07 18:09:13 --> Controller Class Initialized
INFO - 2017-07-07 18:09:13 --> Database Driver Class Initialized
INFO - 2017-07-07 18:09:13 --> Model Class Initialized
INFO - 2017-07-07 18:09:13 --> Helper loaded: form_helper
INFO - 2017-07-07 18:09:13 --> Helper loaded: url_helper
INFO - 2017-07-07 18:09:13 --> Model Class Initialized
INFO - 2017-07-07 18:09:13 --> Final output sent to browser
DEBUG - 2017-07-07 18:09:13 --> Total execution time: 0.1400
ERROR - 2017-07-07 18:09:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:09:15 --> Config Class Initialized
INFO - 2017-07-07 18:09:15 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:09:15 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:09:15 --> Utf8 Class Initialized
INFO - 2017-07-07 18:09:15 --> URI Class Initialized
INFO - 2017-07-07 18:09:15 --> Router Class Initialized
INFO - 2017-07-07 18:09:15 --> Output Class Initialized
INFO - 2017-07-07 18:09:15 --> Security Class Initialized
DEBUG - 2017-07-07 18:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:09:15 --> Input Class Initialized
INFO - 2017-07-07 18:09:15 --> Language Class Initialized
INFO - 2017-07-07 18:09:15 --> Loader Class Initialized
INFO - 2017-07-07 18:09:15 --> Controller Class Initialized
INFO - 2017-07-07 18:09:15 --> Database Driver Class Initialized
INFO - 2017-07-07 18:09:15 --> Model Class Initialized
INFO - 2017-07-07 18:09:15 --> Helper loaded: form_helper
INFO - 2017-07-07 18:09:15 --> Helper loaded: url_helper
INFO - 2017-07-07 18:09:15 --> Model Class Initialized
INFO - 2017-07-07 18:09:15 --> Final output sent to browser
DEBUG - 2017-07-07 18:09:15 --> Total execution time: 0.1410
ERROR - 2017-07-07 18:09:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:09:18 --> Config Class Initialized
INFO - 2017-07-07 18:09:18 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:09:18 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:09:18 --> Utf8 Class Initialized
INFO - 2017-07-07 18:09:18 --> URI Class Initialized
INFO - 2017-07-07 18:09:18 --> Router Class Initialized
INFO - 2017-07-07 18:09:18 --> Output Class Initialized
INFO - 2017-07-07 18:09:18 --> Security Class Initialized
DEBUG - 2017-07-07 18:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:09:18 --> Input Class Initialized
INFO - 2017-07-07 18:09:18 --> Language Class Initialized
INFO - 2017-07-07 18:09:18 --> Loader Class Initialized
INFO - 2017-07-07 18:09:18 --> Controller Class Initialized
INFO - 2017-07-07 18:09:18 --> Database Driver Class Initialized
INFO - 2017-07-07 18:09:18 --> Model Class Initialized
INFO - 2017-07-07 18:09:18 --> Helper loaded: form_helper
INFO - 2017-07-07 18:09:18 --> Helper loaded: url_helper
INFO - 2017-07-07 18:09:18 --> Model Class Initialized
INFO - 2017-07-07 18:09:18 --> Final output sent to browser
DEBUG - 2017-07-07 18:09:18 --> Total execution time: 0.1800
ERROR - 2017-07-07 18:09:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:09:57 --> Config Class Initialized
INFO - 2017-07-07 18:09:57 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:09:57 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:09:57 --> Utf8 Class Initialized
INFO - 2017-07-07 18:09:57 --> URI Class Initialized
INFO - 2017-07-07 18:09:57 --> Router Class Initialized
INFO - 2017-07-07 18:09:57 --> Output Class Initialized
INFO - 2017-07-07 18:09:57 --> Security Class Initialized
DEBUG - 2017-07-07 18:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:09:57 --> Input Class Initialized
INFO - 2017-07-07 18:09:57 --> Language Class Initialized
INFO - 2017-07-07 18:09:57 --> Loader Class Initialized
INFO - 2017-07-07 18:09:57 --> Controller Class Initialized
INFO - 2017-07-07 18:09:57 --> Database Driver Class Initialized
INFO - 2017-07-07 18:09:57 --> Model Class Initialized
INFO - 2017-07-07 18:09:57 --> Helper loaded: form_helper
INFO - 2017-07-07 18:09:57 --> Helper loaded: url_helper
INFO - 2017-07-07 18:09:57 --> Model Class Initialized
INFO - 2017-07-07 18:09:57 --> Final output sent to browser
DEBUG - 2017-07-07 18:09:57 --> Total execution time: 0.0500
ERROR - 2017-07-07 18:12:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:12:22 --> Config Class Initialized
INFO - 2017-07-07 18:12:22 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:12:22 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:12:22 --> Utf8 Class Initialized
INFO - 2017-07-07 18:12:22 --> URI Class Initialized
INFO - 2017-07-07 18:12:23 --> Router Class Initialized
INFO - 2017-07-07 18:12:23 --> Output Class Initialized
INFO - 2017-07-07 18:12:23 --> Security Class Initialized
DEBUG - 2017-07-07 18:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:12:23 --> Input Class Initialized
INFO - 2017-07-07 18:12:23 --> Language Class Initialized
INFO - 2017-07-07 18:12:23 --> Loader Class Initialized
INFO - 2017-07-07 18:12:23 --> Controller Class Initialized
INFO - 2017-07-07 18:12:23 --> Database Driver Class Initialized
INFO - 2017-07-07 18:12:23 --> Model Class Initialized
INFO - 2017-07-07 18:12:23 --> Helper loaded: form_helper
INFO - 2017-07-07 18:12:23 --> Helper loaded: url_helper
INFO - 2017-07-07 18:12:23 --> Model Class Initialized
INFO - 2017-07-07 18:12:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 18:12:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 18:12:23 --> Final output sent to browser
DEBUG - 2017-07-07 18:12:23 --> Total execution time: 0.1520
ERROR - 2017-07-07 18:12:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:12:48 --> Config Class Initialized
INFO - 2017-07-07 18:12:48 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:12:48 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:12:48 --> Utf8 Class Initialized
INFO - 2017-07-07 18:12:48 --> URI Class Initialized
INFO - 2017-07-07 18:12:48 --> Router Class Initialized
INFO - 2017-07-07 18:12:48 --> Output Class Initialized
INFO - 2017-07-07 18:12:48 --> Security Class Initialized
DEBUG - 2017-07-07 18:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:12:48 --> Input Class Initialized
INFO - 2017-07-07 18:12:48 --> Language Class Initialized
INFO - 2017-07-07 18:12:48 --> Loader Class Initialized
INFO - 2017-07-07 18:12:48 --> Controller Class Initialized
INFO - 2017-07-07 18:12:48 --> Database Driver Class Initialized
INFO - 2017-07-07 18:12:48 --> Model Class Initialized
INFO - 2017-07-07 18:12:48 --> Helper loaded: form_helper
INFO - 2017-07-07 18:12:48 --> Helper loaded: url_helper
INFO - 2017-07-07 18:12:48 --> Model Class Initialized
INFO - 2017-07-07 18:12:48 --> Final output sent to browser
DEBUG - 2017-07-07 18:12:48 --> Total execution time: 0.0710
ERROR - 2017-07-07 18:12:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:12:49 --> Config Class Initialized
INFO - 2017-07-07 18:12:49 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:12:49 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:12:49 --> Utf8 Class Initialized
INFO - 2017-07-07 18:12:49 --> URI Class Initialized
INFO - 2017-07-07 18:12:49 --> Router Class Initialized
INFO - 2017-07-07 18:12:49 --> Output Class Initialized
INFO - 2017-07-07 18:12:49 --> Security Class Initialized
DEBUG - 2017-07-07 18:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:12:49 --> Input Class Initialized
INFO - 2017-07-07 18:12:49 --> Language Class Initialized
INFO - 2017-07-07 18:12:49 --> Loader Class Initialized
INFO - 2017-07-07 18:12:49 --> Controller Class Initialized
INFO - 2017-07-07 18:12:49 --> Database Driver Class Initialized
INFO - 2017-07-07 18:12:49 --> Model Class Initialized
INFO - 2017-07-07 18:12:49 --> Helper loaded: form_helper
INFO - 2017-07-07 18:12:49 --> Helper loaded: url_helper
INFO - 2017-07-07 18:12:49 --> Model Class Initialized
INFO - 2017-07-07 18:12:49 --> Final output sent to browser
DEBUG - 2017-07-07 18:12:49 --> Total execution time: 0.1170
ERROR - 2017-07-07 18:12:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:12:58 --> Config Class Initialized
INFO - 2017-07-07 18:12:58 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:12:58 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:12:58 --> Utf8 Class Initialized
INFO - 2017-07-07 18:12:58 --> URI Class Initialized
INFO - 2017-07-07 18:12:58 --> Router Class Initialized
INFO - 2017-07-07 18:12:58 --> Output Class Initialized
INFO - 2017-07-07 18:12:58 --> Security Class Initialized
DEBUG - 2017-07-07 18:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:12:58 --> Input Class Initialized
INFO - 2017-07-07 18:12:58 --> Language Class Initialized
INFO - 2017-07-07 18:12:58 --> Loader Class Initialized
INFO - 2017-07-07 18:12:58 --> Controller Class Initialized
INFO - 2017-07-07 18:12:58 --> Database Driver Class Initialized
INFO - 2017-07-07 18:12:58 --> Model Class Initialized
INFO - 2017-07-07 18:12:58 --> Helper loaded: form_helper
INFO - 2017-07-07 18:12:58 --> Helper loaded: url_helper
INFO - 2017-07-07 18:12:58 --> Model Class Initialized
INFO - 2017-07-07 18:12:58 --> Final output sent to browser
DEBUG - 2017-07-07 18:12:58 --> Total execution time: 0.1910
ERROR - 2017-07-07 18:13:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:13:45 --> Config Class Initialized
INFO - 2017-07-07 18:13:45 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:13:45 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:13:45 --> Utf8 Class Initialized
INFO - 2017-07-07 18:13:45 --> URI Class Initialized
INFO - 2017-07-07 18:13:45 --> Router Class Initialized
INFO - 2017-07-07 18:13:45 --> Output Class Initialized
INFO - 2017-07-07 18:13:45 --> Security Class Initialized
DEBUG - 2017-07-07 18:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:13:45 --> Input Class Initialized
INFO - 2017-07-07 18:13:45 --> Language Class Initialized
INFO - 2017-07-07 18:13:45 --> Loader Class Initialized
INFO - 2017-07-07 18:13:45 --> Controller Class Initialized
INFO - 2017-07-07 18:13:46 --> Database Driver Class Initialized
INFO - 2017-07-07 18:13:46 --> Model Class Initialized
INFO - 2017-07-07 18:13:46 --> Helper loaded: form_helper
INFO - 2017-07-07 18:13:46 --> Helper loaded: url_helper
INFO - 2017-07-07 18:13:46 --> Model Class Initialized
INFO - 2017-07-07 18:13:46 --> Final output sent to browser
DEBUG - 2017-07-07 18:13:46 --> Total execution time: 0.1400
ERROR - 2017-07-07 18:16:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:16:09 --> Config Class Initialized
INFO - 2017-07-07 18:16:09 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:16:09 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:16:09 --> Utf8 Class Initialized
INFO - 2017-07-07 18:16:09 --> URI Class Initialized
INFO - 2017-07-07 18:16:09 --> Router Class Initialized
INFO - 2017-07-07 18:16:09 --> Output Class Initialized
INFO - 2017-07-07 18:16:09 --> Security Class Initialized
DEBUG - 2017-07-07 18:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:16:09 --> Input Class Initialized
INFO - 2017-07-07 18:16:09 --> Language Class Initialized
INFO - 2017-07-07 18:16:09 --> Loader Class Initialized
INFO - 2017-07-07 18:16:09 --> Controller Class Initialized
INFO - 2017-07-07 18:16:09 --> Database Driver Class Initialized
INFO - 2017-07-07 18:16:10 --> Model Class Initialized
INFO - 2017-07-07 18:16:10 --> Helper loaded: form_helper
INFO - 2017-07-07 18:16:10 --> Helper loaded: url_helper
INFO - 2017-07-07 18:16:10 --> Model Class Initialized
INFO - 2017-07-07 18:16:10 --> Final output sent to browser
DEBUG - 2017-07-07 18:16:10 --> Total execution time: 0.1505
ERROR - 2017-07-07 18:16:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:16:11 --> Config Class Initialized
INFO - 2017-07-07 18:16:11 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:16:11 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:16:11 --> Utf8 Class Initialized
INFO - 2017-07-07 18:16:11 --> URI Class Initialized
INFO - 2017-07-07 18:16:11 --> Router Class Initialized
INFO - 2017-07-07 18:16:11 --> Output Class Initialized
INFO - 2017-07-07 18:16:11 --> Security Class Initialized
DEBUG - 2017-07-07 18:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:16:11 --> Input Class Initialized
INFO - 2017-07-07 18:16:11 --> Language Class Initialized
INFO - 2017-07-07 18:16:11 --> Loader Class Initialized
INFO - 2017-07-07 18:16:11 --> Controller Class Initialized
INFO - 2017-07-07 18:16:11 --> Database Driver Class Initialized
INFO - 2017-07-07 18:16:11 --> Model Class Initialized
INFO - 2017-07-07 18:16:11 --> Helper loaded: form_helper
INFO - 2017-07-07 18:16:11 --> Helper loaded: url_helper
INFO - 2017-07-07 18:16:11 --> Model Class Initialized
INFO - 2017-07-07 18:16:11 --> Final output sent to browser
DEBUG - 2017-07-07 18:16:11 --> Total execution time: 0.0630
ERROR - 2017-07-07 18:16:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:16:15 --> Config Class Initialized
INFO - 2017-07-07 18:16:15 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:16:15 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:16:15 --> Utf8 Class Initialized
INFO - 2017-07-07 18:16:15 --> URI Class Initialized
INFO - 2017-07-07 18:16:15 --> Router Class Initialized
INFO - 2017-07-07 18:16:15 --> Output Class Initialized
INFO - 2017-07-07 18:16:15 --> Security Class Initialized
DEBUG - 2017-07-07 18:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:16:15 --> Input Class Initialized
INFO - 2017-07-07 18:16:15 --> Language Class Initialized
INFO - 2017-07-07 18:16:15 --> Loader Class Initialized
INFO - 2017-07-07 18:16:15 --> Controller Class Initialized
INFO - 2017-07-07 18:16:15 --> Database Driver Class Initialized
INFO - 2017-07-07 18:16:15 --> Model Class Initialized
INFO - 2017-07-07 18:16:15 --> Helper loaded: form_helper
INFO - 2017-07-07 18:16:15 --> Helper loaded: url_helper
INFO - 2017-07-07 18:16:15 --> Model Class Initialized
INFO - 2017-07-07 18:16:15 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 18:16:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 18:16:16 --> Final output sent to browser
DEBUG - 2017-07-07 18:16:16 --> Total execution time: 0.1760
ERROR - 2017-07-07 18:16:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:16:18 --> Config Class Initialized
INFO - 2017-07-07 18:16:18 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:16:18 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:16:18 --> Utf8 Class Initialized
INFO - 2017-07-07 18:16:18 --> URI Class Initialized
INFO - 2017-07-07 18:16:18 --> Router Class Initialized
INFO - 2017-07-07 18:16:18 --> Output Class Initialized
INFO - 2017-07-07 18:16:18 --> Security Class Initialized
DEBUG - 2017-07-07 18:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:16:18 --> Input Class Initialized
INFO - 2017-07-07 18:16:18 --> Language Class Initialized
INFO - 2017-07-07 18:16:18 --> Loader Class Initialized
INFO - 2017-07-07 18:16:18 --> Controller Class Initialized
INFO - 2017-07-07 18:16:18 --> Database Driver Class Initialized
INFO - 2017-07-07 18:16:18 --> Model Class Initialized
INFO - 2017-07-07 18:16:18 --> Helper loaded: form_helper
INFO - 2017-07-07 18:16:18 --> Helper loaded: url_helper
INFO - 2017-07-07 18:16:18 --> Model Class Initialized
INFO - 2017-07-07 18:16:18 --> Final output sent to browser
DEBUG - 2017-07-07 18:16:18 --> Total execution time: 0.1300
ERROR - 2017-07-07 18:16:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:16:19 --> Config Class Initialized
INFO - 2017-07-07 18:16:19 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:16:20 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:16:20 --> Utf8 Class Initialized
INFO - 2017-07-07 18:16:20 --> URI Class Initialized
INFO - 2017-07-07 18:16:20 --> Router Class Initialized
INFO - 2017-07-07 18:16:20 --> Output Class Initialized
INFO - 2017-07-07 18:16:20 --> Security Class Initialized
DEBUG - 2017-07-07 18:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:16:20 --> Input Class Initialized
INFO - 2017-07-07 18:16:20 --> Language Class Initialized
INFO - 2017-07-07 18:16:20 --> Loader Class Initialized
INFO - 2017-07-07 18:16:20 --> Controller Class Initialized
INFO - 2017-07-07 18:16:20 --> Database Driver Class Initialized
INFO - 2017-07-07 18:16:20 --> Model Class Initialized
INFO - 2017-07-07 18:16:20 --> Helper loaded: form_helper
INFO - 2017-07-07 18:16:20 --> Helper loaded: url_helper
INFO - 2017-07-07 18:16:20 --> Model Class Initialized
INFO - 2017-07-07 18:16:20 --> Final output sent to browser
DEBUG - 2017-07-07 18:16:20 --> Total execution time: 0.3000
ERROR - 2017-07-07 18:16:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:16:21 --> Config Class Initialized
INFO - 2017-07-07 18:16:21 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:16:21 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:16:21 --> Utf8 Class Initialized
INFO - 2017-07-07 18:16:21 --> URI Class Initialized
INFO - 2017-07-07 18:16:21 --> Router Class Initialized
INFO - 2017-07-07 18:16:21 --> Output Class Initialized
INFO - 2017-07-07 18:16:21 --> Security Class Initialized
DEBUG - 2017-07-07 18:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:16:21 --> Input Class Initialized
INFO - 2017-07-07 18:16:21 --> Language Class Initialized
INFO - 2017-07-07 18:16:21 --> Loader Class Initialized
INFO - 2017-07-07 18:16:21 --> Controller Class Initialized
INFO - 2017-07-07 18:16:21 --> Database Driver Class Initialized
INFO - 2017-07-07 18:16:21 --> Model Class Initialized
INFO - 2017-07-07 18:16:21 --> Helper loaded: form_helper
INFO - 2017-07-07 18:16:21 --> Helper loaded: url_helper
INFO - 2017-07-07 18:16:21 --> Model Class Initialized
INFO - 2017-07-07 18:16:21 --> Final output sent to browser
DEBUG - 2017-07-07 18:16:21 --> Total execution time: 0.1500
ERROR - 2017-07-07 18:16:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:16:22 --> Config Class Initialized
INFO - 2017-07-07 18:16:22 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:16:22 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:16:22 --> Utf8 Class Initialized
INFO - 2017-07-07 18:16:23 --> URI Class Initialized
INFO - 2017-07-07 18:16:23 --> Router Class Initialized
INFO - 2017-07-07 18:16:23 --> Output Class Initialized
INFO - 2017-07-07 18:16:23 --> Security Class Initialized
DEBUG - 2017-07-07 18:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:16:23 --> Input Class Initialized
INFO - 2017-07-07 18:16:23 --> Language Class Initialized
INFO - 2017-07-07 18:16:23 --> Loader Class Initialized
INFO - 2017-07-07 18:16:23 --> Controller Class Initialized
INFO - 2017-07-07 18:16:23 --> Database Driver Class Initialized
INFO - 2017-07-07 18:16:23 --> Model Class Initialized
INFO - 2017-07-07 18:16:23 --> Helper loaded: form_helper
INFO - 2017-07-07 18:16:23 --> Helper loaded: url_helper
INFO - 2017-07-07 18:16:23 --> Model Class Initialized
INFO - 2017-07-07 18:16:23 --> Final output sent to browser
DEBUG - 2017-07-07 18:16:23 --> Total execution time: 0.0600
ERROR - 2017-07-07 18:17:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:17:05 --> Config Class Initialized
INFO - 2017-07-07 18:17:05 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:17:05 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:17:05 --> Utf8 Class Initialized
INFO - 2017-07-07 18:17:05 --> URI Class Initialized
INFO - 2017-07-07 18:17:05 --> Router Class Initialized
INFO - 2017-07-07 18:17:05 --> Output Class Initialized
INFO - 2017-07-07 18:17:05 --> Security Class Initialized
DEBUG - 2017-07-07 18:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:17:05 --> Input Class Initialized
INFO - 2017-07-07 18:17:05 --> Language Class Initialized
INFO - 2017-07-07 18:17:05 --> Loader Class Initialized
INFO - 2017-07-07 18:17:05 --> Controller Class Initialized
INFO - 2017-07-07 18:17:05 --> Database Driver Class Initialized
INFO - 2017-07-07 18:17:05 --> Model Class Initialized
INFO - 2017-07-07 18:17:05 --> Helper loaded: form_helper
INFO - 2017-07-07 18:17:05 --> Helper loaded: url_helper
INFO - 2017-07-07 18:17:05 --> Model Class Initialized
INFO - 2017-07-07 18:17:05 --> Final output sent to browser
DEBUG - 2017-07-07 18:17:05 --> Total execution time: 0.1500
ERROR - 2017-07-07 18:18:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:18:22 --> Config Class Initialized
INFO - 2017-07-07 18:18:22 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:18:22 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:18:22 --> Utf8 Class Initialized
INFO - 2017-07-07 18:18:22 --> URI Class Initialized
INFO - 2017-07-07 18:18:22 --> Router Class Initialized
INFO - 2017-07-07 18:18:22 --> Output Class Initialized
INFO - 2017-07-07 18:18:22 --> Security Class Initialized
DEBUG - 2017-07-07 18:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:18:22 --> Input Class Initialized
INFO - 2017-07-07 18:18:22 --> Language Class Initialized
INFO - 2017-07-07 18:18:22 --> Loader Class Initialized
INFO - 2017-07-07 18:18:22 --> Controller Class Initialized
INFO - 2017-07-07 18:18:22 --> Database Driver Class Initialized
INFO - 2017-07-07 18:18:22 --> Model Class Initialized
INFO - 2017-07-07 18:18:22 --> Helper loaded: form_helper
INFO - 2017-07-07 18:18:22 --> Helper loaded: url_helper
INFO - 2017-07-07 18:18:22 --> Model Class Initialized
INFO - 2017-07-07 18:18:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 18:18:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 18:18:22 --> Final output sent to browser
DEBUG - 2017-07-07 18:18:22 --> Total execution time: 0.1480
ERROR - 2017-07-07 18:18:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:18:49 --> Config Class Initialized
INFO - 2017-07-07 18:18:49 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:18:49 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:18:49 --> Utf8 Class Initialized
INFO - 2017-07-07 18:18:49 --> URI Class Initialized
INFO - 2017-07-07 18:18:49 --> Router Class Initialized
INFO - 2017-07-07 18:18:49 --> Output Class Initialized
INFO - 2017-07-07 18:18:49 --> Security Class Initialized
DEBUG - 2017-07-07 18:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:18:49 --> Input Class Initialized
INFO - 2017-07-07 18:18:49 --> Language Class Initialized
INFO - 2017-07-07 18:18:49 --> Loader Class Initialized
INFO - 2017-07-07 18:18:49 --> Controller Class Initialized
INFO - 2017-07-07 18:18:49 --> Database Driver Class Initialized
INFO - 2017-07-07 18:18:49 --> Model Class Initialized
INFO - 2017-07-07 18:18:49 --> Helper loaded: form_helper
INFO - 2017-07-07 18:18:49 --> Helper loaded: url_helper
INFO - 2017-07-07 18:18:49 --> Model Class Initialized
INFO - 2017-07-07 18:18:49 --> Final output sent to browser
DEBUG - 2017-07-07 18:18:49 --> Total execution time: 0.0700
ERROR - 2017-07-07 18:18:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:18:50 --> Config Class Initialized
INFO - 2017-07-07 18:18:50 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:18:50 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:18:50 --> Utf8 Class Initialized
INFO - 2017-07-07 18:18:50 --> URI Class Initialized
INFO - 2017-07-07 18:18:50 --> Router Class Initialized
INFO - 2017-07-07 18:18:50 --> Output Class Initialized
INFO - 2017-07-07 18:18:50 --> Security Class Initialized
DEBUG - 2017-07-07 18:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:18:50 --> Input Class Initialized
INFO - 2017-07-07 18:18:50 --> Language Class Initialized
INFO - 2017-07-07 18:18:50 --> Loader Class Initialized
INFO - 2017-07-07 18:18:50 --> Controller Class Initialized
INFO - 2017-07-07 18:18:50 --> Database Driver Class Initialized
INFO - 2017-07-07 18:18:50 --> Model Class Initialized
INFO - 2017-07-07 18:18:50 --> Helper loaded: form_helper
INFO - 2017-07-07 18:18:50 --> Helper loaded: url_helper
INFO - 2017-07-07 18:18:50 --> Model Class Initialized
INFO - 2017-07-07 18:18:50 --> Final output sent to browser
DEBUG - 2017-07-07 18:18:50 --> Total execution time: 0.2000
ERROR - 2017-07-07 18:18:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:18:53 --> Config Class Initialized
INFO - 2017-07-07 18:18:53 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:18:53 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:18:53 --> Utf8 Class Initialized
INFO - 2017-07-07 18:18:53 --> URI Class Initialized
INFO - 2017-07-07 18:18:53 --> Router Class Initialized
INFO - 2017-07-07 18:18:53 --> Output Class Initialized
INFO - 2017-07-07 18:18:53 --> Security Class Initialized
DEBUG - 2017-07-07 18:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:18:53 --> Input Class Initialized
INFO - 2017-07-07 18:18:53 --> Language Class Initialized
INFO - 2017-07-07 18:18:53 --> Loader Class Initialized
INFO - 2017-07-07 18:18:53 --> Controller Class Initialized
INFO - 2017-07-07 18:18:53 --> Database Driver Class Initialized
INFO - 2017-07-07 18:18:53 --> Model Class Initialized
INFO - 2017-07-07 18:18:53 --> Helper loaded: form_helper
INFO - 2017-07-07 18:18:53 --> Helper loaded: url_helper
INFO - 2017-07-07 18:18:53 --> Model Class Initialized
INFO - 2017-07-07 18:18:53 --> Final output sent to browser
DEBUG - 2017-07-07 18:18:53 --> Total execution time: 0.1300
ERROR - 2017-07-07 18:19:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:19:34 --> Config Class Initialized
INFO - 2017-07-07 18:19:34 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:19:34 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:19:34 --> Utf8 Class Initialized
INFO - 2017-07-07 18:19:34 --> URI Class Initialized
INFO - 2017-07-07 18:19:34 --> Router Class Initialized
INFO - 2017-07-07 18:19:34 --> Output Class Initialized
INFO - 2017-07-07 18:19:34 --> Security Class Initialized
DEBUG - 2017-07-07 18:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:19:34 --> Input Class Initialized
INFO - 2017-07-07 18:19:34 --> Language Class Initialized
INFO - 2017-07-07 18:19:34 --> Loader Class Initialized
INFO - 2017-07-07 18:19:34 --> Controller Class Initialized
INFO - 2017-07-07 18:19:34 --> Database Driver Class Initialized
INFO - 2017-07-07 18:19:34 --> Model Class Initialized
INFO - 2017-07-07 18:19:34 --> Helper loaded: form_helper
INFO - 2017-07-07 18:19:34 --> Helper loaded: url_helper
INFO - 2017-07-07 18:19:34 --> Model Class Initialized
INFO - 2017-07-07 18:19:34 --> Final output sent to browser
DEBUG - 2017-07-07 18:19:34 --> Total execution time: 0.1200
ERROR - 2017-07-07 18:21:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:21:13 --> Config Class Initialized
INFO - 2017-07-07 18:21:13 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:21:13 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:21:13 --> Utf8 Class Initialized
INFO - 2017-07-07 18:21:13 --> URI Class Initialized
INFO - 2017-07-07 18:21:13 --> Router Class Initialized
INFO - 2017-07-07 18:21:13 --> Output Class Initialized
INFO - 2017-07-07 18:21:13 --> Security Class Initialized
DEBUG - 2017-07-07 18:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:21:13 --> Input Class Initialized
INFO - 2017-07-07 18:21:13 --> Language Class Initialized
INFO - 2017-07-07 18:21:13 --> Loader Class Initialized
INFO - 2017-07-07 18:21:13 --> Controller Class Initialized
INFO - 2017-07-07 18:21:13 --> Database Driver Class Initialized
INFO - 2017-07-07 18:21:13 --> Model Class Initialized
INFO - 2017-07-07 18:21:13 --> Helper loaded: form_helper
INFO - 2017-07-07 18:21:13 --> Helper loaded: url_helper
INFO - 2017-07-07 18:21:13 --> Model Class Initialized
INFO - 2017-07-07 18:21:13 --> Final output sent to browser
DEBUG - 2017-07-07 18:21:13 --> Total execution time: 0.1045
ERROR - 2017-07-07 18:21:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:21:15 --> Config Class Initialized
INFO - 2017-07-07 18:21:15 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:21:15 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:21:15 --> Utf8 Class Initialized
INFO - 2017-07-07 18:21:15 --> URI Class Initialized
INFO - 2017-07-07 18:21:15 --> Router Class Initialized
INFO - 2017-07-07 18:21:15 --> Output Class Initialized
INFO - 2017-07-07 18:21:15 --> Security Class Initialized
DEBUG - 2017-07-07 18:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:21:15 --> Input Class Initialized
INFO - 2017-07-07 18:21:15 --> Language Class Initialized
INFO - 2017-07-07 18:21:15 --> Loader Class Initialized
INFO - 2017-07-07 18:21:15 --> Controller Class Initialized
INFO - 2017-07-07 18:21:15 --> Database Driver Class Initialized
INFO - 2017-07-07 18:21:15 --> Model Class Initialized
INFO - 2017-07-07 18:21:15 --> Helper loaded: form_helper
INFO - 2017-07-07 18:21:15 --> Helper loaded: url_helper
INFO - 2017-07-07 18:21:15 --> Model Class Initialized
INFO - 2017-07-07 18:21:15 --> Final output sent to browser
DEBUG - 2017-07-07 18:21:15 --> Total execution time: 0.0700
ERROR - 2017-07-07 18:21:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:21:24 --> Config Class Initialized
INFO - 2017-07-07 18:21:24 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:21:24 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:21:24 --> Utf8 Class Initialized
INFO - 2017-07-07 18:21:24 --> URI Class Initialized
INFO - 2017-07-07 18:21:24 --> Router Class Initialized
INFO - 2017-07-07 18:21:24 --> Output Class Initialized
INFO - 2017-07-07 18:21:24 --> Security Class Initialized
DEBUG - 2017-07-07 18:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:21:24 --> Input Class Initialized
INFO - 2017-07-07 18:21:24 --> Language Class Initialized
INFO - 2017-07-07 18:21:24 --> Loader Class Initialized
INFO - 2017-07-07 18:21:24 --> Controller Class Initialized
INFO - 2017-07-07 18:21:24 --> Database Driver Class Initialized
INFO - 2017-07-07 18:21:24 --> Model Class Initialized
INFO - 2017-07-07 18:21:24 --> Helper loaded: form_helper
INFO - 2017-07-07 18:21:24 --> Helper loaded: url_helper
INFO - 2017-07-07 18:21:24 --> Model Class Initialized
INFO - 2017-07-07 18:21:24 --> Final output sent to browser
DEBUG - 2017-07-07 18:21:24 --> Total execution time: 0.0990
ERROR - 2017-07-07 18:21:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:21:25 --> Config Class Initialized
INFO - 2017-07-07 18:21:25 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:21:25 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:21:25 --> Utf8 Class Initialized
INFO - 2017-07-07 18:21:25 --> URI Class Initialized
INFO - 2017-07-07 18:21:25 --> Router Class Initialized
INFO - 2017-07-07 18:21:25 --> Output Class Initialized
INFO - 2017-07-07 18:21:25 --> Security Class Initialized
DEBUG - 2017-07-07 18:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:21:25 --> Input Class Initialized
INFO - 2017-07-07 18:21:25 --> Language Class Initialized
INFO - 2017-07-07 18:21:25 --> Loader Class Initialized
INFO - 2017-07-07 18:21:25 --> Controller Class Initialized
INFO - 2017-07-07 18:21:25 --> Database Driver Class Initialized
INFO - 2017-07-07 18:21:25 --> Model Class Initialized
INFO - 2017-07-07 18:21:25 --> Helper loaded: form_helper
INFO - 2017-07-07 18:21:25 --> Helper loaded: url_helper
INFO - 2017-07-07 18:21:25 --> Model Class Initialized
INFO - 2017-07-07 18:21:25 --> Final output sent to browser
DEBUG - 2017-07-07 18:21:25 --> Total execution time: 0.0525
ERROR - 2017-07-07 18:21:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:21:26 --> Config Class Initialized
INFO - 2017-07-07 18:21:26 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:21:26 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:21:26 --> Utf8 Class Initialized
INFO - 2017-07-07 18:21:26 --> URI Class Initialized
INFO - 2017-07-07 18:21:26 --> Router Class Initialized
INFO - 2017-07-07 18:21:26 --> Output Class Initialized
INFO - 2017-07-07 18:21:26 --> Security Class Initialized
DEBUG - 2017-07-07 18:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:21:26 --> Input Class Initialized
INFO - 2017-07-07 18:21:26 --> Language Class Initialized
INFO - 2017-07-07 18:21:26 --> Loader Class Initialized
INFO - 2017-07-07 18:21:26 --> Controller Class Initialized
INFO - 2017-07-07 18:21:26 --> Database Driver Class Initialized
INFO - 2017-07-07 18:21:26 --> Model Class Initialized
INFO - 2017-07-07 18:21:26 --> Helper loaded: form_helper
INFO - 2017-07-07 18:21:26 --> Helper loaded: url_helper
INFO - 2017-07-07 18:21:26 --> Model Class Initialized
INFO - 2017-07-07 18:21:26 --> Final output sent to browser
DEBUG - 2017-07-07 18:21:26 --> Total execution time: 0.0650
ERROR - 2017-07-07 18:22:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:22:15 --> Config Class Initialized
INFO - 2017-07-07 18:22:15 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:22:15 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:22:15 --> Utf8 Class Initialized
INFO - 2017-07-07 18:22:15 --> URI Class Initialized
INFO - 2017-07-07 18:22:15 --> Router Class Initialized
INFO - 2017-07-07 18:22:15 --> Output Class Initialized
INFO - 2017-07-07 18:22:15 --> Security Class Initialized
DEBUG - 2017-07-07 18:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:22:15 --> Input Class Initialized
INFO - 2017-07-07 18:22:15 --> Language Class Initialized
INFO - 2017-07-07 18:22:15 --> Loader Class Initialized
INFO - 2017-07-07 18:22:15 --> Controller Class Initialized
INFO - 2017-07-07 18:22:15 --> Database Driver Class Initialized
INFO - 2017-07-07 18:22:15 --> Model Class Initialized
INFO - 2017-07-07 18:22:15 --> Helper loaded: form_helper
INFO - 2017-07-07 18:22:15 --> Helper loaded: url_helper
INFO - 2017-07-07 18:22:15 --> Model Class Initialized
INFO - 2017-07-07 18:22:15 --> Final output sent to browser
DEBUG - 2017-07-07 18:22:15 --> Total execution time: 0.0745
ERROR - 2017-07-07 18:22:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:22:16 --> Config Class Initialized
INFO - 2017-07-07 18:22:16 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:22:16 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:22:16 --> Utf8 Class Initialized
INFO - 2017-07-07 18:22:16 --> URI Class Initialized
INFO - 2017-07-07 18:22:16 --> Router Class Initialized
INFO - 2017-07-07 18:22:16 --> Output Class Initialized
INFO - 2017-07-07 18:22:16 --> Security Class Initialized
DEBUG - 2017-07-07 18:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:22:16 --> Input Class Initialized
INFO - 2017-07-07 18:22:16 --> Language Class Initialized
INFO - 2017-07-07 18:22:16 --> Loader Class Initialized
INFO - 2017-07-07 18:22:16 --> Controller Class Initialized
INFO - 2017-07-07 18:22:16 --> Database Driver Class Initialized
INFO - 2017-07-07 18:22:16 --> Model Class Initialized
INFO - 2017-07-07 18:22:16 --> Helper loaded: form_helper
INFO - 2017-07-07 18:22:16 --> Helper loaded: url_helper
INFO - 2017-07-07 18:22:16 --> Model Class Initialized
INFO - 2017-07-07 18:22:16 --> Final output sent to browser
DEBUG - 2017-07-07 18:22:16 --> Total execution time: 0.0475
ERROR - 2017-07-07 18:22:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:22:20 --> Config Class Initialized
INFO - 2017-07-07 18:22:20 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:22:20 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:22:20 --> Utf8 Class Initialized
INFO - 2017-07-07 18:22:20 --> URI Class Initialized
INFO - 2017-07-07 18:22:20 --> Router Class Initialized
INFO - 2017-07-07 18:22:20 --> Output Class Initialized
INFO - 2017-07-07 18:22:20 --> Security Class Initialized
DEBUG - 2017-07-07 18:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:22:20 --> Input Class Initialized
INFO - 2017-07-07 18:22:20 --> Language Class Initialized
INFO - 2017-07-07 18:22:20 --> Loader Class Initialized
INFO - 2017-07-07 18:22:20 --> Controller Class Initialized
INFO - 2017-07-07 18:22:20 --> Database Driver Class Initialized
INFO - 2017-07-07 18:22:20 --> Model Class Initialized
INFO - 2017-07-07 18:22:20 --> Helper loaded: form_helper
INFO - 2017-07-07 18:22:20 --> Helper loaded: url_helper
INFO - 2017-07-07 18:22:20 --> Model Class Initialized
INFO - 2017-07-07 18:22:20 --> Final output sent to browser
DEBUG - 2017-07-07 18:22:20 --> Total execution time: 0.0500
ERROR - 2017-07-07 18:22:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:22:24 --> Config Class Initialized
INFO - 2017-07-07 18:22:24 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:22:24 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:22:24 --> Utf8 Class Initialized
INFO - 2017-07-07 18:22:24 --> URI Class Initialized
INFO - 2017-07-07 18:22:24 --> Router Class Initialized
INFO - 2017-07-07 18:22:24 --> Output Class Initialized
INFO - 2017-07-07 18:22:24 --> Security Class Initialized
DEBUG - 2017-07-07 18:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:22:24 --> Input Class Initialized
INFO - 2017-07-07 18:22:24 --> Language Class Initialized
INFO - 2017-07-07 18:22:24 --> Loader Class Initialized
INFO - 2017-07-07 18:22:24 --> Controller Class Initialized
INFO - 2017-07-07 18:22:24 --> Database Driver Class Initialized
INFO - 2017-07-07 18:22:24 --> Model Class Initialized
INFO - 2017-07-07 18:22:24 --> Helper loaded: form_helper
INFO - 2017-07-07 18:22:24 --> Helper loaded: url_helper
INFO - 2017-07-07 18:22:24 --> Model Class Initialized
INFO - 2017-07-07 18:22:24 --> Final output sent to browser
DEBUG - 2017-07-07 18:22:24 --> Total execution time: 0.0670
ERROR - 2017-07-07 18:22:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:22:24 --> Config Class Initialized
INFO - 2017-07-07 18:22:24 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:22:24 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:22:24 --> Utf8 Class Initialized
INFO - 2017-07-07 18:22:24 --> URI Class Initialized
INFO - 2017-07-07 18:22:24 --> Router Class Initialized
INFO - 2017-07-07 18:22:24 --> Output Class Initialized
INFO - 2017-07-07 18:22:24 --> Security Class Initialized
DEBUG - 2017-07-07 18:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:22:24 --> Input Class Initialized
INFO - 2017-07-07 18:22:24 --> Language Class Initialized
INFO - 2017-07-07 18:22:24 --> Loader Class Initialized
INFO - 2017-07-07 18:22:24 --> Controller Class Initialized
INFO - 2017-07-07 18:22:24 --> Database Driver Class Initialized
INFO - 2017-07-07 18:22:24 --> Model Class Initialized
INFO - 2017-07-07 18:22:24 --> Helper loaded: form_helper
INFO - 2017-07-07 18:22:24 --> Helper loaded: url_helper
INFO - 2017-07-07 18:22:24 --> Model Class Initialized
INFO - 2017-07-07 18:22:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 18:22:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 18:22:24 --> Final output sent to browser
DEBUG - 2017-07-07 18:22:24 --> Total execution time: 0.1100
ERROR - 2017-07-07 18:26:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:26:21 --> Config Class Initialized
INFO - 2017-07-07 18:26:21 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:26:21 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:26:21 --> Utf8 Class Initialized
INFO - 2017-07-07 18:26:21 --> URI Class Initialized
INFO - 2017-07-07 18:26:21 --> Router Class Initialized
INFO - 2017-07-07 18:26:21 --> Output Class Initialized
INFO - 2017-07-07 18:26:21 --> Security Class Initialized
DEBUG - 2017-07-07 18:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:26:21 --> Input Class Initialized
INFO - 2017-07-07 18:26:21 --> Language Class Initialized
INFO - 2017-07-07 18:26:21 --> Loader Class Initialized
INFO - 2017-07-07 18:26:21 --> Controller Class Initialized
INFO - 2017-07-07 18:26:21 --> Database Driver Class Initialized
INFO - 2017-07-07 18:26:21 --> Model Class Initialized
INFO - 2017-07-07 18:26:21 --> Helper loaded: form_helper
INFO - 2017-07-07 18:26:21 --> Helper loaded: url_helper
INFO - 2017-07-07 18:26:21 --> Model Class Initialized
INFO - 2017-07-07 18:26:21 --> Final output sent to browser
DEBUG - 2017-07-07 18:26:21 --> Total execution time: 0.1745
ERROR - 2017-07-07 18:26:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:26:22 --> Config Class Initialized
INFO - 2017-07-07 18:26:22 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:26:22 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:26:22 --> Utf8 Class Initialized
INFO - 2017-07-07 18:26:22 --> URI Class Initialized
INFO - 2017-07-07 18:26:22 --> Router Class Initialized
INFO - 2017-07-07 18:26:22 --> Output Class Initialized
INFO - 2017-07-07 18:26:22 --> Security Class Initialized
DEBUG - 2017-07-07 18:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:26:22 --> Input Class Initialized
INFO - 2017-07-07 18:26:22 --> Language Class Initialized
INFO - 2017-07-07 18:26:22 --> Loader Class Initialized
INFO - 2017-07-07 18:26:22 --> Controller Class Initialized
INFO - 2017-07-07 18:26:22 --> Database Driver Class Initialized
INFO - 2017-07-07 18:26:22 --> Model Class Initialized
INFO - 2017-07-07 18:26:22 --> Helper loaded: form_helper
INFO - 2017-07-07 18:26:22 --> Helper loaded: url_helper
INFO - 2017-07-07 18:26:22 --> Model Class Initialized
INFO - 2017-07-07 18:26:22 --> Final output sent to browser
DEBUG - 2017-07-07 18:26:22 --> Total execution time: 0.0525
ERROR - 2017-07-07 18:26:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:26:24 --> Config Class Initialized
INFO - 2017-07-07 18:26:24 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:26:24 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:26:24 --> Utf8 Class Initialized
INFO - 2017-07-07 18:26:24 --> URI Class Initialized
INFO - 2017-07-07 18:26:24 --> Router Class Initialized
INFO - 2017-07-07 18:26:24 --> Output Class Initialized
INFO - 2017-07-07 18:26:24 --> Security Class Initialized
DEBUG - 2017-07-07 18:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:26:24 --> Input Class Initialized
INFO - 2017-07-07 18:26:24 --> Language Class Initialized
INFO - 2017-07-07 18:26:24 --> Loader Class Initialized
INFO - 2017-07-07 18:26:24 --> Controller Class Initialized
INFO - 2017-07-07 18:26:24 --> Database Driver Class Initialized
INFO - 2017-07-07 18:26:24 --> Model Class Initialized
INFO - 2017-07-07 18:26:24 --> Helper loaded: form_helper
INFO - 2017-07-07 18:26:24 --> Helper loaded: url_helper
INFO - 2017-07-07 18:26:24 --> Model Class Initialized
INFO - 2017-07-07 18:26:24 --> Final output sent to browser
DEBUG - 2017-07-07 18:26:24 --> Total execution time: 0.0525
ERROR - 2017-07-07 18:26:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:26:26 --> Config Class Initialized
INFO - 2017-07-07 18:26:26 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:26:26 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:26:26 --> Utf8 Class Initialized
INFO - 2017-07-07 18:26:26 --> URI Class Initialized
INFO - 2017-07-07 18:26:26 --> Router Class Initialized
INFO - 2017-07-07 18:26:26 --> Output Class Initialized
INFO - 2017-07-07 18:26:26 --> Security Class Initialized
DEBUG - 2017-07-07 18:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:26:26 --> Input Class Initialized
INFO - 2017-07-07 18:26:26 --> Language Class Initialized
INFO - 2017-07-07 18:26:26 --> Loader Class Initialized
INFO - 2017-07-07 18:26:26 --> Controller Class Initialized
INFO - 2017-07-07 18:26:26 --> Database Driver Class Initialized
INFO - 2017-07-07 18:26:26 --> Model Class Initialized
INFO - 2017-07-07 18:26:26 --> Helper loaded: form_helper
INFO - 2017-07-07 18:26:26 --> Helper loaded: url_helper
INFO - 2017-07-07 18:26:26 --> Model Class Initialized
INFO - 2017-07-07 18:26:26 --> Final output sent to browser
DEBUG - 2017-07-07 18:26:26 --> Total execution time: 0.0500
ERROR - 2017-07-07 18:26:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:26:28 --> Config Class Initialized
INFO - 2017-07-07 18:26:28 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:26:28 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:26:28 --> Utf8 Class Initialized
INFO - 2017-07-07 18:26:28 --> URI Class Initialized
INFO - 2017-07-07 18:26:28 --> Router Class Initialized
INFO - 2017-07-07 18:26:28 --> Output Class Initialized
INFO - 2017-07-07 18:26:28 --> Security Class Initialized
DEBUG - 2017-07-07 18:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:26:28 --> Input Class Initialized
INFO - 2017-07-07 18:26:28 --> Language Class Initialized
INFO - 2017-07-07 18:26:28 --> Loader Class Initialized
INFO - 2017-07-07 18:26:28 --> Controller Class Initialized
INFO - 2017-07-07 18:26:28 --> Database Driver Class Initialized
INFO - 2017-07-07 18:26:28 --> Model Class Initialized
INFO - 2017-07-07 18:26:28 --> Helper loaded: form_helper
INFO - 2017-07-07 18:26:28 --> Helper loaded: url_helper
INFO - 2017-07-07 18:26:28 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 18:26:28 --> Model Class Initialized
INFO - 2017-07-07 18:26:28 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-07 18:26:28 --> Final output sent to browser
DEBUG - 2017-07-07 18:26:28 --> Total execution time: 0.0930
ERROR - 2017-07-07 18:26:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:26:31 --> Config Class Initialized
INFO - 2017-07-07 18:26:31 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:26:31 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:26:31 --> Utf8 Class Initialized
INFO - 2017-07-07 18:26:31 --> URI Class Initialized
INFO - 2017-07-07 18:26:31 --> Router Class Initialized
INFO - 2017-07-07 18:26:31 --> Output Class Initialized
INFO - 2017-07-07 18:26:31 --> Security Class Initialized
DEBUG - 2017-07-07 18:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:26:31 --> Input Class Initialized
INFO - 2017-07-07 18:26:31 --> Language Class Initialized
INFO - 2017-07-07 18:26:31 --> Loader Class Initialized
INFO - 2017-07-07 18:26:31 --> Controller Class Initialized
INFO - 2017-07-07 18:26:31 --> Database Driver Class Initialized
INFO - 2017-07-07 18:26:31 --> Model Class Initialized
INFO - 2017-07-07 18:26:31 --> Helper loaded: form_helper
INFO - 2017-07-07 18:26:31 --> Helper loaded: url_helper
INFO - 2017-07-07 18:26:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 18:26:31 --> Model Class Initialized
INFO - 2017-07-07 18:26:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 18:26:31 --> Final output sent to browser
DEBUG - 2017-07-07 18:26:31 --> Total execution time: 0.0780
ERROR - 2017-07-07 18:26:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:26:34 --> Config Class Initialized
INFO - 2017-07-07 18:26:34 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:26:34 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:26:34 --> Utf8 Class Initialized
INFO - 2017-07-07 18:26:34 --> URI Class Initialized
INFO - 2017-07-07 18:26:34 --> Router Class Initialized
INFO - 2017-07-07 18:26:34 --> Output Class Initialized
INFO - 2017-07-07 18:26:34 --> Security Class Initialized
DEBUG - 2017-07-07 18:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:26:34 --> Input Class Initialized
INFO - 2017-07-07 18:26:34 --> Language Class Initialized
INFO - 2017-07-07 18:26:34 --> Loader Class Initialized
INFO - 2017-07-07 18:26:34 --> Controller Class Initialized
INFO - 2017-07-07 18:26:34 --> Database Driver Class Initialized
INFO - 2017-07-07 18:26:34 --> Model Class Initialized
INFO - 2017-07-07 18:26:34 --> Helper loaded: form_helper
INFO - 2017-07-07 18:26:34 --> Helper loaded: url_helper
INFO - 2017-07-07 18:26:34 --> Model Class Initialized
INFO - 2017-07-07 18:26:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 18:26:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 18:26:34 --> Final output sent to browser
DEBUG - 2017-07-07 18:26:34 --> Total execution time: 0.0860
ERROR - 2017-07-07 18:27:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:27:40 --> Config Class Initialized
INFO - 2017-07-07 18:27:40 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:27:40 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:27:40 --> Utf8 Class Initialized
INFO - 2017-07-07 18:27:40 --> URI Class Initialized
INFO - 2017-07-07 18:27:40 --> Router Class Initialized
INFO - 2017-07-07 18:27:40 --> Output Class Initialized
INFO - 2017-07-07 18:27:40 --> Security Class Initialized
DEBUG - 2017-07-07 18:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:27:40 --> Input Class Initialized
INFO - 2017-07-07 18:27:40 --> Language Class Initialized
INFO - 2017-07-07 18:27:40 --> Loader Class Initialized
INFO - 2017-07-07 18:27:40 --> Controller Class Initialized
INFO - 2017-07-07 18:27:40 --> Database Driver Class Initialized
INFO - 2017-07-07 18:27:40 --> Model Class Initialized
INFO - 2017-07-07 18:27:40 --> Helper loaded: form_helper
INFO - 2017-07-07 18:27:40 --> Helper loaded: url_helper
INFO - 2017-07-07 18:27:40 --> Model Class Initialized
INFO - 2017-07-07 18:27:40 --> Final output sent to browser
DEBUG - 2017-07-07 18:27:40 --> Total execution time: 0.0450
ERROR - 2017-07-07 18:27:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:27:49 --> Config Class Initialized
INFO - 2017-07-07 18:27:49 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:27:49 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:27:49 --> Utf8 Class Initialized
INFO - 2017-07-07 18:27:49 --> URI Class Initialized
INFO - 2017-07-07 18:27:49 --> Router Class Initialized
INFO - 2017-07-07 18:27:49 --> Output Class Initialized
INFO - 2017-07-07 18:27:49 --> Security Class Initialized
DEBUG - 2017-07-07 18:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:27:49 --> Input Class Initialized
INFO - 2017-07-07 18:27:49 --> Language Class Initialized
INFO - 2017-07-07 18:27:49 --> Loader Class Initialized
INFO - 2017-07-07 18:27:49 --> Controller Class Initialized
INFO - 2017-07-07 18:27:49 --> Database Driver Class Initialized
INFO - 2017-07-07 18:27:49 --> Model Class Initialized
INFO - 2017-07-07 18:27:49 --> Helper loaded: form_helper
INFO - 2017-07-07 18:27:49 --> Helper loaded: url_helper
INFO - 2017-07-07 18:27:49 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 18:27:49 --> Model Class Initialized
INFO - 2017-07-07 18:27:49 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-07 18:27:49 --> Final output sent to browser
DEBUG - 2017-07-07 18:27:49 --> Total execution time: 0.1280
ERROR - 2017-07-07 18:27:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:27:52 --> Config Class Initialized
INFO - 2017-07-07 18:27:52 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:27:52 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:27:52 --> Utf8 Class Initialized
INFO - 2017-07-07 18:27:52 --> URI Class Initialized
INFO - 2017-07-07 18:27:52 --> Router Class Initialized
INFO - 2017-07-07 18:27:52 --> Output Class Initialized
INFO - 2017-07-07 18:27:52 --> Security Class Initialized
DEBUG - 2017-07-07 18:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:27:52 --> Input Class Initialized
INFO - 2017-07-07 18:27:52 --> Language Class Initialized
INFO - 2017-07-07 18:27:52 --> Loader Class Initialized
INFO - 2017-07-07 18:27:52 --> Controller Class Initialized
INFO - 2017-07-07 18:27:52 --> Database Driver Class Initialized
INFO - 2017-07-07 18:27:52 --> Model Class Initialized
INFO - 2017-07-07 18:27:52 --> Helper loaded: form_helper
INFO - 2017-07-07 18:27:52 --> Helper loaded: url_helper
INFO - 2017-07-07 18:27:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 18:27:52 --> Model Class Initialized
INFO - 2017-07-07 18:27:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 18:27:52 --> Final output sent to browser
DEBUG - 2017-07-07 18:27:52 --> Total execution time: 0.0600
ERROR - 2017-07-07 18:27:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:27:55 --> Config Class Initialized
INFO - 2017-07-07 18:27:55 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:27:55 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:27:55 --> Utf8 Class Initialized
INFO - 2017-07-07 18:27:55 --> URI Class Initialized
INFO - 2017-07-07 18:27:55 --> Router Class Initialized
INFO - 2017-07-07 18:27:55 --> Output Class Initialized
INFO - 2017-07-07 18:27:55 --> Security Class Initialized
DEBUG - 2017-07-07 18:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:27:55 --> Input Class Initialized
INFO - 2017-07-07 18:27:55 --> Language Class Initialized
INFO - 2017-07-07 18:27:55 --> Loader Class Initialized
INFO - 2017-07-07 18:27:55 --> Controller Class Initialized
INFO - 2017-07-07 18:27:55 --> Database Driver Class Initialized
INFO - 2017-07-07 18:27:55 --> Model Class Initialized
INFO - 2017-07-07 18:27:55 --> Helper loaded: form_helper
INFO - 2017-07-07 18:27:55 --> Helper loaded: url_helper
INFO - 2017-07-07 18:27:55 --> Model Class Initialized
INFO - 2017-07-07 18:27:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 18:27:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 18:27:55 --> Final output sent to browser
DEBUG - 2017-07-07 18:27:55 --> Total execution time: 0.1390
ERROR - 2017-07-07 18:27:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:27:57 --> Config Class Initialized
INFO - 2017-07-07 18:27:57 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:27:57 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:27:57 --> Utf8 Class Initialized
INFO - 2017-07-07 18:27:57 --> URI Class Initialized
INFO - 2017-07-07 18:27:57 --> Router Class Initialized
INFO - 2017-07-07 18:27:57 --> Output Class Initialized
INFO - 2017-07-07 18:27:57 --> Security Class Initialized
DEBUG - 2017-07-07 18:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:27:57 --> Input Class Initialized
INFO - 2017-07-07 18:27:57 --> Language Class Initialized
INFO - 2017-07-07 18:27:57 --> Loader Class Initialized
INFO - 2017-07-07 18:27:57 --> Controller Class Initialized
INFO - 2017-07-07 18:27:57 --> Database Driver Class Initialized
INFO - 2017-07-07 18:27:57 --> Model Class Initialized
INFO - 2017-07-07 18:27:57 --> Helper loaded: form_helper
INFO - 2017-07-07 18:27:57 --> Helper loaded: url_helper
INFO - 2017-07-07 18:27:57 --> Model Class Initialized
INFO - 2017-07-07 18:27:57 --> Final output sent to browser
DEBUG - 2017-07-07 18:27:57 --> Total execution time: 0.0650
ERROR - 2017-07-07 18:27:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:27:59 --> Config Class Initialized
INFO - 2017-07-07 18:27:59 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:27:59 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:27:59 --> Utf8 Class Initialized
INFO - 2017-07-07 18:27:59 --> URI Class Initialized
INFO - 2017-07-07 18:27:59 --> Router Class Initialized
INFO - 2017-07-07 18:27:59 --> Output Class Initialized
INFO - 2017-07-07 18:27:59 --> Security Class Initialized
DEBUG - 2017-07-07 18:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:27:59 --> Input Class Initialized
INFO - 2017-07-07 18:27:59 --> Language Class Initialized
INFO - 2017-07-07 18:27:59 --> Loader Class Initialized
INFO - 2017-07-07 18:27:59 --> Controller Class Initialized
INFO - 2017-07-07 18:27:59 --> Database Driver Class Initialized
INFO - 2017-07-07 18:27:59 --> Model Class Initialized
INFO - 2017-07-07 18:27:59 --> Helper loaded: form_helper
INFO - 2017-07-07 18:27:59 --> Helper loaded: url_helper
INFO - 2017-07-07 18:27:59 --> Model Class Initialized
INFO - 2017-07-07 18:27:59 --> Final output sent to browser
DEBUG - 2017-07-07 18:27:59 --> Total execution time: 0.1000
ERROR - 2017-07-07 18:27:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:27:59 --> Config Class Initialized
INFO - 2017-07-07 18:27:59 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:27:59 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:27:59 --> Utf8 Class Initialized
INFO - 2017-07-07 18:27:59 --> URI Class Initialized
INFO - 2017-07-07 18:27:59 --> Router Class Initialized
INFO - 2017-07-07 18:27:59 --> Output Class Initialized
INFO - 2017-07-07 18:27:59 --> Security Class Initialized
DEBUG - 2017-07-07 18:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:27:59 --> Input Class Initialized
INFO - 2017-07-07 18:27:59 --> Language Class Initialized
INFO - 2017-07-07 18:27:59 --> Loader Class Initialized
INFO - 2017-07-07 18:27:59 --> Controller Class Initialized
INFO - 2017-07-07 18:28:00 --> Database Driver Class Initialized
INFO - 2017-07-07 18:28:00 --> Model Class Initialized
INFO - 2017-07-07 18:28:00 --> Helper loaded: form_helper
INFO - 2017-07-07 18:28:00 --> Helper loaded: url_helper
INFO - 2017-07-07 18:28:00 --> Model Class Initialized
INFO - 2017-07-07 18:28:00 --> Final output sent to browser
DEBUG - 2017-07-07 18:28:00 --> Total execution time: 0.0500
ERROR - 2017-07-07 18:28:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:28:01 --> Config Class Initialized
INFO - 2017-07-07 18:28:01 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:28:01 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:28:01 --> Utf8 Class Initialized
INFO - 2017-07-07 18:28:01 --> URI Class Initialized
INFO - 2017-07-07 18:28:01 --> Router Class Initialized
INFO - 2017-07-07 18:28:01 --> Output Class Initialized
INFO - 2017-07-07 18:28:01 --> Security Class Initialized
DEBUG - 2017-07-07 18:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:28:01 --> Input Class Initialized
INFO - 2017-07-07 18:28:01 --> Language Class Initialized
INFO - 2017-07-07 18:28:01 --> Loader Class Initialized
INFO - 2017-07-07 18:28:01 --> Controller Class Initialized
INFO - 2017-07-07 18:28:01 --> Database Driver Class Initialized
INFO - 2017-07-07 18:28:01 --> Model Class Initialized
INFO - 2017-07-07 18:28:01 --> Helper loaded: form_helper
INFO - 2017-07-07 18:28:01 --> Helper loaded: url_helper
INFO - 2017-07-07 18:28:01 --> Model Class Initialized
INFO - 2017-07-07 18:28:01 --> Final output sent to browser
DEBUG - 2017-07-07 18:28:01 --> Total execution time: 0.0650
ERROR - 2017-07-07 18:28:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:28:04 --> Config Class Initialized
INFO - 2017-07-07 18:28:04 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:28:04 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:28:04 --> Utf8 Class Initialized
INFO - 2017-07-07 18:28:04 --> URI Class Initialized
INFO - 2017-07-07 18:28:04 --> Router Class Initialized
INFO - 2017-07-07 18:28:04 --> Output Class Initialized
INFO - 2017-07-07 18:28:04 --> Security Class Initialized
DEBUG - 2017-07-07 18:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:28:04 --> Input Class Initialized
INFO - 2017-07-07 18:28:04 --> Language Class Initialized
INFO - 2017-07-07 18:28:04 --> Loader Class Initialized
INFO - 2017-07-07 18:28:04 --> Controller Class Initialized
INFO - 2017-07-07 18:28:04 --> Database Driver Class Initialized
INFO - 2017-07-07 18:28:04 --> Model Class Initialized
INFO - 2017-07-07 18:28:04 --> Helper loaded: form_helper
INFO - 2017-07-07 18:28:04 --> Helper loaded: url_helper
INFO - 2017-07-07 18:28:04 --> Model Class Initialized
INFO - 2017-07-07 18:28:04 --> Final output sent to browser
DEBUG - 2017-07-07 18:28:04 --> Total execution time: 0.0530
ERROR - 2017-07-07 18:28:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:28:45 --> Config Class Initialized
INFO - 2017-07-07 18:28:45 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:28:45 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:28:45 --> Utf8 Class Initialized
INFO - 2017-07-07 18:28:45 --> URI Class Initialized
INFO - 2017-07-07 18:28:45 --> Router Class Initialized
INFO - 2017-07-07 18:28:45 --> Output Class Initialized
INFO - 2017-07-07 18:28:45 --> Security Class Initialized
DEBUG - 2017-07-07 18:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:28:45 --> Input Class Initialized
INFO - 2017-07-07 18:28:45 --> Language Class Initialized
INFO - 2017-07-07 18:28:45 --> Loader Class Initialized
INFO - 2017-07-07 18:28:45 --> Controller Class Initialized
INFO - 2017-07-07 18:28:45 --> Database Driver Class Initialized
INFO - 2017-07-07 18:28:45 --> Model Class Initialized
INFO - 2017-07-07 18:28:45 --> Helper loaded: form_helper
INFO - 2017-07-07 18:28:45 --> Helper loaded: url_helper
INFO - 2017-07-07 18:28:45 --> Model Class Initialized
INFO - 2017-07-07 18:28:45 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 18:28:45 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 18:28:45 --> Final output sent to browser
DEBUG - 2017-07-07 18:28:45 --> Total execution time: 0.1270
ERROR - 2017-07-07 18:29:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:29:02 --> Config Class Initialized
INFO - 2017-07-07 18:29:02 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:29:02 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:29:02 --> Utf8 Class Initialized
INFO - 2017-07-07 18:29:02 --> URI Class Initialized
INFO - 2017-07-07 18:29:02 --> Router Class Initialized
INFO - 2017-07-07 18:29:02 --> Output Class Initialized
INFO - 2017-07-07 18:29:02 --> Security Class Initialized
DEBUG - 2017-07-07 18:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:29:02 --> Input Class Initialized
INFO - 2017-07-07 18:29:02 --> Language Class Initialized
INFO - 2017-07-07 18:29:02 --> Loader Class Initialized
INFO - 2017-07-07 18:29:02 --> Controller Class Initialized
INFO - 2017-07-07 18:29:02 --> Database Driver Class Initialized
INFO - 2017-07-07 18:29:02 --> Model Class Initialized
INFO - 2017-07-07 18:29:02 --> Helper loaded: form_helper
INFO - 2017-07-07 18:29:02 --> Helper loaded: url_helper
INFO - 2017-07-07 18:29:02 --> Model Class Initialized
INFO - 2017-07-07 18:29:03 --> Final output sent to browser
DEBUG - 2017-07-07 18:29:03 --> Total execution time: 0.2550
ERROR - 2017-07-07 18:29:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:29:03 --> Config Class Initialized
INFO - 2017-07-07 18:29:03 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:29:03 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:29:03 --> Utf8 Class Initialized
INFO - 2017-07-07 18:29:03 --> URI Class Initialized
INFO - 2017-07-07 18:29:03 --> Router Class Initialized
INFO - 2017-07-07 18:29:04 --> Output Class Initialized
INFO - 2017-07-07 18:29:04 --> Security Class Initialized
DEBUG - 2017-07-07 18:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:29:04 --> Input Class Initialized
INFO - 2017-07-07 18:29:04 --> Language Class Initialized
INFO - 2017-07-07 18:29:04 --> Loader Class Initialized
INFO - 2017-07-07 18:29:04 --> Controller Class Initialized
INFO - 2017-07-07 18:29:04 --> Database Driver Class Initialized
INFO - 2017-07-07 18:29:04 --> Model Class Initialized
INFO - 2017-07-07 18:29:04 --> Helper loaded: form_helper
INFO - 2017-07-07 18:29:04 --> Helper loaded: url_helper
INFO - 2017-07-07 18:29:04 --> Model Class Initialized
INFO - 2017-07-07 18:29:04 --> Final output sent to browser
DEBUG - 2017-07-07 18:29:04 --> Total execution time: 0.0400
ERROR - 2017-07-07 18:29:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:29:05 --> Config Class Initialized
INFO - 2017-07-07 18:29:05 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:29:05 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:29:05 --> Utf8 Class Initialized
INFO - 2017-07-07 18:29:05 --> URI Class Initialized
INFO - 2017-07-07 18:29:05 --> Router Class Initialized
INFO - 2017-07-07 18:29:05 --> Output Class Initialized
INFO - 2017-07-07 18:29:05 --> Security Class Initialized
DEBUG - 2017-07-07 18:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:29:05 --> Input Class Initialized
INFO - 2017-07-07 18:29:05 --> Language Class Initialized
INFO - 2017-07-07 18:29:05 --> Loader Class Initialized
INFO - 2017-07-07 18:29:05 --> Controller Class Initialized
INFO - 2017-07-07 18:29:05 --> Database Driver Class Initialized
INFO - 2017-07-07 18:29:05 --> Model Class Initialized
INFO - 2017-07-07 18:29:05 --> Helper loaded: form_helper
INFO - 2017-07-07 18:29:05 --> Helper loaded: url_helper
INFO - 2017-07-07 18:29:05 --> Model Class Initialized
INFO - 2017-07-07 18:29:05 --> Final output sent to browser
DEBUG - 2017-07-07 18:29:05 --> Total execution time: 0.0575
ERROR - 2017-07-07 18:29:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:29:08 --> Config Class Initialized
INFO - 2017-07-07 18:29:08 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:29:08 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:29:08 --> Utf8 Class Initialized
INFO - 2017-07-07 18:29:08 --> URI Class Initialized
INFO - 2017-07-07 18:29:08 --> Router Class Initialized
INFO - 2017-07-07 18:29:08 --> Output Class Initialized
INFO - 2017-07-07 18:29:08 --> Security Class Initialized
DEBUG - 2017-07-07 18:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:29:08 --> Input Class Initialized
INFO - 2017-07-07 18:29:08 --> Language Class Initialized
INFO - 2017-07-07 18:29:08 --> Loader Class Initialized
INFO - 2017-07-07 18:29:08 --> Controller Class Initialized
INFO - 2017-07-07 18:29:08 --> Database Driver Class Initialized
INFO - 2017-07-07 18:29:08 --> Model Class Initialized
INFO - 2017-07-07 18:29:08 --> Helper loaded: form_helper
INFO - 2017-07-07 18:29:08 --> Helper loaded: url_helper
INFO - 2017-07-07 18:29:08 --> Model Class Initialized
INFO - 2017-07-07 18:29:08 --> Final output sent to browser
DEBUG - 2017-07-07 18:29:08 --> Total execution time: 0.0480
ERROR - 2017-07-07 18:30:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:30:50 --> Config Class Initialized
INFO - 2017-07-07 18:30:50 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:30:50 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:30:50 --> Utf8 Class Initialized
INFO - 2017-07-07 18:30:50 --> URI Class Initialized
INFO - 2017-07-07 18:30:50 --> Router Class Initialized
INFO - 2017-07-07 18:30:50 --> Output Class Initialized
INFO - 2017-07-07 18:30:50 --> Security Class Initialized
DEBUG - 2017-07-07 18:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:30:50 --> Input Class Initialized
INFO - 2017-07-07 18:30:50 --> Language Class Initialized
INFO - 2017-07-07 18:30:50 --> Loader Class Initialized
INFO - 2017-07-07 18:30:50 --> Controller Class Initialized
INFO - 2017-07-07 18:30:50 --> Database Driver Class Initialized
INFO - 2017-07-07 18:30:50 --> Model Class Initialized
INFO - 2017-07-07 18:30:50 --> Helper loaded: form_helper
INFO - 2017-07-07 18:30:50 --> Helper loaded: url_helper
INFO - 2017-07-07 18:30:50 --> Model Class Initialized
INFO - 2017-07-07 18:30:51 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 18:30:51 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 18:30:51 --> Final output sent to browser
DEBUG - 2017-07-07 18:30:51 --> Total execution time: 0.6750
ERROR - 2017-07-07 18:30:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:30:51 --> Config Class Initialized
INFO - 2017-07-07 18:30:51 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:30:51 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:30:51 --> Utf8 Class Initialized
INFO - 2017-07-07 18:30:51 --> URI Class Initialized
INFO - 2017-07-07 18:30:51 --> Router Class Initialized
INFO - 2017-07-07 18:30:51 --> Output Class Initialized
INFO - 2017-07-07 18:30:51 --> Security Class Initialized
DEBUG - 2017-07-07 18:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:30:51 --> Input Class Initialized
INFO - 2017-07-07 18:30:51 --> Language Class Initialized
INFO - 2017-07-07 18:30:51 --> Loader Class Initialized
INFO - 2017-07-07 18:30:51 --> Controller Class Initialized
INFO - 2017-07-07 18:30:51 --> Database Driver Class Initialized
INFO - 2017-07-07 18:30:51 --> Model Class Initialized
INFO - 2017-07-07 18:30:51 --> Helper loaded: form_helper
INFO - 2017-07-07 18:30:51 --> Helper loaded: url_helper
INFO - 2017-07-07 18:30:51 --> Model Class Initialized
INFO - 2017-07-07 18:30:51 --> Final output sent to browser
DEBUG - 2017-07-07 18:30:51 --> Total execution time: 0.1190
ERROR - 2017-07-07 18:30:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:30:52 --> Config Class Initialized
INFO - 2017-07-07 18:30:52 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:30:52 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:30:52 --> Utf8 Class Initialized
INFO - 2017-07-07 18:30:52 --> URI Class Initialized
INFO - 2017-07-07 18:30:52 --> Router Class Initialized
INFO - 2017-07-07 18:30:52 --> Output Class Initialized
INFO - 2017-07-07 18:30:52 --> Security Class Initialized
DEBUG - 2017-07-07 18:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:30:52 --> Input Class Initialized
INFO - 2017-07-07 18:30:52 --> Language Class Initialized
INFO - 2017-07-07 18:30:52 --> Loader Class Initialized
INFO - 2017-07-07 18:30:52 --> Controller Class Initialized
INFO - 2017-07-07 18:30:52 --> Database Driver Class Initialized
INFO - 2017-07-07 18:30:52 --> Model Class Initialized
INFO - 2017-07-07 18:30:52 --> Helper loaded: form_helper
INFO - 2017-07-07 18:30:52 --> Helper loaded: url_helper
INFO - 2017-07-07 18:30:52 --> Model Class Initialized
INFO - 2017-07-07 18:30:52 --> Final output sent to browser
DEBUG - 2017-07-07 18:30:52 --> Total execution time: 0.0465
ERROR - 2017-07-07 18:30:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:30:56 --> Config Class Initialized
INFO - 2017-07-07 18:30:56 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:30:56 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:30:56 --> Utf8 Class Initialized
INFO - 2017-07-07 18:30:56 --> URI Class Initialized
INFO - 2017-07-07 18:30:56 --> Router Class Initialized
INFO - 2017-07-07 18:30:56 --> Output Class Initialized
INFO - 2017-07-07 18:30:56 --> Security Class Initialized
DEBUG - 2017-07-07 18:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:30:56 --> Input Class Initialized
INFO - 2017-07-07 18:30:56 --> Language Class Initialized
INFO - 2017-07-07 18:30:56 --> Loader Class Initialized
INFO - 2017-07-07 18:30:56 --> Controller Class Initialized
INFO - 2017-07-07 18:30:56 --> Database Driver Class Initialized
INFO - 2017-07-07 18:30:56 --> Model Class Initialized
INFO - 2017-07-07 18:30:56 --> Helper loaded: form_helper
INFO - 2017-07-07 18:30:56 --> Helper loaded: url_helper
INFO - 2017-07-07 18:30:56 --> Model Class Initialized
INFO - 2017-07-07 18:30:56 --> Final output sent to browser
DEBUG - 2017-07-07 18:30:56 --> Total execution time: 0.0475
ERROR - 2017-07-07 18:30:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:30:59 --> Config Class Initialized
INFO - 2017-07-07 18:30:59 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:30:59 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:30:59 --> Utf8 Class Initialized
INFO - 2017-07-07 18:30:59 --> URI Class Initialized
INFO - 2017-07-07 18:30:59 --> Router Class Initialized
INFO - 2017-07-07 18:30:59 --> Output Class Initialized
INFO - 2017-07-07 18:30:59 --> Security Class Initialized
DEBUG - 2017-07-07 18:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:30:59 --> Input Class Initialized
INFO - 2017-07-07 18:30:59 --> Language Class Initialized
INFO - 2017-07-07 18:30:59 --> Loader Class Initialized
INFO - 2017-07-07 18:30:59 --> Controller Class Initialized
INFO - 2017-07-07 18:30:59 --> Database Driver Class Initialized
INFO - 2017-07-07 18:30:59 --> Model Class Initialized
INFO - 2017-07-07 18:30:59 --> Helper loaded: form_helper
INFO - 2017-07-07 18:30:59 --> Helper loaded: url_helper
INFO - 2017-07-07 18:30:59 --> Model Class Initialized
INFO - 2017-07-07 18:30:59 --> Final output sent to browser
DEBUG - 2017-07-07 18:30:59 --> Total execution time: 0.0525
ERROR - 2017-07-07 18:32:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:32:54 --> Config Class Initialized
INFO - 2017-07-07 18:32:54 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:32:54 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:32:54 --> Utf8 Class Initialized
INFO - 2017-07-07 18:32:54 --> URI Class Initialized
INFO - 2017-07-07 18:32:54 --> Router Class Initialized
INFO - 2017-07-07 18:32:54 --> Output Class Initialized
INFO - 2017-07-07 18:32:54 --> Security Class Initialized
DEBUG - 2017-07-07 18:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:32:54 --> Input Class Initialized
INFO - 2017-07-07 18:32:54 --> Language Class Initialized
INFO - 2017-07-07 18:32:54 --> Loader Class Initialized
INFO - 2017-07-07 18:32:54 --> Controller Class Initialized
INFO - 2017-07-07 18:32:54 --> Database Driver Class Initialized
INFO - 2017-07-07 18:32:54 --> Model Class Initialized
INFO - 2017-07-07 18:32:54 --> Helper loaded: form_helper
INFO - 2017-07-07 18:32:54 --> Helper loaded: url_helper
INFO - 2017-07-07 18:32:54 --> Model Class Initialized
INFO - 2017-07-07 18:32:54 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 18:32:54 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 18:32:54 --> Final output sent to browser
DEBUG - 2017-07-07 18:32:54 --> Total execution time: 0.1010
ERROR - 2017-07-07 18:33:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:33:09 --> Config Class Initialized
INFO - 2017-07-07 18:33:09 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:33:09 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:33:09 --> Utf8 Class Initialized
INFO - 2017-07-07 18:33:09 --> URI Class Initialized
INFO - 2017-07-07 18:33:09 --> Router Class Initialized
INFO - 2017-07-07 18:33:09 --> Output Class Initialized
INFO - 2017-07-07 18:33:09 --> Security Class Initialized
DEBUG - 2017-07-07 18:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:33:09 --> Input Class Initialized
INFO - 2017-07-07 18:33:09 --> Language Class Initialized
INFO - 2017-07-07 18:33:09 --> Loader Class Initialized
INFO - 2017-07-07 18:33:09 --> Controller Class Initialized
INFO - 2017-07-07 18:33:09 --> Database Driver Class Initialized
INFO - 2017-07-07 18:33:09 --> Model Class Initialized
INFO - 2017-07-07 18:33:09 --> Helper loaded: form_helper
INFO - 2017-07-07 18:33:09 --> Helper loaded: url_helper
INFO - 2017-07-07 18:33:09 --> Model Class Initialized
INFO - 2017-07-07 18:33:09 --> Final output sent to browser
DEBUG - 2017-07-07 18:33:09 --> Total execution time: 0.0750
ERROR - 2017-07-07 18:33:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:33:10 --> Config Class Initialized
INFO - 2017-07-07 18:33:10 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:33:10 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:33:10 --> Utf8 Class Initialized
INFO - 2017-07-07 18:33:10 --> URI Class Initialized
INFO - 2017-07-07 18:33:10 --> Router Class Initialized
INFO - 2017-07-07 18:33:10 --> Output Class Initialized
INFO - 2017-07-07 18:33:10 --> Security Class Initialized
DEBUG - 2017-07-07 18:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:33:10 --> Input Class Initialized
INFO - 2017-07-07 18:33:10 --> Language Class Initialized
INFO - 2017-07-07 18:33:10 --> Loader Class Initialized
INFO - 2017-07-07 18:33:10 --> Controller Class Initialized
INFO - 2017-07-07 18:33:10 --> Database Driver Class Initialized
INFO - 2017-07-07 18:33:10 --> Model Class Initialized
INFO - 2017-07-07 18:33:10 --> Helper loaded: form_helper
INFO - 2017-07-07 18:33:10 --> Helper loaded: url_helper
INFO - 2017-07-07 18:33:10 --> Model Class Initialized
INFO - 2017-07-07 18:33:10 --> Final output sent to browser
DEBUG - 2017-07-07 18:33:10 --> Total execution time: 0.0425
ERROR - 2017-07-07 18:33:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:33:13 --> Config Class Initialized
INFO - 2017-07-07 18:33:13 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:33:13 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:33:13 --> Utf8 Class Initialized
INFO - 2017-07-07 18:33:13 --> URI Class Initialized
INFO - 2017-07-07 18:33:13 --> Router Class Initialized
INFO - 2017-07-07 18:33:13 --> Output Class Initialized
INFO - 2017-07-07 18:33:13 --> Security Class Initialized
DEBUG - 2017-07-07 18:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:33:13 --> Input Class Initialized
INFO - 2017-07-07 18:33:13 --> Language Class Initialized
INFO - 2017-07-07 18:33:13 --> Loader Class Initialized
INFO - 2017-07-07 18:33:13 --> Controller Class Initialized
INFO - 2017-07-07 18:33:13 --> Database Driver Class Initialized
INFO - 2017-07-07 18:33:13 --> Model Class Initialized
INFO - 2017-07-07 18:33:13 --> Helper loaded: form_helper
INFO - 2017-07-07 18:33:13 --> Helper loaded: url_helper
INFO - 2017-07-07 18:33:13 --> Model Class Initialized
INFO - 2017-07-07 18:33:13 --> Final output sent to browser
DEBUG - 2017-07-07 18:33:13 --> Total execution time: 0.0710
ERROR - 2017-07-07 18:33:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:33:15 --> Config Class Initialized
INFO - 2017-07-07 18:33:15 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:33:15 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:33:15 --> Utf8 Class Initialized
INFO - 2017-07-07 18:33:15 --> URI Class Initialized
INFO - 2017-07-07 18:33:15 --> Router Class Initialized
INFO - 2017-07-07 18:33:15 --> Output Class Initialized
INFO - 2017-07-07 18:33:15 --> Security Class Initialized
DEBUG - 2017-07-07 18:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:33:15 --> Input Class Initialized
INFO - 2017-07-07 18:33:15 --> Language Class Initialized
INFO - 2017-07-07 18:33:15 --> Loader Class Initialized
INFO - 2017-07-07 18:33:15 --> Controller Class Initialized
INFO - 2017-07-07 18:33:15 --> Database Driver Class Initialized
INFO - 2017-07-07 18:33:15 --> Model Class Initialized
INFO - 2017-07-07 18:33:15 --> Helper loaded: form_helper
INFO - 2017-07-07 18:33:15 --> Helper loaded: url_helper
INFO - 2017-07-07 18:33:15 --> Model Class Initialized
INFO - 2017-07-07 18:33:15 --> Final output sent to browser
DEBUG - 2017-07-07 18:33:15 --> Total execution time: 0.0450
ERROR - 2017-07-07 18:34:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:34:47 --> Config Class Initialized
INFO - 2017-07-07 18:34:47 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:34:47 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:34:47 --> Utf8 Class Initialized
INFO - 2017-07-07 18:34:47 --> URI Class Initialized
INFO - 2017-07-07 18:34:47 --> Router Class Initialized
INFO - 2017-07-07 18:34:47 --> Output Class Initialized
INFO - 2017-07-07 18:34:47 --> Security Class Initialized
DEBUG - 2017-07-07 18:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:34:47 --> Input Class Initialized
INFO - 2017-07-07 18:34:47 --> Language Class Initialized
INFO - 2017-07-07 18:34:47 --> Loader Class Initialized
INFO - 2017-07-07 18:34:47 --> Controller Class Initialized
INFO - 2017-07-07 18:34:47 --> Database Driver Class Initialized
INFO - 2017-07-07 18:34:47 --> Model Class Initialized
INFO - 2017-07-07 18:34:47 --> Helper loaded: form_helper
INFO - 2017-07-07 18:34:47 --> Helper loaded: url_helper
INFO - 2017-07-07 18:34:47 --> Model Class Initialized
INFO - 2017-07-07 18:34:47 --> Final output sent to browser
DEBUG - 2017-07-07 18:34:47 --> Total execution time: 0.0500
ERROR - 2017-07-07 18:35:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:35:19 --> Config Class Initialized
INFO - 2017-07-07 18:35:19 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:35:19 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:35:19 --> Utf8 Class Initialized
INFO - 2017-07-07 18:35:19 --> URI Class Initialized
INFO - 2017-07-07 18:35:19 --> Router Class Initialized
INFO - 2017-07-07 18:35:19 --> Output Class Initialized
INFO - 2017-07-07 18:35:19 --> Security Class Initialized
DEBUG - 2017-07-07 18:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:35:19 --> Input Class Initialized
INFO - 2017-07-07 18:35:19 --> Language Class Initialized
INFO - 2017-07-07 18:35:19 --> Loader Class Initialized
INFO - 2017-07-07 18:35:19 --> Controller Class Initialized
INFO - 2017-07-07 18:35:19 --> Database Driver Class Initialized
INFO - 2017-07-07 18:35:19 --> Model Class Initialized
INFO - 2017-07-07 18:35:19 --> Helper loaded: form_helper
INFO - 2017-07-07 18:35:19 --> Helper loaded: url_helper
INFO - 2017-07-07 18:35:19 --> Model Class Initialized
INFO - 2017-07-07 18:35:19 --> Final output sent to browser
DEBUG - 2017-07-07 18:35:19 --> Total execution time: 0.1575
ERROR - 2017-07-07 18:35:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:35:20 --> Config Class Initialized
INFO - 2017-07-07 18:35:20 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:35:20 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:35:20 --> Utf8 Class Initialized
INFO - 2017-07-07 18:35:20 --> URI Class Initialized
INFO - 2017-07-07 18:35:20 --> Router Class Initialized
INFO - 2017-07-07 18:35:20 --> Output Class Initialized
INFO - 2017-07-07 18:35:20 --> Security Class Initialized
DEBUG - 2017-07-07 18:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:35:20 --> Input Class Initialized
INFO - 2017-07-07 18:35:20 --> Language Class Initialized
INFO - 2017-07-07 18:35:20 --> Loader Class Initialized
INFO - 2017-07-07 18:35:20 --> Controller Class Initialized
INFO - 2017-07-07 18:35:20 --> Database Driver Class Initialized
INFO - 2017-07-07 18:35:20 --> Model Class Initialized
INFO - 2017-07-07 18:35:20 --> Helper loaded: form_helper
INFO - 2017-07-07 18:35:20 --> Helper loaded: url_helper
INFO - 2017-07-07 18:35:20 --> Model Class Initialized
INFO - 2017-07-07 18:35:20 --> Final output sent to browser
DEBUG - 2017-07-07 18:35:20 --> Total execution time: 0.0700
ERROR - 2017-07-07 18:35:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:35:28 --> Config Class Initialized
INFO - 2017-07-07 18:35:28 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:35:28 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:35:28 --> Utf8 Class Initialized
INFO - 2017-07-07 18:35:28 --> URI Class Initialized
INFO - 2017-07-07 18:35:28 --> Router Class Initialized
INFO - 2017-07-07 18:35:28 --> Output Class Initialized
INFO - 2017-07-07 18:35:28 --> Security Class Initialized
DEBUG - 2017-07-07 18:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:35:28 --> Input Class Initialized
INFO - 2017-07-07 18:35:28 --> Language Class Initialized
INFO - 2017-07-07 18:35:28 --> Loader Class Initialized
INFO - 2017-07-07 18:35:28 --> Controller Class Initialized
INFO - 2017-07-07 18:35:28 --> Database Driver Class Initialized
INFO - 2017-07-07 18:35:28 --> Model Class Initialized
INFO - 2017-07-07 18:35:28 --> Helper loaded: form_helper
INFO - 2017-07-07 18:35:28 --> Helper loaded: url_helper
INFO - 2017-07-07 18:35:28 --> Model Class Initialized
INFO - 2017-07-07 18:35:28 --> Final output sent to browser
DEBUG - 2017-07-07 18:35:28 --> Total execution time: 0.0900
ERROR - 2017-07-07 18:35:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:35:29 --> Config Class Initialized
INFO - 2017-07-07 18:35:29 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:35:29 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:35:29 --> Utf8 Class Initialized
INFO - 2017-07-07 18:35:29 --> URI Class Initialized
INFO - 2017-07-07 18:35:29 --> Router Class Initialized
INFO - 2017-07-07 18:35:29 --> Output Class Initialized
INFO - 2017-07-07 18:35:29 --> Security Class Initialized
DEBUG - 2017-07-07 18:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:35:29 --> Input Class Initialized
INFO - 2017-07-07 18:35:29 --> Language Class Initialized
INFO - 2017-07-07 18:35:29 --> Loader Class Initialized
INFO - 2017-07-07 18:35:29 --> Controller Class Initialized
INFO - 2017-07-07 18:35:29 --> Database Driver Class Initialized
INFO - 2017-07-07 18:35:29 --> Model Class Initialized
INFO - 2017-07-07 18:35:29 --> Helper loaded: form_helper
INFO - 2017-07-07 18:35:29 --> Helper loaded: url_helper
INFO - 2017-07-07 18:35:29 --> Model Class Initialized
INFO - 2017-07-07 18:35:29 --> Final output sent to browser
DEBUG - 2017-07-07 18:35:29 --> Total execution time: 0.1600
ERROR - 2017-07-07 18:36:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:36:16 --> Config Class Initialized
INFO - 2017-07-07 18:36:16 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:36:16 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:36:16 --> Utf8 Class Initialized
INFO - 2017-07-07 18:36:16 --> URI Class Initialized
INFO - 2017-07-07 18:36:16 --> Router Class Initialized
INFO - 2017-07-07 18:36:16 --> Output Class Initialized
INFO - 2017-07-07 18:36:16 --> Security Class Initialized
DEBUG - 2017-07-07 18:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:36:16 --> Input Class Initialized
INFO - 2017-07-07 18:36:16 --> Language Class Initialized
INFO - 2017-07-07 18:36:16 --> Loader Class Initialized
INFO - 2017-07-07 18:36:16 --> Controller Class Initialized
INFO - 2017-07-07 18:36:16 --> Database Driver Class Initialized
INFO - 2017-07-07 18:36:16 --> Model Class Initialized
INFO - 2017-07-07 18:36:16 --> Helper loaded: form_helper
INFO - 2017-07-07 18:36:16 --> Helper loaded: url_helper
INFO - 2017-07-07 18:36:16 --> Model Class Initialized
INFO - 2017-07-07 18:36:16 --> Final output sent to browser
DEBUG - 2017-07-07 18:36:16 --> Total execution time: 0.0750
ERROR - 2017-07-07 18:37:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:37:23 --> Config Class Initialized
INFO - 2017-07-07 18:37:23 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:37:23 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:37:23 --> Utf8 Class Initialized
INFO - 2017-07-07 18:37:23 --> URI Class Initialized
INFO - 2017-07-07 18:37:23 --> Router Class Initialized
INFO - 2017-07-07 18:37:23 --> Output Class Initialized
INFO - 2017-07-07 18:37:23 --> Security Class Initialized
DEBUG - 2017-07-07 18:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:37:23 --> Input Class Initialized
INFO - 2017-07-07 18:37:23 --> Language Class Initialized
INFO - 2017-07-07 18:37:23 --> Loader Class Initialized
INFO - 2017-07-07 18:37:23 --> Controller Class Initialized
INFO - 2017-07-07 18:37:23 --> Database Driver Class Initialized
INFO - 2017-07-07 18:37:23 --> Model Class Initialized
INFO - 2017-07-07 18:37:23 --> Helper loaded: form_helper
INFO - 2017-07-07 18:37:23 --> Helper loaded: url_helper
INFO - 2017-07-07 18:37:23 --> Model Class Initialized
INFO - 2017-07-07 18:37:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-07 18:37:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-07 18:37:23 --> Final output sent to browser
DEBUG - 2017-07-07 18:37:23 --> Total execution time: 0.0850
ERROR - 2017-07-07 18:37:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:37:26 --> Config Class Initialized
INFO - 2017-07-07 18:37:26 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:37:26 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:37:26 --> Utf8 Class Initialized
INFO - 2017-07-07 18:37:26 --> URI Class Initialized
INFO - 2017-07-07 18:37:26 --> Router Class Initialized
INFO - 2017-07-07 18:37:26 --> Output Class Initialized
INFO - 2017-07-07 18:37:26 --> Security Class Initialized
DEBUG - 2017-07-07 18:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:37:26 --> Input Class Initialized
INFO - 2017-07-07 18:37:26 --> Language Class Initialized
INFO - 2017-07-07 18:37:26 --> Loader Class Initialized
INFO - 2017-07-07 18:37:26 --> Controller Class Initialized
INFO - 2017-07-07 18:37:26 --> Database Driver Class Initialized
INFO - 2017-07-07 18:37:26 --> Model Class Initialized
INFO - 2017-07-07 18:37:26 --> Helper loaded: form_helper
INFO - 2017-07-07 18:37:26 --> Helper loaded: url_helper
INFO - 2017-07-07 18:37:26 --> Model Class Initialized
INFO - 2017-07-07 18:37:26 --> Final output sent to browser
DEBUG - 2017-07-07 18:37:26 --> Total execution time: 0.2475
ERROR - 2017-07-07 18:37:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:37:27 --> Config Class Initialized
INFO - 2017-07-07 18:37:27 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:37:27 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:37:27 --> Utf8 Class Initialized
INFO - 2017-07-07 18:37:27 --> URI Class Initialized
INFO - 2017-07-07 18:37:27 --> Router Class Initialized
INFO - 2017-07-07 18:37:27 --> Output Class Initialized
INFO - 2017-07-07 18:37:27 --> Security Class Initialized
DEBUG - 2017-07-07 18:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:37:27 --> Input Class Initialized
INFO - 2017-07-07 18:37:27 --> Language Class Initialized
INFO - 2017-07-07 18:37:27 --> Loader Class Initialized
INFO - 2017-07-07 18:37:27 --> Controller Class Initialized
INFO - 2017-07-07 18:37:27 --> Database Driver Class Initialized
INFO - 2017-07-07 18:37:27 --> Model Class Initialized
INFO - 2017-07-07 18:37:27 --> Helper loaded: form_helper
INFO - 2017-07-07 18:37:27 --> Helper loaded: url_helper
INFO - 2017-07-07 18:37:27 --> Model Class Initialized
INFO - 2017-07-07 18:37:27 --> Final output sent to browser
DEBUG - 2017-07-07 18:37:27 --> Total execution time: 0.0740
ERROR - 2017-07-07 18:37:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:37:30 --> Config Class Initialized
INFO - 2017-07-07 18:37:30 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:37:30 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:37:30 --> Utf8 Class Initialized
INFO - 2017-07-07 18:37:30 --> URI Class Initialized
INFO - 2017-07-07 18:37:30 --> Router Class Initialized
INFO - 2017-07-07 18:37:30 --> Output Class Initialized
INFO - 2017-07-07 18:37:30 --> Security Class Initialized
DEBUG - 2017-07-07 18:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:37:30 --> Input Class Initialized
INFO - 2017-07-07 18:37:30 --> Language Class Initialized
INFO - 2017-07-07 18:37:30 --> Loader Class Initialized
INFO - 2017-07-07 18:37:30 --> Controller Class Initialized
INFO - 2017-07-07 18:37:30 --> Database Driver Class Initialized
INFO - 2017-07-07 18:37:30 --> Model Class Initialized
INFO - 2017-07-07 18:37:30 --> Helper loaded: form_helper
INFO - 2017-07-07 18:37:30 --> Helper loaded: url_helper
INFO - 2017-07-07 18:37:30 --> Model Class Initialized
INFO - 2017-07-07 18:37:30 --> Final output sent to browser
DEBUG - 2017-07-07 18:37:30 --> Total execution time: 0.1700
ERROR - 2017-07-07 18:37:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:37:40 --> Config Class Initialized
INFO - 2017-07-07 18:37:40 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:37:40 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:37:40 --> Utf8 Class Initialized
INFO - 2017-07-07 18:37:40 --> URI Class Initialized
INFO - 2017-07-07 18:37:40 --> Router Class Initialized
INFO - 2017-07-07 18:37:40 --> Output Class Initialized
INFO - 2017-07-07 18:37:40 --> Security Class Initialized
DEBUG - 2017-07-07 18:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:37:40 --> Input Class Initialized
INFO - 2017-07-07 18:37:40 --> Language Class Initialized
INFO - 2017-07-07 18:37:40 --> Loader Class Initialized
INFO - 2017-07-07 18:37:40 --> Controller Class Initialized
INFO - 2017-07-07 18:37:40 --> Database Driver Class Initialized
INFO - 2017-07-07 18:37:40 --> Model Class Initialized
INFO - 2017-07-07 18:37:40 --> Helper loaded: form_helper
INFO - 2017-07-07 18:37:40 --> Helper loaded: url_helper
INFO - 2017-07-07 18:37:40 --> Model Class Initialized
INFO - 2017-07-07 18:37:40 --> Final output sent to browser
DEBUG - 2017-07-07 18:37:40 --> Total execution time: 0.1500
ERROR - 2017-07-07 18:42:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:42:00 --> Config Class Initialized
INFO - 2017-07-07 18:42:00 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:42:00 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:42:00 --> Utf8 Class Initialized
INFO - 2017-07-07 18:42:00 --> URI Class Initialized
INFO - 2017-07-07 18:42:00 --> Router Class Initialized
INFO - 2017-07-07 18:42:00 --> Output Class Initialized
INFO - 2017-07-07 18:42:00 --> Security Class Initialized
DEBUG - 2017-07-07 18:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:42:00 --> Input Class Initialized
INFO - 2017-07-07 18:42:00 --> Language Class Initialized
INFO - 2017-07-07 18:42:00 --> Loader Class Initialized
INFO - 2017-07-07 18:42:00 --> Controller Class Initialized
INFO - 2017-07-07 18:42:00 --> Database Driver Class Initialized
INFO - 2017-07-07 18:42:00 --> Model Class Initialized
INFO - 2017-07-07 18:42:00 --> Helper loaded: form_helper
INFO - 2017-07-07 18:42:00 --> Helper loaded: url_helper
INFO - 2017-07-07 18:42:00 --> Model Class Initialized
INFO - 2017-07-07 18:42:00 --> Final output sent to browser
DEBUG - 2017-07-07 18:42:00 --> Total execution time: 0.1000
ERROR - 2017-07-07 18:42:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:42:01 --> Config Class Initialized
INFO - 2017-07-07 18:42:01 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:42:01 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:42:01 --> Utf8 Class Initialized
INFO - 2017-07-07 18:42:01 --> URI Class Initialized
INFO - 2017-07-07 18:42:01 --> Router Class Initialized
INFO - 2017-07-07 18:42:01 --> Output Class Initialized
INFO - 2017-07-07 18:42:01 --> Security Class Initialized
DEBUG - 2017-07-07 18:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:42:01 --> Input Class Initialized
INFO - 2017-07-07 18:42:01 --> Language Class Initialized
INFO - 2017-07-07 18:42:01 --> Loader Class Initialized
INFO - 2017-07-07 18:42:01 --> Controller Class Initialized
INFO - 2017-07-07 18:42:01 --> Database Driver Class Initialized
INFO - 2017-07-07 18:42:01 --> Model Class Initialized
INFO - 2017-07-07 18:42:01 --> Helper loaded: form_helper
INFO - 2017-07-07 18:42:01 --> Helper loaded: url_helper
INFO - 2017-07-07 18:42:02 --> Model Class Initialized
INFO - 2017-07-07 18:42:02 --> Final output sent to browser
DEBUG - 2017-07-07 18:42:02 --> Total execution time: 0.1450
ERROR - 2017-07-07 18:42:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-07 18:42:14 --> Config Class Initialized
INFO - 2017-07-07 18:42:14 --> Hooks Class Initialized
DEBUG - 2017-07-07 18:42:14 --> UTF-8 Support Enabled
INFO - 2017-07-07 18:42:14 --> Utf8 Class Initialized
INFO - 2017-07-07 18:42:14 --> URI Class Initialized
INFO - 2017-07-07 18:42:14 --> Router Class Initialized
INFO - 2017-07-07 18:42:14 --> Output Class Initialized
INFO - 2017-07-07 18:42:14 --> Security Class Initialized
DEBUG - 2017-07-07 18:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-07 18:42:14 --> Input Class Initialized
INFO - 2017-07-07 18:42:14 --> Language Class Initialized
INFO - 2017-07-07 18:42:14 --> Loader Class Initialized
INFO - 2017-07-07 18:42:14 --> Controller Class Initialized
INFO - 2017-07-07 18:42:14 --> Database Driver Class Initialized
INFO - 2017-07-07 18:42:14 --> Model Class Initialized
INFO - 2017-07-07 18:42:14 --> Helper loaded: form_helper
INFO - 2017-07-07 18:42:14 --> Helper loaded: url_helper
INFO - 2017-07-07 18:42:14 --> Model Class Initialized
INFO - 2017-07-07 18:42:14 --> Final output sent to browser
DEBUG - 2017-07-07 18:42:14 --> Total execution time: 0.1200
