<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-28 13:00:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-28 13:00:25 --> Config Class Initialized
INFO - 2017-08-28 13:00:25 --> Hooks Class Initialized
DEBUG - 2017-08-28 13:00:25 --> UTF-8 Support Enabled
INFO - 2017-08-28 13:00:25 --> Utf8 Class Initialized
INFO - 2017-08-28 13:00:25 --> URI Class Initialized
DEBUG - 2017-08-28 13:00:25 --> No URI present. Default controller set.
INFO - 2017-08-28 13:00:25 --> Router Class Initialized
INFO - 2017-08-28 13:00:25 --> Output Class Initialized
INFO - 2017-08-28 13:00:25 --> Security Class Initialized
DEBUG - 2017-08-28 13:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-28 13:00:25 --> Input Class Initialized
INFO - 2017-08-28 13:00:25 --> Language Class Initialized
INFO - 2017-08-28 13:00:25 --> Loader Class Initialized
INFO - 2017-08-28 13:00:25 --> Controller Class Initialized
INFO - 2017-08-28 13:00:25 --> Database Driver Class Initialized
INFO - 2017-08-28 13:00:25 --> Model Class Initialized
INFO - 2017-08-28 13:00:25 --> Helper loaded: form_helper
INFO - 2017-08-28 13:00:25 --> Helper loaded: url_helper
INFO - 2017-08-28 13:00:25 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-08-28 13:00:25 --> Final output sent to browser
DEBUG - 2017-08-28 13:00:25 --> Total execution time: 0.0500
ERROR - 2017-08-28 13:00:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-28 13:00:29 --> Config Class Initialized
INFO - 2017-08-28 13:00:29 --> Hooks Class Initialized
DEBUG - 2017-08-28 13:00:29 --> UTF-8 Support Enabled
INFO - 2017-08-28 13:00:29 --> Utf8 Class Initialized
INFO - 2017-08-28 13:00:29 --> URI Class Initialized
INFO - 2017-08-28 13:00:29 --> Router Class Initialized
INFO - 2017-08-28 13:00:29 --> Output Class Initialized
INFO - 2017-08-28 13:00:29 --> Security Class Initialized
DEBUG - 2017-08-28 13:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-28 13:00:29 --> Input Class Initialized
INFO - 2017-08-28 13:00:29 --> Language Class Initialized
INFO - 2017-08-28 13:00:29 --> Loader Class Initialized
INFO - 2017-08-28 13:00:29 --> Controller Class Initialized
INFO - 2017-08-28 13:00:29 --> Database Driver Class Initialized
INFO - 2017-08-28 13:00:29 --> Model Class Initialized
INFO - 2017-08-28 13:00:29 --> Helper loaded: form_helper
INFO - 2017-08-28 13:00:29 --> Helper loaded: url_helper
INFO - 2017-08-28 13:00:29 --> Model Class Initialized
ERROR - 2017-08-28 13:00:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-28 13:00:29 --> Config Class Initialized
INFO - 2017-08-28 13:00:29 --> Hooks Class Initialized
DEBUG - 2017-08-28 13:00:29 --> UTF-8 Support Enabled
INFO - 2017-08-28 13:00:29 --> Utf8 Class Initialized
INFO - 2017-08-28 13:00:29 --> URI Class Initialized
INFO - 2017-08-28 13:00:29 --> Router Class Initialized
INFO - 2017-08-28 13:00:29 --> Output Class Initialized
INFO - 2017-08-28 13:00:29 --> Security Class Initialized
DEBUG - 2017-08-28 13:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-28 13:00:29 --> Input Class Initialized
INFO - 2017-08-28 13:00:29 --> Language Class Initialized
INFO - 2017-08-28 13:00:29 --> Loader Class Initialized
INFO - 2017-08-28 13:00:29 --> Controller Class Initialized
INFO - 2017-08-28 13:00:29 --> Database Driver Class Initialized
INFO - 2017-08-28 13:00:29 --> Model Class Initialized
INFO - 2017-08-28 13:00:29 --> Helper loaded: form_helper
INFO - 2017-08-28 13:00:29 --> Helper loaded: url_helper
INFO - 2017-08-28 13:00:29 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-28 13:00:29 --> Model Class Initialized
INFO - 2017-08-28 13:00:29 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-08-28 13:00:29 --> Final output sent to browser
DEBUG - 2017-08-28 13:00:29 --> Total execution time: 0.0430
ERROR - 2017-08-28 13:00:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-28 13:00:35 --> Config Class Initialized
INFO - 2017-08-28 13:00:35 --> Hooks Class Initialized
DEBUG - 2017-08-28 13:00:35 --> UTF-8 Support Enabled
INFO - 2017-08-28 13:00:35 --> Utf8 Class Initialized
INFO - 2017-08-28 13:00:35 --> URI Class Initialized
INFO - 2017-08-28 13:00:35 --> Router Class Initialized
INFO - 2017-08-28 13:00:35 --> Output Class Initialized
INFO - 2017-08-28 13:00:35 --> Security Class Initialized
DEBUG - 2017-08-28 13:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-28 13:00:35 --> Input Class Initialized
INFO - 2017-08-28 13:00:35 --> Language Class Initialized
INFO - 2017-08-28 13:00:35 --> Loader Class Initialized
INFO - 2017-08-28 13:00:35 --> Controller Class Initialized
INFO - 2017-08-28 13:00:35 --> Database Driver Class Initialized
INFO - 2017-08-28 13:00:35 --> Model Class Initialized
INFO - 2017-08-28 13:00:35 --> Helper loaded: form_helper
INFO - 2017-08-28 13:00:35 --> Helper loaded: url_helper
INFO - 2017-08-28 13:00:35 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-28 13:00:35 --> Model Class Initialized
INFO - 2017-08-28 13:00:35 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-08-28 13:00:35 --> Final output sent to browser
DEBUG - 2017-08-28 13:00:35 --> Total execution time: 0.0630
