<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-03 15:14:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-03 15:14:54 --> Config Class Initialized
INFO - 2017-08-03 15:14:54 --> Hooks Class Initialized
DEBUG - 2017-08-03 15:14:54 --> UTF-8 Support Enabled
INFO - 2017-08-03 15:14:54 --> Utf8 Class Initialized
INFO - 2017-08-03 15:14:54 --> URI Class Initialized
DEBUG - 2017-08-03 15:14:54 --> No URI present. Default controller set.
INFO - 2017-08-03 15:14:54 --> Router Class Initialized
INFO - 2017-08-03 15:14:54 --> Output Class Initialized
INFO - 2017-08-03 15:14:54 --> Security Class Initialized
DEBUG - 2017-08-03 15:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 15:14:54 --> Input Class Initialized
INFO - 2017-08-03 15:14:54 --> Language Class Initialized
INFO - 2017-08-03 15:14:54 --> Loader Class Initialized
INFO - 2017-08-03 15:14:54 --> Controller Class Initialized
INFO - 2017-08-03 15:14:54 --> Database Driver Class Initialized
INFO - 2017-08-03 15:14:54 --> Model Class Initialized
INFO - 2017-08-03 15:14:54 --> Helper loaded: form_helper
INFO - 2017-08-03 15:14:54 --> Helper loaded: url_helper
INFO - 2017-08-03 15:14:54 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-08-03 15:14:54 --> Final output sent to browser
DEBUG - 2017-08-03 15:14:54 --> Total execution time: 0.6250
ERROR - 2017-08-03 15:14:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-03 15:14:58 --> Config Class Initialized
INFO - 2017-08-03 15:14:58 --> Hooks Class Initialized
DEBUG - 2017-08-03 15:14:58 --> UTF-8 Support Enabled
INFO - 2017-08-03 15:14:58 --> Utf8 Class Initialized
INFO - 2017-08-03 15:14:58 --> URI Class Initialized
INFO - 2017-08-03 15:14:58 --> Router Class Initialized
INFO - 2017-08-03 15:14:58 --> Output Class Initialized
INFO - 2017-08-03 15:14:58 --> Security Class Initialized
DEBUG - 2017-08-03 15:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 15:14:58 --> Input Class Initialized
INFO - 2017-08-03 15:14:58 --> Language Class Initialized
INFO - 2017-08-03 15:14:58 --> Loader Class Initialized
INFO - 2017-08-03 15:14:58 --> Controller Class Initialized
INFO - 2017-08-03 15:14:58 --> Database Driver Class Initialized
INFO - 2017-08-03 15:14:58 --> Model Class Initialized
INFO - 2017-08-03 15:14:58 --> Helper loaded: form_helper
INFO - 2017-08-03 15:14:58 --> Helper loaded: url_helper
INFO - 2017-08-03 15:14:58 --> Model Class Initialized
ERROR - 2017-08-03 15:14:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-03 15:14:58 --> Config Class Initialized
INFO - 2017-08-03 15:14:58 --> Hooks Class Initialized
DEBUG - 2017-08-03 15:14:58 --> UTF-8 Support Enabled
INFO - 2017-08-03 15:14:58 --> Utf8 Class Initialized
INFO - 2017-08-03 15:14:58 --> URI Class Initialized
INFO - 2017-08-03 15:14:58 --> Router Class Initialized
INFO - 2017-08-03 15:14:58 --> Output Class Initialized
INFO - 2017-08-03 15:14:58 --> Security Class Initialized
DEBUG - 2017-08-03 15:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 15:14:58 --> Input Class Initialized
INFO - 2017-08-03 15:14:58 --> Language Class Initialized
INFO - 2017-08-03 15:14:58 --> Loader Class Initialized
INFO - 2017-08-03 15:14:58 --> Controller Class Initialized
INFO - 2017-08-03 15:14:58 --> Database Driver Class Initialized
INFO - 2017-08-03 15:14:58 --> Model Class Initialized
INFO - 2017-08-03 15:14:58 --> Helper loaded: form_helper
INFO - 2017-08-03 15:14:58 --> Helper loaded: url_helper
INFO - 2017-08-03 15:14:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-03 15:14:58 --> Model Class Initialized
INFO - 2017-08-03 15:14:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-08-03 15:14:58 --> Final output sent to browser
DEBUG - 2017-08-03 15:14:58 --> Total execution time: 0.0910
ERROR - 2017-08-03 15:15:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-03 15:15:02 --> Config Class Initialized
INFO - 2017-08-03 15:15:02 --> Hooks Class Initialized
DEBUG - 2017-08-03 15:15:02 --> UTF-8 Support Enabled
INFO - 2017-08-03 15:15:02 --> Utf8 Class Initialized
INFO - 2017-08-03 15:15:02 --> URI Class Initialized
INFO - 2017-08-03 15:15:02 --> Router Class Initialized
INFO - 2017-08-03 15:15:02 --> Output Class Initialized
INFO - 2017-08-03 15:15:02 --> Security Class Initialized
DEBUG - 2017-08-03 15:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 15:15:02 --> Input Class Initialized
INFO - 2017-08-03 15:15:02 --> Language Class Initialized
INFO - 2017-08-03 15:15:02 --> Loader Class Initialized
INFO - 2017-08-03 15:15:02 --> Controller Class Initialized
INFO - 2017-08-03 15:15:02 --> Database Driver Class Initialized
INFO - 2017-08-03 15:15:02 --> Model Class Initialized
INFO - 2017-08-03 15:15:02 --> Helper loaded: form_helper
INFO - 2017-08-03 15:15:02 --> Helper loaded: url_helper
INFO - 2017-08-03 15:15:02 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-03 15:15:02 --> Model Class Initialized
INFO - 2017-08-03 15:15:02 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-08-03 15:15:02 --> Final output sent to browser
DEBUG - 2017-08-03 15:15:02 --> Total execution time: 0.0950
ERROR - 2017-08-03 15:15:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-03 15:15:04 --> Config Class Initialized
INFO - 2017-08-03 15:15:04 --> Hooks Class Initialized
DEBUG - 2017-08-03 15:15:04 --> UTF-8 Support Enabled
INFO - 2017-08-03 15:15:04 --> Utf8 Class Initialized
INFO - 2017-08-03 15:15:04 --> URI Class Initialized
INFO - 2017-08-03 15:15:04 --> Router Class Initialized
INFO - 2017-08-03 15:15:04 --> Output Class Initialized
INFO - 2017-08-03 15:15:04 --> Security Class Initialized
DEBUG - 2017-08-03 15:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 15:15:04 --> Input Class Initialized
INFO - 2017-08-03 15:15:04 --> Language Class Initialized
INFO - 2017-08-03 15:15:04 --> Loader Class Initialized
INFO - 2017-08-03 15:15:04 --> Controller Class Initialized
INFO - 2017-08-03 15:15:04 --> Database Driver Class Initialized
INFO - 2017-08-03 15:15:04 --> Model Class Initialized
INFO - 2017-08-03 15:15:04 --> Helper loaded: form_helper
INFO - 2017-08-03 15:15:04 --> Helper loaded: url_helper
INFO - 2017-08-03 15:15:04 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-03 15:15:04 --> Model Class Initialized
INFO - 2017-08-03 15:15:04 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-08-03 15:15:04 --> Final output sent to browser
DEBUG - 2017-08-03 15:15:04 --> Total execution time: 0.1580
