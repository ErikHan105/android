<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-29 17:23:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-29 17:23:07 --> Config Class Initialized
INFO - 2017-07-29 17:23:07 --> Hooks Class Initialized
DEBUG - 2017-07-29 17:23:07 --> UTF-8 Support Enabled
INFO - 2017-07-29 17:23:07 --> Utf8 Class Initialized
INFO - 2017-07-29 17:23:07 --> URI Class Initialized
DEBUG - 2017-07-29 17:23:07 --> No URI present. Default controller set.
INFO - 2017-07-29 17:23:07 --> Router Class Initialized
INFO - 2017-07-29 17:23:07 --> Output Class Initialized
INFO - 2017-07-29 17:23:07 --> Security Class Initialized
DEBUG - 2017-07-29 17:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-29 17:23:07 --> Input Class Initialized
INFO - 2017-07-29 17:23:07 --> Language Class Initialized
INFO - 2017-07-29 17:23:07 --> Loader Class Initialized
INFO - 2017-07-29 17:23:07 --> Controller Class Initialized
INFO - 2017-07-29 17:23:07 --> Database Driver Class Initialized
INFO - 2017-07-29 17:23:07 --> Model Class Initialized
INFO - 2017-07-29 17:23:07 --> Helper loaded: form_helper
INFO - 2017-07-29 17:23:07 --> Helper loaded: url_helper
INFO - 2017-07-29 17:23:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-29 17:23:07 --> Final output sent to browser
DEBUG - 2017-07-29 17:23:07 --> Total execution time: 0.0330
ERROR - 2017-07-29 17:23:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-29 17:23:10 --> Config Class Initialized
INFO - 2017-07-29 17:23:10 --> Hooks Class Initialized
DEBUG - 2017-07-29 17:23:10 --> UTF-8 Support Enabled
INFO - 2017-07-29 17:23:10 --> Utf8 Class Initialized
INFO - 2017-07-29 17:23:10 --> URI Class Initialized
INFO - 2017-07-29 17:23:10 --> Router Class Initialized
INFO - 2017-07-29 17:23:10 --> Output Class Initialized
INFO - 2017-07-29 17:23:10 --> Security Class Initialized
DEBUG - 2017-07-29 17:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-29 17:23:10 --> Input Class Initialized
INFO - 2017-07-29 17:23:10 --> Language Class Initialized
INFO - 2017-07-29 17:23:10 --> Loader Class Initialized
INFO - 2017-07-29 17:23:10 --> Controller Class Initialized
INFO - 2017-07-29 17:23:10 --> Database Driver Class Initialized
INFO - 2017-07-29 17:23:11 --> Model Class Initialized
INFO - 2017-07-29 17:23:11 --> Helper loaded: form_helper
INFO - 2017-07-29 17:23:11 --> Helper loaded: url_helper
INFO - 2017-07-29 17:23:11 --> Model Class Initialized
ERROR - 2017-07-29 17:23:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-29 17:23:11 --> Config Class Initialized
INFO - 2017-07-29 17:23:11 --> Hooks Class Initialized
DEBUG - 2017-07-29 17:23:11 --> UTF-8 Support Enabled
INFO - 2017-07-29 17:23:11 --> Utf8 Class Initialized
INFO - 2017-07-29 17:23:11 --> URI Class Initialized
INFO - 2017-07-29 17:23:11 --> Router Class Initialized
INFO - 2017-07-29 17:23:11 --> Output Class Initialized
INFO - 2017-07-29 17:23:11 --> Security Class Initialized
DEBUG - 2017-07-29 17:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-29 17:23:11 --> Input Class Initialized
INFO - 2017-07-29 17:23:11 --> Language Class Initialized
INFO - 2017-07-29 17:23:11 --> Loader Class Initialized
INFO - 2017-07-29 17:23:11 --> Controller Class Initialized
INFO - 2017-07-29 17:23:11 --> Database Driver Class Initialized
INFO - 2017-07-29 17:23:11 --> Model Class Initialized
INFO - 2017-07-29 17:23:11 --> Helper loaded: form_helper
INFO - 2017-07-29 17:23:11 --> Helper loaded: url_helper
INFO - 2017-07-29 17:23:11 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-29 17:23:11 --> Model Class Initialized
INFO - 2017-07-29 17:23:11 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-29 17:23:11 --> Final output sent to browser
DEBUG - 2017-07-29 17:23:11 --> Total execution time: 0.0520
ERROR - 2017-07-29 17:23:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-29 17:23:14 --> Config Class Initialized
INFO - 2017-07-29 17:23:14 --> Hooks Class Initialized
DEBUG - 2017-07-29 17:23:14 --> UTF-8 Support Enabled
INFO - 2017-07-29 17:23:14 --> Utf8 Class Initialized
INFO - 2017-07-29 17:23:14 --> URI Class Initialized
INFO - 2017-07-29 17:23:14 --> Router Class Initialized
INFO - 2017-07-29 17:23:14 --> Output Class Initialized
INFO - 2017-07-29 17:23:14 --> Security Class Initialized
DEBUG - 2017-07-29 17:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-29 17:23:14 --> Input Class Initialized
INFO - 2017-07-29 17:23:14 --> Language Class Initialized
INFO - 2017-07-29 17:23:14 --> Loader Class Initialized
INFO - 2017-07-29 17:23:14 --> Controller Class Initialized
INFO - 2017-07-29 17:23:14 --> Database Driver Class Initialized
INFO - 2017-07-29 17:23:14 --> Model Class Initialized
INFO - 2017-07-29 17:23:14 --> Helper loaded: form_helper
INFO - 2017-07-29 17:23:14 --> Helper loaded: url_helper
INFO - 2017-07-29 17:23:14 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-29 17:23:14 --> Model Class Initialized
INFO - 2017-07-29 17:23:14 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-29 17:23:14 --> Final output sent to browser
DEBUG - 2017-07-29 17:23:14 --> Total execution time: 0.0490
ERROR - 2017-07-29 17:23:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-29 17:23:16 --> Config Class Initialized
INFO - 2017-07-29 17:23:16 --> Hooks Class Initialized
DEBUG - 2017-07-29 17:23:16 --> UTF-8 Support Enabled
INFO - 2017-07-29 17:23:16 --> Utf8 Class Initialized
INFO - 2017-07-29 17:23:16 --> URI Class Initialized
INFO - 2017-07-29 17:23:16 --> Router Class Initialized
INFO - 2017-07-29 17:23:16 --> Output Class Initialized
INFO - 2017-07-29 17:23:16 --> Security Class Initialized
DEBUG - 2017-07-29 17:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-29 17:23:16 --> Input Class Initialized
INFO - 2017-07-29 17:23:16 --> Language Class Initialized
INFO - 2017-07-29 17:23:16 --> Loader Class Initialized
INFO - 2017-07-29 17:23:16 --> Controller Class Initialized
INFO - 2017-07-29 17:23:16 --> Database Driver Class Initialized
INFO - 2017-07-29 17:23:16 --> Model Class Initialized
INFO - 2017-07-29 17:23:16 --> Helper loaded: form_helper
INFO - 2017-07-29 17:23:16 --> Helper loaded: url_helper
INFO - 2017-07-29 17:23:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-29 17:23:16 --> Model Class Initialized
INFO - 2017-07-29 17:23:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-29 17:23:16 --> Final output sent to browser
DEBUG - 2017-07-29 17:23:16 --> Total execution time: 0.0460
