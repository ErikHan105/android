<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-06 00:25:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 00:25:23 --> Config Class Initialized
INFO - 2017-09-06 00:25:23 --> Hooks Class Initialized
DEBUG - 2017-09-06 00:25:23 --> UTF-8 Support Enabled
INFO - 2017-09-06 00:25:23 --> Utf8 Class Initialized
INFO - 2017-09-06 00:25:23 --> URI Class Initialized
DEBUG - 2017-09-06 00:25:23 --> No URI present. Default controller set.
INFO - 2017-09-06 00:25:23 --> Router Class Initialized
INFO - 2017-09-06 00:25:23 --> Output Class Initialized
INFO - 2017-09-06 00:25:23 --> Security Class Initialized
DEBUG - 2017-09-06 00:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 00:25:23 --> Input Class Initialized
INFO - 2017-09-06 00:25:23 --> Language Class Initialized
INFO - 2017-09-06 00:25:23 --> Loader Class Initialized
INFO - 2017-09-06 00:25:23 --> Controller Class Initialized
INFO - 2017-09-06 00:25:23 --> Database Driver Class Initialized
INFO - 2017-09-06 00:25:25 --> Model Class Initialized
INFO - 2017-09-06 00:25:25 --> Helper loaded: form_helper
INFO - 2017-09-06 00:25:25 --> Helper loaded: url_helper
INFO - 2017-09-06 00:25:25 --> File loaded: C:\xampp\htdocs\biper\application\views\login.php
INFO - 2017-09-06 00:25:25 --> Final output sent to browser
DEBUG - 2017-09-06 00:25:25 --> Total execution time: 2.2011
ERROR - 2017-09-06 00:25:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 00:25:28 --> Config Class Initialized
INFO - 2017-09-06 00:25:28 --> Hooks Class Initialized
DEBUG - 2017-09-06 00:25:28 --> UTF-8 Support Enabled
INFO - 2017-09-06 00:25:28 --> Utf8 Class Initialized
INFO - 2017-09-06 00:25:28 --> URI Class Initialized
INFO - 2017-09-06 00:25:28 --> Router Class Initialized
INFO - 2017-09-06 00:25:28 --> Output Class Initialized
INFO - 2017-09-06 00:25:28 --> Security Class Initialized
DEBUG - 2017-09-06 00:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 00:25:28 --> Input Class Initialized
INFO - 2017-09-06 00:25:28 --> Language Class Initialized
INFO - 2017-09-06 00:25:29 --> Loader Class Initialized
INFO - 2017-09-06 00:25:29 --> Controller Class Initialized
INFO - 2017-09-06 00:25:29 --> Database Driver Class Initialized
INFO - 2017-09-06 00:25:29 --> Model Class Initialized
INFO - 2017-09-06 00:25:29 --> Helper loaded: form_helper
INFO - 2017-09-06 00:25:29 --> Helper loaded: url_helper
INFO - 2017-09-06 00:25:29 --> Model Class Initialized
ERROR - 2017-09-06 00:25:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 00:25:29 --> Config Class Initialized
INFO - 2017-09-06 00:25:29 --> Hooks Class Initialized
DEBUG - 2017-09-06 00:25:29 --> UTF-8 Support Enabled
INFO - 2017-09-06 00:25:29 --> Utf8 Class Initialized
INFO - 2017-09-06 00:25:29 --> URI Class Initialized
INFO - 2017-09-06 00:25:29 --> Router Class Initialized
INFO - 2017-09-06 00:25:29 --> Output Class Initialized
INFO - 2017-09-06 00:25:29 --> Security Class Initialized
DEBUG - 2017-09-06 00:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 00:25:29 --> Input Class Initialized
INFO - 2017-09-06 00:25:29 --> Language Class Initialized
INFO - 2017-09-06 00:25:29 --> Loader Class Initialized
INFO - 2017-09-06 00:25:29 --> Controller Class Initialized
INFO - 2017-09-06 00:25:29 --> Database Driver Class Initialized
INFO - 2017-09-06 00:25:29 --> Model Class Initialized
INFO - 2017-09-06 00:25:29 --> Helper loaded: form_helper
INFO - 2017-09-06 00:25:29 --> Helper loaded: url_helper
INFO - 2017-09-06 00:25:29 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 00:25:29 --> Model Class Initialized
INFO - 2017-09-06 00:25:29 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-06 00:25:29 --> Final output sent to browser
DEBUG - 2017-09-06 00:25:29 --> Total execution time: 0.1330
ERROR - 2017-09-06 00:25:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 00:25:30 --> Config Class Initialized
INFO - 2017-09-06 00:25:30 --> Hooks Class Initialized
DEBUG - 2017-09-06 00:25:30 --> UTF-8 Support Enabled
INFO - 2017-09-06 00:25:30 --> Utf8 Class Initialized
INFO - 2017-09-06 00:25:30 --> URI Class Initialized
INFO - 2017-09-06 00:25:30 --> Router Class Initialized
INFO - 2017-09-06 00:25:30 --> Output Class Initialized
INFO - 2017-09-06 00:25:30 --> Security Class Initialized
DEBUG - 2017-09-06 00:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 00:25:30 --> Input Class Initialized
INFO - 2017-09-06 00:25:30 --> Language Class Initialized
INFO - 2017-09-06 00:25:30 --> Loader Class Initialized
INFO - 2017-09-06 00:25:30 --> Controller Class Initialized
INFO - 2017-09-06 00:25:30 --> Database Driver Class Initialized
INFO - 2017-09-06 00:25:30 --> Model Class Initialized
INFO - 2017-09-06 00:25:30 --> Helper loaded: form_helper
INFO - 2017-09-06 00:25:30 --> Helper loaded: url_helper
INFO - 2017-09-06 00:25:30 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 00:25:30 --> Model Class Initialized
INFO - 2017-09-06 00:25:30 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-06 00:25:30 --> Final output sent to browser
DEBUG - 2017-09-06 00:25:30 --> Total execution time: 0.0680
ERROR - 2017-09-06 00:25:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 00:25:36 --> Config Class Initialized
INFO - 2017-09-06 00:25:36 --> Hooks Class Initialized
DEBUG - 2017-09-06 00:25:36 --> UTF-8 Support Enabled
INFO - 2017-09-06 00:25:36 --> Utf8 Class Initialized
INFO - 2017-09-06 00:25:36 --> URI Class Initialized
INFO - 2017-09-06 00:25:36 --> Router Class Initialized
INFO - 2017-09-06 00:25:36 --> Output Class Initialized
INFO - 2017-09-06 00:25:36 --> Security Class Initialized
DEBUG - 2017-09-06 00:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 00:25:36 --> Input Class Initialized
INFO - 2017-09-06 00:25:36 --> Language Class Initialized
INFO - 2017-09-06 00:25:36 --> Loader Class Initialized
INFO - 2017-09-06 00:25:36 --> Controller Class Initialized
INFO - 2017-09-06 00:25:36 --> Database Driver Class Initialized
INFO - 2017-09-06 00:25:36 --> Model Class Initialized
INFO - 2017-09-06 00:25:36 --> Helper loaded: form_helper
INFO - 2017-09-06 00:25:36 --> Helper loaded: url_helper
INFO - 2017-09-06 00:25:36 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 00:25:36 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-06 00:25:36 --> Final output sent to browser
DEBUG - 2017-09-06 00:25:36 --> Total execution time: 0.0480
ERROR - 2017-09-06 00:30:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 00:30:58 --> Config Class Initialized
INFO - 2017-09-06 00:30:58 --> Hooks Class Initialized
DEBUG - 2017-09-06 00:30:58 --> UTF-8 Support Enabled
INFO - 2017-09-06 00:30:58 --> Utf8 Class Initialized
INFO - 2017-09-06 00:30:58 --> URI Class Initialized
INFO - 2017-09-06 00:30:58 --> Router Class Initialized
INFO - 2017-09-06 00:30:58 --> Output Class Initialized
INFO - 2017-09-06 00:30:58 --> Security Class Initialized
DEBUG - 2017-09-06 00:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 00:30:58 --> Input Class Initialized
INFO - 2017-09-06 00:30:58 --> Language Class Initialized
INFO - 2017-09-06 00:30:58 --> Loader Class Initialized
INFO - 2017-09-06 00:30:58 --> Controller Class Initialized
INFO - 2017-09-06 00:30:58 --> Database Driver Class Initialized
INFO - 2017-09-06 00:30:58 --> Model Class Initialized
INFO - 2017-09-06 00:30:58 --> Helper loaded: form_helper
INFO - 2017-09-06 00:30:58 --> Helper loaded: url_helper
INFO - 2017-09-06 00:30:58 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 00:30:58 --> Model Class Initialized
INFO - 2017-09-06 00:30:58 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-06 00:30:58 --> Final output sent to browser
DEBUG - 2017-09-06 00:30:58 --> Total execution time: 0.0410
ERROR - 2017-09-06 03:15:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:15:08 --> Config Class Initialized
INFO - 2017-09-06 03:15:08 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:15:08 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:15:08 --> Utf8 Class Initialized
INFO - 2017-09-06 03:15:08 --> URI Class Initialized
DEBUG - 2017-09-06 03:15:08 --> No URI present. Default controller set.
INFO - 2017-09-06 03:15:08 --> Router Class Initialized
INFO - 2017-09-06 03:15:08 --> Output Class Initialized
INFO - 2017-09-06 03:15:08 --> Security Class Initialized
DEBUG - 2017-09-06 03:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:15:08 --> Input Class Initialized
INFO - 2017-09-06 03:15:08 --> Language Class Initialized
INFO - 2017-09-06 03:15:08 --> Loader Class Initialized
INFO - 2017-09-06 03:15:08 --> Controller Class Initialized
INFO - 2017-09-06 03:15:08 --> Database Driver Class Initialized
INFO - 2017-09-06 03:15:08 --> Model Class Initialized
INFO - 2017-09-06 03:15:08 --> Helper loaded: form_helper
INFO - 2017-09-06 03:15:08 --> Helper loaded: url_helper
INFO - 2017-09-06 03:15:08 --> File loaded: C:\xampp\htdocs\biper\application\views\login.php
INFO - 2017-09-06 03:15:08 --> Final output sent to browser
DEBUG - 2017-09-06 03:15:08 --> Total execution time: 0.0340
ERROR - 2017-09-06 03:15:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:15:11 --> Config Class Initialized
INFO - 2017-09-06 03:15:11 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:15:11 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:15:11 --> Utf8 Class Initialized
INFO - 2017-09-06 03:15:11 --> URI Class Initialized
INFO - 2017-09-06 03:15:11 --> Router Class Initialized
INFO - 2017-09-06 03:15:11 --> Output Class Initialized
INFO - 2017-09-06 03:15:11 --> Security Class Initialized
DEBUG - 2017-09-06 03:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:15:11 --> Input Class Initialized
INFO - 2017-09-06 03:15:11 --> Language Class Initialized
INFO - 2017-09-06 03:15:11 --> Loader Class Initialized
INFO - 2017-09-06 03:15:11 --> Controller Class Initialized
INFO - 2017-09-06 03:15:11 --> Database Driver Class Initialized
INFO - 2017-09-06 03:15:11 --> Model Class Initialized
INFO - 2017-09-06 03:15:11 --> Helper loaded: form_helper
INFO - 2017-09-06 03:15:11 --> Helper loaded: url_helper
INFO - 2017-09-06 03:15:11 --> Model Class Initialized
ERROR - 2017-09-06 03:15:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:15:11 --> Config Class Initialized
INFO - 2017-09-06 03:15:11 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:15:11 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:15:11 --> Utf8 Class Initialized
INFO - 2017-09-06 03:15:11 --> URI Class Initialized
INFO - 2017-09-06 03:15:11 --> Router Class Initialized
INFO - 2017-09-06 03:15:11 --> Output Class Initialized
INFO - 2017-09-06 03:15:11 --> Security Class Initialized
DEBUG - 2017-09-06 03:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:15:11 --> Input Class Initialized
INFO - 2017-09-06 03:15:11 --> Language Class Initialized
INFO - 2017-09-06 03:15:11 --> Loader Class Initialized
INFO - 2017-09-06 03:15:11 --> Controller Class Initialized
INFO - 2017-09-06 03:15:11 --> Database Driver Class Initialized
INFO - 2017-09-06 03:15:11 --> Model Class Initialized
INFO - 2017-09-06 03:15:11 --> Helper loaded: form_helper
INFO - 2017-09-06 03:15:11 --> Helper loaded: url_helper
INFO - 2017-09-06 03:15:11 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:15:11 --> Model Class Initialized
INFO - 2017-09-06 03:15:11 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-06 03:15:11 --> Final output sent to browser
DEBUG - 2017-09-06 03:15:11 --> Total execution time: 0.0700
ERROR - 2017-09-06 03:15:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:15:25 --> Config Class Initialized
INFO - 2017-09-06 03:15:25 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:15:25 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:15:25 --> Utf8 Class Initialized
INFO - 2017-09-06 03:15:25 --> URI Class Initialized
INFO - 2017-09-06 03:15:25 --> Router Class Initialized
INFO - 2017-09-06 03:15:25 --> Output Class Initialized
INFO - 2017-09-06 03:15:25 --> Security Class Initialized
DEBUG - 2017-09-06 03:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:15:25 --> Input Class Initialized
INFO - 2017-09-06 03:15:25 --> Language Class Initialized
INFO - 2017-09-06 03:15:25 --> Loader Class Initialized
INFO - 2017-09-06 03:15:25 --> Controller Class Initialized
INFO - 2017-09-06 03:15:25 --> Database Driver Class Initialized
INFO - 2017-09-06 03:15:25 --> Model Class Initialized
INFO - 2017-09-06 03:15:25 --> Helper loaded: form_helper
INFO - 2017-09-06 03:15:25 --> Helper loaded: url_helper
INFO - 2017-09-06 03:15:25 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:15:25 --> Model Class Initialized
INFO - 2017-09-06 03:15:25 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-06 03:15:25 --> Final output sent to browser
DEBUG - 2017-09-06 03:15:25 --> Total execution time: 0.0590
ERROR - 2017-09-06 03:15:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:15:39 --> Config Class Initialized
INFO - 2017-09-06 03:15:39 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:15:39 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:15:39 --> Utf8 Class Initialized
INFO - 2017-09-06 03:15:39 --> URI Class Initialized
INFO - 2017-09-06 03:15:39 --> Router Class Initialized
INFO - 2017-09-06 03:15:39 --> Output Class Initialized
INFO - 2017-09-06 03:15:39 --> Security Class Initialized
DEBUG - 2017-09-06 03:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:15:39 --> Input Class Initialized
INFO - 2017-09-06 03:15:39 --> Language Class Initialized
INFO - 2017-09-06 03:15:39 --> Loader Class Initialized
INFO - 2017-09-06 03:15:39 --> Controller Class Initialized
INFO - 2017-09-06 03:15:39 --> Database Driver Class Initialized
INFO - 2017-09-06 03:15:39 --> Model Class Initialized
INFO - 2017-09-06 03:15:39 --> Helper loaded: form_helper
INFO - 2017-09-06 03:15:39 --> Helper loaded: url_helper
INFO - 2017-09-06 03:15:39 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:15:39 --> Model Class Initialized
INFO - 2017-09-06 03:15:39 --> File loaded: C:\xampp\htdocs\biper\application\views\purchase.php
INFO - 2017-09-06 03:15:39 --> Final output sent to browser
DEBUG - 2017-09-06 03:15:39 --> Total execution time: 0.0680
ERROR - 2017-09-06 03:29:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:29:32 --> Config Class Initialized
INFO - 2017-09-06 03:29:32 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:29:32 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:29:32 --> Utf8 Class Initialized
INFO - 2017-09-06 03:29:32 --> URI Class Initialized
INFO - 2017-09-06 03:29:32 --> Router Class Initialized
INFO - 2017-09-06 03:29:32 --> Output Class Initialized
INFO - 2017-09-06 03:29:32 --> Security Class Initialized
DEBUG - 2017-09-06 03:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:29:32 --> Input Class Initialized
INFO - 2017-09-06 03:29:32 --> Language Class Initialized
INFO - 2017-09-06 03:29:32 --> Loader Class Initialized
INFO - 2017-09-06 03:29:32 --> Controller Class Initialized
INFO - 2017-09-06 03:29:32 --> Database Driver Class Initialized
INFO - 2017-09-06 03:29:32 --> Model Class Initialized
INFO - 2017-09-06 03:29:32 --> Helper loaded: form_helper
INFO - 2017-09-06 03:29:32 --> Helper loaded: url_helper
INFO - 2017-09-06 03:29:32 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:29:32 --> Model Class Initialized
INFO - 2017-09-06 03:29:32 --> File loaded: C:\xampp\htdocs\biper\application\views\purchase.php
INFO - 2017-09-06 03:29:32 --> Final output sent to browser
DEBUG - 2017-09-06 03:29:32 --> Total execution time: 0.1290
ERROR - 2017-09-06 03:30:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:30:35 --> Config Class Initialized
INFO - 2017-09-06 03:30:35 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:30:35 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:30:35 --> Utf8 Class Initialized
INFO - 2017-09-06 03:30:35 --> URI Class Initialized
INFO - 2017-09-06 03:30:35 --> Router Class Initialized
INFO - 2017-09-06 03:30:35 --> Output Class Initialized
INFO - 2017-09-06 03:30:35 --> Security Class Initialized
DEBUG - 2017-09-06 03:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:30:35 --> Input Class Initialized
INFO - 2017-09-06 03:30:35 --> Language Class Initialized
INFO - 2017-09-06 03:30:35 --> Loader Class Initialized
INFO - 2017-09-06 03:30:35 --> Controller Class Initialized
INFO - 2017-09-06 03:30:35 --> Database Driver Class Initialized
INFO - 2017-09-06 03:30:35 --> Model Class Initialized
INFO - 2017-09-06 03:30:35 --> Helper loaded: form_helper
INFO - 2017-09-06 03:30:35 --> Helper loaded: url_helper
INFO - 2017-09-06 03:30:35 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:30:35 --> Model Class Initialized
INFO - 2017-09-06 03:30:35 --> File loaded: C:\xampp\htdocs\biper\application\views\purchase.php
INFO - 2017-09-06 03:30:35 --> Final output sent to browser
DEBUG - 2017-09-06 03:30:35 --> Total execution time: 0.0730
ERROR - 2017-09-06 03:30:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:30:45 --> Config Class Initialized
INFO - 2017-09-06 03:30:45 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:30:46 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:30:46 --> Utf8 Class Initialized
INFO - 2017-09-06 03:30:46 --> URI Class Initialized
INFO - 2017-09-06 03:30:46 --> Router Class Initialized
INFO - 2017-09-06 03:30:46 --> Output Class Initialized
INFO - 2017-09-06 03:30:46 --> Security Class Initialized
DEBUG - 2017-09-06 03:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:30:46 --> Input Class Initialized
INFO - 2017-09-06 03:30:46 --> Language Class Initialized
INFO - 2017-09-06 03:30:46 --> Loader Class Initialized
INFO - 2017-09-06 03:30:46 --> Controller Class Initialized
INFO - 2017-09-06 03:30:46 --> Database Driver Class Initialized
INFO - 2017-09-06 03:30:46 --> Model Class Initialized
INFO - 2017-09-06 03:30:46 --> Helper loaded: form_helper
INFO - 2017-09-06 03:30:46 --> Helper loaded: url_helper
INFO - 2017-09-06 03:30:46 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:30:46 --> Model Class Initialized
INFO - 2017-09-06 03:30:46 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-06 03:30:46 --> Final output sent to browser
DEBUG - 2017-09-06 03:30:46 --> Total execution time: 0.0990
ERROR - 2017-09-06 03:32:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:32:02 --> Config Class Initialized
INFO - 2017-09-06 03:32:02 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:32:02 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:32:02 --> Utf8 Class Initialized
INFO - 2017-09-06 03:32:02 --> URI Class Initialized
INFO - 2017-09-06 03:32:02 --> Router Class Initialized
INFO - 2017-09-06 03:32:02 --> Output Class Initialized
INFO - 2017-09-06 03:32:02 --> Security Class Initialized
DEBUG - 2017-09-06 03:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:32:02 --> Input Class Initialized
INFO - 2017-09-06 03:32:02 --> Language Class Initialized
INFO - 2017-09-06 03:32:02 --> Loader Class Initialized
INFO - 2017-09-06 03:32:02 --> Controller Class Initialized
INFO - 2017-09-06 03:32:02 --> Database Driver Class Initialized
INFO - 2017-09-06 03:32:02 --> Model Class Initialized
INFO - 2017-09-06 03:32:02 --> Helper loaded: form_helper
INFO - 2017-09-06 03:32:02 --> Helper loaded: url_helper
INFO - 2017-09-06 03:32:02 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:32:02 --> Model Class Initialized
INFO - 2017-09-06 03:32:02 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-06 03:32:02 --> Final output sent to browser
DEBUG - 2017-09-06 03:32:02 --> Total execution time: 0.1110
ERROR - 2017-09-06 03:32:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:32:13 --> Config Class Initialized
INFO - 2017-09-06 03:32:13 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:32:13 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:32:13 --> Utf8 Class Initialized
INFO - 2017-09-06 03:32:13 --> URI Class Initialized
INFO - 2017-09-06 03:32:13 --> Router Class Initialized
INFO - 2017-09-06 03:32:13 --> Output Class Initialized
INFO - 2017-09-06 03:32:13 --> Security Class Initialized
DEBUG - 2017-09-06 03:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:32:13 --> Input Class Initialized
INFO - 2017-09-06 03:32:13 --> Language Class Initialized
INFO - 2017-09-06 03:32:13 --> Loader Class Initialized
INFO - 2017-09-06 03:32:13 --> Controller Class Initialized
INFO - 2017-09-06 03:32:13 --> Database Driver Class Initialized
INFO - 2017-09-06 03:32:13 --> Model Class Initialized
INFO - 2017-09-06 03:32:13 --> Helper loaded: form_helper
INFO - 2017-09-06 03:32:13 --> Helper loaded: url_helper
INFO - 2017-09-06 03:32:13 --> Model Class Initialized
INFO - 2017-09-06 03:32:13 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:32:13 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-06 03:32:13 --> Final output sent to browser
DEBUG - 2017-09-06 03:32:13 --> Total execution time: 0.1140
ERROR - 2017-09-06 03:32:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:32:15 --> Config Class Initialized
INFO - 2017-09-06 03:32:15 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:32:15 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:32:15 --> Utf8 Class Initialized
INFO - 2017-09-06 03:32:15 --> URI Class Initialized
INFO - 2017-09-06 03:32:15 --> Router Class Initialized
INFO - 2017-09-06 03:32:15 --> Output Class Initialized
INFO - 2017-09-06 03:32:15 --> Security Class Initialized
DEBUG - 2017-09-06 03:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:32:15 --> Input Class Initialized
INFO - 2017-09-06 03:32:15 --> Language Class Initialized
INFO - 2017-09-06 03:32:15 --> Loader Class Initialized
INFO - 2017-09-06 03:32:15 --> Controller Class Initialized
INFO - 2017-09-06 03:32:15 --> Database Driver Class Initialized
INFO - 2017-09-06 03:32:15 --> Model Class Initialized
INFO - 2017-09-06 03:32:15 --> Helper loaded: form_helper
INFO - 2017-09-06 03:32:15 --> Helper loaded: url_helper
INFO - 2017-09-06 03:32:15 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:32:15 --> Model Class Initialized
INFO - 2017-09-06 03:32:15 --> File loaded: C:\xampp\htdocs\biper\application\views\purchase.php
INFO - 2017-09-06 03:32:15 --> Final output sent to browser
DEBUG - 2017-09-06 03:32:15 --> Total execution time: 0.1230
ERROR - 2017-09-06 03:32:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:32:17 --> Config Class Initialized
INFO - 2017-09-06 03:32:17 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:32:17 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:32:17 --> Utf8 Class Initialized
INFO - 2017-09-06 03:32:17 --> URI Class Initialized
INFO - 2017-09-06 03:32:17 --> Router Class Initialized
INFO - 2017-09-06 03:32:17 --> Output Class Initialized
INFO - 2017-09-06 03:32:17 --> Security Class Initialized
DEBUG - 2017-09-06 03:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:32:17 --> Input Class Initialized
INFO - 2017-09-06 03:32:17 --> Language Class Initialized
INFO - 2017-09-06 03:32:17 --> Loader Class Initialized
INFO - 2017-09-06 03:32:17 --> Controller Class Initialized
INFO - 2017-09-06 03:32:17 --> Database Driver Class Initialized
INFO - 2017-09-06 03:32:17 --> Model Class Initialized
INFO - 2017-09-06 03:32:17 --> Helper loaded: form_helper
INFO - 2017-09-06 03:32:17 --> Helper loaded: url_helper
INFO - 2017-09-06 03:32:17 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:32:17 --> Model Class Initialized
INFO - 2017-09-06 03:32:17 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-06 03:32:17 --> Final output sent to browser
DEBUG - 2017-09-06 03:32:17 --> Total execution time: 0.1040
ERROR - 2017-09-06 03:32:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:32:27 --> Config Class Initialized
INFO - 2017-09-06 03:32:27 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:32:27 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:32:27 --> Utf8 Class Initialized
INFO - 2017-09-06 03:32:27 --> URI Class Initialized
INFO - 2017-09-06 03:32:27 --> Router Class Initialized
INFO - 2017-09-06 03:32:27 --> Output Class Initialized
INFO - 2017-09-06 03:32:27 --> Security Class Initialized
DEBUG - 2017-09-06 03:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:32:27 --> Input Class Initialized
INFO - 2017-09-06 03:32:27 --> Language Class Initialized
INFO - 2017-09-06 03:32:27 --> Loader Class Initialized
INFO - 2017-09-06 03:32:27 --> Controller Class Initialized
INFO - 2017-09-06 03:32:27 --> Database Driver Class Initialized
INFO - 2017-09-06 03:32:27 --> Model Class Initialized
INFO - 2017-09-06 03:32:27 --> Helper loaded: form_helper
INFO - 2017-09-06 03:32:27 --> Helper loaded: url_helper
INFO - 2017-09-06 03:32:27 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:32:27 --> Model Class Initialized
INFO - 2017-09-06 03:32:27 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-06 03:32:27 --> Final output sent to browser
DEBUG - 2017-09-06 03:32:27 --> Total execution time: 0.0910
ERROR - 2017-09-06 03:32:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:32:43 --> Config Class Initialized
INFO - 2017-09-06 03:32:43 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:32:43 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:32:43 --> Utf8 Class Initialized
INFO - 2017-09-06 03:32:43 --> URI Class Initialized
INFO - 2017-09-06 03:32:43 --> Router Class Initialized
INFO - 2017-09-06 03:32:43 --> Output Class Initialized
INFO - 2017-09-06 03:32:43 --> Security Class Initialized
DEBUG - 2017-09-06 03:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:32:43 --> Input Class Initialized
INFO - 2017-09-06 03:32:43 --> Language Class Initialized
INFO - 2017-09-06 03:32:43 --> Loader Class Initialized
INFO - 2017-09-06 03:32:43 --> Controller Class Initialized
INFO - 2017-09-06 03:32:43 --> Database Driver Class Initialized
INFO - 2017-09-06 03:32:43 --> Model Class Initialized
INFO - 2017-09-06 03:32:43 --> Helper loaded: form_helper
INFO - 2017-09-06 03:32:43 --> Helper loaded: url_helper
INFO - 2017-09-06 03:32:43 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:32:43 --> Model Class Initialized
INFO - 2017-09-06 03:32:43 --> File loaded: C:\xampp\htdocs\biper\application\views\purchase.php
INFO - 2017-09-06 03:32:43 --> Final output sent to browser
DEBUG - 2017-09-06 03:32:43 --> Total execution time: 0.1010
ERROR - 2017-09-06 03:32:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:32:44 --> Config Class Initialized
INFO - 2017-09-06 03:32:44 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:32:44 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:32:44 --> Utf8 Class Initialized
INFO - 2017-09-06 03:32:44 --> URI Class Initialized
INFO - 2017-09-06 03:32:45 --> Router Class Initialized
INFO - 2017-09-06 03:32:45 --> Output Class Initialized
INFO - 2017-09-06 03:32:45 --> Security Class Initialized
DEBUG - 2017-09-06 03:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:32:45 --> Input Class Initialized
INFO - 2017-09-06 03:32:45 --> Language Class Initialized
INFO - 2017-09-06 03:32:45 --> Loader Class Initialized
INFO - 2017-09-06 03:32:45 --> Controller Class Initialized
INFO - 2017-09-06 03:32:45 --> Database Driver Class Initialized
INFO - 2017-09-06 03:32:45 --> Model Class Initialized
INFO - 2017-09-06 03:32:45 --> Helper loaded: form_helper
INFO - 2017-09-06 03:32:45 --> Helper loaded: url_helper
INFO - 2017-09-06 03:32:45 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:32:45 --> Model Class Initialized
INFO - 2017-09-06 03:32:45 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-06 03:32:45 --> Final output sent to browser
DEBUG - 2017-09-06 03:32:45 --> Total execution time: 0.0920
ERROR - 2017-09-06 03:32:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:32:57 --> Config Class Initialized
INFO - 2017-09-06 03:32:57 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:32:57 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:32:57 --> Utf8 Class Initialized
INFO - 2017-09-06 03:32:57 --> URI Class Initialized
INFO - 2017-09-06 03:32:57 --> Router Class Initialized
INFO - 2017-09-06 03:32:57 --> Output Class Initialized
INFO - 2017-09-06 03:32:57 --> Security Class Initialized
DEBUG - 2017-09-06 03:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:32:57 --> Input Class Initialized
INFO - 2017-09-06 03:32:57 --> Language Class Initialized
INFO - 2017-09-06 03:32:57 --> Loader Class Initialized
INFO - 2017-09-06 03:32:57 --> Controller Class Initialized
INFO - 2017-09-06 03:32:57 --> Database Driver Class Initialized
INFO - 2017-09-06 03:32:57 --> Model Class Initialized
INFO - 2017-09-06 03:32:57 --> Helper loaded: form_helper
INFO - 2017-09-06 03:32:57 --> Helper loaded: url_helper
INFO - 2017-09-06 03:32:57 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:32:57 --> Model Class Initialized
INFO - 2017-09-06 03:32:57 --> File loaded: C:\xampp\htdocs\biper\application\views\purchase.php
INFO - 2017-09-06 03:32:57 --> Final output sent to browser
DEBUG - 2017-09-06 03:32:57 --> Total execution time: 0.1070
ERROR - 2017-09-06 03:33:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:33:04 --> Config Class Initialized
INFO - 2017-09-06 03:33:04 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:33:04 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:33:04 --> Utf8 Class Initialized
INFO - 2017-09-06 03:33:04 --> URI Class Initialized
INFO - 2017-09-06 03:33:04 --> Router Class Initialized
INFO - 2017-09-06 03:33:04 --> Output Class Initialized
INFO - 2017-09-06 03:33:04 --> Security Class Initialized
DEBUG - 2017-09-06 03:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:33:04 --> Input Class Initialized
INFO - 2017-09-06 03:33:04 --> Language Class Initialized
INFO - 2017-09-06 03:33:04 --> Loader Class Initialized
INFO - 2017-09-06 03:33:04 --> Controller Class Initialized
INFO - 2017-09-06 03:33:04 --> Database Driver Class Initialized
INFO - 2017-09-06 03:33:04 --> Model Class Initialized
INFO - 2017-09-06 03:33:04 --> Helper loaded: form_helper
INFO - 2017-09-06 03:33:04 --> Helper loaded: url_helper
INFO - 2017-09-06 03:33:04 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:33:04 --> Model Class Initialized
INFO - 2017-09-06 03:33:04 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-06 03:33:04 --> Final output sent to browser
DEBUG - 2017-09-06 03:33:04 --> Total execution time: 0.0870
ERROR - 2017-09-06 03:37:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:37:33 --> Config Class Initialized
INFO - 2017-09-06 03:37:33 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:37:33 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:37:33 --> Utf8 Class Initialized
INFO - 2017-09-06 03:37:33 --> URI Class Initialized
INFO - 2017-09-06 03:37:33 --> Router Class Initialized
INFO - 2017-09-06 03:37:33 --> Output Class Initialized
INFO - 2017-09-06 03:37:33 --> Security Class Initialized
DEBUG - 2017-09-06 03:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:37:33 --> Input Class Initialized
INFO - 2017-09-06 03:37:33 --> Language Class Initialized
INFO - 2017-09-06 03:37:33 --> Loader Class Initialized
INFO - 2017-09-06 03:37:33 --> Controller Class Initialized
INFO - 2017-09-06 03:37:33 --> Database Driver Class Initialized
INFO - 2017-09-06 03:37:33 --> Model Class Initialized
INFO - 2017-09-06 03:37:33 --> Helper loaded: form_helper
INFO - 2017-09-06 03:37:33 --> Helper loaded: url_helper
INFO - 2017-09-06 03:37:33 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:37:33 --> Model Class Initialized
INFO - 2017-09-06 03:37:33 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-06 03:37:33 --> Final output sent to browser
DEBUG - 2017-09-06 03:37:33 --> Total execution time: 0.1320
ERROR - 2017-09-06 03:37:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:37:42 --> Config Class Initialized
INFO - 2017-09-06 03:37:42 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:37:42 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:37:42 --> Utf8 Class Initialized
INFO - 2017-09-06 03:37:42 --> URI Class Initialized
INFO - 2017-09-06 03:37:42 --> Router Class Initialized
INFO - 2017-09-06 03:37:42 --> Output Class Initialized
INFO - 2017-09-06 03:37:42 --> Security Class Initialized
DEBUG - 2017-09-06 03:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:37:42 --> Input Class Initialized
INFO - 2017-09-06 03:37:42 --> Language Class Initialized
INFO - 2017-09-06 03:37:42 --> Loader Class Initialized
INFO - 2017-09-06 03:37:42 --> Controller Class Initialized
INFO - 2017-09-06 03:37:42 --> Database Driver Class Initialized
INFO - 2017-09-06 03:37:42 --> Model Class Initialized
INFO - 2017-09-06 03:37:42 --> Helper loaded: form_helper
INFO - 2017-09-06 03:37:42 --> Helper loaded: url_helper
INFO - 2017-09-06 03:37:42 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:37:42 --> Model Class Initialized
INFO - 2017-09-06 03:37:42 --> File loaded: C:\xampp\htdocs\biper\application\views\purchase.php
INFO - 2017-09-06 03:37:42 --> Final output sent to browser
DEBUG - 2017-09-06 03:37:42 --> Total execution time: 0.0890
ERROR - 2017-09-06 03:37:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:37:46 --> Config Class Initialized
INFO - 2017-09-06 03:37:46 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:37:46 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:37:46 --> Utf8 Class Initialized
INFO - 2017-09-06 03:37:46 --> URI Class Initialized
INFO - 2017-09-06 03:37:46 --> Router Class Initialized
INFO - 2017-09-06 03:37:46 --> Output Class Initialized
INFO - 2017-09-06 03:37:46 --> Security Class Initialized
DEBUG - 2017-09-06 03:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:37:46 --> Input Class Initialized
INFO - 2017-09-06 03:37:46 --> Language Class Initialized
INFO - 2017-09-06 03:37:46 --> Loader Class Initialized
INFO - 2017-09-06 03:37:46 --> Controller Class Initialized
INFO - 2017-09-06 03:37:46 --> Database Driver Class Initialized
INFO - 2017-09-06 03:37:46 --> Model Class Initialized
INFO - 2017-09-06 03:37:46 --> Helper loaded: form_helper
INFO - 2017-09-06 03:37:46 --> Helper loaded: url_helper
INFO - 2017-09-06 03:37:46 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:37:46 --> Model Class Initialized
INFO - 2017-09-06 03:37:46 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-06 03:37:46 --> Final output sent to browser
DEBUG - 2017-09-06 03:37:46 --> Total execution time: 0.0720
ERROR - 2017-09-06 03:37:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:37:48 --> Config Class Initialized
INFO - 2017-09-06 03:37:48 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:37:48 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:37:48 --> Utf8 Class Initialized
INFO - 2017-09-06 03:37:48 --> URI Class Initialized
INFO - 2017-09-06 03:37:48 --> Router Class Initialized
INFO - 2017-09-06 03:37:48 --> Output Class Initialized
INFO - 2017-09-06 03:37:48 --> Security Class Initialized
DEBUG - 2017-09-06 03:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:37:48 --> Input Class Initialized
INFO - 2017-09-06 03:37:48 --> Language Class Initialized
INFO - 2017-09-06 03:37:48 --> Loader Class Initialized
INFO - 2017-09-06 03:37:48 --> Controller Class Initialized
INFO - 2017-09-06 03:37:48 --> Database Driver Class Initialized
INFO - 2017-09-06 03:37:48 --> Model Class Initialized
INFO - 2017-09-06 03:37:48 --> Helper loaded: form_helper
INFO - 2017-09-06 03:37:48 --> Helper loaded: url_helper
INFO - 2017-09-06 03:37:48 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:37:48 --> Model Class Initialized
INFO - 2017-09-06 03:37:48 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-06 03:37:48 --> Final output sent to browser
DEBUG - 2017-09-06 03:37:48 --> Total execution time: 0.0940
ERROR - 2017-09-06 03:37:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:37:49 --> Config Class Initialized
INFO - 2017-09-06 03:37:49 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:37:49 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:37:49 --> Utf8 Class Initialized
INFO - 2017-09-06 03:37:49 --> URI Class Initialized
INFO - 2017-09-06 03:37:49 --> Router Class Initialized
INFO - 2017-09-06 03:37:49 --> Output Class Initialized
INFO - 2017-09-06 03:37:49 --> Security Class Initialized
DEBUG - 2017-09-06 03:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:37:49 --> Input Class Initialized
INFO - 2017-09-06 03:37:49 --> Language Class Initialized
INFO - 2017-09-06 03:37:49 --> Loader Class Initialized
INFO - 2017-09-06 03:37:49 --> Controller Class Initialized
INFO - 2017-09-06 03:37:49 --> Database Driver Class Initialized
INFO - 2017-09-06 03:37:49 --> Model Class Initialized
INFO - 2017-09-06 03:37:49 --> Helper loaded: form_helper
INFO - 2017-09-06 03:37:49 --> Helper loaded: url_helper
INFO - 2017-09-06 03:37:49 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:37:49 --> Model Class Initialized
INFO - 2017-09-06 03:37:49 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-06 03:37:49 --> Final output sent to browser
DEBUG - 2017-09-06 03:37:49 --> Total execution time: 0.0820
ERROR - 2017-09-06 03:37:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:37:53 --> Config Class Initialized
INFO - 2017-09-06 03:37:53 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:37:53 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:37:53 --> Utf8 Class Initialized
INFO - 2017-09-06 03:37:53 --> URI Class Initialized
INFO - 2017-09-06 03:37:53 --> Router Class Initialized
INFO - 2017-09-06 03:37:53 --> Output Class Initialized
INFO - 2017-09-06 03:37:53 --> Security Class Initialized
DEBUG - 2017-09-06 03:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:37:53 --> Input Class Initialized
INFO - 2017-09-06 03:37:53 --> Language Class Initialized
INFO - 2017-09-06 03:37:53 --> Loader Class Initialized
INFO - 2017-09-06 03:37:53 --> Controller Class Initialized
INFO - 2017-09-06 03:37:53 --> Database Driver Class Initialized
INFO - 2017-09-06 03:37:53 --> Model Class Initialized
INFO - 2017-09-06 03:37:53 --> Helper loaded: form_helper
INFO - 2017-09-06 03:37:53 --> Helper loaded: url_helper
INFO - 2017-09-06 03:37:53 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:37:53 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-06 03:37:53 --> Final output sent to browser
DEBUG - 2017-09-06 03:37:53 --> Total execution time: 0.1010
ERROR - 2017-09-06 03:37:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:37:55 --> Config Class Initialized
INFO - 2017-09-06 03:37:55 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:37:55 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:37:55 --> Utf8 Class Initialized
INFO - 2017-09-06 03:37:55 --> URI Class Initialized
INFO - 2017-09-06 03:37:55 --> Router Class Initialized
INFO - 2017-09-06 03:37:55 --> Output Class Initialized
INFO - 2017-09-06 03:37:55 --> Security Class Initialized
DEBUG - 2017-09-06 03:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:37:56 --> Input Class Initialized
INFO - 2017-09-06 03:37:56 --> Language Class Initialized
INFO - 2017-09-06 03:37:56 --> Loader Class Initialized
INFO - 2017-09-06 03:37:56 --> Controller Class Initialized
INFO - 2017-09-06 03:37:56 --> Database Driver Class Initialized
INFO - 2017-09-06 03:37:56 --> Model Class Initialized
INFO - 2017-09-06 03:37:56 --> Helper loaded: form_helper
INFO - 2017-09-06 03:37:56 --> Helper loaded: url_helper
INFO - 2017-09-06 03:37:56 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:37:56 --> Model Class Initialized
INFO - 2017-09-06 03:37:56 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-06 03:37:56 --> Final output sent to browser
DEBUG - 2017-09-06 03:37:56 --> Total execution time: 0.0990
ERROR - 2017-09-06 03:37:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:37:57 --> Config Class Initialized
INFO - 2017-09-06 03:37:57 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:37:57 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:37:57 --> Utf8 Class Initialized
INFO - 2017-09-06 03:37:57 --> URI Class Initialized
INFO - 2017-09-06 03:37:57 --> Router Class Initialized
INFO - 2017-09-06 03:37:57 --> Output Class Initialized
INFO - 2017-09-06 03:37:57 --> Security Class Initialized
DEBUG - 2017-09-06 03:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:37:57 --> Input Class Initialized
INFO - 2017-09-06 03:37:57 --> Language Class Initialized
INFO - 2017-09-06 03:37:57 --> Loader Class Initialized
INFO - 2017-09-06 03:37:57 --> Controller Class Initialized
INFO - 2017-09-06 03:37:57 --> Database Driver Class Initialized
INFO - 2017-09-06 03:37:57 --> Model Class Initialized
INFO - 2017-09-06 03:37:57 --> Helper loaded: form_helper
INFO - 2017-09-06 03:37:57 --> Helper loaded: url_helper
INFO - 2017-09-06 03:37:57 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:37:57 --> Model Class Initialized
INFO - 2017-09-06 03:37:57 --> File loaded: C:\xampp\htdocs\biper\application\views\purchase.php
INFO - 2017-09-06 03:37:57 --> Final output sent to browser
DEBUG - 2017-09-06 03:37:57 --> Total execution time: 0.0820
ERROR - 2017-09-06 03:42:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:42:23 --> Config Class Initialized
INFO - 2017-09-06 03:42:23 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:42:23 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:42:23 --> Utf8 Class Initialized
INFO - 2017-09-06 03:42:23 --> URI Class Initialized
INFO - 2017-09-06 03:42:23 --> Router Class Initialized
INFO - 2017-09-06 03:42:23 --> Output Class Initialized
INFO - 2017-09-06 03:42:23 --> Security Class Initialized
DEBUG - 2017-09-06 03:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:42:23 --> Input Class Initialized
INFO - 2017-09-06 03:42:23 --> Language Class Initialized
ERROR - 2017-09-06 03:42:23 --> 404 Page Not Found: Mobile/get_videos
ERROR - 2017-09-06 03:42:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:42:38 --> Config Class Initialized
INFO - 2017-09-06 03:42:38 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:42:38 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:42:38 --> Utf8 Class Initialized
INFO - 2017-09-06 03:42:38 --> URI Class Initialized
INFO - 2017-09-06 03:42:38 --> Router Class Initialized
INFO - 2017-09-06 03:42:38 --> Output Class Initialized
INFO - 2017-09-06 03:42:38 --> Security Class Initialized
DEBUG - 2017-09-06 03:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:42:38 --> Input Class Initialized
INFO - 2017-09-06 03:42:38 --> Language Class Initialized
INFO - 2017-09-06 03:42:38 --> Loader Class Initialized
INFO - 2017-09-06 03:42:38 --> Controller Class Initialized
INFO - 2017-09-06 03:42:38 --> Database Driver Class Initialized
INFO - 2017-09-06 03:42:38 --> Model Class Initialized
INFO - 2017-09-06 03:42:38 --> Helper loaded: form_helper
INFO - 2017-09-06 03:42:38 --> Helper loaded: url_helper
INFO - 2017-09-06 03:42:38 --> Model Class Initialized
INFO - 2017-09-06 03:42:38 --> Final output sent to browser
DEBUG - 2017-09-06 03:42:38 --> Total execution time: 0.0720
ERROR - 2017-09-06 03:43:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:43:01 --> Config Class Initialized
INFO - 2017-09-06 03:43:01 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:43:01 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:43:01 --> Utf8 Class Initialized
INFO - 2017-09-06 03:43:01 --> URI Class Initialized
INFO - 2017-09-06 03:43:01 --> Router Class Initialized
INFO - 2017-09-06 03:43:01 --> Output Class Initialized
INFO - 2017-09-06 03:43:01 --> Security Class Initialized
DEBUG - 2017-09-06 03:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:43:01 --> Input Class Initialized
INFO - 2017-09-06 03:43:01 --> Language Class Initialized
INFO - 2017-09-06 03:43:01 --> Loader Class Initialized
INFO - 2017-09-06 03:43:01 --> Controller Class Initialized
INFO - 2017-09-06 03:43:01 --> Database Driver Class Initialized
INFO - 2017-09-06 03:43:01 --> Model Class Initialized
INFO - 2017-09-06 03:43:01 --> Helper loaded: form_helper
INFO - 2017-09-06 03:43:01 --> Helper loaded: url_helper
INFO - 2017-09-06 03:43:01 --> Model Class Initialized
INFO - 2017-09-06 03:43:01 --> Final output sent to browser
DEBUG - 2017-09-06 03:43:01 --> Total execution time: 0.1090
ERROR - 2017-09-06 03:47:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:47:59 --> Config Class Initialized
INFO - 2017-09-06 03:47:59 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:47:59 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:47:59 --> Utf8 Class Initialized
INFO - 2017-09-06 03:47:59 --> URI Class Initialized
INFO - 2017-09-06 03:47:59 --> Router Class Initialized
INFO - 2017-09-06 03:47:59 --> Output Class Initialized
INFO - 2017-09-06 03:47:59 --> Security Class Initialized
DEBUG - 2017-09-06 03:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:47:59 --> Input Class Initialized
INFO - 2017-09-06 03:47:59 --> Language Class Initialized
INFO - 2017-09-06 03:47:59 --> Loader Class Initialized
INFO - 2017-09-06 03:47:59 --> Controller Class Initialized
INFO - 2017-09-06 03:47:59 --> Database Driver Class Initialized
INFO - 2017-09-06 03:47:59 --> Model Class Initialized
INFO - 2017-09-06 03:47:59 --> Helper loaded: form_helper
INFO - 2017-09-06 03:47:59 --> Helper loaded: url_helper
INFO - 2017-09-06 03:47:59 --> Model Class Initialized
INFO - 2017-09-06 03:47:59 --> Final output sent to browser
DEBUG - 2017-09-06 03:47:59 --> Total execution time: 0.1050
ERROR - 2017-09-06 03:48:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:48:23 --> Config Class Initialized
INFO - 2017-09-06 03:48:23 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:48:23 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:48:23 --> Utf8 Class Initialized
INFO - 2017-09-06 03:48:23 --> URI Class Initialized
INFO - 2017-09-06 03:48:23 --> Router Class Initialized
INFO - 2017-09-06 03:48:23 --> Output Class Initialized
INFO - 2017-09-06 03:48:23 --> Security Class Initialized
DEBUG - 2017-09-06 03:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:48:23 --> Input Class Initialized
INFO - 2017-09-06 03:48:23 --> Language Class Initialized
INFO - 2017-09-06 03:48:24 --> Loader Class Initialized
INFO - 2017-09-06 03:48:24 --> Controller Class Initialized
INFO - 2017-09-06 03:48:24 --> Database Driver Class Initialized
INFO - 2017-09-06 03:48:24 --> Model Class Initialized
INFO - 2017-09-06 03:48:24 --> Helper loaded: form_helper
INFO - 2017-09-06 03:48:24 --> Helper loaded: url_helper
INFO - 2017-09-06 03:48:24 --> Model Class Initialized
INFO - 2017-09-06 03:48:24 --> Final output sent to browser
DEBUG - 2017-09-06 03:48:24 --> Total execution time: 0.0670
ERROR - 2017-09-06 03:49:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:49:27 --> Config Class Initialized
INFO - 2017-09-06 03:49:27 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:49:27 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:49:27 --> Utf8 Class Initialized
INFO - 2017-09-06 03:49:27 --> URI Class Initialized
INFO - 2017-09-06 03:49:27 --> Router Class Initialized
INFO - 2017-09-06 03:49:27 --> Output Class Initialized
INFO - 2017-09-06 03:49:27 --> Security Class Initialized
DEBUG - 2017-09-06 03:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:49:27 --> Input Class Initialized
INFO - 2017-09-06 03:49:27 --> Language Class Initialized
INFO - 2017-09-06 03:49:27 --> Loader Class Initialized
INFO - 2017-09-06 03:49:27 --> Controller Class Initialized
INFO - 2017-09-06 03:49:27 --> Database Driver Class Initialized
INFO - 2017-09-06 03:49:27 --> Model Class Initialized
INFO - 2017-09-06 03:49:27 --> Helper loaded: form_helper
INFO - 2017-09-06 03:49:27 --> Helper loaded: url_helper
INFO - 2017-09-06 03:49:27 --> Model Class Initialized
INFO - 2017-09-06 03:49:27 --> Final output sent to browser
DEBUG - 2017-09-06 03:49:27 --> Total execution time: 0.0670
ERROR - 2017-09-06 03:53:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:53:40 --> Config Class Initialized
INFO - 2017-09-06 03:53:40 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:53:40 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:53:40 --> Utf8 Class Initialized
INFO - 2017-09-06 03:53:40 --> URI Class Initialized
INFO - 2017-09-06 03:53:40 --> Router Class Initialized
INFO - 2017-09-06 03:53:40 --> Output Class Initialized
INFO - 2017-09-06 03:53:40 --> Security Class Initialized
DEBUG - 2017-09-06 03:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:53:40 --> Input Class Initialized
INFO - 2017-09-06 03:53:40 --> Language Class Initialized
INFO - 2017-09-06 03:53:40 --> Loader Class Initialized
INFO - 2017-09-06 03:53:40 --> Controller Class Initialized
INFO - 2017-09-06 03:53:40 --> Database Driver Class Initialized
INFO - 2017-09-06 03:53:40 --> Model Class Initialized
INFO - 2017-09-06 03:53:40 --> Helper loaded: form_helper
INFO - 2017-09-06 03:53:40 --> Helper loaded: url_helper
INFO - 2017-09-06 03:53:40 --> Model Class Initialized
INFO - 2017-09-06 03:53:40 --> Final output sent to browser
DEBUG - 2017-09-06 03:53:40 --> Total execution time: 0.1540
ERROR - 2017-09-06 03:53:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:53:46 --> Config Class Initialized
INFO - 2017-09-06 03:53:46 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:53:46 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:53:46 --> Utf8 Class Initialized
INFO - 2017-09-06 03:53:46 --> URI Class Initialized
INFO - 2017-09-06 03:53:46 --> Router Class Initialized
INFO - 2017-09-06 03:53:46 --> Output Class Initialized
INFO - 2017-09-06 03:53:46 --> Security Class Initialized
DEBUG - 2017-09-06 03:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:53:46 --> Input Class Initialized
INFO - 2017-09-06 03:53:46 --> Language Class Initialized
INFO - 2017-09-06 03:53:46 --> Loader Class Initialized
INFO - 2017-09-06 03:53:46 --> Controller Class Initialized
INFO - 2017-09-06 03:53:46 --> Database Driver Class Initialized
INFO - 2017-09-06 03:53:46 --> Model Class Initialized
INFO - 2017-09-06 03:53:46 --> Helper loaded: form_helper
INFO - 2017-09-06 03:53:46 --> Helper loaded: url_helper
INFO - 2017-09-06 03:53:46 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:53:46 --> Model Class Initialized
INFO - 2017-09-06 03:53:46 --> File loaded: C:\xampp\htdocs\biper\application\views\purchase.php
INFO - 2017-09-06 03:53:46 --> Final output sent to browser
DEBUG - 2017-09-06 03:53:46 --> Total execution time: 0.1390
ERROR - 2017-09-06 03:53:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:53:47 --> Config Class Initialized
INFO - 2017-09-06 03:53:47 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:53:47 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:53:47 --> Utf8 Class Initialized
INFO - 2017-09-06 03:53:47 --> URI Class Initialized
INFO - 2017-09-06 03:53:47 --> Router Class Initialized
INFO - 2017-09-06 03:53:47 --> Output Class Initialized
INFO - 2017-09-06 03:53:47 --> Security Class Initialized
DEBUG - 2017-09-06 03:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:53:47 --> Input Class Initialized
INFO - 2017-09-06 03:53:47 --> Language Class Initialized
INFO - 2017-09-06 03:53:47 --> Loader Class Initialized
INFO - 2017-09-06 03:53:47 --> Controller Class Initialized
INFO - 2017-09-06 03:53:47 --> Database Driver Class Initialized
INFO - 2017-09-06 03:53:47 --> Model Class Initialized
INFO - 2017-09-06 03:53:47 --> Helper loaded: form_helper
INFO - 2017-09-06 03:53:47 --> Helper loaded: url_helper
INFO - 2017-09-06 03:53:47 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:53:47 --> Model Class Initialized
INFO - 2017-09-06 03:53:47 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-06 03:53:47 --> Final output sent to browser
DEBUG - 2017-09-06 03:53:47 --> Total execution time: 0.1660
ERROR - 2017-09-06 03:54:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:54:08 --> Config Class Initialized
INFO - 2017-09-06 03:54:08 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:54:08 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:54:08 --> Utf8 Class Initialized
INFO - 2017-09-06 03:54:08 --> URI Class Initialized
INFO - 2017-09-06 03:54:08 --> Router Class Initialized
INFO - 2017-09-06 03:54:08 --> Output Class Initialized
INFO - 2017-09-06 03:54:08 --> Security Class Initialized
DEBUG - 2017-09-06 03:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:54:08 --> Input Class Initialized
INFO - 2017-09-06 03:54:08 --> Language Class Initialized
INFO - 2017-09-06 03:54:08 --> Loader Class Initialized
INFO - 2017-09-06 03:54:08 --> Controller Class Initialized
INFO - 2017-09-06 03:54:08 --> Database Driver Class Initialized
INFO - 2017-09-06 03:54:08 --> Model Class Initialized
INFO - 2017-09-06 03:54:08 --> Helper loaded: form_helper
INFO - 2017-09-06 03:54:08 --> Helper loaded: url_helper
INFO - 2017-09-06 03:54:08 --> Model Class Initialized
INFO - 2017-09-06 03:54:08 --> Final output sent to browser
DEBUG - 2017-09-06 03:54:08 --> Total execution time: 0.0770
ERROR - 2017-09-06 03:54:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:54:10 --> Config Class Initialized
INFO - 2017-09-06 03:54:10 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:54:10 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:54:10 --> Utf8 Class Initialized
INFO - 2017-09-06 03:54:10 --> URI Class Initialized
INFO - 2017-09-06 03:54:10 --> Router Class Initialized
INFO - 2017-09-06 03:54:10 --> Output Class Initialized
INFO - 2017-09-06 03:54:10 --> Security Class Initialized
DEBUG - 2017-09-06 03:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:54:10 --> Input Class Initialized
INFO - 2017-09-06 03:54:10 --> Language Class Initialized
INFO - 2017-09-06 03:54:10 --> Loader Class Initialized
INFO - 2017-09-06 03:54:10 --> Controller Class Initialized
INFO - 2017-09-06 03:54:10 --> Database Driver Class Initialized
INFO - 2017-09-06 03:54:10 --> Model Class Initialized
INFO - 2017-09-06 03:54:10 --> Helper loaded: form_helper
INFO - 2017-09-06 03:54:10 --> Helper loaded: url_helper
INFO - 2017-09-06 03:54:10 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:54:10 --> Model Class Initialized
INFO - 2017-09-06 03:54:10 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-06 03:54:10 --> Final output sent to browser
DEBUG - 2017-09-06 03:54:10 --> Total execution time: 0.1140
ERROR - 2017-09-06 03:54:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:54:21 --> Config Class Initialized
INFO - 2017-09-06 03:54:21 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:54:21 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:54:21 --> Utf8 Class Initialized
INFO - 2017-09-06 03:54:21 --> URI Class Initialized
INFO - 2017-09-06 03:54:21 --> Router Class Initialized
INFO - 2017-09-06 03:54:21 --> Output Class Initialized
INFO - 2017-09-06 03:54:21 --> Security Class Initialized
DEBUG - 2017-09-06 03:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:54:21 --> Input Class Initialized
INFO - 2017-09-06 03:54:21 --> Language Class Initialized
INFO - 2017-09-06 03:54:21 --> Loader Class Initialized
INFO - 2017-09-06 03:54:21 --> Controller Class Initialized
INFO - 2017-09-06 03:54:22 --> Database Driver Class Initialized
INFO - 2017-09-06 03:54:22 --> Model Class Initialized
INFO - 2017-09-06 03:54:22 --> Helper loaded: form_helper
INFO - 2017-09-06 03:54:22 --> Helper loaded: url_helper
INFO - 2017-09-06 03:54:22 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:54:22 --> Model Class Initialized
INFO - 2017-09-06 03:54:22 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-06 03:54:22 --> Final output sent to browser
DEBUG - 2017-09-06 03:54:22 --> Total execution time: 0.1230
ERROR - 2017-09-06 03:54:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:54:23 --> Config Class Initialized
INFO - 2017-09-06 03:54:23 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:54:23 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:54:23 --> Utf8 Class Initialized
INFO - 2017-09-06 03:54:23 --> URI Class Initialized
INFO - 2017-09-06 03:54:23 --> Router Class Initialized
INFO - 2017-09-06 03:54:23 --> Output Class Initialized
INFO - 2017-09-06 03:54:24 --> Security Class Initialized
DEBUG - 2017-09-06 03:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:54:24 --> Input Class Initialized
INFO - 2017-09-06 03:54:24 --> Language Class Initialized
INFO - 2017-09-06 03:54:24 --> Loader Class Initialized
INFO - 2017-09-06 03:54:24 --> Controller Class Initialized
INFO - 2017-09-06 03:54:24 --> Database Driver Class Initialized
INFO - 2017-09-06 03:54:24 --> Model Class Initialized
INFO - 2017-09-06 03:54:24 --> Helper loaded: form_helper
INFO - 2017-09-06 03:54:24 --> Helper loaded: url_helper
INFO - 2017-09-06 03:54:24 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:54:24 --> Model Class Initialized
INFO - 2017-09-06 03:54:24 --> File loaded: C:\xampp\htdocs\biper\application\views\purchase.php
INFO - 2017-09-06 03:54:24 --> Final output sent to browser
DEBUG - 2017-09-06 03:54:24 --> Total execution time: 0.0590
ERROR - 2017-09-06 03:54:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:54:26 --> Config Class Initialized
INFO - 2017-09-06 03:54:26 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:54:26 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:54:26 --> Utf8 Class Initialized
INFO - 2017-09-06 03:54:26 --> URI Class Initialized
INFO - 2017-09-06 03:54:26 --> Router Class Initialized
INFO - 2017-09-06 03:54:26 --> Output Class Initialized
INFO - 2017-09-06 03:54:26 --> Security Class Initialized
DEBUG - 2017-09-06 03:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:54:26 --> Input Class Initialized
INFO - 2017-09-06 03:54:26 --> Language Class Initialized
INFO - 2017-09-06 03:54:26 --> Loader Class Initialized
INFO - 2017-09-06 03:54:26 --> Controller Class Initialized
INFO - 2017-09-06 03:54:26 --> Database Driver Class Initialized
INFO - 2017-09-06 03:54:26 --> Model Class Initialized
INFO - 2017-09-06 03:54:26 --> Helper loaded: form_helper
INFO - 2017-09-06 03:54:26 --> Helper loaded: url_helper
INFO - 2017-09-06 03:54:26 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:54:26 --> Model Class Initialized
INFO - 2017-09-06 03:54:26 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-06 03:54:26 --> Final output sent to browser
DEBUG - 2017-09-06 03:54:26 --> Total execution time: 0.1270
ERROR - 2017-09-06 03:54:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:54:35 --> Config Class Initialized
INFO - 2017-09-06 03:54:35 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:54:35 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:54:35 --> Utf8 Class Initialized
INFO - 2017-09-06 03:54:35 --> URI Class Initialized
INFO - 2017-09-06 03:54:35 --> Router Class Initialized
INFO - 2017-09-06 03:54:35 --> Output Class Initialized
INFO - 2017-09-06 03:54:35 --> Security Class Initialized
DEBUG - 2017-09-06 03:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:54:35 --> Input Class Initialized
INFO - 2017-09-06 03:54:35 --> Language Class Initialized
INFO - 2017-09-06 03:54:35 --> Loader Class Initialized
INFO - 2017-09-06 03:54:35 --> Controller Class Initialized
INFO - 2017-09-06 03:54:35 --> Database Driver Class Initialized
INFO - 2017-09-06 03:54:35 --> Model Class Initialized
INFO - 2017-09-06 03:54:35 --> Helper loaded: form_helper
INFO - 2017-09-06 03:54:35 --> Helper loaded: url_helper
INFO - 2017-09-06 03:54:35 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:54:35 --> Model Class Initialized
INFO - 2017-09-06 03:54:35 --> File loaded: C:\xampp\htdocs\biper\application\views\purchase.php
INFO - 2017-09-06 03:54:35 --> Final output sent to browser
DEBUG - 2017-09-06 03:54:35 --> Total execution time: 0.0560
ERROR - 2017-09-06 03:55:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:55:46 --> Config Class Initialized
INFO - 2017-09-06 03:55:46 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:55:46 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:55:46 --> Utf8 Class Initialized
INFO - 2017-09-06 03:55:46 --> URI Class Initialized
INFO - 2017-09-06 03:55:46 --> Router Class Initialized
INFO - 2017-09-06 03:55:46 --> Output Class Initialized
INFO - 2017-09-06 03:55:46 --> Security Class Initialized
DEBUG - 2017-09-06 03:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:55:46 --> Input Class Initialized
INFO - 2017-09-06 03:55:46 --> Language Class Initialized
INFO - 2017-09-06 03:55:46 --> Loader Class Initialized
INFO - 2017-09-06 03:55:46 --> Controller Class Initialized
INFO - 2017-09-06 03:55:46 --> Database Driver Class Initialized
INFO - 2017-09-06 03:55:46 --> Model Class Initialized
INFO - 2017-09-06 03:55:46 --> Helper loaded: form_helper
INFO - 2017-09-06 03:55:46 --> Helper loaded: url_helper
INFO - 2017-09-06 03:55:46 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:55:46 --> Model Class Initialized
INFO - 2017-09-06 03:55:46 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-06 03:55:46 --> Final output sent to browser
DEBUG - 2017-09-06 03:55:46 --> Total execution time: 0.0990
ERROR - 2017-09-06 03:55:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:55:47 --> Config Class Initialized
INFO - 2017-09-06 03:55:47 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:55:47 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:55:47 --> Utf8 Class Initialized
INFO - 2017-09-06 03:55:47 --> URI Class Initialized
INFO - 2017-09-06 03:55:47 --> Router Class Initialized
INFO - 2017-09-06 03:55:47 --> Output Class Initialized
INFO - 2017-09-06 03:55:47 --> Security Class Initialized
DEBUG - 2017-09-06 03:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:55:47 --> Input Class Initialized
INFO - 2017-09-06 03:55:47 --> Language Class Initialized
INFO - 2017-09-06 03:55:47 --> Loader Class Initialized
INFO - 2017-09-06 03:55:47 --> Controller Class Initialized
INFO - 2017-09-06 03:55:47 --> Database Driver Class Initialized
INFO - 2017-09-06 03:55:47 --> Model Class Initialized
INFO - 2017-09-06 03:55:47 --> Helper loaded: form_helper
INFO - 2017-09-06 03:55:47 --> Helper loaded: url_helper
INFO - 2017-09-06 03:55:47 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:55:47 --> Model Class Initialized
INFO - 2017-09-06 03:55:47 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-06 03:55:47 --> Final output sent to browser
DEBUG - 2017-09-06 03:55:47 --> Total execution time: 0.0830
ERROR - 2017-09-06 03:55:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:55:48 --> Config Class Initialized
INFO - 2017-09-06 03:55:48 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:55:48 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:55:48 --> Utf8 Class Initialized
INFO - 2017-09-06 03:55:48 --> URI Class Initialized
INFO - 2017-09-06 03:55:48 --> Router Class Initialized
INFO - 2017-09-06 03:55:48 --> Output Class Initialized
INFO - 2017-09-06 03:55:48 --> Security Class Initialized
DEBUG - 2017-09-06 03:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:55:48 --> Input Class Initialized
INFO - 2017-09-06 03:55:48 --> Language Class Initialized
INFO - 2017-09-06 03:55:48 --> Loader Class Initialized
INFO - 2017-09-06 03:55:48 --> Controller Class Initialized
INFO - 2017-09-06 03:55:48 --> Database Driver Class Initialized
INFO - 2017-09-06 03:55:48 --> Model Class Initialized
INFO - 2017-09-06 03:55:48 --> Helper loaded: form_helper
INFO - 2017-09-06 03:55:48 --> Helper loaded: url_helper
INFO - 2017-09-06 03:55:48 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:55:48 --> Model Class Initialized
INFO - 2017-09-06 03:55:48 --> File loaded: C:\xampp\htdocs\biper\application\views\purchase.php
INFO - 2017-09-06 03:55:48 --> Final output sent to browser
DEBUG - 2017-09-06 03:55:48 --> Total execution time: 0.0940
ERROR - 2017-09-06 03:55:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-06 03:55:51 --> Config Class Initialized
INFO - 2017-09-06 03:55:51 --> Hooks Class Initialized
DEBUG - 2017-09-06 03:55:51 --> UTF-8 Support Enabled
INFO - 2017-09-06 03:55:51 --> Utf8 Class Initialized
INFO - 2017-09-06 03:55:51 --> URI Class Initialized
INFO - 2017-09-06 03:55:51 --> Router Class Initialized
INFO - 2017-09-06 03:55:51 --> Output Class Initialized
INFO - 2017-09-06 03:55:51 --> Security Class Initialized
DEBUG - 2017-09-06 03:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-06 03:55:51 --> Input Class Initialized
INFO - 2017-09-06 03:55:51 --> Language Class Initialized
INFO - 2017-09-06 03:55:51 --> Loader Class Initialized
INFO - 2017-09-06 03:55:51 --> Controller Class Initialized
INFO - 2017-09-06 03:55:51 --> Database Driver Class Initialized
INFO - 2017-09-06 03:55:51 --> Model Class Initialized
INFO - 2017-09-06 03:55:51 --> Helper loaded: form_helper
INFO - 2017-09-06 03:55:51 --> Helper loaded: url_helper
INFO - 2017-09-06 03:55:51 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-06 03:55:51 --> Model Class Initialized
INFO - 2017-09-06 03:55:51 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-06 03:55:51 --> Final output sent to browser
DEBUG - 2017-09-06 03:55:51 --> Total execution time: 0.1210
