<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-01 16:03:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-01 16:03:51 --> Config Class Initialized
INFO - 2017-08-01 16:03:51 --> Hooks Class Initialized
DEBUG - 2017-08-01 16:03:51 --> UTF-8 Support Enabled
INFO - 2017-08-01 16:03:51 --> Utf8 Class Initialized
INFO - 2017-08-01 16:03:51 --> URI Class Initialized
DEBUG - 2017-08-01 16:03:52 --> No URI present. Default controller set.
INFO - 2017-08-01 16:03:52 --> Router Class Initialized
INFO - 2017-08-01 16:03:52 --> Output Class Initialized
INFO - 2017-08-01 16:03:52 --> Security Class Initialized
DEBUG - 2017-08-01 16:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-01 16:03:52 --> Input Class Initialized
INFO - 2017-08-01 16:03:52 --> Language Class Initialized
INFO - 2017-08-01 16:03:52 --> Loader Class Initialized
INFO - 2017-08-01 16:03:52 --> Controller Class Initialized
INFO - 2017-08-01 16:03:52 --> Database Driver Class Initialized
INFO - 2017-08-01 16:03:52 --> Model Class Initialized
INFO - 2017-08-01 16:03:52 --> Helper loaded: form_helper
INFO - 2017-08-01 16:03:52 --> Helper loaded: url_helper
INFO - 2017-08-01 16:03:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-08-01 16:03:52 --> Final output sent to browser
DEBUG - 2017-08-01 16:03:52 --> Total execution time: 0.0425
ERROR - 2017-08-01 16:03:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-01 16:03:54 --> Config Class Initialized
INFO - 2017-08-01 16:03:54 --> Hooks Class Initialized
DEBUG - 2017-08-01 16:03:54 --> UTF-8 Support Enabled
INFO - 2017-08-01 16:03:54 --> Utf8 Class Initialized
INFO - 2017-08-01 16:03:54 --> URI Class Initialized
INFO - 2017-08-01 16:03:54 --> Router Class Initialized
INFO - 2017-08-01 16:03:54 --> Output Class Initialized
INFO - 2017-08-01 16:03:54 --> Security Class Initialized
DEBUG - 2017-08-01 16:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-01 16:03:54 --> Input Class Initialized
INFO - 2017-08-01 16:03:54 --> Language Class Initialized
INFO - 2017-08-01 16:03:54 --> Loader Class Initialized
INFO - 2017-08-01 16:03:54 --> Controller Class Initialized
INFO - 2017-08-01 16:03:54 --> Database Driver Class Initialized
INFO - 2017-08-01 16:03:54 --> Model Class Initialized
INFO - 2017-08-01 16:03:54 --> Helper loaded: form_helper
INFO - 2017-08-01 16:03:54 --> Helper loaded: url_helper
INFO - 2017-08-01 16:03:54 --> Model Class Initialized
ERROR - 2017-08-01 16:03:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-01 16:03:54 --> Config Class Initialized
INFO - 2017-08-01 16:03:54 --> Hooks Class Initialized
DEBUG - 2017-08-01 16:03:54 --> UTF-8 Support Enabled
INFO - 2017-08-01 16:03:54 --> Utf8 Class Initialized
INFO - 2017-08-01 16:03:54 --> URI Class Initialized
INFO - 2017-08-01 16:03:54 --> Router Class Initialized
INFO - 2017-08-01 16:03:54 --> Output Class Initialized
INFO - 2017-08-01 16:03:54 --> Security Class Initialized
DEBUG - 2017-08-01 16:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-01 16:03:54 --> Input Class Initialized
INFO - 2017-08-01 16:03:54 --> Language Class Initialized
INFO - 2017-08-01 16:03:54 --> Loader Class Initialized
INFO - 2017-08-01 16:03:54 --> Controller Class Initialized
INFO - 2017-08-01 16:03:54 --> Database Driver Class Initialized
INFO - 2017-08-01 16:03:54 --> Model Class Initialized
INFO - 2017-08-01 16:03:54 --> Helper loaded: form_helper
INFO - 2017-08-01 16:03:54 --> Helper loaded: url_helper
INFO - 2017-08-01 16:03:54 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-01 16:03:54 --> Model Class Initialized
INFO - 2017-08-01 16:03:54 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-08-01 16:03:54 --> Final output sent to browser
DEBUG - 2017-08-01 16:03:54 --> Total execution time: 0.0650
