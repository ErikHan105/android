<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-18 03:20:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-18 03:20:11 --> Config Class Initialized
INFO - 2017-08-18 03:20:11 --> Hooks Class Initialized
DEBUG - 2017-08-18 03:20:11 --> UTF-8 Support Enabled
INFO - 2017-08-18 03:20:11 --> Utf8 Class Initialized
INFO - 2017-08-18 03:20:11 --> URI Class Initialized
INFO - 2017-08-18 03:20:11 --> Router Class Initialized
INFO - 2017-08-18 03:20:11 --> Output Class Initialized
INFO - 2017-08-18 03:20:11 --> Security Class Initialized
DEBUG - 2017-08-18 03:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 03:20:11 --> Input Class Initialized
INFO - 2017-08-18 03:20:11 --> Language Class Initialized
INFO - 2017-08-18 03:20:11 --> Loader Class Initialized
INFO - 2017-08-18 03:20:11 --> Controller Class Initialized
INFO - 2017-08-18 03:20:11 --> Database Driver Class Initialized
INFO - 2017-08-18 03:20:11 --> Model Class Initialized
INFO - 2017-08-18 03:20:11 --> Helper loaded: form_helper
INFO - 2017-08-18 03:20:11 --> Helper loaded: url_helper
INFO - 2017-08-18 03:20:11 --> Model Class Initialized
INFO - 2017-08-18 03:20:11 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-18 03:20:11 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-08-18 03:20:11 --> Final output sent to browser
DEBUG - 2017-08-18 03:20:11 --> Total execution time: 0.1390
ERROR - 2017-08-18 08:11:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-18 08:11:14 --> Config Class Initialized
INFO - 2017-08-18 08:11:14 --> Hooks Class Initialized
DEBUG - 2017-08-18 08:11:14 --> UTF-8 Support Enabled
INFO - 2017-08-18 08:11:14 --> Utf8 Class Initialized
INFO - 2017-08-18 08:11:14 --> URI Class Initialized
INFO - 2017-08-18 08:11:14 --> Router Class Initialized
INFO - 2017-08-18 08:11:14 --> Output Class Initialized
INFO - 2017-08-18 08:11:14 --> Security Class Initialized
DEBUG - 2017-08-18 08:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 08:11:14 --> Input Class Initialized
INFO - 2017-08-18 08:11:14 --> Language Class Initialized
INFO - 2017-08-18 08:11:14 --> Loader Class Initialized
INFO - 2017-08-18 08:11:14 --> Controller Class Initialized
INFO - 2017-08-18 08:11:14 --> Database Driver Class Initialized
INFO - 2017-08-18 08:11:14 --> Model Class Initialized
INFO - 2017-08-18 08:11:14 --> Helper loaded: form_helper
INFO - 2017-08-18 08:11:14 --> Helper loaded: url_helper
INFO - 2017-08-18 08:11:14 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-18 08:11:14 --> Model Class Initialized
INFO - 2017-08-18 08:11:14 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-08-18 08:11:14 --> Final output sent to browser
DEBUG - 2017-08-18 08:11:14 --> Total execution time: 0.0880
ERROR - 2017-08-18 08:11:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-18 08:11:23 --> Config Class Initialized
INFO - 2017-08-18 08:11:23 --> Hooks Class Initialized
DEBUG - 2017-08-18 08:11:23 --> UTF-8 Support Enabled
INFO - 2017-08-18 08:11:23 --> Utf8 Class Initialized
INFO - 2017-08-18 08:11:23 --> URI Class Initialized
INFO - 2017-08-18 08:11:23 --> Router Class Initialized
INFO - 2017-08-18 08:11:23 --> Output Class Initialized
INFO - 2017-08-18 08:11:23 --> Security Class Initialized
DEBUG - 2017-08-18 08:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 08:11:23 --> Input Class Initialized
INFO - 2017-08-18 08:11:23 --> Language Class Initialized
INFO - 2017-08-18 08:11:23 --> Loader Class Initialized
INFO - 2017-08-18 08:11:23 --> Controller Class Initialized
INFO - 2017-08-18 08:11:23 --> Database Driver Class Initialized
INFO - 2017-08-18 08:11:23 --> Model Class Initialized
INFO - 2017-08-18 08:11:23 --> Helper loaded: form_helper
INFO - 2017-08-18 08:11:23 --> Helper loaded: url_helper
INFO - 2017-08-18 08:11:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-18 08:11:23 --> Model Class Initialized
INFO - 2017-08-18 08:11:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-08-18 08:11:23 --> Final output sent to browser
DEBUG - 2017-08-18 08:11:23 --> Total execution time: 0.0440
ERROR - 2017-08-18 08:11:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-18 08:11:27 --> Config Class Initialized
INFO - 2017-08-18 08:11:27 --> Hooks Class Initialized
DEBUG - 2017-08-18 08:11:27 --> UTF-8 Support Enabled
INFO - 2017-08-18 08:11:27 --> Utf8 Class Initialized
INFO - 2017-08-18 08:11:27 --> URI Class Initialized
INFO - 2017-08-18 08:11:27 --> Router Class Initialized
INFO - 2017-08-18 08:11:27 --> Output Class Initialized
INFO - 2017-08-18 08:11:27 --> Security Class Initialized
DEBUG - 2017-08-18 08:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 08:11:27 --> Input Class Initialized
INFO - 2017-08-18 08:11:27 --> Language Class Initialized
INFO - 2017-08-18 08:11:27 --> Loader Class Initialized
INFO - 2017-08-18 08:11:27 --> Controller Class Initialized
INFO - 2017-08-18 08:11:27 --> Database Driver Class Initialized
INFO - 2017-08-18 08:11:27 --> Model Class Initialized
INFO - 2017-08-18 08:11:27 --> Helper loaded: form_helper
INFO - 2017-08-18 08:11:27 --> Helper loaded: url_helper
INFO - 2017-08-18 08:11:27 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-18 08:11:27 --> Model Class Initialized
INFO - 2017-08-18 08:11:27 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-08-18 08:11:27 --> Final output sent to browser
DEBUG - 2017-08-18 08:11:27 --> Total execution time: 0.0590
ERROR - 2017-08-18 08:11:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-18 08:11:28 --> Config Class Initialized
INFO - 2017-08-18 08:11:28 --> Hooks Class Initialized
DEBUG - 2017-08-18 08:11:28 --> UTF-8 Support Enabled
INFO - 2017-08-18 08:11:28 --> Utf8 Class Initialized
INFO - 2017-08-18 08:11:28 --> URI Class Initialized
INFO - 2017-08-18 08:11:28 --> Router Class Initialized
INFO - 2017-08-18 08:11:28 --> Output Class Initialized
INFO - 2017-08-18 08:11:28 --> Security Class Initialized
DEBUG - 2017-08-18 08:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 08:11:28 --> Input Class Initialized
INFO - 2017-08-18 08:11:28 --> Language Class Initialized
INFO - 2017-08-18 08:11:28 --> Loader Class Initialized
INFO - 2017-08-18 08:11:28 --> Controller Class Initialized
INFO - 2017-08-18 08:11:28 --> Database Driver Class Initialized
INFO - 2017-08-18 08:11:28 --> Model Class Initialized
INFO - 2017-08-18 08:11:28 --> Helper loaded: form_helper
INFO - 2017-08-18 08:11:28 --> Helper loaded: url_helper
INFO - 2017-08-18 08:11:28 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-18 08:11:28 --> Model Class Initialized
INFO - 2017-08-18 08:11:28 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-08-18 08:11:28 --> Final output sent to browser
DEBUG - 2017-08-18 08:11:28 --> Total execution time: 0.0510
ERROR - 2017-08-18 08:11:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-18 08:11:37 --> Config Class Initialized
INFO - 2017-08-18 08:11:37 --> Hooks Class Initialized
DEBUG - 2017-08-18 08:11:37 --> UTF-8 Support Enabled
INFO - 2017-08-18 08:11:37 --> Utf8 Class Initialized
INFO - 2017-08-18 08:11:37 --> URI Class Initialized
INFO - 2017-08-18 08:11:37 --> Router Class Initialized
INFO - 2017-08-18 08:11:37 --> Output Class Initialized
INFO - 2017-08-18 08:11:37 --> Security Class Initialized
DEBUG - 2017-08-18 08:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 08:11:37 --> Input Class Initialized
INFO - 2017-08-18 08:11:37 --> Language Class Initialized
INFO - 2017-08-18 08:11:37 --> Loader Class Initialized
INFO - 2017-08-18 08:11:37 --> Controller Class Initialized
INFO - 2017-08-18 08:11:37 --> Database Driver Class Initialized
INFO - 2017-08-18 08:11:37 --> Model Class Initialized
INFO - 2017-08-18 08:11:37 --> Helper loaded: form_helper
INFO - 2017-08-18 08:11:37 --> Helper loaded: url_helper
INFO - 2017-08-18 08:11:37 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-18 08:11:37 --> Model Class Initialized
INFO - 2017-08-18 08:11:37 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-08-18 08:11:37 --> Final output sent to browser
DEBUG - 2017-08-18 08:11:37 --> Total execution time: 0.0420
ERROR - 2017-08-18 08:11:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-18 08:11:51 --> Config Class Initialized
INFO - 2017-08-18 08:11:51 --> Hooks Class Initialized
DEBUG - 2017-08-18 08:11:51 --> UTF-8 Support Enabled
INFO - 2017-08-18 08:11:51 --> Utf8 Class Initialized
INFO - 2017-08-18 08:11:51 --> URI Class Initialized
INFO - 2017-08-18 08:11:51 --> Router Class Initialized
INFO - 2017-08-18 08:11:51 --> Output Class Initialized
INFO - 2017-08-18 08:11:51 --> Security Class Initialized
DEBUG - 2017-08-18 08:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 08:11:51 --> Input Class Initialized
INFO - 2017-08-18 08:11:51 --> Language Class Initialized
INFO - 2017-08-18 08:11:51 --> Loader Class Initialized
INFO - 2017-08-18 08:11:51 --> Controller Class Initialized
INFO - 2017-08-18 08:11:51 --> Database Driver Class Initialized
INFO - 2017-08-18 08:11:51 --> Model Class Initialized
INFO - 2017-08-18 08:11:51 --> Helper loaded: form_helper
INFO - 2017-08-18 08:11:51 --> Helper loaded: url_helper
INFO - 2017-08-18 08:11:51 --> Model Class Initialized
INFO - 2017-08-18 08:11:51 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-18 08:11:51 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-08-18 08:11:51 --> Final output sent to browser
DEBUG - 2017-08-18 08:11:51 --> Total execution time: 0.1630
ERROR - 2017-08-18 08:11:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-18 08:11:55 --> Config Class Initialized
INFO - 2017-08-18 08:11:55 --> Hooks Class Initialized
DEBUG - 2017-08-18 08:11:55 --> UTF-8 Support Enabled
INFO - 2017-08-18 08:11:55 --> Utf8 Class Initialized
INFO - 2017-08-18 08:11:55 --> URI Class Initialized
INFO - 2017-08-18 08:11:55 --> Router Class Initialized
INFO - 2017-08-18 08:11:55 --> Output Class Initialized
INFO - 2017-08-18 08:11:55 --> Security Class Initialized
DEBUG - 2017-08-18 08:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 08:11:55 --> Input Class Initialized
INFO - 2017-08-18 08:11:55 --> Language Class Initialized
INFO - 2017-08-18 08:11:55 --> Loader Class Initialized
INFO - 2017-08-18 08:11:55 --> Controller Class Initialized
INFO - 2017-08-18 08:11:55 --> Database Driver Class Initialized
INFO - 2017-08-18 08:11:55 --> Model Class Initialized
INFO - 2017-08-18 08:11:55 --> Helper loaded: form_helper
INFO - 2017-08-18 08:11:55 --> Helper loaded: url_helper
INFO - 2017-08-18 08:11:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-18 08:11:55 --> Model Class Initialized
INFO - 2017-08-18 08:11:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-08-18 08:11:55 --> Final output sent to browser
DEBUG - 2017-08-18 08:11:55 --> Total execution time: 0.0640
ERROR - 2017-08-18 15:02:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-18 15:02:01 --> Config Class Initialized
INFO - 2017-08-18 15:02:01 --> Hooks Class Initialized
DEBUG - 2017-08-18 15:02:01 --> UTF-8 Support Enabled
INFO - 2017-08-18 15:02:01 --> Utf8 Class Initialized
INFO - 2017-08-18 15:02:01 --> URI Class Initialized
DEBUG - 2017-08-18 15:02:01 --> No URI present. Default controller set.
INFO - 2017-08-18 15:02:01 --> Router Class Initialized
INFO - 2017-08-18 15:02:01 --> Output Class Initialized
INFO - 2017-08-18 15:02:01 --> Security Class Initialized
DEBUG - 2017-08-18 15:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 15:02:01 --> Input Class Initialized
INFO - 2017-08-18 15:02:01 --> Language Class Initialized
INFO - 2017-08-18 15:02:01 --> Loader Class Initialized
INFO - 2017-08-18 15:02:01 --> Controller Class Initialized
INFO - 2017-08-18 15:02:01 --> Database Driver Class Initialized
INFO - 2017-08-18 15:02:01 --> Model Class Initialized
INFO - 2017-08-18 15:02:01 --> Helper loaded: form_helper
INFO - 2017-08-18 15:02:01 --> Helper loaded: url_helper
INFO - 2017-08-18 15:02:01 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-08-18 15:02:01 --> Final output sent to browser
DEBUG - 2017-08-18 15:02:01 --> Total execution time: 0.1420
ERROR - 2017-08-18 15:02:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-18 15:02:02 --> Config Class Initialized
INFO - 2017-08-18 15:02:02 --> Hooks Class Initialized
DEBUG - 2017-08-18 15:02:02 --> UTF-8 Support Enabled
INFO - 2017-08-18 15:02:02 --> Utf8 Class Initialized
INFO - 2017-08-18 15:02:02 --> URI Class Initialized
INFO - 2017-08-18 15:02:02 --> Router Class Initialized
INFO - 2017-08-18 15:02:02 --> Output Class Initialized
INFO - 2017-08-18 15:02:02 --> Security Class Initialized
DEBUG - 2017-08-18 15:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 15:02:02 --> Input Class Initialized
INFO - 2017-08-18 15:02:02 --> Language Class Initialized
INFO - 2017-08-18 15:02:02 --> Loader Class Initialized
INFO - 2017-08-18 15:02:02 --> Controller Class Initialized
INFO - 2017-08-18 15:02:02 --> Database Driver Class Initialized
INFO - 2017-08-18 15:02:02 --> Model Class Initialized
INFO - 2017-08-18 15:02:02 --> Helper loaded: form_helper
INFO - 2017-08-18 15:02:02 --> Helper loaded: url_helper
INFO - 2017-08-18 15:02:02 --> Model Class Initialized
ERROR - 2017-08-18 15:02:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-18 15:02:02 --> Config Class Initialized
INFO - 2017-08-18 15:02:02 --> Hooks Class Initialized
DEBUG - 2017-08-18 15:02:02 --> UTF-8 Support Enabled
INFO - 2017-08-18 15:02:02 --> Utf8 Class Initialized
INFO - 2017-08-18 15:02:02 --> URI Class Initialized
INFO - 2017-08-18 15:02:02 --> Router Class Initialized
INFO - 2017-08-18 15:02:02 --> Output Class Initialized
INFO - 2017-08-18 15:02:02 --> Security Class Initialized
DEBUG - 2017-08-18 15:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 15:02:02 --> Input Class Initialized
INFO - 2017-08-18 15:02:02 --> Language Class Initialized
INFO - 2017-08-18 15:02:02 --> Loader Class Initialized
INFO - 2017-08-18 15:02:02 --> Controller Class Initialized
INFO - 2017-08-18 15:02:02 --> Database Driver Class Initialized
INFO - 2017-08-18 15:02:02 --> Model Class Initialized
INFO - 2017-08-18 15:02:02 --> Helper loaded: form_helper
INFO - 2017-08-18 15:02:02 --> Helper loaded: url_helper
INFO - 2017-08-18 15:02:02 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-18 15:02:02 --> Model Class Initialized
INFO - 2017-08-18 15:02:02 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-08-18 15:02:02 --> Final output sent to browser
DEBUG - 2017-08-18 15:02:02 --> Total execution time: 0.1180
ERROR - 2017-08-18 15:02:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-18 15:02:06 --> Config Class Initialized
INFO - 2017-08-18 15:02:06 --> Hooks Class Initialized
DEBUG - 2017-08-18 15:02:06 --> UTF-8 Support Enabled
INFO - 2017-08-18 15:02:06 --> Utf8 Class Initialized
INFO - 2017-08-18 15:02:06 --> URI Class Initialized
INFO - 2017-08-18 15:02:06 --> Router Class Initialized
INFO - 2017-08-18 15:02:06 --> Output Class Initialized
INFO - 2017-08-18 15:02:06 --> Security Class Initialized
DEBUG - 2017-08-18 15:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 15:02:06 --> Input Class Initialized
INFO - 2017-08-18 15:02:06 --> Language Class Initialized
INFO - 2017-08-18 15:02:06 --> Loader Class Initialized
INFO - 2017-08-18 15:02:06 --> Controller Class Initialized
INFO - 2017-08-18 15:02:06 --> Database Driver Class Initialized
INFO - 2017-08-18 15:02:06 --> Model Class Initialized
INFO - 2017-08-18 15:02:06 --> Helper loaded: form_helper
INFO - 2017-08-18 15:02:06 --> Helper loaded: url_helper
INFO - 2017-08-18 15:02:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-18 15:02:06 --> Model Class Initialized
INFO - 2017-08-18 15:02:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-08-18 15:02:06 --> Final output sent to browser
DEBUG - 2017-08-18 15:02:06 --> Total execution time: 0.1150
ERROR - 2017-08-18 15:02:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-18 15:02:12 --> Config Class Initialized
INFO - 2017-08-18 15:02:12 --> Hooks Class Initialized
DEBUG - 2017-08-18 15:02:12 --> UTF-8 Support Enabled
INFO - 2017-08-18 15:02:12 --> Utf8 Class Initialized
INFO - 2017-08-18 15:02:12 --> URI Class Initialized
INFO - 2017-08-18 15:02:12 --> Router Class Initialized
INFO - 2017-08-18 15:02:12 --> Output Class Initialized
INFO - 2017-08-18 15:02:12 --> Security Class Initialized
DEBUG - 2017-08-18 15:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-18 15:02:12 --> Input Class Initialized
INFO - 2017-08-18 15:02:12 --> Language Class Initialized
INFO - 2017-08-18 15:02:12 --> Loader Class Initialized
INFO - 2017-08-18 15:02:12 --> Controller Class Initialized
INFO - 2017-08-18 15:02:12 --> Database Driver Class Initialized
INFO - 2017-08-18 15:02:12 --> Model Class Initialized
INFO - 2017-08-18 15:02:12 --> Helper loaded: form_helper
INFO - 2017-08-18 15:02:12 --> Helper loaded: url_helper
INFO - 2017-08-18 15:02:12 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-18 15:02:12 --> Model Class Initialized
INFO - 2017-08-18 15:02:12 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-08-18 15:02:12 --> Final output sent to browser
DEBUG - 2017-08-18 15:02:12 --> Total execution time: 0.0620
