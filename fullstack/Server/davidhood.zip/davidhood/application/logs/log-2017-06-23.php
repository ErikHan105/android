<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-23 03:43:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:43:38 --> Config Class Initialized
INFO - 2017-06-23 03:43:38 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:43:38 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:43:38 --> Utf8 Class Initialized
INFO - 2017-06-23 03:43:38 --> URI Class Initialized
INFO - 2017-06-23 03:43:38 --> Router Class Initialized
INFO - 2017-06-23 03:43:38 --> Output Class Initialized
INFO - 2017-06-23 03:43:38 --> Security Class Initialized
DEBUG - 2017-06-23 03:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:43:38 --> Input Class Initialized
INFO - 2017-06-23 03:43:38 --> Language Class Initialized
INFO - 2017-06-23 03:43:38 --> Loader Class Initialized
INFO - 2017-06-23 03:43:38 --> Controller Class Initialized
INFO - 2017-06-23 03:43:38 --> Database Driver Class Initialized
INFO - 2017-06-23 03:43:38 --> Model Class Initialized
INFO - 2017-06-23 03:43:38 --> Helper loaded: form_helper
INFO - 2017-06-23 03:43:38 --> Helper loaded: url_helper
INFO - 2017-06-23 03:43:38 --> Model Class Initialized
INFO - 2017-06-23 03:43:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 03:43:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 03:43:38 --> Final output sent to browser
DEBUG - 2017-06-23 03:43:38 --> Total execution time: 0.0660
ERROR - 2017-06-23 03:43:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:43:40 --> Config Class Initialized
INFO - 2017-06-23 03:43:40 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:43:40 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:43:40 --> Utf8 Class Initialized
INFO - 2017-06-23 03:43:40 --> URI Class Initialized
INFO - 2017-06-23 03:43:40 --> Router Class Initialized
INFO - 2017-06-23 03:43:40 --> Output Class Initialized
INFO - 2017-06-23 03:43:40 --> Security Class Initialized
DEBUG - 2017-06-23 03:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:43:40 --> Input Class Initialized
INFO - 2017-06-23 03:43:40 --> Language Class Initialized
INFO - 2017-06-23 03:43:40 --> Loader Class Initialized
INFO - 2017-06-23 03:43:40 --> Controller Class Initialized
INFO - 2017-06-23 03:43:40 --> Database Driver Class Initialized
INFO - 2017-06-23 03:43:40 --> Model Class Initialized
INFO - 2017-06-23 03:43:40 --> Helper loaded: form_helper
INFO - 2017-06-23 03:43:40 --> Helper loaded: url_helper
INFO - 2017-06-23 03:43:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 03:43:40 --> Model Class Initialized
INFO - 2017-06-23 03:43:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 03:43:40 --> Final output sent to browser
DEBUG - 2017-06-23 03:43:40 --> Total execution time: 0.0540
ERROR - 2017-06-23 03:43:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:43:43 --> Config Class Initialized
INFO - 2017-06-23 03:43:43 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:43:43 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:43:43 --> Utf8 Class Initialized
INFO - 2017-06-23 03:43:43 --> URI Class Initialized
INFO - 2017-06-23 03:43:43 --> Router Class Initialized
INFO - 2017-06-23 03:43:43 --> Output Class Initialized
INFO - 2017-06-23 03:43:43 --> Security Class Initialized
DEBUG - 2017-06-23 03:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:43:43 --> Input Class Initialized
INFO - 2017-06-23 03:43:43 --> Language Class Initialized
INFO - 2017-06-23 03:43:43 --> Loader Class Initialized
INFO - 2017-06-23 03:43:43 --> Controller Class Initialized
INFO - 2017-06-23 03:43:43 --> Database Driver Class Initialized
INFO - 2017-06-23 03:43:43 --> Model Class Initialized
INFO - 2017-06-23 03:43:43 --> Helper loaded: form_helper
INFO - 2017-06-23 03:43:43 --> Helper loaded: url_helper
INFO - 2017-06-23 03:43:43 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 03:43:43 --> Model Class Initialized
INFO - 2017-06-23 03:43:43 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-23 03:43:43 --> Final output sent to browser
DEBUG - 2017-06-23 03:43:43 --> Total execution time: 0.0540
ERROR - 2017-06-23 03:43:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:43:46 --> Config Class Initialized
INFO - 2017-06-23 03:43:46 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:43:46 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:43:46 --> Utf8 Class Initialized
INFO - 2017-06-23 03:43:46 --> URI Class Initialized
INFO - 2017-06-23 03:43:46 --> Router Class Initialized
INFO - 2017-06-23 03:43:46 --> Output Class Initialized
INFO - 2017-06-23 03:43:46 --> Security Class Initialized
DEBUG - 2017-06-23 03:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:43:46 --> Input Class Initialized
INFO - 2017-06-23 03:43:46 --> Language Class Initialized
INFO - 2017-06-23 03:43:46 --> Loader Class Initialized
INFO - 2017-06-23 03:43:46 --> Controller Class Initialized
INFO - 2017-06-23 03:43:46 --> Database Driver Class Initialized
INFO - 2017-06-23 03:43:46 --> Model Class Initialized
INFO - 2017-06-23 03:43:46 --> Helper loaded: form_helper
INFO - 2017-06-23 03:43:46 --> Helper loaded: url_helper
INFO - 2017-06-23 03:43:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 03:43:46 --> Model Class Initialized
INFO - 2017-06-23 03:43:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 03:43:46 --> Final output sent to browser
DEBUG - 2017-06-23 03:43:46 --> Total execution time: 0.0440
ERROR - 2017-06-23 03:43:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:43:48 --> Config Class Initialized
INFO - 2017-06-23 03:43:48 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:43:48 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:43:48 --> Utf8 Class Initialized
INFO - 2017-06-23 03:43:48 --> URI Class Initialized
INFO - 2017-06-23 03:43:48 --> Router Class Initialized
INFO - 2017-06-23 03:43:48 --> Output Class Initialized
INFO - 2017-06-23 03:43:48 --> Security Class Initialized
DEBUG - 2017-06-23 03:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:43:48 --> Input Class Initialized
INFO - 2017-06-23 03:43:48 --> Language Class Initialized
INFO - 2017-06-23 03:43:48 --> Loader Class Initialized
INFO - 2017-06-23 03:43:48 --> Controller Class Initialized
INFO - 2017-06-23 03:43:48 --> Database Driver Class Initialized
INFO - 2017-06-23 03:43:48 --> Model Class Initialized
INFO - 2017-06-23 03:43:48 --> Helper loaded: form_helper
INFO - 2017-06-23 03:43:48 --> Helper loaded: url_helper
INFO - 2017-06-23 03:43:48 --> Model Class Initialized
INFO - 2017-06-23 03:43:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 03:43:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 03:43:49 --> Final output sent to browser
DEBUG - 2017-06-23 03:43:49 --> Total execution time: 0.2920
ERROR - 2017-06-23 03:43:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:43:58 --> Config Class Initialized
INFO - 2017-06-23 03:43:58 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:43:58 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:43:58 --> Utf8 Class Initialized
INFO - 2017-06-23 03:43:58 --> URI Class Initialized
INFO - 2017-06-23 03:43:58 --> Router Class Initialized
INFO - 2017-06-23 03:43:58 --> Output Class Initialized
INFO - 2017-06-23 03:43:58 --> Security Class Initialized
DEBUG - 2017-06-23 03:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:43:58 --> Input Class Initialized
INFO - 2017-06-23 03:43:58 --> Language Class Initialized
INFO - 2017-06-23 03:43:58 --> Loader Class Initialized
INFO - 2017-06-23 03:43:58 --> Controller Class Initialized
INFO - 2017-06-23 03:43:58 --> Database Driver Class Initialized
INFO - 2017-06-23 03:43:58 --> Model Class Initialized
INFO - 2017-06-23 03:43:58 --> Helper loaded: form_helper
INFO - 2017-06-23 03:43:58 --> Helper loaded: url_helper
INFO - 2017-06-23 03:43:58 --> Model Class Initialized
INFO - 2017-06-23 03:43:58 --> Final output sent to browser
DEBUG - 2017-06-23 03:43:58 --> Total execution time: 0.0640
ERROR - 2017-06-23 03:43:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:43:59 --> Config Class Initialized
INFO - 2017-06-23 03:43:59 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:43:59 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:43:59 --> Utf8 Class Initialized
INFO - 2017-06-23 03:43:59 --> URI Class Initialized
INFO - 2017-06-23 03:43:59 --> Router Class Initialized
INFO - 2017-06-23 03:43:59 --> Output Class Initialized
INFO - 2017-06-23 03:43:59 --> Security Class Initialized
DEBUG - 2017-06-23 03:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:43:59 --> Input Class Initialized
INFO - 2017-06-23 03:43:59 --> Language Class Initialized
INFO - 2017-06-23 03:43:59 --> Loader Class Initialized
INFO - 2017-06-23 03:43:59 --> Controller Class Initialized
INFO - 2017-06-23 03:43:59 --> Database Driver Class Initialized
INFO - 2017-06-23 03:43:59 --> Model Class Initialized
INFO - 2017-06-23 03:43:59 --> Helper loaded: form_helper
INFO - 2017-06-23 03:43:59 --> Helper loaded: url_helper
INFO - 2017-06-23 03:43:59 --> Model Class Initialized
INFO - 2017-06-23 03:43:59 --> Final output sent to browser
DEBUG - 2017-06-23 03:43:59 --> Total execution time: 0.0510
ERROR - 2017-06-23 03:44:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:44:00 --> Config Class Initialized
INFO - 2017-06-23 03:44:00 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:44:00 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:44:00 --> Utf8 Class Initialized
INFO - 2017-06-23 03:44:00 --> URI Class Initialized
INFO - 2017-06-23 03:44:00 --> Router Class Initialized
INFO - 2017-06-23 03:44:00 --> Output Class Initialized
INFO - 2017-06-23 03:44:00 --> Security Class Initialized
DEBUG - 2017-06-23 03:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:44:00 --> Input Class Initialized
INFO - 2017-06-23 03:44:00 --> Language Class Initialized
INFO - 2017-06-23 03:44:00 --> Loader Class Initialized
INFO - 2017-06-23 03:44:00 --> Controller Class Initialized
INFO - 2017-06-23 03:44:00 --> Database Driver Class Initialized
INFO - 2017-06-23 03:44:00 --> Model Class Initialized
INFO - 2017-06-23 03:44:00 --> Helper loaded: form_helper
INFO - 2017-06-23 03:44:00 --> Helper loaded: url_helper
INFO - 2017-06-23 03:44:00 --> Model Class Initialized
INFO - 2017-06-23 03:44:00 --> Final output sent to browser
DEBUG - 2017-06-23 03:44:00 --> Total execution time: 0.0550
ERROR - 2017-06-23 03:44:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:44:05 --> Config Class Initialized
INFO - 2017-06-23 03:44:05 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:44:05 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:44:05 --> Utf8 Class Initialized
INFO - 2017-06-23 03:44:05 --> URI Class Initialized
INFO - 2017-06-23 03:44:05 --> Router Class Initialized
INFO - 2017-06-23 03:44:05 --> Output Class Initialized
INFO - 2017-06-23 03:44:05 --> Security Class Initialized
DEBUG - 2017-06-23 03:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:44:05 --> Input Class Initialized
INFO - 2017-06-23 03:44:05 --> Language Class Initialized
INFO - 2017-06-23 03:44:05 --> Loader Class Initialized
INFO - 2017-06-23 03:44:05 --> Controller Class Initialized
INFO - 2017-06-23 03:44:05 --> Database Driver Class Initialized
INFO - 2017-06-23 03:44:05 --> Model Class Initialized
INFO - 2017-06-23 03:44:05 --> Helper loaded: form_helper
INFO - 2017-06-23 03:44:05 --> Helper loaded: url_helper
INFO - 2017-06-23 03:44:05 --> Model Class Initialized
INFO - 2017-06-23 03:44:05 --> Final output sent to browser
DEBUG - 2017-06-23 03:44:05 --> Total execution time: 0.0400
ERROR - 2017-06-23 03:44:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:44:08 --> Config Class Initialized
INFO - 2017-06-23 03:44:08 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:44:08 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:44:08 --> Utf8 Class Initialized
INFO - 2017-06-23 03:44:08 --> URI Class Initialized
INFO - 2017-06-23 03:44:08 --> Router Class Initialized
INFO - 2017-06-23 03:44:08 --> Output Class Initialized
INFO - 2017-06-23 03:44:08 --> Security Class Initialized
DEBUG - 2017-06-23 03:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:44:08 --> Input Class Initialized
INFO - 2017-06-23 03:44:08 --> Language Class Initialized
INFO - 2017-06-23 03:44:08 --> Loader Class Initialized
INFO - 2017-06-23 03:44:08 --> Controller Class Initialized
INFO - 2017-06-23 03:44:08 --> Database Driver Class Initialized
INFO - 2017-06-23 03:44:08 --> Model Class Initialized
INFO - 2017-06-23 03:44:08 --> Helper loaded: form_helper
INFO - 2017-06-23 03:44:08 --> Helper loaded: url_helper
INFO - 2017-06-23 03:44:08 --> Model Class Initialized
INFO - 2017-06-23 03:44:08 --> Final output sent to browser
DEBUG - 2017-06-23 03:44:08 --> Total execution time: 0.0470
ERROR - 2017-06-23 03:44:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:44:12 --> Config Class Initialized
INFO - 2017-06-23 03:44:12 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:44:12 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:44:12 --> Utf8 Class Initialized
INFO - 2017-06-23 03:44:12 --> URI Class Initialized
INFO - 2017-06-23 03:44:12 --> Router Class Initialized
INFO - 2017-06-23 03:44:12 --> Output Class Initialized
INFO - 2017-06-23 03:44:12 --> Security Class Initialized
DEBUG - 2017-06-23 03:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:44:12 --> Input Class Initialized
INFO - 2017-06-23 03:44:12 --> Language Class Initialized
INFO - 2017-06-23 03:44:12 --> Loader Class Initialized
INFO - 2017-06-23 03:44:12 --> Controller Class Initialized
INFO - 2017-06-23 03:44:12 --> Database Driver Class Initialized
INFO - 2017-06-23 03:44:12 --> Model Class Initialized
INFO - 2017-06-23 03:44:12 --> Helper loaded: form_helper
INFO - 2017-06-23 03:44:12 --> Helper loaded: url_helper
INFO - 2017-06-23 03:44:12 --> Model Class Initialized
INFO - 2017-06-23 03:44:12 --> Final output sent to browser
DEBUG - 2017-06-23 03:44:12 --> Total execution time: 0.0650
ERROR - 2017-06-23 03:44:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:44:24 --> Config Class Initialized
INFO - 2017-06-23 03:44:24 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:44:24 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:44:24 --> Utf8 Class Initialized
INFO - 2017-06-23 03:44:24 --> URI Class Initialized
INFO - 2017-06-23 03:44:24 --> Router Class Initialized
INFO - 2017-06-23 03:44:24 --> Output Class Initialized
INFO - 2017-06-23 03:44:24 --> Security Class Initialized
DEBUG - 2017-06-23 03:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:44:24 --> Input Class Initialized
INFO - 2017-06-23 03:44:24 --> Language Class Initialized
INFO - 2017-06-23 03:44:24 --> Loader Class Initialized
INFO - 2017-06-23 03:44:24 --> Controller Class Initialized
INFO - 2017-06-23 03:44:24 --> Database Driver Class Initialized
INFO - 2017-06-23 03:44:24 --> Model Class Initialized
INFO - 2017-06-23 03:44:24 --> Helper loaded: form_helper
INFO - 2017-06-23 03:44:24 --> Helper loaded: url_helper
INFO - 2017-06-23 03:44:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 03:44:24 --> Model Class Initialized
INFO - 2017-06-23 03:44:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-23 03:44:24 --> Final output sent to browser
DEBUG - 2017-06-23 03:44:24 --> Total execution time: 0.0520
ERROR - 2017-06-23 03:44:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:44:27 --> Config Class Initialized
INFO - 2017-06-23 03:44:27 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:44:27 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:44:27 --> Utf8 Class Initialized
INFO - 2017-06-23 03:44:27 --> URI Class Initialized
INFO - 2017-06-23 03:44:27 --> Router Class Initialized
INFO - 2017-06-23 03:44:27 --> Output Class Initialized
INFO - 2017-06-23 03:44:27 --> Security Class Initialized
DEBUG - 2017-06-23 03:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:44:27 --> Input Class Initialized
INFO - 2017-06-23 03:44:27 --> Language Class Initialized
INFO - 2017-06-23 03:44:27 --> Loader Class Initialized
INFO - 2017-06-23 03:44:27 --> Controller Class Initialized
INFO - 2017-06-23 03:44:27 --> Database Driver Class Initialized
INFO - 2017-06-23 03:44:27 --> Model Class Initialized
INFO - 2017-06-23 03:44:27 --> Helper loaded: form_helper
INFO - 2017-06-23 03:44:27 --> Helper loaded: url_helper
INFO - 2017-06-23 03:44:27 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 03:44:27 --> Model Class Initialized
INFO - 2017-06-23 03:44:27 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 03:44:27 --> Final output sent to browser
DEBUG - 2017-06-23 03:44:27 --> Total execution time: 0.0510
ERROR - 2017-06-23 03:44:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:44:55 --> Config Class Initialized
INFO - 2017-06-23 03:44:55 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:44:55 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:44:55 --> Utf8 Class Initialized
INFO - 2017-06-23 03:44:55 --> URI Class Initialized
INFO - 2017-06-23 03:44:55 --> Router Class Initialized
INFO - 2017-06-23 03:44:55 --> Output Class Initialized
INFO - 2017-06-23 03:44:55 --> Security Class Initialized
DEBUG - 2017-06-23 03:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:44:56 --> Input Class Initialized
INFO - 2017-06-23 03:44:56 --> Language Class Initialized
INFO - 2017-06-23 03:44:56 --> Loader Class Initialized
INFO - 2017-06-23 03:44:56 --> Controller Class Initialized
INFO - 2017-06-23 03:44:56 --> Database Driver Class Initialized
INFO - 2017-06-23 03:44:56 --> Model Class Initialized
INFO - 2017-06-23 03:44:56 --> Helper loaded: form_helper
INFO - 2017-06-23 03:44:56 --> Helper loaded: url_helper
INFO - 2017-06-23 03:44:56 --> Model Class Initialized
INFO - 2017-06-23 03:44:56 --> Final output sent to browser
DEBUG - 2017-06-23 03:44:56 --> Total execution time: 0.0570
ERROR - 2017-06-23 03:50:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:50:52 --> Config Class Initialized
INFO - 2017-06-23 03:50:52 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:50:52 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:50:52 --> Utf8 Class Initialized
INFO - 2017-06-23 03:50:52 --> URI Class Initialized
INFO - 2017-06-23 03:50:52 --> Router Class Initialized
INFO - 2017-06-23 03:50:52 --> Output Class Initialized
INFO - 2017-06-23 03:50:52 --> Security Class Initialized
DEBUG - 2017-06-23 03:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:50:52 --> Input Class Initialized
INFO - 2017-06-23 03:50:52 --> Language Class Initialized
INFO - 2017-06-23 03:50:52 --> Loader Class Initialized
INFO - 2017-06-23 03:50:52 --> Controller Class Initialized
INFO - 2017-06-23 03:50:52 --> Database Driver Class Initialized
INFO - 2017-06-23 03:50:52 --> Model Class Initialized
INFO - 2017-06-23 03:50:52 --> Helper loaded: form_helper
INFO - 2017-06-23 03:50:52 --> Helper loaded: url_helper
INFO - 2017-06-23 03:50:52 --> Model Class Initialized
INFO - 2017-06-23 03:50:52 --> Final output sent to browser
DEBUG - 2017-06-23 03:50:52 --> Total execution time: 0.0530
ERROR - 2017-06-23 03:50:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:50:53 --> Config Class Initialized
INFO - 2017-06-23 03:50:53 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:50:53 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:50:53 --> Utf8 Class Initialized
INFO - 2017-06-23 03:50:53 --> URI Class Initialized
INFO - 2017-06-23 03:50:53 --> Router Class Initialized
INFO - 2017-06-23 03:50:53 --> Output Class Initialized
INFO - 2017-06-23 03:50:53 --> Security Class Initialized
DEBUG - 2017-06-23 03:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:50:53 --> Input Class Initialized
INFO - 2017-06-23 03:50:53 --> Language Class Initialized
INFO - 2017-06-23 03:50:53 --> Loader Class Initialized
INFO - 2017-06-23 03:50:53 --> Controller Class Initialized
INFO - 2017-06-23 03:50:53 --> Database Driver Class Initialized
INFO - 2017-06-23 03:50:53 --> Model Class Initialized
INFO - 2017-06-23 03:50:53 --> Helper loaded: form_helper
INFO - 2017-06-23 03:50:53 --> Helper loaded: url_helper
INFO - 2017-06-23 03:50:53 --> Model Class Initialized
INFO - 2017-06-23 03:50:53 --> Final output sent to browser
DEBUG - 2017-06-23 03:50:53 --> Total execution time: 0.0580
ERROR - 2017-06-23 03:50:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:50:58 --> Config Class Initialized
INFO - 2017-06-23 03:50:58 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:50:58 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:50:58 --> Utf8 Class Initialized
INFO - 2017-06-23 03:50:58 --> URI Class Initialized
INFO - 2017-06-23 03:50:58 --> Router Class Initialized
INFO - 2017-06-23 03:50:58 --> Output Class Initialized
INFO - 2017-06-23 03:50:58 --> Security Class Initialized
DEBUG - 2017-06-23 03:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:50:58 --> Input Class Initialized
INFO - 2017-06-23 03:50:58 --> Language Class Initialized
INFO - 2017-06-23 03:50:58 --> Loader Class Initialized
INFO - 2017-06-23 03:50:58 --> Controller Class Initialized
INFO - 2017-06-23 03:50:58 --> Database Driver Class Initialized
INFO - 2017-06-23 03:50:58 --> Model Class Initialized
INFO - 2017-06-23 03:50:58 --> Helper loaded: form_helper
INFO - 2017-06-23 03:50:58 --> Helper loaded: url_helper
INFO - 2017-06-23 03:50:58 --> Model Class Initialized
INFO - 2017-06-23 03:50:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 03:50:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 03:50:58 --> Final output sent to browser
DEBUG - 2017-06-23 03:50:58 --> Total execution time: 0.0870
ERROR - 2017-06-23 03:51:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:51:01 --> Config Class Initialized
INFO - 2017-06-23 03:51:01 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:51:01 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:51:01 --> Utf8 Class Initialized
INFO - 2017-06-23 03:51:01 --> URI Class Initialized
INFO - 2017-06-23 03:51:01 --> Router Class Initialized
INFO - 2017-06-23 03:51:01 --> Output Class Initialized
INFO - 2017-06-23 03:51:01 --> Security Class Initialized
DEBUG - 2017-06-23 03:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:51:01 --> Input Class Initialized
INFO - 2017-06-23 03:51:01 --> Language Class Initialized
INFO - 2017-06-23 03:51:01 --> Loader Class Initialized
INFO - 2017-06-23 03:51:01 --> Controller Class Initialized
INFO - 2017-06-23 03:51:01 --> Database Driver Class Initialized
INFO - 2017-06-23 03:51:01 --> Model Class Initialized
INFO - 2017-06-23 03:51:01 --> Helper loaded: form_helper
INFO - 2017-06-23 03:51:01 --> Helper loaded: url_helper
INFO - 2017-06-23 03:51:01 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 03:51:01 --> Model Class Initialized
INFO - 2017-06-23 03:51:01 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-23 03:51:01 --> Final output sent to browser
DEBUG - 2017-06-23 03:51:01 --> Total execution time: 0.0620
ERROR - 2017-06-23 03:51:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:51:03 --> Config Class Initialized
INFO - 2017-06-23 03:51:03 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:51:03 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:51:03 --> Utf8 Class Initialized
INFO - 2017-06-23 03:51:03 --> URI Class Initialized
INFO - 2017-06-23 03:51:03 --> Router Class Initialized
INFO - 2017-06-23 03:51:03 --> Output Class Initialized
INFO - 2017-06-23 03:51:03 --> Security Class Initialized
DEBUG - 2017-06-23 03:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:51:03 --> Input Class Initialized
INFO - 2017-06-23 03:51:03 --> Language Class Initialized
INFO - 2017-06-23 03:51:03 --> Loader Class Initialized
INFO - 2017-06-23 03:51:03 --> Controller Class Initialized
INFO - 2017-06-23 03:51:03 --> Database Driver Class Initialized
INFO - 2017-06-23 03:51:03 --> Model Class Initialized
INFO - 2017-06-23 03:51:03 --> Helper loaded: form_helper
INFO - 2017-06-23 03:51:03 --> Helper loaded: url_helper
INFO - 2017-06-23 03:51:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 03:51:03 --> Model Class Initialized
INFO - 2017-06-23 03:51:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 03:51:03 --> Final output sent to browser
DEBUG - 2017-06-23 03:51:03 --> Total execution time: 0.0660
ERROR - 2017-06-23 03:51:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:51:06 --> Config Class Initialized
INFO - 2017-06-23 03:51:06 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:51:06 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:51:06 --> Utf8 Class Initialized
INFO - 2017-06-23 03:51:06 --> URI Class Initialized
INFO - 2017-06-23 03:51:06 --> Router Class Initialized
INFO - 2017-06-23 03:51:06 --> Output Class Initialized
INFO - 2017-06-23 03:51:06 --> Security Class Initialized
DEBUG - 2017-06-23 03:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:51:06 --> Input Class Initialized
INFO - 2017-06-23 03:51:06 --> Language Class Initialized
INFO - 2017-06-23 03:51:06 --> Loader Class Initialized
INFO - 2017-06-23 03:51:06 --> Controller Class Initialized
INFO - 2017-06-23 03:51:06 --> Database Driver Class Initialized
INFO - 2017-06-23 03:51:06 --> Model Class Initialized
INFO - 2017-06-23 03:51:06 --> Helper loaded: form_helper
INFO - 2017-06-23 03:51:06 --> Helper loaded: url_helper
INFO - 2017-06-23 03:51:06 --> Model Class Initialized
INFO - 2017-06-23 03:51:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 03:51:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 03:51:06 --> Final output sent to browser
DEBUG - 2017-06-23 03:51:06 --> Total execution time: 0.3590
ERROR - 2017-06-23 03:51:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:51:11 --> Config Class Initialized
INFO - 2017-06-23 03:51:11 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:51:11 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:51:11 --> Utf8 Class Initialized
INFO - 2017-06-23 03:51:11 --> URI Class Initialized
INFO - 2017-06-23 03:51:11 --> Router Class Initialized
INFO - 2017-06-23 03:51:11 --> Output Class Initialized
INFO - 2017-06-23 03:51:11 --> Security Class Initialized
DEBUG - 2017-06-23 03:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:51:11 --> Input Class Initialized
INFO - 2017-06-23 03:51:11 --> Language Class Initialized
INFO - 2017-06-23 03:51:11 --> Loader Class Initialized
INFO - 2017-06-23 03:51:11 --> Controller Class Initialized
INFO - 2017-06-23 03:51:11 --> Database Driver Class Initialized
INFO - 2017-06-23 03:51:11 --> Model Class Initialized
INFO - 2017-06-23 03:51:11 --> Helper loaded: form_helper
INFO - 2017-06-23 03:51:11 --> Helper loaded: url_helper
INFO - 2017-06-23 03:51:11 --> Model Class Initialized
INFO - 2017-06-23 03:51:11 --> Final output sent to browser
DEBUG - 2017-06-23 03:51:11 --> Total execution time: 0.0610
ERROR - 2017-06-23 03:51:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 03:51:11 --> Config Class Initialized
INFO - 2017-06-23 03:51:11 --> Hooks Class Initialized
DEBUG - 2017-06-23 03:51:11 --> UTF-8 Support Enabled
INFO - 2017-06-23 03:51:11 --> Utf8 Class Initialized
INFO - 2017-06-23 03:51:11 --> URI Class Initialized
INFO - 2017-06-23 03:51:11 --> Router Class Initialized
INFO - 2017-06-23 03:51:11 --> Output Class Initialized
INFO - 2017-06-23 03:51:11 --> Security Class Initialized
DEBUG - 2017-06-23 03:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 03:51:11 --> Input Class Initialized
INFO - 2017-06-23 03:51:11 --> Language Class Initialized
INFO - 2017-06-23 03:51:11 --> Loader Class Initialized
INFO - 2017-06-23 03:51:11 --> Controller Class Initialized
INFO - 2017-06-23 03:51:11 --> Database Driver Class Initialized
INFO - 2017-06-23 03:51:11 --> Model Class Initialized
INFO - 2017-06-23 03:51:12 --> Helper loaded: form_helper
INFO - 2017-06-23 03:51:12 --> Helper loaded: url_helper
INFO - 2017-06-23 03:51:12 --> Model Class Initialized
INFO - 2017-06-23 03:51:12 --> Final output sent to browser
DEBUG - 2017-06-23 03:51:12 --> Total execution time: 0.0450
ERROR - 2017-06-23 04:12:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:12:12 --> Config Class Initialized
INFO - 2017-06-23 04:12:12 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:12:12 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:12:12 --> Utf8 Class Initialized
INFO - 2017-06-23 04:12:12 --> URI Class Initialized
INFO - 2017-06-23 04:12:12 --> Router Class Initialized
INFO - 2017-06-23 04:12:12 --> Output Class Initialized
INFO - 2017-06-23 04:12:12 --> Security Class Initialized
DEBUG - 2017-06-23 04:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:12:12 --> Input Class Initialized
INFO - 2017-06-23 04:12:12 --> Language Class Initialized
INFO - 2017-06-23 04:12:12 --> Loader Class Initialized
INFO - 2017-06-23 04:12:12 --> Controller Class Initialized
INFO - 2017-06-23 04:12:12 --> Database Driver Class Initialized
INFO - 2017-06-23 04:12:12 --> Model Class Initialized
INFO - 2017-06-23 04:12:12 --> Helper loaded: form_helper
INFO - 2017-06-23 04:12:12 --> Helper loaded: url_helper
INFO - 2017-06-23 04:12:12 --> Model Class Initialized
INFO - 2017-06-23 04:12:12 --> Final output sent to browser
DEBUG - 2017-06-23 04:12:12 --> Total execution time: 0.0860
ERROR - 2017-06-23 04:12:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:12:16 --> Config Class Initialized
INFO - 2017-06-23 04:12:16 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:12:16 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:12:16 --> Utf8 Class Initialized
INFO - 2017-06-23 04:12:16 --> URI Class Initialized
INFO - 2017-06-23 04:12:16 --> Router Class Initialized
INFO - 2017-06-23 04:12:16 --> Output Class Initialized
INFO - 2017-06-23 04:12:16 --> Security Class Initialized
DEBUG - 2017-06-23 04:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:12:16 --> Input Class Initialized
INFO - 2017-06-23 04:12:16 --> Language Class Initialized
INFO - 2017-06-23 04:12:16 --> Loader Class Initialized
INFO - 2017-06-23 04:12:16 --> Controller Class Initialized
INFO - 2017-06-23 04:12:16 --> Database Driver Class Initialized
INFO - 2017-06-23 04:12:16 --> Model Class Initialized
INFO - 2017-06-23 04:12:16 --> Helper loaded: form_helper
INFO - 2017-06-23 04:12:16 --> Helper loaded: url_helper
INFO - 2017-06-23 04:12:16 --> Model Class Initialized
INFO - 2017-06-23 04:12:16 --> Final output sent to browser
DEBUG - 2017-06-23 04:12:16 --> Total execution time: 0.1290
ERROR - 2017-06-23 04:12:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:12:18 --> Config Class Initialized
INFO - 2017-06-23 04:12:18 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:12:18 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:12:18 --> Utf8 Class Initialized
INFO - 2017-06-23 04:12:18 --> URI Class Initialized
INFO - 2017-06-23 04:12:18 --> Router Class Initialized
INFO - 2017-06-23 04:12:18 --> Output Class Initialized
INFO - 2017-06-23 04:12:18 --> Security Class Initialized
DEBUG - 2017-06-23 04:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:12:18 --> Input Class Initialized
INFO - 2017-06-23 04:12:18 --> Language Class Initialized
INFO - 2017-06-23 04:12:18 --> Loader Class Initialized
INFO - 2017-06-23 04:12:18 --> Controller Class Initialized
INFO - 2017-06-23 04:12:18 --> Database Driver Class Initialized
INFO - 2017-06-23 04:12:18 --> Model Class Initialized
INFO - 2017-06-23 04:12:18 --> Helper loaded: form_helper
INFO - 2017-06-23 04:12:18 --> Helper loaded: url_helper
INFO - 2017-06-23 04:12:18 --> Model Class Initialized
INFO - 2017-06-23 04:12:18 --> Final output sent to browser
DEBUG - 2017-06-23 04:12:18 --> Total execution time: 0.0710
ERROR - 2017-06-23 04:12:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:12:21 --> Config Class Initialized
INFO - 2017-06-23 04:12:21 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:12:21 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:12:21 --> Utf8 Class Initialized
INFO - 2017-06-23 04:12:21 --> URI Class Initialized
INFO - 2017-06-23 04:12:21 --> Router Class Initialized
INFO - 2017-06-23 04:12:21 --> Output Class Initialized
INFO - 2017-06-23 04:12:21 --> Security Class Initialized
DEBUG - 2017-06-23 04:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:12:21 --> Input Class Initialized
INFO - 2017-06-23 04:12:21 --> Language Class Initialized
INFO - 2017-06-23 04:12:21 --> Loader Class Initialized
INFO - 2017-06-23 04:12:21 --> Controller Class Initialized
INFO - 2017-06-23 04:12:21 --> Database Driver Class Initialized
INFO - 2017-06-23 04:12:21 --> Model Class Initialized
INFO - 2017-06-23 04:12:21 --> Helper loaded: form_helper
INFO - 2017-06-23 04:12:21 --> Helper loaded: url_helper
INFO - 2017-06-23 04:12:21 --> Model Class Initialized
INFO - 2017-06-23 04:12:21 --> Final output sent to browser
DEBUG - 2017-06-23 04:12:21 --> Total execution time: 0.1090
ERROR - 2017-06-23 04:12:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:12:47 --> Config Class Initialized
INFO - 2017-06-23 04:12:47 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:12:47 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:12:47 --> Utf8 Class Initialized
INFO - 2017-06-23 04:12:47 --> URI Class Initialized
INFO - 2017-06-23 04:12:47 --> Router Class Initialized
INFO - 2017-06-23 04:12:47 --> Output Class Initialized
INFO - 2017-06-23 04:12:47 --> Security Class Initialized
DEBUG - 2017-06-23 04:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:12:47 --> Input Class Initialized
INFO - 2017-06-23 04:12:47 --> Language Class Initialized
INFO - 2017-06-23 04:12:47 --> Loader Class Initialized
INFO - 2017-06-23 04:12:47 --> Controller Class Initialized
INFO - 2017-06-23 04:12:47 --> Database Driver Class Initialized
INFO - 2017-06-23 04:12:47 --> Model Class Initialized
INFO - 2017-06-23 04:12:47 --> Helper loaded: form_helper
INFO - 2017-06-23 04:12:47 --> Helper loaded: url_helper
INFO - 2017-06-23 04:12:47 --> Model Class Initialized
INFO - 2017-06-23 04:12:47 --> Final output sent to browser
DEBUG - 2017-06-23 04:12:47 --> Total execution time: 0.0590
ERROR - 2017-06-23 04:13:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:13:17 --> Config Class Initialized
INFO - 2017-06-23 04:13:17 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:13:17 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:13:17 --> Utf8 Class Initialized
INFO - 2017-06-23 04:13:17 --> URI Class Initialized
INFO - 2017-06-23 04:13:17 --> Router Class Initialized
INFO - 2017-06-23 04:13:17 --> Output Class Initialized
INFO - 2017-06-23 04:13:17 --> Security Class Initialized
DEBUG - 2017-06-23 04:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:13:17 --> Input Class Initialized
INFO - 2017-06-23 04:13:17 --> Language Class Initialized
INFO - 2017-06-23 04:13:17 --> Loader Class Initialized
INFO - 2017-06-23 04:13:17 --> Controller Class Initialized
INFO - 2017-06-23 04:13:17 --> Database Driver Class Initialized
INFO - 2017-06-23 04:13:17 --> Model Class Initialized
INFO - 2017-06-23 04:13:17 --> Helper loaded: form_helper
INFO - 2017-06-23 04:13:17 --> Helper loaded: url_helper
INFO - 2017-06-23 04:13:17 --> Model Class Initialized
INFO - 2017-06-23 04:13:17 --> Final output sent to browser
DEBUG - 2017-06-23 04:13:17 --> Total execution time: 0.0660
ERROR - 2017-06-23 04:13:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:13:35 --> Config Class Initialized
INFO - 2017-06-23 04:13:35 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:13:35 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:13:35 --> Utf8 Class Initialized
INFO - 2017-06-23 04:13:35 --> URI Class Initialized
INFO - 2017-06-23 04:13:35 --> Router Class Initialized
INFO - 2017-06-23 04:13:35 --> Output Class Initialized
INFO - 2017-06-23 04:13:35 --> Security Class Initialized
DEBUG - 2017-06-23 04:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:13:35 --> Input Class Initialized
INFO - 2017-06-23 04:13:35 --> Language Class Initialized
INFO - 2017-06-23 04:13:35 --> Loader Class Initialized
INFO - 2017-06-23 04:13:35 --> Controller Class Initialized
INFO - 2017-06-23 04:13:35 --> Database Driver Class Initialized
INFO - 2017-06-23 04:13:35 --> Model Class Initialized
INFO - 2017-06-23 04:13:35 --> Helper loaded: form_helper
INFO - 2017-06-23 04:13:35 --> Helper loaded: url_helper
INFO - 2017-06-23 04:13:35 --> Model Class Initialized
INFO - 2017-06-23 04:13:35 --> Final output sent to browser
DEBUG - 2017-06-23 04:13:35 --> Total execution time: 0.0790
ERROR - 2017-06-23 04:15:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:15:00 --> Config Class Initialized
INFO - 2017-06-23 04:15:00 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:15:00 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:15:00 --> Utf8 Class Initialized
INFO - 2017-06-23 04:15:00 --> URI Class Initialized
INFO - 2017-06-23 04:15:00 --> Router Class Initialized
INFO - 2017-06-23 04:15:00 --> Output Class Initialized
INFO - 2017-06-23 04:15:00 --> Security Class Initialized
DEBUG - 2017-06-23 04:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:15:00 --> Input Class Initialized
INFO - 2017-06-23 04:15:00 --> Language Class Initialized
INFO - 2017-06-23 04:15:00 --> Loader Class Initialized
INFO - 2017-06-23 04:15:00 --> Controller Class Initialized
INFO - 2017-06-23 04:15:00 --> Database Driver Class Initialized
INFO - 2017-06-23 04:15:00 --> Model Class Initialized
INFO - 2017-06-23 04:15:00 --> Helper loaded: form_helper
INFO - 2017-06-23 04:15:00 --> Helper loaded: url_helper
INFO - 2017-06-23 04:15:00 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 04:15:00 --> Model Class Initialized
INFO - 2017-06-23 04:15:00 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-23 04:15:00 --> Final output sent to browser
DEBUG - 2017-06-23 04:15:00 --> Total execution time: 0.1320
ERROR - 2017-06-23 04:15:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:15:03 --> Config Class Initialized
INFO - 2017-06-23 04:15:03 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:15:03 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:15:03 --> Utf8 Class Initialized
INFO - 2017-06-23 04:15:03 --> URI Class Initialized
INFO - 2017-06-23 04:15:03 --> Router Class Initialized
INFO - 2017-06-23 04:15:03 --> Output Class Initialized
INFO - 2017-06-23 04:15:03 --> Security Class Initialized
DEBUG - 2017-06-23 04:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:15:03 --> Input Class Initialized
INFO - 2017-06-23 04:15:03 --> Language Class Initialized
INFO - 2017-06-23 04:15:03 --> Loader Class Initialized
INFO - 2017-06-23 04:15:03 --> Controller Class Initialized
INFO - 2017-06-23 04:15:03 --> Database Driver Class Initialized
INFO - 2017-06-23 04:15:03 --> Model Class Initialized
INFO - 2017-06-23 04:15:03 --> Helper loaded: form_helper
INFO - 2017-06-23 04:15:03 --> Helper loaded: url_helper
INFO - 2017-06-23 04:15:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 04:15:03 --> Model Class Initialized
INFO - 2017-06-23 04:15:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 04:15:03 --> Final output sent to browser
DEBUG - 2017-06-23 04:15:03 --> Total execution time: 0.1000
ERROR - 2017-06-23 04:28:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:28:33 --> Config Class Initialized
INFO - 2017-06-23 04:28:33 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:28:33 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:28:33 --> Utf8 Class Initialized
INFO - 2017-06-23 04:28:33 --> URI Class Initialized
INFO - 2017-06-23 04:28:33 --> Router Class Initialized
INFO - 2017-06-23 04:28:33 --> Output Class Initialized
INFO - 2017-06-23 04:28:33 --> Security Class Initialized
DEBUG - 2017-06-23 04:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:28:33 --> Input Class Initialized
INFO - 2017-06-23 04:28:33 --> Language Class Initialized
INFO - 2017-06-23 04:28:33 --> Loader Class Initialized
INFO - 2017-06-23 04:28:33 --> Controller Class Initialized
INFO - 2017-06-23 04:28:33 --> Database Driver Class Initialized
INFO - 2017-06-23 04:28:33 --> Model Class Initialized
INFO - 2017-06-23 04:28:33 --> Helper loaded: form_helper
INFO - 2017-06-23 04:28:33 --> Helper loaded: url_helper
INFO - 2017-06-23 04:28:33 --> Model Class Initialized
INFO - 2017-06-23 04:28:33 --> Final output sent to browser
DEBUG - 2017-06-23 04:28:33 --> Total execution time: 0.0530
ERROR - 2017-06-23 04:28:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:28:34 --> Config Class Initialized
INFO - 2017-06-23 04:28:34 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:28:34 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:28:34 --> Utf8 Class Initialized
INFO - 2017-06-23 04:28:34 --> URI Class Initialized
INFO - 2017-06-23 04:28:34 --> Router Class Initialized
INFO - 2017-06-23 04:28:34 --> Output Class Initialized
INFO - 2017-06-23 04:28:34 --> Security Class Initialized
DEBUG - 2017-06-23 04:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:28:34 --> Input Class Initialized
INFO - 2017-06-23 04:28:34 --> Language Class Initialized
INFO - 2017-06-23 04:28:34 --> Loader Class Initialized
INFO - 2017-06-23 04:28:34 --> Controller Class Initialized
INFO - 2017-06-23 04:28:34 --> Database Driver Class Initialized
INFO - 2017-06-23 04:28:34 --> Model Class Initialized
INFO - 2017-06-23 04:28:34 --> Helper loaded: form_helper
INFO - 2017-06-23 04:28:34 --> Helper loaded: url_helper
INFO - 2017-06-23 04:28:34 --> Model Class Initialized
INFO - 2017-06-23 04:28:34 --> Final output sent to browser
DEBUG - 2017-06-23 04:28:34 --> Total execution time: 0.0430
ERROR - 2017-06-23 04:28:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:28:50 --> Config Class Initialized
INFO - 2017-06-23 04:28:50 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:28:50 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:28:50 --> Utf8 Class Initialized
INFO - 2017-06-23 04:28:50 --> URI Class Initialized
INFO - 2017-06-23 04:28:50 --> Router Class Initialized
INFO - 2017-06-23 04:28:50 --> Output Class Initialized
INFO - 2017-06-23 04:28:50 --> Security Class Initialized
DEBUG - 2017-06-23 04:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:28:50 --> Input Class Initialized
INFO - 2017-06-23 04:28:50 --> Language Class Initialized
INFO - 2017-06-23 04:28:50 --> Loader Class Initialized
INFO - 2017-06-23 04:28:50 --> Controller Class Initialized
INFO - 2017-06-23 04:28:50 --> Database Driver Class Initialized
INFO - 2017-06-23 04:28:50 --> Model Class Initialized
INFO - 2017-06-23 04:28:50 --> Helper loaded: form_helper
INFO - 2017-06-23 04:28:50 --> Helper loaded: url_helper
INFO - 2017-06-23 04:28:50 --> Model Class Initialized
INFO - 2017-06-23 04:28:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 04:28:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 04:28:50 --> Final output sent to browser
DEBUG - 2017-06-23 04:28:50 --> Total execution time: 0.1130
ERROR - 2017-06-23 04:28:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:28:52 --> Config Class Initialized
INFO - 2017-06-23 04:28:52 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:28:52 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:28:52 --> Utf8 Class Initialized
INFO - 2017-06-23 04:28:52 --> URI Class Initialized
INFO - 2017-06-23 04:28:52 --> Router Class Initialized
INFO - 2017-06-23 04:28:52 --> Output Class Initialized
INFO - 2017-06-23 04:28:52 --> Security Class Initialized
DEBUG - 2017-06-23 04:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:28:52 --> Input Class Initialized
INFO - 2017-06-23 04:28:52 --> Language Class Initialized
INFO - 2017-06-23 04:28:52 --> Loader Class Initialized
INFO - 2017-06-23 04:28:52 --> Controller Class Initialized
INFO - 2017-06-23 04:28:52 --> Database Driver Class Initialized
INFO - 2017-06-23 04:28:52 --> Model Class Initialized
INFO - 2017-06-23 04:28:52 --> Helper loaded: form_helper
INFO - 2017-06-23 04:28:52 --> Helper loaded: url_helper
INFO - 2017-06-23 04:28:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 04:28:52 --> Model Class Initialized
INFO - 2017-06-23 04:28:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-23 04:28:52 --> Final output sent to browser
DEBUG - 2017-06-23 04:28:52 --> Total execution time: 0.0800
ERROR - 2017-06-23 04:28:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:28:55 --> Config Class Initialized
INFO - 2017-06-23 04:28:55 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:28:55 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:28:55 --> Utf8 Class Initialized
INFO - 2017-06-23 04:28:55 --> URI Class Initialized
INFO - 2017-06-23 04:28:55 --> Router Class Initialized
INFO - 2017-06-23 04:28:55 --> Output Class Initialized
INFO - 2017-06-23 04:28:55 --> Security Class Initialized
DEBUG - 2017-06-23 04:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:28:55 --> Input Class Initialized
INFO - 2017-06-23 04:28:55 --> Language Class Initialized
INFO - 2017-06-23 04:28:55 --> Loader Class Initialized
INFO - 2017-06-23 04:28:55 --> Controller Class Initialized
INFO - 2017-06-23 04:28:55 --> Database Driver Class Initialized
INFO - 2017-06-23 04:28:55 --> Model Class Initialized
INFO - 2017-06-23 04:28:55 --> Helper loaded: form_helper
INFO - 2017-06-23 04:28:55 --> Helper loaded: url_helper
INFO - 2017-06-23 04:28:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 04:28:56 --> Model Class Initialized
INFO - 2017-06-23 04:28:56 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 04:28:56 --> Final output sent to browser
DEBUG - 2017-06-23 04:28:56 --> Total execution time: 0.0650
ERROR - 2017-06-23 04:28:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:28:59 --> Config Class Initialized
INFO - 2017-06-23 04:28:59 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:28:59 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:28:59 --> Utf8 Class Initialized
INFO - 2017-06-23 04:28:59 --> URI Class Initialized
INFO - 2017-06-23 04:28:59 --> Router Class Initialized
INFO - 2017-06-23 04:28:59 --> Output Class Initialized
INFO - 2017-06-23 04:28:59 --> Security Class Initialized
DEBUG - 2017-06-23 04:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:28:59 --> Input Class Initialized
INFO - 2017-06-23 04:28:59 --> Language Class Initialized
INFO - 2017-06-23 04:28:59 --> Loader Class Initialized
INFO - 2017-06-23 04:28:59 --> Controller Class Initialized
INFO - 2017-06-23 04:28:59 --> Database Driver Class Initialized
INFO - 2017-06-23 04:28:59 --> Model Class Initialized
INFO - 2017-06-23 04:28:59 --> Helper loaded: form_helper
INFO - 2017-06-23 04:28:59 --> Helper loaded: url_helper
INFO - 2017-06-23 04:28:59 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 04:28:59 --> Model Class Initialized
INFO - 2017-06-23 04:28:59 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-23 04:28:59 --> Final output sent to browser
DEBUG - 2017-06-23 04:28:59 --> Total execution time: 0.0690
ERROR - 2017-06-23 04:29:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:29:01 --> Config Class Initialized
INFO - 2017-06-23 04:29:01 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:29:01 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:29:01 --> Utf8 Class Initialized
INFO - 2017-06-23 04:29:01 --> URI Class Initialized
INFO - 2017-06-23 04:29:01 --> Router Class Initialized
INFO - 2017-06-23 04:29:01 --> Output Class Initialized
INFO - 2017-06-23 04:29:01 --> Security Class Initialized
DEBUG - 2017-06-23 04:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:29:01 --> Input Class Initialized
INFO - 2017-06-23 04:29:01 --> Language Class Initialized
INFO - 2017-06-23 04:29:01 --> Loader Class Initialized
INFO - 2017-06-23 04:29:01 --> Controller Class Initialized
INFO - 2017-06-23 04:29:01 --> Database Driver Class Initialized
INFO - 2017-06-23 04:29:01 --> Model Class Initialized
INFO - 2017-06-23 04:29:01 --> Helper loaded: form_helper
INFO - 2017-06-23 04:29:01 --> Helper loaded: url_helper
INFO - 2017-06-23 04:29:01 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 04:29:01 --> Model Class Initialized
INFO - 2017-06-23 04:29:01 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 04:29:01 --> Final output sent to browser
DEBUG - 2017-06-23 04:29:01 --> Total execution time: 0.0750
ERROR - 2017-06-23 04:29:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:29:03 --> Config Class Initialized
INFO - 2017-06-23 04:29:03 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:29:03 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:29:03 --> Utf8 Class Initialized
INFO - 2017-06-23 04:29:03 --> URI Class Initialized
INFO - 2017-06-23 04:29:03 --> Router Class Initialized
INFO - 2017-06-23 04:29:03 --> Output Class Initialized
INFO - 2017-06-23 04:29:03 --> Security Class Initialized
DEBUG - 2017-06-23 04:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:29:03 --> Input Class Initialized
INFO - 2017-06-23 04:29:03 --> Language Class Initialized
INFO - 2017-06-23 04:29:03 --> Loader Class Initialized
INFO - 2017-06-23 04:29:03 --> Controller Class Initialized
INFO - 2017-06-23 04:29:03 --> Database Driver Class Initialized
INFO - 2017-06-23 04:29:03 --> Model Class Initialized
INFO - 2017-06-23 04:29:03 --> Helper loaded: form_helper
INFO - 2017-06-23 04:29:03 --> Helper loaded: url_helper
INFO - 2017-06-23 04:29:03 --> Model Class Initialized
INFO - 2017-06-23 04:29:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 04:29:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 04:29:03 --> Final output sent to browser
DEBUG - 2017-06-23 04:29:03 --> Total execution time: 0.2580
ERROR - 2017-06-23 04:29:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:29:08 --> Config Class Initialized
INFO - 2017-06-23 04:29:08 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:29:08 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:29:08 --> Utf8 Class Initialized
INFO - 2017-06-23 04:29:08 --> URI Class Initialized
INFO - 2017-06-23 04:29:08 --> Router Class Initialized
INFO - 2017-06-23 04:29:08 --> Output Class Initialized
INFO - 2017-06-23 04:29:08 --> Security Class Initialized
DEBUG - 2017-06-23 04:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:29:08 --> Input Class Initialized
INFO - 2017-06-23 04:29:08 --> Language Class Initialized
INFO - 2017-06-23 04:29:08 --> Loader Class Initialized
INFO - 2017-06-23 04:29:08 --> Controller Class Initialized
INFO - 2017-06-23 04:29:08 --> Database Driver Class Initialized
INFO - 2017-06-23 04:29:08 --> Model Class Initialized
INFO - 2017-06-23 04:29:08 --> Helper loaded: form_helper
INFO - 2017-06-23 04:29:08 --> Helper loaded: url_helper
INFO - 2017-06-23 04:29:08 --> Model Class Initialized
INFO - 2017-06-23 04:29:08 --> Final output sent to browser
DEBUG - 2017-06-23 04:29:08 --> Total execution time: 0.0600
ERROR - 2017-06-23 04:29:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:29:08 --> Config Class Initialized
INFO - 2017-06-23 04:29:08 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:29:08 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:29:08 --> Utf8 Class Initialized
INFO - 2017-06-23 04:29:08 --> URI Class Initialized
INFO - 2017-06-23 04:29:08 --> Router Class Initialized
INFO - 2017-06-23 04:29:08 --> Output Class Initialized
INFO - 2017-06-23 04:29:08 --> Security Class Initialized
DEBUG - 2017-06-23 04:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:29:08 --> Input Class Initialized
INFO - 2017-06-23 04:29:08 --> Language Class Initialized
INFO - 2017-06-23 04:29:08 --> Loader Class Initialized
INFO - 2017-06-23 04:29:08 --> Controller Class Initialized
INFO - 2017-06-23 04:29:08 --> Database Driver Class Initialized
INFO - 2017-06-23 04:29:08 --> Model Class Initialized
INFO - 2017-06-23 04:29:08 --> Helper loaded: form_helper
INFO - 2017-06-23 04:29:08 --> Helper loaded: url_helper
INFO - 2017-06-23 04:29:08 --> Model Class Initialized
INFO - 2017-06-23 04:29:08 --> Final output sent to browser
DEBUG - 2017-06-23 04:29:08 --> Total execution time: 0.0960
ERROR - 2017-06-23 04:29:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:29:10 --> Config Class Initialized
INFO - 2017-06-23 04:29:10 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:29:10 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:29:10 --> Utf8 Class Initialized
INFO - 2017-06-23 04:29:10 --> URI Class Initialized
INFO - 2017-06-23 04:29:10 --> Router Class Initialized
INFO - 2017-06-23 04:29:10 --> Output Class Initialized
INFO - 2017-06-23 04:29:10 --> Security Class Initialized
DEBUG - 2017-06-23 04:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:29:10 --> Input Class Initialized
INFO - 2017-06-23 04:29:10 --> Language Class Initialized
INFO - 2017-06-23 04:29:10 --> Loader Class Initialized
INFO - 2017-06-23 04:29:10 --> Controller Class Initialized
INFO - 2017-06-23 04:29:10 --> Database Driver Class Initialized
INFO - 2017-06-23 04:29:10 --> Model Class Initialized
INFO - 2017-06-23 04:29:10 --> Helper loaded: form_helper
INFO - 2017-06-23 04:29:10 --> Helper loaded: url_helper
INFO - 2017-06-23 04:29:10 --> Model Class Initialized
INFO - 2017-06-23 04:29:10 --> Final output sent to browser
DEBUG - 2017-06-23 04:29:10 --> Total execution time: 0.0700
ERROR - 2017-06-23 04:29:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:29:12 --> Config Class Initialized
INFO - 2017-06-23 04:29:12 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:29:12 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:29:12 --> Utf8 Class Initialized
INFO - 2017-06-23 04:29:12 --> URI Class Initialized
INFO - 2017-06-23 04:29:12 --> Router Class Initialized
INFO - 2017-06-23 04:29:12 --> Output Class Initialized
INFO - 2017-06-23 04:29:12 --> Security Class Initialized
DEBUG - 2017-06-23 04:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:29:12 --> Input Class Initialized
INFO - 2017-06-23 04:29:12 --> Language Class Initialized
INFO - 2017-06-23 04:29:12 --> Loader Class Initialized
INFO - 2017-06-23 04:29:12 --> Controller Class Initialized
INFO - 2017-06-23 04:29:12 --> Database Driver Class Initialized
INFO - 2017-06-23 04:29:12 --> Model Class Initialized
INFO - 2017-06-23 04:29:12 --> Helper loaded: form_helper
INFO - 2017-06-23 04:29:12 --> Helper loaded: url_helper
INFO - 2017-06-23 04:29:12 --> Model Class Initialized
INFO - 2017-06-23 04:29:12 --> Final output sent to browser
DEBUG - 2017-06-23 04:29:12 --> Total execution time: 0.0520
ERROR - 2017-06-23 04:29:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:29:13 --> Config Class Initialized
INFO - 2017-06-23 04:29:13 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:29:13 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:29:13 --> Utf8 Class Initialized
INFO - 2017-06-23 04:29:13 --> URI Class Initialized
INFO - 2017-06-23 04:29:13 --> Router Class Initialized
INFO - 2017-06-23 04:29:13 --> Output Class Initialized
INFO - 2017-06-23 04:29:13 --> Security Class Initialized
DEBUG - 2017-06-23 04:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:29:13 --> Input Class Initialized
INFO - 2017-06-23 04:29:13 --> Language Class Initialized
INFO - 2017-06-23 04:29:13 --> Loader Class Initialized
INFO - 2017-06-23 04:29:13 --> Controller Class Initialized
INFO - 2017-06-23 04:29:13 --> Database Driver Class Initialized
INFO - 2017-06-23 04:29:13 --> Model Class Initialized
INFO - 2017-06-23 04:29:13 --> Helper loaded: form_helper
INFO - 2017-06-23 04:29:13 --> Helper loaded: url_helper
INFO - 2017-06-23 04:29:13 --> Model Class Initialized
INFO - 2017-06-23 04:29:13 --> Final output sent to browser
DEBUG - 2017-06-23 04:29:13 --> Total execution time: 0.0540
ERROR - 2017-06-23 04:29:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:29:16 --> Config Class Initialized
INFO - 2017-06-23 04:29:16 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:29:16 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:29:16 --> Utf8 Class Initialized
INFO - 2017-06-23 04:29:16 --> URI Class Initialized
INFO - 2017-06-23 04:29:16 --> Router Class Initialized
INFO - 2017-06-23 04:29:16 --> Output Class Initialized
INFO - 2017-06-23 04:29:16 --> Security Class Initialized
DEBUG - 2017-06-23 04:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:29:16 --> Input Class Initialized
INFO - 2017-06-23 04:29:16 --> Language Class Initialized
INFO - 2017-06-23 04:29:16 --> Loader Class Initialized
INFO - 2017-06-23 04:29:16 --> Controller Class Initialized
INFO - 2017-06-23 04:29:16 --> Database Driver Class Initialized
INFO - 2017-06-23 04:29:16 --> Model Class Initialized
INFO - 2017-06-23 04:29:16 --> Helper loaded: form_helper
INFO - 2017-06-23 04:29:16 --> Helper loaded: url_helper
INFO - 2017-06-23 04:29:16 --> Model Class Initialized
INFO - 2017-06-23 04:29:16 --> Final output sent to browser
DEBUG - 2017-06-23 04:29:16 --> Total execution time: 0.0980
ERROR - 2017-06-23 04:29:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:29:35 --> Config Class Initialized
INFO - 2017-06-23 04:29:35 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:29:35 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:29:35 --> Utf8 Class Initialized
INFO - 2017-06-23 04:29:35 --> URI Class Initialized
INFO - 2017-06-23 04:29:35 --> Router Class Initialized
INFO - 2017-06-23 04:29:35 --> Output Class Initialized
INFO - 2017-06-23 04:29:35 --> Security Class Initialized
DEBUG - 2017-06-23 04:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:29:35 --> Input Class Initialized
INFO - 2017-06-23 04:29:35 --> Language Class Initialized
INFO - 2017-06-23 04:29:35 --> Loader Class Initialized
INFO - 2017-06-23 04:29:35 --> Controller Class Initialized
INFO - 2017-06-23 04:29:35 --> Database Driver Class Initialized
INFO - 2017-06-23 04:29:35 --> Model Class Initialized
INFO - 2017-06-23 04:29:35 --> Helper loaded: form_helper
INFO - 2017-06-23 04:29:35 --> Helper loaded: url_helper
INFO - 2017-06-23 04:29:35 --> Model Class Initialized
INFO - 2017-06-23 04:29:35 --> Final output sent to browser
DEBUG - 2017-06-23 04:29:35 --> Total execution time: 0.0460
ERROR - 2017-06-23 04:29:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:29:52 --> Config Class Initialized
INFO - 2017-06-23 04:29:52 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:29:52 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:29:52 --> Utf8 Class Initialized
INFO - 2017-06-23 04:29:52 --> URI Class Initialized
INFO - 2017-06-23 04:29:52 --> Router Class Initialized
INFO - 2017-06-23 04:29:52 --> Output Class Initialized
INFO - 2017-06-23 04:29:52 --> Security Class Initialized
DEBUG - 2017-06-23 04:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:29:52 --> Input Class Initialized
INFO - 2017-06-23 04:29:52 --> Language Class Initialized
INFO - 2017-06-23 04:29:52 --> Loader Class Initialized
INFO - 2017-06-23 04:29:52 --> Controller Class Initialized
INFO - 2017-06-23 04:29:52 --> Database Driver Class Initialized
INFO - 2017-06-23 04:29:52 --> Model Class Initialized
INFO - 2017-06-23 04:29:52 --> Helper loaded: form_helper
INFO - 2017-06-23 04:29:52 --> Helper loaded: url_helper
INFO - 2017-06-23 04:29:52 --> Model Class Initialized
INFO - 2017-06-23 04:29:52 --> Final output sent to browser
DEBUG - 2017-06-23 04:29:52 --> Total execution time: 0.1290
ERROR - 2017-06-23 04:30:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:30:08 --> Config Class Initialized
INFO - 2017-06-23 04:30:08 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:30:08 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:30:08 --> Utf8 Class Initialized
INFO - 2017-06-23 04:30:08 --> URI Class Initialized
INFO - 2017-06-23 04:30:08 --> Router Class Initialized
INFO - 2017-06-23 04:30:08 --> Output Class Initialized
INFO - 2017-06-23 04:30:08 --> Security Class Initialized
DEBUG - 2017-06-23 04:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:30:08 --> Input Class Initialized
INFO - 2017-06-23 04:30:08 --> Language Class Initialized
INFO - 2017-06-23 04:30:08 --> Loader Class Initialized
INFO - 2017-06-23 04:30:08 --> Controller Class Initialized
INFO - 2017-06-23 04:30:08 --> Database Driver Class Initialized
INFO - 2017-06-23 04:30:08 --> Model Class Initialized
INFO - 2017-06-23 04:30:08 --> Helper loaded: form_helper
INFO - 2017-06-23 04:30:08 --> Helper loaded: url_helper
INFO - 2017-06-23 04:30:08 --> Model Class Initialized
INFO - 2017-06-23 04:30:08 --> Final output sent to browser
DEBUG - 2017-06-23 04:30:08 --> Total execution time: 0.1040
ERROR - 2017-06-23 04:30:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:30:46 --> Config Class Initialized
INFO - 2017-06-23 04:30:46 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:30:46 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:30:46 --> Utf8 Class Initialized
INFO - 2017-06-23 04:30:46 --> URI Class Initialized
INFO - 2017-06-23 04:30:46 --> Router Class Initialized
INFO - 2017-06-23 04:30:46 --> Output Class Initialized
INFO - 2017-06-23 04:30:46 --> Security Class Initialized
DEBUG - 2017-06-23 04:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:30:46 --> Input Class Initialized
INFO - 2017-06-23 04:30:46 --> Language Class Initialized
INFO - 2017-06-23 04:30:46 --> Loader Class Initialized
INFO - 2017-06-23 04:30:46 --> Controller Class Initialized
INFO - 2017-06-23 04:30:46 --> Database Driver Class Initialized
INFO - 2017-06-23 04:30:46 --> Model Class Initialized
INFO - 2017-06-23 04:30:46 --> Helper loaded: form_helper
INFO - 2017-06-23 04:30:46 --> Helper loaded: url_helper
INFO - 2017-06-23 04:30:46 --> Model Class Initialized
INFO - 2017-06-23 04:30:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 04:30:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 04:30:46 --> Final output sent to browser
DEBUG - 2017-06-23 04:30:46 --> Total execution time: 0.2110
ERROR - 2017-06-23 04:30:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:30:48 --> Config Class Initialized
INFO - 2017-06-23 04:30:48 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:30:48 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:30:48 --> Utf8 Class Initialized
INFO - 2017-06-23 04:30:48 --> URI Class Initialized
INFO - 2017-06-23 04:30:48 --> Router Class Initialized
INFO - 2017-06-23 04:30:48 --> Output Class Initialized
INFO - 2017-06-23 04:30:48 --> Security Class Initialized
DEBUG - 2017-06-23 04:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:30:48 --> Input Class Initialized
INFO - 2017-06-23 04:30:48 --> Language Class Initialized
INFO - 2017-06-23 04:30:48 --> Loader Class Initialized
INFO - 2017-06-23 04:30:48 --> Controller Class Initialized
INFO - 2017-06-23 04:30:48 --> Database Driver Class Initialized
INFO - 2017-06-23 04:30:48 --> Model Class Initialized
INFO - 2017-06-23 04:30:48 --> Helper loaded: form_helper
INFO - 2017-06-23 04:30:48 --> Helper loaded: url_helper
INFO - 2017-06-23 04:30:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 04:30:48 --> Model Class Initialized
INFO - 2017-06-23 04:30:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-23 04:30:48 --> Final output sent to browser
DEBUG - 2017-06-23 04:30:48 --> Total execution time: 0.2890
ERROR - 2017-06-23 04:30:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:30:50 --> Config Class Initialized
INFO - 2017-06-23 04:30:50 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:30:50 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:30:50 --> Utf8 Class Initialized
INFO - 2017-06-23 04:30:50 --> URI Class Initialized
INFO - 2017-06-23 04:30:50 --> Router Class Initialized
INFO - 2017-06-23 04:30:50 --> Output Class Initialized
INFO - 2017-06-23 04:30:50 --> Security Class Initialized
DEBUG - 2017-06-23 04:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:30:50 --> Input Class Initialized
INFO - 2017-06-23 04:30:50 --> Language Class Initialized
INFO - 2017-06-23 04:30:50 --> Loader Class Initialized
INFO - 2017-06-23 04:30:50 --> Controller Class Initialized
INFO - 2017-06-23 04:30:50 --> Database Driver Class Initialized
INFO - 2017-06-23 04:30:50 --> Model Class Initialized
INFO - 2017-06-23 04:30:50 --> Helper loaded: form_helper
INFO - 2017-06-23 04:30:50 --> Helper loaded: url_helper
INFO - 2017-06-23 04:30:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 04:30:50 --> Model Class Initialized
INFO - 2017-06-23 04:30:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 04:30:50 --> Final output sent to browser
DEBUG - 2017-06-23 04:30:50 --> Total execution time: 0.0665
ERROR - 2017-06-23 04:30:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:30:53 --> Config Class Initialized
INFO - 2017-06-23 04:30:53 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:30:53 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:30:53 --> Utf8 Class Initialized
INFO - 2017-06-23 04:30:53 --> URI Class Initialized
INFO - 2017-06-23 04:30:53 --> Router Class Initialized
INFO - 2017-06-23 04:30:53 --> Output Class Initialized
INFO - 2017-06-23 04:30:53 --> Security Class Initialized
DEBUG - 2017-06-23 04:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:30:53 --> Input Class Initialized
INFO - 2017-06-23 04:30:53 --> Language Class Initialized
INFO - 2017-06-23 04:30:53 --> Loader Class Initialized
INFO - 2017-06-23 04:30:53 --> Controller Class Initialized
INFO - 2017-06-23 04:30:53 --> Database Driver Class Initialized
INFO - 2017-06-23 04:30:53 --> Model Class Initialized
INFO - 2017-06-23 04:30:53 --> Helper loaded: form_helper
INFO - 2017-06-23 04:30:53 --> Helper loaded: url_helper
INFO - 2017-06-23 04:30:53 --> Model Class Initialized
INFO - 2017-06-23 04:30:53 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 04:30:53 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 04:30:53 --> Final output sent to browser
DEBUG - 2017-06-23 04:30:53 --> Total execution time: 0.4010
ERROR - 2017-06-23 04:31:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:31:00 --> Config Class Initialized
INFO - 2017-06-23 04:31:00 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:31:00 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:31:00 --> Utf8 Class Initialized
INFO - 2017-06-23 04:31:00 --> URI Class Initialized
INFO - 2017-06-23 04:31:00 --> Router Class Initialized
INFO - 2017-06-23 04:31:00 --> Output Class Initialized
INFO - 2017-06-23 04:31:00 --> Security Class Initialized
DEBUG - 2017-06-23 04:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:31:00 --> Input Class Initialized
INFO - 2017-06-23 04:31:00 --> Language Class Initialized
INFO - 2017-06-23 04:31:00 --> Loader Class Initialized
INFO - 2017-06-23 04:31:00 --> Controller Class Initialized
INFO - 2017-06-23 04:31:00 --> Database Driver Class Initialized
INFO - 2017-06-23 04:31:00 --> Model Class Initialized
INFO - 2017-06-23 04:31:00 --> Helper loaded: form_helper
INFO - 2017-06-23 04:31:00 --> Helper loaded: url_helper
INFO - 2017-06-23 04:31:00 --> Model Class Initialized
INFO - 2017-06-23 04:31:00 --> Final output sent to browser
DEBUG - 2017-06-23 04:31:00 --> Total execution time: 0.0505
ERROR - 2017-06-23 04:31:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:31:01 --> Config Class Initialized
INFO - 2017-06-23 04:31:01 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:31:01 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:31:01 --> Utf8 Class Initialized
INFO - 2017-06-23 04:31:01 --> URI Class Initialized
INFO - 2017-06-23 04:31:01 --> Router Class Initialized
INFO - 2017-06-23 04:31:01 --> Output Class Initialized
INFO - 2017-06-23 04:31:01 --> Security Class Initialized
DEBUG - 2017-06-23 04:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:31:01 --> Input Class Initialized
INFO - 2017-06-23 04:31:01 --> Language Class Initialized
INFO - 2017-06-23 04:31:01 --> Loader Class Initialized
INFO - 2017-06-23 04:31:01 --> Controller Class Initialized
INFO - 2017-06-23 04:31:01 --> Database Driver Class Initialized
INFO - 2017-06-23 04:31:01 --> Model Class Initialized
INFO - 2017-06-23 04:31:01 --> Helper loaded: form_helper
INFO - 2017-06-23 04:31:01 --> Helper loaded: url_helper
INFO - 2017-06-23 04:31:01 --> Model Class Initialized
INFO - 2017-06-23 04:31:01 --> Final output sent to browser
DEBUG - 2017-06-23 04:31:01 --> Total execution time: 0.0580
ERROR - 2017-06-23 04:31:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:31:03 --> Config Class Initialized
INFO - 2017-06-23 04:31:03 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:31:03 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:31:03 --> Utf8 Class Initialized
INFO - 2017-06-23 04:31:03 --> URI Class Initialized
INFO - 2017-06-23 04:31:03 --> Router Class Initialized
INFO - 2017-06-23 04:31:03 --> Output Class Initialized
INFO - 2017-06-23 04:31:03 --> Security Class Initialized
DEBUG - 2017-06-23 04:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:31:03 --> Input Class Initialized
INFO - 2017-06-23 04:31:03 --> Language Class Initialized
INFO - 2017-06-23 04:31:03 --> Loader Class Initialized
INFO - 2017-06-23 04:31:03 --> Controller Class Initialized
INFO - 2017-06-23 04:31:03 --> Database Driver Class Initialized
INFO - 2017-06-23 04:31:03 --> Model Class Initialized
INFO - 2017-06-23 04:31:03 --> Helper loaded: form_helper
INFO - 2017-06-23 04:31:03 --> Helper loaded: url_helper
INFO - 2017-06-23 04:31:03 --> Model Class Initialized
INFO - 2017-06-23 04:31:03 --> Final output sent to browser
DEBUG - 2017-06-23 04:31:03 --> Total execution time: 0.0600
ERROR - 2017-06-23 04:31:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:31:05 --> Config Class Initialized
INFO - 2017-06-23 04:31:05 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:31:05 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:31:05 --> Utf8 Class Initialized
INFO - 2017-06-23 04:31:05 --> URI Class Initialized
INFO - 2017-06-23 04:31:05 --> Router Class Initialized
INFO - 2017-06-23 04:31:05 --> Output Class Initialized
INFO - 2017-06-23 04:31:05 --> Security Class Initialized
DEBUG - 2017-06-23 04:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:31:05 --> Input Class Initialized
INFO - 2017-06-23 04:31:05 --> Language Class Initialized
INFO - 2017-06-23 04:31:05 --> Loader Class Initialized
INFO - 2017-06-23 04:31:05 --> Controller Class Initialized
INFO - 2017-06-23 04:31:05 --> Database Driver Class Initialized
INFO - 2017-06-23 04:31:05 --> Model Class Initialized
INFO - 2017-06-23 04:31:05 --> Helper loaded: form_helper
INFO - 2017-06-23 04:31:05 --> Helper loaded: url_helper
INFO - 2017-06-23 04:31:05 --> Model Class Initialized
INFO - 2017-06-23 04:31:05 --> Final output sent to browser
DEBUG - 2017-06-23 04:31:05 --> Total execution time: 0.0730
ERROR - 2017-06-23 04:31:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:31:06 --> Config Class Initialized
INFO - 2017-06-23 04:31:06 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:31:06 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:31:06 --> Utf8 Class Initialized
INFO - 2017-06-23 04:31:06 --> URI Class Initialized
INFO - 2017-06-23 04:31:06 --> Router Class Initialized
INFO - 2017-06-23 04:31:06 --> Output Class Initialized
INFO - 2017-06-23 04:31:06 --> Security Class Initialized
DEBUG - 2017-06-23 04:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:31:06 --> Input Class Initialized
INFO - 2017-06-23 04:31:06 --> Language Class Initialized
INFO - 2017-06-23 04:31:06 --> Loader Class Initialized
INFO - 2017-06-23 04:31:06 --> Controller Class Initialized
INFO - 2017-06-23 04:31:06 --> Database Driver Class Initialized
INFO - 2017-06-23 04:31:06 --> Model Class Initialized
INFO - 2017-06-23 04:31:06 --> Helper loaded: form_helper
INFO - 2017-06-23 04:31:06 --> Helper loaded: url_helper
INFO - 2017-06-23 04:31:06 --> Model Class Initialized
INFO - 2017-06-23 04:31:06 --> Final output sent to browser
DEBUG - 2017-06-23 04:31:06 --> Total execution time: 0.1010
ERROR - 2017-06-23 04:31:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:31:10 --> Config Class Initialized
INFO - 2017-06-23 04:31:10 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:31:10 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:31:10 --> Utf8 Class Initialized
INFO - 2017-06-23 04:31:10 --> URI Class Initialized
INFO - 2017-06-23 04:31:10 --> Router Class Initialized
INFO - 2017-06-23 04:31:10 --> Output Class Initialized
INFO - 2017-06-23 04:31:10 --> Security Class Initialized
DEBUG - 2017-06-23 04:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:31:10 --> Input Class Initialized
INFO - 2017-06-23 04:31:10 --> Language Class Initialized
INFO - 2017-06-23 04:31:10 --> Loader Class Initialized
INFO - 2017-06-23 04:31:10 --> Controller Class Initialized
INFO - 2017-06-23 04:31:10 --> Database Driver Class Initialized
INFO - 2017-06-23 04:31:10 --> Model Class Initialized
INFO - 2017-06-23 04:31:10 --> Helper loaded: form_helper
INFO - 2017-06-23 04:31:10 --> Helper loaded: url_helper
INFO - 2017-06-23 04:31:10 --> Model Class Initialized
INFO - 2017-06-23 04:31:10 --> Final output sent to browser
DEBUG - 2017-06-23 04:31:10 --> Total execution time: 0.1680
ERROR - 2017-06-23 04:31:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:31:31 --> Config Class Initialized
INFO - 2017-06-23 04:31:31 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:31:31 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:31:31 --> Utf8 Class Initialized
INFO - 2017-06-23 04:31:31 --> URI Class Initialized
INFO - 2017-06-23 04:31:31 --> Router Class Initialized
INFO - 2017-06-23 04:31:32 --> Output Class Initialized
INFO - 2017-06-23 04:31:32 --> Security Class Initialized
DEBUG - 2017-06-23 04:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:31:32 --> Input Class Initialized
INFO - 2017-06-23 04:31:32 --> Language Class Initialized
INFO - 2017-06-23 04:31:32 --> Loader Class Initialized
INFO - 2017-06-23 04:31:32 --> Controller Class Initialized
INFO - 2017-06-23 04:31:32 --> Database Driver Class Initialized
INFO - 2017-06-23 04:31:32 --> Model Class Initialized
INFO - 2017-06-23 04:31:32 --> Helper loaded: form_helper
INFO - 2017-06-23 04:31:32 --> Helper loaded: url_helper
INFO - 2017-06-23 04:31:32 --> Model Class Initialized
INFO - 2017-06-23 04:31:32 --> Final output sent to browser
DEBUG - 2017-06-23 04:31:32 --> Total execution time: 0.0560
ERROR - 2017-06-23 04:31:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:31:49 --> Config Class Initialized
INFO - 2017-06-23 04:31:49 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:31:49 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:31:49 --> Utf8 Class Initialized
INFO - 2017-06-23 04:31:49 --> URI Class Initialized
INFO - 2017-06-23 04:31:49 --> Router Class Initialized
INFO - 2017-06-23 04:31:49 --> Output Class Initialized
INFO - 2017-06-23 04:31:49 --> Security Class Initialized
DEBUG - 2017-06-23 04:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:31:49 --> Input Class Initialized
INFO - 2017-06-23 04:31:49 --> Language Class Initialized
INFO - 2017-06-23 04:31:49 --> Loader Class Initialized
INFO - 2017-06-23 04:31:49 --> Controller Class Initialized
INFO - 2017-06-23 04:31:49 --> Database Driver Class Initialized
INFO - 2017-06-23 04:31:49 --> Model Class Initialized
INFO - 2017-06-23 04:31:49 --> Helper loaded: form_helper
INFO - 2017-06-23 04:31:49 --> Helper loaded: url_helper
INFO - 2017-06-23 04:31:49 --> Model Class Initialized
INFO - 2017-06-23 04:31:49 --> Final output sent to browser
DEBUG - 2017-06-23 04:31:49 --> Total execution time: 0.1110
ERROR - 2017-06-23 04:32:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:32:04 --> Config Class Initialized
INFO - 2017-06-23 04:32:04 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:32:04 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:32:04 --> Utf8 Class Initialized
INFO - 2017-06-23 04:32:04 --> URI Class Initialized
INFO - 2017-06-23 04:32:04 --> Router Class Initialized
INFO - 2017-06-23 04:32:04 --> Output Class Initialized
INFO - 2017-06-23 04:32:04 --> Security Class Initialized
DEBUG - 2017-06-23 04:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:32:04 --> Input Class Initialized
INFO - 2017-06-23 04:32:04 --> Language Class Initialized
INFO - 2017-06-23 04:32:04 --> Loader Class Initialized
INFO - 2017-06-23 04:32:04 --> Controller Class Initialized
INFO - 2017-06-23 04:32:04 --> Database Driver Class Initialized
INFO - 2017-06-23 04:32:04 --> Model Class Initialized
INFO - 2017-06-23 04:32:04 --> Helper loaded: form_helper
INFO - 2017-06-23 04:32:04 --> Helper loaded: url_helper
INFO - 2017-06-23 04:32:04 --> Model Class Initialized
INFO - 2017-06-23 04:32:04 --> Final output sent to browser
DEBUG - 2017-06-23 04:32:04 --> Total execution time: 0.0470
ERROR - 2017-06-23 04:32:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:32:18 --> Config Class Initialized
INFO - 2017-06-23 04:32:18 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:32:18 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:32:18 --> Utf8 Class Initialized
INFO - 2017-06-23 04:32:18 --> URI Class Initialized
INFO - 2017-06-23 04:32:18 --> Router Class Initialized
INFO - 2017-06-23 04:32:18 --> Output Class Initialized
INFO - 2017-06-23 04:32:18 --> Security Class Initialized
DEBUG - 2017-06-23 04:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:32:18 --> Input Class Initialized
INFO - 2017-06-23 04:32:18 --> Language Class Initialized
INFO - 2017-06-23 04:32:18 --> Loader Class Initialized
INFO - 2017-06-23 04:32:18 --> Controller Class Initialized
INFO - 2017-06-23 04:32:18 --> Database Driver Class Initialized
INFO - 2017-06-23 04:32:18 --> Model Class Initialized
INFO - 2017-06-23 04:32:18 --> Helper loaded: form_helper
INFO - 2017-06-23 04:32:18 --> Helper loaded: url_helper
INFO - 2017-06-23 04:32:18 --> Model Class Initialized
INFO - 2017-06-23 04:32:18 --> Final output sent to browser
DEBUG - 2017-06-23 04:32:18 --> Total execution time: 0.0500
ERROR - 2017-06-23 04:36:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:36:23 --> Config Class Initialized
INFO - 2017-06-23 04:36:23 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:36:23 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:36:23 --> Utf8 Class Initialized
INFO - 2017-06-23 04:36:23 --> URI Class Initialized
INFO - 2017-06-23 04:36:23 --> Router Class Initialized
INFO - 2017-06-23 04:36:23 --> Output Class Initialized
INFO - 2017-06-23 04:36:23 --> Security Class Initialized
DEBUG - 2017-06-23 04:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:36:23 --> Input Class Initialized
INFO - 2017-06-23 04:36:23 --> Language Class Initialized
INFO - 2017-06-23 04:36:23 --> Loader Class Initialized
INFO - 2017-06-23 04:36:23 --> Controller Class Initialized
INFO - 2017-06-23 04:36:23 --> Database Driver Class Initialized
INFO - 2017-06-23 04:36:23 --> Model Class Initialized
INFO - 2017-06-23 04:36:23 --> Helper loaded: form_helper
INFO - 2017-06-23 04:36:23 --> Helper loaded: url_helper
INFO - 2017-06-23 04:36:23 --> Model Class Initialized
INFO - 2017-06-23 04:36:23 --> Final output sent to browser
DEBUG - 2017-06-23 04:36:23 --> Total execution time: 0.1005
ERROR - 2017-06-23 04:36:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:36:24 --> Config Class Initialized
INFO - 2017-06-23 04:36:24 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:36:24 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:36:24 --> Utf8 Class Initialized
INFO - 2017-06-23 04:36:24 --> URI Class Initialized
INFO - 2017-06-23 04:36:24 --> Router Class Initialized
INFO - 2017-06-23 04:36:24 --> Output Class Initialized
INFO - 2017-06-23 04:36:24 --> Security Class Initialized
DEBUG - 2017-06-23 04:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:36:24 --> Input Class Initialized
INFO - 2017-06-23 04:36:24 --> Language Class Initialized
INFO - 2017-06-23 04:36:24 --> Loader Class Initialized
INFO - 2017-06-23 04:36:24 --> Controller Class Initialized
INFO - 2017-06-23 04:36:24 --> Database Driver Class Initialized
INFO - 2017-06-23 04:36:24 --> Model Class Initialized
INFO - 2017-06-23 04:36:24 --> Helper loaded: form_helper
INFO - 2017-06-23 04:36:24 --> Helper loaded: url_helper
INFO - 2017-06-23 04:36:24 --> Model Class Initialized
INFO - 2017-06-23 04:36:24 --> Final output sent to browser
DEBUG - 2017-06-23 04:36:24 --> Total execution time: 0.1330
ERROR - 2017-06-23 04:36:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:36:36 --> Config Class Initialized
INFO - 2017-06-23 04:36:36 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:36:36 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:36:36 --> Utf8 Class Initialized
INFO - 2017-06-23 04:36:36 --> URI Class Initialized
INFO - 2017-06-23 04:36:36 --> Router Class Initialized
INFO - 2017-06-23 04:36:36 --> Output Class Initialized
INFO - 2017-06-23 04:36:36 --> Security Class Initialized
DEBUG - 2017-06-23 04:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:36:36 --> Input Class Initialized
INFO - 2017-06-23 04:36:36 --> Language Class Initialized
INFO - 2017-06-23 04:36:36 --> Loader Class Initialized
INFO - 2017-06-23 04:36:36 --> Controller Class Initialized
INFO - 2017-06-23 04:36:36 --> Database Driver Class Initialized
INFO - 2017-06-23 04:36:36 --> Model Class Initialized
INFO - 2017-06-23 04:36:36 --> Helper loaded: form_helper
INFO - 2017-06-23 04:36:36 --> Helper loaded: url_helper
INFO - 2017-06-23 04:36:36 --> Model Class Initialized
INFO - 2017-06-23 04:36:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 04:36:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 04:36:36 --> Final output sent to browser
DEBUG - 2017-06-23 04:36:36 --> Total execution time: 0.2820
ERROR - 2017-06-23 04:36:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:36:37 --> Config Class Initialized
INFO - 2017-06-23 04:36:37 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:36:37 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:36:37 --> Utf8 Class Initialized
INFO - 2017-06-23 04:36:37 --> URI Class Initialized
INFO - 2017-06-23 04:36:37 --> Router Class Initialized
INFO - 2017-06-23 04:36:37 --> Output Class Initialized
INFO - 2017-06-23 04:36:37 --> Security Class Initialized
DEBUG - 2017-06-23 04:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:36:37 --> Input Class Initialized
INFO - 2017-06-23 04:36:37 --> Language Class Initialized
INFO - 2017-06-23 04:36:37 --> Loader Class Initialized
INFO - 2017-06-23 04:36:37 --> Controller Class Initialized
INFO - 2017-06-23 04:36:37 --> Database Driver Class Initialized
INFO - 2017-06-23 04:36:37 --> Model Class Initialized
INFO - 2017-06-23 04:36:37 --> Helper loaded: form_helper
INFO - 2017-06-23 04:36:37 --> Helper loaded: url_helper
INFO - 2017-06-23 04:36:37 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 04:36:37 --> Model Class Initialized
INFO - 2017-06-23 04:36:37 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-23 04:36:37 --> Final output sent to browser
DEBUG - 2017-06-23 04:36:37 --> Total execution time: 0.0590
ERROR - 2017-06-23 04:36:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:36:40 --> Config Class Initialized
INFO - 2017-06-23 04:36:40 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:36:40 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:36:40 --> Utf8 Class Initialized
INFO - 2017-06-23 04:36:40 --> URI Class Initialized
INFO - 2017-06-23 04:36:40 --> Router Class Initialized
INFO - 2017-06-23 04:36:40 --> Output Class Initialized
INFO - 2017-06-23 04:36:40 --> Security Class Initialized
DEBUG - 2017-06-23 04:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:36:40 --> Input Class Initialized
INFO - 2017-06-23 04:36:40 --> Language Class Initialized
INFO - 2017-06-23 04:36:40 --> Loader Class Initialized
INFO - 2017-06-23 04:36:40 --> Controller Class Initialized
INFO - 2017-06-23 04:36:40 --> Database Driver Class Initialized
INFO - 2017-06-23 04:36:40 --> Model Class Initialized
INFO - 2017-06-23 04:36:40 --> Helper loaded: form_helper
INFO - 2017-06-23 04:36:40 --> Helper loaded: url_helper
INFO - 2017-06-23 04:36:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 04:36:40 --> Model Class Initialized
INFO - 2017-06-23 04:36:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 04:36:40 --> Final output sent to browser
DEBUG - 2017-06-23 04:36:40 --> Total execution time: 0.1800
ERROR - 2017-06-23 04:36:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:36:42 --> Config Class Initialized
INFO - 2017-06-23 04:36:42 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:36:42 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:36:42 --> Utf8 Class Initialized
INFO - 2017-06-23 04:36:42 --> URI Class Initialized
INFO - 2017-06-23 04:36:42 --> Router Class Initialized
INFO - 2017-06-23 04:36:42 --> Output Class Initialized
INFO - 2017-06-23 04:36:42 --> Security Class Initialized
DEBUG - 2017-06-23 04:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:36:42 --> Input Class Initialized
INFO - 2017-06-23 04:36:42 --> Language Class Initialized
INFO - 2017-06-23 04:36:42 --> Loader Class Initialized
INFO - 2017-06-23 04:36:42 --> Controller Class Initialized
INFO - 2017-06-23 04:36:42 --> Database Driver Class Initialized
INFO - 2017-06-23 04:36:42 --> Model Class Initialized
INFO - 2017-06-23 04:36:42 --> Helper loaded: form_helper
INFO - 2017-06-23 04:36:42 --> Helper loaded: url_helper
INFO - 2017-06-23 04:36:42 --> Model Class Initialized
INFO - 2017-06-23 04:36:42 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 04:36:42 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 04:36:42 --> Final output sent to browser
DEBUG - 2017-06-23 04:36:42 --> Total execution time: 0.0820
ERROR - 2017-06-23 04:36:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:36:43 --> Config Class Initialized
INFO - 2017-06-23 04:36:43 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:36:43 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:36:43 --> Utf8 Class Initialized
INFO - 2017-06-23 04:36:43 --> URI Class Initialized
INFO - 2017-06-23 04:36:43 --> Router Class Initialized
INFO - 2017-06-23 04:36:43 --> Output Class Initialized
INFO - 2017-06-23 04:36:43 --> Security Class Initialized
DEBUG - 2017-06-23 04:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:36:43 --> Input Class Initialized
INFO - 2017-06-23 04:36:43 --> Language Class Initialized
INFO - 2017-06-23 04:36:43 --> Loader Class Initialized
INFO - 2017-06-23 04:36:43 --> Controller Class Initialized
INFO - 2017-06-23 04:36:43 --> Database Driver Class Initialized
INFO - 2017-06-23 04:36:43 --> Model Class Initialized
INFO - 2017-06-23 04:36:43 --> Helper loaded: form_helper
INFO - 2017-06-23 04:36:43 --> Helper loaded: url_helper
INFO - 2017-06-23 04:36:43 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 04:36:43 --> Model Class Initialized
INFO - 2017-06-23 04:36:43 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-23 04:36:43 --> Final output sent to browser
DEBUG - 2017-06-23 04:36:43 --> Total execution time: 0.1050
ERROR - 2017-06-23 04:36:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:36:45 --> Config Class Initialized
INFO - 2017-06-23 04:36:45 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:36:45 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:36:45 --> Utf8 Class Initialized
INFO - 2017-06-23 04:36:45 --> URI Class Initialized
INFO - 2017-06-23 04:36:45 --> Router Class Initialized
INFO - 2017-06-23 04:36:45 --> Output Class Initialized
INFO - 2017-06-23 04:36:45 --> Security Class Initialized
DEBUG - 2017-06-23 04:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:36:45 --> Input Class Initialized
INFO - 2017-06-23 04:36:46 --> Language Class Initialized
INFO - 2017-06-23 04:36:46 --> Loader Class Initialized
INFO - 2017-06-23 04:36:46 --> Controller Class Initialized
INFO - 2017-06-23 04:36:46 --> Database Driver Class Initialized
INFO - 2017-06-23 04:36:46 --> Model Class Initialized
INFO - 2017-06-23 04:36:46 --> Helper loaded: form_helper
INFO - 2017-06-23 04:36:46 --> Helper loaded: url_helper
INFO - 2017-06-23 04:36:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 04:36:46 --> Model Class Initialized
INFO - 2017-06-23 04:36:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 04:36:46 --> Final output sent to browser
DEBUG - 2017-06-23 04:36:46 --> Total execution time: 0.0550
ERROR - 2017-06-23 04:36:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:36:48 --> Config Class Initialized
INFO - 2017-06-23 04:36:48 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:36:48 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:36:48 --> Utf8 Class Initialized
INFO - 2017-06-23 04:36:48 --> URI Class Initialized
INFO - 2017-06-23 04:36:48 --> Router Class Initialized
INFO - 2017-06-23 04:36:48 --> Output Class Initialized
INFO - 2017-06-23 04:36:48 --> Security Class Initialized
DEBUG - 2017-06-23 04:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:36:48 --> Input Class Initialized
INFO - 2017-06-23 04:36:48 --> Language Class Initialized
INFO - 2017-06-23 04:36:48 --> Loader Class Initialized
INFO - 2017-06-23 04:36:48 --> Controller Class Initialized
INFO - 2017-06-23 04:36:48 --> Database Driver Class Initialized
INFO - 2017-06-23 04:36:48 --> Model Class Initialized
INFO - 2017-06-23 04:36:48 --> Helper loaded: form_helper
INFO - 2017-06-23 04:36:48 --> Helper loaded: url_helper
INFO - 2017-06-23 04:36:48 --> Model Class Initialized
INFO - 2017-06-23 04:36:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 04:36:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 04:36:48 --> Final output sent to browser
DEBUG - 2017-06-23 04:36:48 --> Total execution time: 0.1680
ERROR - 2017-06-23 04:36:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:36:53 --> Config Class Initialized
INFO - 2017-06-23 04:36:53 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:36:53 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:36:53 --> Utf8 Class Initialized
INFO - 2017-06-23 04:36:53 --> URI Class Initialized
INFO - 2017-06-23 04:36:53 --> Router Class Initialized
INFO - 2017-06-23 04:36:53 --> Output Class Initialized
INFO - 2017-06-23 04:36:53 --> Security Class Initialized
DEBUG - 2017-06-23 04:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:36:53 --> Input Class Initialized
INFO - 2017-06-23 04:36:53 --> Language Class Initialized
INFO - 2017-06-23 04:36:53 --> Loader Class Initialized
INFO - 2017-06-23 04:36:53 --> Controller Class Initialized
INFO - 2017-06-23 04:36:53 --> Database Driver Class Initialized
INFO - 2017-06-23 04:36:53 --> Model Class Initialized
INFO - 2017-06-23 04:36:53 --> Helper loaded: form_helper
INFO - 2017-06-23 04:36:53 --> Helper loaded: url_helper
INFO - 2017-06-23 04:36:53 --> Model Class Initialized
INFO - 2017-06-23 04:36:53 --> Final output sent to browser
DEBUG - 2017-06-23 04:36:53 --> Total execution time: 0.0540
ERROR - 2017-06-23 04:36:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:36:54 --> Config Class Initialized
INFO - 2017-06-23 04:36:54 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:36:54 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:36:54 --> Utf8 Class Initialized
INFO - 2017-06-23 04:36:54 --> URI Class Initialized
INFO - 2017-06-23 04:36:54 --> Router Class Initialized
INFO - 2017-06-23 04:36:54 --> Output Class Initialized
INFO - 2017-06-23 04:36:54 --> Security Class Initialized
DEBUG - 2017-06-23 04:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:36:54 --> Input Class Initialized
INFO - 2017-06-23 04:36:54 --> Language Class Initialized
INFO - 2017-06-23 04:36:54 --> Loader Class Initialized
INFO - 2017-06-23 04:36:54 --> Controller Class Initialized
INFO - 2017-06-23 04:36:54 --> Database Driver Class Initialized
INFO - 2017-06-23 04:36:54 --> Model Class Initialized
INFO - 2017-06-23 04:36:54 --> Helper loaded: form_helper
INFO - 2017-06-23 04:36:54 --> Helper loaded: url_helper
INFO - 2017-06-23 04:36:54 --> Model Class Initialized
INFO - 2017-06-23 04:36:54 --> Final output sent to browser
DEBUG - 2017-06-23 04:36:54 --> Total execution time: 0.0490
ERROR - 2017-06-23 04:36:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:36:55 --> Config Class Initialized
INFO - 2017-06-23 04:36:55 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:36:55 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:36:55 --> Utf8 Class Initialized
INFO - 2017-06-23 04:36:55 --> URI Class Initialized
INFO - 2017-06-23 04:36:55 --> Router Class Initialized
INFO - 2017-06-23 04:36:55 --> Output Class Initialized
INFO - 2017-06-23 04:36:55 --> Security Class Initialized
DEBUG - 2017-06-23 04:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:36:55 --> Input Class Initialized
INFO - 2017-06-23 04:36:55 --> Language Class Initialized
INFO - 2017-06-23 04:36:55 --> Loader Class Initialized
INFO - 2017-06-23 04:36:55 --> Controller Class Initialized
INFO - 2017-06-23 04:36:55 --> Database Driver Class Initialized
INFO - 2017-06-23 04:36:55 --> Model Class Initialized
INFO - 2017-06-23 04:36:55 --> Helper loaded: form_helper
INFO - 2017-06-23 04:36:55 --> Helper loaded: url_helper
INFO - 2017-06-23 04:36:55 --> Model Class Initialized
INFO - 2017-06-23 04:36:55 --> Final output sent to browser
DEBUG - 2017-06-23 04:36:55 --> Total execution time: 0.0820
ERROR - 2017-06-23 04:36:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:36:58 --> Config Class Initialized
INFO - 2017-06-23 04:36:58 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:36:58 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:36:58 --> Utf8 Class Initialized
INFO - 2017-06-23 04:36:58 --> URI Class Initialized
INFO - 2017-06-23 04:36:58 --> Router Class Initialized
INFO - 2017-06-23 04:36:58 --> Output Class Initialized
INFO - 2017-06-23 04:36:58 --> Security Class Initialized
DEBUG - 2017-06-23 04:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:36:58 --> Input Class Initialized
INFO - 2017-06-23 04:36:58 --> Language Class Initialized
INFO - 2017-06-23 04:36:58 --> Loader Class Initialized
INFO - 2017-06-23 04:36:58 --> Controller Class Initialized
INFO - 2017-06-23 04:36:58 --> Database Driver Class Initialized
INFO - 2017-06-23 04:36:58 --> Model Class Initialized
INFO - 2017-06-23 04:36:58 --> Helper loaded: form_helper
INFO - 2017-06-23 04:36:58 --> Helper loaded: url_helper
INFO - 2017-06-23 04:36:58 --> Model Class Initialized
INFO - 2017-06-23 04:36:58 --> Final output sent to browser
DEBUG - 2017-06-23 04:36:58 --> Total execution time: 0.0770
ERROR - 2017-06-23 04:36:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:36:59 --> Config Class Initialized
INFO - 2017-06-23 04:36:59 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:36:59 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:36:59 --> Utf8 Class Initialized
INFO - 2017-06-23 04:36:59 --> URI Class Initialized
INFO - 2017-06-23 04:36:59 --> Router Class Initialized
INFO - 2017-06-23 04:36:59 --> Output Class Initialized
INFO - 2017-06-23 04:36:59 --> Security Class Initialized
DEBUG - 2017-06-23 04:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:36:59 --> Input Class Initialized
INFO - 2017-06-23 04:36:59 --> Language Class Initialized
INFO - 2017-06-23 04:36:59 --> Loader Class Initialized
INFO - 2017-06-23 04:36:59 --> Controller Class Initialized
INFO - 2017-06-23 04:36:59 --> Database Driver Class Initialized
INFO - 2017-06-23 04:36:59 --> Model Class Initialized
INFO - 2017-06-23 04:36:59 --> Helper loaded: form_helper
INFO - 2017-06-23 04:36:59 --> Helper loaded: url_helper
INFO - 2017-06-23 04:36:59 --> Model Class Initialized
INFO - 2017-06-23 04:37:00 --> Final output sent to browser
DEBUG - 2017-06-23 04:37:00 --> Total execution time: 0.0600
ERROR - 2017-06-23 04:37:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:37:02 --> Config Class Initialized
INFO - 2017-06-23 04:37:02 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:37:02 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:37:02 --> Utf8 Class Initialized
INFO - 2017-06-23 04:37:02 --> URI Class Initialized
INFO - 2017-06-23 04:37:02 --> Router Class Initialized
INFO - 2017-06-23 04:37:02 --> Output Class Initialized
INFO - 2017-06-23 04:37:02 --> Security Class Initialized
DEBUG - 2017-06-23 04:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:37:02 --> Input Class Initialized
INFO - 2017-06-23 04:37:02 --> Language Class Initialized
INFO - 2017-06-23 04:37:02 --> Loader Class Initialized
INFO - 2017-06-23 04:37:02 --> Controller Class Initialized
INFO - 2017-06-23 04:37:02 --> Database Driver Class Initialized
INFO - 2017-06-23 04:37:02 --> Model Class Initialized
INFO - 2017-06-23 04:37:02 --> Helper loaded: form_helper
INFO - 2017-06-23 04:37:02 --> Helper loaded: url_helper
INFO - 2017-06-23 04:37:02 --> Model Class Initialized
INFO - 2017-06-23 04:37:02 --> Final output sent to browser
DEBUG - 2017-06-23 04:37:02 --> Total execution time: 0.1000
ERROR - 2017-06-23 04:37:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 04:37:29 --> Config Class Initialized
INFO - 2017-06-23 04:37:29 --> Hooks Class Initialized
DEBUG - 2017-06-23 04:37:29 --> UTF-8 Support Enabled
INFO - 2017-06-23 04:37:29 --> Utf8 Class Initialized
INFO - 2017-06-23 04:37:29 --> URI Class Initialized
INFO - 2017-06-23 04:37:29 --> Router Class Initialized
INFO - 2017-06-23 04:37:29 --> Output Class Initialized
INFO - 2017-06-23 04:37:29 --> Security Class Initialized
DEBUG - 2017-06-23 04:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 04:37:29 --> Input Class Initialized
INFO - 2017-06-23 04:37:29 --> Language Class Initialized
INFO - 2017-06-23 04:37:29 --> Loader Class Initialized
INFO - 2017-06-23 04:37:29 --> Controller Class Initialized
INFO - 2017-06-23 04:37:29 --> Database Driver Class Initialized
INFO - 2017-06-23 04:37:29 --> Model Class Initialized
INFO - 2017-06-23 04:37:29 --> Helper loaded: form_helper
INFO - 2017-06-23 04:37:29 --> Helper loaded: url_helper
INFO - 2017-06-23 04:37:29 --> Model Class Initialized
INFO - 2017-06-23 04:37:29 --> Final output sent to browser
DEBUG - 2017-06-23 04:37:29 --> Total execution time: 0.0760
ERROR - 2017-06-23 12:45:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 12:45:27 --> Config Class Initialized
INFO - 2017-06-23 12:45:27 --> Hooks Class Initialized
DEBUG - 2017-06-23 12:45:27 --> UTF-8 Support Enabled
INFO - 2017-06-23 12:45:27 --> Utf8 Class Initialized
INFO - 2017-06-23 12:45:27 --> URI Class Initialized
INFO - 2017-06-23 12:45:27 --> Router Class Initialized
INFO - 2017-06-23 12:45:27 --> Output Class Initialized
INFO - 2017-06-23 12:45:27 --> Security Class Initialized
DEBUG - 2017-06-23 12:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 12:45:27 --> Input Class Initialized
INFO - 2017-06-23 12:45:27 --> Language Class Initialized
INFO - 2017-06-23 12:45:27 --> Loader Class Initialized
INFO - 2017-06-23 12:45:28 --> Controller Class Initialized
INFO - 2017-06-23 12:45:28 --> Database Driver Class Initialized
INFO - 2017-06-23 12:45:28 --> Model Class Initialized
INFO - 2017-06-23 12:45:28 --> Helper loaded: form_helper
INFO - 2017-06-23 12:45:28 --> Helper loaded: url_helper
INFO - 2017-06-23 12:45:28 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 12:45:28 --> Model Class Initialized
INFO - 2017-06-23 12:45:28 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-23 12:45:28 --> Final output sent to browser
DEBUG - 2017-06-23 12:45:28 --> Total execution time: 0.1230
ERROR - 2017-06-23 16:51:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 16:51:22 --> Config Class Initialized
INFO - 2017-06-23 16:51:22 --> Hooks Class Initialized
DEBUG - 2017-06-23 16:51:22 --> UTF-8 Support Enabled
INFO - 2017-06-23 16:51:22 --> Utf8 Class Initialized
INFO - 2017-06-23 16:51:22 --> URI Class Initialized
INFO - 2017-06-23 16:51:22 --> Router Class Initialized
INFO - 2017-06-23 16:51:22 --> Output Class Initialized
INFO - 2017-06-23 16:51:22 --> Security Class Initialized
DEBUG - 2017-06-23 16:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 16:51:22 --> Input Class Initialized
INFO - 2017-06-23 16:51:22 --> Language Class Initialized
INFO - 2017-06-23 16:51:22 --> Loader Class Initialized
INFO - 2017-06-23 16:51:22 --> Controller Class Initialized
INFO - 2017-06-23 16:51:22 --> Database Driver Class Initialized
INFO - 2017-06-23 16:51:22 --> Model Class Initialized
INFO - 2017-06-23 16:51:22 --> Helper loaded: form_helper
INFO - 2017-06-23 16:51:22 --> Helper loaded: url_helper
INFO - 2017-06-23 16:51:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 16:51:22 --> Model Class Initialized
INFO - 2017-06-23 16:51:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 16:51:22 --> Final output sent to browser
DEBUG - 2017-06-23 16:51:22 --> Total execution time: 0.0860
ERROR - 2017-06-23 16:52:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 16:52:32 --> Config Class Initialized
INFO - 2017-06-23 16:52:32 --> Hooks Class Initialized
DEBUG - 2017-06-23 16:52:32 --> UTF-8 Support Enabled
INFO - 2017-06-23 16:52:32 --> Utf8 Class Initialized
INFO - 2017-06-23 16:52:32 --> URI Class Initialized
INFO - 2017-06-23 16:52:32 --> Router Class Initialized
INFO - 2017-06-23 16:52:32 --> Output Class Initialized
INFO - 2017-06-23 16:52:32 --> Security Class Initialized
DEBUG - 2017-06-23 16:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 16:52:32 --> Input Class Initialized
INFO - 2017-06-23 16:52:32 --> Language Class Initialized
INFO - 2017-06-23 16:52:32 --> Loader Class Initialized
INFO - 2017-06-23 16:52:32 --> Controller Class Initialized
INFO - 2017-06-23 16:52:32 --> Database Driver Class Initialized
INFO - 2017-06-23 16:52:32 --> Model Class Initialized
INFO - 2017-06-23 16:52:32 --> Helper loaded: form_helper
INFO - 2017-06-23 16:52:32 --> Helper loaded: url_helper
INFO - 2017-06-23 16:52:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 16:52:32 --> Model Class Initialized
INFO - 2017-06-23 16:52:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 16:52:32 --> Final output sent to browser
DEBUG - 2017-06-23 16:52:32 --> Total execution time: 0.1100
ERROR - 2017-06-23 16:53:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-23 16:53:40 --> Config Class Initialized
INFO - 2017-06-23 16:53:40 --> Hooks Class Initialized
DEBUG - 2017-06-23 16:53:40 --> UTF-8 Support Enabled
INFO - 2017-06-23 16:53:40 --> Utf8 Class Initialized
INFO - 2017-06-23 16:53:40 --> URI Class Initialized
INFO - 2017-06-23 16:53:40 --> Router Class Initialized
INFO - 2017-06-23 16:53:40 --> Output Class Initialized
INFO - 2017-06-23 16:53:40 --> Security Class Initialized
DEBUG - 2017-06-23 16:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-23 16:53:40 --> Input Class Initialized
INFO - 2017-06-23 16:53:40 --> Language Class Initialized
INFO - 2017-06-23 16:53:40 --> Loader Class Initialized
INFO - 2017-06-23 16:53:40 --> Controller Class Initialized
INFO - 2017-06-23 16:53:40 --> Database Driver Class Initialized
INFO - 2017-06-23 16:53:40 --> Model Class Initialized
INFO - 2017-06-23 16:53:40 --> Helper loaded: form_helper
INFO - 2017-06-23 16:53:40 --> Helper loaded: url_helper
INFO - 2017-06-23 16:53:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-23 16:53:40 --> Model Class Initialized
INFO - 2017-06-23 16:53:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-23 16:53:40 --> Final output sent to browser
DEBUG - 2017-06-23 16:53:40 --> Total execution time: 0.0850
