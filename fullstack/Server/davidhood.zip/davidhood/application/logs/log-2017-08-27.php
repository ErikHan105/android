<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-27 06:04:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-27 06:04:29 --> Config Class Initialized
INFO - 2017-08-27 06:04:29 --> Hooks Class Initialized
DEBUG - 2017-08-27 06:04:29 --> UTF-8 Support Enabled
INFO - 2017-08-27 06:04:29 --> Utf8 Class Initialized
INFO - 2017-08-27 06:04:29 --> URI Class Initialized
DEBUG - 2017-08-27 06:04:29 --> No URI present. Default controller set.
INFO - 2017-08-27 06:04:29 --> Router Class Initialized
INFO - 2017-08-27 06:04:29 --> Output Class Initialized
INFO - 2017-08-27 06:04:29 --> Security Class Initialized
DEBUG - 2017-08-27 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-27 06:04:29 --> Input Class Initialized
INFO - 2017-08-27 06:04:29 --> Language Class Initialized
INFO - 2017-08-27 06:04:29 --> Loader Class Initialized
INFO - 2017-08-27 06:04:29 --> Controller Class Initialized
INFO - 2017-08-27 06:04:29 --> Database Driver Class Initialized
INFO - 2017-08-27 06:04:29 --> Model Class Initialized
INFO - 2017-08-27 06:04:30 --> Helper loaded: form_helper
INFO - 2017-08-27 06:04:30 --> Helper loaded: url_helper
INFO - 2017-08-27 06:04:30 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-08-27 06:04:30 --> Final output sent to browser
DEBUG - 2017-08-27 06:04:30 --> Total execution time: 0.9461
ERROR - 2017-08-27 08:04:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-27 08:04:18 --> Config Class Initialized
INFO - 2017-08-27 08:04:18 --> Hooks Class Initialized
DEBUG - 2017-08-27 08:04:18 --> UTF-8 Support Enabled
INFO - 2017-08-27 08:04:18 --> Utf8 Class Initialized
INFO - 2017-08-27 08:04:18 --> URI Class Initialized
INFO - 2017-08-27 08:04:18 --> Router Class Initialized
INFO - 2017-08-27 08:04:18 --> Output Class Initialized
INFO - 2017-08-27 08:04:18 --> Security Class Initialized
DEBUG - 2017-08-27 08:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-27 08:04:18 --> Input Class Initialized
INFO - 2017-08-27 08:04:18 --> Language Class Initialized
INFO - 2017-08-27 08:04:18 --> Loader Class Initialized
INFO - 2017-08-27 08:04:18 --> Controller Class Initialized
INFO - 2017-08-27 08:04:18 --> Database Driver Class Initialized
INFO - 2017-08-27 08:04:18 --> Model Class Initialized
INFO - 2017-08-27 08:04:18 --> Helper loaded: form_helper
INFO - 2017-08-27 08:04:18 --> Helper loaded: url_helper
INFO - 2017-08-27 08:04:18 --> Model Class Initialized
ERROR - 2017-08-27 08:04:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-27 08:04:18 --> Config Class Initialized
INFO - 2017-08-27 08:04:18 --> Hooks Class Initialized
DEBUG - 2017-08-27 08:04:18 --> UTF-8 Support Enabled
INFO - 2017-08-27 08:04:18 --> Utf8 Class Initialized
INFO - 2017-08-27 08:04:18 --> URI Class Initialized
INFO - 2017-08-27 08:04:18 --> Router Class Initialized
INFO - 2017-08-27 08:04:18 --> Output Class Initialized
INFO - 2017-08-27 08:04:18 --> Security Class Initialized
DEBUG - 2017-08-27 08:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-27 08:04:18 --> Input Class Initialized
INFO - 2017-08-27 08:04:18 --> Language Class Initialized
INFO - 2017-08-27 08:04:18 --> Loader Class Initialized
INFO - 2017-08-27 08:04:18 --> Controller Class Initialized
INFO - 2017-08-27 08:04:18 --> Database Driver Class Initialized
INFO - 2017-08-27 08:04:18 --> Model Class Initialized
INFO - 2017-08-27 08:04:18 --> Helper loaded: form_helper
INFO - 2017-08-27 08:04:18 --> Helper loaded: url_helper
INFO - 2017-08-27 08:04:18 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-27 08:04:18 --> Model Class Initialized
INFO - 2017-08-27 08:04:18 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-08-27 08:04:18 --> Final output sent to browser
DEBUG - 2017-08-27 08:04:18 --> Total execution time: 0.2110
ERROR - 2017-08-27 15:41:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-27 15:41:45 --> Config Class Initialized
INFO - 2017-08-27 15:41:45 --> Hooks Class Initialized
DEBUG - 2017-08-27 15:41:45 --> UTF-8 Support Enabled
INFO - 2017-08-27 15:41:45 --> Utf8 Class Initialized
INFO - 2017-08-27 15:41:45 --> URI Class Initialized
INFO - 2017-08-27 15:41:45 --> Router Class Initialized
INFO - 2017-08-27 15:41:45 --> Output Class Initialized
INFO - 2017-08-27 15:41:45 --> Security Class Initialized
DEBUG - 2017-08-27 15:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-27 15:41:45 --> Input Class Initialized
INFO - 2017-08-27 15:41:45 --> Language Class Initialized
INFO - 2017-08-27 15:41:45 --> Loader Class Initialized
INFO - 2017-08-27 15:41:45 --> Controller Class Initialized
INFO - 2017-08-27 15:41:45 --> Database Driver Class Initialized
INFO - 2017-08-27 15:41:45 --> Model Class Initialized
INFO - 2017-08-27 15:41:45 --> Helper loaded: form_helper
INFO - 2017-08-27 15:41:45 --> Helper loaded: url_helper
INFO - 2017-08-27 15:41:45 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-27 15:41:45 --> Model Class Initialized
INFO - 2017-08-27 15:41:45 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-08-27 15:41:45 --> Final output sent to browser
DEBUG - 2017-08-27 15:41:45 --> Total execution time: 0.1140
ERROR - 2017-08-27 15:47:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-27 15:47:57 --> Config Class Initialized
INFO - 2017-08-27 15:47:57 --> Hooks Class Initialized
DEBUG - 2017-08-27 15:47:57 --> UTF-8 Support Enabled
INFO - 2017-08-27 15:47:57 --> Utf8 Class Initialized
INFO - 2017-08-27 15:47:57 --> URI Class Initialized
INFO - 2017-08-27 15:47:57 --> Router Class Initialized
INFO - 2017-08-27 15:47:57 --> Output Class Initialized
INFO - 2017-08-27 15:47:57 --> Security Class Initialized
DEBUG - 2017-08-27 15:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-27 15:47:57 --> Input Class Initialized
INFO - 2017-08-27 15:47:57 --> Language Class Initialized
INFO - 2017-08-27 15:47:57 --> Loader Class Initialized
INFO - 2017-08-27 15:47:57 --> Controller Class Initialized
INFO - 2017-08-27 15:47:57 --> Database Driver Class Initialized
INFO - 2017-08-27 15:47:57 --> Model Class Initialized
INFO - 2017-08-27 15:47:57 --> Helper loaded: form_helper
INFO - 2017-08-27 15:47:57 --> Helper loaded: url_helper
INFO - 2017-08-27 15:47:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-27 15:47:57 --> Model Class Initialized
INFO - 2017-08-27 15:47:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-08-27 15:47:57 --> Final output sent to browser
DEBUG - 2017-08-27 15:47:57 --> Total execution time: 0.1720
