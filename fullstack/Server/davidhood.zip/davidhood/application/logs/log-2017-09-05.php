<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-05 02:44:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-05 02:44:08 --> Config Class Initialized
INFO - 2017-09-05 02:44:08 --> Hooks Class Initialized
DEBUG - 2017-09-05 02:44:08 --> UTF-8 Support Enabled
INFO - 2017-09-05 02:44:08 --> Utf8 Class Initialized
INFO - 2017-09-05 02:44:08 --> URI Class Initialized
INFO - 2017-09-05 02:44:09 --> Router Class Initialized
INFO - 2017-09-05 02:44:09 --> Output Class Initialized
INFO - 2017-09-05 02:44:09 --> Security Class Initialized
DEBUG - 2017-09-05 02:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 02:44:09 --> Input Class Initialized
INFO - 2017-09-05 02:44:09 --> Language Class Initialized
INFO - 2017-09-05 02:44:09 --> Loader Class Initialized
INFO - 2017-09-05 02:44:09 --> Controller Class Initialized
INFO - 2017-09-05 02:44:09 --> Database Driver Class Initialized
INFO - 2017-09-05 02:44:09 --> Model Class Initialized
INFO - 2017-09-05 02:44:09 --> Helper loaded: form_helper
INFO - 2017-09-05 02:44:09 --> Helper loaded: url_helper
INFO - 2017-09-05 02:44:09 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-09-05 02:44:09 --> Final output sent to browser
DEBUG - 2017-09-05 02:44:09 --> Total execution time: 0.2810
ERROR - 2017-09-05 03:24:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:24:39 --> Config Class Initialized
INFO - 2017-09-05 03:24:39 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:24:39 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:24:39 --> Utf8 Class Initialized
INFO - 2017-09-05 03:24:39 --> URI Class Initialized
DEBUG - 2017-09-05 03:24:39 --> No URI present. Default controller set.
INFO - 2017-09-05 03:24:39 --> Router Class Initialized
INFO - 2017-09-05 03:24:39 --> Output Class Initialized
INFO - 2017-09-05 03:24:39 --> Security Class Initialized
DEBUG - 2017-09-05 03:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:24:39 --> Input Class Initialized
INFO - 2017-09-05 03:24:39 --> Language Class Initialized
INFO - 2017-09-05 03:24:39 --> Loader Class Initialized
INFO - 2017-09-05 03:24:39 --> Controller Class Initialized
INFO - 2017-09-05 03:24:39 --> Database Driver Class Initialized
INFO - 2017-09-05 03:24:39 --> Model Class Initialized
INFO - 2017-09-05 03:24:39 --> Helper loaded: form_helper
INFO - 2017-09-05 03:24:39 --> Helper loaded: url_helper
INFO - 2017-09-05 03:24:39 --> File loaded: C:\xampp\htdocs\biper\application\views\login.php
INFO - 2017-09-05 03:24:39 --> Final output sent to browser
DEBUG - 2017-09-05 03:24:39 --> Total execution time: 0.0900
ERROR - 2017-09-05 03:26:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:26:25 --> Config Class Initialized
INFO - 2017-09-05 03:26:25 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:26:25 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:26:25 --> Utf8 Class Initialized
INFO - 2017-09-05 03:26:25 --> URI Class Initialized
DEBUG - 2017-09-05 03:26:25 --> No URI present. Default controller set.
INFO - 2017-09-05 03:26:25 --> Router Class Initialized
INFO - 2017-09-05 03:26:25 --> Output Class Initialized
INFO - 2017-09-05 03:26:25 --> Security Class Initialized
DEBUG - 2017-09-05 03:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:26:25 --> Input Class Initialized
INFO - 2017-09-05 03:26:25 --> Language Class Initialized
INFO - 2017-09-05 03:26:25 --> Loader Class Initialized
INFO - 2017-09-05 03:26:25 --> Controller Class Initialized
INFO - 2017-09-05 03:26:25 --> Database Driver Class Initialized
INFO - 2017-09-05 03:26:25 --> Model Class Initialized
INFO - 2017-09-05 03:26:25 --> Helper loaded: form_helper
INFO - 2017-09-05 03:26:25 --> Helper loaded: url_helper
INFO - 2017-09-05 03:26:25 --> File loaded: C:\xampp\htdocs\biper\application\views\login.php
INFO - 2017-09-05 03:26:25 --> Final output sent to browser
DEBUG - 2017-09-05 03:26:25 --> Total execution time: 0.0480
ERROR - 2017-09-05 03:26:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:26:43 --> Config Class Initialized
INFO - 2017-09-05 03:26:43 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:26:43 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:26:43 --> Utf8 Class Initialized
INFO - 2017-09-05 03:26:43 --> URI Class Initialized
INFO - 2017-09-05 03:26:43 --> Router Class Initialized
INFO - 2017-09-05 03:26:43 --> Output Class Initialized
INFO - 2017-09-05 03:26:43 --> Security Class Initialized
DEBUG - 2017-09-05 03:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:26:43 --> Input Class Initialized
INFO - 2017-09-05 03:26:43 --> Language Class Initialized
INFO - 2017-09-05 03:26:43 --> Loader Class Initialized
INFO - 2017-09-05 03:26:43 --> Controller Class Initialized
INFO - 2017-09-05 03:26:43 --> Database Driver Class Initialized
INFO - 2017-09-05 03:26:43 --> Model Class Initialized
INFO - 2017-09-05 03:26:43 --> Helper loaded: form_helper
INFO - 2017-09-05 03:26:43 --> Helper loaded: url_helper
INFO - 2017-09-05 03:26:43 --> File loaded: C:\xampp\htdocs\biper\application\views\forgot_password.php
INFO - 2017-09-05 03:26:43 --> Final output sent to browser
DEBUG - 2017-09-05 03:26:43 --> Total execution time: 0.0570
ERROR - 2017-09-05 03:26:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:26:46 --> Config Class Initialized
INFO - 2017-09-05 03:26:46 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:26:46 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:26:46 --> Utf8 Class Initialized
INFO - 2017-09-05 03:26:46 --> URI Class Initialized
DEBUG - 2017-09-05 03:26:46 --> No URI present. Default controller set.
INFO - 2017-09-05 03:26:46 --> Router Class Initialized
INFO - 2017-09-05 03:26:46 --> Output Class Initialized
INFO - 2017-09-05 03:26:46 --> Security Class Initialized
DEBUG - 2017-09-05 03:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:26:46 --> Input Class Initialized
INFO - 2017-09-05 03:26:46 --> Language Class Initialized
INFO - 2017-09-05 03:26:46 --> Loader Class Initialized
INFO - 2017-09-05 03:26:46 --> Controller Class Initialized
INFO - 2017-09-05 03:26:46 --> Database Driver Class Initialized
INFO - 2017-09-05 03:26:46 --> Model Class Initialized
INFO - 2017-09-05 03:26:46 --> Helper loaded: form_helper
INFO - 2017-09-05 03:26:46 --> Helper loaded: url_helper
INFO - 2017-09-05 03:26:46 --> File loaded: C:\xampp\htdocs\biper\application\views\login.php
INFO - 2017-09-05 03:26:46 --> Final output sent to browser
DEBUG - 2017-09-05 03:26:46 --> Total execution time: 0.0630
ERROR - 2017-09-05 03:27:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:27:33 --> Config Class Initialized
INFO - 2017-09-05 03:27:33 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:27:33 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:27:33 --> Utf8 Class Initialized
INFO - 2017-09-05 03:27:33 --> URI Class Initialized
DEBUG - 2017-09-05 03:27:33 --> No URI present. Default controller set.
INFO - 2017-09-05 03:27:33 --> Router Class Initialized
INFO - 2017-09-05 03:27:33 --> Output Class Initialized
INFO - 2017-09-05 03:27:33 --> Security Class Initialized
DEBUG - 2017-09-05 03:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:27:33 --> Input Class Initialized
INFO - 2017-09-05 03:27:33 --> Language Class Initialized
INFO - 2017-09-05 03:27:33 --> Loader Class Initialized
INFO - 2017-09-05 03:27:33 --> Controller Class Initialized
INFO - 2017-09-05 03:27:33 --> Database Driver Class Initialized
INFO - 2017-09-05 03:27:33 --> Model Class Initialized
INFO - 2017-09-05 03:27:33 --> Helper loaded: form_helper
INFO - 2017-09-05 03:27:33 --> Helper loaded: url_helper
INFO - 2017-09-05 03:27:33 --> File loaded: C:\xampp\htdocs\biper\application\views\login.php
INFO - 2017-09-05 03:27:33 --> Final output sent to browser
DEBUG - 2017-09-05 03:27:33 --> Total execution time: 0.0530
ERROR - 2017-09-05 03:29:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:29:01 --> Config Class Initialized
INFO - 2017-09-05 03:29:01 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:29:01 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:29:01 --> Utf8 Class Initialized
INFO - 2017-09-05 03:29:01 --> URI Class Initialized
DEBUG - 2017-09-05 03:29:01 --> No URI present. Default controller set.
INFO - 2017-09-05 03:29:01 --> Router Class Initialized
INFO - 2017-09-05 03:29:01 --> Output Class Initialized
INFO - 2017-09-05 03:29:01 --> Security Class Initialized
DEBUG - 2017-09-05 03:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:29:01 --> Input Class Initialized
INFO - 2017-09-05 03:29:01 --> Language Class Initialized
INFO - 2017-09-05 03:29:01 --> Loader Class Initialized
INFO - 2017-09-05 03:29:01 --> Controller Class Initialized
INFO - 2017-09-05 03:29:01 --> Database Driver Class Initialized
INFO - 2017-09-05 03:29:01 --> Model Class Initialized
INFO - 2017-09-05 03:29:01 --> Helper loaded: form_helper
INFO - 2017-09-05 03:29:01 --> Helper loaded: url_helper
INFO - 2017-09-05 03:29:01 --> File loaded: C:\xampp\htdocs\biper\application\views\login.php
INFO - 2017-09-05 03:29:01 --> Final output sent to browser
DEBUG - 2017-09-05 03:29:01 --> Total execution time: 0.0520
ERROR - 2017-09-05 03:32:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:32:20 --> Config Class Initialized
INFO - 2017-09-05 03:32:20 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:32:20 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:32:20 --> Utf8 Class Initialized
INFO - 2017-09-05 03:32:20 --> URI Class Initialized
DEBUG - 2017-09-05 03:32:20 --> No URI present. Default controller set.
INFO - 2017-09-05 03:32:20 --> Router Class Initialized
INFO - 2017-09-05 03:32:20 --> Output Class Initialized
INFO - 2017-09-05 03:32:20 --> Security Class Initialized
DEBUG - 2017-09-05 03:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:32:20 --> Input Class Initialized
INFO - 2017-09-05 03:32:20 --> Language Class Initialized
INFO - 2017-09-05 03:32:20 --> Loader Class Initialized
INFO - 2017-09-05 03:32:20 --> Controller Class Initialized
INFO - 2017-09-05 03:32:20 --> Database Driver Class Initialized
INFO - 2017-09-05 03:32:20 --> Model Class Initialized
INFO - 2017-09-05 03:32:20 --> Helper loaded: form_helper
INFO - 2017-09-05 03:32:20 --> Helper loaded: url_helper
INFO - 2017-09-05 03:32:20 --> File loaded: C:\xampp\htdocs\biper\application\views\login.php
INFO - 2017-09-05 03:32:20 --> Final output sent to browser
DEBUG - 2017-09-05 03:32:20 --> Total execution time: 0.0790
ERROR - 2017-09-05 03:32:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:32:40 --> Config Class Initialized
INFO - 2017-09-05 03:32:40 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:32:40 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:32:40 --> Utf8 Class Initialized
INFO - 2017-09-05 03:32:40 --> URI Class Initialized
DEBUG - 2017-09-05 03:32:40 --> No URI present. Default controller set.
INFO - 2017-09-05 03:32:41 --> Router Class Initialized
INFO - 2017-09-05 03:32:41 --> Output Class Initialized
INFO - 2017-09-05 03:32:41 --> Security Class Initialized
DEBUG - 2017-09-05 03:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:32:41 --> Input Class Initialized
INFO - 2017-09-05 03:32:41 --> Language Class Initialized
INFO - 2017-09-05 03:32:41 --> Loader Class Initialized
INFO - 2017-09-05 03:32:41 --> Controller Class Initialized
INFO - 2017-09-05 03:32:41 --> Database Driver Class Initialized
INFO - 2017-09-05 03:32:41 --> Model Class Initialized
INFO - 2017-09-05 03:32:41 --> Helper loaded: form_helper
INFO - 2017-09-05 03:32:41 --> Helper loaded: url_helper
INFO - 2017-09-05 03:32:41 --> File loaded: C:\xampp\htdocs\biper\application\views\login.php
INFO - 2017-09-05 03:32:41 --> Final output sent to browser
DEBUG - 2017-09-05 03:32:41 --> Total execution time: 0.0450
ERROR - 2017-09-05 03:33:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:33:25 --> Config Class Initialized
INFO - 2017-09-05 03:33:25 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:33:25 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:33:25 --> Utf8 Class Initialized
INFO - 2017-09-05 03:33:25 --> URI Class Initialized
DEBUG - 2017-09-05 03:33:25 --> No URI present. Default controller set.
INFO - 2017-09-05 03:33:25 --> Router Class Initialized
INFO - 2017-09-05 03:33:25 --> Output Class Initialized
INFO - 2017-09-05 03:33:25 --> Security Class Initialized
DEBUG - 2017-09-05 03:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:33:25 --> Input Class Initialized
INFO - 2017-09-05 03:33:25 --> Language Class Initialized
INFO - 2017-09-05 03:33:25 --> Loader Class Initialized
INFO - 2017-09-05 03:33:25 --> Controller Class Initialized
INFO - 2017-09-05 03:33:25 --> Database Driver Class Initialized
INFO - 2017-09-05 03:33:25 --> Model Class Initialized
INFO - 2017-09-05 03:33:25 --> Helper loaded: form_helper
INFO - 2017-09-05 03:33:25 --> Helper loaded: url_helper
INFO - 2017-09-05 03:33:25 --> File loaded: C:\xampp\htdocs\biper\application\views\login.php
INFO - 2017-09-05 03:33:25 --> Final output sent to browser
DEBUG - 2017-09-05 03:33:25 --> Total execution time: 0.0570
ERROR - 2017-09-05 03:33:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:33:36 --> Config Class Initialized
INFO - 2017-09-05 03:33:36 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:33:36 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:33:36 --> Utf8 Class Initialized
INFO - 2017-09-05 03:33:36 --> URI Class Initialized
DEBUG - 2017-09-05 03:33:36 --> No URI present. Default controller set.
INFO - 2017-09-05 03:33:36 --> Router Class Initialized
INFO - 2017-09-05 03:33:37 --> Output Class Initialized
INFO - 2017-09-05 03:33:37 --> Security Class Initialized
DEBUG - 2017-09-05 03:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:33:37 --> Input Class Initialized
INFO - 2017-09-05 03:33:37 --> Language Class Initialized
INFO - 2017-09-05 03:33:37 --> Loader Class Initialized
INFO - 2017-09-05 03:33:37 --> Controller Class Initialized
INFO - 2017-09-05 03:33:37 --> Database Driver Class Initialized
INFO - 2017-09-05 03:33:37 --> Model Class Initialized
INFO - 2017-09-05 03:33:37 --> Helper loaded: form_helper
INFO - 2017-09-05 03:33:37 --> Helper loaded: url_helper
INFO - 2017-09-05 03:33:37 --> File loaded: C:\xampp\htdocs\biper\application\views\login.php
INFO - 2017-09-05 03:33:37 --> Final output sent to browser
DEBUG - 2017-09-05 03:33:37 --> Total execution time: 0.0910
ERROR - 2017-09-05 03:34:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:34:03 --> Config Class Initialized
INFO - 2017-09-05 03:34:03 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:34:03 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:34:03 --> Utf8 Class Initialized
INFO - 2017-09-05 03:34:03 --> URI Class Initialized
DEBUG - 2017-09-05 03:34:03 --> No URI present. Default controller set.
INFO - 2017-09-05 03:34:03 --> Router Class Initialized
INFO - 2017-09-05 03:34:03 --> Output Class Initialized
INFO - 2017-09-05 03:34:03 --> Security Class Initialized
DEBUG - 2017-09-05 03:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:34:03 --> Input Class Initialized
INFO - 2017-09-05 03:34:03 --> Language Class Initialized
INFO - 2017-09-05 03:34:03 --> Loader Class Initialized
INFO - 2017-09-05 03:34:03 --> Controller Class Initialized
INFO - 2017-09-05 03:34:03 --> Database Driver Class Initialized
INFO - 2017-09-05 03:34:03 --> Model Class Initialized
INFO - 2017-09-05 03:34:03 --> Helper loaded: form_helper
INFO - 2017-09-05 03:34:03 --> Helper loaded: url_helper
INFO - 2017-09-05 03:34:03 --> File loaded: C:\xampp\htdocs\biper\application\views\login.php
INFO - 2017-09-05 03:34:03 --> Final output sent to browser
DEBUG - 2017-09-05 03:34:03 --> Total execution time: 0.0800
ERROR - 2017-09-05 03:34:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:34:20 --> Config Class Initialized
INFO - 2017-09-05 03:34:20 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:34:20 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:34:20 --> Utf8 Class Initialized
INFO - 2017-09-05 03:34:20 --> URI Class Initialized
DEBUG - 2017-09-05 03:34:20 --> No URI present. Default controller set.
INFO - 2017-09-05 03:34:20 --> Router Class Initialized
INFO - 2017-09-05 03:34:20 --> Output Class Initialized
INFO - 2017-09-05 03:34:20 --> Security Class Initialized
DEBUG - 2017-09-05 03:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:34:20 --> Input Class Initialized
INFO - 2017-09-05 03:34:20 --> Language Class Initialized
INFO - 2017-09-05 03:34:20 --> Loader Class Initialized
INFO - 2017-09-05 03:34:20 --> Controller Class Initialized
INFO - 2017-09-05 03:34:20 --> Database Driver Class Initialized
INFO - 2017-09-05 03:34:20 --> Model Class Initialized
INFO - 2017-09-05 03:34:20 --> Helper loaded: form_helper
INFO - 2017-09-05 03:34:20 --> Helper loaded: url_helper
INFO - 2017-09-05 03:34:20 --> File loaded: C:\xampp\htdocs\biper\application\views\login.php
INFO - 2017-09-05 03:34:20 --> Final output sent to browser
DEBUG - 2017-09-05 03:34:20 --> Total execution time: 0.0510
ERROR - 2017-09-05 03:34:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:34:35 --> Config Class Initialized
INFO - 2017-09-05 03:34:35 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:34:35 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:34:35 --> Utf8 Class Initialized
INFO - 2017-09-05 03:34:35 --> URI Class Initialized
DEBUG - 2017-09-05 03:34:35 --> No URI present. Default controller set.
INFO - 2017-09-05 03:34:35 --> Router Class Initialized
INFO - 2017-09-05 03:34:35 --> Output Class Initialized
INFO - 2017-09-05 03:34:35 --> Security Class Initialized
DEBUG - 2017-09-05 03:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:34:35 --> Input Class Initialized
INFO - 2017-09-05 03:34:35 --> Language Class Initialized
INFO - 2017-09-05 03:34:35 --> Loader Class Initialized
INFO - 2017-09-05 03:34:35 --> Controller Class Initialized
INFO - 2017-09-05 03:34:35 --> Database Driver Class Initialized
INFO - 2017-09-05 03:34:35 --> Model Class Initialized
INFO - 2017-09-05 03:34:35 --> Helper loaded: form_helper
INFO - 2017-09-05 03:34:35 --> Helper loaded: url_helper
INFO - 2017-09-05 03:34:35 --> File loaded: C:\xampp\htdocs\biper\application\views\login.php
INFO - 2017-09-05 03:34:35 --> Final output sent to browser
DEBUG - 2017-09-05 03:34:35 --> Total execution time: 0.0530
ERROR - 2017-09-05 03:34:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:34:48 --> Config Class Initialized
INFO - 2017-09-05 03:34:48 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:34:48 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:34:48 --> Utf8 Class Initialized
INFO - 2017-09-05 03:34:48 --> URI Class Initialized
DEBUG - 2017-09-05 03:34:48 --> No URI present. Default controller set.
INFO - 2017-09-05 03:34:48 --> Router Class Initialized
INFO - 2017-09-05 03:34:48 --> Output Class Initialized
INFO - 2017-09-05 03:34:48 --> Security Class Initialized
DEBUG - 2017-09-05 03:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:34:48 --> Input Class Initialized
INFO - 2017-09-05 03:34:48 --> Language Class Initialized
INFO - 2017-09-05 03:34:48 --> Loader Class Initialized
INFO - 2017-09-05 03:34:48 --> Controller Class Initialized
INFO - 2017-09-05 03:34:48 --> Database Driver Class Initialized
INFO - 2017-09-05 03:34:48 --> Model Class Initialized
INFO - 2017-09-05 03:34:48 --> Helper loaded: form_helper
INFO - 2017-09-05 03:34:48 --> Helper loaded: url_helper
INFO - 2017-09-05 03:34:48 --> File loaded: C:\xampp\htdocs\biper\application\views\login.php
INFO - 2017-09-05 03:34:48 --> Final output sent to browser
DEBUG - 2017-09-05 03:34:48 --> Total execution time: 0.1010
ERROR - 2017-09-05 03:34:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:34:59 --> Config Class Initialized
INFO - 2017-09-05 03:34:59 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:34:59 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:34:59 --> Utf8 Class Initialized
INFO - 2017-09-05 03:34:59 --> URI Class Initialized
INFO - 2017-09-05 03:34:59 --> Router Class Initialized
INFO - 2017-09-05 03:34:59 --> Output Class Initialized
INFO - 2017-09-05 03:34:59 --> Security Class Initialized
DEBUG - 2017-09-05 03:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:34:59 --> Input Class Initialized
INFO - 2017-09-05 03:34:59 --> Language Class Initialized
INFO - 2017-09-05 03:34:59 --> Loader Class Initialized
INFO - 2017-09-05 03:34:59 --> Controller Class Initialized
INFO - 2017-09-05 03:34:59 --> Database Driver Class Initialized
INFO - 2017-09-05 03:34:59 --> Model Class Initialized
INFO - 2017-09-05 03:34:59 --> Helper loaded: form_helper
INFO - 2017-09-05 03:34:59 --> Helper loaded: url_helper
INFO - 2017-09-05 03:34:59 --> Model Class Initialized
ERROR - 2017-09-05 03:34:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:34:59 --> Config Class Initialized
INFO - 2017-09-05 03:34:59 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:34:59 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:34:59 --> Utf8 Class Initialized
INFO - 2017-09-05 03:34:59 --> URI Class Initialized
INFO - 2017-09-05 03:34:59 --> Router Class Initialized
INFO - 2017-09-05 03:34:59 --> Output Class Initialized
INFO - 2017-09-05 03:34:59 --> Security Class Initialized
DEBUG - 2017-09-05 03:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:34:59 --> Input Class Initialized
INFO - 2017-09-05 03:34:59 --> Language Class Initialized
INFO - 2017-09-05 03:34:59 --> Loader Class Initialized
INFO - 2017-09-05 03:34:59 --> Controller Class Initialized
INFO - 2017-09-05 03:34:59 --> Database Driver Class Initialized
INFO - 2017-09-05 03:34:59 --> Model Class Initialized
INFO - 2017-09-05 03:34:59 --> Helper loaded: form_helper
INFO - 2017-09-05 03:34:59 --> Helper loaded: url_helper
INFO - 2017-09-05 03:34:59 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 03:34:59 --> Model Class Initialized
INFO - 2017-09-05 03:34:59 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-05 03:34:59 --> Final output sent to browser
DEBUG - 2017-09-05 03:34:59 --> Total execution time: 0.0670
ERROR - 2017-09-05 03:37:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:37:46 --> Config Class Initialized
INFO - 2017-09-05 03:37:46 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:37:46 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:37:46 --> Utf8 Class Initialized
INFO - 2017-09-05 03:37:46 --> URI Class Initialized
INFO - 2017-09-05 03:37:46 --> Router Class Initialized
INFO - 2017-09-05 03:37:46 --> Output Class Initialized
INFO - 2017-09-05 03:37:46 --> Security Class Initialized
DEBUG - 2017-09-05 03:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:37:46 --> Input Class Initialized
INFO - 2017-09-05 03:37:46 --> Language Class Initialized
INFO - 2017-09-05 03:37:46 --> Loader Class Initialized
INFO - 2017-09-05 03:37:46 --> Controller Class Initialized
INFO - 2017-09-05 03:37:46 --> Database Driver Class Initialized
INFO - 2017-09-05 03:37:46 --> Model Class Initialized
INFO - 2017-09-05 03:37:46 --> Helper loaded: form_helper
INFO - 2017-09-05 03:37:46 --> Helper loaded: url_helper
ERROR - 2017-09-05 03:37:46 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\biper\application\views\header.php 82
ERROR - 2017-09-05 03:37:46 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\biper\application\views\header.php 83
INFO - 2017-09-05 03:37:46 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 03:37:46 --> Model Class Initialized
INFO - 2017-09-05 03:37:46 --> File loaded: C:\xampp\htdocs\biper\application\views\users.php
INFO - 2017-09-05 03:37:46 --> Final output sent to browser
DEBUG - 2017-09-05 03:37:46 --> Total execution time: 0.0760
ERROR - 2017-09-05 03:37:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:37:46 --> Config Class Initialized
INFO - 2017-09-05 03:37:46 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:37:46 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:37:46 --> Utf8 Class Initialized
ERROR - 2017-09-05 03:37:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:37:54 --> Config Class Initialized
INFO - 2017-09-05 03:37:54 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:37:54 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:37:54 --> Utf8 Class Initialized
INFO - 2017-09-05 03:37:54 --> URI Class Initialized
INFO - 2017-09-05 03:37:54 --> Router Class Initialized
INFO - 2017-09-05 03:37:54 --> Output Class Initialized
INFO - 2017-09-05 03:37:54 --> Security Class Initialized
DEBUG - 2017-09-05 03:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:37:54 --> Input Class Initialized
INFO - 2017-09-05 03:37:54 --> Language Class Initialized
INFO - 2017-09-05 03:37:54 --> Loader Class Initialized
INFO - 2017-09-05 03:37:54 --> Controller Class Initialized
INFO - 2017-09-05 03:37:54 --> Database Driver Class Initialized
INFO - 2017-09-05 03:37:54 --> Model Class Initialized
INFO - 2017-09-05 03:37:54 --> Helper loaded: form_helper
INFO - 2017-09-05 03:37:54 --> Helper loaded: url_helper
ERROR - 2017-09-05 03:37:54 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\biper\application\views\header.php 82
ERROR - 2017-09-05 03:37:54 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\biper\application\views\header.php 83
INFO - 2017-09-05 03:37:54 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 03:37:54 --> Model Class Initialized
INFO - 2017-09-05 03:37:54 --> File loaded: C:\xampp\htdocs\biper\application\views\songs.php
INFO - 2017-09-05 03:37:54 --> Final output sent to browser
DEBUG - 2017-09-05 03:37:54 --> Total execution time: 0.0660
ERROR - 2017-09-05 03:37:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:37:54 --> Config Class Initialized
INFO - 2017-09-05 03:37:54 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:37:54 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:37:54 --> Utf8 Class Initialized
ERROR - 2017-09-05 03:37:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:37:58 --> Config Class Initialized
INFO - 2017-09-05 03:37:58 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:37:58 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:37:58 --> Utf8 Class Initialized
INFO - 2017-09-05 03:37:58 --> URI Class Initialized
INFO - 2017-09-05 03:37:58 --> Router Class Initialized
INFO - 2017-09-05 03:37:58 --> Output Class Initialized
INFO - 2017-09-05 03:37:58 --> Security Class Initialized
DEBUG - 2017-09-05 03:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:37:58 --> Input Class Initialized
INFO - 2017-09-05 03:37:58 --> Language Class Initialized
INFO - 2017-09-05 03:37:58 --> Loader Class Initialized
INFO - 2017-09-05 03:37:58 --> Controller Class Initialized
INFO - 2017-09-05 03:37:58 --> Database Driver Class Initialized
INFO - 2017-09-05 03:37:58 --> Model Class Initialized
INFO - 2017-09-05 03:37:58 --> Helper loaded: form_helper
INFO - 2017-09-05 03:37:58 --> Helper loaded: url_helper
ERROR - 2017-09-05 03:37:58 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\biper\application\views\header.php 82
ERROR - 2017-09-05 03:37:58 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\biper\application\views\header.php 83
INFO - 2017-09-05 03:37:58 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 03:37:58 --> Model Class Initialized
INFO - 2017-09-05 03:37:58 --> File loaded: C:\xampp\htdocs\biper\application\views\users.php
INFO - 2017-09-05 03:37:58 --> Final output sent to browser
DEBUG - 2017-09-05 03:37:58 --> Total execution time: 0.1020
ERROR - 2017-09-05 03:37:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:37:58 --> Config Class Initialized
INFO - 2017-09-05 03:37:58 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:37:58 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:37:58 --> Utf8 Class Initialized
ERROR - 2017-09-05 03:41:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:41:19 --> Config Class Initialized
INFO - 2017-09-05 03:41:19 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:41:19 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:41:19 --> Utf8 Class Initialized
INFO - 2017-09-05 03:41:19 --> URI Class Initialized
DEBUG - 2017-09-05 03:41:19 --> No URI present. Default controller set.
INFO - 2017-09-05 03:41:19 --> Router Class Initialized
INFO - 2017-09-05 03:41:19 --> Output Class Initialized
INFO - 2017-09-05 03:41:19 --> Security Class Initialized
DEBUG - 2017-09-05 03:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:41:19 --> Input Class Initialized
INFO - 2017-09-05 03:41:19 --> Language Class Initialized
INFO - 2017-09-05 03:41:19 --> Loader Class Initialized
INFO - 2017-09-05 03:41:19 --> Controller Class Initialized
INFO - 2017-09-05 03:41:19 --> Database Driver Class Initialized
INFO - 2017-09-05 03:41:19 --> Model Class Initialized
INFO - 2017-09-05 03:41:19 --> Helper loaded: form_helper
INFO - 2017-09-05 03:41:19 --> Helper loaded: url_helper
INFO - 2017-09-05 03:41:19 --> File loaded: C:\xampp\htdocs\biper\application\views\login.php
INFO - 2017-09-05 03:41:19 --> Final output sent to browser
DEBUG - 2017-09-05 03:41:19 --> Total execution time: 0.0610
ERROR - 2017-09-05 03:41:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:41:21 --> Config Class Initialized
INFO - 2017-09-05 03:41:21 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:41:21 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:41:21 --> Utf8 Class Initialized
INFO - 2017-09-05 03:41:21 --> URI Class Initialized
INFO - 2017-09-05 03:41:21 --> Router Class Initialized
INFO - 2017-09-05 03:41:21 --> Output Class Initialized
INFO - 2017-09-05 03:41:21 --> Security Class Initialized
DEBUG - 2017-09-05 03:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:41:21 --> Input Class Initialized
INFO - 2017-09-05 03:41:21 --> Language Class Initialized
INFO - 2017-09-05 03:41:21 --> Loader Class Initialized
INFO - 2017-09-05 03:41:21 --> Controller Class Initialized
INFO - 2017-09-05 03:41:21 --> Database Driver Class Initialized
INFO - 2017-09-05 03:41:21 --> Model Class Initialized
INFO - 2017-09-05 03:41:21 --> Helper loaded: form_helper
INFO - 2017-09-05 03:41:21 --> Helper loaded: url_helper
INFO - 2017-09-05 03:41:21 --> Model Class Initialized
ERROR - 2017-09-05 03:41:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:41:21 --> Config Class Initialized
INFO - 2017-09-05 03:41:21 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:41:21 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:41:21 --> Utf8 Class Initialized
INFO - 2017-09-05 03:41:21 --> URI Class Initialized
INFO - 2017-09-05 03:41:21 --> Router Class Initialized
INFO - 2017-09-05 03:41:21 --> Output Class Initialized
INFO - 2017-09-05 03:41:21 --> Security Class Initialized
DEBUG - 2017-09-05 03:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:41:21 --> Input Class Initialized
INFO - 2017-09-05 03:41:21 --> Language Class Initialized
INFO - 2017-09-05 03:41:21 --> Loader Class Initialized
INFO - 2017-09-05 03:41:21 --> Controller Class Initialized
INFO - 2017-09-05 03:41:21 --> Database Driver Class Initialized
INFO - 2017-09-05 03:41:21 --> Model Class Initialized
INFO - 2017-09-05 03:41:21 --> Helper loaded: form_helper
INFO - 2017-09-05 03:41:21 --> Helper loaded: url_helper
INFO - 2017-09-05 03:41:21 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 03:41:21 --> Model Class Initialized
INFO - 2017-09-05 03:41:21 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-05 03:41:21 --> Final output sent to browser
DEBUG - 2017-09-05 03:41:21 --> Total execution time: 0.0740
ERROR - 2017-09-05 03:45:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:45:54 --> Config Class Initialized
INFO - 2017-09-05 03:45:54 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:45:54 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:45:54 --> Utf8 Class Initialized
INFO - 2017-09-05 03:45:54 --> URI Class Initialized
INFO - 2017-09-05 03:45:54 --> Router Class Initialized
INFO - 2017-09-05 03:45:54 --> Output Class Initialized
INFO - 2017-09-05 03:45:54 --> Security Class Initialized
DEBUG - 2017-09-05 03:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:45:54 --> Input Class Initialized
INFO - 2017-09-05 03:45:54 --> Language Class Initialized
INFO - 2017-09-05 03:45:54 --> Loader Class Initialized
INFO - 2017-09-05 03:45:54 --> Controller Class Initialized
INFO - 2017-09-05 03:45:54 --> Database Driver Class Initialized
INFO - 2017-09-05 03:45:54 --> Model Class Initialized
INFO - 2017-09-05 03:45:54 --> Helper loaded: form_helper
INFO - 2017-09-05 03:45:54 --> Helper loaded: url_helper
INFO - 2017-09-05 03:45:54 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 03:45:54 --> Model Class Initialized
INFO - 2017-09-05 03:45:54 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-05 03:45:54 --> Final output sent to browser
DEBUG - 2017-09-05 03:45:54 --> Total execution time: 0.0720
ERROR - 2017-09-05 03:45:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:45:56 --> Config Class Initialized
INFO - 2017-09-05 03:45:56 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:45:56 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:45:56 --> Utf8 Class Initialized
INFO - 2017-09-05 03:45:57 --> URI Class Initialized
INFO - 2017-09-05 03:45:57 --> Router Class Initialized
INFO - 2017-09-05 03:45:57 --> Output Class Initialized
INFO - 2017-09-05 03:45:57 --> Security Class Initialized
DEBUG - 2017-09-05 03:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:45:57 --> Input Class Initialized
INFO - 2017-09-05 03:45:57 --> Language Class Initialized
ERROR - 2017-09-05 03:45:57 --> 404 Page Not Found: Services/go_videos
ERROR - 2017-09-05 03:45:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:45:58 --> Config Class Initialized
INFO - 2017-09-05 03:45:58 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:45:58 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:45:58 --> Utf8 Class Initialized
INFO - 2017-09-05 03:45:58 --> URI Class Initialized
INFO - 2017-09-05 03:45:58 --> Router Class Initialized
INFO - 2017-09-05 03:45:58 --> Output Class Initialized
INFO - 2017-09-05 03:45:58 --> Security Class Initialized
DEBUG - 2017-09-05 03:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:45:58 --> Input Class Initialized
INFO - 2017-09-05 03:45:58 --> Language Class Initialized
INFO - 2017-09-05 03:45:58 --> Loader Class Initialized
INFO - 2017-09-05 03:45:58 --> Controller Class Initialized
INFO - 2017-09-05 03:45:58 --> Database Driver Class Initialized
INFO - 2017-09-05 03:45:58 --> Model Class Initialized
INFO - 2017-09-05 03:45:58 --> Helper loaded: form_helper
INFO - 2017-09-05 03:45:58 --> Helper loaded: url_helper
INFO - 2017-09-05 03:45:58 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 03:45:58 --> Model Class Initialized
INFO - 2017-09-05 03:45:58 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-05 03:45:58 --> Final output sent to browser
DEBUG - 2017-09-05 03:45:58 --> Total execution time: 0.0850
ERROR - 2017-09-05 03:47:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:47:11 --> Config Class Initialized
INFO - 2017-09-05 03:47:11 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:47:11 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:47:11 --> Utf8 Class Initialized
INFO - 2017-09-05 03:47:11 --> URI Class Initialized
INFO - 2017-09-05 03:47:11 --> Router Class Initialized
INFO - 2017-09-05 03:47:11 --> Output Class Initialized
INFO - 2017-09-05 03:47:11 --> Security Class Initialized
DEBUG - 2017-09-05 03:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:47:11 --> Input Class Initialized
INFO - 2017-09-05 03:47:11 --> Language Class Initialized
INFO - 2017-09-05 03:47:11 --> Loader Class Initialized
INFO - 2017-09-05 03:47:11 --> Controller Class Initialized
INFO - 2017-09-05 03:47:11 --> Database Driver Class Initialized
INFO - 2017-09-05 03:47:11 --> Model Class Initialized
INFO - 2017-09-05 03:47:11 --> Helper loaded: form_helper
INFO - 2017-09-05 03:47:11 --> Helper loaded: url_helper
INFO - 2017-09-05 03:47:11 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 03:47:11 --> Model Class Initialized
INFO - 2017-09-05 03:47:11 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-05 03:47:11 --> Final output sent to browser
DEBUG - 2017-09-05 03:47:11 --> Total execution time: 0.0620
ERROR - 2017-09-05 03:48:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:48:20 --> Config Class Initialized
INFO - 2017-09-05 03:48:20 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:48:20 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:48:20 --> Utf8 Class Initialized
INFO - 2017-09-05 03:48:20 --> URI Class Initialized
INFO - 2017-09-05 03:48:20 --> Router Class Initialized
INFO - 2017-09-05 03:48:20 --> Output Class Initialized
INFO - 2017-09-05 03:48:20 --> Security Class Initialized
DEBUG - 2017-09-05 03:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:48:20 --> Input Class Initialized
INFO - 2017-09-05 03:48:20 --> Language Class Initialized
INFO - 2017-09-05 03:48:20 --> Loader Class Initialized
INFO - 2017-09-05 03:48:20 --> Controller Class Initialized
INFO - 2017-09-05 03:48:20 --> Database Driver Class Initialized
INFO - 2017-09-05 03:48:20 --> Model Class Initialized
INFO - 2017-09-05 03:48:20 --> Helper loaded: form_helper
INFO - 2017-09-05 03:48:20 --> Helper loaded: url_helper
INFO - 2017-09-05 03:48:20 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 03:48:20 --> Model Class Initialized
ERROR - 2017-09-05 03:48:20 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 50
ERROR - 2017-09-05 03:48:20 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 56
ERROR - 2017-09-05 03:48:20 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 63
ERROR - 2017-09-05 03:48:20 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 70
INFO - 2017-09-05 03:48:20 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-05 03:48:20 --> Final output sent to browser
DEBUG - 2017-09-05 03:48:20 --> Total execution time: 0.0740
ERROR - 2017-09-05 03:48:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:48:44 --> Config Class Initialized
INFO - 2017-09-05 03:48:44 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:48:44 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:48:44 --> Utf8 Class Initialized
INFO - 2017-09-05 03:48:44 --> URI Class Initialized
INFO - 2017-09-05 03:48:44 --> Router Class Initialized
INFO - 2017-09-05 03:48:44 --> Output Class Initialized
INFO - 2017-09-05 03:48:44 --> Security Class Initialized
DEBUG - 2017-09-05 03:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:48:44 --> Input Class Initialized
INFO - 2017-09-05 03:48:44 --> Language Class Initialized
INFO - 2017-09-05 03:48:44 --> Loader Class Initialized
INFO - 2017-09-05 03:48:44 --> Controller Class Initialized
INFO - 2017-09-05 03:48:44 --> Database Driver Class Initialized
INFO - 2017-09-05 03:48:44 --> Model Class Initialized
INFO - 2017-09-05 03:48:44 --> Helper loaded: form_helper
INFO - 2017-09-05 03:48:44 --> Helper loaded: url_helper
INFO - 2017-09-05 03:48:44 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 03:48:44 --> Model Class Initialized
ERROR - 2017-09-05 03:48:44 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 50
ERROR - 2017-09-05 03:48:44 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 56
ERROR - 2017-09-05 03:48:44 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 63
ERROR - 2017-09-05 03:48:44 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 70
INFO - 2017-09-05 03:48:44 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-05 03:48:44 --> Final output sent to browser
DEBUG - 2017-09-05 03:48:44 --> Total execution time: 0.0730
ERROR - 2017-09-05 03:49:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:49:00 --> Config Class Initialized
INFO - 2017-09-05 03:49:00 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:49:00 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:49:00 --> Utf8 Class Initialized
INFO - 2017-09-05 03:49:00 --> URI Class Initialized
INFO - 2017-09-05 03:49:00 --> Router Class Initialized
INFO - 2017-09-05 03:49:00 --> Output Class Initialized
INFO - 2017-09-05 03:49:00 --> Security Class Initialized
DEBUG - 2017-09-05 03:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:49:00 --> Input Class Initialized
INFO - 2017-09-05 03:49:00 --> Language Class Initialized
INFO - 2017-09-05 03:49:00 --> Loader Class Initialized
INFO - 2017-09-05 03:49:00 --> Controller Class Initialized
INFO - 2017-09-05 03:49:00 --> Database Driver Class Initialized
INFO - 2017-09-05 03:49:00 --> Model Class Initialized
INFO - 2017-09-05 03:49:00 --> Helper loaded: form_helper
INFO - 2017-09-05 03:49:00 --> Helper loaded: url_helper
INFO - 2017-09-05 03:49:00 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 03:49:00 --> Model Class Initialized
ERROR - 2017-09-05 03:49:01 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 50
ERROR - 2017-09-05 03:49:01 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 56
ERROR - 2017-09-05 03:49:01 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 63
ERROR - 2017-09-05 03:49:01 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 70
INFO - 2017-09-05 03:49:01 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-05 03:49:01 --> Final output sent to browser
DEBUG - 2017-09-05 03:49:01 --> Total execution time: 0.0740
ERROR - 2017-09-05 03:50:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:50:41 --> Config Class Initialized
INFO - 2017-09-05 03:50:41 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:50:41 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:50:41 --> Utf8 Class Initialized
INFO - 2017-09-05 03:50:41 --> URI Class Initialized
INFO - 2017-09-05 03:50:41 --> Router Class Initialized
INFO - 2017-09-05 03:50:41 --> Output Class Initialized
INFO - 2017-09-05 03:50:41 --> Security Class Initialized
DEBUG - 2017-09-05 03:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:50:41 --> Input Class Initialized
INFO - 2017-09-05 03:50:41 --> Language Class Initialized
INFO - 2017-09-05 03:50:41 --> Loader Class Initialized
INFO - 2017-09-05 03:50:41 --> Controller Class Initialized
INFO - 2017-09-05 03:50:41 --> Database Driver Class Initialized
INFO - 2017-09-05 03:50:41 --> Model Class Initialized
INFO - 2017-09-05 03:50:41 --> Helper loaded: form_helper
INFO - 2017-09-05 03:50:41 --> Helper loaded: url_helper
INFO - 2017-09-05 03:50:41 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 03:50:41 --> Model Class Initialized
ERROR - 2017-09-05 03:50:41 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 50
ERROR - 2017-09-05 03:50:41 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 56
ERROR - 2017-09-05 03:50:41 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 63
ERROR - 2017-09-05 03:50:41 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 70
ERROR - 2017-09-05 03:50:41 --> Severity: Notice --> Undefined variable: chart_video C:\xampp\htdocs\biper\application\views\dashboard.php 128
ERROR - 2017-09-05 03:50:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\biper\application\views\dashboard.php 128
INFO - 2017-09-05 03:50:41 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-05 03:50:41 --> Final output sent to browser
DEBUG - 2017-09-05 03:50:41 --> Total execution time: 0.1040
ERROR - 2017-09-05 03:52:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:52:03 --> Config Class Initialized
INFO - 2017-09-05 03:52:03 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:52:03 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:52:03 --> Utf8 Class Initialized
INFO - 2017-09-05 03:52:03 --> URI Class Initialized
INFO - 2017-09-05 03:52:03 --> Router Class Initialized
INFO - 2017-09-05 03:52:03 --> Output Class Initialized
INFO - 2017-09-05 03:52:03 --> Security Class Initialized
DEBUG - 2017-09-05 03:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:52:03 --> Input Class Initialized
INFO - 2017-09-05 03:52:03 --> Language Class Initialized
ERROR - 2017-09-05 03:52:03 --> 404 Page Not Found: Services/go_videos
ERROR - 2017-09-05 03:52:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:52:04 --> Config Class Initialized
INFO - 2017-09-05 03:52:04 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:52:04 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:52:04 --> Utf8 Class Initialized
INFO - 2017-09-05 03:52:04 --> URI Class Initialized
INFO - 2017-09-05 03:52:04 --> Router Class Initialized
INFO - 2017-09-05 03:52:04 --> Output Class Initialized
INFO - 2017-09-05 03:52:04 --> Security Class Initialized
DEBUG - 2017-09-05 03:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:52:04 --> Input Class Initialized
INFO - 2017-09-05 03:52:04 --> Language Class Initialized
INFO - 2017-09-05 03:52:04 --> Loader Class Initialized
INFO - 2017-09-05 03:52:04 --> Controller Class Initialized
INFO - 2017-09-05 03:52:04 --> Database Driver Class Initialized
INFO - 2017-09-05 03:52:04 --> Model Class Initialized
INFO - 2017-09-05 03:52:04 --> Helper loaded: form_helper
INFO - 2017-09-05 03:52:04 --> Helper loaded: url_helper
INFO - 2017-09-05 03:52:04 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 03:52:04 --> Model Class Initialized
ERROR - 2017-09-05 03:52:04 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 50
ERROR - 2017-09-05 03:52:04 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 56
ERROR - 2017-09-05 03:52:04 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 63
ERROR - 2017-09-05 03:52:04 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 70
ERROR - 2017-09-05 03:52:04 --> Severity: Notice --> Undefined variable: chart_video C:\xampp\htdocs\biper\application\views\dashboard.php 128
ERROR - 2017-09-05 03:52:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\biper\application\views\dashboard.php 128
INFO - 2017-09-05 03:52:04 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-05 03:52:04 --> Final output sent to browser
DEBUG - 2017-09-05 03:52:04 --> Total execution time: 0.0970
ERROR - 2017-09-05 03:52:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:52:05 --> Config Class Initialized
INFO - 2017-09-05 03:52:05 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:52:05 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:52:05 --> Utf8 Class Initialized
INFO - 2017-09-05 03:52:05 --> URI Class Initialized
INFO - 2017-09-05 03:52:05 --> Router Class Initialized
INFO - 2017-09-05 03:52:05 --> Output Class Initialized
INFO - 2017-09-05 03:52:05 --> Security Class Initialized
DEBUG - 2017-09-05 03:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:52:05 --> Input Class Initialized
INFO - 2017-09-05 03:52:05 --> Language Class Initialized
INFO - 2017-09-05 03:52:05 --> Loader Class Initialized
INFO - 2017-09-05 03:52:05 --> Controller Class Initialized
INFO - 2017-09-05 03:52:05 --> Database Driver Class Initialized
INFO - 2017-09-05 03:52:05 --> Model Class Initialized
INFO - 2017-09-05 03:52:05 --> Helper loaded: form_helper
INFO - 2017-09-05 03:52:05 --> Helper loaded: url_helper
INFO - 2017-09-05 03:52:05 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 03:52:05 --> Model Class Initialized
INFO - 2017-09-05 03:52:05 --> File loaded: C:\xampp\htdocs\biper\application\views\purchase.php
INFO - 2017-09-05 03:52:05 --> Final output sent to browser
DEBUG - 2017-09-05 03:52:05 --> Total execution time: 0.0800
ERROR - 2017-09-05 03:52:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 03:52:14 --> Config Class Initialized
INFO - 2017-09-05 03:52:14 --> Hooks Class Initialized
DEBUG - 2017-09-05 03:52:14 --> UTF-8 Support Enabled
INFO - 2017-09-05 03:52:14 --> Utf8 Class Initialized
INFO - 2017-09-05 03:52:14 --> URI Class Initialized
INFO - 2017-09-05 03:52:14 --> Router Class Initialized
INFO - 2017-09-05 03:52:14 --> Output Class Initialized
INFO - 2017-09-05 03:52:14 --> Security Class Initialized
DEBUG - 2017-09-05 03:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 03:52:14 --> Input Class Initialized
INFO - 2017-09-05 03:52:14 --> Language Class Initialized
INFO - 2017-09-05 03:52:14 --> Loader Class Initialized
INFO - 2017-09-05 03:52:14 --> Controller Class Initialized
INFO - 2017-09-05 03:52:14 --> Database Driver Class Initialized
INFO - 2017-09-05 03:52:14 --> Model Class Initialized
INFO - 2017-09-05 03:52:14 --> Helper loaded: form_helper
INFO - 2017-09-05 03:52:14 --> Helper loaded: url_helper
INFO - 2017-09-05 03:52:14 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 03:52:14 --> Model Class Initialized
ERROR - 2017-09-05 03:52:14 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 50
ERROR - 2017-09-05 03:52:14 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 56
ERROR - 2017-09-05 03:52:14 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 63
ERROR - 2017-09-05 03:52:14 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 70
ERROR - 2017-09-05 03:52:14 --> Severity: Notice --> Undefined variable: chart_video C:\xampp\htdocs\biper\application\views\dashboard.php 128
ERROR - 2017-09-05 03:52:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\biper\application\views\dashboard.php 128
INFO - 2017-09-05 03:52:14 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-05 03:52:14 --> Final output sent to browser
DEBUG - 2017-09-05 03:52:14 --> Total execution time: 0.0860
ERROR - 2017-09-05 04:01:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:01:45 --> Config Class Initialized
INFO - 2017-09-05 04:01:45 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:01:45 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:01:45 --> Utf8 Class Initialized
INFO - 2017-09-05 04:01:45 --> URI Class Initialized
INFO - 2017-09-05 04:01:45 --> Router Class Initialized
INFO - 2017-09-05 04:01:45 --> Output Class Initialized
INFO - 2017-09-05 04:01:45 --> Security Class Initialized
DEBUG - 2017-09-05 04:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:01:45 --> Input Class Initialized
INFO - 2017-09-05 04:01:45 --> Language Class Initialized
INFO - 2017-09-05 04:01:45 --> Loader Class Initialized
INFO - 2017-09-05 04:01:45 --> Controller Class Initialized
INFO - 2017-09-05 04:01:45 --> Database Driver Class Initialized
INFO - 2017-09-05 04:01:45 --> Model Class Initialized
INFO - 2017-09-05 04:01:45 --> Helper loaded: form_helper
INFO - 2017-09-05 04:01:45 --> Helper loaded: url_helper
INFO - 2017-09-05 04:01:45 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:01:45 --> Model Class Initialized
ERROR - 2017-09-05 04:01:45 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 50
ERROR - 2017-09-05 04:01:45 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 56
ERROR - 2017-09-05 04:01:45 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 63
ERROR - 2017-09-05 04:01:45 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 70
ERROR - 2017-09-05 04:01:45 --> Severity: Notice --> Undefined variable: chart_video C:\xampp\htdocs\biper\application\views\dashboard.php 128
ERROR - 2017-09-05 04:01:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\biper\application\views\dashboard.php 128
INFO - 2017-09-05 04:01:45 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-05 04:01:45 --> Final output sent to browser
DEBUG - 2017-09-05 04:01:45 --> Total execution time: 0.0750
ERROR - 2017-09-05 04:01:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:01:47 --> Config Class Initialized
INFO - 2017-09-05 04:01:47 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:01:47 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:01:47 --> Utf8 Class Initialized
INFO - 2017-09-05 04:01:47 --> URI Class Initialized
INFO - 2017-09-05 04:01:47 --> Router Class Initialized
INFO - 2017-09-05 04:01:47 --> Output Class Initialized
INFO - 2017-09-05 04:01:47 --> Security Class Initialized
DEBUG - 2017-09-05 04:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:01:47 --> Input Class Initialized
INFO - 2017-09-05 04:01:47 --> Language Class Initialized
INFO - 2017-09-05 04:01:47 --> Loader Class Initialized
INFO - 2017-09-05 04:01:47 --> Controller Class Initialized
INFO - 2017-09-05 04:01:47 --> Database Driver Class Initialized
INFO - 2017-09-05 04:01:47 --> Model Class Initialized
INFO - 2017-09-05 04:01:47 --> Helper loaded: form_helper
INFO - 2017-09-05 04:01:47 --> Helper loaded: url_helper
INFO - 2017-09-05 04:01:47 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:01:47 --> Model Class Initialized
ERROR - 2017-09-05 04:01:47 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 50
ERROR - 2017-09-05 04:01:47 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 56
ERROR - 2017-09-05 04:01:47 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 63
ERROR - 2017-09-05 04:01:47 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 70
ERROR - 2017-09-05 04:01:47 --> Severity: Notice --> Undefined variable: chart_video C:\xampp\htdocs\biper\application\views\dashboard.php 128
ERROR - 2017-09-05 04:01:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\biper\application\views\dashboard.php 128
INFO - 2017-09-05 04:01:47 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-05 04:01:47 --> Final output sent to browser
DEBUG - 2017-09-05 04:01:47 --> Total execution time: 0.0650
ERROR - 2017-09-05 04:01:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:01:49 --> Config Class Initialized
INFO - 2017-09-05 04:01:49 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:01:49 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:01:49 --> Utf8 Class Initialized
INFO - 2017-09-05 04:01:49 --> URI Class Initialized
INFO - 2017-09-05 04:01:49 --> Router Class Initialized
INFO - 2017-09-05 04:01:49 --> Output Class Initialized
INFO - 2017-09-05 04:01:49 --> Security Class Initialized
DEBUG - 2017-09-05 04:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:01:49 --> Input Class Initialized
INFO - 2017-09-05 04:01:49 --> Language Class Initialized
INFO - 2017-09-05 04:01:49 --> Loader Class Initialized
INFO - 2017-09-05 04:01:49 --> Controller Class Initialized
INFO - 2017-09-05 04:01:49 --> Database Driver Class Initialized
INFO - 2017-09-05 04:01:49 --> Model Class Initialized
INFO - 2017-09-05 04:01:49 --> Helper loaded: form_helper
INFO - 2017-09-05 04:01:49 --> Helper loaded: url_helper
INFO - 2017-09-05 04:01:49 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:01:49 --> Model Class Initialized
ERROR - 2017-09-05 04:01:49 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 50
ERROR - 2017-09-05 04:01:49 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 56
ERROR - 2017-09-05 04:01:49 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 63
ERROR - 2017-09-05 04:01:49 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 70
ERROR - 2017-09-05 04:01:49 --> Severity: Notice --> Undefined variable: chart_video C:\xampp\htdocs\biper\application\views\dashboard.php 128
ERROR - 2017-09-05 04:01:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\biper\application\views\dashboard.php 128
INFO - 2017-09-05 04:01:49 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-05 04:01:49 --> Final output sent to browser
DEBUG - 2017-09-05 04:01:49 --> Total execution time: 0.0890
ERROR - 2017-09-05 04:02:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:02:30 --> Config Class Initialized
INFO - 2017-09-05 04:02:30 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:02:30 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:02:30 --> Utf8 Class Initialized
INFO - 2017-09-05 04:02:30 --> URI Class Initialized
INFO - 2017-09-05 04:02:30 --> Router Class Initialized
INFO - 2017-09-05 04:02:30 --> Output Class Initialized
INFO - 2017-09-05 04:02:30 --> Security Class Initialized
DEBUG - 2017-09-05 04:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:02:30 --> Input Class Initialized
INFO - 2017-09-05 04:02:30 --> Language Class Initialized
INFO - 2017-09-05 04:02:30 --> Loader Class Initialized
INFO - 2017-09-05 04:02:30 --> Controller Class Initialized
INFO - 2017-09-05 04:02:30 --> Database Driver Class Initialized
INFO - 2017-09-05 04:02:30 --> Model Class Initialized
INFO - 2017-09-05 04:02:30 --> Helper loaded: form_helper
INFO - 2017-09-05 04:02:30 --> Helper loaded: url_helper
INFO - 2017-09-05 04:02:30 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:02:30 --> Model Class Initialized
ERROR - 2017-09-05 04:02:30 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 50
ERROR - 2017-09-05 04:02:30 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 56
ERROR - 2017-09-05 04:02:30 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 63
ERROR - 2017-09-05 04:02:30 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 70
INFO - 2017-09-05 04:02:30 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-05 04:02:30 --> Final output sent to browser
DEBUG - 2017-09-05 04:02:30 --> Total execution time: 0.0620
ERROR - 2017-09-05 04:03:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:03:27 --> Config Class Initialized
INFO - 2017-09-05 04:03:27 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:03:27 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:03:27 --> Utf8 Class Initialized
INFO - 2017-09-05 04:03:27 --> URI Class Initialized
INFO - 2017-09-05 04:03:27 --> Router Class Initialized
INFO - 2017-09-05 04:03:27 --> Output Class Initialized
INFO - 2017-09-05 04:03:27 --> Security Class Initialized
DEBUG - 2017-09-05 04:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:03:27 --> Input Class Initialized
INFO - 2017-09-05 04:03:27 --> Language Class Initialized
INFO - 2017-09-05 04:03:27 --> Loader Class Initialized
INFO - 2017-09-05 04:03:27 --> Controller Class Initialized
INFO - 2017-09-05 04:03:27 --> Database Driver Class Initialized
INFO - 2017-09-05 04:03:27 --> Model Class Initialized
INFO - 2017-09-05 04:03:27 --> Helper loaded: form_helper
INFO - 2017-09-05 04:03:27 --> Helper loaded: url_helper
INFO - 2017-09-05 04:03:27 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:03:27 --> Model Class Initialized
ERROR - 2017-09-05 04:03:27 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 50
ERROR - 2017-09-05 04:03:27 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 56
ERROR - 2017-09-05 04:03:27 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 63
ERROR - 2017-09-05 04:03:27 --> Severity: Notice --> Undefined index: video C:\xampp\htdocs\biper\application\views\dashboard.php 70
INFO - 2017-09-05 04:03:27 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-05 04:03:27 --> Final output sent to browser
DEBUG - 2017-09-05 04:03:27 --> Total execution time: 0.0650
ERROR - 2017-09-05 04:04:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:04:06 --> Config Class Initialized
INFO - 2017-09-05 04:04:06 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:04:06 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:04:06 --> Utf8 Class Initialized
INFO - 2017-09-05 04:04:06 --> URI Class Initialized
INFO - 2017-09-05 04:04:06 --> Router Class Initialized
INFO - 2017-09-05 04:04:06 --> Output Class Initialized
INFO - 2017-09-05 04:04:06 --> Security Class Initialized
DEBUG - 2017-09-05 04:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:04:06 --> Input Class Initialized
INFO - 2017-09-05 04:04:06 --> Language Class Initialized
INFO - 2017-09-05 04:04:06 --> Loader Class Initialized
INFO - 2017-09-05 04:04:06 --> Controller Class Initialized
INFO - 2017-09-05 04:04:06 --> Database Driver Class Initialized
INFO - 2017-09-05 04:04:06 --> Model Class Initialized
INFO - 2017-09-05 04:04:06 --> Helper loaded: form_helper
INFO - 2017-09-05 04:04:06 --> Helper loaded: url_helper
INFO - 2017-09-05 04:04:06 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:04:06 --> Model Class Initialized
INFO - 2017-09-05 04:04:06 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-05 04:04:06 --> Final output sent to browser
DEBUG - 2017-09-05 04:04:06 --> Total execution time: 0.0750
ERROR - 2017-09-05 04:05:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:05:42 --> Config Class Initialized
INFO - 2017-09-05 04:05:42 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:05:42 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:05:42 --> Utf8 Class Initialized
INFO - 2017-09-05 04:05:42 --> URI Class Initialized
INFO - 2017-09-05 04:05:42 --> Router Class Initialized
INFO - 2017-09-05 04:05:42 --> Output Class Initialized
INFO - 2017-09-05 04:05:42 --> Security Class Initialized
DEBUG - 2017-09-05 04:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:05:42 --> Input Class Initialized
INFO - 2017-09-05 04:05:42 --> Language Class Initialized
ERROR - 2017-09-05 04:05:42 --> 404 Page Not Found: Services/go_videos
ERROR - 2017-09-05 04:05:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:05:44 --> Config Class Initialized
INFO - 2017-09-05 04:05:44 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:05:44 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:05:44 --> Utf8 Class Initialized
INFO - 2017-09-05 04:05:44 --> URI Class Initialized
INFO - 2017-09-05 04:05:44 --> Router Class Initialized
INFO - 2017-09-05 04:05:44 --> Output Class Initialized
INFO - 2017-09-05 04:05:44 --> Security Class Initialized
DEBUG - 2017-09-05 04:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:05:44 --> Input Class Initialized
INFO - 2017-09-05 04:05:44 --> Language Class Initialized
INFO - 2017-09-05 04:05:44 --> Loader Class Initialized
INFO - 2017-09-05 04:05:44 --> Controller Class Initialized
INFO - 2017-09-05 04:05:44 --> Database Driver Class Initialized
INFO - 2017-09-05 04:05:44 --> Model Class Initialized
INFO - 2017-09-05 04:05:44 --> Helper loaded: form_helper
INFO - 2017-09-05 04:05:44 --> Helper loaded: url_helper
INFO - 2017-09-05 04:05:44 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:05:44 --> Model Class Initialized
INFO - 2017-09-05 04:05:44 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-05 04:05:44 --> Final output sent to browser
DEBUG - 2017-09-05 04:05:44 --> Total execution time: 0.0610
ERROR - 2017-09-05 04:17:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:17:22 --> Config Class Initialized
INFO - 2017-09-05 04:17:22 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:17:22 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:17:22 --> Utf8 Class Initialized
INFO - 2017-09-05 04:17:22 --> URI Class Initialized
INFO - 2017-09-05 04:17:22 --> Router Class Initialized
INFO - 2017-09-05 04:17:22 --> Output Class Initialized
INFO - 2017-09-05 04:17:22 --> Security Class Initialized
DEBUG - 2017-09-05 04:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:17:22 --> Input Class Initialized
INFO - 2017-09-05 04:17:22 --> Language Class Initialized
INFO - 2017-09-05 04:17:22 --> Loader Class Initialized
INFO - 2017-09-05 04:17:22 --> Controller Class Initialized
INFO - 2017-09-05 04:17:22 --> Database Driver Class Initialized
INFO - 2017-09-05 04:17:22 --> Model Class Initialized
INFO - 2017-09-05 04:17:22 --> Helper loaded: form_helper
INFO - 2017-09-05 04:17:22 --> Helper loaded: url_helper
INFO - 2017-09-05 04:17:22 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:17:22 --> Model Class Initialized
INFO - 2017-09-05 04:17:22 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 04:17:22 --> Final output sent to browser
DEBUG - 2017-09-05 04:17:22 --> Total execution time: 0.0500
ERROR - 2017-09-05 04:18:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:18:22 --> Config Class Initialized
INFO - 2017-09-05 04:18:22 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:18:22 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:18:22 --> Utf8 Class Initialized
INFO - 2017-09-05 04:18:22 --> URI Class Initialized
INFO - 2017-09-05 04:18:22 --> Router Class Initialized
INFO - 2017-09-05 04:18:22 --> Output Class Initialized
INFO - 2017-09-05 04:18:22 --> Security Class Initialized
DEBUG - 2017-09-05 04:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:18:22 --> Input Class Initialized
INFO - 2017-09-05 04:18:22 --> Language Class Initialized
INFO - 2017-09-05 04:18:22 --> Loader Class Initialized
INFO - 2017-09-05 04:18:22 --> Controller Class Initialized
INFO - 2017-09-05 04:18:22 --> Database Driver Class Initialized
INFO - 2017-09-05 04:18:22 --> Model Class Initialized
INFO - 2017-09-05 04:18:22 --> Helper loaded: form_helper
INFO - 2017-09-05 04:18:22 --> Helper loaded: url_helper
INFO - 2017-09-05 04:18:22 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:18:22 --> Model Class Initialized
INFO - 2017-09-05 04:18:22 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 04:18:22 --> Final output sent to browser
DEBUG - 2017-09-05 04:18:22 --> Total execution time: 0.1500
ERROR - 2017-09-05 04:19:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:19:03 --> Config Class Initialized
INFO - 2017-09-05 04:19:03 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:19:03 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:19:03 --> Utf8 Class Initialized
INFO - 2017-09-05 04:19:03 --> URI Class Initialized
INFO - 2017-09-05 04:19:03 --> Router Class Initialized
INFO - 2017-09-05 04:19:03 --> Output Class Initialized
INFO - 2017-09-05 04:19:03 --> Security Class Initialized
DEBUG - 2017-09-05 04:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:19:03 --> Input Class Initialized
INFO - 2017-09-05 04:19:03 --> Language Class Initialized
INFO - 2017-09-05 04:19:03 --> Loader Class Initialized
INFO - 2017-09-05 04:19:03 --> Controller Class Initialized
INFO - 2017-09-05 04:19:03 --> Database Driver Class Initialized
INFO - 2017-09-05 04:19:03 --> Model Class Initialized
INFO - 2017-09-05 04:19:03 --> Helper loaded: form_helper
INFO - 2017-09-05 04:19:03 --> Helper loaded: url_helper
INFO - 2017-09-05 04:19:03 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:19:03 --> Model Class Initialized
INFO - 2017-09-05 04:19:03 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 04:19:03 --> Final output sent to browser
DEBUG - 2017-09-05 04:19:03 --> Total execution time: 0.0790
ERROR - 2017-09-05 04:20:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:20:22 --> Config Class Initialized
INFO - 2017-09-05 04:20:22 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:20:22 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:20:22 --> Utf8 Class Initialized
INFO - 2017-09-05 04:20:22 --> URI Class Initialized
INFO - 2017-09-05 04:20:22 --> Router Class Initialized
INFO - 2017-09-05 04:20:22 --> Output Class Initialized
INFO - 2017-09-05 04:20:22 --> Security Class Initialized
DEBUG - 2017-09-05 04:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:20:22 --> Input Class Initialized
INFO - 2017-09-05 04:20:22 --> Language Class Initialized
INFO - 2017-09-05 04:20:22 --> Loader Class Initialized
INFO - 2017-09-05 04:20:22 --> Controller Class Initialized
INFO - 2017-09-05 04:20:22 --> Database Driver Class Initialized
INFO - 2017-09-05 04:20:22 --> Model Class Initialized
INFO - 2017-09-05 04:20:22 --> Helper loaded: form_helper
INFO - 2017-09-05 04:20:22 --> Helper loaded: url_helper
INFO - 2017-09-05 04:20:22 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:20:22 --> Model Class Initialized
INFO - 2017-09-05 04:20:22 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 04:20:22 --> Final output sent to browser
DEBUG - 2017-09-05 04:20:22 --> Total execution time: 0.0800
ERROR - 2017-09-05 04:23:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:23:07 --> Config Class Initialized
INFO - 2017-09-05 04:23:07 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:23:07 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:23:07 --> Utf8 Class Initialized
INFO - 2017-09-05 04:23:07 --> URI Class Initialized
INFO - 2017-09-05 04:23:07 --> Router Class Initialized
INFO - 2017-09-05 04:23:07 --> Output Class Initialized
INFO - 2017-09-05 04:23:07 --> Security Class Initialized
DEBUG - 2017-09-05 04:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:23:07 --> Input Class Initialized
INFO - 2017-09-05 04:23:07 --> Language Class Initialized
INFO - 2017-09-05 04:23:07 --> Loader Class Initialized
INFO - 2017-09-05 04:23:07 --> Controller Class Initialized
INFO - 2017-09-05 04:23:07 --> Database Driver Class Initialized
INFO - 2017-09-05 04:23:07 --> Model Class Initialized
INFO - 2017-09-05 04:23:07 --> Helper loaded: form_helper
INFO - 2017-09-05 04:23:07 --> Helper loaded: url_helper
INFO - 2017-09-05 04:23:07 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:23:07 --> Model Class Initialized
INFO - 2017-09-05 04:23:07 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 04:23:07 --> Final output sent to browser
DEBUG - 2017-09-05 04:23:07 --> Total execution time: 0.0780
ERROR - 2017-09-05 04:23:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:23:24 --> Config Class Initialized
INFO - 2017-09-05 04:23:24 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:23:24 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:23:24 --> Utf8 Class Initialized
INFO - 2017-09-05 04:23:24 --> URI Class Initialized
INFO - 2017-09-05 04:23:24 --> Router Class Initialized
INFO - 2017-09-05 04:23:24 --> Output Class Initialized
INFO - 2017-09-05 04:23:24 --> Security Class Initialized
DEBUG - 2017-09-05 04:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:23:24 --> Input Class Initialized
INFO - 2017-09-05 04:23:24 --> Language Class Initialized
INFO - 2017-09-05 04:23:24 --> Loader Class Initialized
INFO - 2017-09-05 04:23:24 --> Controller Class Initialized
INFO - 2017-09-05 04:23:24 --> Database Driver Class Initialized
INFO - 2017-09-05 04:23:24 --> Model Class Initialized
INFO - 2017-09-05 04:23:24 --> Helper loaded: form_helper
INFO - 2017-09-05 04:23:24 --> Helper loaded: url_helper
INFO - 2017-09-05 04:23:24 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:23:24 --> Model Class Initialized
INFO - 2017-09-05 04:23:24 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 04:23:24 --> Final output sent to browser
DEBUG - 2017-09-05 04:23:24 --> Total execution time: 0.0830
ERROR - 2017-09-05 04:23:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:23:41 --> Config Class Initialized
INFO - 2017-09-05 04:23:41 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:23:41 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:23:41 --> Utf8 Class Initialized
INFO - 2017-09-05 04:23:41 --> URI Class Initialized
INFO - 2017-09-05 04:23:41 --> Router Class Initialized
INFO - 2017-09-05 04:23:41 --> Output Class Initialized
INFO - 2017-09-05 04:23:41 --> Security Class Initialized
DEBUG - 2017-09-05 04:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:23:41 --> Input Class Initialized
INFO - 2017-09-05 04:23:41 --> Language Class Initialized
INFO - 2017-09-05 04:23:41 --> Loader Class Initialized
INFO - 2017-09-05 04:23:41 --> Controller Class Initialized
INFO - 2017-09-05 04:23:41 --> Database Driver Class Initialized
INFO - 2017-09-05 04:23:41 --> Model Class Initialized
INFO - 2017-09-05 04:23:41 --> Helper loaded: form_helper
INFO - 2017-09-05 04:23:41 --> Helper loaded: url_helper
INFO - 2017-09-05 04:23:41 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:23:41 --> Model Class Initialized
INFO - 2017-09-05 04:23:41 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 04:23:41 --> Final output sent to browser
DEBUG - 2017-09-05 04:23:41 --> Total execution time: 0.1030
ERROR - 2017-09-05 04:24:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:24:50 --> Config Class Initialized
INFO - 2017-09-05 04:24:50 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:24:50 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:24:50 --> Utf8 Class Initialized
INFO - 2017-09-05 04:24:50 --> URI Class Initialized
INFO - 2017-09-05 04:24:50 --> Router Class Initialized
INFO - 2017-09-05 04:24:50 --> Output Class Initialized
INFO - 2017-09-05 04:24:50 --> Security Class Initialized
DEBUG - 2017-09-05 04:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:24:50 --> Input Class Initialized
INFO - 2017-09-05 04:24:50 --> Language Class Initialized
INFO - 2017-09-05 04:24:50 --> Loader Class Initialized
INFO - 2017-09-05 04:24:50 --> Controller Class Initialized
INFO - 2017-09-05 04:24:50 --> Database Driver Class Initialized
INFO - 2017-09-05 04:24:50 --> Model Class Initialized
INFO - 2017-09-05 04:24:50 --> Helper loaded: form_helper
INFO - 2017-09-05 04:24:50 --> Helper loaded: url_helper
INFO - 2017-09-05 04:24:50 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:24:50 --> Model Class Initialized
INFO - 2017-09-05 04:24:50 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 04:24:50 --> Final output sent to browser
DEBUG - 2017-09-05 04:24:50 --> Total execution time: 0.0570
ERROR - 2017-09-05 04:26:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:26:12 --> Config Class Initialized
INFO - 2017-09-05 04:26:12 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:26:12 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:26:12 --> Utf8 Class Initialized
INFO - 2017-09-05 04:26:12 --> URI Class Initialized
INFO - 2017-09-05 04:26:12 --> Router Class Initialized
INFO - 2017-09-05 04:26:12 --> Output Class Initialized
INFO - 2017-09-05 04:26:12 --> Security Class Initialized
DEBUG - 2017-09-05 04:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:26:12 --> Input Class Initialized
INFO - 2017-09-05 04:26:12 --> Language Class Initialized
INFO - 2017-09-05 04:26:12 --> Loader Class Initialized
INFO - 2017-09-05 04:26:12 --> Controller Class Initialized
INFO - 2017-09-05 04:26:12 --> Database Driver Class Initialized
INFO - 2017-09-05 04:26:12 --> Model Class Initialized
INFO - 2017-09-05 04:26:12 --> Helper loaded: form_helper
INFO - 2017-09-05 04:26:12 --> Helper loaded: url_helper
INFO - 2017-09-05 04:26:12 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:26:12 --> Model Class Initialized
INFO - 2017-09-05 04:26:12 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 04:26:12 --> Final output sent to browser
DEBUG - 2017-09-05 04:26:12 --> Total execution time: 0.0540
ERROR - 2017-09-05 04:26:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:26:24 --> Config Class Initialized
INFO - 2017-09-05 04:26:24 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:26:24 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:26:24 --> Utf8 Class Initialized
INFO - 2017-09-05 04:26:24 --> URI Class Initialized
INFO - 2017-09-05 04:26:24 --> Router Class Initialized
INFO - 2017-09-05 04:26:24 --> Output Class Initialized
INFO - 2017-09-05 04:26:24 --> Security Class Initialized
DEBUG - 2017-09-05 04:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:26:24 --> Input Class Initialized
INFO - 2017-09-05 04:26:24 --> Language Class Initialized
INFO - 2017-09-05 04:26:24 --> Loader Class Initialized
INFO - 2017-09-05 04:26:24 --> Controller Class Initialized
INFO - 2017-09-05 04:26:24 --> Database Driver Class Initialized
INFO - 2017-09-05 04:26:24 --> Model Class Initialized
INFO - 2017-09-05 04:26:24 --> Helper loaded: form_helper
INFO - 2017-09-05 04:26:24 --> Helper loaded: url_helper
INFO - 2017-09-05 04:26:24 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:26:24 --> Model Class Initialized
INFO - 2017-09-05 04:26:24 --> File loaded: C:\xampp\htdocs\biper\application\views\purchase.php
INFO - 2017-09-05 04:26:24 --> Final output sent to browser
DEBUG - 2017-09-05 04:26:24 --> Total execution time: 0.0940
ERROR - 2017-09-05 04:26:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:26:27 --> Config Class Initialized
INFO - 2017-09-05 04:26:27 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:26:27 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:26:27 --> Utf8 Class Initialized
INFO - 2017-09-05 04:26:27 --> URI Class Initialized
INFO - 2017-09-05 04:26:27 --> Router Class Initialized
INFO - 2017-09-05 04:26:27 --> Output Class Initialized
INFO - 2017-09-05 04:26:27 --> Security Class Initialized
DEBUG - 2017-09-05 04:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:26:27 --> Input Class Initialized
INFO - 2017-09-05 04:26:27 --> Language Class Initialized
INFO - 2017-09-05 04:26:27 --> Loader Class Initialized
INFO - 2017-09-05 04:26:27 --> Controller Class Initialized
INFO - 2017-09-05 04:26:27 --> Database Driver Class Initialized
INFO - 2017-09-05 04:26:27 --> Model Class Initialized
INFO - 2017-09-05 04:26:27 --> Helper loaded: form_helper
INFO - 2017-09-05 04:26:27 --> Helper loaded: url_helper
INFO - 2017-09-05 04:26:27 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:26:27 --> Model Class Initialized
INFO - 2017-09-05 04:26:27 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 04:26:27 --> Final output sent to browser
DEBUG - 2017-09-05 04:26:27 --> Total execution time: 0.0870
ERROR - 2017-09-05 04:36:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:36:27 --> Config Class Initialized
INFO - 2017-09-05 04:36:27 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:36:27 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:36:27 --> Utf8 Class Initialized
INFO - 2017-09-05 04:36:27 --> URI Class Initialized
INFO - 2017-09-05 04:36:27 --> Router Class Initialized
INFO - 2017-09-05 04:36:27 --> Output Class Initialized
INFO - 2017-09-05 04:36:27 --> Security Class Initialized
DEBUG - 2017-09-05 04:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:36:27 --> Input Class Initialized
INFO - 2017-09-05 04:36:27 --> Language Class Initialized
INFO - 2017-09-05 04:36:27 --> Loader Class Initialized
INFO - 2017-09-05 04:36:27 --> Controller Class Initialized
INFO - 2017-09-05 04:36:27 --> Database Driver Class Initialized
INFO - 2017-09-05 04:36:27 --> Model Class Initialized
INFO - 2017-09-05 04:36:27 --> Helper loaded: form_helper
INFO - 2017-09-05 04:36:27 --> Helper loaded: url_helper
INFO - 2017-09-05 04:36:27 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:36:27 --> Model Class Initialized
INFO - 2017-09-05 04:36:27 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 04:36:27 --> Final output sent to browser
DEBUG - 2017-09-05 04:36:27 --> Total execution time: 0.0640
ERROR - 2017-09-05 04:36:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:36:30 --> Config Class Initialized
INFO - 2017-09-05 04:36:30 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:36:30 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:36:30 --> Utf8 Class Initialized
INFO - 2017-09-05 04:36:30 --> URI Class Initialized
INFO - 2017-09-05 04:36:30 --> Router Class Initialized
INFO - 2017-09-05 04:36:30 --> Output Class Initialized
INFO - 2017-09-05 04:36:30 --> Security Class Initialized
DEBUG - 2017-09-05 04:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:36:30 --> Input Class Initialized
INFO - 2017-09-05 04:36:30 --> Language Class Initialized
ERROR - 2017-09-05 04:36:30 --> 404 Page Not Found: Services/delete_song
ERROR - 2017-09-05 04:36:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:36:36 --> Config Class Initialized
INFO - 2017-09-05 04:36:36 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:36:36 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:36:36 --> Utf8 Class Initialized
INFO - 2017-09-05 04:36:36 --> URI Class Initialized
INFO - 2017-09-05 04:36:36 --> Router Class Initialized
INFO - 2017-09-05 04:36:36 --> Output Class Initialized
INFO - 2017-09-05 04:36:36 --> Security Class Initialized
DEBUG - 2017-09-05 04:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:36:36 --> Input Class Initialized
INFO - 2017-09-05 04:36:36 --> Language Class Initialized
INFO - 2017-09-05 04:36:36 --> Loader Class Initialized
INFO - 2017-09-05 04:36:36 --> Controller Class Initialized
INFO - 2017-09-05 04:36:36 --> Database Driver Class Initialized
INFO - 2017-09-05 04:36:36 --> Model Class Initialized
INFO - 2017-09-05 04:36:36 --> Helper loaded: form_helper
INFO - 2017-09-05 04:36:36 --> Helper loaded: url_helper
INFO - 2017-09-05 04:36:36 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:36:36 --> Model Class Initialized
INFO - 2017-09-05 04:36:36 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 04:36:36 --> Final output sent to browser
DEBUG - 2017-09-05 04:36:36 --> Total execution time: 0.0740
ERROR - 2017-09-05 04:36:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:36:37 --> Config Class Initialized
INFO - 2017-09-05 04:36:37 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:36:37 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:36:37 --> Utf8 Class Initialized
INFO - 2017-09-05 04:36:37 --> URI Class Initialized
INFO - 2017-09-05 04:36:37 --> Router Class Initialized
INFO - 2017-09-05 04:36:37 --> Output Class Initialized
INFO - 2017-09-05 04:36:37 --> Security Class Initialized
DEBUG - 2017-09-05 04:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:36:37 --> Input Class Initialized
INFO - 2017-09-05 04:36:37 --> Language Class Initialized
INFO - 2017-09-05 04:36:37 --> Loader Class Initialized
INFO - 2017-09-05 04:36:37 --> Controller Class Initialized
INFO - 2017-09-05 04:36:37 --> Database Driver Class Initialized
INFO - 2017-09-05 04:36:37 --> Model Class Initialized
INFO - 2017-09-05 04:36:37 --> Helper loaded: form_helper
INFO - 2017-09-05 04:36:37 --> Helper loaded: url_helper
INFO - 2017-09-05 04:36:37 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:36:37 --> Model Class Initialized
INFO - 2017-09-05 04:36:37 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 04:36:37 --> Final output sent to browser
DEBUG - 2017-09-05 04:36:37 --> Total execution time: 0.0500
ERROR - 2017-09-05 04:36:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:36:59 --> Config Class Initialized
INFO - 2017-09-05 04:36:59 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:36:59 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:36:59 --> Utf8 Class Initialized
INFO - 2017-09-05 04:36:59 --> URI Class Initialized
INFO - 2017-09-05 04:36:59 --> Router Class Initialized
INFO - 2017-09-05 04:36:59 --> Output Class Initialized
INFO - 2017-09-05 04:36:59 --> Security Class Initialized
DEBUG - 2017-09-05 04:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:36:59 --> Input Class Initialized
INFO - 2017-09-05 04:36:59 --> Language Class Initialized
INFO - 2017-09-05 04:36:59 --> Loader Class Initialized
INFO - 2017-09-05 04:36:59 --> Controller Class Initialized
INFO - 2017-09-05 04:36:59 --> Database Driver Class Initialized
INFO - 2017-09-05 04:36:59 --> Model Class Initialized
INFO - 2017-09-05 04:36:59 --> Helper loaded: form_helper
INFO - 2017-09-05 04:36:59 --> Helper loaded: url_helper
INFO - 2017-09-05 04:36:59 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:36:59 --> Model Class Initialized
INFO - 2017-09-05 04:36:59 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 04:36:59 --> Final output sent to browser
DEBUG - 2017-09-05 04:36:59 --> Total execution time: 0.1030
ERROR - 2017-09-05 04:37:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:37:01 --> Config Class Initialized
INFO - 2017-09-05 04:37:01 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:37:01 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:37:01 --> Utf8 Class Initialized
INFO - 2017-09-05 04:37:01 --> URI Class Initialized
INFO - 2017-09-05 04:37:01 --> Router Class Initialized
INFO - 2017-09-05 04:37:01 --> Output Class Initialized
INFO - 2017-09-05 04:37:01 --> Security Class Initialized
DEBUG - 2017-09-05 04:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:37:01 --> Input Class Initialized
INFO - 2017-09-05 04:37:01 --> Language Class Initialized
INFO - 2017-09-05 04:37:01 --> Loader Class Initialized
INFO - 2017-09-05 04:37:01 --> Controller Class Initialized
INFO - 2017-09-05 04:37:01 --> Database Driver Class Initialized
INFO - 2017-09-05 04:37:01 --> Model Class Initialized
INFO - 2017-09-05 04:37:01 --> Helper loaded: form_helper
INFO - 2017-09-05 04:37:01 --> Helper loaded: url_helper
INFO - 2017-09-05 04:37:01 --> Model Class Initialized
INFO - 2017-09-05 04:37:01 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:37:01 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 04:37:01 --> Final output sent to browser
DEBUG - 2017-09-05 04:37:01 --> Total execution time: 0.1170
ERROR - 2017-09-05 04:37:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:37:03 --> Config Class Initialized
INFO - 2017-09-05 04:37:03 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:37:03 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:37:03 --> Utf8 Class Initialized
INFO - 2017-09-05 04:37:03 --> URI Class Initialized
INFO - 2017-09-05 04:37:03 --> Router Class Initialized
INFO - 2017-09-05 04:37:03 --> Output Class Initialized
INFO - 2017-09-05 04:37:03 --> Security Class Initialized
DEBUG - 2017-09-05 04:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:37:03 --> Input Class Initialized
INFO - 2017-09-05 04:37:03 --> Language Class Initialized
INFO - 2017-09-05 04:37:03 --> Loader Class Initialized
INFO - 2017-09-05 04:37:03 --> Controller Class Initialized
INFO - 2017-09-05 04:37:03 --> Database Driver Class Initialized
INFO - 2017-09-05 04:37:03 --> Model Class Initialized
INFO - 2017-09-05 04:37:03 --> Helper loaded: form_helper
INFO - 2017-09-05 04:37:03 --> Helper loaded: url_helper
INFO - 2017-09-05 04:37:03 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:37:03 --> Model Class Initialized
INFO - 2017-09-05 04:37:03 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 04:37:03 --> Final output sent to browser
DEBUG - 2017-09-05 04:37:03 --> Total execution time: 0.0790
ERROR - 2017-09-05 04:52:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:52:29 --> Config Class Initialized
INFO - 2017-09-05 04:52:29 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:52:29 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:52:29 --> Utf8 Class Initialized
INFO - 2017-09-05 04:52:29 --> URI Class Initialized
INFO - 2017-09-05 04:52:29 --> Router Class Initialized
INFO - 2017-09-05 04:52:29 --> Output Class Initialized
INFO - 2017-09-05 04:52:29 --> Security Class Initialized
DEBUG - 2017-09-05 04:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:52:29 --> Input Class Initialized
INFO - 2017-09-05 04:52:29 --> Language Class Initialized
INFO - 2017-09-05 04:52:29 --> Loader Class Initialized
INFO - 2017-09-05 04:52:29 --> Controller Class Initialized
INFO - 2017-09-05 04:52:29 --> Database Driver Class Initialized
INFO - 2017-09-05 04:52:29 --> Model Class Initialized
INFO - 2017-09-05 04:52:29 --> Helper loaded: form_helper
INFO - 2017-09-05 04:52:29 --> Helper loaded: url_helper
INFO - 2017-09-05 04:52:29 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:52:29 --> Model Class Initialized
INFO - 2017-09-05 04:52:29 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 04:52:29 --> Final output sent to browser
DEBUG - 2017-09-05 04:52:29 --> Total execution time: 0.0620
ERROR - 2017-09-05 04:52:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:52:31 --> Config Class Initialized
INFO - 2017-09-05 04:52:31 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:52:31 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:52:31 --> Utf8 Class Initialized
INFO - 2017-09-05 04:52:31 --> URI Class Initialized
INFO - 2017-09-05 04:52:31 --> Router Class Initialized
INFO - 2017-09-05 04:52:31 --> Output Class Initialized
INFO - 2017-09-05 04:52:31 --> Security Class Initialized
DEBUG - 2017-09-05 04:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:52:31 --> Input Class Initialized
INFO - 2017-09-05 04:52:31 --> Language Class Initialized
INFO - 2017-09-05 04:52:31 --> Loader Class Initialized
INFO - 2017-09-05 04:52:31 --> Controller Class Initialized
INFO - 2017-09-05 04:52:31 --> Database Driver Class Initialized
INFO - 2017-09-05 04:52:31 --> Model Class Initialized
INFO - 2017-09-05 04:52:31 --> Helper loaded: form_helper
INFO - 2017-09-05 04:52:31 --> Helper loaded: url_helper
INFO - 2017-09-05 04:52:31 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
ERROR - 2017-09-05 04:52:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\biper\application\views\add_video.php 75
INFO - 2017-09-05 04:52:31 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 04:52:31 --> Final output sent to browser
DEBUG - 2017-09-05 04:52:31 --> Total execution time: 0.0510
ERROR - 2017-09-05 04:53:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:53:33 --> Config Class Initialized
INFO - 2017-09-05 04:53:33 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:53:33 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:53:33 --> Utf8 Class Initialized
INFO - 2017-09-05 04:53:33 --> URI Class Initialized
INFO - 2017-09-05 04:53:33 --> Router Class Initialized
INFO - 2017-09-05 04:53:33 --> Output Class Initialized
INFO - 2017-09-05 04:53:33 --> Security Class Initialized
DEBUG - 2017-09-05 04:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:53:33 --> Input Class Initialized
INFO - 2017-09-05 04:53:33 --> Language Class Initialized
INFO - 2017-09-05 04:53:33 --> Loader Class Initialized
INFO - 2017-09-05 04:53:33 --> Controller Class Initialized
INFO - 2017-09-05 04:53:33 --> Database Driver Class Initialized
INFO - 2017-09-05 04:53:33 --> Model Class Initialized
INFO - 2017-09-05 04:53:33 --> Helper loaded: form_helper
INFO - 2017-09-05 04:53:33 --> Helper loaded: url_helper
INFO - 2017-09-05 04:53:33 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:53:33 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 04:53:33 --> Final output sent to browser
DEBUG - 2017-09-05 04:53:33 --> Total execution time: 0.0620
ERROR - 2017-09-05 04:54:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:54:43 --> Config Class Initialized
INFO - 2017-09-05 04:54:43 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:54:43 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:54:43 --> Utf8 Class Initialized
INFO - 2017-09-05 04:54:43 --> URI Class Initialized
INFO - 2017-09-05 04:54:43 --> Router Class Initialized
INFO - 2017-09-05 04:54:43 --> Output Class Initialized
INFO - 2017-09-05 04:54:43 --> Security Class Initialized
DEBUG - 2017-09-05 04:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:54:43 --> Input Class Initialized
INFO - 2017-09-05 04:54:43 --> Language Class Initialized
INFO - 2017-09-05 04:54:43 --> Loader Class Initialized
INFO - 2017-09-05 04:54:43 --> Controller Class Initialized
INFO - 2017-09-05 04:54:43 --> Database Driver Class Initialized
INFO - 2017-09-05 04:54:43 --> Model Class Initialized
INFO - 2017-09-05 04:54:43 --> Helper loaded: form_helper
INFO - 2017-09-05 04:54:43 --> Helper loaded: url_helper
INFO - 2017-09-05 04:54:43 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:54:43 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 04:54:43 --> Final output sent to browser
DEBUG - 2017-09-05 04:54:43 --> Total execution time: 0.0610
ERROR - 2017-09-05 04:55:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:55:23 --> Config Class Initialized
INFO - 2017-09-05 04:55:23 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:55:23 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:55:23 --> Utf8 Class Initialized
INFO - 2017-09-05 04:55:23 --> URI Class Initialized
INFO - 2017-09-05 04:55:23 --> Router Class Initialized
INFO - 2017-09-05 04:55:23 --> Output Class Initialized
INFO - 2017-09-05 04:55:23 --> Security Class Initialized
DEBUG - 2017-09-05 04:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:55:23 --> Input Class Initialized
INFO - 2017-09-05 04:55:23 --> Language Class Initialized
INFO - 2017-09-05 04:55:23 --> Loader Class Initialized
INFO - 2017-09-05 04:55:23 --> Controller Class Initialized
INFO - 2017-09-05 04:55:23 --> Database Driver Class Initialized
INFO - 2017-09-05 04:55:23 --> Model Class Initialized
INFO - 2017-09-05 04:55:23 --> Helper loaded: form_helper
INFO - 2017-09-05 04:55:23 --> Helper loaded: url_helper
INFO - 2017-09-05 04:55:23 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:55:23 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 04:55:23 --> Final output sent to browser
DEBUG - 2017-09-05 04:55:23 --> Total execution time: 0.0580
ERROR - 2017-09-05 04:56:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:56:09 --> Config Class Initialized
INFO - 2017-09-05 04:56:09 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:56:09 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:56:09 --> Utf8 Class Initialized
INFO - 2017-09-05 04:56:09 --> URI Class Initialized
INFO - 2017-09-05 04:56:09 --> Router Class Initialized
INFO - 2017-09-05 04:56:09 --> Output Class Initialized
INFO - 2017-09-05 04:56:09 --> Security Class Initialized
DEBUG - 2017-09-05 04:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:56:09 --> Input Class Initialized
INFO - 2017-09-05 04:56:09 --> Language Class Initialized
INFO - 2017-09-05 04:56:09 --> Loader Class Initialized
INFO - 2017-09-05 04:56:09 --> Controller Class Initialized
INFO - 2017-09-05 04:56:09 --> Database Driver Class Initialized
INFO - 2017-09-05 04:56:09 --> Model Class Initialized
INFO - 2017-09-05 04:56:09 --> Helper loaded: form_helper
INFO - 2017-09-05 04:56:09 --> Helper loaded: url_helper
INFO - 2017-09-05 04:56:09 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:56:09 --> Model Class Initialized
INFO - 2017-09-05 04:56:09 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 04:56:09 --> Final output sent to browser
DEBUG - 2017-09-05 04:56:09 --> Total execution time: 0.0670
ERROR - 2017-09-05 04:56:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:56:12 --> Config Class Initialized
INFO - 2017-09-05 04:56:12 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:56:12 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:56:12 --> Utf8 Class Initialized
INFO - 2017-09-05 04:56:12 --> URI Class Initialized
INFO - 2017-09-05 04:56:12 --> Router Class Initialized
INFO - 2017-09-05 04:56:12 --> Output Class Initialized
INFO - 2017-09-05 04:56:12 --> Security Class Initialized
DEBUG - 2017-09-05 04:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:56:12 --> Input Class Initialized
INFO - 2017-09-05 04:56:12 --> Language Class Initialized
INFO - 2017-09-05 04:56:12 --> Loader Class Initialized
INFO - 2017-09-05 04:56:12 --> Controller Class Initialized
INFO - 2017-09-05 04:56:12 --> Database Driver Class Initialized
INFO - 2017-09-05 04:56:12 --> Model Class Initialized
INFO - 2017-09-05 04:56:12 --> Helper loaded: form_helper
INFO - 2017-09-05 04:56:12 --> Helper loaded: url_helper
INFO - 2017-09-05 04:56:12 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:56:12 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 04:56:12 --> Final output sent to browser
DEBUG - 2017-09-05 04:56:12 --> Total execution time: 0.0470
ERROR - 2017-09-05 04:56:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:56:56 --> Config Class Initialized
INFO - 2017-09-05 04:56:56 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:56:56 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:56:56 --> Utf8 Class Initialized
INFO - 2017-09-05 04:56:56 --> URI Class Initialized
INFO - 2017-09-05 04:56:56 --> Router Class Initialized
INFO - 2017-09-05 04:56:56 --> Output Class Initialized
INFO - 2017-09-05 04:56:56 --> Security Class Initialized
DEBUG - 2017-09-05 04:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:56:56 --> Input Class Initialized
INFO - 2017-09-05 04:56:56 --> Language Class Initialized
INFO - 2017-09-05 04:56:56 --> Loader Class Initialized
INFO - 2017-09-05 04:56:56 --> Controller Class Initialized
INFO - 2017-09-05 04:56:56 --> Database Driver Class Initialized
INFO - 2017-09-05 04:56:56 --> Model Class Initialized
INFO - 2017-09-05 04:56:56 --> Helper loaded: form_helper
INFO - 2017-09-05 04:56:56 --> Helper loaded: url_helper
INFO - 2017-09-05 04:56:56 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:56:56 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 04:56:56 --> Final output sent to browser
DEBUG - 2017-09-05 04:56:56 --> Total execution time: 0.0560
ERROR - 2017-09-05 04:57:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 04:57:07 --> Config Class Initialized
INFO - 2017-09-05 04:57:07 --> Hooks Class Initialized
DEBUG - 2017-09-05 04:57:07 --> UTF-8 Support Enabled
INFO - 2017-09-05 04:57:07 --> Utf8 Class Initialized
INFO - 2017-09-05 04:57:07 --> URI Class Initialized
INFO - 2017-09-05 04:57:07 --> Router Class Initialized
INFO - 2017-09-05 04:57:07 --> Output Class Initialized
INFO - 2017-09-05 04:57:07 --> Security Class Initialized
DEBUG - 2017-09-05 04:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 04:57:07 --> Input Class Initialized
INFO - 2017-09-05 04:57:07 --> Language Class Initialized
INFO - 2017-09-05 04:57:07 --> Loader Class Initialized
INFO - 2017-09-05 04:57:07 --> Controller Class Initialized
INFO - 2017-09-05 04:57:07 --> Database Driver Class Initialized
INFO - 2017-09-05 04:57:07 --> Model Class Initialized
INFO - 2017-09-05 04:57:07 --> Helper loaded: form_helper
INFO - 2017-09-05 04:57:07 --> Helper loaded: url_helper
INFO - 2017-09-05 04:57:07 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 04:57:07 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 04:57:07 --> Final output sent to browser
DEBUG - 2017-09-05 04:57:07 --> Total execution time: 0.0440
ERROR - 2017-09-05 05:03:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:03:11 --> Config Class Initialized
INFO - 2017-09-05 05:03:11 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:03:11 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:03:11 --> Utf8 Class Initialized
INFO - 2017-09-05 05:03:11 --> URI Class Initialized
INFO - 2017-09-05 05:03:11 --> Router Class Initialized
INFO - 2017-09-05 05:03:11 --> Output Class Initialized
INFO - 2017-09-05 05:03:11 --> Security Class Initialized
DEBUG - 2017-09-05 05:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:03:11 --> Input Class Initialized
INFO - 2017-09-05 05:03:11 --> Language Class Initialized
INFO - 2017-09-05 05:03:11 --> Loader Class Initialized
INFO - 2017-09-05 05:03:11 --> Controller Class Initialized
INFO - 2017-09-05 05:03:11 --> Database Driver Class Initialized
INFO - 2017-09-05 05:03:11 --> Model Class Initialized
INFO - 2017-09-05 05:03:11 --> Helper loaded: form_helper
INFO - 2017-09-05 05:03:11 --> Helper loaded: url_helper
INFO - 2017-09-05 05:03:11 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:03:11 --> Model Class Initialized
INFO - 2017-09-05 05:03:11 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 05:03:11 --> Final output sent to browser
DEBUG - 2017-09-05 05:03:11 --> Total execution time: 0.0810
ERROR - 2017-09-05 05:03:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:03:14 --> Config Class Initialized
INFO - 2017-09-05 05:03:14 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:03:14 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:03:14 --> Utf8 Class Initialized
INFO - 2017-09-05 05:03:14 --> URI Class Initialized
INFO - 2017-09-05 05:03:14 --> Router Class Initialized
INFO - 2017-09-05 05:03:14 --> Output Class Initialized
INFO - 2017-09-05 05:03:14 --> Security Class Initialized
DEBUG - 2017-09-05 05:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:03:14 --> Input Class Initialized
INFO - 2017-09-05 05:03:14 --> Language Class Initialized
INFO - 2017-09-05 05:03:14 --> Loader Class Initialized
INFO - 2017-09-05 05:03:14 --> Controller Class Initialized
INFO - 2017-09-05 05:03:14 --> Database Driver Class Initialized
INFO - 2017-09-05 05:03:14 --> Model Class Initialized
INFO - 2017-09-05 05:03:14 --> Helper loaded: form_helper
INFO - 2017-09-05 05:03:14 --> Helper loaded: url_helper
INFO - 2017-09-05 05:03:14 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:03:14 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:03:14 --> Final output sent to browser
DEBUG - 2017-09-05 05:03:14 --> Total execution time: 0.0490
ERROR - 2017-09-05 05:04:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:04:21 --> Config Class Initialized
INFO - 2017-09-05 05:04:21 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:04:21 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:04:21 --> Utf8 Class Initialized
INFO - 2017-09-05 05:04:21 --> URI Class Initialized
INFO - 2017-09-05 05:04:21 --> Router Class Initialized
INFO - 2017-09-05 05:04:21 --> Output Class Initialized
INFO - 2017-09-05 05:04:21 --> Security Class Initialized
DEBUG - 2017-09-05 05:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:04:21 --> Input Class Initialized
INFO - 2017-09-05 05:04:21 --> Language Class Initialized
INFO - 2017-09-05 05:04:21 --> Loader Class Initialized
INFO - 2017-09-05 05:04:21 --> Controller Class Initialized
INFO - 2017-09-05 05:04:21 --> Database Driver Class Initialized
INFO - 2017-09-05 05:04:21 --> Model Class Initialized
INFO - 2017-09-05 05:04:21 --> Helper loaded: form_helper
INFO - 2017-09-05 05:04:21 --> Helper loaded: url_helper
INFO - 2017-09-05 05:04:21 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:04:21 --> Model Class Initialized
INFO - 2017-09-05 05:04:21 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 05:04:21 --> Final output sent to browser
DEBUG - 2017-09-05 05:04:21 --> Total execution time: 0.0700
ERROR - 2017-09-05 05:04:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:04:23 --> Config Class Initialized
INFO - 2017-09-05 05:04:23 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:04:23 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:04:23 --> Utf8 Class Initialized
INFO - 2017-09-05 05:04:23 --> URI Class Initialized
INFO - 2017-09-05 05:04:23 --> Router Class Initialized
INFO - 2017-09-05 05:04:23 --> Output Class Initialized
INFO - 2017-09-05 05:04:23 --> Security Class Initialized
DEBUG - 2017-09-05 05:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:04:23 --> Input Class Initialized
INFO - 2017-09-05 05:04:23 --> Language Class Initialized
INFO - 2017-09-05 05:04:23 --> Loader Class Initialized
INFO - 2017-09-05 05:04:23 --> Controller Class Initialized
INFO - 2017-09-05 05:04:23 --> Database Driver Class Initialized
INFO - 2017-09-05 05:04:23 --> Model Class Initialized
INFO - 2017-09-05 05:04:23 --> Helper loaded: form_helper
INFO - 2017-09-05 05:04:23 --> Helper loaded: url_helper
INFO - 2017-09-05 05:04:23 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:04:23 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:04:23 --> Final output sent to browser
DEBUG - 2017-09-05 05:04:23 --> Total execution time: 0.0650
ERROR - 2017-09-05 05:04:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:04:34 --> Config Class Initialized
INFO - 2017-09-05 05:04:34 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:04:34 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:04:34 --> Utf8 Class Initialized
INFO - 2017-09-05 05:04:34 --> URI Class Initialized
INFO - 2017-09-05 05:04:34 --> Router Class Initialized
INFO - 2017-09-05 05:04:34 --> Output Class Initialized
INFO - 2017-09-05 05:04:34 --> Security Class Initialized
DEBUG - 2017-09-05 05:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:04:34 --> Input Class Initialized
INFO - 2017-09-05 05:04:34 --> Language Class Initialized
INFO - 2017-09-05 05:04:34 --> Loader Class Initialized
INFO - 2017-09-05 05:04:34 --> Controller Class Initialized
INFO - 2017-09-05 05:04:34 --> Database Driver Class Initialized
INFO - 2017-09-05 05:04:34 --> Model Class Initialized
INFO - 2017-09-05 05:04:34 --> Helper loaded: form_helper
INFO - 2017-09-05 05:04:34 --> Helper loaded: url_helper
INFO - 2017-09-05 05:04:34 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:04:34 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:04:34 --> Final output sent to browser
DEBUG - 2017-09-05 05:04:34 --> Total execution time: 0.0670
ERROR - 2017-09-05 05:05:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:05:26 --> Config Class Initialized
INFO - 2017-09-05 05:05:26 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:05:26 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:05:26 --> Utf8 Class Initialized
INFO - 2017-09-05 05:05:26 --> URI Class Initialized
INFO - 2017-09-05 05:05:26 --> Router Class Initialized
INFO - 2017-09-05 05:05:26 --> Output Class Initialized
INFO - 2017-09-05 05:05:26 --> Security Class Initialized
DEBUG - 2017-09-05 05:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:05:26 --> Input Class Initialized
INFO - 2017-09-05 05:05:26 --> Language Class Initialized
INFO - 2017-09-05 05:05:26 --> Loader Class Initialized
INFO - 2017-09-05 05:05:26 --> Controller Class Initialized
INFO - 2017-09-05 05:05:26 --> Database Driver Class Initialized
INFO - 2017-09-05 05:05:26 --> Model Class Initialized
INFO - 2017-09-05 05:05:26 --> Helper loaded: form_helper
INFO - 2017-09-05 05:05:26 --> Helper loaded: url_helper
INFO - 2017-09-05 05:05:26 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:05:26 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:05:26 --> Final output sent to browser
DEBUG - 2017-09-05 05:05:26 --> Total execution time: 0.0650
ERROR - 2017-09-05 05:05:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:05:33 --> Config Class Initialized
INFO - 2017-09-05 05:05:33 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:05:33 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:05:33 --> Utf8 Class Initialized
INFO - 2017-09-05 05:05:33 --> URI Class Initialized
INFO - 2017-09-05 05:05:33 --> Router Class Initialized
INFO - 2017-09-05 05:05:33 --> Output Class Initialized
INFO - 2017-09-05 05:05:33 --> Security Class Initialized
DEBUG - 2017-09-05 05:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:05:33 --> Input Class Initialized
INFO - 2017-09-05 05:05:33 --> Language Class Initialized
INFO - 2017-09-05 05:05:33 --> Loader Class Initialized
INFO - 2017-09-05 05:05:33 --> Controller Class Initialized
INFO - 2017-09-05 05:05:33 --> Database Driver Class Initialized
INFO - 2017-09-05 05:05:33 --> Model Class Initialized
INFO - 2017-09-05 05:05:33 --> Helper loaded: form_helper
INFO - 2017-09-05 05:05:33 --> Helper loaded: url_helper
INFO - 2017-09-05 05:05:33 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:05:33 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:05:33 --> Final output sent to browser
DEBUG - 2017-09-05 05:05:33 --> Total execution time: 0.0630
ERROR - 2017-09-05 05:05:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:05:54 --> Config Class Initialized
INFO - 2017-09-05 05:05:54 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:05:54 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:05:54 --> Utf8 Class Initialized
INFO - 2017-09-05 05:05:54 --> URI Class Initialized
INFO - 2017-09-05 05:05:54 --> Router Class Initialized
INFO - 2017-09-05 05:05:54 --> Output Class Initialized
INFO - 2017-09-05 05:05:54 --> Security Class Initialized
DEBUG - 2017-09-05 05:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:05:54 --> Input Class Initialized
INFO - 2017-09-05 05:05:54 --> Language Class Initialized
INFO - 2017-09-05 05:05:54 --> Loader Class Initialized
INFO - 2017-09-05 05:05:54 --> Controller Class Initialized
INFO - 2017-09-05 05:05:54 --> Database Driver Class Initialized
INFO - 2017-09-05 05:05:54 --> Model Class Initialized
INFO - 2017-09-05 05:05:54 --> Helper loaded: form_helper
INFO - 2017-09-05 05:05:54 --> Helper loaded: url_helper
INFO - 2017-09-05 05:05:54 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:05:54 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:05:54 --> Final output sent to browser
DEBUG - 2017-09-05 05:05:54 --> Total execution time: 0.0740
ERROR - 2017-09-05 05:14:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:14:43 --> Config Class Initialized
INFO - 2017-09-05 05:14:43 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:14:43 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:14:43 --> Utf8 Class Initialized
INFO - 2017-09-05 05:14:43 --> URI Class Initialized
INFO - 2017-09-05 05:14:43 --> Router Class Initialized
INFO - 2017-09-05 05:14:43 --> Output Class Initialized
INFO - 2017-09-05 05:14:43 --> Security Class Initialized
DEBUG - 2017-09-05 05:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:14:43 --> Input Class Initialized
INFO - 2017-09-05 05:14:43 --> Language Class Initialized
INFO - 2017-09-05 05:14:43 --> Loader Class Initialized
INFO - 2017-09-05 05:14:43 --> Controller Class Initialized
INFO - 2017-09-05 05:14:43 --> Database Driver Class Initialized
INFO - 2017-09-05 05:14:43 --> Model Class Initialized
INFO - 2017-09-05 05:14:43 --> Helper loaded: form_helper
INFO - 2017-09-05 05:14:43 --> Helper loaded: url_helper
INFO - 2017-09-05 05:14:43 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:14:43 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:14:43 --> Final output sent to browser
DEBUG - 2017-09-05 05:14:43 --> Total execution time: 0.0510
ERROR - 2017-09-05 05:18:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:18:44 --> Config Class Initialized
INFO - 2017-09-05 05:18:44 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:18:44 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:18:44 --> Utf8 Class Initialized
INFO - 2017-09-05 05:18:44 --> URI Class Initialized
INFO - 2017-09-05 05:18:44 --> Router Class Initialized
INFO - 2017-09-05 05:18:44 --> Output Class Initialized
INFO - 2017-09-05 05:18:44 --> Security Class Initialized
DEBUG - 2017-09-05 05:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:18:44 --> Input Class Initialized
INFO - 2017-09-05 05:18:44 --> Language Class Initialized
INFO - 2017-09-05 05:18:44 --> Loader Class Initialized
INFO - 2017-09-05 05:18:44 --> Controller Class Initialized
INFO - 2017-09-05 05:18:44 --> Database Driver Class Initialized
INFO - 2017-09-05 05:18:44 --> Model Class Initialized
INFO - 2017-09-05 05:18:44 --> Helper loaded: form_helper
INFO - 2017-09-05 05:18:44 --> Helper loaded: url_helper
INFO - 2017-09-05 05:18:44 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:18:44 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:18:44 --> Final output sent to browser
DEBUG - 2017-09-05 05:18:44 --> Total execution time: 0.0570
ERROR - 2017-09-05 05:19:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:19:21 --> Config Class Initialized
INFO - 2017-09-05 05:19:21 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:19:21 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:19:21 --> Utf8 Class Initialized
INFO - 2017-09-05 05:19:21 --> URI Class Initialized
INFO - 2017-09-05 05:19:21 --> Router Class Initialized
INFO - 2017-09-05 05:19:21 --> Output Class Initialized
INFO - 2017-09-05 05:19:21 --> Security Class Initialized
DEBUG - 2017-09-05 05:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:19:21 --> Input Class Initialized
INFO - 2017-09-05 05:19:21 --> Language Class Initialized
INFO - 2017-09-05 05:19:21 --> Loader Class Initialized
INFO - 2017-09-05 05:19:21 --> Controller Class Initialized
INFO - 2017-09-05 05:19:21 --> Database Driver Class Initialized
INFO - 2017-09-05 05:19:21 --> Model Class Initialized
INFO - 2017-09-05 05:19:21 --> Helper loaded: form_helper
INFO - 2017-09-05 05:19:21 --> Helper loaded: url_helper
INFO - 2017-09-05 05:19:21 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:19:21 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:19:21 --> Final output sent to browser
DEBUG - 2017-09-05 05:19:21 --> Total execution time: 0.0670
ERROR - 2017-09-05 05:19:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:19:32 --> Config Class Initialized
INFO - 2017-09-05 05:19:32 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:19:32 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:19:32 --> Utf8 Class Initialized
INFO - 2017-09-05 05:19:32 --> URI Class Initialized
INFO - 2017-09-05 05:19:32 --> Router Class Initialized
INFO - 2017-09-05 05:19:32 --> Output Class Initialized
INFO - 2017-09-05 05:19:32 --> Security Class Initialized
DEBUG - 2017-09-05 05:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:19:32 --> Input Class Initialized
INFO - 2017-09-05 05:19:32 --> Language Class Initialized
INFO - 2017-09-05 05:19:32 --> Loader Class Initialized
INFO - 2017-09-05 05:19:32 --> Controller Class Initialized
INFO - 2017-09-05 05:19:32 --> Database Driver Class Initialized
INFO - 2017-09-05 05:19:32 --> Model Class Initialized
INFO - 2017-09-05 05:19:32 --> Helper loaded: form_helper
INFO - 2017-09-05 05:19:32 --> Helper loaded: url_helper
INFO - 2017-09-05 05:19:32 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:19:32 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:19:32 --> Final output sent to browser
DEBUG - 2017-09-05 05:19:32 --> Total execution time: 0.0630
ERROR - 2017-09-05 05:21:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:21:24 --> Config Class Initialized
INFO - 2017-09-05 05:21:24 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:21:24 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:21:24 --> Utf8 Class Initialized
INFO - 2017-09-05 05:21:24 --> URI Class Initialized
INFO - 2017-09-05 05:21:24 --> Router Class Initialized
INFO - 2017-09-05 05:21:24 --> Output Class Initialized
INFO - 2017-09-05 05:21:24 --> Security Class Initialized
DEBUG - 2017-09-05 05:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:21:24 --> Input Class Initialized
INFO - 2017-09-05 05:21:24 --> Language Class Initialized
INFO - 2017-09-05 05:21:24 --> Loader Class Initialized
INFO - 2017-09-05 05:21:24 --> Controller Class Initialized
INFO - 2017-09-05 05:21:24 --> Database Driver Class Initialized
INFO - 2017-09-05 05:21:24 --> Model Class Initialized
INFO - 2017-09-05 05:21:24 --> Helper loaded: form_helper
INFO - 2017-09-05 05:21:24 --> Helper loaded: url_helper
INFO - 2017-09-05 05:21:24 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:21:24 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:21:24 --> Final output sent to browser
DEBUG - 2017-09-05 05:21:24 --> Total execution time: 0.0590
ERROR - 2017-09-05 05:21:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:21:33 --> Config Class Initialized
INFO - 2017-09-05 05:21:33 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:21:33 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:21:33 --> Utf8 Class Initialized
INFO - 2017-09-05 05:21:33 --> URI Class Initialized
INFO - 2017-09-05 05:21:33 --> Router Class Initialized
INFO - 2017-09-05 05:21:33 --> Output Class Initialized
INFO - 2017-09-05 05:21:33 --> Security Class Initialized
DEBUG - 2017-09-05 05:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:21:33 --> Input Class Initialized
INFO - 2017-09-05 05:21:33 --> Language Class Initialized
INFO - 2017-09-05 05:21:33 --> Loader Class Initialized
INFO - 2017-09-05 05:21:33 --> Controller Class Initialized
INFO - 2017-09-05 05:21:33 --> Database Driver Class Initialized
INFO - 2017-09-05 05:21:33 --> Model Class Initialized
INFO - 2017-09-05 05:21:33 --> Helper loaded: form_helper
INFO - 2017-09-05 05:21:33 --> Helper loaded: url_helper
ERROR - 2017-09-05 05:21:33 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\biper\application\controllers\Services.php 36
INFO - 2017-09-05 05:21:33 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:21:33 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:21:33 --> Final output sent to browser
DEBUG - 2017-09-05 05:21:33 --> Total execution time: 0.0730
ERROR - 2017-09-05 05:22:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:22:04 --> Config Class Initialized
INFO - 2017-09-05 05:22:04 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:22:04 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:22:04 --> Utf8 Class Initialized
INFO - 2017-09-05 05:22:04 --> URI Class Initialized
INFO - 2017-09-05 05:22:04 --> Router Class Initialized
INFO - 2017-09-05 05:22:04 --> Output Class Initialized
INFO - 2017-09-05 05:22:04 --> Security Class Initialized
DEBUG - 2017-09-05 05:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:22:04 --> Input Class Initialized
INFO - 2017-09-05 05:22:04 --> Language Class Initialized
INFO - 2017-09-05 05:22:04 --> Loader Class Initialized
INFO - 2017-09-05 05:22:04 --> Controller Class Initialized
INFO - 2017-09-05 05:22:04 --> Database Driver Class Initialized
INFO - 2017-09-05 05:22:04 --> Model Class Initialized
INFO - 2017-09-05 05:22:04 --> Helper loaded: form_helper
INFO - 2017-09-05 05:22:04 --> Helper loaded: url_helper
INFO - 2017-09-05 05:22:04 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:22:04 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:22:04 --> Final output sent to browser
DEBUG - 2017-09-05 05:22:04 --> Total execution time: 0.0480
ERROR - 2017-09-05 05:22:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:22:06 --> Config Class Initialized
INFO - 2017-09-05 05:22:06 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:22:06 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:22:06 --> Utf8 Class Initialized
INFO - 2017-09-05 05:22:06 --> URI Class Initialized
INFO - 2017-09-05 05:22:06 --> Router Class Initialized
INFO - 2017-09-05 05:22:06 --> Output Class Initialized
INFO - 2017-09-05 05:22:06 --> Security Class Initialized
DEBUG - 2017-09-05 05:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:22:06 --> Input Class Initialized
INFO - 2017-09-05 05:22:06 --> Language Class Initialized
INFO - 2017-09-05 05:22:06 --> Loader Class Initialized
INFO - 2017-09-05 05:22:06 --> Controller Class Initialized
INFO - 2017-09-05 05:22:06 --> Database Driver Class Initialized
INFO - 2017-09-05 05:22:06 --> Model Class Initialized
INFO - 2017-09-05 05:22:06 --> Helper loaded: form_helper
INFO - 2017-09-05 05:22:06 --> Helper loaded: url_helper
INFO - 2017-09-05 05:22:06 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:22:06 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:22:06 --> Final output sent to browser
DEBUG - 2017-09-05 05:22:06 --> Total execution time: 0.0650
ERROR - 2017-09-05 05:22:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:22:13 --> Config Class Initialized
INFO - 2017-09-05 05:22:13 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:22:13 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:22:13 --> Utf8 Class Initialized
INFO - 2017-09-05 05:22:13 --> URI Class Initialized
INFO - 2017-09-05 05:22:13 --> Router Class Initialized
INFO - 2017-09-05 05:22:13 --> Output Class Initialized
INFO - 2017-09-05 05:22:13 --> Security Class Initialized
DEBUG - 2017-09-05 05:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:22:13 --> Input Class Initialized
INFO - 2017-09-05 05:22:13 --> Language Class Initialized
INFO - 2017-09-05 05:22:13 --> Loader Class Initialized
INFO - 2017-09-05 05:22:13 --> Controller Class Initialized
INFO - 2017-09-05 05:22:13 --> Database Driver Class Initialized
INFO - 2017-09-05 05:22:13 --> Model Class Initialized
INFO - 2017-09-05 05:22:13 --> Helper loaded: form_helper
INFO - 2017-09-05 05:22:13 --> Helper loaded: url_helper
INFO - 2017-09-05 05:22:13 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:22:13 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:22:13 --> Final output sent to browser
DEBUG - 2017-09-05 05:22:13 --> Total execution time: 0.0600
ERROR - 2017-09-05 05:23:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:23:00 --> Config Class Initialized
INFO - 2017-09-05 05:23:00 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:23:00 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:23:00 --> Utf8 Class Initialized
INFO - 2017-09-05 05:23:00 --> URI Class Initialized
INFO - 2017-09-05 05:23:00 --> Router Class Initialized
INFO - 2017-09-05 05:23:00 --> Output Class Initialized
INFO - 2017-09-05 05:23:00 --> Security Class Initialized
DEBUG - 2017-09-05 05:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:23:00 --> Input Class Initialized
INFO - 2017-09-05 05:23:00 --> Language Class Initialized
INFO - 2017-09-05 05:23:00 --> Loader Class Initialized
INFO - 2017-09-05 05:23:00 --> Controller Class Initialized
INFO - 2017-09-05 05:23:00 --> Database Driver Class Initialized
INFO - 2017-09-05 05:23:00 --> Model Class Initialized
INFO - 2017-09-05 05:23:00 --> Helper loaded: form_helper
INFO - 2017-09-05 05:23:00 --> Helper loaded: url_helper
INFO - 2017-09-05 05:23:00 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:23:00 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:23:00 --> Final output sent to browser
DEBUG - 2017-09-05 05:23:00 --> Total execution time: 0.0730
ERROR - 2017-09-05 05:23:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:23:44 --> Config Class Initialized
INFO - 2017-09-05 05:23:44 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:23:44 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:23:44 --> Utf8 Class Initialized
INFO - 2017-09-05 05:23:44 --> URI Class Initialized
INFO - 2017-09-05 05:23:44 --> Router Class Initialized
INFO - 2017-09-05 05:23:44 --> Output Class Initialized
INFO - 2017-09-05 05:23:44 --> Security Class Initialized
DEBUG - 2017-09-05 05:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:23:44 --> Input Class Initialized
INFO - 2017-09-05 05:23:44 --> Language Class Initialized
INFO - 2017-09-05 05:23:44 --> Loader Class Initialized
INFO - 2017-09-05 05:23:44 --> Controller Class Initialized
INFO - 2017-09-05 05:23:44 --> Database Driver Class Initialized
INFO - 2017-09-05 05:23:44 --> Model Class Initialized
INFO - 2017-09-05 05:23:44 --> Helper loaded: form_helper
INFO - 2017-09-05 05:23:44 --> Helper loaded: url_helper
INFO - 2017-09-05 05:23:44 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:23:44 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:23:44 --> Final output sent to browser
DEBUG - 2017-09-05 05:23:44 --> Total execution time: 0.0760
ERROR - 2017-09-05 05:24:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:24:22 --> Config Class Initialized
INFO - 2017-09-05 05:24:22 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:24:22 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:24:22 --> Utf8 Class Initialized
INFO - 2017-09-05 05:24:22 --> URI Class Initialized
INFO - 2017-09-05 05:24:22 --> Router Class Initialized
INFO - 2017-09-05 05:24:22 --> Output Class Initialized
INFO - 2017-09-05 05:24:22 --> Security Class Initialized
DEBUG - 2017-09-05 05:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:24:22 --> Input Class Initialized
INFO - 2017-09-05 05:24:22 --> Language Class Initialized
INFO - 2017-09-05 05:24:22 --> Loader Class Initialized
INFO - 2017-09-05 05:24:22 --> Controller Class Initialized
INFO - 2017-09-05 05:24:22 --> Database Driver Class Initialized
INFO - 2017-09-05 05:24:22 --> Model Class Initialized
INFO - 2017-09-05 05:24:22 --> Helper loaded: form_helper
INFO - 2017-09-05 05:24:22 --> Helper loaded: url_helper
INFO - 2017-09-05 05:24:22 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:24:22 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:24:22 --> Final output sent to browser
DEBUG - 2017-09-05 05:24:22 --> Total execution time: 0.0530
ERROR - 2017-09-05 05:25:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:25:31 --> Config Class Initialized
INFO - 2017-09-05 05:25:31 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:25:31 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:25:31 --> Utf8 Class Initialized
INFO - 2017-09-05 05:25:31 --> URI Class Initialized
INFO - 2017-09-05 05:25:31 --> Router Class Initialized
INFO - 2017-09-05 05:25:31 --> Output Class Initialized
INFO - 2017-09-05 05:25:31 --> Security Class Initialized
DEBUG - 2017-09-05 05:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:25:31 --> Input Class Initialized
INFO - 2017-09-05 05:25:31 --> Language Class Initialized
INFO - 2017-09-05 05:25:31 --> Loader Class Initialized
INFO - 2017-09-05 05:25:31 --> Controller Class Initialized
INFO - 2017-09-05 05:25:31 --> Database Driver Class Initialized
INFO - 2017-09-05 05:25:31 --> Model Class Initialized
INFO - 2017-09-05 05:25:31 --> Helper loaded: form_helper
INFO - 2017-09-05 05:25:31 --> Helper loaded: url_helper
INFO - 2017-09-05 05:25:31 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:25:31 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:25:31 --> Final output sent to browser
DEBUG - 2017-09-05 05:25:31 --> Total execution time: 0.0500
ERROR - 2017-09-05 05:25:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:25:32 --> Config Class Initialized
INFO - 2017-09-05 05:25:32 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:25:32 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:25:32 --> Utf8 Class Initialized
INFO - 2017-09-05 05:25:32 --> URI Class Initialized
INFO - 2017-09-05 05:25:32 --> Router Class Initialized
INFO - 2017-09-05 05:25:32 --> Output Class Initialized
INFO - 2017-09-05 05:25:32 --> Security Class Initialized
DEBUG - 2017-09-05 05:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:25:32 --> Input Class Initialized
INFO - 2017-09-05 05:25:32 --> Language Class Initialized
INFO - 2017-09-05 05:25:32 --> Loader Class Initialized
INFO - 2017-09-05 05:25:32 --> Controller Class Initialized
INFO - 2017-09-05 05:25:32 --> Database Driver Class Initialized
INFO - 2017-09-05 05:25:32 --> Model Class Initialized
INFO - 2017-09-05 05:25:32 --> Helper loaded: form_helper
INFO - 2017-09-05 05:25:32 --> Helper loaded: url_helper
INFO - 2017-09-05 05:25:32 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:25:32 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:25:32 --> Final output sent to browser
DEBUG - 2017-09-05 05:25:32 --> Total execution time: 0.0610
ERROR - 2017-09-05 05:26:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:26:11 --> Config Class Initialized
INFO - 2017-09-05 05:26:11 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:26:11 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:26:11 --> Utf8 Class Initialized
INFO - 2017-09-05 05:26:11 --> URI Class Initialized
INFO - 2017-09-05 05:26:11 --> Router Class Initialized
INFO - 2017-09-05 05:26:11 --> Output Class Initialized
INFO - 2017-09-05 05:26:11 --> Security Class Initialized
DEBUG - 2017-09-05 05:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:26:11 --> Input Class Initialized
INFO - 2017-09-05 05:26:11 --> Language Class Initialized
INFO - 2017-09-05 05:26:11 --> Loader Class Initialized
INFO - 2017-09-05 05:26:11 --> Controller Class Initialized
INFO - 2017-09-05 05:26:11 --> Database Driver Class Initialized
INFO - 2017-09-05 05:26:11 --> Model Class Initialized
INFO - 2017-09-05 05:26:11 --> Helper loaded: form_helper
INFO - 2017-09-05 05:26:11 --> Helper loaded: url_helper
INFO - 2017-09-05 05:26:11 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:26:11 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:26:11 --> Final output sent to browser
DEBUG - 2017-09-05 05:26:11 --> Total execution time: 0.0610
ERROR - 2017-09-05 05:26:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:26:32 --> Config Class Initialized
INFO - 2017-09-05 05:26:32 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:26:32 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:26:32 --> Utf8 Class Initialized
INFO - 2017-09-05 05:26:32 --> URI Class Initialized
INFO - 2017-09-05 05:26:32 --> Router Class Initialized
INFO - 2017-09-05 05:26:32 --> Output Class Initialized
INFO - 2017-09-05 05:26:32 --> Security Class Initialized
DEBUG - 2017-09-05 05:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:26:32 --> Input Class Initialized
INFO - 2017-09-05 05:26:32 --> Language Class Initialized
INFO - 2017-09-05 05:26:32 --> Loader Class Initialized
INFO - 2017-09-05 05:26:32 --> Controller Class Initialized
INFO - 2017-09-05 05:26:32 --> Database Driver Class Initialized
INFO - 2017-09-05 05:26:32 --> Model Class Initialized
INFO - 2017-09-05 05:26:32 --> Helper loaded: form_helper
INFO - 2017-09-05 05:26:32 --> Helper loaded: url_helper
INFO - 2017-09-05 05:26:32 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:26:32 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:26:32 --> Final output sent to browser
DEBUG - 2017-09-05 05:26:32 --> Total execution time: 0.0580
ERROR - 2017-09-05 05:26:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:26:53 --> Config Class Initialized
INFO - 2017-09-05 05:26:53 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:26:53 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:26:53 --> Utf8 Class Initialized
INFO - 2017-09-05 05:26:53 --> URI Class Initialized
INFO - 2017-09-05 05:26:53 --> Router Class Initialized
INFO - 2017-09-05 05:26:53 --> Output Class Initialized
INFO - 2017-09-05 05:26:53 --> Security Class Initialized
DEBUG - 2017-09-05 05:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:26:53 --> Input Class Initialized
INFO - 2017-09-05 05:26:53 --> Language Class Initialized
INFO - 2017-09-05 05:26:53 --> Loader Class Initialized
INFO - 2017-09-05 05:26:53 --> Controller Class Initialized
INFO - 2017-09-05 05:26:53 --> Database Driver Class Initialized
INFO - 2017-09-05 05:26:53 --> Model Class Initialized
INFO - 2017-09-05 05:26:53 --> Helper loaded: form_helper
INFO - 2017-09-05 05:26:53 --> Helper loaded: url_helper
INFO - 2017-09-05 05:26:53 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:26:53 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:26:53 --> Final output sent to browser
DEBUG - 2017-09-05 05:26:53 --> Total execution time: 0.0600
ERROR - 2017-09-05 05:27:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:27:02 --> Config Class Initialized
INFO - 2017-09-05 05:27:02 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:27:02 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:27:02 --> Utf8 Class Initialized
INFO - 2017-09-05 05:27:02 --> URI Class Initialized
INFO - 2017-09-05 05:27:02 --> Router Class Initialized
INFO - 2017-09-05 05:27:02 --> Output Class Initialized
INFO - 2017-09-05 05:27:02 --> Security Class Initialized
DEBUG - 2017-09-05 05:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:27:02 --> Input Class Initialized
INFO - 2017-09-05 05:27:02 --> Language Class Initialized
INFO - 2017-09-05 05:27:02 --> Loader Class Initialized
INFO - 2017-09-05 05:27:02 --> Controller Class Initialized
INFO - 2017-09-05 05:27:02 --> Database Driver Class Initialized
INFO - 2017-09-05 05:27:02 --> Model Class Initialized
INFO - 2017-09-05 05:27:02 --> Helper loaded: form_helper
INFO - 2017-09-05 05:27:02 --> Helper loaded: url_helper
INFO - 2017-09-05 05:27:02 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:27:02 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:27:02 --> Final output sent to browser
DEBUG - 2017-09-05 05:27:02 --> Total execution time: 0.0620
ERROR - 2017-09-05 05:28:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:28:51 --> Config Class Initialized
INFO - 2017-09-05 05:28:51 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:28:51 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:28:51 --> Utf8 Class Initialized
INFO - 2017-09-05 05:28:51 --> URI Class Initialized
INFO - 2017-09-05 05:28:51 --> Router Class Initialized
INFO - 2017-09-05 05:28:51 --> Output Class Initialized
INFO - 2017-09-05 05:28:51 --> Security Class Initialized
DEBUG - 2017-09-05 05:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:28:51 --> Input Class Initialized
INFO - 2017-09-05 05:28:51 --> Language Class Initialized
INFO - 2017-09-05 05:28:51 --> Loader Class Initialized
INFO - 2017-09-05 05:28:51 --> Controller Class Initialized
INFO - 2017-09-05 05:28:51 --> Database Driver Class Initialized
INFO - 2017-09-05 05:28:51 --> Model Class Initialized
INFO - 2017-09-05 05:28:51 --> Helper loaded: form_helper
INFO - 2017-09-05 05:28:51 --> Helper loaded: url_helper
INFO - 2017-09-05 05:28:51 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:28:51 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:28:51 --> Final output sent to browser
DEBUG - 2017-09-05 05:28:51 --> Total execution time: 0.0700
ERROR - 2017-09-05 05:28:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:28:54 --> Config Class Initialized
INFO - 2017-09-05 05:28:54 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:28:54 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:28:54 --> Utf8 Class Initialized
INFO - 2017-09-05 05:28:54 --> URI Class Initialized
INFO - 2017-09-05 05:28:54 --> Router Class Initialized
INFO - 2017-09-05 05:28:54 --> Output Class Initialized
INFO - 2017-09-05 05:28:54 --> Security Class Initialized
DEBUG - 2017-09-05 05:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:28:54 --> Input Class Initialized
INFO - 2017-09-05 05:28:54 --> Language Class Initialized
INFO - 2017-09-05 05:28:54 --> Loader Class Initialized
INFO - 2017-09-05 05:28:54 --> Controller Class Initialized
INFO - 2017-09-05 05:28:54 --> Database Driver Class Initialized
INFO - 2017-09-05 05:28:54 --> Model Class Initialized
INFO - 2017-09-05 05:28:54 --> Helper loaded: form_helper
INFO - 2017-09-05 05:28:54 --> Helper loaded: url_helper
INFO - 2017-09-05 05:28:54 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:28:54 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:28:54 --> Final output sent to browser
DEBUG - 2017-09-05 05:28:54 --> Total execution time: 0.0630
ERROR - 2017-09-05 05:28:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:28:59 --> Config Class Initialized
INFO - 2017-09-05 05:28:59 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:28:59 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:28:59 --> Utf8 Class Initialized
INFO - 2017-09-05 05:28:59 --> URI Class Initialized
INFO - 2017-09-05 05:28:59 --> Router Class Initialized
INFO - 2017-09-05 05:28:59 --> Output Class Initialized
INFO - 2017-09-05 05:28:59 --> Security Class Initialized
DEBUG - 2017-09-05 05:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:28:59 --> Input Class Initialized
INFO - 2017-09-05 05:28:59 --> Language Class Initialized
INFO - 2017-09-05 05:28:59 --> Loader Class Initialized
INFO - 2017-09-05 05:28:59 --> Controller Class Initialized
INFO - 2017-09-05 05:28:59 --> Database Driver Class Initialized
INFO - 2017-09-05 05:28:59 --> Model Class Initialized
INFO - 2017-09-05 05:28:59 --> Helper loaded: form_helper
INFO - 2017-09-05 05:28:59 --> Helper loaded: url_helper
INFO - 2017-09-05 05:28:59 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:28:59 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:28:59 --> Final output sent to browser
DEBUG - 2017-09-05 05:28:59 --> Total execution time: 0.0690
ERROR - 2017-09-05 05:29:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:29:04 --> Config Class Initialized
INFO - 2017-09-05 05:29:04 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:29:04 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:29:04 --> Utf8 Class Initialized
INFO - 2017-09-05 05:29:04 --> URI Class Initialized
INFO - 2017-09-05 05:29:04 --> Router Class Initialized
INFO - 2017-09-05 05:29:04 --> Output Class Initialized
INFO - 2017-09-05 05:29:04 --> Security Class Initialized
DEBUG - 2017-09-05 05:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:29:04 --> Input Class Initialized
INFO - 2017-09-05 05:29:04 --> Language Class Initialized
INFO - 2017-09-05 05:29:04 --> Loader Class Initialized
INFO - 2017-09-05 05:29:04 --> Controller Class Initialized
INFO - 2017-09-05 05:29:04 --> Database Driver Class Initialized
INFO - 2017-09-05 05:29:04 --> Model Class Initialized
INFO - 2017-09-05 05:29:04 --> Helper loaded: form_helper
INFO - 2017-09-05 05:29:04 --> Helper loaded: url_helper
INFO - 2017-09-05 05:29:04 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:29:04 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:29:04 --> Final output sent to browser
DEBUG - 2017-09-05 05:29:04 --> Total execution time: 0.0620
ERROR - 2017-09-05 05:29:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:29:09 --> Config Class Initialized
INFO - 2017-09-05 05:29:09 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:29:09 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:29:09 --> Utf8 Class Initialized
INFO - 2017-09-05 05:29:09 --> URI Class Initialized
INFO - 2017-09-05 05:29:09 --> Router Class Initialized
INFO - 2017-09-05 05:29:09 --> Output Class Initialized
INFO - 2017-09-05 05:29:09 --> Security Class Initialized
DEBUG - 2017-09-05 05:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:29:09 --> Input Class Initialized
INFO - 2017-09-05 05:29:09 --> Language Class Initialized
INFO - 2017-09-05 05:29:09 --> Loader Class Initialized
INFO - 2017-09-05 05:29:09 --> Controller Class Initialized
INFO - 2017-09-05 05:29:09 --> Database Driver Class Initialized
INFO - 2017-09-05 05:29:09 --> Model Class Initialized
INFO - 2017-09-05 05:29:09 --> Helper loaded: form_helper
INFO - 2017-09-05 05:29:09 --> Helper loaded: url_helper
INFO - 2017-09-05 05:29:09 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:29:09 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:29:09 --> Final output sent to browser
DEBUG - 2017-09-05 05:29:09 --> Total execution time: 0.0690
ERROR - 2017-09-05 05:29:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:29:28 --> Config Class Initialized
INFO - 2017-09-05 05:29:28 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:29:28 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:29:28 --> Utf8 Class Initialized
INFO - 2017-09-05 05:29:28 --> URI Class Initialized
INFO - 2017-09-05 05:29:28 --> Router Class Initialized
INFO - 2017-09-05 05:29:28 --> Output Class Initialized
INFO - 2017-09-05 05:29:28 --> Security Class Initialized
DEBUG - 2017-09-05 05:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:29:28 --> Input Class Initialized
INFO - 2017-09-05 05:29:28 --> Language Class Initialized
INFO - 2017-09-05 05:29:28 --> Loader Class Initialized
INFO - 2017-09-05 05:29:28 --> Controller Class Initialized
INFO - 2017-09-05 05:29:28 --> Database Driver Class Initialized
INFO - 2017-09-05 05:29:28 --> Model Class Initialized
INFO - 2017-09-05 05:29:28 --> Helper loaded: form_helper
INFO - 2017-09-05 05:29:28 --> Helper loaded: url_helper
INFO - 2017-09-05 05:29:28 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:29:28 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:29:28 --> Final output sent to browser
DEBUG - 2017-09-05 05:29:28 --> Total execution time: 0.0450
ERROR - 2017-09-05 05:29:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:29:34 --> Config Class Initialized
INFO - 2017-09-05 05:29:34 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:29:34 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:29:34 --> Utf8 Class Initialized
INFO - 2017-09-05 05:29:34 --> URI Class Initialized
INFO - 2017-09-05 05:29:34 --> Router Class Initialized
INFO - 2017-09-05 05:29:34 --> Output Class Initialized
INFO - 2017-09-05 05:29:34 --> Security Class Initialized
DEBUG - 2017-09-05 05:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:29:34 --> Input Class Initialized
INFO - 2017-09-05 05:29:34 --> Language Class Initialized
INFO - 2017-09-05 05:29:34 --> Loader Class Initialized
INFO - 2017-09-05 05:29:34 --> Controller Class Initialized
INFO - 2017-09-05 05:29:34 --> Database Driver Class Initialized
INFO - 2017-09-05 05:29:34 --> Model Class Initialized
INFO - 2017-09-05 05:29:34 --> Helper loaded: form_helper
INFO - 2017-09-05 05:29:34 --> Helper loaded: url_helper
ERROR - 2017-09-05 05:31:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:31:09 --> Config Class Initialized
INFO - 2017-09-05 05:31:09 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:31:09 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:31:09 --> Utf8 Class Initialized
INFO - 2017-09-05 05:31:09 --> URI Class Initialized
INFO - 2017-09-05 05:31:09 --> Router Class Initialized
INFO - 2017-09-05 05:31:10 --> Output Class Initialized
INFO - 2017-09-05 05:31:10 --> Security Class Initialized
DEBUG - 2017-09-05 05:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:31:10 --> Input Class Initialized
INFO - 2017-09-05 05:31:10 --> Language Class Initialized
INFO - 2017-09-05 05:31:10 --> Loader Class Initialized
INFO - 2017-09-05 05:31:10 --> Controller Class Initialized
INFO - 2017-09-05 05:31:10 --> Database Driver Class Initialized
INFO - 2017-09-05 05:31:10 --> Model Class Initialized
INFO - 2017-09-05 05:31:10 --> Helper loaded: form_helper
INFO - 2017-09-05 05:31:10 --> Helper loaded: url_helper
INFO - 2017-09-05 05:31:10 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:31:10 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:31:10 --> Final output sent to browser
DEBUG - 2017-09-05 05:31:10 --> Total execution time: 0.0900
ERROR - 2017-09-05 05:31:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:31:15 --> Config Class Initialized
INFO - 2017-09-05 05:31:15 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:31:15 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:31:15 --> Utf8 Class Initialized
INFO - 2017-09-05 05:31:15 --> URI Class Initialized
INFO - 2017-09-05 05:31:15 --> Router Class Initialized
INFO - 2017-09-05 05:31:15 --> Output Class Initialized
INFO - 2017-09-05 05:31:15 --> Security Class Initialized
DEBUG - 2017-09-05 05:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:31:16 --> Input Class Initialized
INFO - 2017-09-05 05:31:16 --> Language Class Initialized
INFO - 2017-09-05 05:31:16 --> Loader Class Initialized
INFO - 2017-09-05 05:31:16 --> Controller Class Initialized
INFO - 2017-09-05 05:31:16 --> Database Driver Class Initialized
INFO - 2017-09-05 05:31:16 --> Model Class Initialized
INFO - 2017-09-05 05:31:16 --> Helper loaded: form_helper
INFO - 2017-09-05 05:31:16 --> Helper loaded: url_helper
INFO - 2017-09-05 05:31:16 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:31:16 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:31:16 --> Final output sent to browser
DEBUG - 2017-09-05 05:31:16 --> Total execution time: 0.0520
ERROR - 2017-09-05 05:31:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:31:27 --> Config Class Initialized
INFO - 2017-09-05 05:31:27 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:31:27 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:31:27 --> Utf8 Class Initialized
INFO - 2017-09-05 05:31:27 --> URI Class Initialized
INFO - 2017-09-05 05:31:27 --> Router Class Initialized
INFO - 2017-09-05 05:31:27 --> Output Class Initialized
INFO - 2017-09-05 05:31:27 --> Security Class Initialized
DEBUG - 2017-09-05 05:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:31:27 --> Input Class Initialized
INFO - 2017-09-05 05:31:27 --> Language Class Initialized
INFO - 2017-09-05 05:31:27 --> Loader Class Initialized
INFO - 2017-09-05 05:31:27 --> Controller Class Initialized
INFO - 2017-09-05 05:31:27 --> Database Driver Class Initialized
INFO - 2017-09-05 05:31:27 --> Model Class Initialized
INFO - 2017-09-05 05:31:27 --> Helper loaded: form_helper
INFO - 2017-09-05 05:31:27 --> Helper loaded: url_helper
INFO - 2017-09-05 05:31:27 --> Final output sent to browser
DEBUG - 2017-09-05 05:31:27 --> Total execution time: 0.0550
ERROR - 2017-09-05 05:31:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:31:32 --> Config Class Initialized
INFO - 2017-09-05 05:31:32 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:31:32 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:31:32 --> Utf8 Class Initialized
INFO - 2017-09-05 05:31:32 --> URI Class Initialized
INFO - 2017-09-05 05:31:32 --> Router Class Initialized
INFO - 2017-09-05 05:31:32 --> Output Class Initialized
INFO - 2017-09-05 05:31:32 --> Security Class Initialized
DEBUG - 2017-09-05 05:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:31:32 --> Input Class Initialized
INFO - 2017-09-05 05:31:32 --> Language Class Initialized
INFO - 2017-09-05 05:31:32 --> Loader Class Initialized
INFO - 2017-09-05 05:31:32 --> Controller Class Initialized
INFO - 2017-09-05 05:31:32 --> Database Driver Class Initialized
INFO - 2017-09-05 05:31:32 --> Model Class Initialized
INFO - 2017-09-05 05:31:32 --> Helper loaded: form_helper
INFO - 2017-09-05 05:31:32 --> Helper loaded: url_helper
INFO - 2017-09-05 05:31:32 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:31:32 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:31:32 --> Final output sent to browser
DEBUG - 2017-09-05 05:31:32 --> Total execution time: 0.0960
ERROR - 2017-09-05 05:33:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:33:47 --> Config Class Initialized
INFO - 2017-09-05 05:33:47 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:33:47 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:33:47 --> Utf8 Class Initialized
INFO - 2017-09-05 05:33:47 --> URI Class Initialized
INFO - 2017-09-05 05:33:47 --> Router Class Initialized
INFO - 2017-09-05 05:33:47 --> Output Class Initialized
INFO - 2017-09-05 05:33:47 --> Security Class Initialized
DEBUG - 2017-09-05 05:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:33:47 --> Input Class Initialized
INFO - 2017-09-05 05:33:47 --> Language Class Initialized
INFO - 2017-09-05 05:33:47 --> Loader Class Initialized
INFO - 2017-09-05 05:33:47 --> Controller Class Initialized
INFO - 2017-09-05 05:33:47 --> Database Driver Class Initialized
INFO - 2017-09-05 05:33:47 --> Model Class Initialized
INFO - 2017-09-05 05:33:47 --> Helper loaded: form_helper
INFO - 2017-09-05 05:33:47 --> Helper loaded: url_helper
INFO - 2017-09-05 05:33:47 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:33:47 --> Model Class Initialized
INFO - 2017-09-05 05:33:47 --> File loaded: C:\xampp\htdocs\biper\application\views\purchase.php
INFO - 2017-09-05 05:33:47 --> Final output sent to browser
DEBUG - 2017-09-05 05:33:47 --> Total execution time: 0.0740
ERROR - 2017-09-05 05:33:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:33:48 --> Config Class Initialized
INFO - 2017-09-05 05:33:48 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:33:48 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:33:48 --> Utf8 Class Initialized
INFO - 2017-09-05 05:33:48 --> URI Class Initialized
INFO - 2017-09-05 05:33:48 --> Router Class Initialized
INFO - 2017-09-05 05:33:48 --> Output Class Initialized
INFO - 2017-09-05 05:33:48 --> Security Class Initialized
DEBUG - 2017-09-05 05:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:33:48 --> Input Class Initialized
INFO - 2017-09-05 05:33:48 --> Language Class Initialized
INFO - 2017-09-05 05:33:48 --> Loader Class Initialized
INFO - 2017-09-05 05:33:48 --> Controller Class Initialized
INFO - 2017-09-05 05:33:48 --> Database Driver Class Initialized
INFO - 2017-09-05 05:33:48 --> Model Class Initialized
INFO - 2017-09-05 05:33:48 --> Helper loaded: form_helper
INFO - 2017-09-05 05:33:48 --> Helper loaded: url_helper
INFO - 2017-09-05 05:33:48 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:33:48 --> Model Class Initialized
INFO - 2017-09-05 05:33:48 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 05:33:48 --> Final output sent to browser
DEBUG - 2017-09-05 05:33:48 --> Total execution time: 0.0470
ERROR - 2017-09-05 05:33:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:33:49 --> Config Class Initialized
INFO - 2017-09-05 05:33:49 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:33:49 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:33:49 --> Utf8 Class Initialized
INFO - 2017-09-05 05:33:49 --> URI Class Initialized
INFO - 2017-09-05 05:33:49 --> Router Class Initialized
INFO - 2017-09-05 05:33:49 --> Output Class Initialized
INFO - 2017-09-05 05:33:49 --> Security Class Initialized
DEBUG - 2017-09-05 05:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:33:49 --> Input Class Initialized
INFO - 2017-09-05 05:33:49 --> Language Class Initialized
INFO - 2017-09-05 05:33:49 --> Loader Class Initialized
INFO - 2017-09-05 05:33:49 --> Controller Class Initialized
INFO - 2017-09-05 05:33:49 --> Database Driver Class Initialized
INFO - 2017-09-05 05:33:49 --> Model Class Initialized
INFO - 2017-09-05 05:33:49 --> Helper loaded: form_helper
INFO - 2017-09-05 05:33:49 --> Helper loaded: url_helper
INFO - 2017-09-05 05:33:49 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:33:49 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:33:49 --> Final output sent to browser
DEBUG - 2017-09-05 05:33:49 --> Total execution time: 0.0510
ERROR - 2017-09-05 05:34:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:34:03 --> Config Class Initialized
INFO - 2017-09-05 05:34:03 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:34:03 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:34:03 --> Utf8 Class Initialized
INFO - 2017-09-05 05:34:03 --> URI Class Initialized
INFO - 2017-09-05 05:34:03 --> Router Class Initialized
INFO - 2017-09-05 05:34:03 --> Output Class Initialized
INFO - 2017-09-05 05:34:03 --> Security Class Initialized
DEBUG - 2017-09-05 05:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:34:03 --> Input Class Initialized
INFO - 2017-09-05 05:34:03 --> Language Class Initialized
INFO - 2017-09-05 05:34:03 --> Loader Class Initialized
INFO - 2017-09-05 05:34:03 --> Controller Class Initialized
INFO - 2017-09-05 05:34:03 --> Database Driver Class Initialized
INFO - 2017-09-05 05:34:03 --> Model Class Initialized
INFO - 2017-09-05 05:34:03 --> Helper loaded: form_helper
INFO - 2017-09-05 05:34:03 --> Helper loaded: url_helper
INFO - 2017-09-05 05:34:03 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:34:03 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:34:03 --> Final output sent to browser
DEBUG - 2017-09-05 05:34:03 --> Total execution time: 0.0900
ERROR - 2017-09-05 05:34:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:34:06 --> Config Class Initialized
INFO - 2017-09-05 05:34:06 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:34:06 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:34:06 --> Utf8 Class Initialized
INFO - 2017-09-05 05:34:06 --> URI Class Initialized
INFO - 2017-09-05 05:34:06 --> Router Class Initialized
INFO - 2017-09-05 05:34:06 --> Output Class Initialized
INFO - 2017-09-05 05:34:06 --> Security Class Initialized
DEBUG - 2017-09-05 05:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:34:06 --> Input Class Initialized
INFO - 2017-09-05 05:34:06 --> Language Class Initialized
INFO - 2017-09-05 05:34:06 --> Loader Class Initialized
INFO - 2017-09-05 05:34:06 --> Controller Class Initialized
INFO - 2017-09-05 05:34:06 --> Database Driver Class Initialized
INFO - 2017-09-05 05:34:06 --> Model Class Initialized
INFO - 2017-09-05 05:34:06 --> Helper loaded: form_helper
INFO - 2017-09-05 05:34:06 --> Helper loaded: url_helper
INFO - 2017-09-05 05:34:06 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:34:06 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:34:06 --> Final output sent to browser
DEBUG - 2017-09-05 05:34:06 --> Total execution time: 0.0870
ERROR - 2017-09-05 05:34:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:34:25 --> Config Class Initialized
INFO - 2017-09-05 05:34:25 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:34:25 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:34:25 --> Utf8 Class Initialized
INFO - 2017-09-05 05:34:25 --> URI Class Initialized
INFO - 2017-09-05 05:34:25 --> Router Class Initialized
INFO - 2017-09-05 05:34:25 --> Output Class Initialized
INFO - 2017-09-05 05:34:25 --> Security Class Initialized
DEBUG - 2017-09-05 05:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:34:25 --> Input Class Initialized
INFO - 2017-09-05 05:34:25 --> Language Class Initialized
INFO - 2017-09-05 05:34:25 --> Loader Class Initialized
INFO - 2017-09-05 05:34:25 --> Controller Class Initialized
INFO - 2017-09-05 05:34:25 --> Database Driver Class Initialized
INFO - 2017-09-05 05:34:25 --> Model Class Initialized
INFO - 2017-09-05 05:34:25 --> Helper loaded: form_helper
INFO - 2017-09-05 05:34:25 --> Helper loaded: url_helper
INFO - 2017-09-05 05:34:25 --> Model Class Initialized
ERROR - 2017-09-05 05:34:25 --> Severity: Error --> Call to undefined method Service_model::add_video() C:\xampp\htdocs\biper\application\controllers\Services.php 46
ERROR - 2017-09-05 05:34:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:34:32 --> Config Class Initialized
INFO - 2017-09-05 05:34:32 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:34:32 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:34:32 --> Utf8 Class Initialized
INFO - 2017-09-05 05:34:32 --> URI Class Initialized
INFO - 2017-09-05 05:34:32 --> Router Class Initialized
INFO - 2017-09-05 05:34:32 --> Output Class Initialized
INFO - 2017-09-05 05:34:32 --> Security Class Initialized
DEBUG - 2017-09-05 05:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:34:32 --> Input Class Initialized
INFO - 2017-09-05 05:34:32 --> Language Class Initialized
INFO - 2017-09-05 05:34:32 --> Loader Class Initialized
INFO - 2017-09-05 05:34:32 --> Controller Class Initialized
INFO - 2017-09-05 05:34:32 --> Database Driver Class Initialized
INFO - 2017-09-05 05:34:32 --> Model Class Initialized
INFO - 2017-09-05 05:34:32 --> Helper loaded: form_helper
INFO - 2017-09-05 05:34:32 --> Helper loaded: url_helper
INFO - 2017-09-05 05:34:32 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:34:32 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:34:32 --> Final output sent to browser
DEBUG - 2017-09-05 05:34:32 --> Total execution time: 0.0450
ERROR - 2017-09-05 05:41:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:41:19 --> Config Class Initialized
INFO - 2017-09-05 05:41:19 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:41:19 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:41:19 --> Utf8 Class Initialized
INFO - 2017-09-05 05:41:19 --> URI Class Initialized
INFO - 2017-09-05 05:41:19 --> Router Class Initialized
INFO - 2017-09-05 05:41:19 --> Output Class Initialized
INFO - 2017-09-05 05:41:19 --> Security Class Initialized
DEBUG - 2017-09-05 05:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:41:19 --> Input Class Initialized
INFO - 2017-09-05 05:41:19 --> Language Class Initialized
INFO - 2017-09-05 05:41:19 --> Loader Class Initialized
INFO - 2017-09-05 05:41:19 --> Controller Class Initialized
INFO - 2017-09-05 05:41:19 --> Database Driver Class Initialized
INFO - 2017-09-05 05:41:19 --> Model Class Initialized
INFO - 2017-09-05 05:41:19 --> Helper loaded: form_helper
INFO - 2017-09-05 05:41:19 --> Helper loaded: url_helper
INFO - 2017-09-05 05:41:19 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:41:19 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:41:19 --> Final output sent to browser
DEBUG - 2017-09-05 05:41:19 --> Total execution time: 0.0780
ERROR - 2017-09-05 05:41:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:41:24 --> Config Class Initialized
INFO - 2017-09-05 05:41:24 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:41:24 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:41:24 --> Utf8 Class Initialized
INFO - 2017-09-05 05:41:24 --> URI Class Initialized
INFO - 2017-09-05 05:41:24 --> Router Class Initialized
INFO - 2017-09-05 05:41:24 --> Output Class Initialized
INFO - 2017-09-05 05:41:24 --> Security Class Initialized
DEBUG - 2017-09-05 05:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:41:24 --> Input Class Initialized
INFO - 2017-09-05 05:41:24 --> Language Class Initialized
INFO - 2017-09-05 05:41:24 --> Loader Class Initialized
INFO - 2017-09-05 05:41:24 --> Controller Class Initialized
INFO - 2017-09-05 05:41:24 --> Database Driver Class Initialized
INFO - 2017-09-05 05:41:24 --> Model Class Initialized
INFO - 2017-09-05 05:41:24 --> Helper loaded: form_helper
INFO - 2017-09-05 05:41:24 --> Helper loaded: url_helper
INFO - 2017-09-05 05:41:24 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:41:24 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:41:24 --> Final output sent to browser
DEBUG - 2017-09-05 05:41:24 --> Total execution time: 0.0880
ERROR - 2017-09-05 05:41:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:41:32 --> Config Class Initialized
INFO - 2017-09-05 05:41:32 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:41:32 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:41:32 --> Utf8 Class Initialized
INFO - 2017-09-05 05:41:32 --> URI Class Initialized
INFO - 2017-09-05 05:41:32 --> Router Class Initialized
INFO - 2017-09-05 05:41:32 --> Output Class Initialized
INFO - 2017-09-05 05:41:32 --> Security Class Initialized
DEBUG - 2017-09-05 05:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:41:32 --> Input Class Initialized
INFO - 2017-09-05 05:41:32 --> Language Class Initialized
INFO - 2017-09-05 05:41:32 --> Loader Class Initialized
INFO - 2017-09-05 05:41:32 --> Controller Class Initialized
INFO - 2017-09-05 05:41:32 --> Database Driver Class Initialized
INFO - 2017-09-05 05:41:32 --> Model Class Initialized
INFO - 2017-09-05 05:41:32 --> Helper loaded: form_helper
INFO - 2017-09-05 05:41:32 --> Helper loaded: url_helper
INFO - 2017-09-05 05:41:32 --> Model Class Initialized
INFO - 2017-09-05 05:41:32 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:41:32 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:41:32 --> Final output sent to browser
DEBUG - 2017-09-05 05:41:32 --> Total execution time: 0.0770
ERROR - 2017-09-05 05:41:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:41:36 --> Config Class Initialized
INFO - 2017-09-05 05:41:36 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:41:36 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:41:36 --> Utf8 Class Initialized
INFO - 2017-09-05 05:41:36 --> URI Class Initialized
INFO - 2017-09-05 05:41:36 --> Router Class Initialized
INFO - 2017-09-05 05:41:36 --> Output Class Initialized
INFO - 2017-09-05 05:41:36 --> Security Class Initialized
DEBUG - 2017-09-05 05:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:41:36 --> Input Class Initialized
INFO - 2017-09-05 05:41:36 --> Language Class Initialized
INFO - 2017-09-05 05:41:36 --> Loader Class Initialized
INFO - 2017-09-05 05:41:36 --> Controller Class Initialized
INFO - 2017-09-05 05:41:36 --> Database Driver Class Initialized
INFO - 2017-09-05 05:41:36 --> Model Class Initialized
INFO - 2017-09-05 05:41:36 --> Helper loaded: form_helper
INFO - 2017-09-05 05:41:36 --> Helper loaded: url_helper
INFO - 2017-09-05 05:41:36 --> Model Class Initialized
INFO - 2017-09-05 05:41:36 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:41:36 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 05:41:36 --> Final output sent to browser
DEBUG - 2017-09-05 05:41:36 --> Total execution time: 0.1040
ERROR - 2017-09-05 05:41:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 05:41:40 --> Config Class Initialized
INFO - 2017-09-05 05:41:40 --> Hooks Class Initialized
DEBUG - 2017-09-05 05:41:40 --> UTF-8 Support Enabled
INFO - 2017-09-05 05:41:40 --> Utf8 Class Initialized
INFO - 2017-09-05 05:41:40 --> URI Class Initialized
INFO - 2017-09-05 05:41:40 --> Router Class Initialized
INFO - 2017-09-05 05:41:40 --> Output Class Initialized
INFO - 2017-09-05 05:41:40 --> Security Class Initialized
DEBUG - 2017-09-05 05:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 05:41:40 --> Input Class Initialized
INFO - 2017-09-05 05:41:40 --> Language Class Initialized
INFO - 2017-09-05 05:41:40 --> Loader Class Initialized
INFO - 2017-09-05 05:41:40 --> Controller Class Initialized
INFO - 2017-09-05 05:41:40 --> Database Driver Class Initialized
INFO - 2017-09-05 05:41:40 --> Model Class Initialized
INFO - 2017-09-05 05:41:40 --> Helper loaded: form_helper
INFO - 2017-09-05 05:41:40 --> Helper loaded: url_helper
INFO - 2017-09-05 05:41:40 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 05:41:40 --> Model Class Initialized
INFO - 2017-09-05 05:41:40 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 05:41:40 --> Final output sent to browser
DEBUG - 2017-09-05 05:41:40 --> Total execution time: 0.0850
ERROR - 2017-09-05 06:39:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 06:39:11 --> Config Class Initialized
INFO - 2017-09-05 06:39:11 --> Hooks Class Initialized
DEBUG - 2017-09-05 06:39:11 --> UTF-8 Support Enabled
INFO - 2017-09-05 06:39:11 --> Utf8 Class Initialized
INFO - 2017-09-05 06:39:11 --> URI Class Initialized
INFO - 2017-09-05 06:39:11 --> Router Class Initialized
INFO - 2017-09-05 06:39:11 --> Output Class Initialized
INFO - 2017-09-05 06:39:11 --> Security Class Initialized
DEBUG - 2017-09-05 06:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 06:39:11 --> Input Class Initialized
INFO - 2017-09-05 06:39:11 --> Language Class Initialized
INFO - 2017-09-05 06:39:11 --> Loader Class Initialized
INFO - 2017-09-05 06:39:11 --> Controller Class Initialized
INFO - 2017-09-05 06:39:11 --> Database Driver Class Initialized
INFO - 2017-09-05 06:39:11 --> Model Class Initialized
INFO - 2017-09-05 06:39:11 --> Helper loaded: form_helper
INFO - 2017-09-05 06:39:11 --> Helper loaded: url_helper
INFO - 2017-09-05 06:39:11 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 06:39:11 --> Model Class Initialized
INFO - 2017-09-05 06:39:11 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 06:39:11 --> Final output sent to browser
DEBUG - 2017-09-05 06:39:11 --> Total execution time: 0.0800
ERROR - 2017-09-05 06:39:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 06:39:13 --> Config Class Initialized
INFO - 2017-09-05 06:39:13 --> Hooks Class Initialized
DEBUG - 2017-09-05 06:39:13 --> UTF-8 Support Enabled
INFO - 2017-09-05 06:39:13 --> Utf8 Class Initialized
INFO - 2017-09-05 06:39:13 --> URI Class Initialized
INFO - 2017-09-05 06:39:13 --> Router Class Initialized
INFO - 2017-09-05 06:39:13 --> Output Class Initialized
INFO - 2017-09-05 06:39:13 --> Security Class Initialized
DEBUG - 2017-09-05 06:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 06:39:13 --> Input Class Initialized
INFO - 2017-09-05 06:39:13 --> Language Class Initialized
INFO - 2017-09-05 06:39:13 --> Loader Class Initialized
INFO - 2017-09-05 06:39:13 --> Controller Class Initialized
INFO - 2017-09-05 06:39:13 --> Database Driver Class Initialized
INFO - 2017-09-05 06:39:13 --> Model Class Initialized
INFO - 2017-09-05 06:39:13 --> Helper loaded: form_helper
INFO - 2017-09-05 06:39:13 --> Helper loaded: url_helper
INFO - 2017-09-05 06:39:13 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 06:39:13 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 06:39:13 --> Final output sent to browser
DEBUG - 2017-09-05 06:39:13 --> Total execution time: 0.0690
ERROR - 2017-09-05 06:39:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 06:39:14 --> Config Class Initialized
INFO - 2017-09-05 06:39:14 --> Hooks Class Initialized
DEBUG - 2017-09-05 06:39:14 --> UTF-8 Support Enabled
INFO - 2017-09-05 06:39:14 --> Utf8 Class Initialized
INFO - 2017-09-05 06:39:14 --> URI Class Initialized
INFO - 2017-09-05 06:39:14 --> Router Class Initialized
INFO - 2017-09-05 06:39:14 --> Output Class Initialized
INFO - 2017-09-05 06:39:14 --> Security Class Initialized
DEBUG - 2017-09-05 06:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 06:39:14 --> Input Class Initialized
INFO - 2017-09-05 06:39:14 --> Language Class Initialized
INFO - 2017-09-05 06:39:14 --> Loader Class Initialized
INFO - 2017-09-05 06:39:14 --> Controller Class Initialized
INFO - 2017-09-05 06:39:14 --> Database Driver Class Initialized
INFO - 2017-09-05 06:39:14 --> Model Class Initialized
INFO - 2017-09-05 06:39:14 --> Helper loaded: form_helper
INFO - 2017-09-05 06:39:14 --> Helper loaded: url_helper
INFO - 2017-09-05 06:39:14 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 06:39:14 --> Model Class Initialized
INFO - 2017-09-05 06:39:14 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 06:39:14 --> Final output sent to browser
DEBUG - 2017-09-05 06:39:15 --> Total execution time: 0.0670
ERROR - 2017-09-05 06:39:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 06:39:30 --> Config Class Initialized
INFO - 2017-09-05 06:39:30 --> Hooks Class Initialized
DEBUG - 2017-09-05 06:39:30 --> UTF-8 Support Enabled
INFO - 2017-09-05 06:39:30 --> Utf8 Class Initialized
INFO - 2017-09-05 06:39:30 --> URI Class Initialized
INFO - 2017-09-05 06:39:30 --> Router Class Initialized
INFO - 2017-09-05 06:39:30 --> Output Class Initialized
INFO - 2017-09-05 06:39:30 --> Security Class Initialized
DEBUG - 2017-09-05 06:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 06:39:30 --> Input Class Initialized
INFO - 2017-09-05 06:39:30 --> Language Class Initialized
INFO - 2017-09-05 06:39:30 --> Loader Class Initialized
INFO - 2017-09-05 06:39:30 --> Controller Class Initialized
INFO - 2017-09-05 06:39:30 --> Database Driver Class Initialized
INFO - 2017-09-05 06:39:30 --> Model Class Initialized
INFO - 2017-09-05 06:39:30 --> Helper loaded: form_helper
INFO - 2017-09-05 06:39:30 --> Helper loaded: url_helper
INFO - 2017-09-05 06:39:30 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 06:39:30 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 06:39:30 --> Final output sent to browser
DEBUG - 2017-09-05 06:39:30 --> Total execution time: 0.0720
ERROR - 2017-09-05 06:39:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 06:39:48 --> Config Class Initialized
INFO - 2017-09-05 06:39:48 --> Hooks Class Initialized
DEBUG - 2017-09-05 06:39:48 --> UTF-8 Support Enabled
INFO - 2017-09-05 06:39:48 --> Utf8 Class Initialized
INFO - 2017-09-05 06:39:48 --> URI Class Initialized
INFO - 2017-09-05 06:39:48 --> Router Class Initialized
INFO - 2017-09-05 06:39:48 --> Output Class Initialized
INFO - 2017-09-05 06:39:48 --> Security Class Initialized
DEBUG - 2017-09-05 06:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 06:39:48 --> Input Class Initialized
INFO - 2017-09-05 06:39:48 --> Language Class Initialized
INFO - 2017-09-05 06:39:48 --> Loader Class Initialized
INFO - 2017-09-05 06:39:48 --> Controller Class Initialized
INFO - 2017-09-05 06:39:48 --> Database Driver Class Initialized
INFO - 2017-09-05 06:39:48 --> Model Class Initialized
INFO - 2017-09-05 06:39:48 --> Helper loaded: form_helper
INFO - 2017-09-05 06:39:48 --> Helper loaded: url_helper
INFO - 2017-09-05 06:39:48 --> Model Class Initialized
INFO - 2017-09-05 06:39:48 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 06:39:48 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 06:39:48 --> Final output sent to browser
DEBUG - 2017-09-05 06:39:48 --> Total execution time: 0.0780
ERROR - 2017-09-05 06:42:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 06:42:46 --> Config Class Initialized
INFO - 2017-09-05 06:42:46 --> Hooks Class Initialized
DEBUG - 2017-09-05 06:42:46 --> UTF-8 Support Enabled
INFO - 2017-09-05 06:42:46 --> Utf8 Class Initialized
INFO - 2017-09-05 06:42:46 --> URI Class Initialized
INFO - 2017-09-05 06:42:46 --> Router Class Initialized
INFO - 2017-09-05 06:42:46 --> Output Class Initialized
INFO - 2017-09-05 06:42:46 --> Security Class Initialized
DEBUG - 2017-09-05 06:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 06:42:46 --> Input Class Initialized
INFO - 2017-09-05 06:42:46 --> Language Class Initialized
INFO - 2017-09-05 06:42:46 --> Loader Class Initialized
INFO - 2017-09-05 06:42:46 --> Controller Class Initialized
INFO - 2017-09-05 06:42:46 --> Database Driver Class Initialized
INFO - 2017-09-05 06:42:46 --> Model Class Initialized
INFO - 2017-09-05 06:42:46 --> Helper loaded: form_helper
INFO - 2017-09-05 06:42:46 --> Helper loaded: url_helper
INFO - 2017-09-05 06:42:46 --> Model Class Initialized
INFO - 2017-09-05 06:42:46 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 06:42:46 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 06:42:46 --> Final output sent to browser
DEBUG - 2017-09-05 06:42:46 --> Total execution time: 0.1420
ERROR - 2017-09-05 06:43:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 06:43:25 --> Config Class Initialized
INFO - 2017-09-05 06:43:25 --> Hooks Class Initialized
DEBUG - 2017-09-05 06:43:25 --> UTF-8 Support Enabled
INFO - 2017-09-05 06:43:25 --> Utf8 Class Initialized
INFO - 2017-09-05 06:43:25 --> URI Class Initialized
INFO - 2017-09-05 06:43:25 --> Router Class Initialized
INFO - 2017-09-05 06:43:25 --> Output Class Initialized
INFO - 2017-09-05 06:43:25 --> Security Class Initialized
DEBUG - 2017-09-05 06:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 06:43:25 --> Input Class Initialized
INFO - 2017-09-05 06:43:25 --> Language Class Initialized
INFO - 2017-09-05 06:43:25 --> Loader Class Initialized
INFO - 2017-09-05 06:43:25 --> Controller Class Initialized
INFO - 2017-09-05 06:43:25 --> Database Driver Class Initialized
INFO - 2017-09-05 06:43:25 --> Model Class Initialized
INFO - 2017-09-05 06:43:25 --> Helper loaded: form_helper
INFO - 2017-09-05 06:43:25 --> Helper loaded: url_helper
INFO - 2017-09-05 06:43:25 --> Model Class Initialized
INFO - 2017-09-05 06:43:25 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 06:43:25 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 06:43:25 --> Final output sent to browser
DEBUG - 2017-09-05 06:43:25 --> Total execution time: 0.1020
ERROR - 2017-09-05 06:45:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 06:45:07 --> Config Class Initialized
INFO - 2017-09-05 06:45:07 --> Hooks Class Initialized
DEBUG - 2017-09-05 06:45:07 --> UTF-8 Support Enabled
INFO - 2017-09-05 06:45:07 --> Utf8 Class Initialized
INFO - 2017-09-05 06:45:07 --> URI Class Initialized
INFO - 2017-09-05 06:45:07 --> Router Class Initialized
INFO - 2017-09-05 06:45:07 --> Output Class Initialized
INFO - 2017-09-05 06:45:07 --> Security Class Initialized
DEBUG - 2017-09-05 06:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 06:45:07 --> Input Class Initialized
INFO - 2017-09-05 06:45:07 --> Language Class Initialized
INFO - 2017-09-05 06:45:07 --> Loader Class Initialized
INFO - 2017-09-05 06:45:07 --> Controller Class Initialized
INFO - 2017-09-05 06:45:07 --> Database Driver Class Initialized
INFO - 2017-09-05 06:45:07 --> Model Class Initialized
INFO - 2017-09-05 06:45:07 --> Helper loaded: form_helper
INFO - 2017-09-05 06:45:07 --> Helper loaded: url_helper
INFO - 2017-09-05 06:45:07 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 06:45:07 --> Model Class Initialized
INFO - 2017-09-05 06:45:07 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 06:45:07 --> Final output sent to browser
DEBUG - 2017-09-05 06:45:07 --> Total execution time: 0.0510
ERROR - 2017-09-05 06:45:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 06:45:16 --> Config Class Initialized
INFO - 2017-09-05 06:45:16 --> Hooks Class Initialized
DEBUG - 2017-09-05 06:45:16 --> UTF-8 Support Enabled
INFO - 2017-09-05 06:45:16 --> Utf8 Class Initialized
INFO - 2017-09-05 06:45:16 --> URI Class Initialized
INFO - 2017-09-05 06:45:16 --> Router Class Initialized
INFO - 2017-09-05 06:45:16 --> Output Class Initialized
INFO - 2017-09-05 06:45:16 --> Security Class Initialized
DEBUG - 2017-09-05 06:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 06:45:16 --> Input Class Initialized
INFO - 2017-09-05 06:45:16 --> Language Class Initialized
INFO - 2017-09-05 06:45:16 --> Loader Class Initialized
INFO - 2017-09-05 06:45:16 --> Controller Class Initialized
INFO - 2017-09-05 06:45:17 --> Database Driver Class Initialized
INFO - 2017-09-05 06:45:17 --> Model Class Initialized
INFO - 2017-09-05 06:45:17 --> Helper loaded: form_helper
INFO - 2017-09-05 06:45:17 --> Helper loaded: url_helper
INFO - 2017-09-05 06:45:17 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 06:45:17 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 06:45:17 --> Final output sent to browser
DEBUG - 2017-09-05 06:45:17 --> Total execution time: 0.0590
ERROR - 2017-09-05 06:46:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 06:46:21 --> Config Class Initialized
INFO - 2017-09-05 06:46:21 --> Hooks Class Initialized
DEBUG - 2017-09-05 06:46:21 --> UTF-8 Support Enabled
INFO - 2017-09-05 06:46:21 --> Utf8 Class Initialized
INFO - 2017-09-05 06:46:21 --> URI Class Initialized
INFO - 2017-09-05 06:46:21 --> Router Class Initialized
INFO - 2017-09-05 06:46:21 --> Output Class Initialized
INFO - 2017-09-05 06:46:21 --> Security Class Initialized
DEBUG - 2017-09-05 06:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 06:46:21 --> Input Class Initialized
INFO - 2017-09-05 06:46:21 --> Language Class Initialized
INFO - 2017-09-05 06:46:21 --> Loader Class Initialized
INFO - 2017-09-05 06:46:21 --> Controller Class Initialized
INFO - 2017-09-05 06:46:21 --> Database Driver Class Initialized
INFO - 2017-09-05 06:46:21 --> Model Class Initialized
INFO - 2017-09-05 06:46:21 --> Helper loaded: form_helper
INFO - 2017-09-05 06:46:21 --> Helper loaded: url_helper
INFO - 2017-09-05 06:46:21 --> Model Class Initialized
INFO - 2017-09-05 06:46:21 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 06:46:21 --> File loaded: C:\xampp\htdocs\biper\application\views\add_video.php
INFO - 2017-09-05 06:46:21 --> Final output sent to browser
DEBUG - 2017-09-05 06:46:21 --> Total execution time: 0.1170
ERROR - 2017-09-05 06:46:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 06:46:23 --> Config Class Initialized
INFO - 2017-09-05 06:46:23 --> Hooks Class Initialized
DEBUG - 2017-09-05 06:46:23 --> UTF-8 Support Enabled
INFO - 2017-09-05 06:46:23 --> Utf8 Class Initialized
INFO - 2017-09-05 06:46:23 --> URI Class Initialized
INFO - 2017-09-05 06:46:23 --> Router Class Initialized
INFO - 2017-09-05 06:46:23 --> Output Class Initialized
INFO - 2017-09-05 06:46:23 --> Security Class Initialized
DEBUG - 2017-09-05 06:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 06:46:23 --> Input Class Initialized
INFO - 2017-09-05 06:46:23 --> Language Class Initialized
INFO - 2017-09-05 06:46:23 --> Loader Class Initialized
INFO - 2017-09-05 06:46:23 --> Controller Class Initialized
INFO - 2017-09-05 06:46:23 --> Database Driver Class Initialized
INFO - 2017-09-05 06:46:23 --> Model Class Initialized
INFO - 2017-09-05 06:46:23 --> Helper loaded: form_helper
INFO - 2017-09-05 06:46:23 --> Helper loaded: url_helper
INFO - 2017-09-05 06:46:23 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 06:46:23 --> Model Class Initialized
INFO - 2017-09-05 06:46:23 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 06:46:23 --> Final output sent to browser
DEBUG - 2017-09-05 06:46:23 --> Total execution time: 0.0710
ERROR - 2017-09-05 06:48:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 06:48:16 --> Config Class Initialized
INFO - 2017-09-05 06:48:16 --> Hooks Class Initialized
DEBUG - 2017-09-05 06:48:16 --> UTF-8 Support Enabled
INFO - 2017-09-05 06:48:16 --> Utf8 Class Initialized
INFO - 2017-09-05 06:48:16 --> URI Class Initialized
INFO - 2017-09-05 06:48:16 --> Router Class Initialized
INFO - 2017-09-05 06:48:16 --> Output Class Initialized
INFO - 2017-09-05 06:48:16 --> Security Class Initialized
DEBUG - 2017-09-05 06:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 06:48:16 --> Input Class Initialized
INFO - 2017-09-05 06:48:16 --> Language Class Initialized
INFO - 2017-09-05 06:48:16 --> Loader Class Initialized
INFO - 2017-09-05 06:48:16 --> Controller Class Initialized
INFO - 2017-09-05 06:48:16 --> Database Driver Class Initialized
INFO - 2017-09-05 06:48:16 --> Model Class Initialized
INFO - 2017-09-05 06:48:16 --> Helper loaded: form_helper
INFO - 2017-09-05 06:48:16 --> Helper loaded: url_helper
INFO - 2017-09-05 06:48:16 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 06:48:16 --> Model Class Initialized
INFO - 2017-09-05 06:48:16 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 06:48:16 --> Final output sent to browser
DEBUG - 2017-09-05 06:48:16 --> Total execution time: 0.0700
ERROR - 2017-09-05 06:49:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 06:49:34 --> Config Class Initialized
INFO - 2017-09-05 06:49:34 --> Hooks Class Initialized
DEBUG - 2017-09-05 06:49:34 --> UTF-8 Support Enabled
INFO - 2017-09-05 06:49:34 --> Utf8 Class Initialized
INFO - 2017-09-05 06:49:34 --> URI Class Initialized
INFO - 2017-09-05 06:49:34 --> Router Class Initialized
INFO - 2017-09-05 06:49:34 --> Output Class Initialized
INFO - 2017-09-05 06:49:34 --> Security Class Initialized
DEBUG - 2017-09-05 06:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 06:49:34 --> Input Class Initialized
INFO - 2017-09-05 06:49:34 --> Language Class Initialized
INFO - 2017-09-05 06:49:34 --> Loader Class Initialized
INFO - 2017-09-05 06:49:34 --> Controller Class Initialized
INFO - 2017-09-05 06:49:34 --> Database Driver Class Initialized
INFO - 2017-09-05 06:49:34 --> Model Class Initialized
INFO - 2017-09-05 06:49:34 --> Helper loaded: form_helper
INFO - 2017-09-05 06:49:34 --> Helper loaded: url_helper
INFO - 2017-09-05 06:49:34 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 06:49:34 --> Model Class Initialized
INFO - 2017-09-05 06:49:34 --> File loaded: C:\xampp\htdocs\biper\application\views\purchase.php
INFO - 2017-09-05 06:49:34 --> Final output sent to browser
DEBUG - 2017-09-05 06:49:34 --> Total execution time: 0.0820
ERROR - 2017-09-05 06:49:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 06:49:35 --> Config Class Initialized
INFO - 2017-09-05 06:49:35 --> Hooks Class Initialized
DEBUG - 2017-09-05 06:49:35 --> UTF-8 Support Enabled
INFO - 2017-09-05 06:49:35 --> Utf8 Class Initialized
INFO - 2017-09-05 06:49:35 --> URI Class Initialized
INFO - 2017-09-05 06:49:35 --> Router Class Initialized
INFO - 2017-09-05 06:49:35 --> Output Class Initialized
INFO - 2017-09-05 06:49:35 --> Security Class Initialized
DEBUG - 2017-09-05 06:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 06:49:35 --> Input Class Initialized
INFO - 2017-09-05 06:49:35 --> Language Class Initialized
INFO - 2017-09-05 06:49:35 --> Loader Class Initialized
INFO - 2017-09-05 06:49:35 --> Controller Class Initialized
INFO - 2017-09-05 06:49:35 --> Database Driver Class Initialized
INFO - 2017-09-05 06:49:35 --> Model Class Initialized
INFO - 2017-09-05 06:49:35 --> Helper loaded: form_helper
INFO - 2017-09-05 06:49:35 --> Helper loaded: url_helper
INFO - 2017-09-05 06:49:36 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 06:49:36 --> Model Class Initialized
INFO - 2017-09-05 06:49:36 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 06:49:36 --> Final output sent to browser
DEBUG - 2017-09-05 06:49:36 --> Total execution time: 0.0900
ERROR - 2017-09-05 06:50:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 06:50:49 --> Config Class Initialized
INFO - 2017-09-05 06:50:49 --> Hooks Class Initialized
DEBUG - 2017-09-05 06:50:49 --> UTF-8 Support Enabled
INFO - 2017-09-05 06:50:49 --> Utf8 Class Initialized
INFO - 2017-09-05 06:50:49 --> URI Class Initialized
INFO - 2017-09-05 06:50:49 --> Router Class Initialized
INFO - 2017-09-05 06:50:49 --> Output Class Initialized
INFO - 2017-09-05 06:50:49 --> Security Class Initialized
DEBUG - 2017-09-05 06:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 06:50:49 --> Input Class Initialized
INFO - 2017-09-05 06:50:49 --> Language Class Initialized
INFO - 2017-09-05 06:50:49 --> Loader Class Initialized
INFO - 2017-09-05 06:50:49 --> Controller Class Initialized
INFO - 2017-09-05 06:50:49 --> Database Driver Class Initialized
INFO - 2017-09-05 06:50:49 --> Model Class Initialized
INFO - 2017-09-05 06:50:49 --> Helper loaded: form_helper
INFO - 2017-09-05 06:50:49 --> Helper loaded: url_helper
INFO - 2017-09-05 06:50:49 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 06:50:49 --> Model Class Initialized
INFO - 2017-09-05 06:50:49 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 06:50:49 --> Final output sent to browser
DEBUG - 2017-09-05 06:50:49 --> Total execution time: 0.0610
ERROR - 2017-09-05 06:51:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 06:51:18 --> Config Class Initialized
INFO - 2017-09-05 06:51:18 --> Hooks Class Initialized
DEBUG - 2017-09-05 06:51:18 --> UTF-8 Support Enabled
INFO - 2017-09-05 06:51:18 --> Utf8 Class Initialized
INFO - 2017-09-05 06:51:18 --> URI Class Initialized
INFO - 2017-09-05 06:51:18 --> Router Class Initialized
INFO - 2017-09-05 06:51:18 --> Output Class Initialized
INFO - 2017-09-05 06:51:18 --> Security Class Initialized
DEBUG - 2017-09-05 06:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 06:51:18 --> Input Class Initialized
INFO - 2017-09-05 06:51:18 --> Language Class Initialized
INFO - 2017-09-05 06:51:18 --> Loader Class Initialized
INFO - 2017-09-05 06:51:18 --> Controller Class Initialized
INFO - 2017-09-05 06:51:18 --> Database Driver Class Initialized
INFO - 2017-09-05 06:51:18 --> Model Class Initialized
INFO - 2017-09-05 06:51:18 --> Helper loaded: form_helper
INFO - 2017-09-05 06:51:18 --> Helper loaded: url_helper
INFO - 2017-09-05 06:51:18 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 06:51:18 --> Model Class Initialized
INFO - 2017-09-05 06:51:18 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 06:51:19 --> Final output sent to browser
DEBUG - 2017-09-05 06:51:19 --> Total execution time: 0.0610
ERROR - 2017-09-05 06:51:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 06:51:36 --> Config Class Initialized
INFO - 2017-09-05 06:51:36 --> Hooks Class Initialized
DEBUG - 2017-09-05 06:51:37 --> UTF-8 Support Enabled
INFO - 2017-09-05 06:51:37 --> Utf8 Class Initialized
INFO - 2017-09-05 06:51:37 --> URI Class Initialized
INFO - 2017-09-05 06:51:37 --> Router Class Initialized
INFO - 2017-09-05 06:51:37 --> Output Class Initialized
INFO - 2017-09-05 06:51:37 --> Security Class Initialized
DEBUG - 2017-09-05 06:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 06:51:37 --> Input Class Initialized
INFO - 2017-09-05 06:51:37 --> Language Class Initialized
INFO - 2017-09-05 06:51:37 --> Loader Class Initialized
INFO - 2017-09-05 06:51:37 --> Controller Class Initialized
INFO - 2017-09-05 06:51:37 --> Database Driver Class Initialized
INFO - 2017-09-05 06:51:37 --> Model Class Initialized
INFO - 2017-09-05 06:51:37 --> Helper loaded: form_helper
INFO - 2017-09-05 06:51:37 --> Helper loaded: url_helper
INFO - 2017-09-05 06:51:37 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 06:51:37 --> File loaded: C:\xampp\htdocs\biper\application\views\user_profile.php
INFO - 2017-09-05 06:51:37 --> Final output sent to browser
DEBUG - 2017-09-05 06:51:37 --> Total execution time: 0.2000
ERROR - 2017-09-05 06:51:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-05 06:51:45 --> Config Class Initialized
INFO - 2017-09-05 06:51:45 --> Hooks Class Initialized
DEBUG - 2017-09-05 06:51:45 --> UTF-8 Support Enabled
INFO - 2017-09-05 06:51:45 --> Utf8 Class Initialized
INFO - 2017-09-05 06:51:45 --> URI Class Initialized
INFO - 2017-09-05 06:51:45 --> Router Class Initialized
INFO - 2017-09-05 06:51:45 --> Output Class Initialized
INFO - 2017-09-05 06:51:45 --> Security Class Initialized
DEBUG - 2017-09-05 06:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-05 06:51:45 --> Input Class Initialized
INFO - 2017-09-05 06:51:45 --> Language Class Initialized
INFO - 2017-09-05 06:51:45 --> Loader Class Initialized
INFO - 2017-09-05 06:51:45 --> Controller Class Initialized
INFO - 2017-09-05 06:51:45 --> Database Driver Class Initialized
INFO - 2017-09-05 06:51:45 --> Model Class Initialized
INFO - 2017-09-05 06:51:45 --> Helper loaded: form_helper
INFO - 2017-09-05 06:51:45 --> Helper loaded: url_helper
INFO - 2017-09-05 06:51:45 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-05 06:51:45 --> Model Class Initialized
INFO - 2017-09-05 06:51:45 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-05 06:51:45 --> Final output sent to browser
DEBUG - 2017-09-05 06:51:45 --> Total execution time: 0.0600
