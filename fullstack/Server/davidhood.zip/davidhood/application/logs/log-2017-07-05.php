<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-05 16:54:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-05 16:54:02 --> Config Class Initialized
INFO - 2017-07-05 16:54:02 --> Hooks Class Initialized
DEBUG - 2017-07-05 16:54:02 --> UTF-8 Support Enabled
INFO - 2017-07-05 16:54:02 --> Utf8 Class Initialized
INFO - 2017-07-05 16:54:02 --> URI Class Initialized
DEBUG - 2017-07-05 16:54:02 --> No URI present. Default controller set.
INFO - 2017-07-05 16:54:02 --> Router Class Initialized
INFO - 2017-07-05 16:54:02 --> Output Class Initialized
INFO - 2017-07-05 16:54:02 --> Security Class Initialized
DEBUG - 2017-07-05 16:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-05 16:54:02 --> Input Class Initialized
INFO - 2017-07-05 16:54:02 --> Language Class Initialized
INFO - 2017-07-05 16:54:02 --> Loader Class Initialized
INFO - 2017-07-05 16:54:02 --> Controller Class Initialized
INFO - 2017-07-05 16:54:02 --> Database Driver Class Initialized
INFO - 2017-07-05 16:54:02 --> Model Class Initialized
INFO - 2017-07-05 16:54:02 --> Helper loaded: form_helper
INFO - 2017-07-05 16:54:02 --> Helper loaded: url_helper
INFO - 2017-07-05 16:54:02 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-05 16:54:02 --> Final output sent to browser
DEBUG - 2017-07-05 16:54:02 --> Total execution time: 0.0350
ERROR - 2017-07-05 16:54:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-05 16:54:03 --> Config Class Initialized
INFO - 2017-07-05 16:54:03 --> Hooks Class Initialized
DEBUG - 2017-07-05 16:54:03 --> UTF-8 Support Enabled
INFO - 2017-07-05 16:54:03 --> Utf8 Class Initialized
INFO - 2017-07-05 16:54:03 --> URI Class Initialized
INFO - 2017-07-05 16:54:03 --> Router Class Initialized
INFO - 2017-07-05 16:54:03 --> Output Class Initialized
INFO - 2017-07-05 16:54:03 --> Security Class Initialized
DEBUG - 2017-07-05 16:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-05 16:54:03 --> Input Class Initialized
INFO - 2017-07-05 16:54:03 --> Language Class Initialized
INFO - 2017-07-05 16:54:03 --> Loader Class Initialized
INFO - 2017-07-05 16:54:03 --> Controller Class Initialized
INFO - 2017-07-05 16:54:03 --> Database Driver Class Initialized
INFO - 2017-07-05 16:54:03 --> Model Class Initialized
INFO - 2017-07-05 16:54:03 --> Helper loaded: form_helper
INFO - 2017-07-05 16:54:03 --> Helper loaded: url_helper
INFO - 2017-07-05 16:54:03 --> Model Class Initialized
ERROR - 2017-07-05 16:54:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-05 16:54:03 --> Config Class Initialized
INFO - 2017-07-05 16:54:03 --> Hooks Class Initialized
DEBUG - 2017-07-05 16:54:03 --> UTF-8 Support Enabled
INFO - 2017-07-05 16:54:03 --> Utf8 Class Initialized
INFO - 2017-07-05 16:54:03 --> URI Class Initialized
INFO - 2017-07-05 16:54:03 --> Router Class Initialized
INFO - 2017-07-05 16:54:03 --> Output Class Initialized
INFO - 2017-07-05 16:54:03 --> Security Class Initialized
DEBUG - 2017-07-05 16:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-05 16:54:03 --> Input Class Initialized
INFO - 2017-07-05 16:54:03 --> Language Class Initialized
INFO - 2017-07-05 16:54:03 --> Loader Class Initialized
INFO - 2017-07-05 16:54:03 --> Controller Class Initialized
INFO - 2017-07-05 16:54:03 --> Database Driver Class Initialized
INFO - 2017-07-05 16:54:03 --> Model Class Initialized
INFO - 2017-07-05 16:54:03 --> Helper loaded: form_helper
INFO - 2017-07-05 16:54:03 --> Helper loaded: url_helper
INFO - 2017-07-05 16:54:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-05 16:54:03 --> Model Class Initialized
INFO - 2017-07-05 16:54:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-05 16:54:03 --> Final output sent to browser
DEBUG - 2017-07-05 16:54:03 --> Total execution time: 0.0580
ERROR - 2017-07-05 16:54:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-05 16:54:57 --> Config Class Initialized
INFO - 2017-07-05 16:54:57 --> Hooks Class Initialized
DEBUG - 2017-07-05 16:54:57 --> UTF-8 Support Enabled
INFO - 2017-07-05 16:54:57 --> Utf8 Class Initialized
INFO - 2017-07-05 16:54:57 --> URI Class Initialized
INFO - 2017-07-05 16:54:57 --> Router Class Initialized
INFO - 2017-07-05 16:54:57 --> Output Class Initialized
INFO - 2017-07-05 16:54:57 --> Security Class Initialized
DEBUG - 2017-07-05 16:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-05 16:54:57 --> Input Class Initialized
INFO - 2017-07-05 16:54:57 --> Language Class Initialized
INFO - 2017-07-05 16:54:57 --> Loader Class Initialized
INFO - 2017-07-05 16:54:57 --> Controller Class Initialized
INFO - 2017-07-05 16:54:57 --> Database Driver Class Initialized
INFO - 2017-07-05 16:54:57 --> Model Class Initialized
INFO - 2017-07-05 16:54:57 --> Helper loaded: form_helper
INFO - 2017-07-05 16:54:57 --> Helper loaded: url_helper
INFO - 2017-07-05 16:54:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-05 16:54:57 --> Model Class Initialized
INFO - 2017-07-05 16:54:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\users.php
INFO - 2017-07-05 16:54:57 --> Final output sent to browser
DEBUG - 2017-07-05 16:54:57 --> Total execution time: 0.0510
ERROR - 2017-07-05 16:54:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-05 16:54:59 --> Config Class Initialized
INFO - 2017-07-05 16:54:59 --> Hooks Class Initialized
DEBUG - 2017-07-05 16:54:59 --> UTF-8 Support Enabled
INFO - 2017-07-05 16:54:59 --> Utf8 Class Initialized
INFO - 2017-07-05 16:54:59 --> URI Class Initialized
INFO - 2017-07-05 16:54:59 --> Router Class Initialized
INFO - 2017-07-05 16:54:59 --> Output Class Initialized
INFO - 2017-07-05 16:54:59 --> Security Class Initialized
DEBUG - 2017-07-05 16:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-05 16:54:59 --> Input Class Initialized
INFO - 2017-07-05 16:54:59 --> Language Class Initialized
INFO - 2017-07-05 16:54:59 --> Loader Class Initialized
INFO - 2017-07-05 16:54:59 --> Controller Class Initialized
INFO - 2017-07-05 16:54:59 --> Database Driver Class Initialized
INFO - 2017-07-05 16:54:59 --> Model Class Initialized
INFO - 2017-07-05 16:54:59 --> Helper loaded: form_helper
INFO - 2017-07-05 16:54:59 --> Helper loaded: url_helper
INFO - 2017-07-05 16:54:59 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-05 16:54:59 --> Model Class Initialized
INFO - 2017-07-05 16:54:59 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-05 16:54:59 --> Final output sent to browser
DEBUG - 2017-07-05 16:54:59 --> Total execution time: 0.0930
ERROR - 2017-07-05 16:55:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-05 16:55:01 --> Config Class Initialized
INFO - 2017-07-05 16:55:01 --> Hooks Class Initialized
DEBUG - 2017-07-05 16:55:01 --> UTF-8 Support Enabled
INFO - 2017-07-05 16:55:01 --> Utf8 Class Initialized
INFO - 2017-07-05 16:55:01 --> URI Class Initialized
INFO - 2017-07-05 16:55:01 --> Router Class Initialized
INFO - 2017-07-05 16:55:01 --> Output Class Initialized
INFO - 2017-07-05 16:55:01 --> Security Class Initialized
DEBUG - 2017-07-05 16:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-05 16:55:01 --> Input Class Initialized
INFO - 2017-07-05 16:55:01 --> Language Class Initialized
INFO - 2017-07-05 16:55:01 --> Loader Class Initialized
INFO - 2017-07-05 16:55:01 --> Controller Class Initialized
INFO - 2017-07-05 16:55:01 --> Database Driver Class Initialized
INFO - 2017-07-05 16:55:01 --> Model Class Initialized
INFO - 2017-07-05 16:55:01 --> Helper loaded: form_helper
INFO - 2017-07-05 16:55:01 --> Helper loaded: url_helper
INFO - 2017-07-05 16:55:01 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-05 16:55:01 --> Model Class Initialized
INFO - 2017-07-05 16:55:01 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-05 16:55:01 --> Final output sent to browser
DEBUG - 2017-07-05 16:55:01 --> Total execution time: 0.0680
ERROR - 2017-07-05 16:56:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-05 16:56:22 --> Config Class Initialized
INFO - 2017-07-05 16:56:22 --> Hooks Class Initialized
DEBUG - 2017-07-05 16:56:22 --> UTF-8 Support Enabled
INFO - 2017-07-05 16:56:22 --> Utf8 Class Initialized
INFO - 2017-07-05 16:56:22 --> URI Class Initialized
INFO - 2017-07-05 16:56:22 --> Router Class Initialized
INFO - 2017-07-05 16:56:22 --> Output Class Initialized
INFO - 2017-07-05 16:56:22 --> Security Class Initialized
DEBUG - 2017-07-05 16:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-05 16:56:22 --> Input Class Initialized
INFO - 2017-07-05 16:56:22 --> Language Class Initialized
INFO - 2017-07-05 16:56:22 --> Loader Class Initialized
INFO - 2017-07-05 16:56:22 --> Controller Class Initialized
INFO - 2017-07-05 16:56:22 --> Database Driver Class Initialized
INFO - 2017-07-05 16:56:22 --> Model Class Initialized
INFO - 2017-07-05 16:56:22 --> Helper loaded: form_helper
INFO - 2017-07-05 16:56:22 --> Helper loaded: url_helper
INFO - 2017-07-05 16:56:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-05 16:56:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\user_profile.php
INFO - 2017-07-05 16:56:22 --> Final output sent to browser
DEBUG - 2017-07-05 16:56:22 --> Total execution time: 0.1750
ERROR - 2017-07-05 16:56:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-05 16:56:27 --> Config Class Initialized
INFO - 2017-07-05 16:56:27 --> Hooks Class Initialized
DEBUG - 2017-07-05 16:56:27 --> UTF-8 Support Enabled
INFO - 2017-07-05 16:56:27 --> Utf8 Class Initialized
INFO - 2017-07-05 16:56:27 --> URI Class Initialized
INFO - 2017-07-05 16:56:27 --> Router Class Initialized
INFO - 2017-07-05 16:56:27 --> Output Class Initialized
INFO - 2017-07-05 16:56:27 --> Security Class Initialized
DEBUG - 2017-07-05 16:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-05 16:56:27 --> Input Class Initialized
INFO - 2017-07-05 16:56:27 --> Language Class Initialized
INFO - 2017-07-05 16:56:27 --> Loader Class Initialized
INFO - 2017-07-05 16:56:27 --> Controller Class Initialized
INFO - 2017-07-05 16:56:27 --> Database Driver Class Initialized
INFO - 2017-07-05 16:56:27 --> Model Class Initialized
INFO - 2017-07-05 16:56:27 --> Helper loaded: form_helper
INFO - 2017-07-05 16:56:27 --> Helper loaded: url_helper
INFO - 2017-07-05 16:56:27 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-05 16:56:27 --> Model Class Initialized
INFO - 2017-07-05 16:56:27 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-05 16:56:27 --> Final output sent to browser
DEBUG - 2017-07-05 16:56:27 --> Total execution time: 0.0990
ERROR - 2017-07-05 16:56:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-05 16:56:46 --> Config Class Initialized
INFO - 2017-07-05 16:56:46 --> Hooks Class Initialized
DEBUG - 2017-07-05 16:56:46 --> UTF-8 Support Enabled
INFO - 2017-07-05 16:56:46 --> Utf8 Class Initialized
INFO - 2017-07-05 16:56:46 --> URI Class Initialized
INFO - 2017-07-05 16:56:46 --> Router Class Initialized
INFO - 2017-07-05 16:56:46 --> Output Class Initialized
INFO - 2017-07-05 16:56:46 --> Security Class Initialized
DEBUG - 2017-07-05 16:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-05 16:56:46 --> Input Class Initialized
INFO - 2017-07-05 16:56:46 --> Language Class Initialized
INFO - 2017-07-05 16:56:46 --> Loader Class Initialized
INFO - 2017-07-05 16:56:46 --> Controller Class Initialized
INFO - 2017-07-05 16:56:46 --> Database Driver Class Initialized
INFO - 2017-07-05 16:56:46 --> Model Class Initialized
INFO - 2017-07-05 16:56:46 --> Helper loaded: form_helper
INFO - 2017-07-05 16:56:46 --> Helper loaded: url_helper
INFO - 2017-07-05 16:56:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-05 16:56:46 --> Model Class Initialized
INFO - 2017-07-05 16:56:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-05 16:56:46 --> Final output sent to browser
DEBUG - 2017-07-05 16:56:46 --> Total execution time: 0.0490
