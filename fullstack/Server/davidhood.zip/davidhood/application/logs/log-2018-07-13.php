<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-13 06:46:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 06:46:54 --> Config Class Initialized
INFO - 2018-07-13 06:46:54 --> Hooks Class Initialized
DEBUG - 2018-07-13 06:46:54 --> UTF-8 Support Enabled
INFO - 2018-07-13 06:46:54 --> Utf8 Class Initialized
INFO - 2018-07-13 06:46:54 --> URI Class Initialized
INFO - 2018-07-13 06:46:54 --> Router Class Initialized
INFO - 2018-07-13 06:46:54 --> Output Class Initialized
INFO - 2018-07-13 06:46:54 --> Security Class Initialized
DEBUG - 2018-07-13 06:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 06:46:54 --> Input Class Initialized
INFO - 2018-07-13 06:46:54 --> Language Class Initialized
INFO - 2018-07-13 06:46:54 --> Loader Class Initialized
INFO - 2018-07-13 06:46:54 --> Controller Class Initialized
INFO - 2018-07-13 06:46:54 --> Database Driver Class Initialized
INFO - 2018-07-13 06:46:54 --> Model Class Initialized
INFO - 2018-07-13 06:46:54 --> Helper loaded: url_helper
DEBUG - 2018-07-13 06:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 06:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 06:46:54 --> Model Class Initialized
INFO - 2018-07-13 06:46:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 06:46:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-13 06:46:54 --> Final output sent to browser
DEBUG - 2018-07-13 06:46:54 --> Total execution time: 0.1221
ERROR - 2018-07-13 06:47:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 06:47:11 --> Config Class Initialized
INFO - 2018-07-13 06:47:11 --> Hooks Class Initialized
DEBUG - 2018-07-13 06:47:11 --> UTF-8 Support Enabled
INFO - 2018-07-13 06:47:11 --> Utf8 Class Initialized
INFO - 2018-07-13 06:47:11 --> URI Class Initialized
INFO - 2018-07-13 06:47:11 --> Router Class Initialized
INFO - 2018-07-13 06:47:11 --> Output Class Initialized
INFO - 2018-07-13 06:47:11 --> Security Class Initialized
DEBUG - 2018-07-13 06:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 06:47:11 --> Input Class Initialized
INFO - 2018-07-13 06:47:11 --> Language Class Initialized
INFO - 2018-07-13 06:47:11 --> Loader Class Initialized
INFO - 2018-07-13 06:47:11 --> Controller Class Initialized
INFO - 2018-07-13 06:47:11 --> Database Driver Class Initialized
INFO - 2018-07-13 06:47:11 --> Model Class Initialized
INFO - 2018-07-13 06:47:11 --> Helper loaded: url_helper
DEBUG - 2018-07-13 06:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 06:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 06:47:11 --> Model Class Initialized
INFO - 2018-07-13 06:47:11 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 06:47:11 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-13 06:47:11 --> Final output sent to browser
DEBUG - 2018-07-13 06:47:11 --> Total execution time: 0.0393
ERROR - 2018-07-13 06:57:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 06:57:23 --> Config Class Initialized
INFO - 2018-07-13 06:57:23 --> Hooks Class Initialized
DEBUG - 2018-07-13 06:57:23 --> UTF-8 Support Enabled
INFO - 2018-07-13 06:57:23 --> Utf8 Class Initialized
INFO - 2018-07-13 06:57:23 --> URI Class Initialized
INFO - 2018-07-13 06:57:23 --> Router Class Initialized
INFO - 2018-07-13 06:57:23 --> Output Class Initialized
INFO - 2018-07-13 06:57:23 --> Security Class Initialized
DEBUG - 2018-07-13 06:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 06:57:23 --> Input Class Initialized
INFO - 2018-07-13 06:57:23 --> Language Class Initialized
INFO - 2018-07-13 06:57:23 --> Loader Class Initialized
INFO - 2018-07-13 06:57:23 --> Controller Class Initialized
INFO - 2018-07-13 06:57:23 --> Database Driver Class Initialized
INFO - 2018-07-13 06:57:23 --> Model Class Initialized
INFO - 2018-07-13 06:57:23 --> Helper loaded: url_helper
DEBUG - 2018-07-13 06:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 06:57:23 --> Session: Class initialized using 'files' driver.
ERROR - 2018-07-13 06:57:23 --> Severity: error --> Exception: syntax error, unexpected 'return' (T_RETURN), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\davidhood\application\models\Model.php 54
ERROR - 2018-07-13 06:57:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 06:57:47 --> Config Class Initialized
INFO - 2018-07-13 06:57:47 --> Hooks Class Initialized
DEBUG - 2018-07-13 06:57:47 --> UTF-8 Support Enabled
INFO - 2018-07-13 06:57:47 --> Utf8 Class Initialized
INFO - 2018-07-13 06:57:47 --> URI Class Initialized
INFO - 2018-07-13 06:57:47 --> Router Class Initialized
INFO - 2018-07-13 06:57:47 --> Output Class Initialized
INFO - 2018-07-13 06:57:47 --> Security Class Initialized
DEBUG - 2018-07-13 06:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 06:57:47 --> Input Class Initialized
INFO - 2018-07-13 06:57:47 --> Language Class Initialized
INFO - 2018-07-13 06:57:47 --> Loader Class Initialized
INFO - 2018-07-13 06:57:47 --> Controller Class Initialized
INFO - 2018-07-13 06:57:47 --> Database Driver Class Initialized
INFO - 2018-07-13 06:57:47 --> Model Class Initialized
INFO - 2018-07-13 06:57:47 --> Helper loaded: url_helper
DEBUG - 2018-07-13 06:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 06:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 06:57:47 --> Model Class Initialized
INFO - 2018-07-13 06:57:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 06:57:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-13 06:57:47 --> Final output sent to browser
DEBUG - 2018-07-13 06:57:47 --> Total execution time: 0.0374
ERROR - 2018-07-13 06:57:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 06:57:53 --> Config Class Initialized
INFO - 2018-07-13 06:57:53 --> Hooks Class Initialized
DEBUG - 2018-07-13 06:57:53 --> UTF-8 Support Enabled
INFO - 2018-07-13 06:57:53 --> Utf8 Class Initialized
INFO - 2018-07-13 06:57:53 --> URI Class Initialized
INFO - 2018-07-13 06:57:53 --> Router Class Initialized
INFO - 2018-07-13 06:57:53 --> Output Class Initialized
INFO - 2018-07-13 06:57:53 --> Security Class Initialized
DEBUG - 2018-07-13 06:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 06:57:53 --> Input Class Initialized
INFO - 2018-07-13 06:57:53 --> Language Class Initialized
INFO - 2018-07-13 06:57:53 --> Loader Class Initialized
INFO - 2018-07-13 06:57:53 --> Controller Class Initialized
INFO - 2018-07-13 06:57:53 --> Database Driver Class Initialized
INFO - 2018-07-13 06:57:53 --> Model Class Initialized
INFO - 2018-07-13 06:57:53 --> Helper loaded: url_helper
DEBUG - 2018-07-13 06:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 06:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 06:57:53 --> Model Class Initialized
INFO - 2018-07-13 06:57:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 06:57:53 --> Severity: Notice --> Undefined variable: lang C:\xampp\htdocs\davidhood\application\models\Model.php 52
INFO - 2018-07-13 06:57:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 06:57:53 --> Final output sent to browser
DEBUG - 2018-07-13 06:57:53 --> Total execution time: 0.0386
ERROR - 2018-07-13 06:58:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 06:58:09 --> Config Class Initialized
INFO - 2018-07-13 06:58:09 --> Hooks Class Initialized
DEBUG - 2018-07-13 06:58:09 --> UTF-8 Support Enabled
INFO - 2018-07-13 06:58:09 --> Utf8 Class Initialized
INFO - 2018-07-13 06:58:09 --> URI Class Initialized
INFO - 2018-07-13 06:58:09 --> Router Class Initialized
INFO - 2018-07-13 06:58:09 --> Output Class Initialized
INFO - 2018-07-13 06:58:09 --> Security Class Initialized
DEBUG - 2018-07-13 06:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 06:58:09 --> Input Class Initialized
INFO - 2018-07-13 06:58:09 --> Language Class Initialized
INFO - 2018-07-13 06:58:09 --> Loader Class Initialized
INFO - 2018-07-13 06:58:09 --> Controller Class Initialized
INFO - 2018-07-13 06:58:09 --> Database Driver Class Initialized
INFO - 2018-07-13 06:58:09 --> Model Class Initialized
INFO - 2018-07-13 06:58:09 --> Helper loaded: url_helper
DEBUG - 2018-07-13 06:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 06:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 06:58:09 --> Model Class Initialized
INFO - 2018-07-13 06:58:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 06:58:09 --> Query error: Unknown column 'created' in 'order clause' - Invalid query: SELECT *
FROM `tbl_user`
WHERE `deleted` =0
ORDER BY `created` DESC
INFO - 2018-07-13 06:58:09 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-13 06:58:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 06:58:54 --> Config Class Initialized
INFO - 2018-07-13 06:58:54 --> Hooks Class Initialized
DEBUG - 2018-07-13 06:58:54 --> UTF-8 Support Enabled
INFO - 2018-07-13 06:58:54 --> Utf8 Class Initialized
INFO - 2018-07-13 06:58:54 --> URI Class Initialized
INFO - 2018-07-13 06:58:54 --> Router Class Initialized
INFO - 2018-07-13 06:58:54 --> Output Class Initialized
INFO - 2018-07-13 06:58:54 --> Security Class Initialized
DEBUG - 2018-07-13 06:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 06:58:54 --> Input Class Initialized
INFO - 2018-07-13 06:58:54 --> Language Class Initialized
INFO - 2018-07-13 06:58:54 --> Loader Class Initialized
INFO - 2018-07-13 06:58:54 --> Controller Class Initialized
INFO - 2018-07-13 06:58:54 --> Database Driver Class Initialized
INFO - 2018-07-13 06:58:54 --> Model Class Initialized
INFO - 2018-07-13 06:58:54 --> Helper loaded: url_helper
DEBUG - 2018-07-13 06:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 06:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 06:58:54 --> Model Class Initialized
INFO - 2018-07-13 06:58:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 06:58:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 06:58:54 --> Final output sent to browser
DEBUG - 2018-07-13 06:58:54 --> Total execution time: 0.0548
ERROR - 2018-07-13 06:59:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 06:59:50 --> Config Class Initialized
INFO - 2018-07-13 06:59:50 --> Hooks Class Initialized
DEBUG - 2018-07-13 06:59:50 --> UTF-8 Support Enabled
INFO - 2018-07-13 06:59:50 --> Utf8 Class Initialized
INFO - 2018-07-13 06:59:50 --> URI Class Initialized
INFO - 2018-07-13 06:59:50 --> Router Class Initialized
INFO - 2018-07-13 06:59:50 --> Output Class Initialized
INFO - 2018-07-13 06:59:50 --> Security Class Initialized
DEBUG - 2018-07-13 06:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 06:59:50 --> Input Class Initialized
INFO - 2018-07-13 06:59:50 --> Language Class Initialized
INFO - 2018-07-13 06:59:50 --> Loader Class Initialized
INFO - 2018-07-13 06:59:50 --> Controller Class Initialized
INFO - 2018-07-13 06:59:50 --> Database Driver Class Initialized
INFO - 2018-07-13 06:59:50 --> Model Class Initialized
INFO - 2018-07-13 06:59:50 --> Helper loaded: url_helper
DEBUG - 2018-07-13 06:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 06:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 06:59:50 --> Model Class Initialized
INFO - 2018-07-13 06:59:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 06:59:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-13 06:59:50 --> Final output sent to browser
DEBUG - 2018-07-13 06:59:50 --> Total execution time: 0.0593
ERROR - 2018-07-13 06:59:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 06:59:59 --> Config Class Initialized
INFO - 2018-07-13 06:59:59 --> Hooks Class Initialized
DEBUG - 2018-07-13 06:59:59 --> UTF-8 Support Enabled
INFO - 2018-07-13 06:59:59 --> Utf8 Class Initialized
INFO - 2018-07-13 06:59:59 --> URI Class Initialized
INFO - 2018-07-13 06:59:59 --> Router Class Initialized
INFO - 2018-07-13 06:59:59 --> Output Class Initialized
INFO - 2018-07-13 06:59:59 --> Security Class Initialized
DEBUG - 2018-07-13 06:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 06:59:59 --> Input Class Initialized
INFO - 2018-07-13 06:59:59 --> Language Class Initialized
INFO - 2018-07-13 06:59:59 --> Loader Class Initialized
INFO - 2018-07-13 06:59:59 --> Controller Class Initialized
INFO - 2018-07-13 06:59:59 --> Database Driver Class Initialized
INFO - 2018-07-13 06:59:59 --> Model Class Initialized
INFO - 2018-07-13 06:59:59 --> Helper loaded: url_helper
DEBUG - 2018-07-13 06:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 06:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 06:59:59 --> Model Class Initialized
INFO - 2018-07-13 06:59:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 06:59:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 06:59:59 --> Final output sent to browser
DEBUG - 2018-07-13 06:59:59 --> Total execution time: 0.0366
ERROR - 2018-07-13 07:00:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:00:27 --> Config Class Initialized
INFO - 2018-07-13 07:00:27 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:00:27 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:00:27 --> Utf8 Class Initialized
INFO - 2018-07-13 07:00:27 --> URI Class Initialized
INFO - 2018-07-13 07:00:27 --> Router Class Initialized
INFO - 2018-07-13 07:00:27 --> Output Class Initialized
INFO - 2018-07-13 07:00:27 --> Security Class Initialized
DEBUG - 2018-07-13 07:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:00:27 --> Input Class Initialized
INFO - 2018-07-13 07:00:27 --> Language Class Initialized
INFO - 2018-07-13 07:00:27 --> Loader Class Initialized
INFO - 2018-07-13 07:00:27 --> Controller Class Initialized
INFO - 2018-07-13 07:00:27 --> Database Driver Class Initialized
INFO - 2018-07-13 07:00:27 --> Model Class Initialized
INFO - 2018-07-13 07:00:27 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:00:27 --> Model Class Initialized
INFO - 2018-07-13 07:00:27 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:00:27 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 07:00:27 --> Final output sent to browser
DEBUG - 2018-07-13 07:00:27 --> Total execution time: 0.0367
ERROR - 2018-07-13 07:00:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:00:51 --> Config Class Initialized
INFO - 2018-07-13 07:00:51 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:00:51 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:00:51 --> Utf8 Class Initialized
INFO - 2018-07-13 07:00:51 --> URI Class Initialized
INFO - 2018-07-13 07:00:51 --> Router Class Initialized
INFO - 2018-07-13 07:00:51 --> Output Class Initialized
INFO - 2018-07-13 07:00:51 --> Security Class Initialized
DEBUG - 2018-07-13 07:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:00:51 --> Input Class Initialized
INFO - 2018-07-13 07:00:51 --> Language Class Initialized
INFO - 2018-07-13 07:00:51 --> Loader Class Initialized
INFO - 2018-07-13 07:00:51 --> Controller Class Initialized
INFO - 2018-07-13 07:00:51 --> Database Driver Class Initialized
INFO - 2018-07-13 07:00:51 --> Model Class Initialized
INFO - 2018-07-13 07:00:51 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:00:51 --> Model Class Initialized
INFO - 2018-07-13 07:00:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:00:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-13 07:00:51 --> Final output sent to browser
DEBUG - 2018-07-13 07:00:51 --> Total execution time: 0.0481
ERROR - 2018-07-13 07:00:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:00:55 --> Config Class Initialized
INFO - 2018-07-13 07:00:55 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:00:55 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:00:55 --> Utf8 Class Initialized
INFO - 2018-07-13 07:00:55 --> URI Class Initialized
INFO - 2018-07-13 07:00:55 --> Router Class Initialized
INFO - 2018-07-13 07:00:55 --> Output Class Initialized
INFO - 2018-07-13 07:00:55 --> Security Class Initialized
DEBUG - 2018-07-13 07:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:00:55 --> Input Class Initialized
INFO - 2018-07-13 07:00:55 --> Language Class Initialized
INFO - 2018-07-13 07:00:55 --> Loader Class Initialized
INFO - 2018-07-13 07:00:55 --> Controller Class Initialized
INFO - 2018-07-13 07:00:55 --> Database Driver Class Initialized
INFO - 2018-07-13 07:00:55 --> Model Class Initialized
INFO - 2018-07-13 07:00:55 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:00:55 --> Model Class Initialized
INFO - 2018-07-13 07:00:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:00:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 07:00:55 --> Final output sent to browser
DEBUG - 2018-07-13 07:00:55 --> Total execution time: 0.0366
ERROR - 2018-07-13 07:00:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:00:56 --> Config Class Initialized
INFO - 2018-07-13 07:00:56 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:00:56 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:00:56 --> Utf8 Class Initialized
INFO - 2018-07-13 07:00:56 --> URI Class Initialized
INFO - 2018-07-13 07:00:56 --> Router Class Initialized
INFO - 2018-07-13 07:00:56 --> Output Class Initialized
INFO - 2018-07-13 07:00:56 --> Security Class Initialized
DEBUG - 2018-07-13 07:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:00:56 --> Input Class Initialized
INFO - 2018-07-13 07:00:56 --> Language Class Initialized
INFO - 2018-07-13 07:00:56 --> Loader Class Initialized
INFO - 2018-07-13 07:00:56 --> Controller Class Initialized
INFO - 2018-07-13 07:00:56 --> Database Driver Class Initialized
INFO - 2018-07-13 07:00:56 --> Model Class Initialized
INFO - 2018-07-13 07:00:56 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:00:56 --> Model Class Initialized
INFO - 2018-07-13 07:00:56 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:00:56 --> Model Class Initialized
ERROR - 2018-07-13 07:00:56 --> Severity: Notice --> Undefined index: video_id C:\xampp\htdocs\davidhood\application\models\User_model.php 76
ERROR - 2018-07-13 07:00:56 --> Query error: Table 'davidhood.tbl_video' doesn't exist - Invalid query: SELECT *
FROM `tbl_video`
WHERE `id` IS NULL
INFO - 2018-07-13 07:00:56 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-13 07:00:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:00:58 --> Config Class Initialized
INFO - 2018-07-13 07:00:58 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:00:58 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:00:58 --> Utf8 Class Initialized
INFO - 2018-07-13 07:00:58 --> URI Class Initialized
INFO - 2018-07-13 07:00:58 --> Router Class Initialized
INFO - 2018-07-13 07:00:58 --> Output Class Initialized
INFO - 2018-07-13 07:00:58 --> Security Class Initialized
DEBUG - 2018-07-13 07:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:00:58 --> Input Class Initialized
INFO - 2018-07-13 07:00:58 --> Language Class Initialized
INFO - 2018-07-13 07:00:58 --> Loader Class Initialized
INFO - 2018-07-13 07:00:58 --> Controller Class Initialized
INFO - 2018-07-13 07:00:58 --> Database Driver Class Initialized
INFO - 2018-07-13 07:00:58 --> Model Class Initialized
INFO - 2018-07-13 07:00:58 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:00:58 --> Model Class Initialized
INFO - 2018-07-13 07:00:58 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:00:58 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 07:00:58 --> Final output sent to browser
DEBUG - 2018-07-13 07:00:58 --> Total execution time: 0.0368
ERROR - 2018-07-13 07:01:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:01:00 --> Config Class Initialized
INFO - 2018-07-13 07:01:00 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:01:00 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:01:00 --> Utf8 Class Initialized
INFO - 2018-07-13 07:01:00 --> URI Class Initialized
INFO - 2018-07-13 07:01:00 --> Router Class Initialized
INFO - 2018-07-13 07:01:00 --> Output Class Initialized
INFO - 2018-07-13 07:01:00 --> Security Class Initialized
DEBUG - 2018-07-13 07:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:01:00 --> Input Class Initialized
INFO - 2018-07-13 07:01:00 --> Language Class Initialized
INFO - 2018-07-13 07:01:00 --> Loader Class Initialized
INFO - 2018-07-13 07:01:00 --> Controller Class Initialized
INFO - 2018-07-13 07:01:00 --> Database Driver Class Initialized
INFO - 2018-07-13 07:01:00 --> Model Class Initialized
INFO - 2018-07-13 07:01:00 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:01:00 --> Model Class Initialized
INFO - 2018-07-13 07:01:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:01:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 07:01:00 --> Final output sent to browser
DEBUG - 2018-07-13 07:01:00 --> Total execution time: 0.0354
ERROR - 2018-07-13 07:01:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:01:46 --> Config Class Initialized
INFO - 2018-07-13 07:01:46 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:01:46 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:01:46 --> Utf8 Class Initialized
INFO - 2018-07-13 07:01:46 --> URI Class Initialized
INFO - 2018-07-13 07:01:46 --> Router Class Initialized
INFO - 2018-07-13 07:01:46 --> Output Class Initialized
INFO - 2018-07-13 07:01:46 --> Security Class Initialized
DEBUG - 2018-07-13 07:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:01:46 --> Input Class Initialized
INFO - 2018-07-13 07:01:46 --> Language Class Initialized
INFO - 2018-07-13 07:01:46 --> Loader Class Initialized
INFO - 2018-07-13 07:01:46 --> Controller Class Initialized
INFO - 2018-07-13 07:01:46 --> Database Driver Class Initialized
INFO - 2018-07-13 07:01:46 --> Model Class Initialized
INFO - 2018-07-13 07:01:46 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:01:46 --> Model Class Initialized
INFO - 2018-07-13 07:01:46 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:01:46 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 07:01:46 --> Final output sent to browser
DEBUG - 2018-07-13 07:01:46 --> Total execution time: 0.0499
ERROR - 2018-07-13 07:03:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:03:14 --> Config Class Initialized
INFO - 2018-07-13 07:03:14 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:03:14 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:03:14 --> Utf8 Class Initialized
INFO - 2018-07-13 07:03:14 --> URI Class Initialized
INFO - 2018-07-13 07:03:14 --> Router Class Initialized
INFO - 2018-07-13 07:03:14 --> Output Class Initialized
INFO - 2018-07-13 07:03:14 --> Security Class Initialized
DEBUG - 2018-07-13 07:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:03:14 --> Input Class Initialized
INFO - 2018-07-13 07:03:14 --> Language Class Initialized
INFO - 2018-07-13 07:03:14 --> Loader Class Initialized
INFO - 2018-07-13 07:03:14 --> Controller Class Initialized
INFO - 2018-07-13 07:03:14 --> Database Driver Class Initialized
INFO - 2018-07-13 07:03:14 --> Model Class Initialized
INFO - 2018-07-13 07:03:14 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:03:14 --> Model Class Initialized
INFO - 2018-07-13 07:03:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:03:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 07:03:14 --> Final output sent to browser
DEBUG - 2018-07-13 07:03:14 --> Total execution time: 0.0533
ERROR - 2018-07-13 07:03:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:03:16 --> Config Class Initialized
INFO - 2018-07-13 07:03:16 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:03:16 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:03:16 --> Utf8 Class Initialized
INFO - 2018-07-13 07:03:16 --> URI Class Initialized
INFO - 2018-07-13 07:03:16 --> Router Class Initialized
INFO - 2018-07-13 07:03:16 --> Output Class Initialized
INFO - 2018-07-13 07:03:16 --> Security Class Initialized
DEBUG - 2018-07-13 07:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:03:16 --> Input Class Initialized
INFO - 2018-07-13 07:03:16 --> Language Class Initialized
INFO - 2018-07-13 07:03:16 --> Loader Class Initialized
INFO - 2018-07-13 07:03:16 --> Controller Class Initialized
INFO - 2018-07-13 07:03:16 --> Database Driver Class Initialized
INFO - 2018-07-13 07:03:16 --> Model Class Initialized
INFO - 2018-07-13 07:03:16 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:03:16 --> Model Class Initialized
INFO - 2018-07-13 07:03:16 --> Final output sent to browser
DEBUG - 2018-07-13 07:03:16 --> Total execution time: 0.0800
ERROR - 2018-07-13 07:03:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:03:54 --> Config Class Initialized
INFO - 2018-07-13 07:03:54 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:03:54 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:03:54 --> Utf8 Class Initialized
INFO - 2018-07-13 07:03:54 --> URI Class Initialized
INFO - 2018-07-13 07:03:54 --> Router Class Initialized
INFO - 2018-07-13 07:03:54 --> Output Class Initialized
INFO - 2018-07-13 07:03:54 --> Security Class Initialized
DEBUG - 2018-07-13 07:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:03:54 --> Input Class Initialized
INFO - 2018-07-13 07:03:54 --> Language Class Initialized
INFO - 2018-07-13 07:03:54 --> Loader Class Initialized
INFO - 2018-07-13 07:03:54 --> Controller Class Initialized
INFO - 2018-07-13 07:03:54 --> Database Driver Class Initialized
INFO - 2018-07-13 07:03:54 --> Model Class Initialized
INFO - 2018-07-13 07:03:54 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:03:54 --> Model Class Initialized
INFO - 2018-07-13 07:03:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:03:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 07:03:54 --> Final output sent to browser
DEBUG - 2018-07-13 07:03:54 --> Total execution time: 0.0412
ERROR - 2018-07-13 07:04:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:04:01 --> Config Class Initialized
INFO - 2018-07-13 07:04:01 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:04:02 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:04:02 --> Utf8 Class Initialized
INFO - 2018-07-13 07:04:02 --> URI Class Initialized
INFO - 2018-07-13 07:04:02 --> Router Class Initialized
INFO - 2018-07-13 07:04:02 --> Output Class Initialized
INFO - 2018-07-13 07:04:02 --> Security Class Initialized
DEBUG - 2018-07-13 07:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:04:02 --> Input Class Initialized
INFO - 2018-07-13 07:04:02 --> Language Class Initialized
INFO - 2018-07-13 07:04:02 --> Loader Class Initialized
INFO - 2018-07-13 07:04:02 --> Controller Class Initialized
INFO - 2018-07-13 07:04:02 --> Database Driver Class Initialized
INFO - 2018-07-13 07:04:02 --> Model Class Initialized
INFO - 2018-07-13 07:04:02 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:04:02 --> Model Class Initialized
INFO - 2018-07-13 07:04:02 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:04:02 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 07:04:02 --> Final output sent to browser
DEBUG - 2018-07-13 07:04:02 --> Total execution time: 0.0371
ERROR - 2018-07-13 07:04:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:04:03 --> Config Class Initialized
INFO - 2018-07-13 07:04:03 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:04:03 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:04:03 --> Utf8 Class Initialized
INFO - 2018-07-13 07:04:03 --> URI Class Initialized
INFO - 2018-07-13 07:04:03 --> Router Class Initialized
INFO - 2018-07-13 07:04:03 --> Output Class Initialized
INFO - 2018-07-13 07:04:03 --> Security Class Initialized
DEBUG - 2018-07-13 07:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:04:03 --> Input Class Initialized
INFO - 2018-07-13 07:04:03 --> Language Class Initialized
INFO - 2018-07-13 07:04:03 --> Loader Class Initialized
INFO - 2018-07-13 07:04:03 --> Controller Class Initialized
INFO - 2018-07-13 07:04:03 --> Database Driver Class Initialized
INFO - 2018-07-13 07:04:03 --> Model Class Initialized
INFO - 2018-07-13 07:04:03 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:04:03 --> Model Class Initialized
ERROR - 2018-07-13 07:04:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:04:03 --> Config Class Initialized
INFO - 2018-07-13 07:04:03 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:04:03 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:04:03 --> Utf8 Class Initialized
INFO - 2018-07-13 07:04:03 --> URI Class Initialized
INFO - 2018-07-13 07:04:03 --> Router Class Initialized
INFO - 2018-07-13 07:04:03 --> Output Class Initialized
INFO - 2018-07-13 07:04:03 --> Security Class Initialized
DEBUG - 2018-07-13 07:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:04:03 --> Input Class Initialized
INFO - 2018-07-13 07:04:03 --> Language Class Initialized
INFO - 2018-07-13 07:04:03 --> Loader Class Initialized
INFO - 2018-07-13 07:04:03 --> Controller Class Initialized
INFO - 2018-07-13 07:04:03 --> Database Driver Class Initialized
INFO - 2018-07-13 07:04:03 --> Model Class Initialized
INFO - 2018-07-13 07:04:03 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:04:04 --> Model Class Initialized
INFO - 2018-07-13 07:04:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:04:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 07:04:04 --> Final output sent to browser
DEBUG - 2018-07-13 07:04:04 --> Total execution time: 0.0392
ERROR - 2018-07-13 07:04:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:04:07 --> Config Class Initialized
INFO - 2018-07-13 07:04:07 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:04:07 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:04:07 --> Utf8 Class Initialized
INFO - 2018-07-13 07:04:07 --> URI Class Initialized
INFO - 2018-07-13 07:04:07 --> Router Class Initialized
INFO - 2018-07-13 07:04:07 --> Output Class Initialized
INFO - 2018-07-13 07:04:07 --> Security Class Initialized
DEBUG - 2018-07-13 07:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:04:07 --> Input Class Initialized
INFO - 2018-07-13 07:04:07 --> Language Class Initialized
INFO - 2018-07-13 07:04:07 --> Loader Class Initialized
INFO - 2018-07-13 07:04:07 --> Controller Class Initialized
INFO - 2018-07-13 07:04:07 --> Database Driver Class Initialized
INFO - 2018-07-13 07:04:07 --> Model Class Initialized
INFO - 2018-07-13 07:04:07 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:04:07 --> Model Class Initialized
INFO - 2018-07-13 07:04:07 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:04:07 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 07:04:07 --> Final output sent to browser
DEBUG - 2018-07-13 07:04:07 --> Total execution time: 0.0380
ERROR - 2018-07-13 07:04:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:04:18 --> Config Class Initialized
INFO - 2018-07-13 07:04:18 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:04:18 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:04:18 --> Utf8 Class Initialized
INFO - 2018-07-13 07:04:18 --> URI Class Initialized
INFO - 2018-07-13 07:04:18 --> Router Class Initialized
INFO - 2018-07-13 07:04:18 --> Output Class Initialized
INFO - 2018-07-13 07:04:18 --> Security Class Initialized
DEBUG - 2018-07-13 07:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:04:18 --> Input Class Initialized
INFO - 2018-07-13 07:04:18 --> Language Class Initialized
INFO - 2018-07-13 07:04:18 --> Loader Class Initialized
INFO - 2018-07-13 07:04:18 --> Controller Class Initialized
INFO - 2018-07-13 07:04:18 --> Database Driver Class Initialized
INFO - 2018-07-13 07:04:18 --> Model Class Initialized
INFO - 2018-07-13 07:04:18 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:04:18 --> Model Class Initialized
INFO - 2018-07-13 07:04:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:04:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 07:04:18 --> Final output sent to browser
DEBUG - 2018-07-13 07:04:18 --> Total execution time: 0.0469
ERROR - 2018-07-13 07:15:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:15:15 --> Config Class Initialized
INFO - 2018-07-13 07:15:15 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:15:15 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:15:15 --> Utf8 Class Initialized
INFO - 2018-07-13 07:15:15 --> URI Class Initialized
INFO - 2018-07-13 07:15:15 --> Router Class Initialized
INFO - 2018-07-13 07:15:15 --> Output Class Initialized
INFO - 2018-07-13 07:15:15 --> Security Class Initialized
DEBUG - 2018-07-13 07:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:15:15 --> Input Class Initialized
INFO - 2018-07-13 07:15:15 --> Language Class Initialized
ERROR - 2018-07-13 07:15:15 --> Severity: Compile Error --> Cannot redeclare Main::purchase() C:\xampp\htdocs\davidhood\application\controllers\Main.php 115
ERROR - 2018-07-13 07:15:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:15:38 --> Config Class Initialized
INFO - 2018-07-13 07:15:38 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:15:38 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:15:38 --> Utf8 Class Initialized
INFO - 2018-07-13 07:15:38 --> URI Class Initialized
INFO - 2018-07-13 07:15:38 --> Router Class Initialized
INFO - 2018-07-13 07:15:38 --> Output Class Initialized
INFO - 2018-07-13 07:15:38 --> Security Class Initialized
DEBUG - 2018-07-13 07:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:15:38 --> Input Class Initialized
INFO - 2018-07-13 07:15:38 --> Language Class Initialized
INFO - 2018-07-13 07:15:38 --> Loader Class Initialized
INFO - 2018-07-13 07:15:38 --> Controller Class Initialized
INFO - 2018-07-13 07:15:38 --> Database Driver Class Initialized
INFO - 2018-07-13 07:15:38 --> Model Class Initialized
INFO - 2018-07-13 07:15:38 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:15:38 --> Model Class Initialized
INFO - 2018-07-13 07:15:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:15:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 07:15:38 --> Final output sent to browser
DEBUG - 2018-07-13 07:15:38 --> Total execution time: 0.0395
ERROR - 2018-07-13 07:16:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:16:40 --> Config Class Initialized
INFO - 2018-07-13 07:16:40 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:16:40 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:16:40 --> Utf8 Class Initialized
INFO - 2018-07-13 07:16:40 --> URI Class Initialized
INFO - 2018-07-13 07:16:40 --> Router Class Initialized
INFO - 2018-07-13 07:16:40 --> Output Class Initialized
INFO - 2018-07-13 07:16:40 --> Security Class Initialized
DEBUG - 2018-07-13 07:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:16:40 --> Input Class Initialized
INFO - 2018-07-13 07:16:40 --> Language Class Initialized
INFO - 2018-07-13 07:16:40 --> Loader Class Initialized
INFO - 2018-07-13 07:16:40 --> Controller Class Initialized
INFO - 2018-07-13 07:16:40 --> Database Driver Class Initialized
INFO - 2018-07-13 07:16:40 --> Model Class Initialized
INFO - 2018-07-13 07:16:40 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:16:40 --> Model Class Initialized
INFO - 2018-07-13 07:16:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:16:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 07:16:40 --> Final output sent to browser
DEBUG - 2018-07-13 07:16:40 --> Total execution time: 0.0487
ERROR - 2018-07-13 07:17:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:17:22 --> Config Class Initialized
INFO - 2018-07-13 07:17:22 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:17:22 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:17:22 --> Utf8 Class Initialized
INFO - 2018-07-13 07:17:22 --> URI Class Initialized
INFO - 2018-07-13 07:17:22 --> Router Class Initialized
INFO - 2018-07-13 07:17:22 --> Output Class Initialized
INFO - 2018-07-13 07:17:22 --> Security Class Initialized
DEBUG - 2018-07-13 07:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:17:22 --> Input Class Initialized
INFO - 2018-07-13 07:17:22 --> Language Class Initialized
INFO - 2018-07-13 07:17:22 --> Loader Class Initialized
INFO - 2018-07-13 07:17:22 --> Controller Class Initialized
INFO - 2018-07-13 07:17:22 --> Database Driver Class Initialized
INFO - 2018-07-13 07:17:22 --> Model Class Initialized
INFO - 2018-07-13 07:17:22 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:17:22 --> Model Class Initialized
INFO - 2018-07-13 07:17:22 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:17:22 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 07:17:22 --> Final output sent to browser
DEBUG - 2018-07-13 07:17:22 --> Total execution time: 0.0421
ERROR - 2018-07-13 07:17:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:17:41 --> Config Class Initialized
INFO - 2018-07-13 07:17:41 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:17:41 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:17:41 --> Utf8 Class Initialized
INFO - 2018-07-13 07:17:41 --> URI Class Initialized
INFO - 2018-07-13 07:17:41 --> Router Class Initialized
INFO - 2018-07-13 07:17:41 --> Output Class Initialized
INFO - 2018-07-13 07:17:41 --> Security Class Initialized
DEBUG - 2018-07-13 07:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:17:41 --> Input Class Initialized
INFO - 2018-07-13 07:17:41 --> Language Class Initialized
INFO - 2018-07-13 07:17:41 --> Loader Class Initialized
INFO - 2018-07-13 07:17:41 --> Controller Class Initialized
INFO - 2018-07-13 07:17:41 --> Database Driver Class Initialized
INFO - 2018-07-13 07:17:41 --> Model Class Initialized
INFO - 2018-07-13 07:17:41 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:17:41 --> Model Class Initialized
INFO - 2018-07-13 07:17:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:17:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 07:17:41 --> Final output sent to browser
DEBUG - 2018-07-13 07:17:41 --> Total execution time: 0.0480
ERROR - 2018-07-13 07:17:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:17:54 --> Config Class Initialized
INFO - 2018-07-13 07:17:54 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:17:54 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:17:54 --> Utf8 Class Initialized
INFO - 2018-07-13 07:17:54 --> URI Class Initialized
INFO - 2018-07-13 07:17:54 --> Router Class Initialized
INFO - 2018-07-13 07:17:54 --> Output Class Initialized
INFO - 2018-07-13 07:17:54 --> Security Class Initialized
DEBUG - 2018-07-13 07:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:17:54 --> Input Class Initialized
INFO - 2018-07-13 07:17:54 --> Language Class Initialized
INFO - 2018-07-13 07:17:54 --> Loader Class Initialized
INFO - 2018-07-13 07:17:54 --> Controller Class Initialized
INFO - 2018-07-13 07:17:54 --> Database Driver Class Initialized
INFO - 2018-07-13 07:17:54 --> Model Class Initialized
INFO - 2018-07-13 07:17:54 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:17:54 --> Model Class Initialized
INFO - 2018-07-13 07:17:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:17:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 07:17:54 --> Final output sent to browser
DEBUG - 2018-07-13 07:17:54 --> Total execution time: 0.0423
ERROR - 2018-07-13 07:26:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:26:50 --> Config Class Initialized
INFO - 2018-07-13 07:26:50 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:26:50 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:26:50 --> Utf8 Class Initialized
INFO - 2018-07-13 07:26:50 --> URI Class Initialized
INFO - 2018-07-13 07:26:50 --> Router Class Initialized
INFO - 2018-07-13 07:26:50 --> Output Class Initialized
INFO - 2018-07-13 07:26:50 --> Security Class Initialized
DEBUG - 2018-07-13 07:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:26:50 --> Input Class Initialized
INFO - 2018-07-13 07:26:50 --> Language Class Initialized
INFO - 2018-07-13 07:26:50 --> Loader Class Initialized
INFO - 2018-07-13 07:26:50 --> Controller Class Initialized
INFO - 2018-07-13 07:26:50 --> Database Driver Class Initialized
INFO - 2018-07-13 07:26:50 --> Model Class Initialized
INFO - 2018-07-13 07:26:50 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:26:50 --> Model Class Initialized
INFO - 2018-07-13 07:26:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:26:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 07:26:50 --> Final output sent to browser
DEBUG - 2018-07-13 07:26:50 --> Total execution time: 0.0937
ERROR - 2018-07-13 07:26:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:26:51 --> Config Class Initialized
INFO - 2018-07-13 07:26:51 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:26:51 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:26:51 --> Utf8 Class Initialized
INFO - 2018-07-13 07:26:51 --> URI Class Initialized
INFO - 2018-07-13 07:26:51 --> Router Class Initialized
INFO - 2018-07-13 07:26:51 --> Output Class Initialized
INFO - 2018-07-13 07:26:51 --> Security Class Initialized
DEBUG - 2018-07-13 07:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:26:51 --> Input Class Initialized
INFO - 2018-07-13 07:26:51 --> Language Class Initialized
INFO - 2018-07-13 07:26:51 --> Loader Class Initialized
INFO - 2018-07-13 07:26:51 --> Controller Class Initialized
INFO - 2018-07-13 07:26:51 --> Database Driver Class Initialized
INFO - 2018-07-13 07:26:51 --> Model Class Initialized
INFO - 2018-07-13 07:26:51 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:26:51 --> Model Class Initialized
INFO - 2018-07-13 07:26:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 07:26:51 --> Severity: error --> Exception: Call to undefined method Model::get_purchase() C:\xampp\htdocs\davidhood\application\controllers\Main.php 94
ERROR - 2018-07-13 07:27:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:27:49 --> Config Class Initialized
INFO - 2018-07-13 07:27:49 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:27:49 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:27:49 --> Utf8 Class Initialized
INFO - 2018-07-13 07:27:49 --> URI Class Initialized
INFO - 2018-07-13 07:27:49 --> Router Class Initialized
INFO - 2018-07-13 07:27:49 --> Output Class Initialized
INFO - 2018-07-13 07:27:49 --> Security Class Initialized
DEBUG - 2018-07-13 07:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:27:49 --> Input Class Initialized
INFO - 2018-07-13 07:27:49 --> Language Class Initialized
INFO - 2018-07-13 07:27:49 --> Loader Class Initialized
INFO - 2018-07-13 07:27:49 --> Controller Class Initialized
INFO - 2018-07-13 07:27:49 --> Database Driver Class Initialized
INFO - 2018-07-13 07:27:49 --> Model Class Initialized
INFO - 2018-07-13 07:27:49 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:27:49 --> Model Class Initialized
INFO - 2018-07-13 07:27:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 07:27:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\davidhood\application\views\purchase.php 57
ERROR - 2018-07-13 07:27:49 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\davidhood\application\views\purchase.php 65
ERROR - 2018-07-13 07:27:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\davidhood\application\views\purchase.php 57
INFO - 2018-07-13 07:27:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 07:27:49 --> Final output sent to browser
DEBUG - 2018-07-13 07:27:49 --> Total execution time: 0.0586
ERROR - 2018-07-13 07:28:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:28:43 --> Config Class Initialized
INFO - 2018-07-13 07:28:43 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:28:43 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:28:43 --> Utf8 Class Initialized
INFO - 2018-07-13 07:28:43 --> URI Class Initialized
INFO - 2018-07-13 07:28:43 --> Router Class Initialized
INFO - 2018-07-13 07:28:43 --> Output Class Initialized
INFO - 2018-07-13 07:28:43 --> Security Class Initialized
DEBUG - 2018-07-13 07:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:28:43 --> Input Class Initialized
INFO - 2018-07-13 07:28:43 --> Language Class Initialized
INFO - 2018-07-13 07:28:43 --> Loader Class Initialized
INFO - 2018-07-13 07:28:43 --> Controller Class Initialized
INFO - 2018-07-13 07:28:43 --> Database Driver Class Initialized
INFO - 2018-07-13 07:28:43 --> Model Class Initialized
INFO - 2018-07-13 07:28:43 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:28:43 --> Model Class Initialized
INFO - 2018-07-13 07:28:43 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 07:28:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\davidhood\application\views\purchase.php 57
ERROR - 2018-07-13 07:28:43 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\davidhood\application\views\purchase.php 65
ERROR - 2018-07-13 07:28:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\davidhood\application\views\purchase.php 57
INFO - 2018-07-13 07:28:43 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 07:28:43 --> Final output sent to browser
DEBUG - 2018-07-13 07:28:43 --> Total execution time: 0.0621
ERROR - 2018-07-13 07:29:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:29:00 --> Config Class Initialized
INFO - 2018-07-13 07:29:00 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:29:00 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:29:00 --> Utf8 Class Initialized
INFO - 2018-07-13 07:29:00 --> URI Class Initialized
INFO - 2018-07-13 07:29:00 --> Router Class Initialized
INFO - 2018-07-13 07:29:00 --> Output Class Initialized
INFO - 2018-07-13 07:29:00 --> Security Class Initialized
DEBUG - 2018-07-13 07:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:29:00 --> Input Class Initialized
INFO - 2018-07-13 07:29:00 --> Language Class Initialized
INFO - 2018-07-13 07:29:00 --> Loader Class Initialized
INFO - 2018-07-13 07:29:00 --> Controller Class Initialized
INFO - 2018-07-13 07:29:00 --> Database Driver Class Initialized
INFO - 2018-07-13 07:29:00 --> Model Class Initialized
INFO - 2018-07-13 07:29:00 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:29:00 --> Model Class Initialized
INFO - 2018-07-13 07:29:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 07:29:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\davidhood\application\views\purchase.php 57
ERROR - 2018-07-13 07:29:00 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\davidhood\application\views\purchase.php 65
ERROR - 2018-07-13 07:29:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\davidhood\application\views\purchase.php 57
INFO - 2018-07-13 07:29:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 07:29:00 --> Final output sent to browser
DEBUG - 2018-07-13 07:29:00 --> Total execution time: 0.0395
ERROR - 2018-07-13 07:29:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:29:35 --> Config Class Initialized
INFO - 2018-07-13 07:29:35 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:29:35 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:29:35 --> Utf8 Class Initialized
INFO - 2018-07-13 07:29:35 --> URI Class Initialized
INFO - 2018-07-13 07:29:35 --> Router Class Initialized
INFO - 2018-07-13 07:29:35 --> Output Class Initialized
INFO - 2018-07-13 07:29:35 --> Security Class Initialized
DEBUG - 2018-07-13 07:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:29:35 --> Input Class Initialized
INFO - 2018-07-13 07:29:35 --> Language Class Initialized
INFO - 2018-07-13 07:29:35 --> Loader Class Initialized
INFO - 2018-07-13 07:29:35 --> Controller Class Initialized
INFO - 2018-07-13 07:29:35 --> Database Driver Class Initialized
INFO - 2018-07-13 07:29:35 --> Model Class Initialized
INFO - 2018-07-13 07:29:35 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:29:35 --> Model Class Initialized
INFO - 2018-07-13 07:29:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 07:29:35 --> Severity: Notice --> Undefined index: user C:\xampp\htdocs\davidhood\application\views\purchase.php 60
ERROR - 2018-07-13 07:29:35 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\davidhood\application\views\purchase.php 63
ERROR - 2018-07-13 07:29:35 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\davidhood\application\views\purchase.php 65
INFO - 2018-07-13 07:29:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 07:29:35 --> Final output sent to browser
DEBUG - 2018-07-13 07:29:35 --> Total execution time: 0.0450
ERROR - 2018-07-13 07:31:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:31:32 --> Config Class Initialized
INFO - 2018-07-13 07:31:32 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:31:32 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:31:32 --> Utf8 Class Initialized
INFO - 2018-07-13 07:31:32 --> URI Class Initialized
INFO - 2018-07-13 07:31:32 --> Router Class Initialized
INFO - 2018-07-13 07:31:32 --> Output Class Initialized
INFO - 2018-07-13 07:31:32 --> Security Class Initialized
DEBUG - 2018-07-13 07:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:31:32 --> Input Class Initialized
INFO - 2018-07-13 07:31:32 --> Language Class Initialized
INFO - 2018-07-13 07:31:32 --> Loader Class Initialized
INFO - 2018-07-13 07:31:32 --> Controller Class Initialized
INFO - 2018-07-13 07:31:32 --> Database Driver Class Initialized
INFO - 2018-07-13 07:31:32 --> Model Class Initialized
INFO - 2018-07-13 07:31:32 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:31:32 --> Model Class Initialized
INFO - 2018-07-13 07:31:32 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 07:31:32 --> Severity: error --> Exception: Call to a member function result_array() on array C:\xampp\htdocs\davidhood\application\models\Model.php 61
ERROR - 2018-07-13 07:32:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:32:00 --> Config Class Initialized
INFO - 2018-07-13 07:32:00 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:32:00 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:32:00 --> Utf8 Class Initialized
INFO - 2018-07-13 07:32:00 --> URI Class Initialized
INFO - 2018-07-13 07:32:00 --> Router Class Initialized
INFO - 2018-07-13 07:32:00 --> Output Class Initialized
INFO - 2018-07-13 07:32:00 --> Security Class Initialized
DEBUG - 2018-07-13 07:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:32:00 --> Input Class Initialized
INFO - 2018-07-13 07:32:00 --> Language Class Initialized
INFO - 2018-07-13 07:32:00 --> Loader Class Initialized
INFO - 2018-07-13 07:32:00 --> Controller Class Initialized
INFO - 2018-07-13 07:32:00 --> Database Driver Class Initialized
INFO - 2018-07-13 07:32:00 --> Model Class Initialized
INFO - 2018-07-13 07:32:00 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:32:00 --> Model Class Initialized
INFO - 2018-07-13 07:32:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 07:32:00 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\davidhood\application\views\purchase.php 60
ERROR - 2018-07-13 07:32:00 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\davidhood\application\views\purchase.php 63
ERROR - 2018-07-13 07:32:00 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\davidhood\application\views\purchase.php 65
INFO - 2018-07-13 07:32:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 07:32:00 --> Final output sent to browser
DEBUG - 2018-07-13 07:32:00 --> Total execution time: 0.0421
ERROR - 2018-07-13 07:32:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:32:51 --> Config Class Initialized
INFO - 2018-07-13 07:32:51 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:32:51 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:32:51 --> Utf8 Class Initialized
INFO - 2018-07-13 07:32:51 --> URI Class Initialized
INFO - 2018-07-13 07:32:51 --> Router Class Initialized
INFO - 2018-07-13 07:32:51 --> Output Class Initialized
INFO - 2018-07-13 07:32:51 --> Security Class Initialized
DEBUG - 2018-07-13 07:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:32:51 --> Input Class Initialized
INFO - 2018-07-13 07:32:51 --> Language Class Initialized
INFO - 2018-07-13 07:32:51 --> Loader Class Initialized
INFO - 2018-07-13 07:32:51 --> Controller Class Initialized
INFO - 2018-07-13 07:32:51 --> Database Driver Class Initialized
INFO - 2018-07-13 07:32:51 --> Model Class Initialized
INFO - 2018-07-13 07:32:51 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:32:51 --> Model Class Initialized
INFO - 2018-07-13 07:32:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 07:32:51 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\davidhood\application\views\purchase.php 60
ERROR - 2018-07-13 07:32:51 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\davidhood\application\views\purchase.php 63
ERROR - 2018-07-13 07:32:51 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\davidhood\application\views\purchase.php 65
INFO - 2018-07-13 07:32:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 07:32:51 --> Final output sent to browser
DEBUG - 2018-07-13 07:32:51 --> Total execution time: 0.0421
ERROR - 2018-07-13 07:33:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:33:17 --> Config Class Initialized
INFO - 2018-07-13 07:33:17 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:33:17 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:33:17 --> Utf8 Class Initialized
INFO - 2018-07-13 07:33:17 --> URI Class Initialized
INFO - 2018-07-13 07:33:17 --> Router Class Initialized
INFO - 2018-07-13 07:33:17 --> Output Class Initialized
INFO - 2018-07-13 07:33:17 --> Security Class Initialized
DEBUG - 2018-07-13 07:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:33:17 --> Input Class Initialized
INFO - 2018-07-13 07:33:17 --> Language Class Initialized
INFO - 2018-07-13 07:33:17 --> Loader Class Initialized
INFO - 2018-07-13 07:33:17 --> Controller Class Initialized
INFO - 2018-07-13 07:33:17 --> Database Driver Class Initialized
INFO - 2018-07-13 07:33:17 --> Model Class Initialized
INFO - 2018-07-13 07:33:17 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:33:17 --> Model Class Initialized
INFO - 2018-07-13 07:33:17 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 07:33:17 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\davidhood\application\views\purchase.php 60
ERROR - 2018-07-13 07:33:17 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\davidhood\application\views\purchase.php 63
ERROR - 2018-07-13 07:33:17 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\davidhood\application\views\purchase.php 65
INFO - 2018-07-13 07:33:17 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 07:33:17 --> Final output sent to browser
DEBUG - 2018-07-13 07:33:17 --> Total execution time: 0.0390
ERROR - 2018-07-13 07:33:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:33:34 --> Config Class Initialized
INFO - 2018-07-13 07:33:34 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:33:34 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:33:34 --> Utf8 Class Initialized
INFO - 2018-07-13 07:33:34 --> URI Class Initialized
INFO - 2018-07-13 07:33:34 --> Router Class Initialized
INFO - 2018-07-13 07:33:34 --> Output Class Initialized
INFO - 2018-07-13 07:33:34 --> Security Class Initialized
DEBUG - 2018-07-13 07:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:33:34 --> Input Class Initialized
INFO - 2018-07-13 07:33:34 --> Language Class Initialized
INFO - 2018-07-13 07:33:34 --> Loader Class Initialized
INFO - 2018-07-13 07:33:34 --> Controller Class Initialized
INFO - 2018-07-13 07:33:34 --> Database Driver Class Initialized
INFO - 2018-07-13 07:33:34 --> Model Class Initialized
INFO - 2018-07-13 07:33:34 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:33:34 --> Model Class Initialized
INFO - 2018-07-13 07:33:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 07:33:34 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\davidhood\application\views\purchase.php 60
ERROR - 2018-07-13 07:33:34 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\davidhood\application\views\purchase.php 63
ERROR - 2018-07-13 07:33:34 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\davidhood\application\views\purchase.php 65
INFO - 2018-07-13 07:33:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 07:33:34 --> Final output sent to browser
DEBUG - 2018-07-13 07:33:34 --> Total execution time: 0.0531
ERROR - 2018-07-13 07:34:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:34:06 --> Config Class Initialized
INFO - 2018-07-13 07:34:06 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:34:06 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:34:06 --> Utf8 Class Initialized
INFO - 2018-07-13 07:34:06 --> URI Class Initialized
INFO - 2018-07-13 07:34:06 --> Router Class Initialized
INFO - 2018-07-13 07:34:06 --> Output Class Initialized
INFO - 2018-07-13 07:34:06 --> Security Class Initialized
DEBUG - 2018-07-13 07:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:34:06 --> Input Class Initialized
INFO - 2018-07-13 07:34:06 --> Language Class Initialized
INFO - 2018-07-13 07:34:06 --> Loader Class Initialized
INFO - 2018-07-13 07:34:06 --> Controller Class Initialized
INFO - 2018-07-13 07:34:06 --> Database Driver Class Initialized
INFO - 2018-07-13 07:34:06 --> Model Class Initialized
INFO - 2018-07-13 07:34:06 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:34:06 --> Model Class Initialized
INFO - 2018-07-13 07:34:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 07:34:06 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\davidhood\application\views\purchase.php 63
ERROR - 2018-07-13 07:34:06 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\davidhood\application\views\purchase.php 65
INFO - 2018-07-13 07:34:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 07:34:06 --> Final output sent to browser
DEBUG - 2018-07-13 07:34:06 --> Total execution time: 0.0432
ERROR - 2018-07-13 07:37:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:37:03 --> Config Class Initialized
INFO - 2018-07-13 07:37:03 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:37:03 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:37:03 --> Utf8 Class Initialized
INFO - 2018-07-13 07:37:03 --> URI Class Initialized
INFO - 2018-07-13 07:37:03 --> Router Class Initialized
INFO - 2018-07-13 07:37:03 --> Output Class Initialized
INFO - 2018-07-13 07:37:03 --> Security Class Initialized
DEBUG - 2018-07-13 07:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:37:03 --> Input Class Initialized
INFO - 2018-07-13 07:37:03 --> Language Class Initialized
INFO - 2018-07-13 07:37:03 --> Loader Class Initialized
INFO - 2018-07-13 07:37:03 --> Controller Class Initialized
INFO - 2018-07-13 07:37:03 --> Database Driver Class Initialized
INFO - 2018-07-13 07:37:03 --> Model Class Initialized
INFO - 2018-07-13 07:37:03 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:37:03 --> Model Class Initialized
INFO - 2018-07-13 07:37:03 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 07:37:03 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\davidhood\application\views\purchase.php 65
INFO - 2018-07-13 07:37:03 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 07:37:03 --> Final output sent to browser
DEBUG - 2018-07-13 07:37:03 --> Total execution time: 0.0495
ERROR - 2018-07-13 07:38:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:38:09 --> Config Class Initialized
INFO - 2018-07-13 07:38:09 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:38:09 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:38:09 --> Utf8 Class Initialized
INFO - 2018-07-13 07:38:09 --> URI Class Initialized
INFO - 2018-07-13 07:38:09 --> Router Class Initialized
INFO - 2018-07-13 07:38:09 --> Output Class Initialized
INFO - 2018-07-13 07:38:09 --> Security Class Initialized
DEBUG - 2018-07-13 07:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:38:09 --> Input Class Initialized
INFO - 2018-07-13 07:38:09 --> Language Class Initialized
INFO - 2018-07-13 07:38:09 --> Loader Class Initialized
INFO - 2018-07-13 07:38:09 --> Controller Class Initialized
INFO - 2018-07-13 07:38:09 --> Database Driver Class Initialized
INFO - 2018-07-13 07:38:09 --> Model Class Initialized
INFO - 2018-07-13 07:38:09 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:38:09 --> Model Class Initialized
INFO - 2018-07-13 07:38:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:38:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 07:38:09 --> Final output sent to browser
DEBUG - 2018-07-13 07:38:09 --> Total execution time: 0.0505
ERROR - 2018-07-13 07:40:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:40:25 --> Config Class Initialized
INFO - 2018-07-13 07:40:25 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:40:25 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:40:25 --> Utf8 Class Initialized
INFO - 2018-07-13 07:40:25 --> URI Class Initialized
INFO - 2018-07-13 07:40:25 --> Router Class Initialized
INFO - 2018-07-13 07:40:25 --> Output Class Initialized
INFO - 2018-07-13 07:40:25 --> Security Class Initialized
DEBUG - 2018-07-13 07:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:40:25 --> Input Class Initialized
INFO - 2018-07-13 07:40:25 --> Language Class Initialized
INFO - 2018-07-13 07:40:25 --> Loader Class Initialized
INFO - 2018-07-13 07:40:25 --> Controller Class Initialized
INFO - 2018-07-13 07:40:25 --> Database Driver Class Initialized
INFO - 2018-07-13 07:40:25 --> Model Class Initialized
INFO - 2018-07-13 07:40:25 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:40:25 --> Model Class Initialized
INFO - 2018-07-13 07:40:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 07:40:25 --> Severity: error --> Exception: syntax error, unexpected 'id' (T_STRING), expecting ',' or ';' C:\xampp\htdocs\davidhood\application\views\purchase.php 62
ERROR - 2018-07-13 07:40:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:40:41 --> Config Class Initialized
INFO - 2018-07-13 07:40:41 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:40:41 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:40:41 --> Utf8 Class Initialized
INFO - 2018-07-13 07:40:41 --> URI Class Initialized
INFO - 2018-07-13 07:40:41 --> Router Class Initialized
INFO - 2018-07-13 07:40:41 --> Output Class Initialized
INFO - 2018-07-13 07:40:41 --> Security Class Initialized
DEBUG - 2018-07-13 07:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:40:41 --> Input Class Initialized
INFO - 2018-07-13 07:40:41 --> Language Class Initialized
INFO - 2018-07-13 07:40:41 --> Loader Class Initialized
INFO - 2018-07-13 07:40:41 --> Controller Class Initialized
INFO - 2018-07-13 07:40:41 --> Database Driver Class Initialized
INFO - 2018-07-13 07:40:41 --> Model Class Initialized
INFO - 2018-07-13 07:40:41 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:40:41 --> Model Class Initialized
INFO - 2018-07-13 07:40:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 07:40:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 07:40:41 --> Final output sent to browser
DEBUG - 2018-07-13 07:40:41 --> Total execution time: 0.0356
ERROR - 2018-07-13 07:45:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 07:45:28 --> Config Class Initialized
INFO - 2018-07-13 07:45:28 --> Hooks Class Initialized
DEBUG - 2018-07-13 07:45:28 --> UTF-8 Support Enabled
INFO - 2018-07-13 07:45:28 --> Utf8 Class Initialized
INFO - 2018-07-13 07:45:28 --> URI Class Initialized
INFO - 2018-07-13 07:45:28 --> Router Class Initialized
INFO - 2018-07-13 07:45:28 --> Output Class Initialized
INFO - 2018-07-13 07:45:28 --> Security Class Initialized
DEBUG - 2018-07-13 07:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 07:45:28 --> Input Class Initialized
INFO - 2018-07-13 07:45:28 --> Language Class Initialized
INFO - 2018-07-13 07:45:28 --> Loader Class Initialized
INFO - 2018-07-13 07:45:28 --> Controller Class Initialized
INFO - 2018-07-13 07:45:28 --> Database Driver Class Initialized
INFO - 2018-07-13 07:45:28 --> Model Class Initialized
INFO - 2018-07-13 07:45:28 --> Helper loaded: url_helper
DEBUG - 2018-07-13 07:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 07:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 07:45:28 --> Model Class Initialized
INFO - 2018-07-13 07:45:28 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 07:45:28 --> Severity: error --> Exception: syntax error, unexpected '"', expecting ',' or ';' C:\xampp\htdocs\davidhood\application\views\purchase.php 62
ERROR - 2018-07-13 09:01:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:01:06 --> Config Class Initialized
INFO - 2018-07-13 09:01:06 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:01:06 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:01:06 --> Utf8 Class Initialized
INFO - 2018-07-13 09:01:06 --> URI Class Initialized
INFO - 2018-07-13 09:01:06 --> Router Class Initialized
INFO - 2018-07-13 09:01:06 --> Output Class Initialized
INFO - 2018-07-13 09:01:06 --> Security Class Initialized
DEBUG - 2018-07-13 09:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:01:06 --> Input Class Initialized
INFO - 2018-07-13 09:01:06 --> Language Class Initialized
INFO - 2018-07-13 09:01:06 --> Loader Class Initialized
INFO - 2018-07-13 09:01:06 --> Controller Class Initialized
INFO - 2018-07-13 09:01:06 --> Database Driver Class Initialized
INFO - 2018-07-13 09:01:06 --> Model Class Initialized
INFO - 2018-07-13 09:01:06 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:01:06 --> Model Class Initialized
INFO - 2018-07-13 09:01:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 09:01:06 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\davidhood\application\views\purchase.php 90
ERROR - 2018-07-13 09:01:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:01:22 --> Config Class Initialized
INFO - 2018-07-13 09:01:22 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:01:22 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:01:22 --> Utf8 Class Initialized
INFO - 2018-07-13 09:01:22 --> URI Class Initialized
INFO - 2018-07-13 09:01:22 --> Router Class Initialized
INFO - 2018-07-13 09:01:22 --> Output Class Initialized
INFO - 2018-07-13 09:01:22 --> Security Class Initialized
DEBUG - 2018-07-13 09:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:01:22 --> Input Class Initialized
INFO - 2018-07-13 09:01:22 --> Language Class Initialized
INFO - 2018-07-13 09:01:22 --> Loader Class Initialized
INFO - 2018-07-13 09:01:22 --> Controller Class Initialized
INFO - 2018-07-13 09:01:22 --> Database Driver Class Initialized
INFO - 2018-07-13 09:01:22 --> Model Class Initialized
INFO - 2018-07-13 09:01:22 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:01:22 --> Model Class Initialized
INFO - 2018-07-13 09:01:22 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 09:01:22 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\davidhood\application\views\purchase.php 90
ERROR - 2018-07-13 09:01:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:01:23 --> Config Class Initialized
INFO - 2018-07-13 09:01:23 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:01:23 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:01:23 --> Utf8 Class Initialized
INFO - 2018-07-13 09:01:23 --> URI Class Initialized
INFO - 2018-07-13 09:01:23 --> Router Class Initialized
INFO - 2018-07-13 09:01:23 --> Output Class Initialized
INFO - 2018-07-13 09:01:23 --> Security Class Initialized
DEBUG - 2018-07-13 09:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:01:23 --> Input Class Initialized
INFO - 2018-07-13 09:01:23 --> Language Class Initialized
INFO - 2018-07-13 09:01:23 --> Loader Class Initialized
INFO - 2018-07-13 09:01:23 --> Controller Class Initialized
INFO - 2018-07-13 09:01:23 --> Database Driver Class Initialized
INFO - 2018-07-13 09:01:23 --> Model Class Initialized
INFO - 2018-07-13 09:01:23 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:01:23 --> Model Class Initialized
INFO - 2018-07-13 09:01:23 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 09:01:23 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\davidhood\application\views\purchase.php 90
ERROR - 2018-07-13 09:01:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:01:26 --> Config Class Initialized
INFO - 2018-07-13 09:01:26 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:01:26 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:01:26 --> Utf8 Class Initialized
INFO - 2018-07-13 09:01:26 --> URI Class Initialized
INFO - 2018-07-13 09:01:26 --> Router Class Initialized
INFO - 2018-07-13 09:01:26 --> Output Class Initialized
INFO - 2018-07-13 09:01:26 --> Security Class Initialized
DEBUG - 2018-07-13 09:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:01:26 --> Input Class Initialized
INFO - 2018-07-13 09:01:26 --> Language Class Initialized
INFO - 2018-07-13 09:01:26 --> Loader Class Initialized
INFO - 2018-07-13 09:01:26 --> Controller Class Initialized
INFO - 2018-07-13 09:01:26 --> Database Driver Class Initialized
INFO - 2018-07-13 09:01:26 --> Model Class Initialized
INFO - 2018-07-13 09:01:26 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:01:26 --> Model Class Initialized
INFO - 2018-07-13 09:01:26 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 09:01:26 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\davidhood\application\views\purchase.php 90
ERROR - 2018-07-13 09:01:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:01:35 --> Config Class Initialized
INFO - 2018-07-13 09:01:35 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:01:35 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:01:35 --> Utf8 Class Initialized
INFO - 2018-07-13 09:01:35 --> URI Class Initialized
DEBUG - 2018-07-13 09:01:35 --> No URI present. Default controller set.
INFO - 2018-07-13 09:01:35 --> Router Class Initialized
INFO - 2018-07-13 09:01:35 --> Output Class Initialized
INFO - 2018-07-13 09:01:35 --> Security Class Initialized
DEBUG - 2018-07-13 09:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:01:35 --> Input Class Initialized
INFO - 2018-07-13 09:01:35 --> Language Class Initialized
INFO - 2018-07-13 09:01:35 --> Loader Class Initialized
INFO - 2018-07-13 09:01:35 --> Controller Class Initialized
INFO - 2018-07-13 09:01:35 --> Database Driver Class Initialized
INFO - 2018-07-13 09:01:35 --> Model Class Initialized
INFO - 2018-07-13 09:01:35 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:01:35 --> Model Class Initialized
INFO - 2018-07-13 09:01:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-13 09:01:35 --> Final output sent to browser
DEBUG - 2018-07-13 09:01:35 --> Total execution time: 0.0514
ERROR - 2018-07-13 09:01:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:01:37 --> Config Class Initialized
INFO - 2018-07-13 09:01:37 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:01:37 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:01:37 --> Utf8 Class Initialized
INFO - 2018-07-13 09:01:37 --> URI Class Initialized
INFO - 2018-07-13 09:01:37 --> Router Class Initialized
INFO - 2018-07-13 09:01:37 --> Output Class Initialized
INFO - 2018-07-13 09:01:37 --> Security Class Initialized
DEBUG - 2018-07-13 09:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:01:37 --> Input Class Initialized
INFO - 2018-07-13 09:01:37 --> Language Class Initialized
INFO - 2018-07-13 09:01:37 --> Loader Class Initialized
INFO - 2018-07-13 09:01:37 --> Controller Class Initialized
INFO - 2018-07-13 09:01:37 --> Database Driver Class Initialized
INFO - 2018-07-13 09:01:37 --> Model Class Initialized
INFO - 2018-07-13 09:01:37 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:01:37 --> Model Class Initialized
ERROR - 2018-07-13 09:01:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:01:37 --> Config Class Initialized
INFO - 2018-07-13 09:01:37 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:01:37 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:01:37 --> Utf8 Class Initialized
INFO - 2018-07-13 09:01:37 --> URI Class Initialized
INFO - 2018-07-13 09:01:37 --> Router Class Initialized
INFO - 2018-07-13 09:01:37 --> Output Class Initialized
INFO - 2018-07-13 09:01:37 --> Security Class Initialized
DEBUG - 2018-07-13 09:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:01:37 --> Input Class Initialized
INFO - 2018-07-13 09:01:37 --> Language Class Initialized
INFO - 2018-07-13 09:01:37 --> Loader Class Initialized
INFO - 2018-07-13 09:01:37 --> Controller Class Initialized
INFO - 2018-07-13 09:01:37 --> Database Driver Class Initialized
INFO - 2018-07-13 09:01:37 --> Model Class Initialized
INFO - 2018-07-13 09:01:37 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:01:37 --> Model Class Initialized
INFO - 2018-07-13 09:01:37 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:01:37 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-13 09:01:37 --> Final output sent to browser
DEBUG - 2018-07-13 09:01:37 --> Total execution time: 0.0541
ERROR - 2018-07-13 09:01:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:01:39 --> Config Class Initialized
INFO - 2018-07-13 09:01:39 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:01:39 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:01:39 --> Utf8 Class Initialized
INFO - 2018-07-13 09:01:39 --> URI Class Initialized
INFO - 2018-07-13 09:01:39 --> Router Class Initialized
INFO - 2018-07-13 09:01:39 --> Output Class Initialized
INFO - 2018-07-13 09:01:39 --> Security Class Initialized
DEBUG - 2018-07-13 09:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:01:39 --> Input Class Initialized
INFO - 2018-07-13 09:01:39 --> Language Class Initialized
INFO - 2018-07-13 09:01:39 --> Loader Class Initialized
INFO - 2018-07-13 09:01:39 --> Controller Class Initialized
INFO - 2018-07-13 09:01:39 --> Database Driver Class Initialized
INFO - 2018-07-13 09:01:39 --> Model Class Initialized
INFO - 2018-07-13 09:01:39 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:01:39 --> Model Class Initialized
INFO - 2018-07-13 09:01:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 09:01:39 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\davidhood\application\views\purchase.php 90
ERROR - 2018-07-13 09:03:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:03:02 --> Config Class Initialized
INFO - 2018-07-13 09:03:02 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:03:02 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:03:02 --> Utf8 Class Initialized
INFO - 2018-07-13 09:03:02 --> URI Class Initialized
INFO - 2018-07-13 09:03:02 --> Router Class Initialized
INFO - 2018-07-13 09:03:02 --> Output Class Initialized
INFO - 2018-07-13 09:03:02 --> Security Class Initialized
DEBUG - 2018-07-13 09:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:03:02 --> Input Class Initialized
INFO - 2018-07-13 09:03:02 --> Language Class Initialized
INFO - 2018-07-13 09:03:02 --> Loader Class Initialized
INFO - 2018-07-13 09:03:02 --> Controller Class Initialized
INFO - 2018-07-13 09:03:02 --> Database Driver Class Initialized
INFO - 2018-07-13 09:03:02 --> Model Class Initialized
INFO - 2018-07-13 09:03:02 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:03:02 --> Model Class Initialized
INFO - 2018-07-13 09:03:02 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:03:02 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:03:02 --> Final output sent to browser
DEBUG - 2018-07-13 09:03:02 --> Total execution time: 0.0369
ERROR - 2018-07-13 09:06:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:06:43 --> Config Class Initialized
INFO - 2018-07-13 09:06:43 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:06:43 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:06:43 --> Utf8 Class Initialized
INFO - 2018-07-13 09:06:43 --> URI Class Initialized
INFO - 2018-07-13 09:06:43 --> Router Class Initialized
INFO - 2018-07-13 09:06:43 --> Output Class Initialized
INFO - 2018-07-13 09:06:43 --> Security Class Initialized
DEBUG - 2018-07-13 09:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:06:43 --> Input Class Initialized
INFO - 2018-07-13 09:06:43 --> Language Class Initialized
INFO - 2018-07-13 09:06:43 --> Loader Class Initialized
INFO - 2018-07-13 09:06:43 --> Controller Class Initialized
INFO - 2018-07-13 09:06:43 --> Database Driver Class Initialized
INFO - 2018-07-13 09:06:43 --> Model Class Initialized
INFO - 2018-07-13 09:06:43 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:06:43 --> Model Class Initialized
INFO - 2018-07-13 09:06:43 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:06:43 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:06:43 --> Final output sent to browser
DEBUG - 2018-07-13 09:06:43 --> Total execution time: 0.0640
ERROR - 2018-07-13 09:06:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:06:53 --> Config Class Initialized
INFO - 2018-07-13 09:06:53 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:06:53 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:06:53 --> Utf8 Class Initialized
INFO - 2018-07-13 09:06:53 --> URI Class Initialized
INFO - 2018-07-13 09:06:53 --> Router Class Initialized
INFO - 2018-07-13 09:06:53 --> Output Class Initialized
INFO - 2018-07-13 09:06:53 --> Security Class Initialized
DEBUG - 2018-07-13 09:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:06:53 --> Input Class Initialized
INFO - 2018-07-13 09:06:53 --> Language Class Initialized
INFO - 2018-07-13 09:06:53 --> Loader Class Initialized
INFO - 2018-07-13 09:06:53 --> Controller Class Initialized
INFO - 2018-07-13 09:06:53 --> Database Driver Class Initialized
INFO - 2018-07-13 09:06:53 --> Model Class Initialized
INFO - 2018-07-13 09:06:53 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:06:53 --> Model Class Initialized
INFO - 2018-07-13 09:06:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:06:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:06:53 --> Final output sent to browser
DEBUG - 2018-07-13 09:06:53 --> Total execution time: 0.0351
ERROR - 2018-07-13 09:08:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:08:32 --> Config Class Initialized
INFO - 2018-07-13 09:08:32 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:08:32 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:08:32 --> Utf8 Class Initialized
INFO - 2018-07-13 09:08:32 --> URI Class Initialized
INFO - 2018-07-13 09:08:32 --> Router Class Initialized
INFO - 2018-07-13 09:08:32 --> Output Class Initialized
INFO - 2018-07-13 09:08:32 --> Security Class Initialized
DEBUG - 2018-07-13 09:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:08:32 --> Input Class Initialized
INFO - 2018-07-13 09:08:32 --> Language Class Initialized
INFO - 2018-07-13 09:08:32 --> Loader Class Initialized
INFO - 2018-07-13 09:08:32 --> Controller Class Initialized
INFO - 2018-07-13 09:08:32 --> Database Driver Class Initialized
INFO - 2018-07-13 09:08:32 --> Model Class Initialized
INFO - 2018-07-13 09:08:32 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:08:32 --> Model Class Initialized
INFO - 2018-07-13 09:08:32 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:08:32 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:08:32 --> Final output sent to browser
DEBUG - 2018-07-13 09:08:32 --> Total execution time: 0.0551
ERROR - 2018-07-13 09:09:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:09:08 --> Config Class Initialized
INFO - 2018-07-13 09:09:08 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:09:08 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:09:08 --> Utf8 Class Initialized
INFO - 2018-07-13 09:09:08 --> URI Class Initialized
INFO - 2018-07-13 09:09:08 --> Router Class Initialized
INFO - 2018-07-13 09:09:08 --> Output Class Initialized
INFO - 2018-07-13 09:09:08 --> Security Class Initialized
DEBUG - 2018-07-13 09:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:09:08 --> Input Class Initialized
INFO - 2018-07-13 09:09:08 --> Language Class Initialized
INFO - 2018-07-13 09:09:08 --> Loader Class Initialized
INFO - 2018-07-13 09:09:08 --> Controller Class Initialized
INFO - 2018-07-13 09:09:08 --> Database Driver Class Initialized
INFO - 2018-07-13 09:09:08 --> Model Class Initialized
INFO - 2018-07-13 09:09:08 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:09:08 --> Model Class Initialized
INFO - 2018-07-13 09:09:08 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:09:08 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:09:08 --> Final output sent to browser
DEBUG - 2018-07-13 09:09:08 --> Total execution time: 0.0378
ERROR - 2018-07-13 09:09:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:09:39 --> Config Class Initialized
INFO - 2018-07-13 09:09:39 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:09:39 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:09:39 --> Utf8 Class Initialized
INFO - 2018-07-13 09:09:39 --> URI Class Initialized
INFO - 2018-07-13 09:09:39 --> Router Class Initialized
INFO - 2018-07-13 09:09:39 --> Output Class Initialized
INFO - 2018-07-13 09:09:39 --> Security Class Initialized
DEBUG - 2018-07-13 09:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:09:39 --> Input Class Initialized
INFO - 2018-07-13 09:09:39 --> Language Class Initialized
INFO - 2018-07-13 09:09:39 --> Loader Class Initialized
INFO - 2018-07-13 09:09:39 --> Controller Class Initialized
INFO - 2018-07-13 09:09:39 --> Database Driver Class Initialized
INFO - 2018-07-13 09:09:39 --> Model Class Initialized
INFO - 2018-07-13 09:09:39 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:09:39 --> Model Class Initialized
INFO - 2018-07-13 09:09:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:09:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:09:39 --> Final output sent to browser
DEBUG - 2018-07-13 09:09:39 --> Total execution time: 0.0491
ERROR - 2018-07-13 09:12:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:12:46 --> Config Class Initialized
INFO - 2018-07-13 09:12:46 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:12:46 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:12:46 --> Utf8 Class Initialized
INFO - 2018-07-13 09:12:46 --> URI Class Initialized
INFO - 2018-07-13 09:12:46 --> Router Class Initialized
INFO - 2018-07-13 09:12:46 --> Output Class Initialized
INFO - 2018-07-13 09:12:46 --> Security Class Initialized
DEBUG - 2018-07-13 09:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:12:46 --> Input Class Initialized
INFO - 2018-07-13 09:12:46 --> Language Class Initialized
INFO - 2018-07-13 09:12:46 --> Loader Class Initialized
INFO - 2018-07-13 09:12:46 --> Controller Class Initialized
INFO - 2018-07-13 09:12:46 --> Database Driver Class Initialized
INFO - 2018-07-13 09:12:46 --> Model Class Initialized
INFO - 2018-07-13 09:12:46 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:12:46 --> Session: Class initialized using 'files' driver.
ERROR - 2018-07-13 09:12:46 --> Severity: error --> Exception: syntax error, unexpected 'status' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\davidhood\application\models\Model.php 68
ERROR - 2018-07-13 09:13:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:13:04 --> Config Class Initialized
INFO - 2018-07-13 09:13:04 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:13:04 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:13:04 --> Utf8 Class Initialized
INFO - 2018-07-13 09:13:04 --> URI Class Initialized
INFO - 2018-07-13 09:13:04 --> Router Class Initialized
INFO - 2018-07-13 09:13:04 --> Output Class Initialized
INFO - 2018-07-13 09:13:04 --> Security Class Initialized
DEBUG - 2018-07-13 09:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:13:04 --> Input Class Initialized
INFO - 2018-07-13 09:13:04 --> Language Class Initialized
INFO - 2018-07-13 09:13:04 --> Loader Class Initialized
INFO - 2018-07-13 09:13:04 --> Controller Class Initialized
INFO - 2018-07-13 09:13:04 --> Database Driver Class Initialized
INFO - 2018-07-13 09:13:04 --> Model Class Initialized
INFO - 2018-07-13 09:13:04 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:13:04 --> Model Class Initialized
INFO - 2018-07-13 09:13:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:13:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:13:04 --> Final output sent to browser
DEBUG - 2018-07-13 09:13:04 --> Total execution time: 0.0449
ERROR - 2018-07-13 09:13:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:13:07 --> Config Class Initialized
INFO - 2018-07-13 09:13:07 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:13:07 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:13:07 --> Utf8 Class Initialized
INFO - 2018-07-13 09:13:07 --> URI Class Initialized
INFO - 2018-07-13 09:13:07 --> Router Class Initialized
INFO - 2018-07-13 09:13:07 --> Output Class Initialized
INFO - 2018-07-13 09:13:07 --> Security Class Initialized
DEBUG - 2018-07-13 09:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:13:07 --> Input Class Initialized
INFO - 2018-07-13 09:13:07 --> Language Class Initialized
INFO - 2018-07-13 09:13:07 --> Loader Class Initialized
INFO - 2018-07-13 09:13:07 --> Controller Class Initialized
INFO - 2018-07-13 09:13:07 --> Database Driver Class Initialized
INFO - 2018-07-13 09:13:07 --> Model Class Initialized
INFO - 2018-07-13 09:13:07 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:13:07 --> Model Class Initialized
ERROR - 2018-07-13 09:13:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:13:07 --> Config Class Initialized
INFO - 2018-07-13 09:13:07 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:13:07 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:13:07 --> Utf8 Class Initialized
INFO - 2018-07-13 09:13:07 --> URI Class Initialized
INFO - 2018-07-13 09:13:07 --> Router Class Initialized
INFO - 2018-07-13 09:13:07 --> Output Class Initialized
INFO - 2018-07-13 09:13:07 --> Security Class Initialized
DEBUG - 2018-07-13 09:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:13:07 --> Input Class Initialized
INFO - 2018-07-13 09:13:07 --> Language Class Initialized
INFO - 2018-07-13 09:13:07 --> Loader Class Initialized
INFO - 2018-07-13 09:13:07 --> Controller Class Initialized
INFO - 2018-07-13 09:13:07 --> Database Driver Class Initialized
INFO - 2018-07-13 09:13:07 --> Model Class Initialized
INFO - 2018-07-13 09:13:07 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:13:07 --> Model Class Initialized
INFO - 2018-07-13 09:13:07 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:13:07 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:13:07 --> Final output sent to browser
DEBUG - 2018-07-13 09:13:07 --> Total execution time: 0.0343
ERROR - 2018-07-13 09:13:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:13:16 --> Config Class Initialized
INFO - 2018-07-13 09:13:16 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:13:17 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:13:17 --> Utf8 Class Initialized
INFO - 2018-07-13 09:13:17 --> URI Class Initialized
INFO - 2018-07-13 09:13:17 --> Router Class Initialized
INFO - 2018-07-13 09:13:17 --> Output Class Initialized
INFO - 2018-07-13 09:13:17 --> Security Class Initialized
DEBUG - 2018-07-13 09:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:13:17 --> Input Class Initialized
INFO - 2018-07-13 09:13:17 --> Language Class Initialized
INFO - 2018-07-13 09:13:17 --> Loader Class Initialized
INFO - 2018-07-13 09:13:17 --> Controller Class Initialized
INFO - 2018-07-13 09:13:17 --> Database Driver Class Initialized
INFO - 2018-07-13 09:13:17 --> Model Class Initialized
INFO - 2018-07-13 09:13:17 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:13:17 --> Model Class Initialized
INFO - 2018-07-13 09:13:17 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:13:17 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:13:17 --> Final output sent to browser
DEBUG - 2018-07-13 09:13:17 --> Total execution time: 0.0368
ERROR - 2018-07-13 09:13:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:13:27 --> Config Class Initialized
INFO - 2018-07-13 09:13:27 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:13:27 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:13:27 --> Utf8 Class Initialized
INFO - 2018-07-13 09:13:27 --> URI Class Initialized
INFO - 2018-07-13 09:13:27 --> Router Class Initialized
INFO - 2018-07-13 09:13:27 --> Output Class Initialized
INFO - 2018-07-13 09:13:27 --> Security Class Initialized
DEBUG - 2018-07-13 09:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:13:27 --> Input Class Initialized
INFO - 2018-07-13 09:13:27 --> Language Class Initialized
INFO - 2018-07-13 09:13:27 --> Loader Class Initialized
INFO - 2018-07-13 09:13:27 --> Controller Class Initialized
INFO - 2018-07-13 09:13:27 --> Database Driver Class Initialized
INFO - 2018-07-13 09:13:27 --> Model Class Initialized
INFO - 2018-07-13 09:13:27 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:13:27 --> Model Class Initialized
INFO - 2018-07-13 09:13:27 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:13:27 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:13:27 --> Final output sent to browser
DEBUG - 2018-07-13 09:13:27 --> Total execution time: 0.0369
ERROR - 2018-07-13 09:13:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:13:29 --> Config Class Initialized
INFO - 2018-07-13 09:13:29 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:13:29 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:13:29 --> Utf8 Class Initialized
INFO - 2018-07-13 09:13:29 --> URI Class Initialized
INFO - 2018-07-13 09:13:29 --> Router Class Initialized
INFO - 2018-07-13 09:13:29 --> Output Class Initialized
INFO - 2018-07-13 09:13:29 --> Security Class Initialized
DEBUG - 2018-07-13 09:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:13:29 --> Input Class Initialized
INFO - 2018-07-13 09:13:29 --> Language Class Initialized
INFO - 2018-07-13 09:13:29 --> Loader Class Initialized
INFO - 2018-07-13 09:13:29 --> Controller Class Initialized
INFO - 2018-07-13 09:13:29 --> Database Driver Class Initialized
INFO - 2018-07-13 09:13:29 --> Model Class Initialized
INFO - 2018-07-13 09:13:29 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:13:29 --> Model Class Initialized
ERROR - 2018-07-13 09:13:29 --> Severity: error --> Exception: Too few arguments to function Main::delete(), 1 passed in C:\xampp\htdocs\davidhood\system\core\CodeIgniter.php on line 529 and exactly 2 expected C:\xampp\htdocs\davidhood\application\controllers\Main.php 67
ERROR - 2018-07-13 09:13:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:13:49 --> Config Class Initialized
INFO - 2018-07-13 09:13:49 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:13:49 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:13:49 --> Utf8 Class Initialized
INFO - 2018-07-13 09:13:49 --> URI Class Initialized
INFO - 2018-07-13 09:13:49 --> Router Class Initialized
INFO - 2018-07-13 09:13:49 --> Output Class Initialized
INFO - 2018-07-13 09:13:49 --> Security Class Initialized
DEBUG - 2018-07-13 09:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:13:49 --> Input Class Initialized
INFO - 2018-07-13 09:13:49 --> Language Class Initialized
INFO - 2018-07-13 09:13:49 --> Loader Class Initialized
INFO - 2018-07-13 09:13:49 --> Controller Class Initialized
INFO - 2018-07-13 09:13:49 --> Database Driver Class Initialized
INFO - 2018-07-13 09:13:49 --> Model Class Initialized
INFO - 2018-07-13 09:13:49 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:13:49 --> Model Class Initialized
INFO - 2018-07-13 09:13:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:13:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:13:49 --> Final output sent to browser
DEBUG - 2018-07-13 09:13:49 --> Total execution time: 0.0604
ERROR - 2018-07-13 09:13:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:13:51 --> Config Class Initialized
INFO - 2018-07-13 09:13:51 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:13:51 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:13:51 --> Utf8 Class Initialized
INFO - 2018-07-13 09:13:51 --> URI Class Initialized
INFO - 2018-07-13 09:13:51 --> Router Class Initialized
INFO - 2018-07-13 09:13:51 --> Output Class Initialized
INFO - 2018-07-13 09:13:51 --> Security Class Initialized
DEBUG - 2018-07-13 09:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:13:51 --> Input Class Initialized
INFO - 2018-07-13 09:13:51 --> Language Class Initialized
INFO - 2018-07-13 09:13:51 --> Loader Class Initialized
INFO - 2018-07-13 09:13:51 --> Controller Class Initialized
INFO - 2018-07-13 09:13:51 --> Database Driver Class Initialized
INFO - 2018-07-13 09:13:51 --> Model Class Initialized
INFO - 2018-07-13 09:13:51 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:13:51 --> Model Class Initialized
INFO - 2018-07-13 09:13:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:13:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:13:51 --> Final output sent to browser
DEBUG - 2018-07-13 09:13:51 --> Total execution time: 0.0404
ERROR - 2018-07-13 09:13:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:13:53 --> Config Class Initialized
INFO - 2018-07-13 09:13:53 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:13:53 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:13:53 --> Utf8 Class Initialized
INFO - 2018-07-13 09:13:53 --> URI Class Initialized
INFO - 2018-07-13 09:13:53 --> Router Class Initialized
INFO - 2018-07-13 09:13:53 --> Output Class Initialized
INFO - 2018-07-13 09:13:53 --> Security Class Initialized
DEBUG - 2018-07-13 09:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:13:53 --> Input Class Initialized
INFO - 2018-07-13 09:13:53 --> Language Class Initialized
INFO - 2018-07-13 09:13:53 --> Loader Class Initialized
INFO - 2018-07-13 09:13:53 --> Controller Class Initialized
INFO - 2018-07-13 09:13:54 --> Database Driver Class Initialized
INFO - 2018-07-13 09:13:54 --> Model Class Initialized
INFO - 2018-07-13 09:13:54 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:13:54 --> Model Class Initialized
INFO - 2018-07-13 09:13:54 --> Final output sent to browser
DEBUG - 2018-07-13 09:13:54 --> Total execution time: 0.0648
ERROR - 2018-07-13 09:14:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:14:30 --> Config Class Initialized
INFO - 2018-07-13 09:14:30 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:14:30 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:14:30 --> Utf8 Class Initialized
INFO - 2018-07-13 09:14:30 --> URI Class Initialized
INFO - 2018-07-13 09:14:30 --> Router Class Initialized
INFO - 2018-07-13 09:14:30 --> Output Class Initialized
INFO - 2018-07-13 09:14:30 --> Security Class Initialized
DEBUG - 2018-07-13 09:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:14:30 --> Input Class Initialized
INFO - 2018-07-13 09:14:30 --> Language Class Initialized
INFO - 2018-07-13 09:14:30 --> Loader Class Initialized
INFO - 2018-07-13 09:14:31 --> Controller Class Initialized
INFO - 2018-07-13 09:14:31 --> Database Driver Class Initialized
INFO - 2018-07-13 09:14:31 --> Model Class Initialized
INFO - 2018-07-13 09:14:31 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:14:31 --> Model Class Initialized
INFO - 2018-07-13 09:14:31 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:14:31 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:14:31 --> Final output sent to browser
DEBUG - 2018-07-13 09:14:31 --> Total execution time: 0.0365
ERROR - 2018-07-13 09:14:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:14:32 --> Config Class Initialized
INFO - 2018-07-13 09:14:32 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:14:32 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:14:32 --> Utf8 Class Initialized
INFO - 2018-07-13 09:14:32 --> URI Class Initialized
INFO - 2018-07-13 09:14:32 --> Router Class Initialized
INFO - 2018-07-13 09:14:32 --> Output Class Initialized
INFO - 2018-07-13 09:14:32 --> Security Class Initialized
DEBUG - 2018-07-13 09:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:14:32 --> Input Class Initialized
INFO - 2018-07-13 09:14:32 --> Language Class Initialized
INFO - 2018-07-13 09:14:32 --> Loader Class Initialized
INFO - 2018-07-13 09:14:32 --> Controller Class Initialized
INFO - 2018-07-13 09:14:32 --> Database Driver Class Initialized
INFO - 2018-07-13 09:14:32 --> Model Class Initialized
INFO - 2018-07-13 09:14:32 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:14:32 --> Model Class Initialized
INFO - 2018-07-13 09:14:32 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:14:32 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:14:32 --> Final output sent to browser
DEBUG - 2018-07-13 09:14:32 --> Total execution time: 0.0410
ERROR - 2018-07-13 09:14:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:14:34 --> Config Class Initialized
INFO - 2018-07-13 09:14:34 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:14:34 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:14:34 --> Utf8 Class Initialized
INFO - 2018-07-13 09:14:34 --> URI Class Initialized
INFO - 2018-07-13 09:14:34 --> Router Class Initialized
INFO - 2018-07-13 09:14:34 --> Output Class Initialized
INFO - 2018-07-13 09:14:34 --> Security Class Initialized
DEBUG - 2018-07-13 09:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:14:34 --> Input Class Initialized
INFO - 2018-07-13 09:14:34 --> Language Class Initialized
INFO - 2018-07-13 09:14:34 --> Loader Class Initialized
INFO - 2018-07-13 09:14:34 --> Controller Class Initialized
INFO - 2018-07-13 09:14:34 --> Database Driver Class Initialized
INFO - 2018-07-13 09:14:34 --> Model Class Initialized
INFO - 2018-07-13 09:14:34 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:14:34 --> Model Class Initialized
ERROR - 2018-07-13 09:14:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:14:34 --> Config Class Initialized
INFO - 2018-07-13 09:14:34 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:14:34 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:14:34 --> Utf8 Class Initialized
INFO - 2018-07-13 09:14:34 --> URI Class Initialized
INFO - 2018-07-13 09:14:34 --> Router Class Initialized
INFO - 2018-07-13 09:14:34 --> Output Class Initialized
INFO - 2018-07-13 09:14:34 --> Security Class Initialized
DEBUG - 2018-07-13 09:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:14:34 --> Input Class Initialized
INFO - 2018-07-13 09:14:34 --> Language Class Initialized
INFO - 2018-07-13 09:14:34 --> Loader Class Initialized
INFO - 2018-07-13 09:14:34 --> Controller Class Initialized
INFO - 2018-07-13 09:14:34 --> Database Driver Class Initialized
INFO - 2018-07-13 09:14:34 --> Model Class Initialized
INFO - 2018-07-13 09:14:34 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:14:34 --> Model Class Initialized
INFO - 2018-07-13 09:14:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:14:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:14:34 --> Final output sent to browser
DEBUG - 2018-07-13 09:14:34 --> Total execution time: 0.0494
ERROR - 2018-07-13 09:14:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:14:51 --> Config Class Initialized
INFO - 2018-07-13 09:14:51 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:14:51 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:14:51 --> Utf8 Class Initialized
INFO - 2018-07-13 09:14:51 --> URI Class Initialized
INFO - 2018-07-13 09:14:51 --> Router Class Initialized
INFO - 2018-07-13 09:14:51 --> Output Class Initialized
INFO - 2018-07-13 09:14:51 --> Security Class Initialized
DEBUG - 2018-07-13 09:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:14:51 --> Input Class Initialized
INFO - 2018-07-13 09:14:51 --> Language Class Initialized
INFO - 2018-07-13 09:14:51 --> Loader Class Initialized
INFO - 2018-07-13 09:14:51 --> Controller Class Initialized
INFO - 2018-07-13 09:14:51 --> Database Driver Class Initialized
INFO - 2018-07-13 09:14:51 --> Model Class Initialized
INFO - 2018-07-13 09:14:51 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:14:51 --> Model Class Initialized
INFO - 2018-07-13 09:14:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:14:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:14:51 --> Final output sent to browser
DEBUG - 2018-07-13 09:14:51 --> Total execution time: 0.0360
ERROR - 2018-07-13 09:14:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:14:52 --> Config Class Initialized
INFO - 2018-07-13 09:14:52 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:14:52 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:14:52 --> Utf8 Class Initialized
INFO - 2018-07-13 09:14:52 --> URI Class Initialized
INFO - 2018-07-13 09:14:52 --> Router Class Initialized
INFO - 2018-07-13 09:14:52 --> Output Class Initialized
INFO - 2018-07-13 09:14:52 --> Security Class Initialized
DEBUG - 2018-07-13 09:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:14:52 --> Input Class Initialized
INFO - 2018-07-13 09:14:52 --> Language Class Initialized
INFO - 2018-07-13 09:14:52 --> Loader Class Initialized
INFO - 2018-07-13 09:14:52 --> Controller Class Initialized
INFO - 2018-07-13 09:14:52 --> Database Driver Class Initialized
INFO - 2018-07-13 09:14:52 --> Model Class Initialized
INFO - 2018-07-13 09:14:52 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:14:52 --> Model Class Initialized
INFO - 2018-07-13 09:14:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:14:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 09:14:52 --> Final output sent to browser
DEBUG - 2018-07-13 09:14:52 --> Total execution time: 0.0370
ERROR - 2018-07-13 09:14:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:14:54 --> Config Class Initialized
INFO - 2018-07-13 09:14:54 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:14:54 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:14:54 --> Utf8 Class Initialized
INFO - 2018-07-13 09:14:54 --> URI Class Initialized
INFO - 2018-07-13 09:14:54 --> Router Class Initialized
INFO - 2018-07-13 09:14:54 --> Output Class Initialized
INFO - 2018-07-13 09:14:54 --> Security Class Initialized
DEBUG - 2018-07-13 09:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:14:54 --> Input Class Initialized
INFO - 2018-07-13 09:14:54 --> Language Class Initialized
INFO - 2018-07-13 09:14:54 --> Loader Class Initialized
INFO - 2018-07-13 09:14:54 --> Controller Class Initialized
INFO - 2018-07-13 09:14:54 --> Database Driver Class Initialized
INFO - 2018-07-13 09:14:54 --> Model Class Initialized
INFO - 2018-07-13 09:14:54 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:14:54 --> Model Class Initialized
INFO - 2018-07-13 09:14:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:14:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-13 09:14:54 --> Final output sent to browser
DEBUG - 2018-07-13 09:14:54 --> Total execution time: 0.0352
ERROR - 2018-07-13 09:15:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:15:00 --> Config Class Initialized
INFO - 2018-07-13 09:15:00 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:15:00 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:15:00 --> Utf8 Class Initialized
INFO - 2018-07-13 09:15:00 --> URI Class Initialized
INFO - 2018-07-13 09:15:00 --> Router Class Initialized
INFO - 2018-07-13 09:15:00 --> Output Class Initialized
INFO - 2018-07-13 09:15:00 --> Security Class Initialized
DEBUG - 2018-07-13 09:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:15:00 --> Input Class Initialized
INFO - 2018-07-13 09:15:00 --> Language Class Initialized
INFO - 2018-07-13 09:15:00 --> Loader Class Initialized
INFO - 2018-07-13 09:15:00 --> Controller Class Initialized
INFO - 2018-07-13 09:15:00 --> Database Driver Class Initialized
INFO - 2018-07-13 09:15:00 --> Model Class Initialized
INFO - 2018-07-13 09:15:00 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:15:00 --> Model Class Initialized
INFO - 2018-07-13 09:15:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:15:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:15:00 --> Final output sent to browser
DEBUG - 2018-07-13 09:15:00 --> Total execution time: 0.0466
ERROR - 2018-07-13 09:15:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:15:06 --> Config Class Initialized
INFO - 2018-07-13 09:15:06 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:15:06 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:15:06 --> Utf8 Class Initialized
INFO - 2018-07-13 09:15:06 --> URI Class Initialized
INFO - 2018-07-13 09:15:06 --> Router Class Initialized
INFO - 2018-07-13 09:15:06 --> Output Class Initialized
INFO - 2018-07-13 09:15:06 --> Security Class Initialized
DEBUG - 2018-07-13 09:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:15:06 --> Input Class Initialized
INFO - 2018-07-13 09:15:06 --> Language Class Initialized
INFO - 2018-07-13 09:15:06 --> Loader Class Initialized
INFO - 2018-07-13 09:15:06 --> Controller Class Initialized
INFO - 2018-07-13 09:15:06 --> Database Driver Class Initialized
INFO - 2018-07-13 09:15:06 --> Model Class Initialized
INFO - 2018-07-13 09:15:06 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:15:06 --> Model Class Initialized
INFO - 2018-07-13 09:15:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:15:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 09:15:06 --> Final output sent to browser
DEBUG - 2018-07-13 09:15:06 --> Total execution time: 0.0340
ERROR - 2018-07-13 09:15:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:15:12 --> Config Class Initialized
INFO - 2018-07-13 09:15:12 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:15:12 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:15:12 --> Utf8 Class Initialized
INFO - 2018-07-13 09:15:12 --> URI Class Initialized
INFO - 2018-07-13 09:15:12 --> Router Class Initialized
INFO - 2018-07-13 09:15:12 --> Output Class Initialized
INFO - 2018-07-13 09:15:12 --> Security Class Initialized
DEBUG - 2018-07-13 09:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:15:12 --> Input Class Initialized
INFO - 2018-07-13 09:15:12 --> Language Class Initialized
INFO - 2018-07-13 09:15:12 --> Loader Class Initialized
INFO - 2018-07-13 09:15:12 --> Controller Class Initialized
INFO - 2018-07-13 09:15:12 --> Database Driver Class Initialized
INFO - 2018-07-13 09:15:12 --> Model Class Initialized
INFO - 2018-07-13 09:15:12 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:15:12 --> Model Class Initialized
INFO - 2018-07-13 09:15:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:15:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:15:12 --> Final output sent to browser
DEBUG - 2018-07-13 09:15:12 --> Total execution time: 0.0617
ERROR - 2018-07-13 09:16:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:16:10 --> Config Class Initialized
INFO - 2018-07-13 09:16:10 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:16:10 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:16:10 --> Utf8 Class Initialized
INFO - 2018-07-13 09:16:10 --> URI Class Initialized
INFO - 2018-07-13 09:16:10 --> Router Class Initialized
INFO - 2018-07-13 09:16:10 --> Output Class Initialized
INFO - 2018-07-13 09:16:10 --> Security Class Initialized
DEBUG - 2018-07-13 09:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:16:10 --> Input Class Initialized
INFO - 2018-07-13 09:16:10 --> Language Class Initialized
INFO - 2018-07-13 09:16:10 --> Loader Class Initialized
INFO - 2018-07-13 09:16:10 --> Controller Class Initialized
INFO - 2018-07-13 09:16:10 --> Database Driver Class Initialized
INFO - 2018-07-13 09:16:10 --> Model Class Initialized
INFO - 2018-07-13 09:16:10 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:16:10 --> Model Class Initialized
INFO - 2018-07-13 09:16:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:16:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:16:10 --> Final output sent to browser
DEBUG - 2018-07-13 09:16:10 --> Total execution time: 0.0591
ERROR - 2018-07-13 09:16:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:16:12 --> Config Class Initialized
INFO - 2018-07-13 09:16:12 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:16:12 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:16:12 --> Utf8 Class Initialized
INFO - 2018-07-13 09:16:12 --> URI Class Initialized
INFO - 2018-07-13 09:16:12 --> Router Class Initialized
INFO - 2018-07-13 09:16:12 --> Output Class Initialized
INFO - 2018-07-13 09:16:12 --> Security Class Initialized
DEBUG - 2018-07-13 09:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:16:12 --> Input Class Initialized
INFO - 2018-07-13 09:16:12 --> Language Class Initialized
INFO - 2018-07-13 09:16:12 --> Loader Class Initialized
INFO - 2018-07-13 09:16:12 --> Controller Class Initialized
INFO - 2018-07-13 09:16:12 --> Database Driver Class Initialized
INFO - 2018-07-13 09:16:12 --> Model Class Initialized
INFO - 2018-07-13 09:16:12 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:16:12 --> Model Class Initialized
INFO - 2018-07-13 09:16:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:16:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 09:16:12 --> Final output sent to browser
DEBUG - 2018-07-13 09:16:12 --> Total execution time: 0.0348
ERROR - 2018-07-13 09:16:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:16:14 --> Config Class Initialized
INFO - 2018-07-13 09:16:14 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:16:14 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:16:14 --> Utf8 Class Initialized
INFO - 2018-07-13 09:16:14 --> URI Class Initialized
INFO - 2018-07-13 09:16:14 --> Router Class Initialized
INFO - 2018-07-13 09:16:14 --> Output Class Initialized
INFO - 2018-07-13 09:16:14 --> Security Class Initialized
DEBUG - 2018-07-13 09:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:16:14 --> Input Class Initialized
INFO - 2018-07-13 09:16:14 --> Language Class Initialized
INFO - 2018-07-13 09:16:14 --> Loader Class Initialized
INFO - 2018-07-13 09:16:14 --> Controller Class Initialized
INFO - 2018-07-13 09:16:14 --> Database Driver Class Initialized
INFO - 2018-07-13 09:16:14 --> Model Class Initialized
INFO - 2018-07-13 09:16:14 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:16:14 --> Model Class Initialized
INFO - 2018-07-13 09:16:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:16:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-13 09:16:14 --> Final output sent to browser
DEBUG - 2018-07-13 09:16:14 --> Total execution time: 0.0431
ERROR - 2018-07-13 09:16:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:16:18 --> Config Class Initialized
INFO - 2018-07-13 09:16:18 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:16:18 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:16:18 --> Utf8 Class Initialized
INFO - 2018-07-13 09:16:18 --> URI Class Initialized
INFO - 2018-07-13 09:16:18 --> Router Class Initialized
INFO - 2018-07-13 09:16:18 --> Output Class Initialized
INFO - 2018-07-13 09:16:18 --> Security Class Initialized
DEBUG - 2018-07-13 09:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:16:18 --> Input Class Initialized
INFO - 2018-07-13 09:16:18 --> Language Class Initialized
INFO - 2018-07-13 09:16:18 --> Loader Class Initialized
INFO - 2018-07-13 09:16:18 --> Controller Class Initialized
INFO - 2018-07-13 09:16:18 --> Database Driver Class Initialized
INFO - 2018-07-13 09:16:18 --> Model Class Initialized
INFO - 2018-07-13 09:16:18 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:16:18 --> Model Class Initialized
INFO - 2018-07-13 09:16:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:16:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-13 09:16:18 --> Final output sent to browser
DEBUG - 2018-07-13 09:16:18 --> Total execution time: 0.0385
ERROR - 2018-07-13 09:16:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:16:20 --> Config Class Initialized
INFO - 2018-07-13 09:16:20 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:16:20 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:16:20 --> Utf8 Class Initialized
INFO - 2018-07-13 09:16:20 --> URI Class Initialized
INFO - 2018-07-13 09:16:20 --> Router Class Initialized
INFO - 2018-07-13 09:16:20 --> Output Class Initialized
INFO - 2018-07-13 09:16:20 --> Security Class Initialized
DEBUG - 2018-07-13 09:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:16:20 --> Input Class Initialized
INFO - 2018-07-13 09:16:20 --> Language Class Initialized
INFO - 2018-07-13 09:16:20 --> Loader Class Initialized
INFO - 2018-07-13 09:16:20 --> Controller Class Initialized
INFO - 2018-07-13 09:16:20 --> Database Driver Class Initialized
INFO - 2018-07-13 09:16:20 --> Model Class Initialized
INFO - 2018-07-13 09:16:20 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:16:20 --> Model Class Initialized
INFO - 2018-07-13 09:16:20 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:16:20 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-13 09:16:20 --> Final output sent to browser
DEBUG - 2018-07-13 09:16:20 --> Total execution time: 0.0435
ERROR - 2018-07-13 09:17:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:17:03 --> Config Class Initialized
INFO - 2018-07-13 09:17:03 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:17:03 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:17:03 --> Utf8 Class Initialized
INFO - 2018-07-13 09:17:03 --> URI Class Initialized
INFO - 2018-07-13 09:17:03 --> Router Class Initialized
INFO - 2018-07-13 09:17:03 --> Output Class Initialized
INFO - 2018-07-13 09:17:03 --> Security Class Initialized
DEBUG - 2018-07-13 09:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:17:03 --> Input Class Initialized
INFO - 2018-07-13 09:17:03 --> Language Class Initialized
INFO - 2018-07-13 09:17:03 --> Loader Class Initialized
INFO - 2018-07-13 09:17:03 --> Controller Class Initialized
INFO - 2018-07-13 09:17:03 --> Database Driver Class Initialized
INFO - 2018-07-13 09:17:03 --> Model Class Initialized
INFO - 2018-07-13 09:17:03 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:17:03 --> Model Class Initialized
INFO - 2018-07-13 09:17:03 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:17:03 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-13 09:17:03 --> Final output sent to browser
DEBUG - 2018-07-13 09:17:03 --> Total execution time: 0.0353
ERROR - 2018-07-13 09:17:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:17:10 --> Config Class Initialized
INFO - 2018-07-13 09:17:10 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:17:10 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:17:10 --> Utf8 Class Initialized
INFO - 2018-07-13 09:17:10 --> URI Class Initialized
INFO - 2018-07-13 09:17:10 --> Router Class Initialized
INFO - 2018-07-13 09:17:10 --> Output Class Initialized
INFO - 2018-07-13 09:17:10 --> Security Class Initialized
DEBUG - 2018-07-13 09:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:17:10 --> Input Class Initialized
INFO - 2018-07-13 09:17:10 --> Language Class Initialized
INFO - 2018-07-13 09:17:10 --> Loader Class Initialized
INFO - 2018-07-13 09:17:10 --> Controller Class Initialized
INFO - 2018-07-13 09:17:10 --> Database Driver Class Initialized
INFO - 2018-07-13 09:17:10 --> Model Class Initialized
INFO - 2018-07-13 09:17:10 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:17:10 --> Model Class Initialized
INFO - 2018-07-13 09:17:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:17:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-13 09:17:10 --> Final output sent to browser
DEBUG - 2018-07-13 09:17:10 --> Total execution time: 0.0482
ERROR - 2018-07-13 09:17:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:17:12 --> Config Class Initialized
INFO - 2018-07-13 09:17:12 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:17:12 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:17:12 --> Utf8 Class Initialized
INFO - 2018-07-13 09:17:12 --> URI Class Initialized
INFO - 2018-07-13 09:17:12 --> Router Class Initialized
INFO - 2018-07-13 09:17:12 --> Output Class Initialized
INFO - 2018-07-13 09:17:12 --> Security Class Initialized
DEBUG - 2018-07-13 09:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:17:12 --> Input Class Initialized
INFO - 2018-07-13 09:17:12 --> Language Class Initialized
INFO - 2018-07-13 09:17:12 --> Loader Class Initialized
INFO - 2018-07-13 09:17:12 --> Controller Class Initialized
INFO - 2018-07-13 09:17:12 --> Database Driver Class Initialized
INFO - 2018-07-13 09:17:12 --> Model Class Initialized
INFO - 2018-07-13 09:17:12 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:17:12 --> Model Class Initialized
INFO - 2018-07-13 09:17:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:17:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-13 09:17:12 --> Final output sent to browser
DEBUG - 2018-07-13 09:17:12 --> Total execution time: 0.0366
ERROR - 2018-07-13 09:17:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:17:20 --> Config Class Initialized
INFO - 2018-07-13 09:17:20 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:17:20 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:17:20 --> Utf8 Class Initialized
INFO - 2018-07-13 09:17:20 --> URI Class Initialized
INFO - 2018-07-13 09:17:20 --> Router Class Initialized
INFO - 2018-07-13 09:17:20 --> Output Class Initialized
INFO - 2018-07-13 09:17:20 --> Security Class Initialized
DEBUG - 2018-07-13 09:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:17:20 --> Input Class Initialized
INFO - 2018-07-13 09:17:20 --> Language Class Initialized
INFO - 2018-07-13 09:17:20 --> Loader Class Initialized
INFO - 2018-07-13 09:17:20 --> Controller Class Initialized
INFO - 2018-07-13 09:17:20 --> Database Driver Class Initialized
INFO - 2018-07-13 09:17:20 --> Model Class Initialized
INFO - 2018-07-13 09:17:20 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:17:20 --> Model Class Initialized
INFO - 2018-07-13 09:17:20 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:17:20 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 09:17:20 --> Final output sent to browser
DEBUG - 2018-07-13 09:17:20 --> Total execution time: 0.0599
ERROR - 2018-07-13 09:17:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:17:21 --> Config Class Initialized
INFO - 2018-07-13 09:17:21 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:17:21 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:17:21 --> Utf8 Class Initialized
INFO - 2018-07-13 09:17:21 --> URI Class Initialized
INFO - 2018-07-13 09:17:21 --> Router Class Initialized
INFO - 2018-07-13 09:17:21 --> Output Class Initialized
INFO - 2018-07-13 09:17:21 --> Security Class Initialized
DEBUG - 2018-07-13 09:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:17:21 --> Input Class Initialized
INFO - 2018-07-13 09:17:21 --> Language Class Initialized
INFO - 2018-07-13 09:17:21 --> Loader Class Initialized
INFO - 2018-07-13 09:17:21 --> Controller Class Initialized
INFO - 2018-07-13 09:17:21 --> Database Driver Class Initialized
INFO - 2018-07-13 09:17:21 --> Model Class Initialized
INFO - 2018-07-13 09:17:21 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:17:21 --> Model Class Initialized
INFO - 2018-07-13 09:17:21 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:17:21 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:17:21 --> Final output sent to browser
DEBUG - 2018-07-13 09:17:21 --> Total execution time: 0.0368
ERROR - 2018-07-13 09:17:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:17:23 --> Config Class Initialized
INFO - 2018-07-13 09:17:23 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:17:23 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:17:23 --> Utf8 Class Initialized
INFO - 2018-07-13 09:17:23 --> URI Class Initialized
INFO - 2018-07-13 09:17:23 --> Router Class Initialized
INFO - 2018-07-13 09:17:23 --> Output Class Initialized
INFO - 2018-07-13 09:17:23 --> Security Class Initialized
DEBUG - 2018-07-13 09:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:17:23 --> Input Class Initialized
INFO - 2018-07-13 09:17:23 --> Language Class Initialized
INFO - 2018-07-13 09:17:23 --> Loader Class Initialized
INFO - 2018-07-13 09:17:23 --> Controller Class Initialized
INFO - 2018-07-13 09:17:23 --> Database Driver Class Initialized
INFO - 2018-07-13 09:17:23 --> Model Class Initialized
INFO - 2018-07-13 09:17:23 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:17:23 --> Model Class Initialized
INFO - 2018-07-13 09:17:23 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:17:23 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 09:17:23 --> Final output sent to browser
DEBUG - 2018-07-13 09:17:23 --> Total execution time: 0.0392
ERROR - 2018-07-13 09:17:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:17:25 --> Config Class Initialized
INFO - 2018-07-13 09:17:25 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:17:25 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:17:25 --> Utf8 Class Initialized
INFO - 2018-07-13 09:17:25 --> URI Class Initialized
INFO - 2018-07-13 09:17:25 --> Router Class Initialized
INFO - 2018-07-13 09:17:25 --> Output Class Initialized
INFO - 2018-07-13 09:17:25 --> Security Class Initialized
DEBUG - 2018-07-13 09:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:17:25 --> Input Class Initialized
INFO - 2018-07-13 09:17:25 --> Language Class Initialized
INFO - 2018-07-13 09:17:25 --> Loader Class Initialized
INFO - 2018-07-13 09:17:25 --> Controller Class Initialized
INFO - 2018-07-13 09:17:25 --> Database Driver Class Initialized
INFO - 2018-07-13 09:17:25 --> Model Class Initialized
INFO - 2018-07-13 09:17:25 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:17:25 --> Model Class Initialized
INFO - 2018-07-13 09:17:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:17:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-13 09:17:25 --> Final output sent to browser
DEBUG - 2018-07-13 09:17:25 --> Total execution time: 0.0401
ERROR - 2018-07-13 09:17:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:17:26 --> Config Class Initialized
INFO - 2018-07-13 09:17:26 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:17:26 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:17:26 --> Utf8 Class Initialized
INFO - 2018-07-13 09:17:26 --> URI Class Initialized
INFO - 2018-07-13 09:17:26 --> Router Class Initialized
INFO - 2018-07-13 09:17:26 --> Output Class Initialized
INFO - 2018-07-13 09:17:26 --> Security Class Initialized
DEBUG - 2018-07-13 09:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:17:26 --> Input Class Initialized
INFO - 2018-07-13 09:17:26 --> Language Class Initialized
INFO - 2018-07-13 09:17:26 --> Loader Class Initialized
INFO - 2018-07-13 09:17:26 --> Controller Class Initialized
INFO - 2018-07-13 09:17:26 --> Database Driver Class Initialized
INFO - 2018-07-13 09:17:26 --> Model Class Initialized
INFO - 2018-07-13 09:17:26 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:17:26 --> Model Class Initialized
INFO - 2018-07-13 09:17:26 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:17:26 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:17:26 --> Final output sent to browser
DEBUG - 2018-07-13 09:17:26 --> Total execution time: 0.0516
ERROR - 2018-07-13 09:17:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:17:28 --> Config Class Initialized
INFO - 2018-07-13 09:17:28 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:17:28 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:17:28 --> Utf8 Class Initialized
INFO - 2018-07-13 09:17:28 --> URI Class Initialized
INFO - 2018-07-13 09:17:28 --> Router Class Initialized
INFO - 2018-07-13 09:17:28 --> Output Class Initialized
INFO - 2018-07-13 09:17:28 --> Security Class Initialized
DEBUG - 2018-07-13 09:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:17:28 --> Input Class Initialized
INFO - 2018-07-13 09:17:28 --> Language Class Initialized
INFO - 2018-07-13 09:17:28 --> Loader Class Initialized
INFO - 2018-07-13 09:17:28 --> Controller Class Initialized
INFO - 2018-07-13 09:17:29 --> Database Driver Class Initialized
INFO - 2018-07-13 09:17:29 --> Model Class Initialized
INFO - 2018-07-13 09:17:29 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:17:29 --> Model Class Initialized
ERROR - 2018-07-13 09:17:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:17:29 --> Config Class Initialized
INFO - 2018-07-13 09:17:29 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:17:29 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:17:29 --> Utf8 Class Initialized
INFO - 2018-07-13 09:17:29 --> URI Class Initialized
INFO - 2018-07-13 09:17:29 --> Router Class Initialized
INFO - 2018-07-13 09:17:29 --> Output Class Initialized
INFO - 2018-07-13 09:17:29 --> Security Class Initialized
DEBUG - 2018-07-13 09:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:17:29 --> Input Class Initialized
INFO - 2018-07-13 09:17:29 --> Language Class Initialized
INFO - 2018-07-13 09:17:29 --> Loader Class Initialized
INFO - 2018-07-13 09:17:29 --> Controller Class Initialized
INFO - 2018-07-13 09:17:29 --> Database Driver Class Initialized
INFO - 2018-07-13 09:17:29 --> Model Class Initialized
INFO - 2018-07-13 09:17:29 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:17:29 --> Model Class Initialized
INFO - 2018-07-13 09:17:29 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:17:29 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:17:29 --> Final output sent to browser
DEBUG - 2018-07-13 09:17:29 --> Total execution time: 0.0401
ERROR - 2018-07-13 09:17:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:17:35 --> Config Class Initialized
INFO - 2018-07-13 09:17:35 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:17:35 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:17:35 --> Utf8 Class Initialized
INFO - 2018-07-13 09:17:35 --> URI Class Initialized
INFO - 2018-07-13 09:17:35 --> Router Class Initialized
INFO - 2018-07-13 09:17:35 --> Output Class Initialized
INFO - 2018-07-13 09:17:35 --> Security Class Initialized
DEBUG - 2018-07-13 09:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:17:35 --> Input Class Initialized
INFO - 2018-07-13 09:17:35 --> Language Class Initialized
INFO - 2018-07-13 09:17:35 --> Loader Class Initialized
INFO - 2018-07-13 09:17:35 --> Controller Class Initialized
INFO - 2018-07-13 09:17:35 --> Database Driver Class Initialized
INFO - 2018-07-13 09:17:35 --> Model Class Initialized
INFO - 2018-07-13 09:17:35 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:17:35 --> Model Class Initialized
INFO - 2018-07-13 09:17:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:17:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 09:17:35 --> Final output sent to browser
DEBUG - 2018-07-13 09:17:35 --> Total execution time: 0.0398
ERROR - 2018-07-13 09:17:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:17:50 --> Config Class Initialized
INFO - 2018-07-13 09:17:50 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:17:50 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:17:50 --> Utf8 Class Initialized
INFO - 2018-07-13 09:17:50 --> URI Class Initialized
INFO - 2018-07-13 09:17:50 --> Router Class Initialized
INFO - 2018-07-13 09:17:50 --> Output Class Initialized
INFO - 2018-07-13 09:17:50 --> Security Class Initialized
DEBUG - 2018-07-13 09:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:17:50 --> Input Class Initialized
INFO - 2018-07-13 09:17:50 --> Language Class Initialized
INFO - 2018-07-13 09:17:50 --> Loader Class Initialized
INFO - 2018-07-13 09:17:50 --> Controller Class Initialized
INFO - 2018-07-13 09:17:50 --> Database Driver Class Initialized
INFO - 2018-07-13 09:17:50 --> Model Class Initialized
INFO - 2018-07-13 09:17:50 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:17:50 --> Model Class Initialized
INFO - 2018-07-13 09:17:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:17:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 09:17:50 --> Final output sent to browser
DEBUG - 2018-07-13 09:17:50 --> Total execution time: 0.0359
ERROR - 2018-07-13 09:17:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:17:51 --> Config Class Initialized
INFO - 2018-07-13 09:17:51 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:17:51 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:17:51 --> Utf8 Class Initialized
INFO - 2018-07-13 09:17:51 --> URI Class Initialized
INFO - 2018-07-13 09:17:51 --> Router Class Initialized
INFO - 2018-07-13 09:17:51 --> Output Class Initialized
INFO - 2018-07-13 09:17:51 --> Security Class Initialized
DEBUG - 2018-07-13 09:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:17:51 --> Input Class Initialized
INFO - 2018-07-13 09:17:51 --> Language Class Initialized
INFO - 2018-07-13 09:17:51 --> Loader Class Initialized
INFO - 2018-07-13 09:17:51 --> Controller Class Initialized
INFO - 2018-07-13 09:17:51 --> Database Driver Class Initialized
INFO - 2018-07-13 09:17:51 --> Model Class Initialized
INFO - 2018-07-13 09:17:51 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:17:51 --> Model Class Initialized
INFO - 2018-07-13 09:17:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:17:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-13 09:17:51 --> Final output sent to browser
DEBUG - 2018-07-13 09:17:51 --> Total execution time: 0.0493
ERROR - 2018-07-13 09:19:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:19:25 --> Config Class Initialized
INFO - 2018-07-13 09:19:25 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:19:25 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:19:25 --> Utf8 Class Initialized
INFO - 2018-07-13 09:19:25 --> URI Class Initialized
INFO - 2018-07-13 09:19:25 --> Router Class Initialized
INFO - 2018-07-13 09:19:25 --> Output Class Initialized
INFO - 2018-07-13 09:19:25 --> Security Class Initialized
DEBUG - 2018-07-13 09:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:19:25 --> Input Class Initialized
INFO - 2018-07-13 09:19:25 --> Language Class Initialized
INFO - 2018-07-13 09:19:25 --> Loader Class Initialized
INFO - 2018-07-13 09:19:25 --> Controller Class Initialized
INFO - 2018-07-13 09:19:25 --> Database Driver Class Initialized
INFO - 2018-07-13 09:19:25 --> Model Class Initialized
INFO - 2018-07-13 09:19:25 --> Helper loaded: form_helper
INFO - 2018-07-13 09:19:25 --> Helper loaded: url_helper
ERROR - 2018-07-13 09:19:25 --> Severity: Notice --> Undefined index: Davidhood C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-07-13 09:19:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-13 09:19:25 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\user_profile.php 68
ERROR - 2018-07-13 09:19:25 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\user_profile.php 73
ERROR - 2018-07-13 09:19:25 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\user_profile.php 82
ERROR - 2018-07-13 09:19:25 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\user_profile.php 92
ERROR - 2018-07-13 09:19:25 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\user_profile.php 101
INFO - 2018-07-13 09:19:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user_profile.php
INFO - 2018-07-13 09:19:25 --> Final output sent to browser
DEBUG - 2018-07-13 09:19:25 --> Total execution time: 0.0694
ERROR - 2018-07-13 09:19:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:19:25 --> Config Class Initialized
INFO - 2018-07-13 09:19:25 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:19:25 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:19:25 --> Utf8 Class Initialized
INFO - 2018-07-13 09:19:25 --> URI Class Initialized
INFO - 2018-07-13 09:19:25 --> Router Class Initialized
INFO - 2018-07-13 09:19:25 --> Output Class Initialized
INFO - 2018-07-13 09:19:25 --> Security Class Initialized
DEBUG - 2018-07-13 09:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:19:25 --> Input Class Initialized
INFO - 2018-07-13 09:19:25 --> Language Class Initialized
ERROR - 2018-07-13 09:19:25 --> 404 Page Not Found: UploadImages/admin
ERROR - 2018-07-13 09:19:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:19:25 --> Config Class Initialized
INFO - 2018-07-13 09:19:25 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:19:25 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:19:25 --> Utf8 Class Initialized
INFO - 2018-07-13 09:19:25 --> URI Class Initialized
DEBUG - 2018-07-13 09:19:25 --> No URI present. Default controller set.
INFO - 2018-07-13 09:19:25 --> Router Class Initialized
INFO - 2018-07-13 09:19:25 --> Output Class Initialized
INFO - 2018-07-13 09:19:25 --> Security Class Initialized
DEBUG - 2018-07-13 09:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:19:25 --> Input Class Initialized
INFO - 2018-07-13 09:19:25 --> Language Class Initialized
INFO - 2018-07-13 09:19:25 --> Loader Class Initialized
INFO - 2018-07-13 09:19:25 --> Controller Class Initialized
INFO - 2018-07-13 09:19:25 --> Database Driver Class Initialized
INFO - 2018-07-13 09:19:25 --> Model Class Initialized
INFO - 2018-07-13 09:19:25 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:19:25 --> Model Class Initialized
INFO - 2018-07-13 09:19:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-13 09:19:25 --> Final output sent to browser
DEBUG - 2018-07-13 09:19:25 --> Total execution time: 0.0455
ERROR - 2018-07-13 09:19:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:19:28 --> Config Class Initialized
INFO - 2018-07-13 09:19:28 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:19:28 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:19:28 --> Utf8 Class Initialized
INFO - 2018-07-13 09:19:28 --> URI Class Initialized
INFO - 2018-07-13 09:19:28 --> Router Class Initialized
INFO - 2018-07-13 09:19:28 --> Output Class Initialized
INFO - 2018-07-13 09:19:28 --> Security Class Initialized
DEBUG - 2018-07-13 09:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:19:28 --> Input Class Initialized
INFO - 2018-07-13 09:19:28 --> Language Class Initialized
INFO - 2018-07-13 09:19:28 --> Loader Class Initialized
INFO - 2018-07-13 09:19:28 --> Controller Class Initialized
INFO - 2018-07-13 09:19:28 --> Database Driver Class Initialized
INFO - 2018-07-13 09:19:28 --> Model Class Initialized
INFO - 2018-07-13 09:19:28 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:19:28 --> Model Class Initialized
ERROR - 2018-07-13 09:19:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:19:28 --> Config Class Initialized
INFO - 2018-07-13 09:19:28 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:19:28 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:19:28 --> Utf8 Class Initialized
INFO - 2018-07-13 09:19:28 --> URI Class Initialized
INFO - 2018-07-13 09:19:28 --> Router Class Initialized
INFO - 2018-07-13 09:19:28 --> Output Class Initialized
INFO - 2018-07-13 09:19:28 --> Security Class Initialized
DEBUG - 2018-07-13 09:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:19:28 --> Input Class Initialized
INFO - 2018-07-13 09:19:28 --> Language Class Initialized
INFO - 2018-07-13 09:19:28 --> Loader Class Initialized
INFO - 2018-07-13 09:19:28 --> Controller Class Initialized
INFO - 2018-07-13 09:19:28 --> Database Driver Class Initialized
INFO - 2018-07-13 09:19:28 --> Model Class Initialized
INFO - 2018-07-13 09:19:28 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:19:28 --> Model Class Initialized
INFO - 2018-07-13 09:19:28 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:19:28 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-13 09:19:28 --> Final output sent to browser
DEBUG - 2018-07-13 09:19:28 --> Total execution time: 0.0384
ERROR - 2018-07-13 09:19:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:19:39 --> Config Class Initialized
INFO - 2018-07-13 09:19:39 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:19:39 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:19:39 --> Utf8 Class Initialized
INFO - 2018-07-13 09:19:39 --> URI Class Initialized
INFO - 2018-07-13 09:19:39 --> Router Class Initialized
INFO - 2018-07-13 09:19:39 --> Output Class Initialized
INFO - 2018-07-13 09:19:39 --> Security Class Initialized
DEBUG - 2018-07-13 09:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:19:39 --> Input Class Initialized
INFO - 2018-07-13 09:19:39 --> Language Class Initialized
INFO - 2018-07-13 09:19:39 --> Loader Class Initialized
INFO - 2018-07-13 09:19:39 --> Controller Class Initialized
INFO - 2018-07-13 09:19:39 --> Database Driver Class Initialized
INFO - 2018-07-13 09:19:39 --> Model Class Initialized
INFO - 2018-07-13 09:19:39 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:19:39 --> Model Class Initialized
INFO - 2018-07-13 09:19:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:19:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-13 09:19:39 --> Final output sent to browser
DEBUG - 2018-07-13 09:19:39 --> Total execution time: 0.0508
ERROR - 2018-07-13 09:20:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:20:06 --> Config Class Initialized
INFO - 2018-07-13 09:20:06 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:20:06 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:20:06 --> Utf8 Class Initialized
INFO - 2018-07-13 09:20:06 --> URI Class Initialized
INFO - 2018-07-13 09:20:06 --> Router Class Initialized
INFO - 2018-07-13 09:20:06 --> Output Class Initialized
INFO - 2018-07-13 09:20:06 --> Security Class Initialized
DEBUG - 2018-07-13 09:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:20:06 --> Input Class Initialized
INFO - 2018-07-13 09:20:06 --> Language Class Initialized
INFO - 2018-07-13 09:20:06 --> Loader Class Initialized
INFO - 2018-07-13 09:20:06 --> Controller Class Initialized
INFO - 2018-07-13 09:20:06 --> Database Driver Class Initialized
INFO - 2018-07-13 09:20:06 --> Model Class Initialized
INFO - 2018-07-13 09:20:06 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:20:06 --> Model Class Initialized
INFO - 2018-07-13 09:20:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:20:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 09:20:06 --> Final output sent to browser
DEBUG - 2018-07-13 09:20:06 --> Total execution time: 0.0372
ERROR - 2018-07-13 09:20:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:20:07 --> Config Class Initialized
INFO - 2018-07-13 09:20:07 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:20:07 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:20:07 --> Utf8 Class Initialized
INFO - 2018-07-13 09:20:07 --> URI Class Initialized
INFO - 2018-07-13 09:20:07 --> Router Class Initialized
INFO - 2018-07-13 09:20:07 --> Output Class Initialized
INFO - 2018-07-13 09:20:07 --> Security Class Initialized
DEBUG - 2018-07-13 09:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:20:07 --> Input Class Initialized
INFO - 2018-07-13 09:20:07 --> Language Class Initialized
INFO - 2018-07-13 09:20:07 --> Loader Class Initialized
INFO - 2018-07-13 09:20:07 --> Controller Class Initialized
INFO - 2018-07-13 09:20:07 --> Database Driver Class Initialized
INFO - 2018-07-13 09:20:07 --> Model Class Initialized
INFO - 2018-07-13 09:20:07 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:20:07 --> Model Class Initialized
INFO - 2018-07-13 09:20:07 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:20:07 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-13 09:20:07 --> Final output sent to browser
DEBUG - 2018-07-13 09:20:07 --> Total execution time: 0.0624
ERROR - 2018-07-13 09:20:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:20:09 --> Config Class Initialized
INFO - 2018-07-13 09:20:09 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:20:09 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:20:09 --> Utf8 Class Initialized
INFO - 2018-07-13 09:20:09 --> URI Class Initialized
INFO - 2018-07-13 09:20:09 --> Router Class Initialized
INFO - 2018-07-13 09:20:09 --> Output Class Initialized
INFO - 2018-07-13 09:20:09 --> Security Class Initialized
DEBUG - 2018-07-13 09:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:20:09 --> Input Class Initialized
INFO - 2018-07-13 09:20:09 --> Language Class Initialized
INFO - 2018-07-13 09:20:09 --> Loader Class Initialized
INFO - 2018-07-13 09:20:09 --> Controller Class Initialized
INFO - 2018-07-13 09:20:09 --> Database Driver Class Initialized
INFO - 2018-07-13 09:20:09 --> Model Class Initialized
INFO - 2018-07-13 09:20:09 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:20:09 --> Model Class Initialized
INFO - 2018-07-13 09:20:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:20:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-13 09:20:09 --> Final output sent to browser
DEBUG - 2018-07-13 09:20:09 --> Total execution time: 0.0390
ERROR - 2018-07-13 09:20:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:20:36 --> Config Class Initialized
INFO - 2018-07-13 09:20:36 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:20:36 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:20:36 --> Utf8 Class Initialized
INFO - 2018-07-13 09:20:36 --> URI Class Initialized
INFO - 2018-07-13 09:20:36 --> Router Class Initialized
INFO - 2018-07-13 09:20:36 --> Output Class Initialized
INFO - 2018-07-13 09:20:36 --> Security Class Initialized
DEBUG - 2018-07-13 09:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:20:36 --> Input Class Initialized
INFO - 2018-07-13 09:20:36 --> Language Class Initialized
INFO - 2018-07-13 09:20:36 --> Loader Class Initialized
INFO - 2018-07-13 09:20:36 --> Controller Class Initialized
INFO - 2018-07-13 09:20:36 --> Database Driver Class Initialized
INFO - 2018-07-13 09:20:36 --> Model Class Initialized
INFO - 2018-07-13 09:20:36 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:20:36 --> Model Class Initialized
INFO - 2018-07-13 09:20:36 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:20:36 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-13 09:20:36 --> Final output sent to browser
DEBUG - 2018-07-13 09:20:36 --> Total execution time: 0.0349
ERROR - 2018-07-13 09:20:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 09:20:46 --> Config Class Initialized
INFO - 2018-07-13 09:20:46 --> Hooks Class Initialized
DEBUG - 2018-07-13 09:20:46 --> UTF-8 Support Enabled
INFO - 2018-07-13 09:20:46 --> Utf8 Class Initialized
INFO - 2018-07-13 09:20:46 --> URI Class Initialized
INFO - 2018-07-13 09:20:46 --> Router Class Initialized
INFO - 2018-07-13 09:20:46 --> Output Class Initialized
INFO - 2018-07-13 09:20:46 --> Security Class Initialized
DEBUG - 2018-07-13 09:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 09:20:46 --> Input Class Initialized
INFO - 2018-07-13 09:20:46 --> Language Class Initialized
INFO - 2018-07-13 09:20:46 --> Loader Class Initialized
INFO - 2018-07-13 09:20:46 --> Controller Class Initialized
INFO - 2018-07-13 09:20:46 --> Database Driver Class Initialized
INFO - 2018-07-13 09:20:46 --> Model Class Initialized
INFO - 2018-07-13 09:20:46 --> Helper loaded: url_helper
DEBUG - 2018-07-13 09:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-13 09:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-13 09:20:46 --> Model Class Initialized
INFO - 2018-07-13 09:20:46 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-13 09:20:46 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-13 09:20:46 --> Final output sent to browser
DEBUG - 2018-07-13 09:20:46 --> Total execution time: 0.0354
ERROR - 2018-07-13 19:46:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 19:46:31 --> Config Class Initialized
INFO - 2018-07-13 19:46:31 --> Hooks Class Initialized
DEBUG - 2018-07-13 19:46:31 --> UTF-8 Support Enabled
INFO - 2018-07-13 19:46:31 --> Utf8 Class Initialized
INFO - 2018-07-13 19:46:31 --> URI Class Initialized
INFO - 2018-07-13 19:46:31 --> Router Class Initialized
INFO - 2018-07-13 19:46:31 --> Output Class Initialized
INFO - 2018-07-13 19:46:31 --> Security Class Initialized
DEBUG - 2018-07-13 19:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 19:46:31 --> Input Class Initialized
INFO - 2018-07-13 19:46:31 --> Language Class Initialized
INFO - 2018-07-13 19:46:31 --> Loader Class Initialized
INFO - 2018-07-13 19:46:31 --> Controller Class Initialized
INFO - 2018-07-13 19:46:31 --> Database Driver Class Initialized
INFO - 2018-07-13 19:46:31 --> Model Class Initialized
INFO - 2018-07-13 19:46:31 --> Helper loaded: form_helper
INFO - 2018-07-13 19:46:31 --> Helper loaded: url_helper
ERROR - 2018-07-13 19:46:31 --> Severity: Compile Error --> Cannot redeclare Model::login() C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 362
ERROR - 2018-07-13 19:47:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 19:47:23 --> Config Class Initialized
INFO - 2018-07-13 19:47:23 --> Hooks Class Initialized
DEBUG - 2018-07-13 19:47:23 --> UTF-8 Support Enabled
INFO - 2018-07-13 19:47:23 --> Utf8 Class Initialized
INFO - 2018-07-13 19:47:23 --> URI Class Initialized
INFO - 2018-07-13 19:47:23 --> Router Class Initialized
INFO - 2018-07-13 19:47:23 --> Output Class Initialized
INFO - 2018-07-13 19:47:23 --> Security Class Initialized
DEBUG - 2018-07-13 19:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 19:47:23 --> Input Class Initialized
INFO - 2018-07-13 19:47:23 --> Language Class Initialized
INFO - 2018-07-13 19:47:23 --> Loader Class Initialized
INFO - 2018-07-13 19:47:23 --> Controller Class Initialized
INFO - 2018-07-13 19:47:23 --> Database Driver Class Initialized
INFO - 2018-07-13 19:47:23 --> Model Class Initialized
INFO - 2018-07-13 19:47:23 --> Helper loaded: form_helper
INFO - 2018-07-13 19:47:23 --> Helper loaded: url_helper
ERROR - 2018-07-13 19:47:23 --> Severity: Compile Error --> Cannot redeclare Model::login() C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 362
ERROR - 2018-07-13 19:47:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 19:47:53 --> Config Class Initialized
INFO - 2018-07-13 19:47:53 --> Hooks Class Initialized
DEBUG - 2018-07-13 19:47:53 --> UTF-8 Support Enabled
INFO - 2018-07-13 19:47:53 --> Utf8 Class Initialized
INFO - 2018-07-13 19:47:53 --> URI Class Initialized
INFO - 2018-07-13 19:47:53 --> Router Class Initialized
INFO - 2018-07-13 19:47:53 --> Output Class Initialized
INFO - 2018-07-13 19:47:53 --> Security Class Initialized
DEBUG - 2018-07-13 19:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 19:47:53 --> Input Class Initialized
INFO - 2018-07-13 19:47:53 --> Language Class Initialized
INFO - 2018-07-13 19:47:53 --> Loader Class Initialized
INFO - 2018-07-13 19:47:53 --> Controller Class Initialized
INFO - 2018-07-13 19:47:53 --> Database Driver Class Initialized
INFO - 2018-07-13 19:47:53 --> Model Class Initialized
INFO - 2018-07-13 19:47:53 --> Helper loaded: form_helper
INFO - 2018-07-13 19:47:53 --> Helper loaded: url_helper
ERROR - 2018-07-13 19:47:54 --> Severity: error --> Exception: C:\xampp\htdocs\davidhood\application\models/Mobile_model.php exists, but doesn't declare class Mobile_model C:\xampp\htdocs\davidhood\system\core\Loader.php 336
ERROR - 2018-07-13 19:49:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 19:49:17 --> Config Class Initialized
INFO - 2018-07-13 19:49:17 --> Hooks Class Initialized
DEBUG - 2018-07-13 19:49:17 --> UTF-8 Support Enabled
INFO - 2018-07-13 19:49:17 --> Utf8 Class Initialized
INFO - 2018-07-13 19:49:17 --> URI Class Initialized
INFO - 2018-07-13 19:49:17 --> Router Class Initialized
INFO - 2018-07-13 19:49:17 --> Output Class Initialized
INFO - 2018-07-13 19:49:17 --> Security Class Initialized
DEBUG - 2018-07-13 19:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 19:49:17 --> Input Class Initialized
INFO - 2018-07-13 19:49:17 --> Language Class Initialized
INFO - 2018-07-13 19:49:17 --> Loader Class Initialized
INFO - 2018-07-13 19:49:17 --> Controller Class Initialized
INFO - 2018-07-13 19:49:17 --> Database Driver Class Initialized
INFO - 2018-07-13 19:49:17 --> Model Class Initialized
INFO - 2018-07-13 19:49:17 --> Helper loaded: form_helper
INFO - 2018-07-13 19:49:17 --> Helper loaded: url_helper
ERROR - 2018-07-13 19:49:17 --> Severity: error --> Exception: C:\xampp\htdocs\davidhood\application\models/Mobile_model.php exists, but doesn't declare class Mobile_model C:\xampp\htdocs\davidhood\system\core\Loader.php 336
ERROR - 2018-07-13 19:50:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 19:50:13 --> Config Class Initialized
INFO - 2018-07-13 19:50:13 --> Hooks Class Initialized
DEBUG - 2018-07-13 19:50:13 --> UTF-8 Support Enabled
INFO - 2018-07-13 19:50:13 --> Utf8 Class Initialized
INFO - 2018-07-13 19:50:13 --> URI Class Initialized
INFO - 2018-07-13 19:50:13 --> Router Class Initialized
INFO - 2018-07-13 19:50:13 --> Output Class Initialized
INFO - 2018-07-13 19:50:13 --> Security Class Initialized
DEBUG - 2018-07-13 19:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 19:50:13 --> Input Class Initialized
INFO - 2018-07-13 19:50:13 --> Language Class Initialized
INFO - 2018-07-13 19:50:13 --> Loader Class Initialized
INFO - 2018-07-13 19:50:13 --> Controller Class Initialized
INFO - 2018-07-13 19:50:13 --> Database Driver Class Initialized
INFO - 2018-07-13 19:50:13 --> Model Class Initialized
INFO - 2018-07-13 19:50:13 --> Helper loaded: form_helper
INFO - 2018-07-13 19:50:13 --> Helper loaded: url_helper
ERROR - 2018-07-13 19:50:13 --> Severity: error --> Exception: C:\xampp\htdocs\davidhood\application\models/Mobile_model.php exists, but doesn't declare class Mobile_model C:\xampp\htdocs\davidhood\system\core\Loader.php 336
ERROR - 2018-07-13 19:51:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 19:51:18 --> Config Class Initialized
INFO - 2018-07-13 19:51:18 --> Hooks Class Initialized
DEBUG - 2018-07-13 19:51:18 --> UTF-8 Support Enabled
INFO - 2018-07-13 19:51:18 --> Utf8 Class Initialized
INFO - 2018-07-13 19:51:19 --> URI Class Initialized
INFO - 2018-07-13 19:51:19 --> Router Class Initialized
INFO - 2018-07-13 19:51:19 --> Output Class Initialized
INFO - 2018-07-13 19:51:19 --> Security Class Initialized
DEBUG - 2018-07-13 19:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 19:51:19 --> Input Class Initialized
INFO - 2018-07-13 19:51:19 --> Language Class Initialized
INFO - 2018-07-13 19:51:19 --> Loader Class Initialized
INFO - 2018-07-13 19:51:19 --> Controller Class Initialized
INFO - 2018-07-13 19:51:19 --> Database Driver Class Initialized
INFO - 2018-07-13 19:51:19 --> Model Class Initialized
INFO - 2018-07-13 19:51:19 --> Helper loaded: form_helper
INFO - 2018-07-13 19:51:19 --> Helper loaded: url_helper
ERROR - 2018-07-13 19:51:19 --> Severity: error --> Exception: C:\xampp\htdocs\davidhood\application\models/Mobile_model.php exists, but doesn't declare class Mobile_model C:\xampp\htdocs\davidhood\system\core\Loader.php 336
ERROR - 2018-07-13 19:51:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 19:51:23 --> Config Class Initialized
INFO - 2018-07-13 19:51:23 --> Hooks Class Initialized
DEBUG - 2018-07-13 19:51:23 --> UTF-8 Support Enabled
INFO - 2018-07-13 19:51:23 --> Utf8 Class Initialized
INFO - 2018-07-13 19:51:23 --> URI Class Initialized
INFO - 2018-07-13 19:51:23 --> Router Class Initialized
INFO - 2018-07-13 19:51:23 --> Output Class Initialized
INFO - 2018-07-13 19:51:23 --> Security Class Initialized
DEBUG - 2018-07-13 19:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 19:51:23 --> Input Class Initialized
INFO - 2018-07-13 19:51:23 --> Language Class Initialized
INFO - 2018-07-13 19:51:23 --> Loader Class Initialized
INFO - 2018-07-13 19:51:23 --> Controller Class Initialized
INFO - 2018-07-13 19:51:23 --> Database Driver Class Initialized
INFO - 2018-07-13 19:51:23 --> Model Class Initialized
INFO - 2018-07-13 19:51:23 --> Helper loaded: form_helper
INFO - 2018-07-13 19:51:23 --> Helper loaded: url_helper
ERROR - 2018-07-13 19:51:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 19:51:32 --> Config Class Initialized
INFO - 2018-07-13 19:51:32 --> Hooks Class Initialized
DEBUG - 2018-07-13 19:51:32 --> UTF-8 Support Enabled
INFO - 2018-07-13 19:51:32 --> Utf8 Class Initialized
INFO - 2018-07-13 19:51:32 --> URI Class Initialized
INFO - 2018-07-13 19:51:32 --> Router Class Initialized
INFO - 2018-07-13 19:51:32 --> Output Class Initialized
INFO - 2018-07-13 19:51:32 --> Security Class Initialized
DEBUG - 2018-07-13 19:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 19:51:32 --> Input Class Initialized
INFO - 2018-07-13 19:51:32 --> Language Class Initialized
INFO - 2018-07-13 19:51:32 --> Loader Class Initialized
INFO - 2018-07-13 19:51:32 --> Controller Class Initialized
INFO - 2018-07-13 19:51:32 --> Database Driver Class Initialized
INFO - 2018-07-13 19:51:32 --> Model Class Initialized
INFO - 2018-07-13 19:51:32 --> Helper loaded: form_helper
INFO - 2018-07-13 19:51:32 --> Helper loaded: url_helper
ERROR - 2018-07-13 19:51:32 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 16
ERROR - 2018-07-13 19:51:32 --> Severity: Notice --> Undefined variable: out_array C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 40
INFO - 2018-07-13 19:51:32 --> Final output sent to browser
DEBUG - 2018-07-13 19:51:32 --> Total execution time: 0.0828
ERROR - 2018-07-13 19:52:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 19:52:50 --> Config Class Initialized
INFO - 2018-07-13 19:52:50 --> Hooks Class Initialized
DEBUG - 2018-07-13 19:52:50 --> UTF-8 Support Enabled
INFO - 2018-07-13 19:52:50 --> Utf8 Class Initialized
INFO - 2018-07-13 19:52:50 --> URI Class Initialized
INFO - 2018-07-13 19:52:50 --> Router Class Initialized
INFO - 2018-07-13 19:52:50 --> Output Class Initialized
INFO - 2018-07-13 19:52:50 --> Security Class Initialized
DEBUG - 2018-07-13 19:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 19:52:50 --> Input Class Initialized
INFO - 2018-07-13 19:52:50 --> Language Class Initialized
INFO - 2018-07-13 19:52:50 --> Loader Class Initialized
INFO - 2018-07-13 19:52:50 --> Controller Class Initialized
INFO - 2018-07-13 19:52:50 --> Database Driver Class Initialized
INFO - 2018-07-13 19:52:50 --> Model Class Initialized
INFO - 2018-07-13 19:52:50 --> Helper loaded: form_helper
INFO - 2018-07-13 19:52:50 --> Helper loaded: url_helper
ERROR - 2018-07-13 19:52:50 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 16
ERROR - 2018-07-13 19:52:50 --> Severity: Notice --> Undefined variable: out_array C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 40
INFO - 2018-07-13 19:52:50 --> Final output sent to browser
DEBUG - 2018-07-13 19:52:50 --> Total execution time: 0.0423
ERROR - 2018-07-13 19:53:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 19:53:17 --> Config Class Initialized
INFO - 2018-07-13 19:53:17 --> Hooks Class Initialized
DEBUG - 2018-07-13 19:53:17 --> UTF-8 Support Enabled
INFO - 2018-07-13 19:53:17 --> Utf8 Class Initialized
INFO - 2018-07-13 19:53:17 --> URI Class Initialized
INFO - 2018-07-13 19:53:17 --> Router Class Initialized
INFO - 2018-07-13 19:53:17 --> Output Class Initialized
INFO - 2018-07-13 19:53:17 --> Security Class Initialized
DEBUG - 2018-07-13 19:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 19:53:17 --> Input Class Initialized
INFO - 2018-07-13 19:53:17 --> Language Class Initialized
INFO - 2018-07-13 19:53:17 --> Loader Class Initialized
INFO - 2018-07-13 19:53:17 --> Controller Class Initialized
INFO - 2018-07-13 19:53:17 --> Database Driver Class Initialized
INFO - 2018-07-13 19:53:17 --> Model Class Initialized
INFO - 2018-07-13 19:53:17 --> Helper loaded: form_helper
INFO - 2018-07-13 19:53:17 --> Helper loaded: url_helper
ERROR - 2018-07-13 19:53:17 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 16
ERROR - 2018-07-13 19:53:17 --> Severity: Notice --> Undefined variable: out_array C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 40
INFO - 2018-07-13 19:53:17 --> Final output sent to browser
DEBUG - 2018-07-13 19:53:17 --> Total execution time: 0.0810
ERROR - 2018-07-13 19:54:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 19:54:53 --> Config Class Initialized
INFO - 2018-07-13 19:54:53 --> Hooks Class Initialized
DEBUG - 2018-07-13 19:54:53 --> UTF-8 Support Enabled
INFO - 2018-07-13 19:54:53 --> Utf8 Class Initialized
INFO - 2018-07-13 19:54:53 --> URI Class Initialized
INFO - 2018-07-13 19:54:53 --> Router Class Initialized
INFO - 2018-07-13 19:54:53 --> Output Class Initialized
INFO - 2018-07-13 19:54:53 --> Security Class Initialized
DEBUG - 2018-07-13 19:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 19:54:53 --> Input Class Initialized
INFO - 2018-07-13 19:54:53 --> Language Class Initialized
INFO - 2018-07-13 19:54:53 --> Loader Class Initialized
INFO - 2018-07-13 19:54:53 --> Controller Class Initialized
INFO - 2018-07-13 19:54:53 --> Database Driver Class Initialized
INFO - 2018-07-13 19:54:53 --> Model Class Initialized
INFO - 2018-07-13 19:54:53 --> Helper loaded: form_helper
INFO - 2018-07-13 19:54:53 --> Helper loaded: url_helper
ERROR - 2018-07-13 19:54:53 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 16
ERROR - 2018-07-13 19:54:53 --> Severity: Notice --> Undefined variable: out_array C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 40
INFO - 2018-07-13 19:54:53 --> Final output sent to browser
DEBUG - 2018-07-13 19:54:53 --> Total execution time: 0.0531
ERROR - 2018-07-13 19:54:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 19:54:59 --> Config Class Initialized
INFO - 2018-07-13 19:54:59 --> Hooks Class Initialized
DEBUG - 2018-07-13 19:54:59 --> UTF-8 Support Enabled
INFO - 2018-07-13 19:54:59 --> Utf8 Class Initialized
INFO - 2018-07-13 19:54:59 --> URI Class Initialized
INFO - 2018-07-13 19:54:59 --> Router Class Initialized
INFO - 2018-07-13 19:54:59 --> Output Class Initialized
INFO - 2018-07-13 19:54:59 --> Security Class Initialized
DEBUG - 2018-07-13 19:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 19:54:59 --> Input Class Initialized
INFO - 2018-07-13 19:54:59 --> Language Class Initialized
INFO - 2018-07-13 19:54:59 --> Loader Class Initialized
INFO - 2018-07-13 19:54:59 --> Controller Class Initialized
INFO - 2018-07-13 19:54:59 --> Database Driver Class Initialized
INFO - 2018-07-13 19:54:59 --> Model Class Initialized
INFO - 2018-07-13 19:54:59 --> Helper loaded: form_helper
INFO - 2018-07-13 19:54:59 --> Helper loaded: url_helper
ERROR - 2018-07-13 19:54:59 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 16
ERROR - 2018-07-13 19:54:59 --> Severity: Notice --> Undefined variable: out_array C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 40
INFO - 2018-07-13 19:54:59 --> Final output sent to browser
DEBUG - 2018-07-13 19:54:59 --> Total execution time: 0.0501
ERROR - 2018-07-13 19:55:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 19:55:24 --> Config Class Initialized
INFO - 2018-07-13 19:55:24 --> Hooks Class Initialized
DEBUG - 2018-07-13 19:55:24 --> UTF-8 Support Enabled
INFO - 2018-07-13 19:55:24 --> Utf8 Class Initialized
INFO - 2018-07-13 19:55:24 --> URI Class Initialized
INFO - 2018-07-13 19:55:24 --> Router Class Initialized
INFO - 2018-07-13 19:55:24 --> Output Class Initialized
INFO - 2018-07-13 19:55:24 --> Security Class Initialized
DEBUG - 2018-07-13 19:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 19:55:24 --> Input Class Initialized
INFO - 2018-07-13 19:55:24 --> Language Class Initialized
INFO - 2018-07-13 19:55:24 --> Loader Class Initialized
INFO - 2018-07-13 19:55:24 --> Controller Class Initialized
INFO - 2018-07-13 19:55:24 --> Database Driver Class Initialized
INFO - 2018-07-13 19:55:24 --> Model Class Initialized
INFO - 2018-07-13 19:55:24 --> Helper loaded: form_helper
INFO - 2018-07-13 19:55:24 --> Helper loaded: url_helper
ERROR - 2018-07-13 19:55:24 --> Severity: Notice --> Undefined property: Mobile::$mobile_model C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 19
ERROR - 2018-07-13 19:55:24 --> Severity: error --> Exception: Call to a member function login() on null C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 19
ERROR - 2018-07-13 19:57:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 19:57:40 --> Config Class Initialized
INFO - 2018-07-13 19:57:40 --> Hooks Class Initialized
DEBUG - 2018-07-13 19:57:40 --> UTF-8 Support Enabled
INFO - 2018-07-13 19:57:40 --> Utf8 Class Initialized
INFO - 2018-07-13 19:57:40 --> URI Class Initialized
INFO - 2018-07-13 19:57:40 --> Router Class Initialized
INFO - 2018-07-13 19:57:40 --> Output Class Initialized
INFO - 2018-07-13 19:57:40 --> Security Class Initialized
DEBUG - 2018-07-13 19:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 19:57:40 --> Input Class Initialized
INFO - 2018-07-13 19:57:40 --> Language Class Initialized
INFO - 2018-07-13 19:57:40 --> Loader Class Initialized
INFO - 2018-07-13 19:57:40 --> Controller Class Initialized
INFO - 2018-07-13 19:57:40 --> Database Driver Class Initialized
INFO - 2018-07-13 19:57:40 --> Model Class Initialized
INFO - 2018-07-13 19:57:40 --> Helper loaded: form_helper
INFO - 2018-07-13 19:57:40 --> Helper loaded: url_helper
ERROR - 2018-07-13 19:57:40 --> Severity: error --> Exception: C:\xampp\htdocs\davidhood\application\models/Mobile_model.php exists, but doesn't declare class Mobile_model C:\xampp\htdocs\davidhood\system\core\Loader.php 336
ERROR - 2018-07-13 20:02:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 20:02:25 --> Config Class Initialized
INFO - 2018-07-13 20:02:25 --> Hooks Class Initialized
DEBUG - 2018-07-13 20:02:25 --> UTF-8 Support Enabled
INFO - 2018-07-13 20:02:25 --> Utf8 Class Initialized
INFO - 2018-07-13 20:02:25 --> URI Class Initialized
INFO - 2018-07-13 20:02:25 --> Router Class Initialized
INFO - 2018-07-13 20:02:25 --> Output Class Initialized
INFO - 2018-07-13 20:02:25 --> Security Class Initialized
DEBUG - 2018-07-13 20:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 20:02:25 --> Input Class Initialized
INFO - 2018-07-13 20:02:25 --> Language Class Initialized
INFO - 2018-07-13 20:02:25 --> Loader Class Initialized
INFO - 2018-07-13 20:02:25 --> Controller Class Initialized
INFO - 2018-07-13 20:02:25 --> Database Driver Class Initialized
INFO - 2018-07-13 20:02:25 --> Model Class Initialized
INFO - 2018-07-13 20:02:25 --> Helper loaded: url_helper
INFO - 2018-07-13 20:02:25 --> Model Class Initialized
ERROR - 2018-07-13 20:02:25 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 18
ERROR - 2018-07-13 20:02:25 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 18
INFO - 2018-07-13 20:02:25 --> Final output sent to browser
DEBUG - 2018-07-13 20:02:25 --> Total execution time: 0.0561
ERROR - 2018-07-13 20:02:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 20:02:48 --> Config Class Initialized
INFO - 2018-07-13 20:02:48 --> Hooks Class Initialized
DEBUG - 2018-07-13 20:02:48 --> UTF-8 Support Enabled
INFO - 2018-07-13 20:02:48 --> Utf8 Class Initialized
INFO - 2018-07-13 20:02:48 --> URI Class Initialized
INFO - 2018-07-13 20:02:48 --> Router Class Initialized
INFO - 2018-07-13 20:02:48 --> Output Class Initialized
INFO - 2018-07-13 20:02:48 --> Security Class Initialized
DEBUG - 2018-07-13 20:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 20:02:48 --> Input Class Initialized
INFO - 2018-07-13 20:02:48 --> Language Class Initialized
INFO - 2018-07-13 20:02:48 --> Loader Class Initialized
INFO - 2018-07-13 20:02:48 --> Controller Class Initialized
INFO - 2018-07-13 20:02:48 --> Database Driver Class Initialized
INFO - 2018-07-13 20:02:48 --> Model Class Initialized
INFO - 2018-07-13 20:02:48 --> Helper loaded: url_helper
INFO - 2018-07-13 20:02:48 --> Model Class Initialized
INFO - 2018-07-13 20:02:48 --> Final output sent to browser
DEBUG - 2018-07-13 20:02:48 --> Total execution time: 0.0375
ERROR - 2018-07-13 20:38:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 20:38:18 --> Config Class Initialized
INFO - 2018-07-13 20:38:18 --> Hooks Class Initialized
DEBUG - 2018-07-13 20:38:18 --> UTF-8 Support Enabled
INFO - 2018-07-13 20:38:18 --> Utf8 Class Initialized
INFO - 2018-07-13 20:38:18 --> URI Class Initialized
INFO - 2018-07-13 20:38:18 --> Router Class Initialized
INFO - 2018-07-13 20:38:18 --> Output Class Initialized
INFO - 2018-07-13 20:38:18 --> Security Class Initialized
DEBUG - 2018-07-13 20:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 20:38:18 --> Input Class Initialized
INFO - 2018-07-13 20:38:18 --> Language Class Initialized
INFO - 2018-07-13 20:38:18 --> Loader Class Initialized
INFO - 2018-07-13 20:38:18 --> Controller Class Initialized
INFO - 2018-07-13 20:38:18 --> Database Driver Class Initialized
INFO - 2018-07-13 20:38:19 --> Model Class Initialized
INFO - 2018-07-13 20:38:19 --> Helper loaded: url_helper
INFO - 2018-07-13 20:38:19 --> Model Class Initialized
ERROR - 2018-07-13 20:38:19 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 15
ERROR - 2018-07-13 20:38:19 --> Severity: Notice --> Undefined variable: out_array C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 39
INFO - 2018-07-13 20:38:19 --> Final output sent to browser
DEBUG - 2018-07-13 20:38:19 --> Total execution time: 0.0699
ERROR - 2018-07-13 20:47:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 20:47:58 --> Config Class Initialized
INFO - 2018-07-13 20:47:58 --> Hooks Class Initialized
DEBUG - 2018-07-13 20:47:58 --> UTF-8 Support Enabled
INFO - 2018-07-13 20:47:58 --> Utf8 Class Initialized
INFO - 2018-07-13 20:47:58 --> URI Class Initialized
INFO - 2018-07-13 20:47:58 --> Router Class Initialized
INFO - 2018-07-13 20:47:58 --> Output Class Initialized
INFO - 2018-07-13 20:47:58 --> Security Class Initialized
DEBUG - 2018-07-13 20:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 20:47:58 --> Input Class Initialized
INFO - 2018-07-13 20:47:58 --> Language Class Initialized
INFO - 2018-07-13 20:47:58 --> Loader Class Initialized
INFO - 2018-07-13 20:47:58 --> Controller Class Initialized
INFO - 2018-07-13 20:47:58 --> Database Driver Class Initialized
INFO - 2018-07-13 20:47:58 --> Model Class Initialized
INFO - 2018-07-13 20:47:58 --> Helper loaded: url_helper
INFO - 2018-07-13 20:47:58 --> Model Class Initialized
ERROR - 2018-07-13 20:48:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 20:48:34 --> Config Class Initialized
INFO - 2018-07-13 20:48:34 --> Hooks Class Initialized
DEBUG - 2018-07-13 20:48:34 --> UTF-8 Support Enabled
INFO - 2018-07-13 20:48:34 --> Utf8 Class Initialized
INFO - 2018-07-13 20:48:34 --> URI Class Initialized
INFO - 2018-07-13 20:48:34 --> Router Class Initialized
INFO - 2018-07-13 20:48:34 --> Output Class Initialized
INFO - 2018-07-13 20:48:34 --> Security Class Initialized
DEBUG - 2018-07-13 20:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 20:48:34 --> Input Class Initialized
INFO - 2018-07-13 20:48:34 --> Language Class Initialized
INFO - 2018-07-13 20:48:34 --> Loader Class Initialized
INFO - 2018-07-13 20:48:34 --> Controller Class Initialized
INFO - 2018-07-13 20:48:34 --> Database Driver Class Initialized
INFO - 2018-07-13 20:48:34 --> Model Class Initialized
INFO - 2018-07-13 20:48:34 --> Helper loaded: url_helper
INFO - 2018-07-13 20:48:34 --> Model Class Initialized
ERROR - 2018-07-13 20:48:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 20:48:51 --> Config Class Initialized
INFO - 2018-07-13 20:48:51 --> Hooks Class Initialized
DEBUG - 2018-07-13 20:48:51 --> UTF-8 Support Enabled
INFO - 2018-07-13 20:48:51 --> Utf8 Class Initialized
INFO - 2018-07-13 20:48:51 --> URI Class Initialized
INFO - 2018-07-13 20:48:51 --> Router Class Initialized
INFO - 2018-07-13 20:48:51 --> Output Class Initialized
INFO - 2018-07-13 20:48:51 --> Security Class Initialized
DEBUG - 2018-07-13 20:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 20:48:51 --> Input Class Initialized
INFO - 2018-07-13 20:48:51 --> Language Class Initialized
INFO - 2018-07-13 20:48:51 --> Loader Class Initialized
INFO - 2018-07-13 20:48:51 --> Controller Class Initialized
INFO - 2018-07-13 20:48:51 --> Database Driver Class Initialized
INFO - 2018-07-13 20:48:51 --> Model Class Initialized
INFO - 2018-07-13 20:48:51 --> Helper loaded: url_helper
INFO - 2018-07-13 20:48:51 --> Model Class Initialized
ERROR - 2018-07-13 20:48:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 20:48:57 --> Config Class Initialized
INFO - 2018-07-13 20:48:57 --> Hooks Class Initialized
DEBUG - 2018-07-13 20:48:57 --> UTF-8 Support Enabled
INFO - 2018-07-13 20:48:57 --> Utf8 Class Initialized
INFO - 2018-07-13 20:48:57 --> URI Class Initialized
INFO - 2018-07-13 20:48:57 --> Router Class Initialized
INFO - 2018-07-13 20:48:57 --> Output Class Initialized
INFO - 2018-07-13 20:48:57 --> Security Class Initialized
DEBUG - 2018-07-13 20:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 20:48:57 --> Input Class Initialized
INFO - 2018-07-13 20:48:57 --> Language Class Initialized
INFO - 2018-07-13 20:48:57 --> Loader Class Initialized
INFO - 2018-07-13 20:48:57 --> Controller Class Initialized
INFO - 2018-07-13 20:48:57 --> Database Driver Class Initialized
INFO - 2018-07-13 20:48:57 --> Model Class Initialized
INFO - 2018-07-13 20:48:57 --> Helper loaded: url_helper
INFO - 2018-07-13 20:48:57 --> Model Class Initialized
ERROR - 2018-07-13 20:49:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 20:49:06 --> Config Class Initialized
INFO - 2018-07-13 20:49:06 --> Hooks Class Initialized
DEBUG - 2018-07-13 20:49:06 --> UTF-8 Support Enabled
INFO - 2018-07-13 20:49:06 --> Utf8 Class Initialized
INFO - 2018-07-13 20:49:06 --> URI Class Initialized
INFO - 2018-07-13 20:49:06 --> Router Class Initialized
INFO - 2018-07-13 20:49:06 --> Output Class Initialized
INFO - 2018-07-13 20:49:06 --> Security Class Initialized
DEBUG - 2018-07-13 20:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 20:49:06 --> Input Class Initialized
INFO - 2018-07-13 20:49:06 --> Language Class Initialized
INFO - 2018-07-13 20:49:06 --> Loader Class Initialized
INFO - 2018-07-13 20:49:06 --> Controller Class Initialized
INFO - 2018-07-13 20:49:06 --> Database Driver Class Initialized
INFO - 2018-07-13 20:49:06 --> Model Class Initialized
INFO - 2018-07-13 20:49:06 --> Helper loaded: url_helper
INFO - 2018-07-13 20:49:06 --> Model Class Initialized
ERROR - 2018-07-13 20:49:06 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 15
ERROR - 2018-07-13 20:49:06 --> Severity: Notice --> Undefined variable: out_array C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 39
INFO - 2018-07-13 20:49:06 --> Final output sent to browser
DEBUG - 2018-07-13 20:49:06 --> Total execution time: 0.0362
ERROR - 2018-07-13 20:49:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 20:49:13 --> Config Class Initialized
INFO - 2018-07-13 20:49:13 --> Hooks Class Initialized
DEBUG - 2018-07-13 20:49:13 --> UTF-8 Support Enabled
INFO - 2018-07-13 20:49:13 --> Utf8 Class Initialized
INFO - 2018-07-13 20:49:13 --> URI Class Initialized
INFO - 2018-07-13 20:49:13 --> Router Class Initialized
INFO - 2018-07-13 20:49:13 --> Output Class Initialized
INFO - 2018-07-13 20:49:13 --> Security Class Initialized
DEBUG - 2018-07-13 20:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 20:49:13 --> Input Class Initialized
INFO - 2018-07-13 20:49:13 --> Language Class Initialized
INFO - 2018-07-13 20:49:13 --> Loader Class Initialized
INFO - 2018-07-13 20:49:13 --> Controller Class Initialized
INFO - 2018-07-13 20:49:13 --> Database Driver Class Initialized
INFO - 2018-07-13 20:49:14 --> Model Class Initialized
INFO - 2018-07-13 20:49:14 --> Helper loaded: url_helper
INFO - 2018-07-13 20:49:14 --> Model Class Initialized
ERROR - 2018-07-13 20:49:14 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 15
ERROR - 2018-07-13 20:49:14 --> Severity: Notice --> Undefined variable: out_array C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 39
INFO - 2018-07-13 20:49:14 --> Final output sent to browser
DEBUG - 2018-07-13 20:49:14 --> Total execution time: 0.0464
ERROR - 2018-07-13 20:49:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 20:49:15 --> Config Class Initialized
INFO - 2018-07-13 20:49:15 --> Hooks Class Initialized
DEBUG - 2018-07-13 20:49:15 --> UTF-8 Support Enabled
INFO - 2018-07-13 20:49:15 --> Utf8 Class Initialized
INFO - 2018-07-13 20:49:15 --> URI Class Initialized
INFO - 2018-07-13 20:49:15 --> Router Class Initialized
INFO - 2018-07-13 20:49:15 --> Output Class Initialized
INFO - 2018-07-13 20:49:15 --> Security Class Initialized
DEBUG - 2018-07-13 20:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 20:49:15 --> Input Class Initialized
INFO - 2018-07-13 20:49:15 --> Language Class Initialized
INFO - 2018-07-13 20:49:15 --> Loader Class Initialized
INFO - 2018-07-13 20:49:15 --> Controller Class Initialized
INFO - 2018-07-13 20:49:15 --> Database Driver Class Initialized
INFO - 2018-07-13 20:49:15 --> Model Class Initialized
INFO - 2018-07-13 20:49:15 --> Helper loaded: url_helper
INFO - 2018-07-13 20:49:15 --> Model Class Initialized
ERROR - 2018-07-13 20:49:15 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 15
ERROR - 2018-07-13 20:49:15 --> Severity: Notice --> Undefined variable: out_array C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 39
INFO - 2018-07-13 20:49:15 --> Final output sent to browser
DEBUG - 2018-07-13 20:49:15 --> Total execution time: 0.0458
ERROR - 2018-07-13 20:49:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 20:49:20 --> Config Class Initialized
INFO - 2018-07-13 20:49:20 --> Hooks Class Initialized
DEBUG - 2018-07-13 20:49:20 --> UTF-8 Support Enabled
INFO - 2018-07-13 20:49:20 --> Utf8 Class Initialized
INFO - 2018-07-13 20:49:20 --> URI Class Initialized
INFO - 2018-07-13 20:49:20 --> Router Class Initialized
INFO - 2018-07-13 20:49:20 --> Output Class Initialized
INFO - 2018-07-13 20:49:20 --> Security Class Initialized
DEBUG - 2018-07-13 20:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 20:49:20 --> Input Class Initialized
INFO - 2018-07-13 20:49:20 --> Language Class Initialized
INFO - 2018-07-13 20:49:20 --> Loader Class Initialized
INFO - 2018-07-13 20:49:20 --> Controller Class Initialized
INFO - 2018-07-13 20:49:20 --> Database Driver Class Initialized
INFO - 2018-07-13 20:49:20 --> Model Class Initialized
INFO - 2018-07-13 20:49:20 --> Helper loaded: url_helper
INFO - 2018-07-13 20:49:20 --> Model Class Initialized
ERROR - 2018-07-13 20:49:20 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 18
ERROR - 2018-07-13 20:49:20 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 18
INFO - 2018-07-13 20:49:20 --> Final output sent to browser
DEBUG - 2018-07-13 20:49:20 --> Total execution time: 0.0709
ERROR - 2018-07-13 21:24:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 21:24:40 --> Config Class Initialized
INFO - 2018-07-13 21:24:40 --> Hooks Class Initialized
DEBUG - 2018-07-13 21:24:40 --> UTF-8 Support Enabled
INFO - 2018-07-13 21:24:40 --> Utf8 Class Initialized
INFO - 2018-07-13 21:24:40 --> URI Class Initialized
INFO - 2018-07-13 21:24:40 --> Router Class Initialized
INFO - 2018-07-13 21:24:40 --> Output Class Initialized
INFO - 2018-07-13 21:24:40 --> Security Class Initialized
DEBUG - 2018-07-13 21:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 21:24:40 --> Input Class Initialized
INFO - 2018-07-13 21:24:40 --> Language Class Initialized
INFO - 2018-07-13 21:24:40 --> Loader Class Initialized
INFO - 2018-07-13 21:24:40 --> Controller Class Initialized
INFO - 2018-07-13 21:24:40 --> Database Driver Class Initialized
INFO - 2018-07-13 21:24:40 --> Model Class Initialized
INFO - 2018-07-13 21:24:40 --> Helper loaded: url_helper
INFO - 2018-07-13 21:24:40 --> Model Class Initialized
ERROR - 2018-07-13 21:24:40 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 18
ERROR - 2018-07-13 21:24:40 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 18
INFO - 2018-07-13 21:24:40 --> Final output sent to browser
DEBUG - 2018-07-13 21:24:40 --> Total execution time: 0.0367
ERROR - 2018-07-13 21:24:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 21:24:47 --> Config Class Initialized
INFO - 2018-07-13 21:24:47 --> Hooks Class Initialized
DEBUG - 2018-07-13 21:24:47 --> UTF-8 Support Enabled
INFO - 2018-07-13 21:24:47 --> Utf8 Class Initialized
INFO - 2018-07-13 21:24:47 --> URI Class Initialized
INFO - 2018-07-13 21:24:47 --> Router Class Initialized
INFO - 2018-07-13 21:24:47 --> Output Class Initialized
INFO - 2018-07-13 21:24:47 --> Security Class Initialized
DEBUG - 2018-07-13 21:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 21:24:47 --> Input Class Initialized
INFO - 2018-07-13 21:24:47 --> Language Class Initialized
INFO - 2018-07-13 21:24:47 --> Loader Class Initialized
INFO - 2018-07-13 21:24:47 --> Controller Class Initialized
INFO - 2018-07-13 21:24:47 --> Database Driver Class Initialized
INFO - 2018-07-13 21:24:47 --> Model Class Initialized
INFO - 2018-07-13 21:24:47 --> Helper loaded: url_helper
INFO - 2018-07-13 21:24:47 --> Model Class Initialized
INFO - 2018-07-13 21:24:47 --> Final output sent to browser
DEBUG - 2018-07-13 21:24:47 --> Total execution time: 0.0429
ERROR - 2018-07-13 21:58:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 21:58:00 --> Config Class Initialized
INFO - 2018-07-13 21:58:00 --> Hooks Class Initialized
DEBUG - 2018-07-13 21:58:00 --> UTF-8 Support Enabled
INFO - 2018-07-13 21:58:00 --> Utf8 Class Initialized
INFO - 2018-07-13 21:58:00 --> URI Class Initialized
INFO - 2018-07-13 21:58:00 --> Router Class Initialized
INFO - 2018-07-13 21:58:00 --> Output Class Initialized
INFO - 2018-07-13 21:58:00 --> Security Class Initialized
DEBUG - 2018-07-13 21:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 21:58:00 --> Input Class Initialized
INFO - 2018-07-13 21:58:00 --> Language Class Initialized
INFO - 2018-07-13 21:58:00 --> Loader Class Initialized
INFO - 2018-07-13 21:58:00 --> Controller Class Initialized
INFO - 2018-07-13 21:58:01 --> Database Driver Class Initialized
INFO - 2018-07-13 21:58:01 --> Model Class Initialized
INFO - 2018-07-13 21:58:01 --> Helper loaded: url_helper
INFO - 2018-07-13 21:58:01 --> Model Class Initialized
ERROR - 2018-07-13 21:58:01 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 15
ERROR - 2018-07-13 21:58:01 --> Severity: Notice --> Undefined variable: out_array C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 39
INFO - 2018-07-13 21:58:01 --> Final output sent to browser
DEBUG - 2018-07-13 21:58:01 --> Total execution time: 0.0432
ERROR - 2018-07-13 22:00:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 22:00:24 --> Config Class Initialized
INFO - 2018-07-13 22:00:24 --> Hooks Class Initialized
DEBUG - 2018-07-13 22:00:24 --> UTF-8 Support Enabled
INFO - 2018-07-13 22:00:24 --> Utf8 Class Initialized
INFO - 2018-07-13 22:00:24 --> URI Class Initialized
INFO - 2018-07-13 22:00:24 --> Router Class Initialized
INFO - 2018-07-13 22:00:24 --> Output Class Initialized
INFO - 2018-07-13 22:00:24 --> Security Class Initialized
DEBUG - 2018-07-13 22:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 22:00:24 --> Input Class Initialized
INFO - 2018-07-13 22:00:24 --> Language Class Initialized
INFO - 2018-07-13 22:00:24 --> Loader Class Initialized
INFO - 2018-07-13 22:00:24 --> Controller Class Initialized
INFO - 2018-07-13 22:00:24 --> Database Driver Class Initialized
INFO - 2018-07-13 22:00:24 --> Model Class Initialized
INFO - 2018-07-13 22:00:24 --> Helper loaded: url_helper
INFO - 2018-07-13 22:00:24 --> Model Class Initialized
INFO - 2018-07-13 22:00:24 --> Final output sent to browser
DEBUG - 2018-07-13 22:00:24 --> Total execution time: 0.0473
ERROR - 2018-07-13 22:43:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 22:43:54 --> Config Class Initialized
INFO - 2018-07-13 22:43:54 --> Hooks Class Initialized
DEBUG - 2018-07-13 22:43:54 --> UTF-8 Support Enabled
INFO - 2018-07-13 22:43:54 --> Utf8 Class Initialized
INFO - 2018-07-13 22:43:54 --> URI Class Initialized
INFO - 2018-07-13 22:43:54 --> Router Class Initialized
INFO - 2018-07-13 22:43:54 --> Output Class Initialized
INFO - 2018-07-13 22:43:54 --> Security Class Initialized
DEBUG - 2018-07-13 22:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 22:43:54 --> Input Class Initialized
INFO - 2018-07-13 22:43:54 --> Language Class Initialized
INFO - 2018-07-13 22:43:54 --> Loader Class Initialized
INFO - 2018-07-13 22:43:54 --> Controller Class Initialized
INFO - 2018-07-13 22:43:54 --> Database Driver Class Initialized
INFO - 2018-07-13 22:43:54 --> Model Class Initialized
INFO - 2018-07-13 22:43:54 --> Helper loaded: url_helper
INFO - 2018-07-13 22:43:54 --> Model Class Initialized
INFO - 2018-07-13 22:43:54 --> Final output sent to browser
DEBUG - 2018-07-13 22:43:54 --> Total execution time: 0.0388
ERROR - 2018-07-13 22:46:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-13 22:46:32 --> Config Class Initialized
INFO - 2018-07-13 22:46:32 --> Hooks Class Initialized
DEBUG - 2018-07-13 22:46:32 --> UTF-8 Support Enabled
INFO - 2018-07-13 22:46:32 --> Utf8 Class Initialized
INFO - 2018-07-13 22:46:32 --> URI Class Initialized
INFO - 2018-07-13 22:46:32 --> Router Class Initialized
INFO - 2018-07-13 22:46:32 --> Output Class Initialized
INFO - 2018-07-13 22:46:32 --> Security Class Initialized
DEBUG - 2018-07-13 22:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-13 22:46:32 --> Input Class Initialized
INFO - 2018-07-13 22:46:32 --> Language Class Initialized
INFO - 2018-07-13 22:46:32 --> Loader Class Initialized
INFO - 2018-07-13 22:46:32 --> Controller Class Initialized
INFO - 2018-07-13 22:46:32 --> Database Driver Class Initialized
INFO - 2018-07-13 22:46:32 --> Model Class Initialized
INFO - 2018-07-13 22:46:32 --> Helper loaded: url_helper
INFO - 2018-07-13 22:46:32 --> Model Class Initialized
INFO - 2018-07-13 22:46:32 --> Final output sent to browser
DEBUG - 2018-07-13 22:46:32 --> Total execution time: 0.0455
