<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-07 14:42:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 14:42:46 --> Config Class Initialized
INFO - 2017-09-07 14:42:46 --> Hooks Class Initialized
DEBUG - 2017-09-07 14:42:46 --> UTF-8 Support Enabled
INFO - 2017-09-07 14:42:46 --> Utf8 Class Initialized
INFO - 2017-09-07 14:42:46 --> URI Class Initialized
DEBUG - 2017-09-07 14:42:46 --> No URI present. Default controller set.
INFO - 2017-09-07 14:42:46 --> Router Class Initialized
INFO - 2017-09-07 14:42:46 --> Output Class Initialized
INFO - 2017-09-07 14:42:46 --> Security Class Initialized
DEBUG - 2017-09-07 14:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 14:42:46 --> Input Class Initialized
INFO - 2017-09-07 14:42:46 --> Language Class Initialized
INFO - 2017-09-07 14:42:46 --> Loader Class Initialized
INFO - 2017-09-07 14:42:46 --> Controller Class Initialized
INFO - 2017-09-07 14:42:46 --> Database Driver Class Initialized
INFO - 2017-09-07 14:42:46 --> Model Class Initialized
ERROR - 2017-09-07 14:42:46 --> Query error: Table 'biper.tbl_admin' doesn't exist in engine - Invalid query: SELECT *
FROM `tbl_admin`
WHERE `ikey` = 'date'
INFO - 2017-09-07 14:42:46 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-09-07 14:58:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 14:58:04 --> Config Class Initialized
INFO - 2017-09-07 14:58:04 --> Hooks Class Initialized
DEBUG - 2017-09-07 14:58:04 --> UTF-8 Support Enabled
INFO - 2017-09-07 14:58:04 --> Utf8 Class Initialized
INFO - 2017-09-07 14:58:04 --> URI Class Initialized
DEBUG - 2017-09-07 14:58:04 --> No URI present. Default controller set.
INFO - 2017-09-07 14:58:04 --> Router Class Initialized
INFO - 2017-09-07 14:58:04 --> Output Class Initialized
INFO - 2017-09-07 14:58:04 --> Security Class Initialized
DEBUG - 2017-09-07 14:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 14:58:04 --> Input Class Initialized
INFO - 2017-09-07 14:58:04 --> Language Class Initialized
INFO - 2017-09-07 14:58:04 --> Loader Class Initialized
INFO - 2017-09-07 14:58:04 --> Controller Class Initialized
INFO - 2017-09-07 14:58:04 --> Database Driver Class Initialized
INFO - 2017-09-07 14:58:04 --> Model Class Initialized
INFO - 2017-09-07 14:58:04 --> Helper loaded: form_helper
INFO - 2017-09-07 14:58:04 --> Helper loaded: url_helper
INFO - 2017-09-07 14:58:04 --> File loaded: C:\xampp\htdocs\biper\application\views\login.php
INFO - 2017-09-07 14:58:04 --> Final output sent to browser
DEBUG - 2017-09-07 14:58:04 --> Total execution time: 0.2100
ERROR - 2017-09-07 14:58:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 14:58:08 --> Config Class Initialized
INFO - 2017-09-07 14:58:08 --> Hooks Class Initialized
DEBUG - 2017-09-07 14:58:08 --> UTF-8 Support Enabled
INFO - 2017-09-07 14:58:08 --> Utf8 Class Initialized
INFO - 2017-09-07 14:58:08 --> URI Class Initialized
INFO - 2017-09-07 14:58:08 --> Router Class Initialized
INFO - 2017-09-07 14:58:08 --> Output Class Initialized
INFO - 2017-09-07 14:58:08 --> Security Class Initialized
DEBUG - 2017-09-07 14:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 14:58:08 --> Input Class Initialized
INFO - 2017-09-07 14:58:08 --> Language Class Initialized
INFO - 2017-09-07 14:58:08 --> Loader Class Initialized
INFO - 2017-09-07 14:58:08 --> Controller Class Initialized
INFO - 2017-09-07 14:58:08 --> Database Driver Class Initialized
INFO - 2017-09-07 14:58:08 --> Model Class Initialized
INFO - 2017-09-07 14:58:08 --> Helper loaded: form_helper
INFO - 2017-09-07 14:58:08 --> Helper loaded: url_helper
INFO - 2017-09-07 14:58:08 --> Model Class Initialized
ERROR - 2017-09-07 14:58:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 14:58:08 --> Config Class Initialized
INFO - 2017-09-07 14:58:08 --> Hooks Class Initialized
DEBUG - 2017-09-07 14:58:08 --> UTF-8 Support Enabled
INFO - 2017-09-07 14:58:08 --> Utf8 Class Initialized
INFO - 2017-09-07 14:58:08 --> URI Class Initialized
INFO - 2017-09-07 14:58:08 --> Router Class Initialized
INFO - 2017-09-07 14:58:08 --> Output Class Initialized
INFO - 2017-09-07 14:58:08 --> Security Class Initialized
DEBUG - 2017-09-07 14:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 14:58:08 --> Input Class Initialized
INFO - 2017-09-07 14:58:08 --> Language Class Initialized
INFO - 2017-09-07 14:58:08 --> Loader Class Initialized
INFO - 2017-09-07 14:58:08 --> Controller Class Initialized
INFO - 2017-09-07 14:58:08 --> Database Driver Class Initialized
INFO - 2017-09-07 14:58:08 --> Model Class Initialized
INFO - 2017-09-07 14:58:08 --> Helper loaded: form_helper
INFO - 2017-09-07 14:58:08 --> Helper loaded: url_helper
INFO - 2017-09-07 14:58:08 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 14:58:08 --> Model Class Initialized
INFO - 2017-09-07 14:58:08 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-07 14:58:08 --> Final output sent to browser
DEBUG - 2017-09-07 14:58:08 --> Total execution time: 0.0500
ERROR - 2017-09-07 14:59:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 14:59:52 --> Config Class Initialized
INFO - 2017-09-07 14:59:52 --> Hooks Class Initialized
DEBUG - 2017-09-07 14:59:52 --> UTF-8 Support Enabled
INFO - 2017-09-07 14:59:52 --> Utf8 Class Initialized
INFO - 2017-09-07 14:59:52 --> URI Class Initialized
INFO - 2017-09-07 14:59:52 --> Router Class Initialized
INFO - 2017-09-07 14:59:52 --> Output Class Initialized
INFO - 2017-09-07 14:59:52 --> Security Class Initialized
DEBUG - 2017-09-07 14:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 14:59:52 --> Input Class Initialized
INFO - 2017-09-07 14:59:52 --> Language Class Initialized
INFO - 2017-09-07 14:59:52 --> Loader Class Initialized
INFO - 2017-09-07 14:59:52 --> Controller Class Initialized
INFO - 2017-09-07 14:59:52 --> Database Driver Class Initialized
INFO - 2017-09-07 14:59:52 --> Model Class Initialized
INFO - 2017-09-07 14:59:52 --> Helper loaded: form_helper
INFO - 2017-09-07 14:59:52 --> Helper loaded: url_helper
INFO - 2017-09-07 14:59:52 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 14:59:52 --> Model Class Initialized
INFO - 2017-09-07 14:59:52 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-07 14:59:52 --> Final output sent to browser
DEBUG - 2017-09-07 14:59:52 --> Total execution time: 0.1130
ERROR - 2017-09-07 15:00:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:00:15 --> Config Class Initialized
INFO - 2017-09-07 15:00:15 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:00:15 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:00:15 --> Utf8 Class Initialized
INFO - 2017-09-07 15:00:15 --> URI Class Initialized
INFO - 2017-09-07 15:00:15 --> Router Class Initialized
INFO - 2017-09-07 15:00:15 --> Output Class Initialized
INFO - 2017-09-07 15:00:15 --> Security Class Initialized
DEBUG - 2017-09-07 15:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:00:16 --> Input Class Initialized
INFO - 2017-09-07 15:00:16 --> Language Class Initialized
INFO - 2017-09-07 15:00:16 --> Loader Class Initialized
INFO - 2017-09-07 15:00:16 --> Controller Class Initialized
INFO - 2017-09-07 15:00:16 --> Database Driver Class Initialized
INFO - 2017-09-07 15:00:16 --> Model Class Initialized
INFO - 2017-09-07 15:00:16 --> Helper loaded: form_helper
INFO - 2017-09-07 15:00:16 --> Helper loaded: url_helper
INFO - 2017-09-07 15:00:16 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:00:16 --> Model Class Initialized
INFO - 2017-09-07 15:00:16 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-07 15:00:16 --> Final output sent to browser
DEBUG - 2017-09-07 15:00:16 --> Total execution time: 0.0790
ERROR - 2017-09-07 15:00:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:00:22 --> Config Class Initialized
INFO - 2017-09-07 15:00:22 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:00:22 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:00:22 --> Utf8 Class Initialized
INFO - 2017-09-07 15:00:22 --> URI Class Initialized
INFO - 2017-09-07 15:00:22 --> Router Class Initialized
INFO - 2017-09-07 15:00:22 --> Output Class Initialized
INFO - 2017-09-07 15:00:22 --> Security Class Initialized
DEBUG - 2017-09-07 15:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:00:22 --> Input Class Initialized
INFO - 2017-09-07 15:00:22 --> Language Class Initialized
INFO - 2017-09-07 15:00:22 --> Loader Class Initialized
INFO - 2017-09-07 15:00:22 --> Controller Class Initialized
INFO - 2017-09-07 15:00:22 --> Database Driver Class Initialized
INFO - 2017-09-07 15:00:22 --> Model Class Initialized
INFO - 2017-09-07 15:00:22 --> Helper loaded: form_helper
INFO - 2017-09-07 15:00:22 --> Helper loaded: url_helper
INFO - 2017-09-07 15:00:22 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:00:22 --> Model Class Initialized
ERROR - 2017-09-07 15:00:22 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\biper\application\views\videos.php 70
INFO - 2017-09-07 15:00:22 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-07 15:00:22 --> Final output sent to browser
DEBUG - 2017-09-07 15:00:22 --> Total execution time: 0.1000
ERROR - 2017-09-07 15:01:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:01:12 --> Config Class Initialized
INFO - 2017-09-07 15:01:12 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:01:12 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:01:12 --> Utf8 Class Initialized
INFO - 2017-09-07 15:01:12 --> URI Class Initialized
INFO - 2017-09-07 15:01:12 --> Router Class Initialized
INFO - 2017-09-07 15:01:12 --> Output Class Initialized
INFO - 2017-09-07 15:01:12 --> Security Class Initialized
DEBUG - 2017-09-07 15:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:01:12 --> Input Class Initialized
INFO - 2017-09-07 15:01:12 --> Language Class Initialized
INFO - 2017-09-07 15:01:12 --> Loader Class Initialized
INFO - 2017-09-07 15:01:12 --> Controller Class Initialized
INFO - 2017-09-07 15:01:12 --> Database Driver Class Initialized
INFO - 2017-09-07 15:01:12 --> Model Class Initialized
INFO - 2017-09-07 15:01:12 --> Helper loaded: form_helper
INFO - 2017-09-07 15:01:12 --> Helper loaded: url_helper
INFO - 2017-09-07 15:01:12 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:01:12 --> Model Class Initialized
INFO - 2017-09-07 15:01:12 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-07 15:01:12 --> Final output sent to browser
DEBUG - 2017-09-07 15:01:12 --> Total execution time: 0.0480
ERROR - 2017-09-07 15:01:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:01:54 --> Config Class Initialized
INFO - 2017-09-07 15:01:54 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:01:54 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:01:54 --> Utf8 Class Initialized
INFO - 2017-09-07 15:01:54 --> URI Class Initialized
INFO - 2017-09-07 15:01:54 --> Router Class Initialized
INFO - 2017-09-07 15:01:54 --> Output Class Initialized
INFO - 2017-09-07 15:01:54 --> Security Class Initialized
DEBUG - 2017-09-07 15:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:01:54 --> Input Class Initialized
INFO - 2017-09-07 15:01:54 --> Language Class Initialized
INFO - 2017-09-07 15:01:54 --> Loader Class Initialized
INFO - 2017-09-07 15:01:54 --> Controller Class Initialized
INFO - 2017-09-07 15:01:54 --> Database Driver Class Initialized
INFO - 2017-09-07 15:01:54 --> Model Class Initialized
INFO - 2017-09-07 15:01:54 --> Helper loaded: form_helper
INFO - 2017-09-07 15:01:54 --> Helper loaded: url_helper
INFO - 2017-09-07 15:01:54 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:01:54 --> Model Class Initialized
INFO - 2017-09-07 15:01:54 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-07 15:01:54 --> Final output sent to browser
DEBUG - 2017-09-07 15:01:54 --> Total execution time: 0.1010
ERROR - 2017-09-07 15:02:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:02:02 --> Config Class Initialized
INFO - 2017-09-07 15:02:02 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:02:02 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:02:02 --> Utf8 Class Initialized
INFO - 2017-09-07 15:02:02 --> URI Class Initialized
INFO - 2017-09-07 15:02:02 --> Router Class Initialized
INFO - 2017-09-07 15:02:02 --> Output Class Initialized
INFO - 2017-09-07 15:02:02 --> Security Class Initialized
DEBUG - 2017-09-07 15:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:02:02 --> Input Class Initialized
INFO - 2017-09-07 15:02:02 --> Language Class Initialized
INFO - 2017-09-07 15:02:02 --> Loader Class Initialized
INFO - 2017-09-07 15:02:02 --> Controller Class Initialized
INFO - 2017-09-07 15:02:02 --> Database Driver Class Initialized
INFO - 2017-09-07 15:02:02 --> Model Class Initialized
INFO - 2017-09-07 15:02:02 --> Helper loaded: form_helper
INFO - 2017-09-07 15:02:02 --> Helper loaded: url_helper
INFO - 2017-09-07 15:02:02 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:02:02 --> Model Class Initialized
INFO - 2017-09-07 15:02:02 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-07 15:02:02 --> Final output sent to browser
DEBUG - 2017-09-07 15:02:02 --> Total execution time: 0.0850
ERROR - 2017-09-07 15:03:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:03:32 --> Config Class Initialized
INFO - 2017-09-07 15:03:32 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:03:32 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:03:32 --> Utf8 Class Initialized
INFO - 2017-09-07 15:03:32 --> URI Class Initialized
INFO - 2017-09-07 15:03:32 --> Router Class Initialized
INFO - 2017-09-07 15:03:32 --> Output Class Initialized
INFO - 2017-09-07 15:03:32 --> Security Class Initialized
DEBUG - 2017-09-07 15:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:03:32 --> Input Class Initialized
INFO - 2017-09-07 15:03:32 --> Language Class Initialized
INFO - 2017-09-07 15:03:32 --> Loader Class Initialized
INFO - 2017-09-07 15:03:32 --> Controller Class Initialized
INFO - 2017-09-07 15:03:32 --> Database Driver Class Initialized
INFO - 2017-09-07 15:03:32 --> Model Class Initialized
INFO - 2017-09-07 15:03:32 --> Helper loaded: form_helper
INFO - 2017-09-07 15:03:32 --> Helper loaded: url_helper
INFO - 2017-09-07 15:03:32 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:03:32 --> Model Class Initialized
INFO - 2017-09-07 15:03:32 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-07 15:03:32 --> Final output sent to browser
DEBUG - 2017-09-07 15:03:32 --> Total execution time: 0.0490
ERROR - 2017-09-07 15:03:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:03:34 --> Config Class Initialized
INFO - 2017-09-07 15:03:34 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:03:34 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:03:34 --> Utf8 Class Initialized
INFO - 2017-09-07 15:03:34 --> URI Class Initialized
INFO - 2017-09-07 15:03:34 --> Router Class Initialized
INFO - 2017-09-07 15:03:34 --> Output Class Initialized
INFO - 2017-09-07 15:03:34 --> Security Class Initialized
DEBUG - 2017-09-07 15:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:03:34 --> Input Class Initialized
INFO - 2017-09-07 15:03:34 --> Language Class Initialized
INFO - 2017-09-07 15:03:34 --> Loader Class Initialized
INFO - 2017-09-07 15:03:34 --> Controller Class Initialized
INFO - 2017-09-07 15:03:34 --> Database Driver Class Initialized
INFO - 2017-09-07 15:03:34 --> Model Class Initialized
INFO - 2017-09-07 15:03:34 --> Helper loaded: form_helper
INFO - 2017-09-07 15:03:34 --> Helper loaded: url_helper
INFO - 2017-09-07 15:03:34 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:03:34 --> Model Class Initialized
INFO - 2017-09-07 15:03:34 --> File loaded: C:\xampp\htdocs\biper\application\views\purchase.php
INFO - 2017-09-07 15:03:34 --> Final output sent to browser
DEBUG - 2017-09-07 15:03:34 --> Total execution time: 0.1280
ERROR - 2017-09-07 15:03:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:03:35 --> Config Class Initialized
INFO - 2017-09-07 15:03:35 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:03:35 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:03:35 --> Utf8 Class Initialized
INFO - 2017-09-07 15:03:35 --> URI Class Initialized
INFO - 2017-09-07 15:03:35 --> Router Class Initialized
INFO - 2017-09-07 15:03:35 --> Output Class Initialized
INFO - 2017-09-07 15:03:35 --> Security Class Initialized
DEBUG - 2017-09-07 15:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:03:35 --> Input Class Initialized
INFO - 2017-09-07 15:03:35 --> Language Class Initialized
INFO - 2017-09-07 15:03:35 --> Loader Class Initialized
INFO - 2017-09-07 15:03:35 --> Controller Class Initialized
INFO - 2017-09-07 15:03:35 --> Database Driver Class Initialized
INFO - 2017-09-07 15:03:35 --> Model Class Initialized
INFO - 2017-09-07 15:03:35 --> Helper loaded: form_helper
INFO - 2017-09-07 15:03:35 --> Helper loaded: url_helper
INFO - 2017-09-07 15:03:35 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:03:35 --> Model Class Initialized
INFO - 2017-09-07 15:03:35 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-07 15:03:35 --> Final output sent to browser
DEBUG - 2017-09-07 15:03:35 --> Total execution time: 0.1260
ERROR - 2017-09-07 15:03:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:03:41 --> Config Class Initialized
INFO - 2017-09-07 15:03:41 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:03:41 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:03:41 --> Utf8 Class Initialized
INFO - 2017-09-07 15:03:41 --> URI Class Initialized
INFO - 2017-09-07 15:03:41 --> Router Class Initialized
INFO - 2017-09-07 15:03:41 --> Output Class Initialized
INFO - 2017-09-07 15:03:41 --> Security Class Initialized
DEBUG - 2017-09-07 15:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:03:41 --> Input Class Initialized
INFO - 2017-09-07 15:03:41 --> Language Class Initialized
INFO - 2017-09-07 15:03:41 --> Loader Class Initialized
INFO - 2017-09-07 15:03:41 --> Controller Class Initialized
INFO - 2017-09-07 15:03:41 --> Database Driver Class Initialized
INFO - 2017-09-07 15:03:41 --> Model Class Initialized
INFO - 2017-09-07 15:03:41 --> Helper loaded: form_helper
INFO - 2017-09-07 15:03:41 --> Helper loaded: url_helper
INFO - 2017-09-07 15:03:41 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:03:41 --> Model Class Initialized
INFO - 2017-09-07 15:03:41 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-07 15:03:41 --> Final output sent to browser
DEBUG - 2017-09-07 15:03:41 --> Total execution time: 0.0730
ERROR - 2017-09-07 15:03:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:03:44 --> Config Class Initialized
INFO - 2017-09-07 15:03:44 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:03:44 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:03:44 --> Utf8 Class Initialized
INFO - 2017-09-07 15:03:44 --> URI Class Initialized
INFO - 2017-09-07 15:03:44 --> Router Class Initialized
INFO - 2017-09-07 15:03:44 --> Output Class Initialized
INFO - 2017-09-07 15:03:44 --> Security Class Initialized
DEBUG - 2017-09-07 15:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:03:44 --> Input Class Initialized
INFO - 2017-09-07 15:03:44 --> Language Class Initialized
INFO - 2017-09-07 15:03:44 --> Loader Class Initialized
INFO - 2017-09-07 15:03:44 --> Controller Class Initialized
INFO - 2017-09-07 15:03:44 --> Database Driver Class Initialized
INFO - 2017-09-07 15:03:44 --> Model Class Initialized
INFO - 2017-09-07 15:03:44 --> Helper loaded: form_helper
INFO - 2017-09-07 15:03:44 --> Helper loaded: url_helper
INFO - 2017-09-07 15:03:44 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:03:44 --> Model Class Initialized
INFO - 2017-09-07 15:03:44 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-07 15:03:44 --> Final output sent to browser
DEBUG - 2017-09-07 15:03:44 --> Total execution time: 0.1250
ERROR - 2017-09-07 15:06:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:06:58 --> Config Class Initialized
INFO - 2017-09-07 15:06:58 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:06:58 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:06:58 --> Utf8 Class Initialized
INFO - 2017-09-07 15:06:58 --> URI Class Initialized
INFO - 2017-09-07 15:06:58 --> Router Class Initialized
INFO - 2017-09-07 15:06:58 --> Output Class Initialized
INFO - 2017-09-07 15:06:58 --> Security Class Initialized
DEBUG - 2017-09-07 15:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:06:58 --> Input Class Initialized
INFO - 2017-09-07 15:06:58 --> Language Class Initialized
INFO - 2017-09-07 15:06:58 --> Loader Class Initialized
INFO - 2017-09-07 15:06:58 --> Controller Class Initialized
INFO - 2017-09-07 15:06:58 --> Database Driver Class Initialized
INFO - 2017-09-07 15:06:58 --> Model Class Initialized
INFO - 2017-09-07 15:06:58 --> Helper loaded: form_helper
INFO - 2017-09-07 15:06:58 --> Helper loaded: url_helper
INFO - 2017-09-07 15:06:58 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:06:58 --> Model Class Initialized
INFO - 2017-09-07 15:06:58 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-07 15:06:58 --> Final output sent to browser
DEBUG - 2017-09-07 15:06:58 --> Total execution time: 0.0510
ERROR - 2017-09-07 15:07:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:07:01 --> Config Class Initialized
INFO - 2017-09-07 15:07:01 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:07:01 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:07:01 --> Utf8 Class Initialized
INFO - 2017-09-07 15:07:01 --> URI Class Initialized
INFO - 2017-09-07 15:07:01 --> Router Class Initialized
INFO - 2017-09-07 15:07:01 --> Output Class Initialized
INFO - 2017-09-07 15:07:01 --> Security Class Initialized
DEBUG - 2017-09-07 15:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:07:01 --> Input Class Initialized
INFO - 2017-09-07 15:07:01 --> Language Class Initialized
INFO - 2017-09-07 15:07:01 --> Loader Class Initialized
INFO - 2017-09-07 15:07:01 --> Controller Class Initialized
INFO - 2017-09-07 15:07:01 --> Database Driver Class Initialized
INFO - 2017-09-07 15:07:01 --> Model Class Initialized
INFO - 2017-09-07 15:07:01 --> Helper loaded: form_helper
INFO - 2017-09-07 15:07:01 --> Helper loaded: url_helper
INFO - 2017-09-07 15:07:01 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
ERROR - 2017-09-07 15:07:01 --> Severity: Notice --> Undefined index: mystage C:\xampp\htdocs\biper\application\views\user_profile.php 68
ERROR - 2017-09-07 15:07:01 --> Severity: Notice --> Undefined index: mystage C:\xampp\htdocs\biper\application\views\user_profile.php 73
ERROR - 2017-09-07 15:07:01 --> Severity: Notice --> Undefined index: mystage C:\xampp\htdocs\biper\application\views\user_profile.php 82
ERROR - 2017-09-07 15:07:01 --> Severity: Notice --> Undefined index: mystage C:\xampp\htdocs\biper\application\views\user_profile.php 92
ERROR - 2017-09-07 15:07:01 --> Severity: Notice --> Undefined index: mystage C:\xampp\htdocs\biper\application\views\user_profile.php 101
INFO - 2017-09-07 15:07:01 --> File loaded: C:\xampp\htdocs\biper\application\views\user_profile.php
INFO - 2017-09-07 15:07:01 --> Final output sent to browser
DEBUG - 2017-09-07 15:07:01 --> Total execution time: 0.0760
ERROR - 2017-09-07 15:08:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:08:40 --> Config Class Initialized
INFO - 2017-09-07 15:08:40 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:08:40 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:08:40 --> Utf8 Class Initialized
INFO - 2017-09-07 15:08:40 --> URI Class Initialized
INFO - 2017-09-07 15:08:40 --> Router Class Initialized
INFO - 2017-09-07 15:08:40 --> Output Class Initialized
INFO - 2017-09-07 15:08:40 --> Security Class Initialized
DEBUG - 2017-09-07 15:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:08:40 --> Input Class Initialized
INFO - 2017-09-07 15:08:40 --> Language Class Initialized
INFO - 2017-09-07 15:08:40 --> Loader Class Initialized
INFO - 2017-09-07 15:08:40 --> Controller Class Initialized
INFO - 2017-09-07 15:08:41 --> Database Driver Class Initialized
INFO - 2017-09-07 15:08:41 --> Model Class Initialized
INFO - 2017-09-07 15:08:41 --> Helper loaded: form_helper
INFO - 2017-09-07 15:08:41 --> Helper loaded: url_helper
INFO - 2017-09-07 15:08:41 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:08:41 --> File loaded: C:\xampp\htdocs\biper\application\views\user_profile.php
INFO - 2017-09-07 15:08:41 --> Final output sent to browser
DEBUG - 2017-09-07 15:08:41 --> Total execution time: 0.0830
ERROR - 2017-09-07 15:09:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:09:03 --> Config Class Initialized
INFO - 2017-09-07 15:09:03 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:09:03 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:09:03 --> Utf8 Class Initialized
INFO - 2017-09-07 15:09:03 --> URI Class Initialized
INFO - 2017-09-07 15:09:03 --> Router Class Initialized
INFO - 2017-09-07 15:09:03 --> Output Class Initialized
INFO - 2017-09-07 15:09:03 --> Security Class Initialized
DEBUG - 2017-09-07 15:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:09:03 --> Input Class Initialized
INFO - 2017-09-07 15:09:03 --> Language Class Initialized
INFO - 2017-09-07 15:09:03 --> Loader Class Initialized
INFO - 2017-09-07 15:09:03 --> Controller Class Initialized
INFO - 2017-09-07 15:09:03 --> Database Driver Class Initialized
INFO - 2017-09-07 15:09:03 --> Model Class Initialized
INFO - 2017-09-07 15:09:03 --> Helper loaded: form_helper
INFO - 2017-09-07 15:09:03 --> Helper loaded: url_helper
INFO - 2017-09-07 15:09:03 --> Upload Class Initialized
INFO - 2017-09-07 15:09:03 --> Final output sent to browser
DEBUG - 2017-09-07 15:09:03 --> Total execution time: 0.0800
ERROR - 2017-09-07 15:09:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:09:20 --> Config Class Initialized
INFO - 2017-09-07 15:09:20 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:09:20 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:09:20 --> Utf8 Class Initialized
INFO - 2017-09-07 15:09:20 --> URI Class Initialized
INFO - 2017-09-07 15:09:20 --> Router Class Initialized
INFO - 2017-09-07 15:09:20 --> Output Class Initialized
INFO - 2017-09-07 15:09:20 --> Security Class Initialized
DEBUG - 2017-09-07 15:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:09:20 --> Input Class Initialized
INFO - 2017-09-07 15:09:20 --> Language Class Initialized
INFO - 2017-09-07 15:09:20 --> Loader Class Initialized
INFO - 2017-09-07 15:09:20 --> Controller Class Initialized
INFO - 2017-09-07 15:09:20 --> Database Driver Class Initialized
INFO - 2017-09-07 15:09:20 --> Model Class Initialized
INFO - 2017-09-07 15:09:20 --> Helper loaded: form_helper
INFO - 2017-09-07 15:09:20 --> Helper loaded: url_helper
INFO - 2017-09-07 15:09:20 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:09:20 --> File loaded: C:\xampp\htdocs\biper\application\views\user_profile.php
INFO - 2017-09-07 15:09:20 --> Final output sent to browser
DEBUG - 2017-09-07 15:09:20 --> Total execution time: 0.3910
ERROR - 2017-09-07 15:09:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:09:30 --> Config Class Initialized
INFO - 2017-09-07 15:09:30 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:09:30 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:09:30 --> Utf8 Class Initialized
INFO - 2017-09-07 15:09:30 --> URI Class Initialized
INFO - 2017-09-07 15:09:30 --> Router Class Initialized
INFO - 2017-09-07 15:09:30 --> Output Class Initialized
INFO - 2017-09-07 15:09:30 --> Security Class Initialized
DEBUG - 2017-09-07 15:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:09:30 --> Input Class Initialized
INFO - 2017-09-07 15:09:30 --> Language Class Initialized
INFO - 2017-09-07 15:09:30 --> Loader Class Initialized
INFO - 2017-09-07 15:09:30 --> Controller Class Initialized
INFO - 2017-09-07 15:09:30 --> Database Driver Class Initialized
INFO - 2017-09-07 15:09:30 --> Model Class Initialized
INFO - 2017-09-07 15:09:30 --> Helper loaded: form_helper
INFO - 2017-09-07 15:09:30 --> Helper loaded: url_helper
INFO - 2017-09-07 15:09:30 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:09:30 --> Model Class Initialized
INFO - 2017-09-07 15:09:30 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-07 15:09:30 --> Final output sent to browser
DEBUG - 2017-09-07 15:09:30 --> Total execution time: 0.0860
ERROR - 2017-09-07 15:09:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:09:36 --> Config Class Initialized
INFO - 2017-09-07 15:09:36 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:09:36 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:09:36 --> Utf8 Class Initialized
INFO - 2017-09-07 15:09:36 --> URI Class Initialized
INFO - 2017-09-07 15:09:36 --> Router Class Initialized
INFO - 2017-09-07 15:09:36 --> Output Class Initialized
INFO - 2017-09-07 15:09:36 --> Security Class Initialized
DEBUG - 2017-09-07 15:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:09:36 --> Input Class Initialized
INFO - 2017-09-07 15:09:36 --> Language Class Initialized
INFO - 2017-09-07 15:09:36 --> Loader Class Initialized
INFO - 2017-09-07 15:09:36 --> Controller Class Initialized
INFO - 2017-09-07 15:09:36 --> Database Driver Class Initialized
INFO - 2017-09-07 15:09:36 --> Model Class Initialized
INFO - 2017-09-07 15:09:36 --> Helper loaded: form_helper
INFO - 2017-09-07 15:09:36 --> Helper loaded: url_helper
INFO - 2017-09-07 15:09:36 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:09:36 --> File loaded: C:\xampp\htdocs\biper\application\views\user_profile.php
INFO - 2017-09-07 15:09:36 --> Final output sent to browser
DEBUG - 2017-09-07 15:09:36 --> Total execution time: 0.0760
ERROR - 2017-09-07 15:10:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:10:53 --> Config Class Initialized
INFO - 2017-09-07 15:10:53 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:10:53 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:10:53 --> Utf8 Class Initialized
INFO - 2017-09-07 15:10:53 --> URI Class Initialized
INFO - 2017-09-07 15:10:53 --> Router Class Initialized
INFO - 2017-09-07 15:10:53 --> Output Class Initialized
INFO - 2017-09-07 15:10:53 --> Security Class Initialized
DEBUG - 2017-09-07 15:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:10:53 --> Input Class Initialized
INFO - 2017-09-07 15:10:53 --> Language Class Initialized
INFO - 2017-09-07 15:10:53 --> Loader Class Initialized
INFO - 2017-09-07 15:10:53 --> Controller Class Initialized
INFO - 2017-09-07 15:10:53 --> Database Driver Class Initialized
INFO - 2017-09-07 15:10:53 --> Model Class Initialized
INFO - 2017-09-07 15:10:53 --> Helper loaded: form_helper
INFO - 2017-09-07 15:10:53 --> Helper loaded: url_helper
INFO - 2017-09-07 15:10:53 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:10:53 --> File loaded: C:\xampp\htdocs\biper\application\views\user_profile.php
INFO - 2017-09-07 15:10:53 --> Final output sent to browser
DEBUG - 2017-09-07 15:10:53 --> Total execution time: 0.0910
ERROR - 2017-09-07 15:11:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:11:03 --> Config Class Initialized
INFO - 2017-09-07 15:11:03 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:11:03 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:11:03 --> Utf8 Class Initialized
INFO - 2017-09-07 15:11:03 --> URI Class Initialized
INFO - 2017-09-07 15:11:03 --> Router Class Initialized
INFO - 2017-09-07 15:11:03 --> Output Class Initialized
INFO - 2017-09-07 15:11:03 --> Security Class Initialized
DEBUG - 2017-09-07 15:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:11:03 --> Input Class Initialized
INFO - 2017-09-07 15:11:03 --> Language Class Initialized
INFO - 2017-09-07 15:11:03 --> Loader Class Initialized
INFO - 2017-09-07 15:11:03 --> Controller Class Initialized
INFO - 2017-09-07 15:11:03 --> Database Driver Class Initialized
INFO - 2017-09-07 15:11:03 --> Model Class Initialized
INFO - 2017-09-07 15:11:03 --> Helper loaded: form_helper
INFO - 2017-09-07 15:11:03 --> Helper loaded: url_helper
INFO - 2017-09-07 15:11:04 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:11:04 --> File loaded: C:\xampp\htdocs\biper\application\views\user_profile.php
INFO - 2017-09-07 15:11:04 --> Final output sent to browser
DEBUG - 2017-09-07 15:11:04 --> Total execution time: 0.2780
ERROR - 2017-09-07 15:11:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:11:11 --> Config Class Initialized
INFO - 2017-09-07 15:11:11 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:11:11 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:11:11 --> Utf8 Class Initialized
INFO - 2017-09-07 15:11:11 --> URI Class Initialized
INFO - 2017-09-07 15:11:11 --> Router Class Initialized
INFO - 2017-09-07 15:11:11 --> Output Class Initialized
INFO - 2017-09-07 15:11:11 --> Security Class Initialized
DEBUG - 2017-09-07 15:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:11:11 --> Input Class Initialized
INFO - 2017-09-07 15:11:11 --> Language Class Initialized
INFO - 2017-09-07 15:11:11 --> Loader Class Initialized
INFO - 2017-09-07 15:11:11 --> Controller Class Initialized
INFO - 2017-09-07 15:11:11 --> Database Driver Class Initialized
INFO - 2017-09-07 15:11:11 --> Model Class Initialized
INFO - 2017-09-07 15:11:11 --> Helper loaded: form_helper
INFO - 2017-09-07 15:11:11 --> Helper loaded: url_helper
INFO - 2017-09-07 15:11:11 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:11:11 --> File loaded: C:\xampp\htdocs\biper\application\views\user_profile.php
INFO - 2017-09-07 15:11:11 --> Final output sent to browser
DEBUG - 2017-09-07 15:11:11 --> Total execution time: 0.0800
ERROR - 2017-09-07 15:11:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:11:13 --> Config Class Initialized
INFO - 2017-09-07 15:11:13 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:11:13 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:11:13 --> Utf8 Class Initialized
INFO - 2017-09-07 15:11:13 --> URI Class Initialized
INFO - 2017-09-07 15:11:13 --> Router Class Initialized
INFO - 2017-09-07 15:11:13 --> Output Class Initialized
INFO - 2017-09-07 15:11:13 --> Security Class Initialized
DEBUG - 2017-09-07 15:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:11:13 --> Input Class Initialized
INFO - 2017-09-07 15:11:13 --> Language Class Initialized
INFO - 2017-09-07 15:11:13 --> Loader Class Initialized
INFO - 2017-09-07 15:11:13 --> Controller Class Initialized
INFO - 2017-09-07 15:11:13 --> Database Driver Class Initialized
INFO - 2017-09-07 15:11:13 --> Model Class Initialized
INFO - 2017-09-07 15:11:13 --> Helper loaded: form_helper
INFO - 2017-09-07 15:11:13 --> Helper loaded: url_helper
INFO - 2017-09-07 15:11:13 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:11:13 --> Model Class Initialized
INFO - 2017-09-07 15:11:13 --> File loaded: C:\xampp\htdocs\biper\application\views\dashboard.php
INFO - 2017-09-07 15:11:13 --> Final output sent to browser
DEBUG - 2017-09-07 15:11:13 --> Total execution time: 0.0900
ERROR - 2017-09-07 15:11:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:11:21 --> Config Class Initialized
INFO - 2017-09-07 15:11:21 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:11:21 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:11:21 --> Utf8 Class Initialized
INFO - 2017-09-07 15:11:21 --> URI Class Initialized
INFO - 2017-09-07 15:11:21 --> Router Class Initialized
INFO - 2017-09-07 15:11:21 --> Output Class Initialized
INFO - 2017-09-07 15:11:21 --> Security Class Initialized
DEBUG - 2017-09-07 15:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:11:21 --> Input Class Initialized
INFO - 2017-09-07 15:11:21 --> Language Class Initialized
INFO - 2017-09-07 15:11:21 --> Loader Class Initialized
INFO - 2017-09-07 15:11:21 --> Controller Class Initialized
INFO - 2017-09-07 15:11:21 --> Database Driver Class Initialized
INFO - 2017-09-07 15:11:21 --> Model Class Initialized
INFO - 2017-09-07 15:11:21 --> Helper loaded: form_helper
INFO - 2017-09-07 15:11:21 --> Helper loaded: url_helper
INFO - 2017-09-07 15:11:21 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:11:21 --> Model Class Initialized
INFO - 2017-09-07 15:11:21 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-07 15:11:21 --> Final output sent to browser
DEBUG - 2017-09-07 15:11:21 --> Total execution time: 0.1030
ERROR - 2017-09-07 15:11:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:11:32 --> Config Class Initialized
INFO - 2017-09-07 15:11:32 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:11:32 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:11:32 --> Utf8 Class Initialized
INFO - 2017-09-07 15:11:32 --> URI Class Initialized
INFO - 2017-09-07 15:11:32 --> Router Class Initialized
INFO - 2017-09-07 15:11:32 --> Output Class Initialized
INFO - 2017-09-07 15:11:32 --> Security Class Initialized
DEBUG - 2017-09-07 15:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:11:32 --> Input Class Initialized
INFO - 2017-09-07 15:11:32 --> Language Class Initialized
INFO - 2017-09-07 15:11:32 --> Loader Class Initialized
INFO - 2017-09-07 15:11:32 --> Controller Class Initialized
INFO - 2017-09-07 15:11:32 --> Database Driver Class Initialized
INFO - 2017-09-07 15:11:32 --> Model Class Initialized
INFO - 2017-09-07 15:11:32 --> Helper loaded: form_helper
INFO - 2017-09-07 15:11:32 --> Helper loaded: url_helper
INFO - 2017-09-07 15:11:32 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:11:32 --> Model Class Initialized
INFO - 2017-09-07 15:11:32 --> File loaded: C:\xampp\htdocs\biper\application\views\purchase.php
INFO - 2017-09-07 15:11:32 --> Final output sent to browser
DEBUG - 2017-09-07 15:11:32 --> Total execution time: 0.0670
ERROR - 2017-09-07 15:11:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\biper\application\vendor/autoload.php was not found.
INFO - 2017-09-07 15:11:34 --> Config Class Initialized
INFO - 2017-09-07 15:11:34 --> Hooks Class Initialized
DEBUG - 2017-09-07 15:11:34 --> UTF-8 Support Enabled
INFO - 2017-09-07 15:11:34 --> Utf8 Class Initialized
INFO - 2017-09-07 15:11:34 --> URI Class Initialized
INFO - 2017-09-07 15:11:34 --> Router Class Initialized
INFO - 2017-09-07 15:11:34 --> Output Class Initialized
INFO - 2017-09-07 15:11:34 --> Security Class Initialized
DEBUG - 2017-09-07 15:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-07 15:11:34 --> Input Class Initialized
INFO - 2017-09-07 15:11:34 --> Language Class Initialized
INFO - 2017-09-07 15:11:34 --> Loader Class Initialized
INFO - 2017-09-07 15:11:34 --> Controller Class Initialized
INFO - 2017-09-07 15:11:34 --> Database Driver Class Initialized
INFO - 2017-09-07 15:11:34 --> Model Class Initialized
INFO - 2017-09-07 15:11:34 --> Helper loaded: form_helper
INFO - 2017-09-07 15:11:34 --> Helper loaded: url_helper
INFO - 2017-09-07 15:11:34 --> File loaded: C:\xampp\htdocs\biper\application\views\header.php
INFO - 2017-09-07 15:11:34 --> Model Class Initialized
INFO - 2017-09-07 15:11:34 --> File loaded: C:\xampp\htdocs\biper\application\views\videos.php
INFO - 2017-09-07 15:11:34 --> Final output sent to browser
DEBUG - 2017-09-07 15:11:34 --> Total execution time: 0.0880
