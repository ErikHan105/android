<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-21 07:50:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-21 07:50:35 --> Config Class Initialized
INFO - 2017-07-21 07:50:35 --> Hooks Class Initialized
DEBUG - 2017-07-21 07:50:35 --> UTF-8 Support Enabled
INFO - 2017-07-21 07:50:35 --> Utf8 Class Initialized
INFO - 2017-07-21 07:50:35 --> URI Class Initialized
INFO - 2017-07-21 07:50:35 --> Router Class Initialized
INFO - 2017-07-21 07:50:35 --> Output Class Initialized
INFO - 2017-07-21 07:50:35 --> Security Class Initialized
DEBUG - 2017-07-21 07:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 07:50:35 --> Input Class Initialized
INFO - 2017-07-21 07:50:35 --> Language Class Initialized
INFO - 2017-07-21 07:50:35 --> Loader Class Initialized
INFO - 2017-07-21 07:50:35 --> Controller Class Initialized
INFO - 2017-07-21 07:50:35 --> Database Driver Class Initialized
INFO - 2017-07-21 07:50:35 --> Model Class Initialized
INFO - 2017-07-21 07:50:35 --> Helper loaded: form_helper
INFO - 2017-07-21 07:50:35 --> Helper loaded: url_helper
INFO - 2017-07-21 07:50:35 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-21 07:50:35 --> Model Class Initialized
INFO - 2017-07-21 07:50:35 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-21 07:50:35 --> Final output sent to browser
DEBUG - 2017-07-21 07:50:35 --> Total execution time: 0.0800
