<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-06 20:22:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:22:22 --> Config Class Initialized
INFO - 2017-07-06 20:22:22 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:22:22 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:22:22 --> Utf8 Class Initialized
INFO - 2017-07-06 20:22:22 --> URI Class Initialized
INFO - 2017-07-06 20:22:22 --> Router Class Initialized
INFO - 2017-07-06 20:22:22 --> Output Class Initialized
INFO - 2017-07-06 20:22:22 --> Security Class Initialized
DEBUG - 2017-07-06 20:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:22:22 --> Input Class Initialized
INFO - 2017-07-06 20:22:22 --> Language Class Initialized
INFO - 2017-07-06 20:22:22 --> Loader Class Initialized
INFO - 2017-07-06 20:22:22 --> Controller Class Initialized
INFO - 2017-07-06 20:22:22 --> Database Driver Class Initialized
INFO - 2017-07-06 20:22:22 --> Model Class Initialized
INFO - 2017-07-06 20:22:22 --> Helper loaded: form_helper
INFO - 2017-07-06 20:22:22 --> Helper loaded: url_helper
INFO - 2017-07-06 20:22:22 --> Model Class Initialized
INFO - 2017-07-06 20:22:22 --> Final output sent to browser
DEBUG - 2017-07-06 20:22:22 --> Total execution time: 0.2280
ERROR - 2017-07-06 20:22:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:22:23 --> Config Class Initialized
INFO - 2017-07-06 20:22:23 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:22:23 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:22:23 --> Utf8 Class Initialized
INFO - 2017-07-06 20:22:23 --> URI Class Initialized
INFO - 2017-07-06 20:22:23 --> Router Class Initialized
INFO - 2017-07-06 20:22:23 --> Output Class Initialized
INFO - 2017-07-06 20:22:23 --> Security Class Initialized
DEBUG - 2017-07-06 20:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:22:23 --> Input Class Initialized
INFO - 2017-07-06 20:22:23 --> Language Class Initialized
INFO - 2017-07-06 20:22:23 --> Loader Class Initialized
INFO - 2017-07-06 20:22:23 --> Controller Class Initialized
INFO - 2017-07-06 20:22:23 --> Database Driver Class Initialized
INFO - 2017-07-06 20:22:23 --> Model Class Initialized
INFO - 2017-07-06 20:22:23 --> Helper loaded: form_helper
INFO - 2017-07-06 20:22:23 --> Helper loaded: url_helper
INFO - 2017-07-06 20:22:23 --> Model Class Initialized
INFO - 2017-07-06 20:22:23 --> Final output sent to browser
DEBUG - 2017-07-06 20:22:23 --> Total execution time: 0.0500
ERROR - 2017-07-06 20:22:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:22:33 --> Config Class Initialized
INFO - 2017-07-06 20:22:33 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:22:33 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:22:33 --> Utf8 Class Initialized
INFO - 2017-07-06 20:22:33 --> URI Class Initialized
INFO - 2017-07-06 20:22:33 --> Router Class Initialized
INFO - 2017-07-06 20:22:33 --> Output Class Initialized
INFO - 2017-07-06 20:22:33 --> Security Class Initialized
DEBUG - 2017-07-06 20:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:22:33 --> Input Class Initialized
INFO - 2017-07-06 20:22:33 --> Language Class Initialized
INFO - 2017-07-06 20:22:33 --> Loader Class Initialized
INFO - 2017-07-06 20:22:33 --> Controller Class Initialized
INFO - 2017-07-06 20:22:33 --> Database Driver Class Initialized
INFO - 2017-07-06 20:22:33 --> Model Class Initialized
INFO - 2017-07-06 20:22:33 --> Helper loaded: form_helper
INFO - 2017-07-06 20:22:33 --> Helper loaded: url_helper
INFO - 2017-07-06 20:22:33 --> Model Class Initialized
INFO - 2017-07-06 20:22:33 --> Final output sent to browser
DEBUG - 2017-07-06 20:22:33 --> Total execution time: 0.0570
ERROR - 2017-07-06 20:22:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:22:57 --> Config Class Initialized
INFO - 2017-07-06 20:22:57 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:22:57 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:22:57 --> Utf8 Class Initialized
INFO - 2017-07-06 20:22:57 --> URI Class Initialized
INFO - 2017-07-06 20:22:57 --> Router Class Initialized
INFO - 2017-07-06 20:22:57 --> Output Class Initialized
INFO - 2017-07-06 20:22:57 --> Security Class Initialized
DEBUG - 2017-07-06 20:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:22:57 --> Input Class Initialized
INFO - 2017-07-06 20:22:57 --> Language Class Initialized
INFO - 2017-07-06 20:22:57 --> Loader Class Initialized
INFO - 2017-07-06 20:22:57 --> Controller Class Initialized
INFO - 2017-07-06 20:22:57 --> Database Driver Class Initialized
INFO - 2017-07-06 20:22:57 --> Model Class Initialized
INFO - 2017-07-06 20:22:57 --> Helper loaded: form_helper
INFO - 2017-07-06 20:22:57 --> Helper loaded: url_helper
INFO - 2017-07-06 20:22:57 --> Model Class Initialized
INFO - 2017-07-06 20:22:57 --> Final output sent to browser
DEBUG - 2017-07-06 20:22:57 --> Total execution time: 0.0430
ERROR - 2017-07-06 20:23:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:23:28 --> Config Class Initialized
INFO - 2017-07-06 20:23:28 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:23:28 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:23:28 --> Utf8 Class Initialized
INFO - 2017-07-06 20:23:28 --> URI Class Initialized
INFO - 2017-07-06 20:23:28 --> Router Class Initialized
INFO - 2017-07-06 20:23:28 --> Output Class Initialized
INFO - 2017-07-06 20:23:28 --> Security Class Initialized
DEBUG - 2017-07-06 20:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:23:28 --> Input Class Initialized
INFO - 2017-07-06 20:23:28 --> Language Class Initialized
INFO - 2017-07-06 20:23:28 --> Loader Class Initialized
INFO - 2017-07-06 20:23:28 --> Controller Class Initialized
INFO - 2017-07-06 20:23:28 --> Database Driver Class Initialized
INFO - 2017-07-06 20:23:28 --> Model Class Initialized
INFO - 2017-07-06 20:23:28 --> Helper loaded: form_helper
INFO - 2017-07-06 20:23:28 --> Helper loaded: url_helper
INFO - 2017-07-06 20:23:28 --> Model Class Initialized
INFO - 2017-07-06 20:23:28 --> Final output sent to browser
DEBUG - 2017-07-06 20:23:28 --> Total execution time: 0.0440
ERROR - 2017-07-06 20:23:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:23:30 --> Config Class Initialized
INFO - 2017-07-06 20:23:30 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:23:30 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:23:30 --> Utf8 Class Initialized
INFO - 2017-07-06 20:23:30 --> URI Class Initialized
INFO - 2017-07-06 20:23:30 --> Router Class Initialized
INFO - 2017-07-06 20:23:30 --> Output Class Initialized
INFO - 2017-07-06 20:23:30 --> Security Class Initialized
DEBUG - 2017-07-06 20:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:23:30 --> Input Class Initialized
INFO - 2017-07-06 20:23:30 --> Language Class Initialized
INFO - 2017-07-06 20:23:30 --> Loader Class Initialized
INFO - 2017-07-06 20:23:30 --> Controller Class Initialized
INFO - 2017-07-06 20:23:30 --> Database Driver Class Initialized
INFO - 2017-07-06 20:23:30 --> Model Class Initialized
INFO - 2017-07-06 20:23:30 --> Helper loaded: form_helper
INFO - 2017-07-06 20:23:30 --> Helper loaded: url_helper
INFO - 2017-07-06 20:23:30 --> Model Class Initialized
INFO - 2017-07-06 20:23:30 --> Final output sent to browser
DEBUG - 2017-07-06 20:23:30 --> Total execution time: 0.0440
ERROR - 2017-07-06 20:25:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:25:36 --> Config Class Initialized
INFO - 2017-07-06 20:25:36 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:25:36 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:25:36 --> Utf8 Class Initialized
INFO - 2017-07-06 20:25:36 --> URI Class Initialized
INFO - 2017-07-06 20:25:36 --> Router Class Initialized
INFO - 2017-07-06 20:25:36 --> Output Class Initialized
INFO - 2017-07-06 20:25:36 --> Security Class Initialized
DEBUG - 2017-07-06 20:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:25:36 --> Input Class Initialized
INFO - 2017-07-06 20:25:36 --> Language Class Initialized
INFO - 2017-07-06 20:25:36 --> Loader Class Initialized
INFO - 2017-07-06 20:25:36 --> Controller Class Initialized
INFO - 2017-07-06 20:25:36 --> Database Driver Class Initialized
INFO - 2017-07-06 20:25:36 --> Model Class Initialized
INFO - 2017-07-06 20:25:36 --> Helper loaded: form_helper
INFO - 2017-07-06 20:25:36 --> Helper loaded: url_helper
INFO - 2017-07-06 20:25:36 --> Model Class Initialized
INFO - 2017-07-06 20:25:36 --> Final output sent to browser
DEBUG - 2017-07-06 20:25:36 --> Total execution time: 0.1180
ERROR - 2017-07-06 20:25:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:25:37 --> Config Class Initialized
INFO - 2017-07-06 20:25:37 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:25:37 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:25:37 --> Utf8 Class Initialized
INFO - 2017-07-06 20:25:37 --> URI Class Initialized
INFO - 2017-07-06 20:25:37 --> Router Class Initialized
INFO - 2017-07-06 20:25:37 --> Output Class Initialized
INFO - 2017-07-06 20:25:37 --> Security Class Initialized
DEBUG - 2017-07-06 20:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:25:37 --> Input Class Initialized
INFO - 2017-07-06 20:25:37 --> Language Class Initialized
INFO - 2017-07-06 20:25:37 --> Loader Class Initialized
INFO - 2017-07-06 20:25:37 --> Controller Class Initialized
INFO - 2017-07-06 20:25:37 --> Database Driver Class Initialized
INFO - 2017-07-06 20:25:37 --> Model Class Initialized
INFO - 2017-07-06 20:25:37 --> Helper loaded: form_helper
INFO - 2017-07-06 20:25:37 --> Helper loaded: url_helper
INFO - 2017-07-06 20:25:37 --> Model Class Initialized
INFO - 2017-07-06 20:25:37 --> Final output sent to browser
DEBUG - 2017-07-06 20:25:37 --> Total execution time: 0.0570
ERROR - 2017-07-06 20:26:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:26:21 --> Config Class Initialized
INFO - 2017-07-06 20:26:21 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:26:21 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:26:21 --> Utf8 Class Initialized
INFO - 2017-07-06 20:26:21 --> URI Class Initialized
INFO - 2017-07-06 20:26:21 --> Router Class Initialized
INFO - 2017-07-06 20:26:21 --> Output Class Initialized
INFO - 2017-07-06 20:26:21 --> Security Class Initialized
DEBUG - 2017-07-06 20:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:26:21 --> Input Class Initialized
INFO - 2017-07-06 20:26:21 --> Language Class Initialized
INFO - 2017-07-06 20:26:21 --> Loader Class Initialized
INFO - 2017-07-06 20:26:21 --> Controller Class Initialized
INFO - 2017-07-06 20:26:21 --> Database Driver Class Initialized
INFO - 2017-07-06 20:26:21 --> Model Class Initialized
INFO - 2017-07-06 20:26:21 --> Helper loaded: form_helper
INFO - 2017-07-06 20:26:21 --> Helper loaded: url_helper
INFO - 2017-07-06 20:26:21 --> Model Class Initialized
INFO - 2017-07-06 20:26:21 --> Final output sent to browser
DEBUG - 2017-07-06 20:26:21 --> Total execution time: 0.0460
ERROR - 2017-07-06 20:26:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:26:22 --> Config Class Initialized
INFO - 2017-07-06 20:26:22 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:26:22 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:26:22 --> Utf8 Class Initialized
INFO - 2017-07-06 20:26:22 --> URI Class Initialized
INFO - 2017-07-06 20:26:22 --> Router Class Initialized
INFO - 2017-07-06 20:26:22 --> Output Class Initialized
INFO - 2017-07-06 20:26:22 --> Security Class Initialized
DEBUG - 2017-07-06 20:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:26:22 --> Input Class Initialized
INFO - 2017-07-06 20:26:22 --> Language Class Initialized
INFO - 2017-07-06 20:26:22 --> Loader Class Initialized
INFO - 2017-07-06 20:26:22 --> Controller Class Initialized
INFO - 2017-07-06 20:26:22 --> Database Driver Class Initialized
INFO - 2017-07-06 20:26:22 --> Model Class Initialized
INFO - 2017-07-06 20:26:22 --> Helper loaded: form_helper
INFO - 2017-07-06 20:26:22 --> Helper loaded: url_helper
INFO - 2017-07-06 20:26:22 --> Model Class Initialized
INFO - 2017-07-06 20:26:22 --> Final output sent to browser
DEBUG - 2017-07-06 20:26:22 --> Total execution time: 0.0390
ERROR - 2017-07-06 20:26:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:26:23 --> Config Class Initialized
INFO - 2017-07-06 20:26:23 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:26:23 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:26:23 --> Utf8 Class Initialized
INFO - 2017-07-06 20:26:23 --> URI Class Initialized
INFO - 2017-07-06 20:26:23 --> Router Class Initialized
INFO - 2017-07-06 20:26:23 --> Output Class Initialized
INFO - 2017-07-06 20:26:23 --> Security Class Initialized
DEBUG - 2017-07-06 20:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:26:23 --> Input Class Initialized
INFO - 2017-07-06 20:26:23 --> Language Class Initialized
INFO - 2017-07-06 20:26:23 --> Loader Class Initialized
INFO - 2017-07-06 20:26:23 --> Controller Class Initialized
INFO - 2017-07-06 20:26:23 --> Database Driver Class Initialized
INFO - 2017-07-06 20:26:23 --> Model Class Initialized
INFO - 2017-07-06 20:26:23 --> Helper loaded: form_helper
INFO - 2017-07-06 20:26:23 --> Helper loaded: url_helper
INFO - 2017-07-06 20:26:23 --> Model Class Initialized
INFO - 2017-07-06 20:26:23 --> Final output sent to browser
DEBUG - 2017-07-06 20:26:23 --> Total execution time: 0.0450
ERROR - 2017-07-06 20:30:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:30:09 --> Config Class Initialized
INFO - 2017-07-06 20:30:09 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:30:09 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:30:09 --> Utf8 Class Initialized
INFO - 2017-07-06 20:30:09 --> URI Class Initialized
INFO - 2017-07-06 20:30:09 --> Router Class Initialized
INFO - 2017-07-06 20:30:09 --> Output Class Initialized
INFO - 2017-07-06 20:30:09 --> Security Class Initialized
DEBUG - 2017-07-06 20:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:30:09 --> Input Class Initialized
INFO - 2017-07-06 20:30:09 --> Language Class Initialized
INFO - 2017-07-06 20:30:09 --> Loader Class Initialized
INFO - 2017-07-06 20:30:09 --> Controller Class Initialized
INFO - 2017-07-06 20:30:09 --> Database Driver Class Initialized
INFO - 2017-07-06 20:30:09 --> Model Class Initialized
INFO - 2017-07-06 20:30:09 --> Helper loaded: form_helper
INFO - 2017-07-06 20:30:09 --> Helper loaded: url_helper
INFO - 2017-07-06 20:30:09 --> Model Class Initialized
INFO - 2017-07-06 20:30:09 --> Final output sent to browser
DEBUG - 2017-07-06 20:30:09 --> Total execution time: 0.0550
ERROR - 2017-07-06 20:30:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:30:10 --> Config Class Initialized
INFO - 2017-07-06 20:30:10 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:30:10 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:30:10 --> Utf8 Class Initialized
INFO - 2017-07-06 20:30:10 --> URI Class Initialized
INFO - 2017-07-06 20:30:10 --> Router Class Initialized
INFO - 2017-07-06 20:30:10 --> Output Class Initialized
INFO - 2017-07-06 20:30:10 --> Security Class Initialized
DEBUG - 2017-07-06 20:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:30:10 --> Input Class Initialized
INFO - 2017-07-06 20:30:10 --> Language Class Initialized
INFO - 2017-07-06 20:30:10 --> Loader Class Initialized
INFO - 2017-07-06 20:30:10 --> Controller Class Initialized
INFO - 2017-07-06 20:30:10 --> Database Driver Class Initialized
INFO - 2017-07-06 20:30:11 --> Model Class Initialized
INFO - 2017-07-06 20:30:11 --> Helper loaded: form_helper
INFO - 2017-07-06 20:30:11 --> Helper loaded: url_helper
INFO - 2017-07-06 20:30:11 --> Model Class Initialized
INFO - 2017-07-06 20:30:11 --> Final output sent to browser
DEBUG - 2017-07-06 20:30:11 --> Total execution time: 0.0580
ERROR - 2017-07-06 20:30:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:30:11 --> Config Class Initialized
INFO - 2017-07-06 20:30:11 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:30:11 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:30:11 --> Utf8 Class Initialized
INFO - 2017-07-06 20:30:11 --> URI Class Initialized
INFO - 2017-07-06 20:30:11 --> Router Class Initialized
INFO - 2017-07-06 20:30:12 --> Output Class Initialized
INFO - 2017-07-06 20:30:12 --> Security Class Initialized
DEBUG - 2017-07-06 20:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:30:12 --> Input Class Initialized
INFO - 2017-07-06 20:30:12 --> Language Class Initialized
INFO - 2017-07-06 20:30:12 --> Loader Class Initialized
INFO - 2017-07-06 20:30:12 --> Controller Class Initialized
INFO - 2017-07-06 20:30:12 --> Database Driver Class Initialized
INFO - 2017-07-06 20:30:12 --> Model Class Initialized
INFO - 2017-07-06 20:30:12 --> Helper loaded: form_helper
INFO - 2017-07-06 20:30:12 --> Helper loaded: url_helper
INFO - 2017-07-06 20:30:12 --> Model Class Initialized
INFO - 2017-07-06 20:30:12 --> Final output sent to browser
DEBUG - 2017-07-06 20:30:12 --> Total execution time: 0.0560
ERROR - 2017-07-06 20:30:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:30:44 --> Config Class Initialized
INFO - 2017-07-06 20:30:44 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:30:44 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:30:44 --> Utf8 Class Initialized
INFO - 2017-07-06 20:30:44 --> URI Class Initialized
INFO - 2017-07-06 20:30:44 --> Router Class Initialized
INFO - 2017-07-06 20:30:44 --> Output Class Initialized
INFO - 2017-07-06 20:30:44 --> Security Class Initialized
DEBUG - 2017-07-06 20:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:30:44 --> Input Class Initialized
INFO - 2017-07-06 20:30:44 --> Language Class Initialized
INFO - 2017-07-06 20:30:44 --> Loader Class Initialized
INFO - 2017-07-06 20:30:44 --> Controller Class Initialized
INFO - 2017-07-06 20:30:44 --> Database Driver Class Initialized
INFO - 2017-07-06 20:30:44 --> Model Class Initialized
INFO - 2017-07-06 20:30:44 --> Helper loaded: form_helper
INFO - 2017-07-06 20:30:44 --> Helper loaded: url_helper
INFO - 2017-07-06 20:30:44 --> Model Class Initialized
INFO - 2017-07-06 20:30:44 --> Final output sent to browser
DEBUG - 2017-07-06 20:30:44 --> Total execution time: 0.0420
ERROR - 2017-07-06 20:32:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:32:42 --> Config Class Initialized
INFO - 2017-07-06 20:32:42 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:32:42 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:32:42 --> Utf8 Class Initialized
INFO - 2017-07-06 20:32:42 --> URI Class Initialized
INFO - 2017-07-06 20:32:42 --> Router Class Initialized
INFO - 2017-07-06 20:32:42 --> Output Class Initialized
INFO - 2017-07-06 20:32:42 --> Security Class Initialized
DEBUG - 2017-07-06 20:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:32:42 --> Input Class Initialized
INFO - 2017-07-06 20:32:42 --> Language Class Initialized
INFO - 2017-07-06 20:32:42 --> Loader Class Initialized
INFO - 2017-07-06 20:32:42 --> Controller Class Initialized
INFO - 2017-07-06 20:32:42 --> Database Driver Class Initialized
INFO - 2017-07-06 20:32:42 --> Model Class Initialized
INFO - 2017-07-06 20:32:42 --> Helper loaded: form_helper
INFO - 2017-07-06 20:32:42 --> Helper loaded: url_helper
INFO - 2017-07-06 20:32:42 --> Model Class Initialized
INFO - 2017-07-06 20:32:42 --> Final output sent to browser
DEBUG - 2017-07-06 20:32:42 --> Total execution time: 0.0570
ERROR - 2017-07-06 20:33:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:33:22 --> Config Class Initialized
INFO - 2017-07-06 20:33:22 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:33:22 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:33:22 --> Utf8 Class Initialized
INFO - 2017-07-06 20:33:22 --> URI Class Initialized
INFO - 2017-07-06 20:33:22 --> Router Class Initialized
INFO - 2017-07-06 20:33:22 --> Output Class Initialized
INFO - 2017-07-06 20:33:22 --> Security Class Initialized
DEBUG - 2017-07-06 20:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:33:22 --> Input Class Initialized
INFO - 2017-07-06 20:33:22 --> Language Class Initialized
INFO - 2017-07-06 20:33:22 --> Loader Class Initialized
INFO - 2017-07-06 20:33:22 --> Controller Class Initialized
INFO - 2017-07-06 20:33:22 --> Database Driver Class Initialized
INFO - 2017-07-06 20:33:22 --> Model Class Initialized
INFO - 2017-07-06 20:33:22 --> Helper loaded: form_helper
INFO - 2017-07-06 20:33:22 --> Helper loaded: url_helper
INFO - 2017-07-06 20:33:22 --> Model Class Initialized
INFO - 2017-07-06 20:33:22 --> Final output sent to browser
DEBUG - 2017-07-06 20:33:22 --> Total execution time: 0.0570
ERROR - 2017-07-06 20:34:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:34:30 --> Config Class Initialized
INFO - 2017-07-06 20:34:30 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:34:30 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:34:30 --> Utf8 Class Initialized
INFO - 2017-07-06 20:34:30 --> URI Class Initialized
INFO - 2017-07-06 20:34:30 --> Router Class Initialized
INFO - 2017-07-06 20:34:30 --> Output Class Initialized
INFO - 2017-07-06 20:34:30 --> Security Class Initialized
DEBUG - 2017-07-06 20:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:34:30 --> Input Class Initialized
INFO - 2017-07-06 20:34:30 --> Language Class Initialized
INFO - 2017-07-06 20:34:30 --> Loader Class Initialized
INFO - 2017-07-06 20:34:30 --> Controller Class Initialized
INFO - 2017-07-06 20:34:30 --> Database Driver Class Initialized
INFO - 2017-07-06 20:34:30 --> Model Class Initialized
INFO - 2017-07-06 20:34:30 --> Helper loaded: form_helper
INFO - 2017-07-06 20:34:30 --> Helper loaded: url_helper
INFO - 2017-07-06 20:34:30 --> Model Class Initialized
INFO - 2017-07-06 20:34:30 --> Final output sent to browser
DEBUG - 2017-07-06 20:34:30 --> Total execution time: 0.0570
ERROR - 2017-07-06 20:34:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:34:31 --> Config Class Initialized
INFO - 2017-07-06 20:34:31 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:34:31 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:34:31 --> Utf8 Class Initialized
INFO - 2017-07-06 20:34:31 --> URI Class Initialized
INFO - 2017-07-06 20:34:31 --> Router Class Initialized
INFO - 2017-07-06 20:34:31 --> Output Class Initialized
INFO - 2017-07-06 20:34:31 --> Security Class Initialized
DEBUG - 2017-07-06 20:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:34:31 --> Input Class Initialized
INFO - 2017-07-06 20:34:31 --> Language Class Initialized
INFO - 2017-07-06 20:34:31 --> Loader Class Initialized
INFO - 2017-07-06 20:34:31 --> Controller Class Initialized
INFO - 2017-07-06 20:34:31 --> Database Driver Class Initialized
INFO - 2017-07-06 20:34:31 --> Model Class Initialized
INFO - 2017-07-06 20:34:31 --> Helper loaded: form_helper
INFO - 2017-07-06 20:34:31 --> Helper loaded: url_helper
INFO - 2017-07-06 20:34:31 --> Model Class Initialized
INFO - 2017-07-06 20:34:31 --> Final output sent to browser
DEBUG - 2017-07-06 20:34:31 --> Total execution time: 0.0550
ERROR - 2017-07-06 20:34:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:34:48 --> Config Class Initialized
INFO - 2017-07-06 20:34:48 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:34:48 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:34:48 --> Utf8 Class Initialized
INFO - 2017-07-06 20:34:48 --> URI Class Initialized
DEBUG - 2017-07-06 20:34:48 --> No URI present. Default controller set.
INFO - 2017-07-06 20:34:48 --> Router Class Initialized
INFO - 2017-07-06 20:34:48 --> Output Class Initialized
INFO - 2017-07-06 20:34:48 --> Security Class Initialized
DEBUG - 2017-07-06 20:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:34:48 --> Input Class Initialized
INFO - 2017-07-06 20:34:48 --> Language Class Initialized
INFO - 2017-07-06 20:34:48 --> Loader Class Initialized
INFO - 2017-07-06 20:34:48 --> Controller Class Initialized
INFO - 2017-07-06 20:34:48 --> Database Driver Class Initialized
INFO - 2017-07-06 20:34:48 --> Model Class Initialized
INFO - 2017-07-06 20:34:48 --> Helper loaded: form_helper
INFO - 2017-07-06 20:34:48 --> Helper loaded: url_helper
INFO - 2017-07-06 20:34:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-06 20:34:48 --> Final output sent to browser
DEBUG - 2017-07-06 20:34:48 --> Total execution time: 0.0940
ERROR - 2017-07-06 20:34:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:34:50 --> Config Class Initialized
INFO - 2017-07-06 20:34:50 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:34:50 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:34:50 --> Utf8 Class Initialized
INFO - 2017-07-06 20:34:50 --> URI Class Initialized
INFO - 2017-07-06 20:34:50 --> Router Class Initialized
INFO - 2017-07-06 20:34:50 --> Output Class Initialized
INFO - 2017-07-06 20:34:50 --> Security Class Initialized
DEBUG - 2017-07-06 20:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:34:50 --> Input Class Initialized
INFO - 2017-07-06 20:34:50 --> Language Class Initialized
INFO - 2017-07-06 20:34:50 --> Loader Class Initialized
INFO - 2017-07-06 20:34:50 --> Controller Class Initialized
INFO - 2017-07-06 20:34:50 --> Database Driver Class Initialized
INFO - 2017-07-06 20:34:50 --> Model Class Initialized
INFO - 2017-07-06 20:34:50 --> Helper loaded: form_helper
INFO - 2017-07-06 20:34:50 --> Helper loaded: url_helper
INFO - 2017-07-06 20:34:50 --> Model Class Initialized
ERROR - 2017-07-06 20:34:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:34:50 --> Config Class Initialized
INFO - 2017-07-06 20:34:50 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:34:50 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:34:51 --> Utf8 Class Initialized
INFO - 2017-07-06 20:34:51 --> URI Class Initialized
INFO - 2017-07-06 20:34:51 --> Router Class Initialized
INFO - 2017-07-06 20:34:51 --> Output Class Initialized
INFO - 2017-07-06 20:34:51 --> Security Class Initialized
DEBUG - 2017-07-06 20:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:34:51 --> Input Class Initialized
INFO - 2017-07-06 20:34:51 --> Language Class Initialized
INFO - 2017-07-06 20:34:51 --> Loader Class Initialized
INFO - 2017-07-06 20:34:51 --> Controller Class Initialized
INFO - 2017-07-06 20:34:51 --> Database Driver Class Initialized
INFO - 2017-07-06 20:34:51 --> Model Class Initialized
INFO - 2017-07-06 20:34:51 --> Helper loaded: form_helper
INFO - 2017-07-06 20:34:51 --> Helper loaded: url_helper
INFO - 2017-07-06 20:34:51 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-06 20:34:51 --> Model Class Initialized
INFO - 2017-07-06 20:34:51 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-06 20:34:51 --> Final output sent to browser
DEBUG - 2017-07-06 20:34:51 --> Total execution time: 0.0910
ERROR - 2017-07-06 20:34:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:34:57 --> Config Class Initialized
INFO - 2017-07-06 20:34:57 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:34:57 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:34:57 --> Utf8 Class Initialized
INFO - 2017-07-06 20:34:57 --> URI Class Initialized
INFO - 2017-07-06 20:34:57 --> Router Class Initialized
INFO - 2017-07-06 20:34:57 --> Output Class Initialized
INFO - 2017-07-06 20:34:57 --> Security Class Initialized
DEBUG - 2017-07-06 20:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:34:57 --> Input Class Initialized
INFO - 2017-07-06 20:34:57 --> Language Class Initialized
INFO - 2017-07-06 20:34:57 --> Loader Class Initialized
INFO - 2017-07-06 20:34:57 --> Controller Class Initialized
INFO - 2017-07-06 20:34:57 --> Database Driver Class Initialized
INFO - 2017-07-06 20:34:57 --> Model Class Initialized
INFO - 2017-07-06 20:34:57 --> Helper loaded: form_helper
INFO - 2017-07-06 20:34:57 --> Helper loaded: url_helper
INFO - 2017-07-06 20:34:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-06 20:34:57 --> Model Class Initialized
INFO - 2017-07-06 20:34:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-06 20:34:57 --> Final output sent to browser
DEBUG - 2017-07-06 20:34:57 --> Total execution time: 0.0600
ERROR - 2017-07-06 20:35:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:35:01 --> Config Class Initialized
INFO - 2017-07-06 20:35:01 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:35:01 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:35:01 --> Utf8 Class Initialized
INFO - 2017-07-06 20:35:01 --> URI Class Initialized
INFO - 2017-07-06 20:35:01 --> Router Class Initialized
INFO - 2017-07-06 20:35:01 --> Output Class Initialized
INFO - 2017-07-06 20:35:01 --> Security Class Initialized
DEBUG - 2017-07-06 20:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:35:01 --> Input Class Initialized
INFO - 2017-07-06 20:35:01 --> Language Class Initialized
INFO - 2017-07-06 20:35:01 --> Loader Class Initialized
INFO - 2017-07-06 20:35:01 --> Controller Class Initialized
INFO - 2017-07-06 20:35:01 --> Database Driver Class Initialized
INFO - 2017-07-06 20:35:01 --> Model Class Initialized
INFO - 2017-07-06 20:35:01 --> Helper loaded: form_helper
INFO - 2017-07-06 20:35:01 --> Helper loaded: url_helper
INFO - 2017-07-06 20:35:01 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-06 20:35:01 --> Model Class Initialized
INFO - 2017-07-06 20:35:01 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-06 20:35:01 --> Final output sent to browser
DEBUG - 2017-07-06 20:35:01 --> Total execution time: 0.0690
ERROR - 2017-07-06 20:35:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:35:05 --> Config Class Initialized
INFO - 2017-07-06 20:35:05 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:35:05 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:35:05 --> Utf8 Class Initialized
INFO - 2017-07-06 20:35:05 --> URI Class Initialized
INFO - 2017-07-06 20:35:05 --> Router Class Initialized
INFO - 2017-07-06 20:35:05 --> Output Class Initialized
INFO - 2017-07-06 20:35:05 --> Security Class Initialized
DEBUG - 2017-07-06 20:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:35:05 --> Input Class Initialized
INFO - 2017-07-06 20:35:05 --> Language Class Initialized
INFO - 2017-07-06 20:35:05 --> Loader Class Initialized
INFO - 2017-07-06 20:35:05 --> Controller Class Initialized
INFO - 2017-07-06 20:35:05 --> Database Driver Class Initialized
INFO - 2017-07-06 20:35:05 --> Model Class Initialized
INFO - 2017-07-06 20:35:05 --> Helper loaded: form_helper
INFO - 2017-07-06 20:35:05 --> Helper loaded: url_helper
INFO - 2017-07-06 20:35:05 --> Model Class Initialized
INFO - 2017-07-06 20:35:05 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-06 20:35:05 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-06 20:35:05 --> Final output sent to browser
DEBUG - 2017-07-06 20:35:05 --> Total execution time: 0.1880
ERROR - 2017-07-06 20:35:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:35:08 --> Config Class Initialized
INFO - 2017-07-06 20:35:08 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:35:08 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:35:08 --> Utf8 Class Initialized
INFO - 2017-07-06 20:35:09 --> URI Class Initialized
INFO - 2017-07-06 20:35:09 --> Router Class Initialized
INFO - 2017-07-06 20:35:09 --> Output Class Initialized
INFO - 2017-07-06 20:35:09 --> Security Class Initialized
DEBUG - 2017-07-06 20:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:35:09 --> Input Class Initialized
INFO - 2017-07-06 20:35:09 --> Language Class Initialized
INFO - 2017-07-06 20:35:09 --> Loader Class Initialized
INFO - 2017-07-06 20:35:09 --> Controller Class Initialized
INFO - 2017-07-06 20:35:09 --> Database Driver Class Initialized
INFO - 2017-07-06 20:35:09 --> Model Class Initialized
INFO - 2017-07-06 20:35:09 --> Helper loaded: form_helper
INFO - 2017-07-06 20:35:09 --> Helper loaded: url_helper
INFO - 2017-07-06 20:35:09 --> Model Class Initialized
INFO - 2017-07-06 20:35:09 --> Final output sent to browser
DEBUG - 2017-07-06 20:35:09 --> Total execution time: 0.0960
ERROR - 2017-07-06 20:35:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:35:10 --> Config Class Initialized
INFO - 2017-07-06 20:35:10 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:35:10 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:35:10 --> Utf8 Class Initialized
INFO - 2017-07-06 20:35:10 --> URI Class Initialized
INFO - 2017-07-06 20:35:10 --> Router Class Initialized
INFO - 2017-07-06 20:35:10 --> Output Class Initialized
INFO - 2017-07-06 20:35:10 --> Security Class Initialized
DEBUG - 2017-07-06 20:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:35:10 --> Input Class Initialized
INFO - 2017-07-06 20:35:10 --> Language Class Initialized
INFO - 2017-07-06 20:35:10 --> Loader Class Initialized
INFO - 2017-07-06 20:35:10 --> Controller Class Initialized
INFO - 2017-07-06 20:35:10 --> Database Driver Class Initialized
INFO - 2017-07-06 20:35:10 --> Model Class Initialized
INFO - 2017-07-06 20:35:10 --> Helper loaded: form_helper
INFO - 2017-07-06 20:35:10 --> Helper loaded: url_helper
INFO - 2017-07-06 20:35:10 --> Model Class Initialized
INFO - 2017-07-06 20:35:10 --> Final output sent to browser
DEBUG - 2017-07-06 20:35:10 --> Total execution time: 0.1520
ERROR - 2017-07-06 20:35:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:35:11 --> Config Class Initialized
INFO - 2017-07-06 20:35:11 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:35:11 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:35:11 --> Utf8 Class Initialized
INFO - 2017-07-06 20:35:11 --> URI Class Initialized
INFO - 2017-07-06 20:35:11 --> Router Class Initialized
INFO - 2017-07-06 20:35:11 --> Output Class Initialized
INFO - 2017-07-06 20:35:11 --> Security Class Initialized
DEBUG - 2017-07-06 20:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:35:11 --> Input Class Initialized
INFO - 2017-07-06 20:35:11 --> Language Class Initialized
INFO - 2017-07-06 20:35:11 --> Loader Class Initialized
INFO - 2017-07-06 20:35:11 --> Controller Class Initialized
INFO - 2017-07-06 20:35:11 --> Database Driver Class Initialized
INFO - 2017-07-06 20:35:11 --> Model Class Initialized
INFO - 2017-07-06 20:35:11 --> Helper loaded: form_helper
INFO - 2017-07-06 20:35:11 --> Helper loaded: url_helper
INFO - 2017-07-06 20:35:11 --> Model Class Initialized
INFO - 2017-07-06 20:35:11 --> Final output sent to browser
DEBUG - 2017-07-06 20:35:11 --> Total execution time: 0.0570
ERROR - 2017-07-06 20:35:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:35:22 --> Config Class Initialized
INFO - 2017-07-06 20:35:22 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:35:22 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:35:22 --> Utf8 Class Initialized
INFO - 2017-07-06 20:35:22 --> URI Class Initialized
INFO - 2017-07-06 20:35:22 --> Router Class Initialized
INFO - 2017-07-06 20:35:22 --> Output Class Initialized
INFO - 2017-07-06 20:35:22 --> Security Class Initialized
DEBUG - 2017-07-06 20:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:35:22 --> Input Class Initialized
INFO - 2017-07-06 20:35:22 --> Language Class Initialized
INFO - 2017-07-06 20:35:22 --> Loader Class Initialized
INFO - 2017-07-06 20:35:22 --> Controller Class Initialized
INFO - 2017-07-06 20:35:22 --> Database Driver Class Initialized
INFO - 2017-07-06 20:35:22 --> Model Class Initialized
INFO - 2017-07-06 20:35:22 --> Helper loaded: form_helper
INFO - 2017-07-06 20:35:22 --> Helper loaded: url_helper
INFO - 2017-07-06 20:35:22 --> Model Class Initialized
INFO - 2017-07-06 20:35:22 --> Final output sent to browser
DEBUG - 2017-07-06 20:35:22 --> Total execution time: 0.0540
ERROR - 2017-07-06 20:35:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:35:32 --> Config Class Initialized
INFO - 2017-07-06 20:35:32 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:35:32 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:35:32 --> Utf8 Class Initialized
INFO - 2017-07-06 20:35:32 --> URI Class Initialized
INFO - 2017-07-06 20:35:32 --> Router Class Initialized
INFO - 2017-07-06 20:35:32 --> Output Class Initialized
INFO - 2017-07-06 20:35:32 --> Security Class Initialized
DEBUG - 2017-07-06 20:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:35:32 --> Input Class Initialized
INFO - 2017-07-06 20:35:32 --> Language Class Initialized
INFO - 2017-07-06 20:35:32 --> Loader Class Initialized
INFO - 2017-07-06 20:35:32 --> Controller Class Initialized
INFO - 2017-07-06 20:35:32 --> Database Driver Class Initialized
INFO - 2017-07-06 20:35:32 --> Model Class Initialized
INFO - 2017-07-06 20:35:32 --> Helper loaded: form_helper
INFO - 2017-07-06 20:35:32 --> Helper loaded: url_helper
INFO - 2017-07-06 20:35:32 --> Model Class Initialized
INFO - 2017-07-06 20:35:32 --> Final output sent to browser
DEBUG - 2017-07-06 20:35:32 --> Total execution time: 0.0490
ERROR - 2017-07-06 20:35:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:35:36 --> Config Class Initialized
INFO - 2017-07-06 20:35:36 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:35:36 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:35:36 --> Utf8 Class Initialized
INFO - 2017-07-06 20:35:36 --> URI Class Initialized
INFO - 2017-07-06 20:35:36 --> Router Class Initialized
INFO - 2017-07-06 20:35:36 --> Output Class Initialized
INFO - 2017-07-06 20:35:36 --> Security Class Initialized
DEBUG - 2017-07-06 20:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:35:36 --> Input Class Initialized
INFO - 2017-07-06 20:35:36 --> Language Class Initialized
INFO - 2017-07-06 20:35:36 --> Loader Class Initialized
INFO - 2017-07-06 20:35:36 --> Controller Class Initialized
INFO - 2017-07-06 20:35:36 --> Database Driver Class Initialized
INFO - 2017-07-06 20:35:36 --> Model Class Initialized
INFO - 2017-07-06 20:35:36 --> Helper loaded: form_helper
INFO - 2017-07-06 20:35:36 --> Helper loaded: url_helper
INFO - 2017-07-06 20:35:36 --> Model Class Initialized
INFO - 2017-07-06 20:35:36 --> Final output sent to browser
DEBUG - 2017-07-06 20:35:36 --> Total execution time: 0.0640
ERROR - 2017-07-06 20:35:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:35:39 --> Config Class Initialized
INFO - 2017-07-06 20:35:39 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:35:39 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:35:39 --> Utf8 Class Initialized
INFO - 2017-07-06 20:35:39 --> URI Class Initialized
INFO - 2017-07-06 20:35:39 --> Router Class Initialized
INFO - 2017-07-06 20:35:39 --> Output Class Initialized
INFO - 2017-07-06 20:35:39 --> Security Class Initialized
DEBUG - 2017-07-06 20:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:35:39 --> Input Class Initialized
INFO - 2017-07-06 20:35:39 --> Language Class Initialized
INFO - 2017-07-06 20:35:39 --> Loader Class Initialized
INFO - 2017-07-06 20:35:39 --> Controller Class Initialized
INFO - 2017-07-06 20:35:39 --> Database Driver Class Initialized
INFO - 2017-07-06 20:35:39 --> Model Class Initialized
INFO - 2017-07-06 20:35:39 --> Helper loaded: form_helper
INFO - 2017-07-06 20:35:39 --> Helper loaded: url_helper
INFO - 2017-07-06 20:35:39 --> Model Class Initialized
INFO - 2017-07-06 20:35:39 --> Final output sent to browser
DEBUG - 2017-07-06 20:35:39 --> Total execution time: 0.0480
ERROR - 2017-07-06 20:36:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:36:34 --> Config Class Initialized
INFO - 2017-07-06 20:36:34 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:36:34 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:36:34 --> Utf8 Class Initialized
INFO - 2017-07-06 20:36:34 --> URI Class Initialized
INFO - 2017-07-06 20:36:34 --> Router Class Initialized
INFO - 2017-07-06 20:36:34 --> Output Class Initialized
INFO - 2017-07-06 20:36:34 --> Security Class Initialized
DEBUG - 2017-07-06 20:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:36:34 --> Input Class Initialized
INFO - 2017-07-06 20:36:34 --> Language Class Initialized
INFO - 2017-07-06 20:36:34 --> Loader Class Initialized
INFO - 2017-07-06 20:36:34 --> Controller Class Initialized
INFO - 2017-07-06 20:36:34 --> Database Driver Class Initialized
INFO - 2017-07-06 20:36:34 --> Model Class Initialized
INFO - 2017-07-06 20:36:34 --> Helper loaded: form_helper
INFO - 2017-07-06 20:36:34 --> Helper loaded: url_helper
INFO - 2017-07-06 20:36:34 --> Model Class Initialized
INFO - 2017-07-06 20:36:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-06 20:36:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-06 20:36:34 --> Final output sent to browser
DEBUG - 2017-07-06 20:36:34 --> Total execution time: 0.0720
ERROR - 2017-07-06 20:36:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:36:52 --> Config Class Initialized
INFO - 2017-07-06 20:36:52 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:36:52 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:36:52 --> Utf8 Class Initialized
INFO - 2017-07-06 20:36:52 --> URI Class Initialized
INFO - 2017-07-06 20:36:52 --> Router Class Initialized
INFO - 2017-07-06 20:36:52 --> Output Class Initialized
INFO - 2017-07-06 20:36:52 --> Security Class Initialized
DEBUG - 2017-07-06 20:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:36:52 --> Input Class Initialized
INFO - 2017-07-06 20:36:52 --> Language Class Initialized
INFO - 2017-07-06 20:36:52 --> Loader Class Initialized
INFO - 2017-07-06 20:36:52 --> Controller Class Initialized
INFO - 2017-07-06 20:36:52 --> Database Driver Class Initialized
INFO - 2017-07-06 20:36:52 --> Model Class Initialized
INFO - 2017-07-06 20:36:52 --> Helper loaded: form_helper
INFO - 2017-07-06 20:36:52 --> Helper loaded: url_helper
INFO - 2017-07-06 20:36:52 --> Model Class Initialized
INFO - 2017-07-06 20:36:52 --> Final output sent to browser
DEBUG - 2017-07-06 20:36:52 --> Total execution time: 0.0500
ERROR - 2017-07-06 20:36:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:36:53 --> Config Class Initialized
INFO - 2017-07-06 20:36:53 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:36:53 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:36:53 --> Utf8 Class Initialized
INFO - 2017-07-06 20:36:53 --> URI Class Initialized
INFO - 2017-07-06 20:36:53 --> Router Class Initialized
INFO - 2017-07-06 20:36:53 --> Output Class Initialized
INFO - 2017-07-06 20:36:53 --> Security Class Initialized
DEBUG - 2017-07-06 20:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:36:53 --> Input Class Initialized
INFO - 2017-07-06 20:36:53 --> Language Class Initialized
INFO - 2017-07-06 20:36:53 --> Loader Class Initialized
INFO - 2017-07-06 20:36:53 --> Controller Class Initialized
INFO - 2017-07-06 20:36:53 --> Database Driver Class Initialized
INFO - 2017-07-06 20:36:53 --> Model Class Initialized
INFO - 2017-07-06 20:36:53 --> Helper loaded: form_helper
INFO - 2017-07-06 20:36:53 --> Helper loaded: url_helper
INFO - 2017-07-06 20:36:53 --> Model Class Initialized
INFO - 2017-07-06 20:36:53 --> Final output sent to browser
DEBUG - 2017-07-06 20:36:53 --> Total execution time: 0.0470
ERROR - 2017-07-06 20:36:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:36:57 --> Config Class Initialized
INFO - 2017-07-06 20:36:57 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:36:57 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:36:57 --> Utf8 Class Initialized
INFO - 2017-07-06 20:36:57 --> URI Class Initialized
INFO - 2017-07-06 20:36:57 --> Router Class Initialized
INFO - 2017-07-06 20:36:57 --> Output Class Initialized
INFO - 2017-07-06 20:36:57 --> Security Class Initialized
DEBUG - 2017-07-06 20:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:36:57 --> Input Class Initialized
INFO - 2017-07-06 20:36:57 --> Language Class Initialized
INFO - 2017-07-06 20:36:57 --> Loader Class Initialized
INFO - 2017-07-06 20:36:57 --> Controller Class Initialized
INFO - 2017-07-06 20:36:57 --> Database Driver Class Initialized
INFO - 2017-07-06 20:36:57 --> Model Class Initialized
INFO - 2017-07-06 20:36:57 --> Helper loaded: form_helper
INFO - 2017-07-06 20:36:57 --> Helper loaded: url_helper
INFO - 2017-07-06 20:36:57 --> Model Class Initialized
INFO - 2017-07-06 20:36:57 --> Final output sent to browser
DEBUG - 2017-07-06 20:36:57 --> Total execution time: 0.0590
ERROR - 2017-07-06 20:36:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:36:59 --> Config Class Initialized
INFO - 2017-07-06 20:36:59 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:36:59 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:36:59 --> Utf8 Class Initialized
INFO - 2017-07-06 20:36:59 --> URI Class Initialized
INFO - 2017-07-06 20:36:59 --> Router Class Initialized
INFO - 2017-07-06 20:36:59 --> Output Class Initialized
INFO - 2017-07-06 20:36:59 --> Security Class Initialized
DEBUG - 2017-07-06 20:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:36:59 --> Input Class Initialized
INFO - 2017-07-06 20:36:59 --> Language Class Initialized
INFO - 2017-07-06 20:36:59 --> Loader Class Initialized
INFO - 2017-07-06 20:36:59 --> Controller Class Initialized
INFO - 2017-07-06 20:36:59 --> Database Driver Class Initialized
INFO - 2017-07-06 20:36:59 --> Model Class Initialized
INFO - 2017-07-06 20:36:59 --> Helper loaded: form_helper
INFO - 2017-07-06 20:36:59 --> Helper loaded: url_helper
INFO - 2017-07-06 20:36:59 --> Model Class Initialized
INFO - 2017-07-06 20:36:59 --> Final output sent to browser
DEBUG - 2017-07-06 20:36:59 --> Total execution time: 0.0460
ERROR - 2017-07-06 20:41:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:41:50 --> Config Class Initialized
INFO - 2017-07-06 20:41:50 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:41:50 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:41:50 --> Utf8 Class Initialized
INFO - 2017-07-06 20:41:50 --> URI Class Initialized
INFO - 2017-07-06 20:41:50 --> Router Class Initialized
INFO - 2017-07-06 20:41:50 --> Output Class Initialized
INFO - 2017-07-06 20:41:50 --> Security Class Initialized
DEBUG - 2017-07-06 20:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:41:50 --> Input Class Initialized
INFO - 2017-07-06 20:41:50 --> Language Class Initialized
INFO - 2017-07-06 20:41:50 --> Loader Class Initialized
INFO - 2017-07-06 20:41:50 --> Controller Class Initialized
INFO - 2017-07-06 20:41:50 --> Database Driver Class Initialized
INFO - 2017-07-06 20:41:50 --> Model Class Initialized
INFO - 2017-07-06 20:41:50 --> Helper loaded: form_helper
INFO - 2017-07-06 20:41:50 --> Helper loaded: url_helper
INFO - 2017-07-06 20:41:50 --> Model Class Initialized
INFO - 2017-07-06 20:41:50 --> Final output sent to browser
DEBUG - 2017-07-06 20:41:50 --> Total execution time: 0.0590
ERROR - 2017-07-06 20:41:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:41:50 --> Config Class Initialized
INFO - 2017-07-06 20:41:50 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:41:50 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:41:50 --> Utf8 Class Initialized
INFO - 2017-07-06 20:41:50 --> URI Class Initialized
INFO - 2017-07-06 20:41:50 --> Router Class Initialized
INFO - 2017-07-06 20:41:50 --> Output Class Initialized
INFO - 2017-07-06 20:41:50 --> Security Class Initialized
DEBUG - 2017-07-06 20:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:41:50 --> Input Class Initialized
INFO - 2017-07-06 20:41:50 --> Language Class Initialized
INFO - 2017-07-06 20:41:50 --> Loader Class Initialized
INFO - 2017-07-06 20:41:50 --> Controller Class Initialized
INFO - 2017-07-06 20:41:50 --> Database Driver Class Initialized
INFO - 2017-07-06 20:41:50 --> Model Class Initialized
INFO - 2017-07-06 20:41:50 --> Helper loaded: form_helper
INFO - 2017-07-06 20:41:50 --> Helper loaded: url_helper
INFO - 2017-07-06 20:41:50 --> Model Class Initialized
INFO - 2017-07-06 20:41:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-06 20:41:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-06 20:41:50 --> Final output sent to browser
DEBUG - 2017-07-06 20:41:50 --> Total execution time: 0.4110
ERROR - 2017-07-06 20:41:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:41:51 --> Config Class Initialized
INFO - 2017-07-06 20:41:51 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:41:51 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:41:51 --> Utf8 Class Initialized
INFO - 2017-07-06 20:41:51 --> URI Class Initialized
INFO - 2017-07-06 20:41:51 --> Router Class Initialized
INFO - 2017-07-06 20:41:51 --> Output Class Initialized
INFO - 2017-07-06 20:41:51 --> Security Class Initialized
DEBUG - 2017-07-06 20:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:41:51 --> Input Class Initialized
INFO - 2017-07-06 20:41:51 --> Language Class Initialized
INFO - 2017-07-06 20:41:51 --> Loader Class Initialized
INFO - 2017-07-06 20:41:51 --> Controller Class Initialized
INFO - 2017-07-06 20:41:51 --> Database Driver Class Initialized
INFO - 2017-07-06 20:41:51 --> Model Class Initialized
INFO - 2017-07-06 20:41:51 --> Helper loaded: form_helper
INFO - 2017-07-06 20:41:51 --> Helper loaded: url_helper
INFO - 2017-07-06 20:41:51 --> Model Class Initialized
INFO - 2017-07-06 20:41:51 --> Final output sent to browser
DEBUG - 2017-07-06 20:41:51 --> Total execution time: 0.0480
ERROR - 2017-07-06 20:42:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:42:01 --> Config Class Initialized
INFO - 2017-07-06 20:42:01 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:42:01 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:42:01 --> Utf8 Class Initialized
INFO - 2017-07-06 20:42:01 --> URI Class Initialized
INFO - 2017-07-06 20:42:01 --> Router Class Initialized
INFO - 2017-07-06 20:42:01 --> Output Class Initialized
INFO - 2017-07-06 20:42:01 --> Security Class Initialized
DEBUG - 2017-07-06 20:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:42:01 --> Input Class Initialized
INFO - 2017-07-06 20:42:01 --> Language Class Initialized
INFO - 2017-07-06 20:42:01 --> Loader Class Initialized
INFO - 2017-07-06 20:42:01 --> Controller Class Initialized
INFO - 2017-07-06 20:42:01 --> Database Driver Class Initialized
INFO - 2017-07-06 20:42:01 --> Model Class Initialized
INFO - 2017-07-06 20:42:01 --> Helper loaded: form_helper
INFO - 2017-07-06 20:42:01 --> Helper loaded: url_helper
INFO - 2017-07-06 20:42:01 --> Model Class Initialized
INFO - 2017-07-06 20:42:01 --> Final output sent to browser
DEBUG - 2017-07-06 20:42:01 --> Total execution time: 0.0660
ERROR - 2017-07-06 20:42:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:42:04 --> Config Class Initialized
INFO - 2017-07-06 20:42:04 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:42:04 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:42:04 --> Utf8 Class Initialized
INFO - 2017-07-06 20:42:04 --> URI Class Initialized
INFO - 2017-07-06 20:42:04 --> Router Class Initialized
INFO - 2017-07-06 20:42:04 --> Output Class Initialized
INFO - 2017-07-06 20:42:04 --> Security Class Initialized
DEBUG - 2017-07-06 20:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:42:04 --> Input Class Initialized
INFO - 2017-07-06 20:42:04 --> Language Class Initialized
INFO - 2017-07-06 20:42:04 --> Loader Class Initialized
INFO - 2017-07-06 20:42:04 --> Controller Class Initialized
INFO - 2017-07-06 20:42:04 --> Database Driver Class Initialized
INFO - 2017-07-06 20:42:04 --> Model Class Initialized
INFO - 2017-07-06 20:42:04 --> Helper loaded: form_helper
INFO - 2017-07-06 20:42:04 --> Helper loaded: url_helper
INFO - 2017-07-06 20:42:04 --> Model Class Initialized
INFO - 2017-07-06 20:42:04 --> Final output sent to browser
DEBUG - 2017-07-06 20:42:04 --> Total execution time: 0.0500
ERROR - 2017-07-06 20:42:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:42:53 --> Config Class Initialized
INFO - 2017-07-06 20:42:53 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:42:53 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:42:53 --> Utf8 Class Initialized
INFO - 2017-07-06 20:42:53 --> URI Class Initialized
INFO - 2017-07-06 20:42:53 --> Router Class Initialized
INFO - 2017-07-06 20:42:53 --> Output Class Initialized
INFO - 2017-07-06 20:42:53 --> Security Class Initialized
DEBUG - 2017-07-06 20:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:42:53 --> Input Class Initialized
INFO - 2017-07-06 20:42:53 --> Language Class Initialized
INFO - 2017-07-06 20:42:53 --> Loader Class Initialized
INFO - 2017-07-06 20:42:53 --> Controller Class Initialized
INFO - 2017-07-06 20:42:53 --> Database Driver Class Initialized
INFO - 2017-07-06 20:42:53 --> Model Class Initialized
INFO - 2017-07-06 20:42:53 --> Helper loaded: form_helper
INFO - 2017-07-06 20:42:53 --> Helper loaded: url_helper
INFO - 2017-07-06 20:42:53 --> Model Class Initialized
INFO - 2017-07-06 20:42:53 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-06 20:42:53 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-06 20:42:53 --> Final output sent to browser
DEBUG - 2017-07-06 20:42:53 --> Total execution time: 0.0840
ERROR - 2017-07-06 20:42:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:42:58 --> Config Class Initialized
INFO - 2017-07-06 20:42:58 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:42:58 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:42:58 --> Utf8 Class Initialized
INFO - 2017-07-06 20:42:58 --> URI Class Initialized
INFO - 2017-07-06 20:42:58 --> Router Class Initialized
INFO - 2017-07-06 20:42:58 --> Output Class Initialized
INFO - 2017-07-06 20:42:58 --> Security Class Initialized
DEBUG - 2017-07-06 20:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:42:58 --> Input Class Initialized
INFO - 2017-07-06 20:42:58 --> Language Class Initialized
INFO - 2017-07-06 20:42:58 --> Loader Class Initialized
INFO - 2017-07-06 20:42:58 --> Controller Class Initialized
INFO - 2017-07-06 20:42:58 --> Database Driver Class Initialized
INFO - 2017-07-06 20:42:58 --> Model Class Initialized
INFO - 2017-07-06 20:42:58 --> Helper loaded: form_helper
INFO - 2017-07-06 20:42:58 --> Helper loaded: url_helper
INFO - 2017-07-06 20:42:58 --> Model Class Initialized
INFO - 2017-07-06 20:42:58 --> Final output sent to browser
DEBUG - 2017-07-06 20:42:58 --> Total execution time: 0.0470
ERROR - 2017-07-06 20:42:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:42:59 --> Config Class Initialized
INFO - 2017-07-06 20:42:59 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:42:59 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:42:59 --> Utf8 Class Initialized
INFO - 2017-07-06 20:42:59 --> URI Class Initialized
INFO - 2017-07-06 20:42:59 --> Router Class Initialized
INFO - 2017-07-06 20:42:59 --> Output Class Initialized
INFO - 2017-07-06 20:42:59 --> Security Class Initialized
DEBUG - 2017-07-06 20:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:42:59 --> Input Class Initialized
INFO - 2017-07-06 20:42:59 --> Language Class Initialized
INFO - 2017-07-06 20:42:59 --> Loader Class Initialized
INFO - 2017-07-06 20:42:59 --> Controller Class Initialized
INFO - 2017-07-06 20:42:59 --> Database Driver Class Initialized
INFO - 2017-07-06 20:42:59 --> Model Class Initialized
INFO - 2017-07-06 20:42:59 --> Helper loaded: form_helper
INFO - 2017-07-06 20:42:59 --> Helper loaded: url_helper
INFO - 2017-07-06 20:42:59 --> Model Class Initialized
INFO - 2017-07-06 20:42:59 --> Final output sent to browser
DEBUG - 2017-07-06 20:42:59 --> Total execution time: 0.0490
ERROR - 2017-07-06 20:43:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:43:01 --> Config Class Initialized
INFO - 2017-07-06 20:43:01 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:43:01 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:43:01 --> Utf8 Class Initialized
INFO - 2017-07-06 20:43:01 --> URI Class Initialized
INFO - 2017-07-06 20:43:01 --> Router Class Initialized
INFO - 2017-07-06 20:43:01 --> Output Class Initialized
INFO - 2017-07-06 20:43:01 --> Security Class Initialized
DEBUG - 2017-07-06 20:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:43:01 --> Input Class Initialized
INFO - 2017-07-06 20:43:01 --> Language Class Initialized
INFO - 2017-07-06 20:43:01 --> Loader Class Initialized
INFO - 2017-07-06 20:43:01 --> Controller Class Initialized
INFO - 2017-07-06 20:43:01 --> Database Driver Class Initialized
INFO - 2017-07-06 20:43:01 --> Model Class Initialized
INFO - 2017-07-06 20:43:01 --> Helper loaded: form_helper
INFO - 2017-07-06 20:43:01 --> Helper loaded: url_helper
INFO - 2017-07-06 20:43:01 --> Model Class Initialized
INFO - 2017-07-06 20:43:01 --> Final output sent to browser
DEBUG - 2017-07-06 20:43:01 --> Total execution time: 0.0590
ERROR - 2017-07-06 20:43:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:43:03 --> Config Class Initialized
INFO - 2017-07-06 20:43:03 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:43:03 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:43:03 --> Utf8 Class Initialized
INFO - 2017-07-06 20:43:03 --> URI Class Initialized
INFO - 2017-07-06 20:43:03 --> Router Class Initialized
INFO - 2017-07-06 20:43:03 --> Output Class Initialized
INFO - 2017-07-06 20:43:03 --> Security Class Initialized
DEBUG - 2017-07-06 20:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:43:03 --> Input Class Initialized
INFO - 2017-07-06 20:43:03 --> Language Class Initialized
INFO - 2017-07-06 20:43:03 --> Loader Class Initialized
INFO - 2017-07-06 20:43:03 --> Controller Class Initialized
INFO - 2017-07-06 20:43:03 --> Database Driver Class Initialized
INFO - 2017-07-06 20:43:03 --> Model Class Initialized
INFO - 2017-07-06 20:43:03 --> Helper loaded: form_helper
INFO - 2017-07-06 20:43:03 --> Helper loaded: url_helper
INFO - 2017-07-06 20:43:03 --> Model Class Initialized
INFO - 2017-07-06 20:43:03 --> Final output sent to browser
DEBUG - 2017-07-06 20:43:03 --> Total execution time: 0.0550
ERROR - 2017-07-06 20:53:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:53:57 --> Config Class Initialized
INFO - 2017-07-06 20:53:57 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:53:57 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:53:57 --> Utf8 Class Initialized
INFO - 2017-07-06 20:53:57 --> URI Class Initialized
INFO - 2017-07-06 20:53:57 --> Router Class Initialized
INFO - 2017-07-06 20:53:57 --> Output Class Initialized
INFO - 2017-07-06 20:53:57 --> Security Class Initialized
DEBUG - 2017-07-06 20:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:53:57 --> Input Class Initialized
INFO - 2017-07-06 20:53:57 --> Language Class Initialized
INFO - 2017-07-06 20:53:57 --> Loader Class Initialized
INFO - 2017-07-06 20:53:57 --> Controller Class Initialized
INFO - 2017-07-06 20:53:57 --> Database Driver Class Initialized
INFO - 2017-07-06 20:53:57 --> Model Class Initialized
INFO - 2017-07-06 20:53:57 --> Helper loaded: form_helper
INFO - 2017-07-06 20:53:57 --> Helper loaded: url_helper
INFO - 2017-07-06 20:53:57 --> Model Class Initialized
INFO - 2017-07-06 20:53:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-06 20:53:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-06 20:53:57 --> Final output sent to browser
DEBUG - 2017-07-06 20:53:57 --> Total execution time: 0.1360
ERROR - 2017-07-06 20:54:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:54:08 --> Config Class Initialized
INFO - 2017-07-06 20:54:08 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:54:08 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:54:08 --> Utf8 Class Initialized
INFO - 2017-07-06 20:54:08 --> URI Class Initialized
INFO - 2017-07-06 20:54:08 --> Router Class Initialized
INFO - 2017-07-06 20:54:08 --> Output Class Initialized
INFO - 2017-07-06 20:54:08 --> Security Class Initialized
DEBUG - 2017-07-06 20:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:54:08 --> Input Class Initialized
INFO - 2017-07-06 20:54:08 --> Language Class Initialized
INFO - 2017-07-06 20:54:08 --> Loader Class Initialized
INFO - 2017-07-06 20:54:08 --> Controller Class Initialized
INFO - 2017-07-06 20:54:08 --> Database Driver Class Initialized
INFO - 2017-07-06 20:54:08 --> Model Class Initialized
INFO - 2017-07-06 20:54:08 --> Helper loaded: form_helper
INFO - 2017-07-06 20:54:08 --> Helper loaded: url_helper
INFO - 2017-07-06 20:54:08 --> Model Class Initialized
INFO - 2017-07-06 20:54:08 --> Final output sent to browser
DEBUG - 2017-07-06 20:54:08 --> Total execution time: 0.0640
ERROR - 2017-07-06 20:54:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:54:09 --> Config Class Initialized
INFO - 2017-07-06 20:54:09 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:54:09 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:54:09 --> Utf8 Class Initialized
INFO - 2017-07-06 20:54:09 --> URI Class Initialized
INFO - 2017-07-06 20:54:09 --> Router Class Initialized
INFO - 2017-07-06 20:54:09 --> Output Class Initialized
INFO - 2017-07-06 20:54:09 --> Security Class Initialized
DEBUG - 2017-07-06 20:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:54:09 --> Input Class Initialized
INFO - 2017-07-06 20:54:09 --> Language Class Initialized
INFO - 2017-07-06 20:54:09 --> Loader Class Initialized
INFO - 2017-07-06 20:54:09 --> Controller Class Initialized
INFO - 2017-07-06 20:54:09 --> Database Driver Class Initialized
INFO - 2017-07-06 20:54:09 --> Model Class Initialized
INFO - 2017-07-06 20:54:09 --> Helper loaded: form_helper
INFO - 2017-07-06 20:54:09 --> Helper loaded: url_helper
INFO - 2017-07-06 20:54:09 --> Model Class Initialized
INFO - 2017-07-06 20:54:09 --> Final output sent to browser
DEBUG - 2017-07-06 20:54:09 --> Total execution time: 0.0580
ERROR - 2017-07-06 20:54:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:54:11 --> Config Class Initialized
INFO - 2017-07-06 20:54:11 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:54:11 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:54:11 --> Utf8 Class Initialized
INFO - 2017-07-06 20:54:11 --> URI Class Initialized
INFO - 2017-07-06 20:54:11 --> Router Class Initialized
INFO - 2017-07-06 20:54:11 --> Output Class Initialized
INFO - 2017-07-06 20:54:11 --> Security Class Initialized
DEBUG - 2017-07-06 20:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:54:11 --> Input Class Initialized
INFO - 2017-07-06 20:54:11 --> Language Class Initialized
INFO - 2017-07-06 20:54:11 --> Loader Class Initialized
INFO - 2017-07-06 20:54:11 --> Controller Class Initialized
INFO - 2017-07-06 20:54:11 --> Database Driver Class Initialized
INFO - 2017-07-06 20:54:11 --> Model Class Initialized
INFO - 2017-07-06 20:54:11 --> Helper loaded: form_helper
INFO - 2017-07-06 20:54:11 --> Helper loaded: url_helper
INFO - 2017-07-06 20:54:11 --> Model Class Initialized
INFO - 2017-07-06 20:54:11 --> Final output sent to browser
DEBUG - 2017-07-06 20:54:11 --> Total execution time: 0.0640
ERROR - 2017-07-06 20:54:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-06 20:54:13 --> Config Class Initialized
INFO - 2017-07-06 20:54:13 --> Hooks Class Initialized
DEBUG - 2017-07-06 20:54:13 --> UTF-8 Support Enabled
INFO - 2017-07-06 20:54:13 --> Utf8 Class Initialized
INFO - 2017-07-06 20:54:13 --> URI Class Initialized
INFO - 2017-07-06 20:54:13 --> Router Class Initialized
INFO - 2017-07-06 20:54:13 --> Output Class Initialized
INFO - 2017-07-06 20:54:13 --> Security Class Initialized
DEBUG - 2017-07-06 20:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-06 20:54:13 --> Input Class Initialized
INFO - 2017-07-06 20:54:13 --> Language Class Initialized
INFO - 2017-07-06 20:54:13 --> Loader Class Initialized
INFO - 2017-07-06 20:54:13 --> Controller Class Initialized
INFO - 2017-07-06 20:54:13 --> Database Driver Class Initialized
INFO - 2017-07-06 20:54:13 --> Model Class Initialized
INFO - 2017-07-06 20:54:13 --> Helper loaded: form_helper
INFO - 2017-07-06 20:54:13 --> Helper loaded: url_helper
INFO - 2017-07-06 20:54:13 --> Model Class Initialized
INFO - 2017-07-06 20:54:13 --> Final output sent to browser
DEBUG - 2017-07-06 20:54:13 --> Total execution time: 0.0630
