<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-17 08:01:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:01:53 --> Config Class Initialized
INFO - 2017-08-17 08:01:53 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:01:53 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:01:53 --> Utf8 Class Initialized
INFO - 2017-08-17 08:01:53 --> URI Class Initialized
DEBUG - 2017-08-17 08:01:53 --> No URI present. Default controller set.
INFO - 2017-08-17 08:01:53 --> Router Class Initialized
INFO - 2017-08-17 08:01:53 --> Output Class Initialized
INFO - 2017-08-17 08:01:53 --> Security Class Initialized
DEBUG - 2017-08-17 08:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:01:53 --> Input Class Initialized
INFO - 2017-08-17 08:01:53 --> Language Class Initialized
INFO - 2017-08-17 08:01:53 --> Loader Class Initialized
INFO - 2017-08-17 08:01:53 --> Controller Class Initialized
INFO - 2017-08-17 08:01:53 --> Database Driver Class Initialized
INFO - 2017-08-17 08:01:53 --> Model Class Initialized
INFO - 2017-08-17 08:01:53 --> Helper loaded: form_helper
INFO - 2017-08-17 08:01:53 --> Helper loaded: url_helper
INFO - 2017-08-17 08:01:53 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-08-17 08:01:53 --> Final output sent to browser
DEBUG - 2017-08-17 08:01:53 --> Total execution time: 0.0600
ERROR - 2017-08-17 08:01:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:01:55 --> Config Class Initialized
INFO - 2017-08-17 08:01:55 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:01:55 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:01:55 --> Utf8 Class Initialized
INFO - 2017-08-17 08:01:55 --> URI Class Initialized
INFO - 2017-08-17 08:01:55 --> Router Class Initialized
INFO - 2017-08-17 08:01:55 --> Output Class Initialized
INFO - 2017-08-17 08:01:55 --> Security Class Initialized
DEBUG - 2017-08-17 08:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:01:55 --> Input Class Initialized
INFO - 2017-08-17 08:01:55 --> Language Class Initialized
INFO - 2017-08-17 08:01:55 --> Loader Class Initialized
INFO - 2017-08-17 08:01:55 --> Controller Class Initialized
INFO - 2017-08-17 08:01:55 --> Database Driver Class Initialized
INFO - 2017-08-17 08:01:55 --> Model Class Initialized
INFO - 2017-08-17 08:01:55 --> Helper loaded: form_helper
INFO - 2017-08-17 08:01:55 --> Helper loaded: url_helper
INFO - 2017-08-17 08:01:55 --> Model Class Initialized
ERROR - 2017-08-17 08:01:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:01:55 --> Config Class Initialized
INFO - 2017-08-17 08:01:55 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:01:55 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:01:55 --> Utf8 Class Initialized
INFO - 2017-08-17 08:01:55 --> URI Class Initialized
INFO - 2017-08-17 08:01:55 --> Router Class Initialized
INFO - 2017-08-17 08:01:55 --> Output Class Initialized
INFO - 2017-08-17 08:01:55 --> Security Class Initialized
DEBUG - 2017-08-17 08:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:01:55 --> Input Class Initialized
INFO - 2017-08-17 08:01:55 --> Language Class Initialized
INFO - 2017-08-17 08:01:55 --> Loader Class Initialized
INFO - 2017-08-17 08:01:55 --> Controller Class Initialized
INFO - 2017-08-17 08:01:55 --> Database Driver Class Initialized
INFO - 2017-08-17 08:01:55 --> Model Class Initialized
INFO - 2017-08-17 08:01:55 --> Helper loaded: form_helper
INFO - 2017-08-17 08:01:55 --> Helper loaded: url_helper
INFO - 2017-08-17 08:01:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-17 08:01:55 --> Model Class Initialized
INFO - 2017-08-17 08:01:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-08-17 08:01:55 --> Final output sent to browser
DEBUG - 2017-08-17 08:01:55 --> Total execution time: 0.0830
ERROR - 2017-08-17 08:01:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:01:58 --> Config Class Initialized
INFO - 2017-08-17 08:01:58 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:01:58 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:01:58 --> Utf8 Class Initialized
INFO - 2017-08-17 08:01:58 --> URI Class Initialized
INFO - 2017-08-17 08:01:58 --> Router Class Initialized
INFO - 2017-08-17 08:01:58 --> Output Class Initialized
INFO - 2017-08-17 08:01:58 --> Security Class Initialized
DEBUG - 2017-08-17 08:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:01:58 --> Input Class Initialized
INFO - 2017-08-17 08:01:58 --> Language Class Initialized
INFO - 2017-08-17 08:01:58 --> Loader Class Initialized
INFO - 2017-08-17 08:01:58 --> Controller Class Initialized
INFO - 2017-08-17 08:01:58 --> Database Driver Class Initialized
INFO - 2017-08-17 08:01:58 --> Model Class Initialized
INFO - 2017-08-17 08:01:58 --> Helper loaded: form_helper
INFO - 2017-08-17 08:01:58 --> Helper loaded: url_helper
INFO - 2017-08-17 08:01:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-17 08:01:58 --> Model Class Initialized
INFO - 2017-08-17 08:01:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-08-17 08:01:58 --> Final output sent to browser
DEBUG - 2017-08-17 08:01:58 --> Total execution time: 0.0820
ERROR - 2017-08-17 08:02:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:02:06 --> Config Class Initialized
INFO - 2017-08-17 08:02:06 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:02:06 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:02:06 --> Utf8 Class Initialized
INFO - 2017-08-17 08:02:06 --> URI Class Initialized
INFO - 2017-08-17 08:02:06 --> Router Class Initialized
INFO - 2017-08-17 08:02:06 --> Output Class Initialized
INFO - 2017-08-17 08:02:06 --> Security Class Initialized
DEBUG - 2017-08-17 08:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:02:06 --> Input Class Initialized
INFO - 2017-08-17 08:02:06 --> Language Class Initialized
INFO - 2017-08-17 08:02:06 --> Loader Class Initialized
INFO - 2017-08-17 08:02:06 --> Controller Class Initialized
INFO - 2017-08-17 08:02:06 --> Database Driver Class Initialized
INFO - 2017-08-17 08:02:06 --> Model Class Initialized
INFO - 2017-08-17 08:02:06 --> Helper loaded: form_helper
INFO - 2017-08-17 08:02:06 --> Helper loaded: url_helper
INFO - 2017-08-17 08:02:06 --> Upload Class Initialized
INFO - 2017-08-17 08:02:06 --> Final output sent to browser
DEBUG - 2017-08-17 08:02:06 --> Total execution time: 0.0820
ERROR - 2017-08-17 08:02:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:02:18 --> Config Class Initialized
INFO - 2017-08-17 08:02:18 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:02:18 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:02:18 --> Utf8 Class Initialized
INFO - 2017-08-17 08:02:18 --> URI Class Initialized
INFO - 2017-08-17 08:02:18 --> Router Class Initialized
INFO - 2017-08-17 08:02:18 --> Output Class Initialized
INFO - 2017-08-17 08:02:18 --> Security Class Initialized
DEBUG - 2017-08-17 08:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:02:18 --> Input Class Initialized
INFO - 2017-08-17 08:02:18 --> Language Class Initialized
INFO - 2017-08-17 08:02:18 --> Loader Class Initialized
INFO - 2017-08-17 08:02:18 --> Controller Class Initialized
INFO - 2017-08-17 08:02:18 --> Database Driver Class Initialized
INFO - 2017-08-17 08:02:18 --> Model Class Initialized
INFO - 2017-08-17 08:02:18 --> Helper loaded: form_helper
INFO - 2017-08-17 08:02:18 --> Helper loaded: url_helper
INFO - 2017-08-17 08:02:18 --> Upload Class Initialized
INFO - 2017-08-17 08:02:18 --> Final output sent to browser
DEBUG - 2017-08-17 08:02:18 --> Total execution time: 0.0810
ERROR - 2017-08-17 08:02:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:02:31 --> Config Class Initialized
INFO - 2017-08-17 08:02:31 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:02:31 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:02:31 --> Utf8 Class Initialized
INFO - 2017-08-17 08:02:31 --> URI Class Initialized
INFO - 2017-08-17 08:02:31 --> Router Class Initialized
INFO - 2017-08-17 08:02:31 --> Output Class Initialized
INFO - 2017-08-17 08:02:31 --> Security Class Initialized
DEBUG - 2017-08-17 08:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:02:31 --> Input Class Initialized
INFO - 2017-08-17 08:02:31 --> Language Class Initialized
INFO - 2017-08-17 08:02:31 --> Loader Class Initialized
INFO - 2017-08-17 08:02:31 --> Controller Class Initialized
INFO - 2017-08-17 08:02:31 --> Database Driver Class Initialized
INFO - 2017-08-17 08:02:31 --> Model Class Initialized
INFO - 2017-08-17 08:02:31 --> Helper loaded: form_helper
INFO - 2017-08-17 08:02:31 --> Helper loaded: url_helper
INFO - 2017-08-17 08:02:31 --> Upload Class Initialized
INFO - 2017-08-17 08:02:31 --> Final output sent to browser
DEBUG - 2017-08-17 08:02:31 --> Total execution time: 0.0420
ERROR - 2017-08-17 08:02:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:02:31 --> Config Class Initialized
INFO - 2017-08-17 08:02:31 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:02:31 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:02:31 --> Utf8 Class Initialized
INFO - 2017-08-17 08:02:31 --> URI Class Initialized
INFO - 2017-08-17 08:02:31 --> Router Class Initialized
INFO - 2017-08-17 08:02:31 --> Output Class Initialized
INFO - 2017-08-17 08:02:31 --> Security Class Initialized
DEBUG - 2017-08-17 08:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:02:31 --> Input Class Initialized
INFO - 2017-08-17 08:02:31 --> Language Class Initialized
INFO - 2017-08-17 08:02:31 --> Loader Class Initialized
INFO - 2017-08-17 08:02:31 --> Controller Class Initialized
INFO - 2017-08-17 08:02:31 --> Database Driver Class Initialized
INFO - 2017-08-17 08:02:31 --> Model Class Initialized
INFO - 2017-08-17 08:02:31 --> Helper loaded: form_helper
INFO - 2017-08-17 08:02:31 --> Helper loaded: url_helper
INFO - 2017-08-17 08:02:31 --> Upload Class Initialized
INFO - 2017-08-17 08:02:31 --> Final output sent to browser
DEBUG - 2017-08-17 08:02:31 --> Total execution time: 0.1690
ERROR - 2017-08-17 08:02:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:02:31 --> Config Class Initialized
INFO - 2017-08-17 08:02:31 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:02:31 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:02:31 --> Utf8 Class Initialized
INFO - 2017-08-17 08:02:31 --> URI Class Initialized
INFO - 2017-08-17 08:02:31 --> Router Class Initialized
INFO - 2017-08-17 08:02:31 --> Output Class Initialized
INFO - 2017-08-17 08:02:31 --> Security Class Initialized
DEBUG - 2017-08-17 08:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:02:31 --> Input Class Initialized
INFO - 2017-08-17 08:02:31 --> Language Class Initialized
INFO - 2017-08-17 08:02:31 --> Loader Class Initialized
INFO - 2017-08-17 08:02:31 --> Controller Class Initialized
INFO - 2017-08-17 08:02:31 --> Database Driver Class Initialized
INFO - 2017-08-17 08:02:31 --> Model Class Initialized
INFO - 2017-08-17 08:02:32 --> Helper loaded: form_helper
INFO - 2017-08-17 08:02:32 --> Helper loaded: url_helper
INFO - 2017-08-17 08:02:32 --> Upload Class Initialized
INFO - 2017-08-17 08:02:32 --> Final output sent to browser
DEBUG - 2017-08-17 08:02:32 --> Total execution time: 0.0410
ERROR - 2017-08-17 08:02:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:02:32 --> Config Class Initialized
INFO - 2017-08-17 08:02:32 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:02:32 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:02:32 --> Utf8 Class Initialized
INFO - 2017-08-17 08:02:32 --> URI Class Initialized
INFO - 2017-08-17 08:02:32 --> Router Class Initialized
INFO - 2017-08-17 08:02:32 --> Output Class Initialized
INFO - 2017-08-17 08:02:32 --> Security Class Initialized
DEBUG - 2017-08-17 08:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:02:32 --> Input Class Initialized
INFO - 2017-08-17 08:02:32 --> Language Class Initialized
INFO - 2017-08-17 08:02:32 --> Loader Class Initialized
INFO - 2017-08-17 08:02:32 --> Controller Class Initialized
INFO - 2017-08-17 08:02:32 --> Database Driver Class Initialized
INFO - 2017-08-17 08:02:32 --> Model Class Initialized
INFO - 2017-08-17 08:02:32 --> Helper loaded: form_helper
INFO - 2017-08-17 08:02:32 --> Helper loaded: url_helper
INFO - 2017-08-17 08:02:32 --> Upload Class Initialized
INFO - 2017-08-17 08:02:32 --> Final output sent to browser
DEBUG - 2017-08-17 08:02:32 --> Total execution time: 0.0430
ERROR - 2017-08-17 08:02:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:02:32 --> Config Class Initialized
INFO - 2017-08-17 08:02:32 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:02:32 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:02:32 --> Utf8 Class Initialized
INFO - 2017-08-17 08:02:32 --> URI Class Initialized
INFO - 2017-08-17 08:02:32 --> Router Class Initialized
INFO - 2017-08-17 08:02:32 --> Output Class Initialized
INFO - 2017-08-17 08:02:32 --> Security Class Initialized
DEBUG - 2017-08-17 08:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:02:32 --> Input Class Initialized
INFO - 2017-08-17 08:02:32 --> Language Class Initialized
INFO - 2017-08-17 08:02:32 --> Loader Class Initialized
INFO - 2017-08-17 08:02:32 --> Controller Class Initialized
INFO - 2017-08-17 08:02:32 --> Database Driver Class Initialized
INFO - 2017-08-17 08:02:32 --> Model Class Initialized
INFO - 2017-08-17 08:02:32 --> Helper loaded: form_helper
INFO - 2017-08-17 08:02:32 --> Helper loaded: url_helper
INFO - 2017-08-17 08:02:32 --> Upload Class Initialized
INFO - 2017-08-17 08:02:32 --> Final output sent to browser
DEBUG - 2017-08-17 08:02:32 --> Total execution time: 0.0420
ERROR - 2017-08-17 08:02:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:02:32 --> Config Class Initialized
INFO - 2017-08-17 08:02:32 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:02:32 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:02:32 --> Utf8 Class Initialized
INFO - 2017-08-17 08:02:32 --> URI Class Initialized
INFO - 2017-08-17 08:02:32 --> Router Class Initialized
INFO - 2017-08-17 08:02:32 --> Output Class Initialized
INFO - 2017-08-17 08:02:32 --> Security Class Initialized
DEBUG - 2017-08-17 08:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:02:32 --> Input Class Initialized
INFO - 2017-08-17 08:02:32 --> Language Class Initialized
INFO - 2017-08-17 08:02:32 --> Loader Class Initialized
INFO - 2017-08-17 08:02:32 --> Controller Class Initialized
INFO - 2017-08-17 08:02:32 --> Database Driver Class Initialized
INFO - 2017-08-17 08:02:32 --> Model Class Initialized
INFO - 2017-08-17 08:02:32 --> Helper loaded: form_helper
INFO - 2017-08-17 08:02:32 --> Helper loaded: url_helper
INFO - 2017-08-17 08:02:32 --> Upload Class Initialized
INFO - 2017-08-17 08:02:32 --> Final output sent to browser
DEBUG - 2017-08-17 08:02:32 --> Total execution time: 0.0420
ERROR - 2017-08-17 08:02:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:02:37 --> Config Class Initialized
INFO - 2017-08-17 08:02:37 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:02:37 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:02:37 --> Utf8 Class Initialized
INFO - 2017-08-17 08:02:37 --> URI Class Initialized
INFO - 2017-08-17 08:02:37 --> Router Class Initialized
INFO - 2017-08-17 08:02:37 --> Output Class Initialized
INFO - 2017-08-17 08:02:37 --> Security Class Initialized
DEBUG - 2017-08-17 08:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:02:37 --> Input Class Initialized
INFO - 2017-08-17 08:02:37 --> Language Class Initialized
INFO - 2017-08-17 08:02:37 --> Loader Class Initialized
INFO - 2017-08-17 08:02:37 --> Controller Class Initialized
INFO - 2017-08-17 08:02:37 --> Database Driver Class Initialized
INFO - 2017-08-17 08:02:37 --> Model Class Initialized
INFO - 2017-08-17 08:02:37 --> Helper loaded: form_helper
INFO - 2017-08-17 08:02:37 --> Helper loaded: url_helper
INFO - 2017-08-17 08:02:37 --> Upload Class Initialized
INFO - 2017-08-17 08:02:37 --> Final output sent to browser
DEBUG - 2017-08-17 08:02:37 --> Total execution time: 0.0460
ERROR - 2017-08-17 08:02:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:02:47 --> Config Class Initialized
INFO - 2017-08-17 08:02:47 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:02:47 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:02:47 --> Utf8 Class Initialized
INFO - 2017-08-17 08:02:47 --> URI Class Initialized
INFO - 2017-08-17 08:02:47 --> Router Class Initialized
INFO - 2017-08-17 08:02:47 --> Output Class Initialized
INFO - 2017-08-17 08:02:47 --> Security Class Initialized
DEBUG - 2017-08-17 08:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:02:47 --> Input Class Initialized
INFO - 2017-08-17 08:02:47 --> Language Class Initialized
INFO - 2017-08-17 08:02:47 --> Loader Class Initialized
INFO - 2017-08-17 08:02:47 --> Controller Class Initialized
INFO - 2017-08-17 08:02:47 --> Database Driver Class Initialized
INFO - 2017-08-17 08:02:47 --> Model Class Initialized
INFO - 2017-08-17 08:02:47 --> Helper loaded: form_helper
INFO - 2017-08-17 08:02:47 --> Helper loaded: url_helper
INFO - 2017-08-17 08:02:47 --> Upload Class Initialized
INFO - 2017-08-17 08:02:47 --> Final output sent to browser
DEBUG - 2017-08-17 08:02:47 --> Total execution time: 0.0430
ERROR - 2017-08-17 08:02:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:02:47 --> Config Class Initialized
INFO - 2017-08-17 08:02:47 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:02:47 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:02:47 --> Utf8 Class Initialized
INFO - 2017-08-17 08:02:47 --> URI Class Initialized
INFO - 2017-08-17 08:02:47 --> Router Class Initialized
INFO - 2017-08-17 08:02:47 --> Output Class Initialized
INFO - 2017-08-17 08:02:47 --> Security Class Initialized
DEBUG - 2017-08-17 08:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:02:47 --> Input Class Initialized
INFO - 2017-08-17 08:02:47 --> Language Class Initialized
INFO - 2017-08-17 08:02:47 --> Loader Class Initialized
INFO - 2017-08-17 08:02:47 --> Controller Class Initialized
INFO - 2017-08-17 08:02:47 --> Database Driver Class Initialized
INFO - 2017-08-17 08:02:47 --> Model Class Initialized
INFO - 2017-08-17 08:02:47 --> Helper loaded: form_helper
INFO - 2017-08-17 08:02:47 --> Helper loaded: url_helper
INFO - 2017-08-17 08:02:47 --> Upload Class Initialized
INFO - 2017-08-17 08:02:47 --> Final output sent to browser
DEBUG - 2017-08-17 08:02:47 --> Total execution time: 0.0430
ERROR - 2017-08-17 08:02:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:02:47 --> Config Class Initialized
INFO - 2017-08-17 08:02:47 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:02:47 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:02:47 --> Utf8 Class Initialized
INFO - 2017-08-17 08:02:47 --> URI Class Initialized
INFO - 2017-08-17 08:02:47 --> Router Class Initialized
INFO - 2017-08-17 08:02:47 --> Output Class Initialized
INFO - 2017-08-17 08:02:47 --> Security Class Initialized
DEBUG - 2017-08-17 08:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:02:47 --> Input Class Initialized
INFO - 2017-08-17 08:02:47 --> Language Class Initialized
INFO - 2017-08-17 08:02:47 --> Loader Class Initialized
INFO - 2017-08-17 08:02:47 --> Controller Class Initialized
INFO - 2017-08-17 08:02:47 --> Database Driver Class Initialized
INFO - 2017-08-17 08:02:47 --> Model Class Initialized
INFO - 2017-08-17 08:02:47 --> Helper loaded: form_helper
INFO - 2017-08-17 08:02:47 --> Helper loaded: url_helper
INFO - 2017-08-17 08:02:47 --> Upload Class Initialized
INFO - 2017-08-17 08:02:47 --> Final output sent to browser
DEBUG - 2017-08-17 08:02:47 --> Total execution time: 0.0460
ERROR - 2017-08-17 08:02:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:02:47 --> Config Class Initialized
INFO - 2017-08-17 08:02:47 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:02:47 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:02:47 --> Utf8 Class Initialized
INFO - 2017-08-17 08:02:47 --> URI Class Initialized
INFO - 2017-08-17 08:02:47 --> Router Class Initialized
INFO - 2017-08-17 08:02:47 --> Output Class Initialized
INFO - 2017-08-17 08:02:47 --> Security Class Initialized
DEBUG - 2017-08-17 08:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:02:47 --> Input Class Initialized
INFO - 2017-08-17 08:02:47 --> Language Class Initialized
INFO - 2017-08-17 08:02:47 --> Loader Class Initialized
INFO - 2017-08-17 08:02:47 --> Controller Class Initialized
INFO - 2017-08-17 08:02:47 --> Database Driver Class Initialized
INFO - 2017-08-17 08:02:47 --> Model Class Initialized
INFO - 2017-08-17 08:02:47 --> Helper loaded: form_helper
INFO - 2017-08-17 08:02:47 --> Helper loaded: url_helper
INFO - 2017-08-17 08:02:47 --> Upload Class Initialized
INFO - 2017-08-17 08:02:47 --> Final output sent to browser
DEBUG - 2017-08-17 08:02:47 --> Total execution time: 0.0690
ERROR - 2017-08-17 08:02:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:02:48 --> Config Class Initialized
INFO - 2017-08-17 08:02:48 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:02:48 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:02:48 --> Utf8 Class Initialized
INFO - 2017-08-17 08:02:48 --> URI Class Initialized
INFO - 2017-08-17 08:02:48 --> Router Class Initialized
INFO - 2017-08-17 08:02:48 --> Output Class Initialized
INFO - 2017-08-17 08:02:48 --> Security Class Initialized
DEBUG - 2017-08-17 08:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:02:48 --> Input Class Initialized
INFO - 2017-08-17 08:02:48 --> Language Class Initialized
INFO - 2017-08-17 08:02:48 --> Loader Class Initialized
INFO - 2017-08-17 08:02:48 --> Controller Class Initialized
INFO - 2017-08-17 08:02:48 --> Database Driver Class Initialized
INFO - 2017-08-17 08:02:48 --> Model Class Initialized
INFO - 2017-08-17 08:02:48 --> Helper loaded: form_helper
INFO - 2017-08-17 08:02:48 --> Helper loaded: url_helper
INFO - 2017-08-17 08:02:48 --> Upload Class Initialized
INFO - 2017-08-17 08:02:48 --> Final output sent to browser
DEBUG - 2017-08-17 08:02:48 --> Total execution time: 0.0490
ERROR - 2017-08-17 08:02:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:02:48 --> Config Class Initialized
INFO - 2017-08-17 08:02:48 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:02:48 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:02:48 --> Utf8 Class Initialized
INFO - 2017-08-17 08:02:48 --> URI Class Initialized
INFO - 2017-08-17 08:02:48 --> Router Class Initialized
INFO - 2017-08-17 08:02:48 --> Output Class Initialized
INFO - 2017-08-17 08:02:48 --> Security Class Initialized
DEBUG - 2017-08-17 08:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:02:48 --> Input Class Initialized
INFO - 2017-08-17 08:02:48 --> Language Class Initialized
INFO - 2017-08-17 08:02:48 --> Loader Class Initialized
INFO - 2017-08-17 08:02:48 --> Controller Class Initialized
INFO - 2017-08-17 08:02:48 --> Database Driver Class Initialized
INFO - 2017-08-17 08:02:48 --> Model Class Initialized
INFO - 2017-08-17 08:02:48 --> Helper loaded: form_helper
INFO - 2017-08-17 08:02:48 --> Helper loaded: url_helper
INFO - 2017-08-17 08:02:48 --> Upload Class Initialized
INFO - 2017-08-17 08:02:48 --> Final output sent to browser
DEBUG - 2017-08-17 08:02:48 --> Total execution time: 0.0480
ERROR - 2017-08-17 08:02:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:02:48 --> Config Class Initialized
INFO - 2017-08-17 08:02:48 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:02:48 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:02:48 --> Utf8 Class Initialized
INFO - 2017-08-17 08:02:48 --> URI Class Initialized
INFO - 2017-08-17 08:02:48 --> Router Class Initialized
INFO - 2017-08-17 08:02:48 --> Output Class Initialized
INFO - 2017-08-17 08:02:48 --> Security Class Initialized
DEBUG - 2017-08-17 08:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:02:48 --> Input Class Initialized
INFO - 2017-08-17 08:02:48 --> Language Class Initialized
INFO - 2017-08-17 08:02:48 --> Loader Class Initialized
INFO - 2017-08-17 08:02:48 --> Controller Class Initialized
INFO - 2017-08-17 08:02:48 --> Database Driver Class Initialized
INFO - 2017-08-17 08:02:48 --> Model Class Initialized
INFO - 2017-08-17 08:02:48 --> Helper loaded: form_helper
INFO - 2017-08-17 08:02:48 --> Helper loaded: url_helper
INFO - 2017-08-17 08:02:48 --> Upload Class Initialized
INFO - 2017-08-17 08:02:48 --> Final output sent to browser
DEBUG - 2017-08-17 08:02:48 --> Total execution time: 0.0680
ERROR - 2017-08-17 08:02:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:02:53 --> Config Class Initialized
INFO - 2017-08-17 08:02:53 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:02:53 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:02:53 --> Utf8 Class Initialized
INFO - 2017-08-17 08:02:53 --> URI Class Initialized
INFO - 2017-08-17 08:02:53 --> Router Class Initialized
INFO - 2017-08-17 08:02:53 --> Output Class Initialized
INFO - 2017-08-17 08:02:53 --> Security Class Initialized
DEBUG - 2017-08-17 08:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:02:53 --> Input Class Initialized
INFO - 2017-08-17 08:02:53 --> Language Class Initialized
INFO - 2017-08-17 08:02:53 --> Loader Class Initialized
INFO - 2017-08-17 08:02:53 --> Controller Class Initialized
INFO - 2017-08-17 08:02:53 --> Database Driver Class Initialized
INFO - 2017-08-17 08:02:53 --> Model Class Initialized
INFO - 2017-08-17 08:02:53 --> Helper loaded: form_helper
INFO - 2017-08-17 08:02:53 --> Helper loaded: url_helper
INFO - 2017-08-17 08:02:53 --> Upload Class Initialized
INFO - 2017-08-17 08:02:53 --> Final output sent to browser
DEBUG - 2017-08-17 08:02:53 --> Total execution time: 0.0470
ERROR - 2017-08-17 08:03:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:03:03 --> Config Class Initialized
INFO - 2017-08-17 08:03:03 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:03:03 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:03:03 --> Utf8 Class Initialized
INFO - 2017-08-17 08:03:03 --> URI Class Initialized
INFO - 2017-08-17 08:03:03 --> Router Class Initialized
INFO - 2017-08-17 08:03:03 --> Output Class Initialized
INFO - 2017-08-17 08:03:03 --> Security Class Initialized
DEBUG - 2017-08-17 08:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:03:03 --> Input Class Initialized
INFO - 2017-08-17 08:03:03 --> Language Class Initialized
INFO - 2017-08-17 08:03:03 --> Loader Class Initialized
INFO - 2017-08-17 08:03:03 --> Controller Class Initialized
INFO - 2017-08-17 08:03:03 --> Database Driver Class Initialized
INFO - 2017-08-17 08:03:03 --> Model Class Initialized
INFO - 2017-08-17 08:03:03 --> Helper loaded: form_helper
INFO - 2017-08-17 08:03:03 --> Helper loaded: url_helper
INFO - 2017-08-17 08:03:03 --> Upload Class Initialized
INFO - 2017-08-17 08:03:03 --> Final output sent to browser
DEBUG - 2017-08-17 08:03:03 --> Total execution time: 0.0470
ERROR - 2017-08-17 08:03:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:03:03 --> Config Class Initialized
INFO - 2017-08-17 08:03:03 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:03:03 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:03:03 --> Utf8 Class Initialized
INFO - 2017-08-17 08:03:03 --> URI Class Initialized
INFO - 2017-08-17 08:03:03 --> Router Class Initialized
INFO - 2017-08-17 08:03:03 --> Output Class Initialized
INFO - 2017-08-17 08:03:03 --> Security Class Initialized
DEBUG - 2017-08-17 08:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:03:03 --> Input Class Initialized
INFO - 2017-08-17 08:03:03 --> Language Class Initialized
INFO - 2017-08-17 08:03:03 --> Loader Class Initialized
INFO - 2017-08-17 08:03:03 --> Controller Class Initialized
INFO - 2017-08-17 08:03:03 --> Database Driver Class Initialized
INFO - 2017-08-17 08:03:03 --> Model Class Initialized
INFO - 2017-08-17 08:03:03 --> Helper loaded: form_helper
INFO - 2017-08-17 08:03:03 --> Helper loaded: url_helper
INFO - 2017-08-17 08:03:03 --> Upload Class Initialized
INFO - 2017-08-17 08:03:03 --> Final output sent to browser
DEBUG - 2017-08-17 08:03:03 --> Total execution time: 0.0660
ERROR - 2017-08-17 08:03:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:03:06 --> Config Class Initialized
INFO - 2017-08-17 08:03:06 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:03:06 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:03:06 --> Utf8 Class Initialized
INFO - 2017-08-17 08:03:06 --> URI Class Initialized
INFO - 2017-08-17 08:03:06 --> Router Class Initialized
INFO - 2017-08-17 08:03:06 --> Output Class Initialized
INFO - 2017-08-17 08:03:06 --> Security Class Initialized
DEBUG - 2017-08-17 08:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:03:06 --> Input Class Initialized
INFO - 2017-08-17 08:03:06 --> Language Class Initialized
INFO - 2017-08-17 08:03:06 --> Loader Class Initialized
INFO - 2017-08-17 08:03:06 --> Controller Class Initialized
INFO - 2017-08-17 08:03:06 --> Database Driver Class Initialized
INFO - 2017-08-17 08:03:06 --> Model Class Initialized
INFO - 2017-08-17 08:03:06 --> Helper loaded: form_helper
INFO - 2017-08-17 08:03:06 --> Helper loaded: url_helper
INFO - 2017-08-17 08:03:06 --> Model Class Initialized
INFO - 2017-08-17 08:03:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-17 08:03:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-08-17 08:03:07 --> Final output sent to browser
DEBUG - 2017-08-17 08:03:07 --> Total execution time: 1.3411
ERROR - 2017-08-17 08:19:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-17 08:19:17 --> Config Class Initialized
INFO - 2017-08-17 08:19:17 --> Hooks Class Initialized
DEBUG - 2017-08-17 08:19:17 --> UTF-8 Support Enabled
INFO - 2017-08-17 08:19:17 --> Utf8 Class Initialized
INFO - 2017-08-17 08:19:17 --> URI Class Initialized
DEBUG - 2017-08-17 08:19:17 --> No URI present. Default controller set.
INFO - 2017-08-17 08:19:17 --> Router Class Initialized
INFO - 2017-08-17 08:19:17 --> Output Class Initialized
INFO - 2017-08-17 08:19:17 --> Security Class Initialized
DEBUG - 2017-08-17 08:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-17 08:19:17 --> Input Class Initialized
INFO - 2017-08-17 08:19:17 --> Language Class Initialized
INFO - 2017-08-17 08:19:17 --> Loader Class Initialized
INFO - 2017-08-17 08:19:17 --> Controller Class Initialized
INFO - 2017-08-17 08:19:17 --> Database Driver Class Initialized
INFO - 2017-08-17 08:19:17 --> Model Class Initialized
INFO - 2017-08-17 08:19:17 --> Helper loaded: form_helper
INFO - 2017-08-17 08:19:17 --> Helper loaded: url_helper
INFO - 2017-08-17 08:19:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-08-17 08:19:17 --> Final output sent to browser
DEBUG - 2017-08-17 08:19:17 --> Total execution time: 0.0600
