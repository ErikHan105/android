<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-16 04:57:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 04:57:53 --> Config Class Initialized
INFO - 2018-07-16 04:57:53 --> Hooks Class Initialized
DEBUG - 2018-07-16 04:57:53 --> UTF-8 Support Enabled
INFO - 2018-07-16 04:57:53 --> Utf8 Class Initialized
INFO - 2018-07-16 04:57:53 --> URI Class Initialized
INFO - 2018-07-16 04:57:53 --> Router Class Initialized
INFO - 2018-07-16 04:57:53 --> Output Class Initialized
INFO - 2018-07-16 04:57:53 --> Security Class Initialized
DEBUG - 2018-07-16 04:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 04:57:53 --> Input Class Initialized
INFO - 2018-07-16 04:57:53 --> Language Class Initialized
INFO - 2018-07-16 04:57:53 --> Loader Class Initialized
INFO - 2018-07-16 04:57:53 --> Controller Class Initialized
INFO - 2018-07-16 04:57:53 --> Database Driver Class Initialized
INFO - 2018-07-16 04:57:53 --> Model Class Initialized
INFO - 2018-07-16 04:57:53 --> Helper loaded: url_helper
DEBUG - 2018-07-16 04:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 04:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 04:57:53 --> Model Class Initialized
ERROR - 2018-07-16 04:57:53 --> Severity: Notice --> Undefined index: Davidhood C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-07-16 04:57:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 04:57:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 04:57:53 --> Final output sent to browser
DEBUG - 2018-07-16 04:57:53 --> Total execution time: 0.0455
ERROR - 2018-07-16 04:57:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 04:57:54 --> Config Class Initialized
INFO - 2018-07-16 04:57:54 --> Hooks Class Initialized
DEBUG - 2018-07-16 04:57:54 --> UTF-8 Support Enabled
INFO - 2018-07-16 04:57:54 --> Utf8 Class Initialized
INFO - 2018-07-16 04:57:54 --> URI Class Initialized
DEBUG - 2018-07-16 04:57:54 --> No URI present. Default controller set.
INFO - 2018-07-16 04:57:54 --> Router Class Initialized
INFO - 2018-07-16 04:57:54 --> Output Class Initialized
INFO - 2018-07-16 04:57:54 --> Security Class Initialized
DEBUG - 2018-07-16 04:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 04:57:54 --> Input Class Initialized
INFO - 2018-07-16 04:57:54 --> Language Class Initialized
INFO - 2018-07-16 04:57:54 --> Loader Class Initialized
INFO - 2018-07-16 04:57:54 --> Controller Class Initialized
INFO - 2018-07-16 04:57:54 --> Database Driver Class Initialized
INFO - 2018-07-16 04:57:54 --> Model Class Initialized
INFO - 2018-07-16 04:57:54 --> Helper loaded: url_helper
DEBUG - 2018-07-16 04:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 04:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 04:57:54 --> Model Class Initialized
INFO - 2018-07-16 04:57:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-16 04:57:54 --> Final output sent to browser
DEBUG - 2018-07-16 04:57:54 --> Total execution time: 0.0533
ERROR - 2018-07-16 04:57:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 04:57:55 --> Config Class Initialized
INFO - 2018-07-16 04:57:55 --> Hooks Class Initialized
DEBUG - 2018-07-16 04:57:55 --> UTF-8 Support Enabled
INFO - 2018-07-16 04:57:55 --> Utf8 Class Initialized
INFO - 2018-07-16 04:57:56 --> URI Class Initialized
INFO - 2018-07-16 04:57:56 --> Router Class Initialized
INFO - 2018-07-16 04:57:56 --> Output Class Initialized
INFO - 2018-07-16 04:57:56 --> Security Class Initialized
DEBUG - 2018-07-16 04:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 04:57:56 --> Input Class Initialized
INFO - 2018-07-16 04:57:56 --> Language Class Initialized
INFO - 2018-07-16 04:57:56 --> Loader Class Initialized
INFO - 2018-07-16 04:57:56 --> Controller Class Initialized
INFO - 2018-07-16 04:57:56 --> Database Driver Class Initialized
INFO - 2018-07-16 04:57:56 --> Model Class Initialized
INFO - 2018-07-16 04:57:56 --> Helper loaded: url_helper
DEBUG - 2018-07-16 04:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 04:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 04:57:56 --> Model Class Initialized
ERROR - 2018-07-16 04:57:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 04:57:56 --> Config Class Initialized
INFO - 2018-07-16 04:57:56 --> Hooks Class Initialized
DEBUG - 2018-07-16 04:57:56 --> UTF-8 Support Enabled
INFO - 2018-07-16 04:57:56 --> Utf8 Class Initialized
INFO - 2018-07-16 04:57:56 --> URI Class Initialized
INFO - 2018-07-16 04:57:56 --> Router Class Initialized
INFO - 2018-07-16 04:57:56 --> Output Class Initialized
INFO - 2018-07-16 04:57:56 --> Security Class Initialized
DEBUG - 2018-07-16 04:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 04:57:56 --> Input Class Initialized
INFO - 2018-07-16 04:57:56 --> Language Class Initialized
INFO - 2018-07-16 04:57:56 --> Loader Class Initialized
INFO - 2018-07-16 04:57:56 --> Controller Class Initialized
INFO - 2018-07-16 04:57:56 --> Database Driver Class Initialized
INFO - 2018-07-16 04:57:56 --> Model Class Initialized
INFO - 2018-07-16 04:57:56 --> Helper loaded: url_helper
DEBUG - 2018-07-16 04:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 04:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 04:57:56 --> Model Class Initialized
INFO - 2018-07-16 04:57:56 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 04:57:56 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 04:57:56 --> Final output sent to browser
DEBUG - 2018-07-16 04:57:56 --> Total execution time: 0.0494
ERROR - 2018-07-16 04:57:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 04:57:59 --> Config Class Initialized
INFO - 2018-07-16 04:57:59 --> Hooks Class Initialized
DEBUG - 2018-07-16 04:57:59 --> UTF-8 Support Enabled
INFO - 2018-07-16 04:57:59 --> Utf8 Class Initialized
INFO - 2018-07-16 04:57:59 --> URI Class Initialized
INFO - 2018-07-16 04:57:59 --> Router Class Initialized
INFO - 2018-07-16 04:57:59 --> Output Class Initialized
INFO - 2018-07-16 04:57:59 --> Security Class Initialized
DEBUG - 2018-07-16 04:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 04:57:59 --> Input Class Initialized
INFO - 2018-07-16 04:57:59 --> Language Class Initialized
INFO - 2018-07-16 04:57:59 --> Loader Class Initialized
INFO - 2018-07-16 04:57:59 --> Controller Class Initialized
INFO - 2018-07-16 04:57:59 --> Database Driver Class Initialized
INFO - 2018-07-16 04:57:59 --> Model Class Initialized
INFO - 2018-07-16 04:57:59 --> Helper loaded: url_helper
DEBUG - 2018-07-16 04:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 04:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 04:57:59 --> Model Class Initialized
INFO - 2018-07-16 04:57:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 04:57:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 04:57:59 --> Final output sent to browser
DEBUG - 2018-07-16 04:57:59 --> Total execution time: 0.0619
ERROR - 2018-07-16 05:24:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 05:24:16 --> Config Class Initialized
INFO - 2018-07-16 05:24:16 --> Hooks Class Initialized
DEBUG - 2018-07-16 05:24:16 --> UTF-8 Support Enabled
INFO - 2018-07-16 05:24:16 --> Utf8 Class Initialized
INFO - 2018-07-16 05:24:16 --> URI Class Initialized
INFO - 2018-07-16 05:24:16 --> Router Class Initialized
INFO - 2018-07-16 05:24:16 --> Output Class Initialized
INFO - 2018-07-16 05:24:16 --> Security Class Initialized
DEBUG - 2018-07-16 05:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 05:24:16 --> Input Class Initialized
INFO - 2018-07-16 05:24:16 --> Language Class Initialized
INFO - 2018-07-16 05:24:16 --> Loader Class Initialized
INFO - 2018-07-16 05:24:16 --> Controller Class Initialized
INFO - 2018-07-16 05:24:16 --> Database Driver Class Initialized
INFO - 2018-07-16 05:24:16 --> Model Class Initialized
INFO - 2018-07-16 05:24:16 --> Helper loaded: url_helper
DEBUG - 2018-07-16 05:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 05:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 05:24:16 --> Model Class Initialized
INFO - 2018-07-16 05:24:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 05:24:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 05:24:16 --> Final output sent to browser
DEBUG - 2018-07-16 05:24:16 --> Total execution time: 0.0479
ERROR - 2018-07-16 05:25:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 05:25:40 --> Config Class Initialized
INFO - 2018-07-16 05:25:40 --> Hooks Class Initialized
DEBUG - 2018-07-16 05:25:40 --> UTF-8 Support Enabled
INFO - 2018-07-16 05:25:40 --> Utf8 Class Initialized
INFO - 2018-07-16 05:25:40 --> URI Class Initialized
INFO - 2018-07-16 05:25:40 --> Router Class Initialized
INFO - 2018-07-16 05:25:40 --> Output Class Initialized
INFO - 2018-07-16 05:25:40 --> Security Class Initialized
DEBUG - 2018-07-16 05:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 05:25:40 --> Input Class Initialized
INFO - 2018-07-16 05:25:40 --> Language Class Initialized
INFO - 2018-07-16 05:25:40 --> Loader Class Initialized
INFO - 2018-07-16 05:25:40 --> Controller Class Initialized
INFO - 2018-07-16 05:25:40 --> Database Driver Class Initialized
INFO - 2018-07-16 05:25:40 --> Model Class Initialized
INFO - 2018-07-16 05:25:40 --> Helper loaded: url_helper
DEBUG - 2018-07-16 05:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 05:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 05:25:40 --> Model Class Initialized
INFO - 2018-07-16 05:25:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 05:25:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 05:25:40 --> Final output sent to browser
DEBUG - 2018-07-16 05:25:40 --> Total execution time: 0.0423
ERROR - 2018-07-16 05:25:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 05:25:57 --> Config Class Initialized
INFO - 2018-07-16 05:25:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 05:25:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 05:25:57 --> Utf8 Class Initialized
INFO - 2018-07-16 05:25:57 --> URI Class Initialized
INFO - 2018-07-16 05:25:57 --> Router Class Initialized
INFO - 2018-07-16 05:25:57 --> Output Class Initialized
INFO - 2018-07-16 05:25:57 --> Security Class Initialized
DEBUG - 2018-07-16 05:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 05:25:57 --> Input Class Initialized
INFO - 2018-07-16 05:25:57 --> Language Class Initialized
INFO - 2018-07-16 05:25:57 --> Loader Class Initialized
INFO - 2018-07-16 05:25:57 --> Controller Class Initialized
INFO - 2018-07-16 05:25:57 --> Database Driver Class Initialized
INFO - 2018-07-16 05:25:57 --> Model Class Initialized
INFO - 2018-07-16 05:25:57 --> Helper loaded: url_helper
DEBUG - 2018-07-16 05:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 05:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 05:25:57 --> Model Class Initialized
INFO - 2018-07-16 05:25:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 05:25:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 05:25:57 --> Final output sent to browser
DEBUG - 2018-07-16 05:25:57 --> Total execution time: 0.0520
ERROR - 2018-07-16 05:26:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 05:26:04 --> Config Class Initialized
INFO - 2018-07-16 05:26:04 --> Hooks Class Initialized
DEBUG - 2018-07-16 05:26:04 --> UTF-8 Support Enabled
INFO - 2018-07-16 05:26:04 --> Utf8 Class Initialized
INFO - 2018-07-16 05:26:04 --> URI Class Initialized
INFO - 2018-07-16 05:26:04 --> Router Class Initialized
INFO - 2018-07-16 05:26:04 --> Output Class Initialized
INFO - 2018-07-16 05:26:04 --> Security Class Initialized
DEBUG - 2018-07-16 05:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 05:26:04 --> Input Class Initialized
INFO - 2018-07-16 05:26:04 --> Language Class Initialized
INFO - 2018-07-16 05:26:04 --> Loader Class Initialized
INFO - 2018-07-16 05:26:04 --> Controller Class Initialized
INFO - 2018-07-16 05:26:04 --> Database Driver Class Initialized
INFO - 2018-07-16 05:26:04 --> Model Class Initialized
INFO - 2018-07-16 05:26:04 --> Helper loaded: url_helper
DEBUG - 2018-07-16 05:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 05:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 05:26:04 --> Model Class Initialized
INFO - 2018-07-16 05:26:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 05:26:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 05:26:04 --> Final output sent to browser
DEBUG - 2018-07-16 05:26:04 --> Total execution time: 0.0504
ERROR - 2018-07-16 05:27:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 05:27:50 --> Config Class Initialized
INFO - 2018-07-16 05:27:50 --> Hooks Class Initialized
DEBUG - 2018-07-16 05:27:50 --> UTF-8 Support Enabled
INFO - 2018-07-16 05:27:50 --> Utf8 Class Initialized
INFO - 2018-07-16 05:27:50 --> URI Class Initialized
INFO - 2018-07-16 05:27:50 --> Router Class Initialized
INFO - 2018-07-16 05:27:50 --> Output Class Initialized
INFO - 2018-07-16 05:27:50 --> Security Class Initialized
DEBUG - 2018-07-16 05:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 05:27:50 --> Input Class Initialized
INFO - 2018-07-16 05:27:50 --> Language Class Initialized
INFO - 2018-07-16 05:27:50 --> Loader Class Initialized
INFO - 2018-07-16 05:27:50 --> Controller Class Initialized
INFO - 2018-07-16 05:27:50 --> Database Driver Class Initialized
INFO - 2018-07-16 05:27:50 --> Model Class Initialized
INFO - 2018-07-16 05:27:50 --> Helper loaded: url_helper
DEBUG - 2018-07-16 05:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 05:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 05:27:50 --> Model Class Initialized
INFO - 2018-07-16 05:27:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 05:27:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 05:27:50 --> Final output sent to browser
DEBUG - 2018-07-16 05:27:50 --> Total execution time: 0.0583
ERROR - 2018-07-16 05:30:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 05:30:45 --> Config Class Initialized
INFO - 2018-07-16 05:30:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 05:30:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 05:30:45 --> Utf8 Class Initialized
INFO - 2018-07-16 05:30:45 --> URI Class Initialized
INFO - 2018-07-16 05:30:45 --> Router Class Initialized
INFO - 2018-07-16 05:30:45 --> Output Class Initialized
INFO - 2018-07-16 05:30:45 --> Security Class Initialized
DEBUG - 2018-07-16 05:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 05:30:45 --> Input Class Initialized
INFO - 2018-07-16 05:30:45 --> Language Class Initialized
INFO - 2018-07-16 05:30:45 --> Loader Class Initialized
INFO - 2018-07-16 05:30:45 --> Controller Class Initialized
INFO - 2018-07-16 05:30:45 --> Database Driver Class Initialized
INFO - 2018-07-16 05:30:45 --> Model Class Initialized
INFO - 2018-07-16 05:30:45 --> Helper loaded: url_helper
DEBUG - 2018-07-16 05:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 05:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 05:30:45 --> Model Class Initialized
INFO - 2018-07-16 05:30:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 05:30:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 05:30:45 --> Final output sent to browser
DEBUG - 2018-07-16 05:30:45 --> Total execution time: 0.0451
ERROR - 2018-07-16 05:34:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 05:34:40 --> Config Class Initialized
INFO - 2018-07-16 05:34:40 --> Hooks Class Initialized
DEBUG - 2018-07-16 05:34:40 --> UTF-8 Support Enabled
INFO - 2018-07-16 05:34:40 --> Utf8 Class Initialized
INFO - 2018-07-16 05:34:40 --> URI Class Initialized
INFO - 2018-07-16 05:34:40 --> Router Class Initialized
INFO - 2018-07-16 05:34:40 --> Output Class Initialized
INFO - 2018-07-16 05:34:40 --> Security Class Initialized
DEBUG - 2018-07-16 05:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 05:34:40 --> Input Class Initialized
INFO - 2018-07-16 05:34:40 --> Language Class Initialized
INFO - 2018-07-16 05:34:40 --> Loader Class Initialized
INFO - 2018-07-16 05:34:40 --> Controller Class Initialized
INFO - 2018-07-16 05:34:40 --> Database Driver Class Initialized
INFO - 2018-07-16 05:34:40 --> Model Class Initialized
INFO - 2018-07-16 05:34:40 --> Helper loaded: url_helper
DEBUG - 2018-07-16 05:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 05:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 05:34:40 --> Model Class Initialized
INFO - 2018-07-16 05:34:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 05:34:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 05:34:40 --> Final output sent to browser
DEBUG - 2018-07-16 05:34:40 --> Total execution time: 0.0450
ERROR - 2018-07-16 05:35:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 05:35:04 --> Config Class Initialized
INFO - 2018-07-16 05:35:04 --> Hooks Class Initialized
DEBUG - 2018-07-16 05:35:04 --> UTF-8 Support Enabled
INFO - 2018-07-16 05:35:04 --> Utf8 Class Initialized
INFO - 2018-07-16 05:35:04 --> URI Class Initialized
INFO - 2018-07-16 05:35:04 --> Router Class Initialized
INFO - 2018-07-16 05:35:04 --> Output Class Initialized
INFO - 2018-07-16 05:35:04 --> Security Class Initialized
DEBUG - 2018-07-16 05:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 05:35:04 --> Input Class Initialized
INFO - 2018-07-16 05:35:04 --> Language Class Initialized
INFO - 2018-07-16 05:35:04 --> Loader Class Initialized
INFO - 2018-07-16 05:35:04 --> Controller Class Initialized
INFO - 2018-07-16 05:35:04 --> Database Driver Class Initialized
INFO - 2018-07-16 05:35:04 --> Model Class Initialized
INFO - 2018-07-16 05:35:04 --> Helper loaded: url_helper
DEBUG - 2018-07-16 05:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 05:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 05:35:04 --> Model Class Initialized
INFO - 2018-07-16 05:35:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 05:35:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 05:35:04 --> Final output sent to browser
DEBUG - 2018-07-16 05:35:04 --> Total execution time: 0.0823
ERROR - 2018-07-16 05:37:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 05:37:47 --> Config Class Initialized
INFO - 2018-07-16 05:37:47 --> Hooks Class Initialized
DEBUG - 2018-07-16 05:37:47 --> UTF-8 Support Enabled
INFO - 2018-07-16 05:37:47 --> Utf8 Class Initialized
INFO - 2018-07-16 05:37:47 --> URI Class Initialized
INFO - 2018-07-16 05:37:47 --> Router Class Initialized
INFO - 2018-07-16 05:37:47 --> Output Class Initialized
INFO - 2018-07-16 05:37:47 --> Security Class Initialized
DEBUG - 2018-07-16 05:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 05:37:47 --> Input Class Initialized
INFO - 2018-07-16 05:37:47 --> Language Class Initialized
INFO - 2018-07-16 05:37:47 --> Loader Class Initialized
INFO - 2018-07-16 05:37:47 --> Controller Class Initialized
INFO - 2018-07-16 05:37:47 --> Database Driver Class Initialized
INFO - 2018-07-16 05:37:47 --> Model Class Initialized
INFO - 2018-07-16 05:37:47 --> Helper loaded: url_helper
DEBUG - 2018-07-16 05:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 05:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 05:37:47 --> Model Class Initialized
INFO - 2018-07-16 05:37:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 05:37:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 05:37:47 --> Final output sent to browser
DEBUG - 2018-07-16 05:37:47 --> Total execution time: 0.0442
ERROR - 2018-07-16 05:38:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 05:38:23 --> Config Class Initialized
INFO - 2018-07-16 05:38:23 --> Hooks Class Initialized
DEBUG - 2018-07-16 05:38:23 --> UTF-8 Support Enabled
INFO - 2018-07-16 05:38:23 --> Utf8 Class Initialized
INFO - 2018-07-16 05:38:23 --> URI Class Initialized
INFO - 2018-07-16 05:38:23 --> Router Class Initialized
INFO - 2018-07-16 05:38:23 --> Output Class Initialized
INFO - 2018-07-16 05:38:23 --> Security Class Initialized
DEBUG - 2018-07-16 05:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 05:38:23 --> Input Class Initialized
INFO - 2018-07-16 05:38:23 --> Language Class Initialized
INFO - 2018-07-16 05:38:23 --> Loader Class Initialized
INFO - 2018-07-16 05:38:23 --> Controller Class Initialized
INFO - 2018-07-16 05:38:23 --> Database Driver Class Initialized
INFO - 2018-07-16 05:38:23 --> Model Class Initialized
INFO - 2018-07-16 05:38:23 --> Helper loaded: url_helper
DEBUG - 2018-07-16 05:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 05:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 05:38:23 --> Model Class Initialized
INFO - 2018-07-16 05:38:23 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 05:38:23 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 05:38:23 --> Final output sent to browser
DEBUG - 2018-07-16 05:38:23 --> Total execution time: 0.0576
ERROR - 2018-07-16 06:04:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:04:21 --> Config Class Initialized
INFO - 2018-07-16 06:04:21 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:04:21 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:04:21 --> Utf8 Class Initialized
INFO - 2018-07-16 06:04:21 --> URI Class Initialized
INFO - 2018-07-16 06:04:21 --> Router Class Initialized
INFO - 2018-07-16 06:04:21 --> Output Class Initialized
INFO - 2018-07-16 06:04:21 --> Security Class Initialized
DEBUG - 2018-07-16 06:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:04:21 --> Input Class Initialized
INFO - 2018-07-16 06:04:21 --> Language Class Initialized
INFO - 2018-07-16 06:04:21 --> Loader Class Initialized
INFO - 2018-07-16 06:04:21 --> Controller Class Initialized
INFO - 2018-07-16 06:04:21 --> Database Driver Class Initialized
INFO - 2018-07-16 06:04:21 --> Model Class Initialized
INFO - 2018-07-16 06:04:21 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:04:21 --> Model Class Initialized
INFO - 2018-07-16 06:04:21 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:04:21 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:04:21 --> Final output sent to browser
DEBUG - 2018-07-16 06:04:21 --> Total execution time: 0.0589
ERROR - 2018-07-16 06:06:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:06:56 --> Config Class Initialized
INFO - 2018-07-16 06:06:56 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:06:56 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:06:56 --> Utf8 Class Initialized
INFO - 2018-07-16 06:06:56 --> URI Class Initialized
INFO - 2018-07-16 06:06:56 --> Router Class Initialized
INFO - 2018-07-16 06:06:56 --> Output Class Initialized
INFO - 2018-07-16 06:06:56 --> Security Class Initialized
DEBUG - 2018-07-16 06:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:06:56 --> Input Class Initialized
INFO - 2018-07-16 06:06:56 --> Language Class Initialized
INFO - 2018-07-16 06:06:56 --> Loader Class Initialized
INFO - 2018-07-16 06:06:56 --> Controller Class Initialized
INFO - 2018-07-16 06:06:56 --> Database Driver Class Initialized
INFO - 2018-07-16 06:06:56 --> Model Class Initialized
INFO - 2018-07-16 06:06:56 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:06:56 --> Model Class Initialized
INFO - 2018-07-16 06:06:56 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:06:56 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:06:56 --> Final output sent to browser
DEBUG - 2018-07-16 06:06:56 --> Total execution time: 0.0517
ERROR - 2018-07-16 06:08:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:08:25 --> Config Class Initialized
INFO - 2018-07-16 06:08:25 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:08:25 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:08:25 --> Utf8 Class Initialized
INFO - 2018-07-16 06:08:25 --> URI Class Initialized
INFO - 2018-07-16 06:08:25 --> Router Class Initialized
INFO - 2018-07-16 06:08:25 --> Output Class Initialized
INFO - 2018-07-16 06:08:25 --> Security Class Initialized
DEBUG - 2018-07-16 06:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:08:25 --> Input Class Initialized
INFO - 2018-07-16 06:08:25 --> Language Class Initialized
INFO - 2018-07-16 06:08:25 --> Loader Class Initialized
INFO - 2018-07-16 06:08:25 --> Controller Class Initialized
INFO - 2018-07-16 06:08:25 --> Database Driver Class Initialized
INFO - 2018-07-16 06:08:25 --> Model Class Initialized
INFO - 2018-07-16 06:08:25 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:08:25 --> Model Class Initialized
INFO - 2018-07-16 06:08:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:08:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:08:25 --> Final output sent to browser
DEBUG - 2018-07-16 06:08:25 --> Total execution time: 0.0656
ERROR - 2018-07-16 06:08:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:08:37 --> Config Class Initialized
INFO - 2018-07-16 06:08:37 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:08:37 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:08:37 --> Utf8 Class Initialized
INFO - 2018-07-16 06:08:37 --> URI Class Initialized
INFO - 2018-07-16 06:08:37 --> Router Class Initialized
INFO - 2018-07-16 06:08:37 --> Output Class Initialized
INFO - 2018-07-16 06:08:37 --> Security Class Initialized
DEBUG - 2018-07-16 06:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:08:37 --> Input Class Initialized
INFO - 2018-07-16 06:08:37 --> Language Class Initialized
INFO - 2018-07-16 06:08:37 --> Loader Class Initialized
INFO - 2018-07-16 06:08:37 --> Controller Class Initialized
INFO - 2018-07-16 06:08:37 --> Database Driver Class Initialized
INFO - 2018-07-16 06:08:37 --> Model Class Initialized
INFO - 2018-07-16 06:08:37 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:08:37 --> Model Class Initialized
INFO - 2018-07-16 06:08:37 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:08:37 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:08:37 --> Final output sent to browser
DEBUG - 2018-07-16 06:08:37 --> Total execution time: 0.0821
ERROR - 2018-07-16 06:13:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:13:03 --> Config Class Initialized
INFO - 2018-07-16 06:13:03 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:13:03 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:13:03 --> Utf8 Class Initialized
INFO - 2018-07-16 06:13:03 --> URI Class Initialized
INFO - 2018-07-16 06:13:03 --> Router Class Initialized
INFO - 2018-07-16 06:13:03 --> Output Class Initialized
INFO - 2018-07-16 06:13:03 --> Security Class Initialized
DEBUG - 2018-07-16 06:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:13:03 --> Input Class Initialized
INFO - 2018-07-16 06:13:03 --> Language Class Initialized
INFO - 2018-07-16 06:13:03 --> Loader Class Initialized
INFO - 2018-07-16 06:13:03 --> Controller Class Initialized
INFO - 2018-07-16 06:13:03 --> Database Driver Class Initialized
INFO - 2018-07-16 06:13:03 --> Model Class Initialized
INFO - 2018-07-16 06:13:03 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:13:03 --> Model Class Initialized
INFO - 2018-07-16 06:13:03 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:13:03 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:13:03 --> Final output sent to browser
DEBUG - 2018-07-16 06:13:03 --> Total execution time: 0.0864
ERROR - 2018-07-16 06:19:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:19:01 --> Config Class Initialized
INFO - 2018-07-16 06:19:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:19:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:19:01 --> Utf8 Class Initialized
INFO - 2018-07-16 06:19:01 --> URI Class Initialized
INFO - 2018-07-16 06:19:01 --> Router Class Initialized
INFO - 2018-07-16 06:19:01 --> Output Class Initialized
INFO - 2018-07-16 06:19:01 --> Security Class Initialized
DEBUG - 2018-07-16 06:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:19:01 --> Input Class Initialized
INFO - 2018-07-16 06:19:01 --> Language Class Initialized
INFO - 2018-07-16 06:19:01 --> Loader Class Initialized
INFO - 2018-07-16 06:19:01 --> Controller Class Initialized
INFO - 2018-07-16 06:19:01 --> Database Driver Class Initialized
INFO - 2018-07-16 06:19:01 --> Model Class Initialized
INFO - 2018-07-16 06:19:01 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:19:01 --> Model Class Initialized
INFO - 2018-07-16 06:19:01 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:19:01 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:19:01 --> Final output sent to browser
DEBUG - 2018-07-16 06:19:01 --> Total execution time: 0.0491
ERROR - 2018-07-16 06:19:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:19:01 --> Config Class Initialized
INFO - 2018-07-16 06:19:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:19:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:19:01 --> Utf8 Class Initialized
INFO - 2018-07-16 06:19:01 --> URI Class Initialized
INFO - 2018-07-16 06:19:01 --> Router Class Initialized
INFO - 2018-07-16 06:19:01 --> Output Class Initialized
INFO - 2018-07-16 06:19:01 --> Security Class Initialized
DEBUG - 2018-07-16 06:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:19:01 --> Input Class Initialized
INFO - 2018-07-16 06:19:01 --> Language Class Initialized
ERROR - 2018-07-16 06:19:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-07-16 06:19:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:19:01 --> Config Class Initialized
INFO - 2018-07-16 06:19:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:19:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:19:01 --> Utf8 Class Initialized
INFO - 2018-07-16 06:19:01 --> URI Class Initialized
INFO - 2018-07-16 06:19:01 --> Router Class Initialized
INFO - 2018-07-16 06:19:01 --> Output Class Initialized
INFO - 2018-07-16 06:19:01 --> Security Class Initialized
DEBUG - 2018-07-16 06:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:19:01 --> Input Class Initialized
INFO - 2018-07-16 06:19:01 --> Language Class Initialized
ERROR - 2018-07-16 06:19:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-07-16 06:19:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:19:29 --> Config Class Initialized
INFO - 2018-07-16 06:19:29 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:19:29 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:19:29 --> Utf8 Class Initialized
INFO - 2018-07-16 06:19:29 --> URI Class Initialized
INFO - 2018-07-16 06:19:29 --> Router Class Initialized
INFO - 2018-07-16 06:19:29 --> Output Class Initialized
INFO - 2018-07-16 06:19:29 --> Security Class Initialized
DEBUG - 2018-07-16 06:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:19:29 --> Input Class Initialized
INFO - 2018-07-16 06:19:29 --> Language Class Initialized
INFO - 2018-07-16 06:19:29 --> Loader Class Initialized
INFO - 2018-07-16 06:19:29 --> Controller Class Initialized
INFO - 2018-07-16 06:19:29 --> Database Driver Class Initialized
INFO - 2018-07-16 06:19:29 --> Model Class Initialized
INFO - 2018-07-16 06:19:29 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:19:29 --> Model Class Initialized
INFO - 2018-07-16 06:19:29 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:19:29 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:19:29 --> Final output sent to browser
DEBUG - 2018-07-16 06:19:29 --> Total execution time: 0.0580
ERROR - 2018-07-16 06:19:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:19:29 --> Config Class Initialized
INFO - 2018-07-16 06:19:29 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:19:29 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:19:29 --> Utf8 Class Initialized
INFO - 2018-07-16 06:19:29 --> URI Class Initialized
INFO - 2018-07-16 06:19:29 --> Router Class Initialized
INFO - 2018-07-16 06:19:29 --> Output Class Initialized
INFO - 2018-07-16 06:19:29 --> Security Class Initialized
DEBUG - 2018-07-16 06:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:19:29 --> Input Class Initialized
INFO - 2018-07-16 06:19:29 --> Language Class Initialized
ERROR - 2018-07-16 06:19:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-07-16 06:19:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:19:29 --> Config Class Initialized
INFO - 2018-07-16 06:19:29 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:19:29 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:19:29 --> Utf8 Class Initialized
INFO - 2018-07-16 06:19:29 --> URI Class Initialized
INFO - 2018-07-16 06:19:29 --> Router Class Initialized
INFO - 2018-07-16 06:19:29 --> Output Class Initialized
INFO - 2018-07-16 06:19:29 --> Security Class Initialized
DEBUG - 2018-07-16 06:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:19:29 --> Input Class Initialized
INFO - 2018-07-16 06:19:29 --> Language Class Initialized
ERROR - 2018-07-16 06:19:29 --> 404 Page Not Found: Assets/css
ERROR - 2018-07-16 06:19:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:19:59 --> Config Class Initialized
INFO - 2018-07-16 06:19:59 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:19:59 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:19:59 --> Utf8 Class Initialized
INFO - 2018-07-16 06:19:59 --> URI Class Initialized
INFO - 2018-07-16 06:19:59 --> Router Class Initialized
INFO - 2018-07-16 06:19:59 --> Output Class Initialized
INFO - 2018-07-16 06:19:59 --> Security Class Initialized
DEBUG - 2018-07-16 06:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:19:59 --> Input Class Initialized
INFO - 2018-07-16 06:19:59 --> Language Class Initialized
INFO - 2018-07-16 06:19:59 --> Loader Class Initialized
INFO - 2018-07-16 06:19:59 --> Controller Class Initialized
INFO - 2018-07-16 06:19:59 --> Database Driver Class Initialized
INFO - 2018-07-16 06:19:59 --> Model Class Initialized
INFO - 2018-07-16 06:19:59 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:19:59 --> Model Class Initialized
INFO - 2018-07-16 06:19:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:19:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:19:59 --> Final output sent to browser
DEBUG - 2018-07-16 06:19:59 --> Total execution time: 0.0815
ERROR - 2018-07-16 06:21:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:21:00 --> Config Class Initialized
INFO - 2018-07-16 06:21:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:21:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:21:00 --> Utf8 Class Initialized
INFO - 2018-07-16 06:21:00 --> URI Class Initialized
INFO - 2018-07-16 06:21:01 --> Router Class Initialized
INFO - 2018-07-16 06:21:01 --> Output Class Initialized
INFO - 2018-07-16 06:21:01 --> Security Class Initialized
DEBUG - 2018-07-16 06:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:21:01 --> Input Class Initialized
INFO - 2018-07-16 06:21:01 --> Language Class Initialized
INFO - 2018-07-16 06:21:01 --> Loader Class Initialized
INFO - 2018-07-16 06:21:01 --> Controller Class Initialized
INFO - 2018-07-16 06:21:01 --> Database Driver Class Initialized
INFO - 2018-07-16 06:21:01 --> Model Class Initialized
INFO - 2018-07-16 06:21:01 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:21:01 --> Model Class Initialized
INFO - 2018-07-16 06:21:01 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:21:01 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:21:01 --> Final output sent to browser
DEBUG - 2018-07-16 06:21:01 --> Total execution time: 0.0542
ERROR - 2018-07-16 06:21:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:21:27 --> Config Class Initialized
INFO - 2018-07-16 06:21:27 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:21:27 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:21:27 --> Utf8 Class Initialized
INFO - 2018-07-16 06:21:27 --> URI Class Initialized
INFO - 2018-07-16 06:21:27 --> Router Class Initialized
INFO - 2018-07-16 06:21:27 --> Output Class Initialized
INFO - 2018-07-16 06:21:27 --> Security Class Initialized
DEBUG - 2018-07-16 06:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:21:27 --> Input Class Initialized
INFO - 2018-07-16 06:21:27 --> Language Class Initialized
INFO - 2018-07-16 06:21:27 --> Loader Class Initialized
INFO - 2018-07-16 06:21:27 --> Controller Class Initialized
INFO - 2018-07-16 06:21:27 --> Database Driver Class Initialized
INFO - 2018-07-16 06:21:27 --> Model Class Initialized
INFO - 2018-07-16 06:21:27 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:21:27 --> Model Class Initialized
INFO - 2018-07-16 06:21:27 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:21:27 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:21:27 --> Final output sent to browser
DEBUG - 2018-07-16 06:21:27 --> Total execution time: 0.0708
ERROR - 2018-07-16 06:21:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:21:41 --> Config Class Initialized
INFO - 2018-07-16 06:21:41 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:21:41 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:21:41 --> Utf8 Class Initialized
INFO - 2018-07-16 06:21:41 --> URI Class Initialized
INFO - 2018-07-16 06:21:41 --> Router Class Initialized
INFO - 2018-07-16 06:21:41 --> Output Class Initialized
INFO - 2018-07-16 06:21:41 --> Security Class Initialized
DEBUG - 2018-07-16 06:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:21:41 --> Input Class Initialized
INFO - 2018-07-16 06:21:41 --> Language Class Initialized
INFO - 2018-07-16 06:21:41 --> Loader Class Initialized
INFO - 2018-07-16 06:21:41 --> Controller Class Initialized
INFO - 2018-07-16 06:21:41 --> Database Driver Class Initialized
INFO - 2018-07-16 06:21:41 --> Model Class Initialized
INFO - 2018-07-16 06:21:41 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:21:41 --> Model Class Initialized
INFO - 2018-07-16 06:21:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:21:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:21:41 --> Final output sent to browser
DEBUG - 2018-07-16 06:21:41 --> Total execution time: 0.0589
ERROR - 2018-07-16 06:23:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:23:25 --> Config Class Initialized
INFO - 2018-07-16 06:23:25 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:23:25 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:23:25 --> Utf8 Class Initialized
INFO - 2018-07-16 06:23:25 --> URI Class Initialized
INFO - 2018-07-16 06:23:25 --> Router Class Initialized
INFO - 2018-07-16 06:23:25 --> Output Class Initialized
INFO - 2018-07-16 06:23:25 --> Security Class Initialized
DEBUG - 2018-07-16 06:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:23:25 --> Input Class Initialized
INFO - 2018-07-16 06:23:25 --> Language Class Initialized
INFO - 2018-07-16 06:23:25 --> Loader Class Initialized
INFO - 2018-07-16 06:23:25 --> Controller Class Initialized
INFO - 2018-07-16 06:23:25 --> Database Driver Class Initialized
INFO - 2018-07-16 06:23:25 --> Model Class Initialized
INFO - 2018-07-16 06:23:25 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:23:25 --> Model Class Initialized
INFO - 2018-07-16 06:23:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:23:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:23:25 --> Final output sent to browser
DEBUG - 2018-07-16 06:23:25 --> Total execution time: 0.0659
ERROR - 2018-07-16 06:23:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:23:48 --> Config Class Initialized
INFO - 2018-07-16 06:23:48 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:23:48 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:23:48 --> Utf8 Class Initialized
INFO - 2018-07-16 06:23:48 --> URI Class Initialized
INFO - 2018-07-16 06:23:48 --> Router Class Initialized
INFO - 2018-07-16 06:23:48 --> Output Class Initialized
INFO - 2018-07-16 06:23:48 --> Security Class Initialized
DEBUG - 2018-07-16 06:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:23:48 --> Input Class Initialized
INFO - 2018-07-16 06:23:48 --> Language Class Initialized
INFO - 2018-07-16 06:23:48 --> Loader Class Initialized
INFO - 2018-07-16 06:23:48 --> Controller Class Initialized
INFO - 2018-07-16 06:23:48 --> Database Driver Class Initialized
INFO - 2018-07-16 06:23:48 --> Model Class Initialized
INFO - 2018-07-16 06:23:48 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:23:48 --> Model Class Initialized
INFO - 2018-07-16 06:23:48 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:23:48 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:23:48 --> Final output sent to browser
DEBUG - 2018-07-16 06:23:48 --> Total execution time: 0.0430
ERROR - 2018-07-16 06:23:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:23:58 --> Config Class Initialized
INFO - 2018-07-16 06:23:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:23:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:23:58 --> Utf8 Class Initialized
INFO - 2018-07-16 06:23:58 --> URI Class Initialized
INFO - 2018-07-16 06:23:58 --> Router Class Initialized
INFO - 2018-07-16 06:23:58 --> Output Class Initialized
INFO - 2018-07-16 06:23:58 --> Security Class Initialized
DEBUG - 2018-07-16 06:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:23:58 --> Input Class Initialized
INFO - 2018-07-16 06:23:58 --> Language Class Initialized
INFO - 2018-07-16 06:23:58 --> Loader Class Initialized
INFO - 2018-07-16 06:23:58 --> Controller Class Initialized
INFO - 2018-07-16 06:23:58 --> Database Driver Class Initialized
INFO - 2018-07-16 06:23:58 --> Model Class Initialized
INFO - 2018-07-16 06:23:58 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:23:58 --> Model Class Initialized
INFO - 2018-07-16 06:23:58 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:23:58 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:23:58 --> Final output sent to browser
DEBUG - 2018-07-16 06:23:58 --> Total execution time: 0.0622
ERROR - 2018-07-16 06:24:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:24:21 --> Config Class Initialized
INFO - 2018-07-16 06:24:21 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:24:21 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:24:21 --> Utf8 Class Initialized
INFO - 2018-07-16 06:24:21 --> URI Class Initialized
INFO - 2018-07-16 06:24:21 --> Router Class Initialized
INFO - 2018-07-16 06:24:21 --> Output Class Initialized
INFO - 2018-07-16 06:24:21 --> Security Class Initialized
DEBUG - 2018-07-16 06:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:24:21 --> Input Class Initialized
INFO - 2018-07-16 06:24:21 --> Language Class Initialized
INFO - 2018-07-16 06:24:21 --> Loader Class Initialized
INFO - 2018-07-16 06:24:21 --> Controller Class Initialized
INFO - 2018-07-16 06:24:21 --> Database Driver Class Initialized
INFO - 2018-07-16 06:24:21 --> Model Class Initialized
INFO - 2018-07-16 06:24:21 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:24:21 --> Model Class Initialized
INFO - 2018-07-16 06:24:21 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:24:21 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:24:21 --> Final output sent to browser
DEBUG - 2018-07-16 06:24:21 --> Total execution time: 0.0537
ERROR - 2018-07-16 06:24:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:24:55 --> Config Class Initialized
INFO - 2018-07-16 06:24:55 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:24:55 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:24:55 --> Utf8 Class Initialized
INFO - 2018-07-16 06:24:55 --> URI Class Initialized
INFO - 2018-07-16 06:24:55 --> Router Class Initialized
INFO - 2018-07-16 06:24:55 --> Output Class Initialized
INFO - 2018-07-16 06:24:55 --> Security Class Initialized
DEBUG - 2018-07-16 06:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:24:55 --> Input Class Initialized
INFO - 2018-07-16 06:24:55 --> Language Class Initialized
INFO - 2018-07-16 06:24:55 --> Loader Class Initialized
INFO - 2018-07-16 06:24:55 --> Controller Class Initialized
INFO - 2018-07-16 06:24:55 --> Database Driver Class Initialized
INFO - 2018-07-16 06:24:55 --> Model Class Initialized
INFO - 2018-07-16 06:24:55 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:24:55 --> Model Class Initialized
INFO - 2018-07-16 06:24:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:24:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:24:55 --> Final output sent to browser
DEBUG - 2018-07-16 06:24:55 --> Total execution time: 0.0458
ERROR - 2018-07-16 06:28:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:28:05 --> Config Class Initialized
INFO - 2018-07-16 06:28:05 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:28:05 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:28:05 --> Utf8 Class Initialized
INFO - 2018-07-16 06:28:05 --> URI Class Initialized
INFO - 2018-07-16 06:28:05 --> Router Class Initialized
INFO - 2018-07-16 06:28:05 --> Output Class Initialized
INFO - 2018-07-16 06:28:05 --> Security Class Initialized
DEBUG - 2018-07-16 06:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:28:05 --> Input Class Initialized
INFO - 2018-07-16 06:28:05 --> Language Class Initialized
INFO - 2018-07-16 06:28:05 --> Loader Class Initialized
INFO - 2018-07-16 06:28:05 --> Controller Class Initialized
INFO - 2018-07-16 06:28:05 --> Database Driver Class Initialized
INFO - 2018-07-16 06:28:05 --> Model Class Initialized
INFO - 2018-07-16 06:28:05 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:28:05 --> Model Class Initialized
INFO - 2018-07-16 06:28:05 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:28:05 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:28:05 --> Final output sent to browser
DEBUG - 2018-07-16 06:28:05 --> Total execution time: 0.0736
ERROR - 2018-07-16 06:28:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:28:58 --> Config Class Initialized
INFO - 2018-07-16 06:28:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:28:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:28:58 --> Utf8 Class Initialized
INFO - 2018-07-16 06:28:58 --> URI Class Initialized
INFO - 2018-07-16 06:28:58 --> Router Class Initialized
INFO - 2018-07-16 06:28:58 --> Output Class Initialized
INFO - 2018-07-16 06:28:58 --> Security Class Initialized
DEBUG - 2018-07-16 06:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:28:58 --> Input Class Initialized
INFO - 2018-07-16 06:28:58 --> Language Class Initialized
INFO - 2018-07-16 06:28:58 --> Loader Class Initialized
INFO - 2018-07-16 06:28:58 --> Controller Class Initialized
INFO - 2018-07-16 06:28:58 --> Database Driver Class Initialized
INFO - 2018-07-16 06:28:58 --> Model Class Initialized
INFO - 2018-07-16 06:28:58 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:28:58 --> Model Class Initialized
INFO - 2018-07-16 06:28:58 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:28:58 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:28:58 --> Final output sent to browser
DEBUG - 2018-07-16 06:28:58 --> Total execution time: 0.0664
ERROR - 2018-07-16 06:29:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:29:23 --> Config Class Initialized
INFO - 2018-07-16 06:29:23 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:29:23 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:29:23 --> Utf8 Class Initialized
INFO - 2018-07-16 06:29:23 --> URI Class Initialized
INFO - 2018-07-16 06:29:23 --> Router Class Initialized
INFO - 2018-07-16 06:29:23 --> Output Class Initialized
INFO - 2018-07-16 06:29:23 --> Security Class Initialized
DEBUG - 2018-07-16 06:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:29:23 --> Input Class Initialized
INFO - 2018-07-16 06:29:23 --> Language Class Initialized
INFO - 2018-07-16 06:29:23 --> Loader Class Initialized
INFO - 2018-07-16 06:29:23 --> Controller Class Initialized
INFO - 2018-07-16 06:29:23 --> Database Driver Class Initialized
INFO - 2018-07-16 06:29:23 --> Model Class Initialized
INFO - 2018-07-16 06:29:23 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:29:23 --> Model Class Initialized
INFO - 2018-07-16 06:29:23 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:29:23 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:29:23 --> Final output sent to browser
DEBUG - 2018-07-16 06:29:23 --> Total execution time: 0.0458
ERROR - 2018-07-16 06:30:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:30:30 --> Config Class Initialized
INFO - 2018-07-16 06:30:30 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:30:30 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:30:30 --> Utf8 Class Initialized
INFO - 2018-07-16 06:30:30 --> URI Class Initialized
INFO - 2018-07-16 06:30:30 --> Router Class Initialized
INFO - 2018-07-16 06:30:30 --> Output Class Initialized
INFO - 2018-07-16 06:30:30 --> Security Class Initialized
DEBUG - 2018-07-16 06:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:30:30 --> Input Class Initialized
INFO - 2018-07-16 06:30:30 --> Language Class Initialized
INFO - 2018-07-16 06:30:30 --> Loader Class Initialized
INFO - 2018-07-16 06:30:30 --> Controller Class Initialized
INFO - 2018-07-16 06:30:30 --> Database Driver Class Initialized
INFO - 2018-07-16 06:30:30 --> Model Class Initialized
INFO - 2018-07-16 06:30:30 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:30:30 --> Model Class Initialized
INFO - 2018-07-16 06:30:30 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:30:30 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:30:30 --> Final output sent to browser
DEBUG - 2018-07-16 06:30:30 --> Total execution time: 0.0532
ERROR - 2018-07-16 06:30:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:30:57 --> Config Class Initialized
INFO - 2018-07-16 06:30:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:30:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:30:57 --> Utf8 Class Initialized
INFO - 2018-07-16 06:30:57 --> URI Class Initialized
INFO - 2018-07-16 06:30:57 --> Router Class Initialized
INFO - 2018-07-16 06:30:57 --> Output Class Initialized
INFO - 2018-07-16 06:30:57 --> Security Class Initialized
DEBUG - 2018-07-16 06:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:30:57 --> Input Class Initialized
INFO - 2018-07-16 06:30:57 --> Language Class Initialized
INFO - 2018-07-16 06:30:57 --> Loader Class Initialized
INFO - 2018-07-16 06:30:57 --> Controller Class Initialized
INFO - 2018-07-16 06:30:57 --> Database Driver Class Initialized
INFO - 2018-07-16 06:30:57 --> Model Class Initialized
INFO - 2018-07-16 06:30:57 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:30:57 --> Model Class Initialized
INFO - 2018-07-16 06:30:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:30:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:30:57 --> Final output sent to browser
DEBUG - 2018-07-16 06:30:57 --> Total execution time: 0.0456
ERROR - 2018-07-16 06:31:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:31:12 --> Config Class Initialized
INFO - 2018-07-16 06:31:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:31:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:31:12 --> Utf8 Class Initialized
INFO - 2018-07-16 06:31:12 --> URI Class Initialized
INFO - 2018-07-16 06:31:12 --> Router Class Initialized
INFO - 2018-07-16 06:31:12 --> Output Class Initialized
INFO - 2018-07-16 06:31:12 --> Security Class Initialized
DEBUG - 2018-07-16 06:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:31:12 --> Input Class Initialized
INFO - 2018-07-16 06:31:12 --> Language Class Initialized
INFO - 2018-07-16 06:31:12 --> Loader Class Initialized
INFO - 2018-07-16 06:31:12 --> Controller Class Initialized
INFO - 2018-07-16 06:31:12 --> Database Driver Class Initialized
INFO - 2018-07-16 06:31:12 --> Model Class Initialized
INFO - 2018-07-16 06:31:12 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:31:12 --> Model Class Initialized
INFO - 2018-07-16 06:31:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:31:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:31:12 --> Final output sent to browser
DEBUG - 2018-07-16 06:31:12 --> Total execution time: 0.0479
ERROR - 2018-07-16 06:31:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:31:35 --> Config Class Initialized
INFO - 2018-07-16 06:31:35 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:31:35 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:31:35 --> Utf8 Class Initialized
INFO - 2018-07-16 06:31:35 --> URI Class Initialized
INFO - 2018-07-16 06:31:35 --> Router Class Initialized
INFO - 2018-07-16 06:31:35 --> Output Class Initialized
INFO - 2018-07-16 06:31:35 --> Security Class Initialized
DEBUG - 2018-07-16 06:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:31:35 --> Input Class Initialized
INFO - 2018-07-16 06:31:35 --> Language Class Initialized
INFO - 2018-07-16 06:31:35 --> Loader Class Initialized
INFO - 2018-07-16 06:31:35 --> Controller Class Initialized
INFO - 2018-07-16 06:31:35 --> Database Driver Class Initialized
INFO - 2018-07-16 06:31:35 --> Model Class Initialized
INFO - 2018-07-16 06:31:35 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:31:35 --> Model Class Initialized
INFO - 2018-07-16 06:31:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:31:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:31:35 --> Final output sent to browser
DEBUG - 2018-07-16 06:31:35 --> Total execution time: 0.0639
ERROR - 2018-07-16 06:32:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:32:22 --> Config Class Initialized
INFO - 2018-07-16 06:32:22 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:32:22 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:32:22 --> Utf8 Class Initialized
INFO - 2018-07-16 06:32:22 --> URI Class Initialized
INFO - 2018-07-16 06:32:22 --> Router Class Initialized
INFO - 2018-07-16 06:32:22 --> Output Class Initialized
INFO - 2018-07-16 06:32:22 --> Security Class Initialized
DEBUG - 2018-07-16 06:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:32:22 --> Input Class Initialized
INFO - 2018-07-16 06:32:22 --> Language Class Initialized
INFO - 2018-07-16 06:32:22 --> Loader Class Initialized
INFO - 2018-07-16 06:32:22 --> Controller Class Initialized
INFO - 2018-07-16 06:32:22 --> Database Driver Class Initialized
INFO - 2018-07-16 06:32:22 --> Model Class Initialized
INFO - 2018-07-16 06:32:22 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:32:22 --> Model Class Initialized
INFO - 2018-07-16 06:32:22 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:32:22 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:32:22 --> Final output sent to browser
DEBUG - 2018-07-16 06:32:22 --> Total execution time: 0.0542
ERROR - 2018-07-16 06:34:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:34:33 --> Config Class Initialized
INFO - 2018-07-16 06:34:33 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:34:33 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:34:33 --> Utf8 Class Initialized
INFO - 2018-07-16 06:34:33 --> URI Class Initialized
INFO - 2018-07-16 06:34:33 --> Router Class Initialized
INFO - 2018-07-16 06:34:33 --> Output Class Initialized
INFO - 2018-07-16 06:34:33 --> Security Class Initialized
DEBUG - 2018-07-16 06:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:34:33 --> Input Class Initialized
INFO - 2018-07-16 06:34:33 --> Language Class Initialized
INFO - 2018-07-16 06:34:33 --> Loader Class Initialized
INFO - 2018-07-16 06:34:33 --> Controller Class Initialized
INFO - 2018-07-16 06:34:33 --> Database Driver Class Initialized
INFO - 2018-07-16 06:34:33 --> Model Class Initialized
INFO - 2018-07-16 06:34:33 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:34:33 --> Model Class Initialized
INFO - 2018-07-16 06:34:33 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:34:33 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:34:33 --> Final output sent to browser
DEBUG - 2018-07-16 06:34:33 --> Total execution time: 0.0702
ERROR - 2018-07-16 06:36:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:36:49 --> Config Class Initialized
INFO - 2018-07-16 06:36:49 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:36:49 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:36:49 --> Utf8 Class Initialized
INFO - 2018-07-16 06:36:49 --> URI Class Initialized
INFO - 2018-07-16 06:36:49 --> Router Class Initialized
INFO - 2018-07-16 06:36:49 --> Output Class Initialized
INFO - 2018-07-16 06:36:49 --> Security Class Initialized
DEBUG - 2018-07-16 06:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:36:49 --> Input Class Initialized
INFO - 2018-07-16 06:36:49 --> Language Class Initialized
INFO - 2018-07-16 06:36:49 --> Loader Class Initialized
INFO - 2018-07-16 06:36:49 --> Controller Class Initialized
INFO - 2018-07-16 06:36:49 --> Database Driver Class Initialized
INFO - 2018-07-16 06:36:49 --> Model Class Initialized
INFO - 2018-07-16 06:36:49 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:36:49 --> Model Class Initialized
INFO - 2018-07-16 06:36:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:36:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:36:49 --> Final output sent to browser
DEBUG - 2018-07-16 06:36:49 --> Total execution time: 0.0521
ERROR - 2018-07-16 06:52:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:52:38 --> Config Class Initialized
INFO - 2018-07-16 06:52:38 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:52:38 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:52:38 --> Utf8 Class Initialized
INFO - 2018-07-16 06:52:38 --> URI Class Initialized
INFO - 2018-07-16 06:52:38 --> Router Class Initialized
INFO - 2018-07-16 06:52:38 --> Output Class Initialized
INFO - 2018-07-16 06:52:38 --> Security Class Initialized
DEBUG - 2018-07-16 06:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:52:38 --> Input Class Initialized
INFO - 2018-07-16 06:52:38 --> Language Class Initialized
INFO - 2018-07-16 06:52:38 --> Loader Class Initialized
INFO - 2018-07-16 06:52:38 --> Controller Class Initialized
INFO - 2018-07-16 06:52:38 --> Database Driver Class Initialized
INFO - 2018-07-16 06:52:38 --> Model Class Initialized
INFO - 2018-07-16 06:52:38 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:52:38 --> Model Class Initialized
INFO - 2018-07-16 06:52:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:52:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:52:38 --> Final output sent to browser
DEBUG - 2018-07-16 06:52:38 --> Total execution time: 0.0464
ERROR - 2018-07-16 06:53:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:53:58 --> Config Class Initialized
INFO - 2018-07-16 06:53:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:53:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:53:58 --> Utf8 Class Initialized
INFO - 2018-07-16 06:53:58 --> URI Class Initialized
INFO - 2018-07-16 06:53:58 --> Router Class Initialized
INFO - 2018-07-16 06:53:58 --> Output Class Initialized
INFO - 2018-07-16 06:53:58 --> Security Class Initialized
DEBUG - 2018-07-16 06:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:53:58 --> Input Class Initialized
INFO - 2018-07-16 06:53:58 --> Language Class Initialized
INFO - 2018-07-16 06:53:58 --> Loader Class Initialized
INFO - 2018-07-16 06:53:58 --> Controller Class Initialized
INFO - 2018-07-16 06:53:58 --> Database Driver Class Initialized
INFO - 2018-07-16 06:53:58 --> Model Class Initialized
INFO - 2018-07-16 06:53:58 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:53:58 --> Model Class Initialized
INFO - 2018-07-16 06:53:58 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:53:58 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:53:58 --> Final output sent to browser
DEBUG - 2018-07-16 06:53:58 --> Total execution time: 0.0532
ERROR - 2018-07-16 06:56:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:56:40 --> Config Class Initialized
INFO - 2018-07-16 06:56:40 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:56:40 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:56:40 --> Utf8 Class Initialized
INFO - 2018-07-16 06:56:40 --> URI Class Initialized
INFO - 2018-07-16 06:56:40 --> Router Class Initialized
INFO - 2018-07-16 06:56:40 --> Output Class Initialized
INFO - 2018-07-16 06:56:40 --> Security Class Initialized
DEBUG - 2018-07-16 06:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:56:40 --> Input Class Initialized
INFO - 2018-07-16 06:56:40 --> Language Class Initialized
INFO - 2018-07-16 06:56:40 --> Loader Class Initialized
INFO - 2018-07-16 06:56:40 --> Controller Class Initialized
INFO - 2018-07-16 06:56:40 --> Database Driver Class Initialized
INFO - 2018-07-16 06:56:40 --> Model Class Initialized
INFO - 2018-07-16 06:56:40 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:56:40 --> Model Class Initialized
INFO - 2018-07-16 06:56:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:56:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:56:40 --> Final output sent to browser
DEBUG - 2018-07-16 06:56:40 --> Total execution time: 0.0428
ERROR - 2018-07-16 06:58:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:58:35 --> Config Class Initialized
INFO - 2018-07-16 06:58:35 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:58:35 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:58:35 --> Utf8 Class Initialized
INFO - 2018-07-16 06:58:35 --> URI Class Initialized
INFO - 2018-07-16 06:58:35 --> Router Class Initialized
INFO - 2018-07-16 06:58:35 --> Output Class Initialized
INFO - 2018-07-16 06:58:35 --> Security Class Initialized
DEBUG - 2018-07-16 06:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:58:35 --> Input Class Initialized
INFO - 2018-07-16 06:58:35 --> Language Class Initialized
INFO - 2018-07-16 06:58:35 --> Loader Class Initialized
INFO - 2018-07-16 06:58:35 --> Controller Class Initialized
INFO - 2018-07-16 06:58:35 --> Database Driver Class Initialized
INFO - 2018-07-16 06:58:35 --> Model Class Initialized
INFO - 2018-07-16 06:58:35 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:58:35 --> Model Class Initialized
INFO - 2018-07-16 06:58:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:58:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:58:35 --> Final output sent to browser
DEBUG - 2018-07-16 06:58:35 --> Total execution time: 0.0685
ERROR - 2018-07-16 06:59:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 06:59:23 --> Config Class Initialized
INFO - 2018-07-16 06:59:23 --> Hooks Class Initialized
DEBUG - 2018-07-16 06:59:23 --> UTF-8 Support Enabled
INFO - 2018-07-16 06:59:23 --> Utf8 Class Initialized
INFO - 2018-07-16 06:59:23 --> URI Class Initialized
INFO - 2018-07-16 06:59:23 --> Router Class Initialized
INFO - 2018-07-16 06:59:23 --> Output Class Initialized
INFO - 2018-07-16 06:59:23 --> Security Class Initialized
DEBUG - 2018-07-16 06:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 06:59:23 --> Input Class Initialized
INFO - 2018-07-16 06:59:23 --> Language Class Initialized
INFO - 2018-07-16 06:59:23 --> Loader Class Initialized
INFO - 2018-07-16 06:59:23 --> Controller Class Initialized
INFO - 2018-07-16 06:59:23 --> Database Driver Class Initialized
INFO - 2018-07-16 06:59:23 --> Model Class Initialized
INFO - 2018-07-16 06:59:23 --> Helper loaded: url_helper
DEBUG - 2018-07-16 06:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 06:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 06:59:23 --> Model Class Initialized
INFO - 2018-07-16 06:59:23 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 06:59:23 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 06:59:23 --> Final output sent to browser
DEBUG - 2018-07-16 06:59:23 --> Total execution time: 0.0614
ERROR - 2018-07-16 07:00:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:00:27 --> Config Class Initialized
INFO - 2018-07-16 07:00:27 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:00:27 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:00:27 --> Utf8 Class Initialized
INFO - 2018-07-16 07:00:27 --> URI Class Initialized
INFO - 2018-07-16 07:00:27 --> Router Class Initialized
INFO - 2018-07-16 07:00:27 --> Output Class Initialized
INFO - 2018-07-16 07:00:27 --> Security Class Initialized
DEBUG - 2018-07-16 07:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:00:27 --> Input Class Initialized
INFO - 2018-07-16 07:00:27 --> Language Class Initialized
INFO - 2018-07-16 07:00:27 --> Loader Class Initialized
INFO - 2018-07-16 07:00:27 --> Controller Class Initialized
INFO - 2018-07-16 07:00:27 --> Database Driver Class Initialized
INFO - 2018-07-16 07:00:27 --> Model Class Initialized
INFO - 2018-07-16 07:00:27 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:00:27 --> Model Class Initialized
INFO - 2018-07-16 07:00:27 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:00:27 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 07:00:27 --> Final output sent to browser
DEBUG - 2018-07-16 07:00:27 --> Total execution time: 0.0780
ERROR - 2018-07-16 07:33:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:33:14 --> Config Class Initialized
INFO - 2018-07-16 07:33:14 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:33:14 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:33:14 --> Utf8 Class Initialized
INFO - 2018-07-16 07:33:14 --> URI Class Initialized
INFO - 2018-07-16 07:33:14 --> Router Class Initialized
INFO - 2018-07-16 07:33:14 --> Output Class Initialized
INFO - 2018-07-16 07:33:14 --> Security Class Initialized
DEBUG - 2018-07-16 07:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:33:14 --> Input Class Initialized
INFO - 2018-07-16 07:33:14 --> Language Class Initialized
INFO - 2018-07-16 07:33:14 --> Loader Class Initialized
INFO - 2018-07-16 07:33:14 --> Controller Class Initialized
INFO - 2018-07-16 07:33:14 --> Database Driver Class Initialized
INFO - 2018-07-16 07:33:14 --> Model Class Initialized
INFO - 2018-07-16 07:33:14 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:33:14 --> Model Class Initialized
INFO - 2018-07-16 07:33:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:33:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 07:33:14 --> Final output sent to browser
DEBUG - 2018-07-16 07:33:14 --> Total execution time: 0.0567
ERROR - 2018-07-16 07:36:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:36:12 --> Config Class Initialized
INFO - 2018-07-16 07:36:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:36:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:36:12 --> Utf8 Class Initialized
INFO - 2018-07-16 07:36:12 --> URI Class Initialized
INFO - 2018-07-16 07:36:12 --> Router Class Initialized
INFO - 2018-07-16 07:36:12 --> Output Class Initialized
INFO - 2018-07-16 07:36:12 --> Security Class Initialized
DEBUG - 2018-07-16 07:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:36:12 --> Input Class Initialized
INFO - 2018-07-16 07:36:12 --> Language Class Initialized
INFO - 2018-07-16 07:36:12 --> Loader Class Initialized
INFO - 2018-07-16 07:36:12 --> Controller Class Initialized
INFO - 2018-07-16 07:36:12 --> Database Driver Class Initialized
INFO - 2018-07-16 07:36:12 --> Model Class Initialized
INFO - 2018-07-16 07:36:12 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:36:12 --> Model Class Initialized
INFO - 2018-07-16 07:36:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:36:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 07:36:12 --> Final output sent to browser
DEBUG - 2018-07-16 07:36:12 --> Total execution time: 0.0817
ERROR - 2018-07-16 07:37:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:37:27 --> Config Class Initialized
INFO - 2018-07-16 07:37:27 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:37:27 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:37:27 --> Utf8 Class Initialized
INFO - 2018-07-16 07:37:27 --> URI Class Initialized
INFO - 2018-07-16 07:37:27 --> Router Class Initialized
INFO - 2018-07-16 07:37:27 --> Output Class Initialized
INFO - 2018-07-16 07:37:27 --> Security Class Initialized
DEBUG - 2018-07-16 07:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:37:27 --> Input Class Initialized
INFO - 2018-07-16 07:37:27 --> Language Class Initialized
INFO - 2018-07-16 07:37:27 --> Loader Class Initialized
INFO - 2018-07-16 07:37:27 --> Controller Class Initialized
INFO - 2018-07-16 07:37:27 --> Database Driver Class Initialized
ERROR - 2018-07-16 07:37:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Only one usage of each socket address (protocol/network address/port) is normally permitted.
 C:\xampp\htdocs\davidhood\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-07-16 07:37:27 --> Unable to connect to the database
INFO - 2018-07-16 07:37:27 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-16 07:37:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:37:44 --> Config Class Initialized
INFO - 2018-07-16 07:37:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:37:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:37:44 --> Utf8 Class Initialized
INFO - 2018-07-16 07:37:44 --> URI Class Initialized
INFO - 2018-07-16 07:37:44 --> Router Class Initialized
INFO - 2018-07-16 07:37:44 --> Output Class Initialized
INFO - 2018-07-16 07:37:44 --> Security Class Initialized
DEBUG - 2018-07-16 07:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:37:44 --> Input Class Initialized
INFO - 2018-07-16 07:37:44 --> Language Class Initialized
INFO - 2018-07-16 07:37:44 --> Loader Class Initialized
INFO - 2018-07-16 07:37:44 --> Controller Class Initialized
INFO - 2018-07-16 07:37:44 --> Database Driver Class Initialized
INFO - 2018-07-16 07:37:44 --> Model Class Initialized
INFO - 2018-07-16 07:37:44 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:37:44 --> Model Class Initialized
INFO - 2018-07-16 07:37:44 --> Final output sent to browser
DEBUG - 2018-07-16 07:37:44 --> Total execution time: 0.0631
ERROR - 2018-07-16 07:37:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:37:48 --> Config Class Initialized
INFO - 2018-07-16 07:37:48 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:37:48 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:37:48 --> Utf8 Class Initialized
INFO - 2018-07-16 07:37:48 --> URI Class Initialized
DEBUG - 2018-07-16 07:37:48 --> No URI present. Default controller set.
INFO - 2018-07-16 07:37:48 --> Router Class Initialized
INFO - 2018-07-16 07:37:48 --> Output Class Initialized
INFO - 2018-07-16 07:37:48 --> Security Class Initialized
DEBUG - 2018-07-16 07:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:37:48 --> Input Class Initialized
INFO - 2018-07-16 07:37:48 --> Language Class Initialized
INFO - 2018-07-16 07:37:48 --> Loader Class Initialized
INFO - 2018-07-16 07:37:48 --> Controller Class Initialized
INFO - 2018-07-16 07:37:48 --> Database Driver Class Initialized
INFO - 2018-07-16 07:37:48 --> Model Class Initialized
INFO - 2018-07-16 07:37:48 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:37:48 --> Model Class Initialized
INFO - 2018-07-16 07:37:48 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-16 07:37:48 --> Final output sent to browser
DEBUG - 2018-07-16 07:37:48 --> Total execution time: 0.0573
ERROR - 2018-07-16 07:37:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:37:49 --> Config Class Initialized
INFO - 2018-07-16 07:37:49 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:37:49 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:37:49 --> Utf8 Class Initialized
INFO - 2018-07-16 07:37:49 --> URI Class Initialized
INFO - 2018-07-16 07:37:49 --> Router Class Initialized
INFO - 2018-07-16 07:37:49 --> Output Class Initialized
INFO - 2018-07-16 07:37:49 --> Security Class Initialized
DEBUG - 2018-07-16 07:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:37:49 --> Input Class Initialized
INFO - 2018-07-16 07:37:49 --> Language Class Initialized
INFO - 2018-07-16 07:37:49 --> Loader Class Initialized
INFO - 2018-07-16 07:37:49 --> Controller Class Initialized
INFO - 2018-07-16 07:37:49 --> Database Driver Class Initialized
INFO - 2018-07-16 07:37:50 --> Model Class Initialized
INFO - 2018-07-16 07:37:50 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:37:50 --> Model Class Initialized
ERROR - 2018-07-16 07:37:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:37:50 --> Config Class Initialized
INFO - 2018-07-16 07:37:50 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:37:50 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:37:50 --> Utf8 Class Initialized
INFO - 2018-07-16 07:37:50 --> URI Class Initialized
INFO - 2018-07-16 07:37:50 --> Router Class Initialized
INFO - 2018-07-16 07:37:50 --> Output Class Initialized
INFO - 2018-07-16 07:37:50 --> Security Class Initialized
DEBUG - 2018-07-16 07:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:37:50 --> Input Class Initialized
INFO - 2018-07-16 07:37:50 --> Language Class Initialized
INFO - 2018-07-16 07:37:50 --> Loader Class Initialized
INFO - 2018-07-16 07:37:50 --> Controller Class Initialized
INFO - 2018-07-16 07:37:50 --> Database Driver Class Initialized
INFO - 2018-07-16 07:37:50 --> Model Class Initialized
INFO - 2018-07-16 07:37:50 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:37:50 --> Model Class Initialized
INFO - 2018-07-16 07:37:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:37:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 07:37:50 --> Final output sent to browser
DEBUG - 2018-07-16 07:37:50 --> Total execution time: 0.0491
ERROR - 2018-07-16 07:37:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:37:51 --> Config Class Initialized
INFO - 2018-07-16 07:37:51 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:37:51 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:37:51 --> Utf8 Class Initialized
INFO - 2018-07-16 07:37:51 --> URI Class Initialized
INFO - 2018-07-16 07:37:51 --> Router Class Initialized
INFO - 2018-07-16 07:37:51 --> Output Class Initialized
INFO - 2018-07-16 07:37:51 --> Security Class Initialized
DEBUG - 2018-07-16 07:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:37:51 --> Input Class Initialized
INFO - 2018-07-16 07:37:51 --> Language Class Initialized
INFO - 2018-07-16 07:37:51 --> Loader Class Initialized
INFO - 2018-07-16 07:37:51 --> Controller Class Initialized
INFO - 2018-07-16 07:37:51 --> Database Driver Class Initialized
INFO - 2018-07-16 07:37:51 --> Model Class Initialized
INFO - 2018-07-16 07:37:51 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:37:51 --> Model Class Initialized
INFO - 2018-07-16 07:37:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:37:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 07:37:51 --> Final output sent to browser
DEBUG - 2018-07-16 07:37:51 --> Total execution time: 0.0509
ERROR - 2018-07-16 07:38:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:38:21 --> Config Class Initialized
INFO - 2018-07-16 07:38:21 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:38:21 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:38:21 --> Utf8 Class Initialized
INFO - 2018-07-16 07:38:21 --> URI Class Initialized
INFO - 2018-07-16 07:38:21 --> Router Class Initialized
INFO - 2018-07-16 07:38:21 --> Output Class Initialized
INFO - 2018-07-16 07:38:21 --> Security Class Initialized
DEBUG - 2018-07-16 07:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:38:21 --> Input Class Initialized
INFO - 2018-07-16 07:38:21 --> Language Class Initialized
INFO - 2018-07-16 07:38:21 --> Loader Class Initialized
INFO - 2018-07-16 07:38:21 --> Controller Class Initialized
INFO - 2018-07-16 07:38:21 --> Database Driver Class Initialized
INFO - 2018-07-16 07:38:21 --> Model Class Initialized
INFO - 2018-07-16 07:38:21 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:38:21 --> Model Class Initialized
ERROR - 2018-07-16 07:38:21 --> Severity: Notice --> Undefined index: check0 C:\xampp\htdocs\davidhood\application\controllers\Main.php 52
ERROR - 2018-07-16 07:38:21 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\davidhood\system\database\DB_driver.php 1476
ERROR - 2018-07-16 07:38:21 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_advertise` (`title`, `price`, `url`, `description`, `lang`, `type`, `cnt`, `question`, `answer`, `created`) VALUES ('t', '0.1', 'https://drive.google.com/open?id=1e6pBBVZUzFh3GppFDnQivgVERlXtRAG6', 'test', 'french', 'once', 0, '', Array, 1531719501)
INFO - 2018-07-16 07:38:21 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-16 07:39:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:39:36 --> Config Class Initialized
INFO - 2018-07-16 07:39:36 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:39:36 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:39:36 --> Utf8 Class Initialized
INFO - 2018-07-16 07:39:36 --> URI Class Initialized
INFO - 2018-07-16 07:39:36 --> Router Class Initialized
INFO - 2018-07-16 07:39:36 --> Output Class Initialized
INFO - 2018-07-16 07:39:36 --> Security Class Initialized
DEBUG - 2018-07-16 07:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:39:36 --> Input Class Initialized
INFO - 2018-07-16 07:39:36 --> Language Class Initialized
INFO - 2018-07-16 07:39:36 --> Loader Class Initialized
INFO - 2018-07-16 07:39:36 --> Controller Class Initialized
INFO - 2018-07-16 07:39:36 --> Database Driver Class Initialized
INFO - 2018-07-16 07:39:36 --> Model Class Initialized
INFO - 2018-07-16 07:39:36 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:39:36 --> Model Class Initialized
ERROR - 2018-07-16 07:39:36 --> Severity: Notice --> Undefined index: check0 C:\xampp\htdocs\davidhood\application\controllers\Main.php 52
ERROR - 2018-07-16 07:39:36 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\davidhood\system\database\DB_driver.php 1476
ERROR - 2018-07-16 07:39:36 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_advertise` (`title`, `price`, `url`, `description`, `lang`, `type`, `cnt`, `question`, `answer`, `created`) VALUES ('t', '0.1', 'https://drive.google.com/open?id=1e6pBBVZUzFh3GppFDnQivgVERlXtRAG6', 'test', 'french', 'once', 0, '', Array, 1531719576)
INFO - 2018-07-16 07:39:36 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-16 07:39:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:39:38 --> Config Class Initialized
INFO - 2018-07-16 07:39:38 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:39:38 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:39:38 --> Utf8 Class Initialized
INFO - 2018-07-16 07:39:38 --> URI Class Initialized
INFO - 2018-07-16 07:39:38 --> Router Class Initialized
INFO - 2018-07-16 07:39:38 --> Output Class Initialized
INFO - 2018-07-16 07:39:38 --> Security Class Initialized
DEBUG - 2018-07-16 07:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:39:38 --> Input Class Initialized
INFO - 2018-07-16 07:39:38 --> Language Class Initialized
INFO - 2018-07-16 07:39:38 --> Loader Class Initialized
INFO - 2018-07-16 07:39:38 --> Controller Class Initialized
INFO - 2018-07-16 07:39:38 --> Database Driver Class Initialized
INFO - 2018-07-16 07:39:38 --> Model Class Initialized
INFO - 2018-07-16 07:39:38 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:39:38 --> Model Class Initialized
ERROR - 2018-07-16 07:39:38 --> Severity: Notice --> Undefined index: check0 C:\xampp\htdocs\davidhood\application\controllers\Main.php 52
ERROR - 2018-07-16 07:39:38 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\davidhood\system\database\DB_driver.php 1476
ERROR - 2018-07-16 07:39:38 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_advertise` (`title`, `price`, `url`, `description`, `lang`, `type`, `cnt`, `question`, `answer`, `created`) VALUES ('t', '0.1', 'https://drive.google.com/open?id=1e6pBBVZUzFh3GppFDnQivgVERlXtRAG6', 'test', 'french', 'once', 0, '', Array, 1531719578)
INFO - 2018-07-16 07:39:38 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-16 07:40:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:40:00 --> Config Class Initialized
INFO - 2018-07-16 07:40:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:40:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:40:00 --> Utf8 Class Initialized
INFO - 2018-07-16 07:40:00 --> URI Class Initialized
INFO - 2018-07-16 07:40:00 --> Router Class Initialized
INFO - 2018-07-16 07:40:00 --> Output Class Initialized
INFO - 2018-07-16 07:40:00 --> Security Class Initialized
DEBUG - 2018-07-16 07:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:40:00 --> Input Class Initialized
INFO - 2018-07-16 07:40:00 --> Language Class Initialized
INFO - 2018-07-16 07:40:00 --> Loader Class Initialized
INFO - 2018-07-16 07:40:00 --> Controller Class Initialized
INFO - 2018-07-16 07:40:00 --> Database Driver Class Initialized
INFO - 2018-07-16 07:40:00 --> Model Class Initialized
INFO - 2018-07-16 07:40:00 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:40:00 --> Model Class Initialized
ERROR - 2018-07-16 07:40:00 --> Severity: Notice --> Undefined index: check0 C:\xampp\htdocs\davidhood\application\controllers\Main.php 52
ERROR - 2018-07-16 07:40:00 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\davidhood\system\database\DB_driver.php 1476
ERROR - 2018-07-16 07:40:00 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_advertise` (`title`, `price`, `url`, `description`, `lang`, `type`, `cnt`, `question`, `answer`, `created`) VALUES ('t', '0.1', 'https://drive.google.com/open?id=1e6pBBVZUzFh3GppFDnQivgVERlXtRAG6', 'test', 'french', 'once', 0, '', Array, 1531719600)
INFO - 2018-07-16 07:40:00 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-16 07:41:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:41:13 --> Config Class Initialized
INFO - 2018-07-16 07:41:13 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:41:13 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:41:13 --> Utf8 Class Initialized
INFO - 2018-07-16 07:41:13 --> URI Class Initialized
INFO - 2018-07-16 07:41:13 --> Router Class Initialized
INFO - 2018-07-16 07:41:13 --> Output Class Initialized
INFO - 2018-07-16 07:41:13 --> Security Class Initialized
DEBUG - 2018-07-16 07:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:41:13 --> Input Class Initialized
INFO - 2018-07-16 07:41:13 --> Language Class Initialized
INFO - 2018-07-16 07:41:13 --> Loader Class Initialized
INFO - 2018-07-16 07:41:13 --> Controller Class Initialized
INFO - 2018-07-16 07:41:13 --> Database Driver Class Initialized
INFO - 2018-07-16 07:41:13 --> Model Class Initialized
INFO - 2018-07-16 07:41:13 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:41:13 --> Model Class Initialized
ERROR - 2018-07-16 07:41:13 --> Severity: Notice --> Undefined index: check0 C:\xampp\htdocs\davidhood\application\controllers\Main.php 52
ERROR - 2018-07-16 07:41:13 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\davidhood\system\database\DB_driver.php 1476
ERROR - 2018-07-16 07:41:13 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_advertise` (`title`, `price`, `url`, `description`, `lang`, `type`, `cnt`, `question`, `answer`, `created`) VALUES ('t', '0.1', 'https://drive.google.com/open?id=1e6pBBVZUzFh3GppFDnQivgVERlXtRAG6', 'test', 'french', 'once', 0, '', Array, 1531719673)
INFO - 2018-07-16 07:41:13 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-16 07:41:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:41:16 --> Config Class Initialized
INFO - 2018-07-16 07:41:16 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:41:16 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:41:16 --> Utf8 Class Initialized
INFO - 2018-07-16 07:41:16 --> URI Class Initialized
INFO - 2018-07-16 07:41:16 --> Router Class Initialized
INFO - 2018-07-16 07:41:16 --> Output Class Initialized
INFO - 2018-07-16 07:41:16 --> Security Class Initialized
DEBUG - 2018-07-16 07:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:41:16 --> Input Class Initialized
INFO - 2018-07-16 07:41:16 --> Language Class Initialized
INFO - 2018-07-16 07:41:16 --> Loader Class Initialized
INFO - 2018-07-16 07:41:16 --> Controller Class Initialized
INFO - 2018-07-16 07:41:16 --> Database Driver Class Initialized
INFO - 2018-07-16 07:41:16 --> Model Class Initialized
INFO - 2018-07-16 07:41:16 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:41:16 --> Model Class Initialized
ERROR - 2018-07-16 07:41:16 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\davidhood\application\controllers\Main.php 37
ERROR - 2018-07-16 07:41:16 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\davidhood\application\controllers\Main.php 38
ERROR - 2018-07-16 07:41:16 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\davidhood\application\controllers\Main.php 39
ERROR - 2018-07-16 07:41:16 --> Severity: Notice --> Undefined index: url C:\xampp\htdocs\davidhood\application\controllers\Main.php 40
ERROR - 2018-07-16 07:41:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\davidhood\application\controllers\Main.php 41
ERROR - 2018-07-16 07:41:16 --> Severity: Notice --> Undefined index: lang C:\xampp\htdocs\davidhood\application\controllers\Main.php 46
ERROR - 2018-07-16 07:41:16 --> Severity: Notice --> Undefined index: question C:\xampp\htdocs\davidhood\application\controllers\Main.php 47
INFO - 2018-07-16 07:41:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:41:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 07:41:16 --> Final output sent to browser
DEBUG - 2018-07-16 07:41:16 --> Total execution time: 0.0661
ERROR - 2018-07-16 07:41:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:41:23 --> Config Class Initialized
INFO - 2018-07-16 07:41:23 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:41:23 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:41:23 --> Utf8 Class Initialized
INFO - 2018-07-16 07:41:23 --> URI Class Initialized
DEBUG - 2018-07-16 07:41:23 --> No URI present. Default controller set.
INFO - 2018-07-16 07:41:23 --> Router Class Initialized
INFO - 2018-07-16 07:41:23 --> Output Class Initialized
INFO - 2018-07-16 07:41:23 --> Security Class Initialized
DEBUG - 2018-07-16 07:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:41:23 --> Input Class Initialized
INFO - 2018-07-16 07:41:23 --> Language Class Initialized
INFO - 2018-07-16 07:41:23 --> Loader Class Initialized
INFO - 2018-07-16 07:41:23 --> Controller Class Initialized
INFO - 2018-07-16 07:41:23 --> Database Driver Class Initialized
INFO - 2018-07-16 07:41:23 --> Model Class Initialized
INFO - 2018-07-16 07:41:23 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:41:23 --> Model Class Initialized
INFO - 2018-07-16 07:41:23 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-16 07:41:23 --> Final output sent to browser
DEBUG - 2018-07-16 07:41:23 --> Total execution time: 0.0414
ERROR - 2018-07-16 07:41:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:41:24 --> Config Class Initialized
INFO - 2018-07-16 07:41:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:41:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:41:24 --> Utf8 Class Initialized
INFO - 2018-07-16 07:41:24 --> URI Class Initialized
INFO - 2018-07-16 07:41:24 --> Router Class Initialized
INFO - 2018-07-16 07:41:24 --> Output Class Initialized
INFO - 2018-07-16 07:41:24 --> Security Class Initialized
DEBUG - 2018-07-16 07:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:41:24 --> Input Class Initialized
INFO - 2018-07-16 07:41:24 --> Language Class Initialized
INFO - 2018-07-16 07:41:24 --> Loader Class Initialized
INFO - 2018-07-16 07:41:24 --> Controller Class Initialized
INFO - 2018-07-16 07:41:24 --> Database Driver Class Initialized
INFO - 2018-07-16 07:41:24 --> Model Class Initialized
INFO - 2018-07-16 07:41:24 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:41:24 --> Model Class Initialized
ERROR - 2018-07-16 07:41:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:41:24 --> Config Class Initialized
INFO - 2018-07-16 07:41:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:41:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:41:24 --> Utf8 Class Initialized
INFO - 2018-07-16 07:41:24 --> URI Class Initialized
INFO - 2018-07-16 07:41:24 --> Router Class Initialized
INFO - 2018-07-16 07:41:24 --> Output Class Initialized
INFO - 2018-07-16 07:41:24 --> Security Class Initialized
DEBUG - 2018-07-16 07:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:41:24 --> Input Class Initialized
INFO - 2018-07-16 07:41:24 --> Language Class Initialized
INFO - 2018-07-16 07:41:24 --> Loader Class Initialized
INFO - 2018-07-16 07:41:24 --> Controller Class Initialized
INFO - 2018-07-16 07:41:24 --> Database Driver Class Initialized
INFO - 2018-07-16 07:41:24 --> Model Class Initialized
INFO - 2018-07-16 07:41:24 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:41:24 --> Model Class Initialized
INFO - 2018-07-16 07:41:24 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:41:24 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 07:41:24 --> Final output sent to browser
DEBUG - 2018-07-16 07:41:24 --> Total execution time: 0.0482
ERROR - 2018-07-16 07:41:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:41:31 --> Config Class Initialized
INFO - 2018-07-16 07:41:31 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:41:31 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:41:31 --> Utf8 Class Initialized
INFO - 2018-07-16 07:41:31 --> URI Class Initialized
INFO - 2018-07-16 07:41:31 --> Router Class Initialized
INFO - 2018-07-16 07:41:31 --> Output Class Initialized
INFO - 2018-07-16 07:41:31 --> Security Class Initialized
DEBUG - 2018-07-16 07:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:41:31 --> Input Class Initialized
INFO - 2018-07-16 07:41:31 --> Language Class Initialized
INFO - 2018-07-16 07:41:31 --> Loader Class Initialized
INFO - 2018-07-16 07:41:31 --> Controller Class Initialized
INFO - 2018-07-16 07:41:31 --> Database Driver Class Initialized
INFO - 2018-07-16 07:41:31 --> Model Class Initialized
INFO - 2018-07-16 07:41:31 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:41:31 --> Model Class Initialized
INFO - 2018-07-16 07:41:31 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:41:31 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 07:41:31 --> Final output sent to browser
DEBUG - 2018-07-16 07:41:31 --> Total execution time: 0.0555
ERROR - 2018-07-16 07:42:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:42:12 --> Config Class Initialized
INFO - 2018-07-16 07:42:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:42:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:42:12 --> Utf8 Class Initialized
INFO - 2018-07-16 07:42:12 --> URI Class Initialized
INFO - 2018-07-16 07:42:12 --> Router Class Initialized
INFO - 2018-07-16 07:42:12 --> Output Class Initialized
INFO - 2018-07-16 07:42:12 --> Security Class Initialized
DEBUG - 2018-07-16 07:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:42:12 --> Input Class Initialized
INFO - 2018-07-16 07:42:12 --> Language Class Initialized
INFO - 2018-07-16 07:42:12 --> Loader Class Initialized
INFO - 2018-07-16 07:42:12 --> Controller Class Initialized
INFO - 2018-07-16 07:42:12 --> Database Driver Class Initialized
INFO - 2018-07-16 07:42:12 --> Model Class Initialized
INFO - 2018-07-16 07:42:12 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:42:12 --> Model Class Initialized
ERROR - 2018-07-16 07:42:12 --> Severity: Notice --> Undefined index: check0 C:\xampp\htdocs\davidhood\application\controllers\Main.php 52
ERROR - 2018-07-16 07:42:12 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\davidhood\system\database\DB_driver.php 1476
ERROR - 2018-07-16 07:42:12 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_advertise` (`title`, `price`, `url`, `description`, `lang`, `type`, `cnt`, `question`, `answer`, `created`) VALUES ('t', '0.2', 'https://drive.google.com/open?id=1e6pBBVZUzFh3GppFDnQivgVERlXtRAG6', 'sdf', 'french', 'once', 0, '', Array, 1531719732)
INFO - 2018-07-16 07:42:12 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-16 07:43:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:43:10 --> Config Class Initialized
INFO - 2018-07-16 07:43:10 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:43:10 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:43:10 --> Utf8 Class Initialized
INFO - 2018-07-16 07:43:10 --> URI Class Initialized
INFO - 2018-07-16 07:43:10 --> Router Class Initialized
INFO - 2018-07-16 07:43:10 --> Output Class Initialized
INFO - 2018-07-16 07:43:10 --> Security Class Initialized
DEBUG - 2018-07-16 07:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:43:10 --> Input Class Initialized
INFO - 2018-07-16 07:43:10 --> Language Class Initialized
INFO - 2018-07-16 07:43:10 --> Loader Class Initialized
INFO - 2018-07-16 07:43:10 --> Controller Class Initialized
INFO - 2018-07-16 07:43:10 --> Database Driver Class Initialized
INFO - 2018-07-16 07:43:10 --> Model Class Initialized
INFO - 2018-07-16 07:43:10 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:43:10 --> Model Class Initialized
INFO - 2018-07-16 07:43:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:43:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 07:43:10 --> Final output sent to browser
DEBUG - 2018-07-16 07:43:10 --> Total execution time: 0.0462
ERROR - 2018-07-16 07:45:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:45:54 --> Config Class Initialized
INFO - 2018-07-16 07:45:54 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:45:54 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:45:54 --> Utf8 Class Initialized
INFO - 2018-07-16 07:45:54 --> URI Class Initialized
INFO - 2018-07-16 07:45:54 --> Router Class Initialized
INFO - 2018-07-16 07:45:54 --> Output Class Initialized
INFO - 2018-07-16 07:45:54 --> Security Class Initialized
DEBUG - 2018-07-16 07:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:45:54 --> Input Class Initialized
INFO - 2018-07-16 07:45:54 --> Language Class Initialized
INFO - 2018-07-16 07:45:54 --> Loader Class Initialized
INFO - 2018-07-16 07:45:54 --> Controller Class Initialized
INFO - 2018-07-16 07:45:54 --> Database Driver Class Initialized
INFO - 2018-07-16 07:45:54 --> Model Class Initialized
INFO - 2018-07-16 07:45:54 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:45:54 --> Model Class Initialized
INFO - 2018-07-16 07:45:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:45:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 07:45:54 --> Final output sent to browser
DEBUG - 2018-07-16 07:45:54 --> Total execution time: 0.0654
ERROR - 2018-07-16 07:46:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:46:36 --> Config Class Initialized
INFO - 2018-07-16 07:46:36 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:46:36 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:46:36 --> Utf8 Class Initialized
INFO - 2018-07-16 07:46:36 --> URI Class Initialized
INFO - 2018-07-16 07:46:36 --> Router Class Initialized
INFO - 2018-07-16 07:46:36 --> Output Class Initialized
INFO - 2018-07-16 07:46:36 --> Security Class Initialized
DEBUG - 2018-07-16 07:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:46:36 --> Input Class Initialized
INFO - 2018-07-16 07:46:36 --> Language Class Initialized
INFO - 2018-07-16 07:46:36 --> Loader Class Initialized
INFO - 2018-07-16 07:46:36 --> Controller Class Initialized
INFO - 2018-07-16 07:46:36 --> Database Driver Class Initialized
INFO - 2018-07-16 07:46:36 --> Model Class Initialized
INFO - 2018-07-16 07:46:36 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:46:36 --> Model Class Initialized
ERROR - 2018-07-16 07:46:36 --> Severity: Notice --> Undefined index: check0 C:\xampp\htdocs\davidhood\application\controllers\Main.php 52
ERROR - 2018-07-16 07:46:36 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\davidhood\system\database\DB_driver.php 1476
ERROR - 2018-07-16 07:46:36 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_advertise` (`title`, `price`, `url`, `description`, `lang`, `type`, `cnt`, `question`, `answer`, `created`) VALUES ('sdf', '0.1', 'https://drive.google.com/open?id=1e6pBBVZUzFh3GppFDnQivgVERlXtRAG6', 'sdf', 'french', 'once', 0, '', Array, 1531719996)
INFO - 2018-07-16 07:46:36 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-16 07:46:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:46:52 --> Config Class Initialized
INFO - 2018-07-16 07:46:52 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:46:52 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:46:52 --> Utf8 Class Initialized
INFO - 2018-07-16 07:46:52 --> URI Class Initialized
INFO - 2018-07-16 07:46:52 --> Router Class Initialized
INFO - 2018-07-16 07:46:52 --> Output Class Initialized
INFO - 2018-07-16 07:46:52 --> Security Class Initialized
DEBUG - 2018-07-16 07:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:46:52 --> Input Class Initialized
INFO - 2018-07-16 07:46:52 --> Language Class Initialized
INFO - 2018-07-16 07:46:52 --> Loader Class Initialized
INFO - 2018-07-16 07:46:52 --> Controller Class Initialized
INFO - 2018-07-16 07:46:52 --> Database Driver Class Initialized
INFO - 2018-07-16 07:46:52 --> Model Class Initialized
INFO - 2018-07-16 07:46:52 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:46:52 --> Model Class Initialized
INFO - 2018-07-16 07:46:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:46:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 07:46:52 --> Final output sent to browser
DEBUG - 2018-07-16 07:46:52 --> Total execution time: 0.0689
ERROR - 2018-07-16 07:46:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:46:59 --> Config Class Initialized
INFO - 2018-07-16 07:46:59 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:46:59 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:46:59 --> Utf8 Class Initialized
INFO - 2018-07-16 07:46:59 --> URI Class Initialized
INFO - 2018-07-16 07:46:59 --> Router Class Initialized
INFO - 2018-07-16 07:46:59 --> Output Class Initialized
INFO - 2018-07-16 07:46:59 --> Security Class Initialized
DEBUG - 2018-07-16 07:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:46:59 --> Input Class Initialized
INFO - 2018-07-16 07:46:59 --> Language Class Initialized
INFO - 2018-07-16 07:46:59 --> Loader Class Initialized
INFO - 2018-07-16 07:46:59 --> Controller Class Initialized
INFO - 2018-07-16 07:46:59 --> Database Driver Class Initialized
INFO - 2018-07-16 07:46:59 --> Model Class Initialized
INFO - 2018-07-16 07:46:59 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:46:59 --> Model Class Initialized
ERROR - 2018-07-16 07:46:59 --> Severity: Notice --> Undefined index: check0 C:\xampp\htdocs\davidhood\application\controllers\Main.php 52
ERROR - 2018-07-16 07:46:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\davidhood\system\database\DB_driver.php 1476
ERROR - 2018-07-16 07:46:59 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_advertise` (`title`, `price`, `url`, `description`, `lang`, `type`, `cnt`, `question`, `answer`, `created`) VALUES ('sdf', '0.1', 'https://drive.google.com/open?id=1e6pBBVZUzFh3GppFDnQivgVERlXtRAG6', 'sdf', 'french', 'once', 0, '', Array, 1531720019)
INFO - 2018-07-16 07:46:59 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-16 07:47:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:47:15 --> Config Class Initialized
INFO - 2018-07-16 07:47:15 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:47:15 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:47:15 --> Utf8 Class Initialized
INFO - 2018-07-16 07:47:15 --> URI Class Initialized
INFO - 2018-07-16 07:47:15 --> Router Class Initialized
INFO - 2018-07-16 07:47:15 --> Output Class Initialized
INFO - 2018-07-16 07:47:15 --> Security Class Initialized
DEBUG - 2018-07-16 07:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:47:15 --> Input Class Initialized
INFO - 2018-07-16 07:47:15 --> Language Class Initialized
INFO - 2018-07-16 07:47:15 --> Loader Class Initialized
INFO - 2018-07-16 07:47:15 --> Controller Class Initialized
INFO - 2018-07-16 07:47:15 --> Database Driver Class Initialized
INFO - 2018-07-16 07:47:15 --> Model Class Initialized
INFO - 2018-07-16 07:47:15 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:47:15 --> Model Class Initialized
INFO - 2018-07-16 07:47:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:47:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 07:47:15 --> Final output sent to browser
DEBUG - 2018-07-16 07:47:15 --> Total execution time: 0.0672
ERROR - 2018-07-16 07:47:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:47:17 --> Config Class Initialized
INFO - 2018-07-16 07:47:17 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:47:17 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:47:17 --> Utf8 Class Initialized
INFO - 2018-07-16 07:47:17 --> URI Class Initialized
INFO - 2018-07-16 07:47:17 --> Router Class Initialized
INFO - 2018-07-16 07:47:17 --> Output Class Initialized
INFO - 2018-07-16 07:47:17 --> Security Class Initialized
DEBUG - 2018-07-16 07:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:47:17 --> Input Class Initialized
INFO - 2018-07-16 07:47:17 --> Language Class Initialized
INFO - 2018-07-16 07:47:17 --> Loader Class Initialized
INFO - 2018-07-16 07:47:17 --> Controller Class Initialized
INFO - 2018-07-16 07:47:17 --> Database Driver Class Initialized
INFO - 2018-07-16 07:47:17 --> Model Class Initialized
INFO - 2018-07-16 07:47:17 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:47:17 --> Model Class Initialized
ERROR - 2018-07-16 07:47:17 --> Severity: Notice --> Undefined index: check0 C:\xampp\htdocs\davidhood\application\controllers\Main.php 52
ERROR - 2018-07-16 07:47:17 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\davidhood\system\database\DB_driver.php 1476
ERROR - 2018-07-16 07:47:17 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_advertise` (`title`, `price`, `url`, `description`, `lang`, `type`, `cnt`, `question`, `answer`, `created`) VALUES ('sdf', '0.1', 'https://drive.google.com/open?id=1e6pBBVZUzFh3GppFDnQivgVERlXtRAG6', 'sdf', 'french', 'once', 0, '', Array, 1531720037)
INFO - 2018-07-16 07:47:17 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-16 07:47:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:47:20 --> Config Class Initialized
INFO - 2018-07-16 07:47:20 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:47:20 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:47:20 --> Utf8 Class Initialized
INFO - 2018-07-16 07:47:20 --> URI Class Initialized
INFO - 2018-07-16 07:47:20 --> Router Class Initialized
INFO - 2018-07-16 07:47:20 --> Output Class Initialized
INFO - 2018-07-16 07:47:20 --> Security Class Initialized
DEBUG - 2018-07-16 07:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:47:20 --> Input Class Initialized
INFO - 2018-07-16 07:47:20 --> Language Class Initialized
INFO - 2018-07-16 07:47:20 --> Loader Class Initialized
INFO - 2018-07-16 07:47:20 --> Controller Class Initialized
INFO - 2018-07-16 07:47:20 --> Database Driver Class Initialized
INFO - 2018-07-16 07:47:20 --> Model Class Initialized
INFO - 2018-07-16 07:47:20 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:47:20 --> Model Class Initialized
INFO - 2018-07-16 07:47:20 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:47:20 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 07:47:20 --> Final output sent to browser
DEBUG - 2018-07-16 07:47:20 --> Total execution time: 0.0473
ERROR - 2018-07-16 07:47:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:47:22 --> Config Class Initialized
INFO - 2018-07-16 07:47:22 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:47:23 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:47:23 --> Utf8 Class Initialized
INFO - 2018-07-16 07:47:23 --> URI Class Initialized
INFO - 2018-07-16 07:47:23 --> Router Class Initialized
INFO - 2018-07-16 07:47:23 --> Output Class Initialized
INFO - 2018-07-16 07:47:23 --> Security Class Initialized
DEBUG - 2018-07-16 07:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:47:23 --> Input Class Initialized
INFO - 2018-07-16 07:47:23 --> Language Class Initialized
INFO - 2018-07-16 07:47:23 --> Loader Class Initialized
INFO - 2018-07-16 07:47:23 --> Controller Class Initialized
INFO - 2018-07-16 07:47:23 --> Database Driver Class Initialized
INFO - 2018-07-16 07:47:23 --> Model Class Initialized
INFO - 2018-07-16 07:47:23 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:47:23 --> Model Class Initialized
ERROR - 2018-07-16 07:47:23 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\davidhood\system\database\DB_driver.php 1476
ERROR - 2018-07-16 07:47:23 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_advertise` (`title`, `price`, `url`, `description`, `lang`, `type`, `cnt`, `question`, `answer`, `created`) VALUES ('sdf', '0.1', 'https://drive.google.com/open?id=1e6pBBVZUzFh3GppFDnQivgVERlXtRAG6', 'sdf', 'french', 'once', 0, '', Array, 1531720043)
INFO - 2018-07-16 07:47:23 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-16 07:50:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:50:41 --> Config Class Initialized
INFO - 2018-07-16 07:50:41 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:50:41 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:50:41 --> Utf8 Class Initialized
INFO - 2018-07-16 07:50:41 --> URI Class Initialized
INFO - 2018-07-16 07:50:41 --> Router Class Initialized
INFO - 2018-07-16 07:50:41 --> Output Class Initialized
INFO - 2018-07-16 07:50:41 --> Security Class Initialized
DEBUG - 2018-07-16 07:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:50:41 --> Input Class Initialized
INFO - 2018-07-16 07:50:41 --> Language Class Initialized
INFO - 2018-07-16 07:50:41 --> Loader Class Initialized
INFO - 2018-07-16 07:50:41 --> Controller Class Initialized
INFO - 2018-07-16 07:50:41 --> Database Driver Class Initialized
INFO - 2018-07-16 07:50:41 --> Model Class Initialized
INFO - 2018-07-16 07:50:41 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:50:41 --> Model Class Initialized
INFO - 2018-07-16 07:50:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:50:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 07:50:41 --> Final output sent to browser
DEBUG - 2018-07-16 07:50:41 --> Total execution time: 0.0654
ERROR - 2018-07-16 07:50:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:50:50 --> Config Class Initialized
INFO - 2018-07-16 07:50:50 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:50:50 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:50:50 --> Utf8 Class Initialized
INFO - 2018-07-16 07:50:50 --> URI Class Initialized
INFO - 2018-07-16 07:50:50 --> Router Class Initialized
INFO - 2018-07-16 07:50:50 --> Output Class Initialized
INFO - 2018-07-16 07:50:50 --> Security Class Initialized
DEBUG - 2018-07-16 07:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:50:50 --> Input Class Initialized
INFO - 2018-07-16 07:50:50 --> Language Class Initialized
INFO - 2018-07-16 07:50:50 --> Loader Class Initialized
INFO - 2018-07-16 07:50:50 --> Controller Class Initialized
INFO - 2018-07-16 07:50:50 --> Database Driver Class Initialized
INFO - 2018-07-16 07:50:50 --> Model Class Initialized
INFO - 2018-07-16 07:50:50 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:50:50 --> Model Class Initialized
ERROR - 2018-07-16 07:50:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\davidhood\system\database\DB_driver.php 1476
ERROR - 2018-07-16 07:50:50 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_advertise` (`title`, `price`, `url`, `description`, `lang`, `type`, `cnt`, `question`, `answer`, `created`) VALUES ('sdf', '0.1', 'https://drive.google.com/open?id=1e6pBBVZUzFh3GppFDnQivgVERlXtRAG6', 'sdf', 'french', 'once', 0, '', Array, 1531720250)
INFO - 2018-07-16 07:50:50 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-16 07:51:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:51:57 --> Config Class Initialized
INFO - 2018-07-16 07:51:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:51:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:51:57 --> Utf8 Class Initialized
INFO - 2018-07-16 07:51:57 --> URI Class Initialized
INFO - 2018-07-16 07:51:57 --> Router Class Initialized
INFO - 2018-07-16 07:51:57 --> Output Class Initialized
INFO - 2018-07-16 07:51:57 --> Security Class Initialized
DEBUG - 2018-07-16 07:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:51:57 --> Input Class Initialized
INFO - 2018-07-16 07:51:57 --> Language Class Initialized
INFO - 2018-07-16 07:51:57 --> Loader Class Initialized
INFO - 2018-07-16 07:51:57 --> Controller Class Initialized
INFO - 2018-07-16 07:51:57 --> Database Driver Class Initialized
INFO - 2018-07-16 07:51:57 --> Model Class Initialized
INFO - 2018-07-16 07:51:57 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:51:57 --> Model Class Initialized
INFO - 2018-07-16 07:51:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:51:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 07:51:57 --> Final output sent to browser
DEBUG - 2018-07-16 07:51:57 --> Total execution time: 0.0648
ERROR - 2018-07-16 07:52:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:52:02 --> Config Class Initialized
INFO - 2018-07-16 07:52:02 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:52:02 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:52:02 --> Utf8 Class Initialized
INFO - 2018-07-16 07:52:02 --> URI Class Initialized
INFO - 2018-07-16 07:52:02 --> Router Class Initialized
INFO - 2018-07-16 07:52:02 --> Output Class Initialized
INFO - 2018-07-16 07:52:02 --> Security Class Initialized
DEBUG - 2018-07-16 07:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:52:02 --> Input Class Initialized
INFO - 2018-07-16 07:52:02 --> Language Class Initialized
INFO - 2018-07-16 07:52:02 --> Loader Class Initialized
INFO - 2018-07-16 07:52:02 --> Controller Class Initialized
INFO - 2018-07-16 07:52:02 --> Database Driver Class Initialized
INFO - 2018-07-16 07:52:02 --> Model Class Initialized
INFO - 2018-07-16 07:52:02 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:52:02 --> Model Class Initialized
INFO - 2018-07-16 07:52:02 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:52:02 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 07:52:02 --> Final output sent to browser
DEBUG - 2018-07-16 07:52:02 --> Total execution time: 0.0476
ERROR - 2018-07-16 07:54:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:54:37 --> Config Class Initialized
INFO - 2018-07-16 07:54:37 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:54:37 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:54:37 --> Utf8 Class Initialized
INFO - 2018-07-16 07:54:37 --> URI Class Initialized
INFO - 2018-07-16 07:54:37 --> Router Class Initialized
INFO - 2018-07-16 07:54:37 --> Output Class Initialized
INFO - 2018-07-16 07:54:37 --> Security Class Initialized
DEBUG - 2018-07-16 07:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:54:37 --> Input Class Initialized
INFO - 2018-07-16 07:54:37 --> Language Class Initialized
INFO - 2018-07-16 07:54:37 --> Loader Class Initialized
INFO - 2018-07-16 07:54:37 --> Controller Class Initialized
INFO - 2018-07-16 07:54:37 --> Database Driver Class Initialized
INFO - 2018-07-16 07:54:37 --> Model Class Initialized
INFO - 2018-07-16 07:54:37 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:54:37 --> Model Class Initialized
ERROR - 2018-07-16 07:54:37 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\davidhood\application\controllers\Main.php 75
INFO - 2018-07-16 07:54:37 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:54:37 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 07:54:37 --> Final output sent to browser
DEBUG - 2018-07-16 07:54:37 --> Total execution time: 0.0546
ERROR - 2018-07-16 07:55:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:55:33 --> Config Class Initialized
INFO - 2018-07-16 07:55:33 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:55:33 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:55:33 --> Utf8 Class Initialized
INFO - 2018-07-16 07:55:33 --> URI Class Initialized
INFO - 2018-07-16 07:55:33 --> Router Class Initialized
INFO - 2018-07-16 07:55:33 --> Output Class Initialized
INFO - 2018-07-16 07:55:33 --> Security Class Initialized
DEBUG - 2018-07-16 07:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:55:33 --> Input Class Initialized
INFO - 2018-07-16 07:55:33 --> Language Class Initialized
INFO - 2018-07-16 07:55:33 --> Loader Class Initialized
INFO - 2018-07-16 07:55:33 --> Controller Class Initialized
INFO - 2018-07-16 07:55:33 --> Database Driver Class Initialized
INFO - 2018-07-16 07:55:33 --> Model Class Initialized
INFO - 2018-07-16 07:55:33 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:55:33 --> Model Class Initialized
INFO - 2018-07-16 07:55:33 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:55:33 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 07:55:33 --> Final output sent to browser
DEBUG - 2018-07-16 07:55:33 --> Total execution time: 0.0607
ERROR - 2018-07-16 07:55:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:55:53 --> Config Class Initialized
INFO - 2018-07-16 07:55:53 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:55:53 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:55:53 --> Utf8 Class Initialized
INFO - 2018-07-16 07:55:53 --> URI Class Initialized
INFO - 2018-07-16 07:55:53 --> Router Class Initialized
INFO - 2018-07-16 07:55:53 --> Output Class Initialized
INFO - 2018-07-16 07:55:53 --> Security Class Initialized
DEBUG - 2018-07-16 07:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:55:53 --> Input Class Initialized
INFO - 2018-07-16 07:55:53 --> Language Class Initialized
INFO - 2018-07-16 07:55:53 --> Loader Class Initialized
INFO - 2018-07-16 07:55:53 --> Controller Class Initialized
INFO - 2018-07-16 07:55:53 --> Database Driver Class Initialized
INFO - 2018-07-16 07:55:53 --> Model Class Initialized
INFO - 2018-07-16 07:55:53 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:55:53 --> Model Class Initialized
INFO - 2018-07-16 07:55:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:55:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 07:55:53 --> Final output sent to browser
DEBUG - 2018-07-16 07:55:53 --> Total execution time: 0.0877
ERROR - 2018-07-16 07:55:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 07:55:58 --> Config Class Initialized
INFO - 2018-07-16 07:55:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 07:55:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 07:55:58 --> Utf8 Class Initialized
INFO - 2018-07-16 07:55:58 --> URI Class Initialized
INFO - 2018-07-16 07:55:58 --> Router Class Initialized
INFO - 2018-07-16 07:55:58 --> Output Class Initialized
INFO - 2018-07-16 07:55:58 --> Security Class Initialized
DEBUG - 2018-07-16 07:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 07:55:58 --> Input Class Initialized
INFO - 2018-07-16 07:55:58 --> Language Class Initialized
INFO - 2018-07-16 07:55:58 --> Loader Class Initialized
INFO - 2018-07-16 07:55:58 --> Controller Class Initialized
INFO - 2018-07-16 07:55:58 --> Database Driver Class Initialized
INFO - 2018-07-16 07:55:58 --> Model Class Initialized
INFO - 2018-07-16 07:55:58 --> Helper loaded: url_helper
DEBUG - 2018-07-16 07:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 07:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 07:55:58 --> Model Class Initialized
INFO - 2018-07-16 07:55:58 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 07:55:58 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 07:55:58 --> Final output sent to browser
DEBUG - 2018-07-16 07:55:58 --> Total execution time: 0.0600
ERROR - 2018-07-16 13:15:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:15:11 --> Config Class Initialized
INFO - 2018-07-16 13:15:11 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:15:11 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:15:11 --> Utf8 Class Initialized
INFO - 2018-07-16 13:15:11 --> URI Class Initialized
INFO - 2018-07-16 13:15:11 --> Router Class Initialized
INFO - 2018-07-16 13:15:11 --> Output Class Initialized
INFO - 2018-07-16 13:15:11 --> Security Class Initialized
DEBUG - 2018-07-16 13:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:15:11 --> Input Class Initialized
INFO - 2018-07-16 13:15:11 --> Language Class Initialized
INFO - 2018-07-16 13:15:11 --> Loader Class Initialized
INFO - 2018-07-16 13:15:11 --> Controller Class Initialized
INFO - 2018-07-16 13:15:11 --> Database Driver Class Initialized
INFO - 2018-07-16 13:15:11 --> Model Class Initialized
INFO - 2018-07-16 13:15:11 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:15:11 --> Model Class Initialized
ERROR - 2018-07-16 13:15:11 --> Severity: Notice --> Undefined index: Davidhood C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-07-16 13:15:11 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:15:11 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-16 13:15:11 --> Final output sent to browser
DEBUG - 2018-07-16 13:15:11 --> Total execution time: 0.0509
ERROR - 2018-07-16 13:15:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:15:12 --> Config Class Initialized
INFO - 2018-07-16 13:15:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:15:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:15:12 --> Utf8 Class Initialized
INFO - 2018-07-16 13:15:12 --> URI Class Initialized
DEBUG - 2018-07-16 13:15:12 --> No URI present. Default controller set.
INFO - 2018-07-16 13:15:12 --> Router Class Initialized
INFO - 2018-07-16 13:15:12 --> Output Class Initialized
INFO - 2018-07-16 13:15:12 --> Security Class Initialized
DEBUG - 2018-07-16 13:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:15:12 --> Input Class Initialized
INFO - 2018-07-16 13:15:12 --> Language Class Initialized
INFO - 2018-07-16 13:15:12 --> Loader Class Initialized
INFO - 2018-07-16 13:15:12 --> Controller Class Initialized
INFO - 2018-07-16 13:15:12 --> Database Driver Class Initialized
INFO - 2018-07-16 13:15:12 --> Model Class Initialized
INFO - 2018-07-16 13:15:12 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:15:12 --> Model Class Initialized
INFO - 2018-07-16 13:15:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-16 13:15:12 --> Final output sent to browser
DEBUG - 2018-07-16 13:15:12 --> Total execution time: 0.0490
ERROR - 2018-07-16 13:15:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:15:13 --> Config Class Initialized
INFO - 2018-07-16 13:15:13 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:15:13 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:15:13 --> Utf8 Class Initialized
INFO - 2018-07-16 13:15:13 --> URI Class Initialized
INFO - 2018-07-16 13:15:13 --> Router Class Initialized
INFO - 2018-07-16 13:15:13 --> Output Class Initialized
INFO - 2018-07-16 13:15:13 --> Security Class Initialized
DEBUG - 2018-07-16 13:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:15:13 --> Input Class Initialized
INFO - 2018-07-16 13:15:13 --> Language Class Initialized
INFO - 2018-07-16 13:15:13 --> Loader Class Initialized
INFO - 2018-07-16 13:15:13 --> Controller Class Initialized
INFO - 2018-07-16 13:15:13 --> Database Driver Class Initialized
INFO - 2018-07-16 13:15:13 --> Model Class Initialized
INFO - 2018-07-16 13:15:13 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:15:13 --> Model Class Initialized
ERROR - 2018-07-16 13:15:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:15:13 --> Config Class Initialized
INFO - 2018-07-16 13:15:13 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:15:13 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:15:13 --> Utf8 Class Initialized
INFO - 2018-07-16 13:15:13 --> URI Class Initialized
INFO - 2018-07-16 13:15:13 --> Router Class Initialized
INFO - 2018-07-16 13:15:13 --> Output Class Initialized
INFO - 2018-07-16 13:15:13 --> Security Class Initialized
DEBUG - 2018-07-16 13:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:15:13 --> Input Class Initialized
INFO - 2018-07-16 13:15:13 --> Language Class Initialized
INFO - 2018-07-16 13:15:13 --> Loader Class Initialized
INFO - 2018-07-16 13:15:13 --> Controller Class Initialized
INFO - 2018-07-16 13:15:13 --> Database Driver Class Initialized
INFO - 2018-07-16 13:15:13 --> Model Class Initialized
INFO - 2018-07-16 13:15:13 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:15:13 --> Model Class Initialized
INFO - 2018-07-16 13:15:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:15:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 13:15:13 --> Final output sent to browser
DEBUG - 2018-07-16 13:15:13 --> Total execution time: 0.0603
ERROR - 2018-07-16 13:15:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:15:16 --> Config Class Initialized
INFO - 2018-07-16 13:15:16 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:15:16 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:15:16 --> Utf8 Class Initialized
INFO - 2018-07-16 13:15:16 --> URI Class Initialized
INFO - 2018-07-16 13:15:16 --> Router Class Initialized
INFO - 2018-07-16 13:15:16 --> Output Class Initialized
INFO - 2018-07-16 13:15:16 --> Security Class Initialized
DEBUG - 2018-07-16 13:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:15:16 --> Input Class Initialized
INFO - 2018-07-16 13:15:16 --> Language Class Initialized
INFO - 2018-07-16 13:15:16 --> Loader Class Initialized
INFO - 2018-07-16 13:15:16 --> Controller Class Initialized
INFO - 2018-07-16 13:15:16 --> Database Driver Class Initialized
INFO - 2018-07-16 13:15:16 --> Model Class Initialized
INFO - 2018-07-16 13:15:16 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:15:16 --> Model Class Initialized
INFO - 2018-07-16 13:15:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:15:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 13:15:16 --> Final output sent to browser
DEBUG - 2018-07-16 13:15:16 --> Total execution time: 0.0515
ERROR - 2018-07-16 13:25:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:25:24 --> Config Class Initialized
INFO - 2018-07-16 13:25:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:25:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:25:24 --> Utf8 Class Initialized
INFO - 2018-07-16 13:25:24 --> URI Class Initialized
INFO - 2018-07-16 13:25:24 --> Router Class Initialized
INFO - 2018-07-16 13:25:24 --> Output Class Initialized
INFO - 2018-07-16 13:25:24 --> Security Class Initialized
DEBUG - 2018-07-16 13:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:25:24 --> Input Class Initialized
INFO - 2018-07-16 13:25:24 --> Language Class Initialized
INFO - 2018-07-16 13:25:24 --> Loader Class Initialized
INFO - 2018-07-16 13:25:24 --> Controller Class Initialized
INFO - 2018-07-16 13:25:24 --> Database Driver Class Initialized
INFO - 2018-07-16 13:25:24 --> Model Class Initialized
INFO - 2018-07-16 13:25:24 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:25:24 --> Model Class Initialized
INFO - 2018-07-16 13:25:24 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:25:24 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 13:25:24 --> Final output sent to browser
DEBUG - 2018-07-16 13:25:24 --> Total execution time: 0.0745
ERROR - 2018-07-16 13:25:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:25:53 --> Config Class Initialized
INFO - 2018-07-16 13:25:53 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:25:53 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:25:53 --> Utf8 Class Initialized
INFO - 2018-07-16 13:25:53 --> URI Class Initialized
INFO - 2018-07-16 13:25:53 --> Router Class Initialized
INFO - 2018-07-16 13:25:53 --> Output Class Initialized
INFO - 2018-07-16 13:25:53 --> Security Class Initialized
DEBUG - 2018-07-16 13:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:25:53 --> Input Class Initialized
INFO - 2018-07-16 13:25:53 --> Language Class Initialized
INFO - 2018-07-16 13:25:53 --> Loader Class Initialized
INFO - 2018-07-16 13:25:53 --> Controller Class Initialized
INFO - 2018-07-16 13:25:53 --> Database Driver Class Initialized
INFO - 2018-07-16 13:25:53 --> Model Class Initialized
INFO - 2018-07-16 13:25:53 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:25:53 --> Model Class Initialized
ERROR - 2018-07-16 13:25:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\davidhood\system\database\DB_driver.php 1476
ERROR - 2018-07-16 13:25:53 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_advertise` (`title`, `price`, `url`, `description`, `lang`, `type`, `cnt`, `question`, `answer`, `created`) VALUES ('sd', '0.1', 'https://drive.google.com/open?id=1e6pBBVZUzFh3GppFDnQivgVERlXtRAG6', 'sdf', 'french', 'once', 0, 'asdf', Array, 1531740353)
INFO - 2018-07-16 13:25:53 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-16 13:27:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:27:28 --> Config Class Initialized
INFO - 2018-07-16 13:27:28 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:27:28 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:27:28 --> Utf8 Class Initialized
INFO - 2018-07-16 13:27:28 --> URI Class Initialized
INFO - 2018-07-16 13:27:28 --> Router Class Initialized
INFO - 2018-07-16 13:27:28 --> Output Class Initialized
INFO - 2018-07-16 13:27:28 --> Security Class Initialized
DEBUG - 2018-07-16 13:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:27:28 --> Input Class Initialized
INFO - 2018-07-16 13:27:28 --> Language Class Initialized
INFO - 2018-07-16 13:27:28 --> Loader Class Initialized
INFO - 2018-07-16 13:27:28 --> Controller Class Initialized
INFO - 2018-07-16 13:27:28 --> Database Driver Class Initialized
INFO - 2018-07-16 13:27:28 --> Model Class Initialized
INFO - 2018-07-16 13:27:28 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:27:28 --> Model Class Initialized
ERROR - 2018-07-16 13:27:28 --> Severity: Notice --> Undefined index: answer C:\xampp\htdocs\davidhood\application\models\Model.php 49
INFO - 2018-07-16 13:27:28 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-16 13:27:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:27:53 --> Config Class Initialized
INFO - 2018-07-16 13:27:53 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:27:53 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:27:53 --> Utf8 Class Initialized
INFO - 2018-07-16 13:27:53 --> URI Class Initialized
INFO - 2018-07-16 13:27:53 --> Router Class Initialized
INFO - 2018-07-16 13:27:53 --> Output Class Initialized
INFO - 2018-07-16 13:27:53 --> Security Class Initialized
DEBUG - 2018-07-16 13:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:27:53 --> Input Class Initialized
INFO - 2018-07-16 13:27:53 --> Language Class Initialized
INFO - 2018-07-16 13:27:53 --> Loader Class Initialized
INFO - 2018-07-16 13:27:53 --> Controller Class Initialized
INFO - 2018-07-16 13:27:53 --> Database Driver Class Initialized
INFO - 2018-07-16 13:27:53 --> Model Class Initialized
INFO - 2018-07-16 13:27:53 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:27:53 --> Model Class Initialized
INFO - 2018-07-16 13:27:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-16 13:27:53 --> Severity: Notice --> Undefined index: answer C:\xampp\htdocs\davidhood\application\views\add_advertisement.php 127
ERROR - 2018-07-16 13:27:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\davidhood\application\views\add_advertisement.php 127
INFO - 2018-07-16 13:27:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 13:27:53 --> Final output sent to browser
DEBUG - 2018-07-16 13:27:53 --> Total execution time: 0.0700
ERROR - 2018-07-16 13:30:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:30:02 --> Config Class Initialized
INFO - 2018-07-16 13:30:02 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:30:02 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:30:02 --> Utf8 Class Initialized
INFO - 2018-07-16 13:30:02 --> URI Class Initialized
INFO - 2018-07-16 13:30:02 --> Router Class Initialized
INFO - 2018-07-16 13:30:02 --> Output Class Initialized
INFO - 2018-07-16 13:30:02 --> Security Class Initialized
DEBUG - 2018-07-16 13:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:30:02 --> Input Class Initialized
INFO - 2018-07-16 13:30:02 --> Language Class Initialized
ERROR - 2018-07-16 13:30:02 --> Severity: error --> Exception: syntax error, unexpected ''answer'' (T_CONSTANT_ENCAPSED_STRING), expecting variable (T_VARIABLE) C:\xampp\htdocs\davidhood\application\controllers\Main.php 26
ERROR - 2018-07-16 13:30:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:30:36 --> Config Class Initialized
INFO - 2018-07-16 13:30:36 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:30:36 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:30:36 --> Utf8 Class Initialized
INFO - 2018-07-16 13:30:36 --> URI Class Initialized
DEBUG - 2018-07-16 13:30:36 --> No URI present. Default controller set.
INFO - 2018-07-16 13:30:36 --> Router Class Initialized
INFO - 2018-07-16 13:30:36 --> Output Class Initialized
INFO - 2018-07-16 13:30:36 --> Security Class Initialized
DEBUG - 2018-07-16 13:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:30:36 --> Input Class Initialized
INFO - 2018-07-16 13:30:36 --> Language Class Initialized
INFO - 2018-07-16 13:30:36 --> Loader Class Initialized
INFO - 2018-07-16 13:30:36 --> Controller Class Initialized
INFO - 2018-07-16 13:30:36 --> Database Driver Class Initialized
INFO - 2018-07-16 13:30:36 --> Model Class Initialized
INFO - 2018-07-16 13:30:36 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:30:36 --> Model Class Initialized
INFO - 2018-07-16 13:30:36 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-16 13:30:36 --> Final output sent to browser
DEBUG - 2018-07-16 13:30:36 --> Total execution time: 0.0670
ERROR - 2018-07-16 13:30:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:30:37 --> Config Class Initialized
INFO - 2018-07-16 13:30:37 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:30:37 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:30:37 --> Utf8 Class Initialized
INFO - 2018-07-16 13:30:37 --> URI Class Initialized
INFO - 2018-07-16 13:30:37 --> Router Class Initialized
INFO - 2018-07-16 13:30:37 --> Output Class Initialized
INFO - 2018-07-16 13:30:37 --> Security Class Initialized
DEBUG - 2018-07-16 13:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:30:37 --> Input Class Initialized
INFO - 2018-07-16 13:30:37 --> Language Class Initialized
INFO - 2018-07-16 13:30:37 --> Loader Class Initialized
INFO - 2018-07-16 13:30:37 --> Controller Class Initialized
INFO - 2018-07-16 13:30:37 --> Database Driver Class Initialized
INFO - 2018-07-16 13:30:37 --> Model Class Initialized
INFO - 2018-07-16 13:30:37 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:30:37 --> Model Class Initialized
ERROR - 2018-07-16 13:30:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:30:37 --> Config Class Initialized
INFO - 2018-07-16 13:30:37 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:30:37 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:30:37 --> Utf8 Class Initialized
INFO - 2018-07-16 13:30:37 --> URI Class Initialized
INFO - 2018-07-16 13:30:37 --> Router Class Initialized
INFO - 2018-07-16 13:30:37 --> Output Class Initialized
INFO - 2018-07-16 13:30:37 --> Security Class Initialized
DEBUG - 2018-07-16 13:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:30:37 --> Input Class Initialized
INFO - 2018-07-16 13:30:37 --> Language Class Initialized
ERROR - 2018-07-16 13:30:37 --> Severity: error --> Exception: syntax error, unexpected ''answer'' (T_CONSTANT_ENCAPSED_STRING), expecting variable (T_VARIABLE) C:\xampp\htdocs\davidhood\application\controllers\Main.php 26
ERROR - 2018-07-16 13:31:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:31:37 --> Config Class Initialized
INFO - 2018-07-16 13:31:37 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:31:37 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:31:37 --> Utf8 Class Initialized
INFO - 2018-07-16 13:31:37 --> URI Class Initialized
INFO - 2018-07-16 13:31:37 --> Router Class Initialized
INFO - 2018-07-16 13:31:37 --> Output Class Initialized
INFO - 2018-07-16 13:31:37 --> Security Class Initialized
DEBUG - 2018-07-16 13:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:31:37 --> Input Class Initialized
INFO - 2018-07-16 13:31:37 --> Language Class Initialized
ERROR - 2018-07-16 13:31:37 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ')' C:\xampp\htdocs\davidhood\application\controllers\Main.php 26
ERROR - 2018-07-16 13:32:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:32:00 --> Config Class Initialized
INFO - 2018-07-16 13:32:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:32:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:32:00 --> Utf8 Class Initialized
INFO - 2018-07-16 13:32:00 --> URI Class Initialized
INFO - 2018-07-16 13:32:00 --> Router Class Initialized
INFO - 2018-07-16 13:32:00 --> Output Class Initialized
INFO - 2018-07-16 13:32:00 --> Security Class Initialized
DEBUG - 2018-07-16 13:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:32:00 --> Input Class Initialized
INFO - 2018-07-16 13:32:00 --> Language Class Initialized
INFO - 2018-07-16 13:32:00 --> Loader Class Initialized
INFO - 2018-07-16 13:32:00 --> Controller Class Initialized
INFO - 2018-07-16 13:32:00 --> Database Driver Class Initialized
INFO - 2018-07-16 13:32:00 --> Model Class Initialized
INFO - 2018-07-16 13:32:00 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:32:00 --> Model Class Initialized
INFO - 2018-07-16 13:32:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:32:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 13:32:00 --> Final output sent to browser
DEBUG - 2018-07-16 13:32:00 --> Total execution time: 0.0882
ERROR - 2018-07-16 13:32:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:32:12 --> Config Class Initialized
INFO - 2018-07-16 13:32:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:32:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:32:12 --> Utf8 Class Initialized
INFO - 2018-07-16 13:32:12 --> URI Class Initialized
INFO - 2018-07-16 13:32:12 --> Router Class Initialized
INFO - 2018-07-16 13:32:12 --> Output Class Initialized
INFO - 2018-07-16 13:32:12 --> Security Class Initialized
DEBUG - 2018-07-16 13:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:32:12 --> Input Class Initialized
INFO - 2018-07-16 13:32:12 --> Language Class Initialized
INFO - 2018-07-16 13:32:12 --> Loader Class Initialized
INFO - 2018-07-16 13:32:12 --> Controller Class Initialized
INFO - 2018-07-16 13:32:12 --> Database Driver Class Initialized
INFO - 2018-07-16 13:32:12 --> Model Class Initialized
INFO - 2018-07-16 13:32:12 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:32:12 --> Model Class Initialized
ERROR - 2018-07-16 13:32:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:32:12 --> Config Class Initialized
INFO - 2018-07-16 13:32:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:32:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:32:12 --> Utf8 Class Initialized
INFO - 2018-07-16 13:32:12 --> URI Class Initialized
INFO - 2018-07-16 13:32:12 --> Router Class Initialized
INFO - 2018-07-16 13:32:12 --> Output Class Initialized
INFO - 2018-07-16 13:32:12 --> Security Class Initialized
DEBUG - 2018-07-16 13:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:32:12 --> Input Class Initialized
INFO - 2018-07-16 13:32:12 --> Language Class Initialized
INFO - 2018-07-16 13:32:12 --> Loader Class Initialized
INFO - 2018-07-16 13:32:12 --> Controller Class Initialized
INFO - 2018-07-16 13:32:12 --> Database Driver Class Initialized
INFO - 2018-07-16 13:32:12 --> Model Class Initialized
INFO - 2018-07-16 13:32:12 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:32:12 --> Model Class Initialized
INFO - 2018-07-16 13:32:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:32:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 13:32:12 --> Final output sent to browser
DEBUG - 2018-07-16 13:32:12 --> Total execution time: 0.0666
ERROR - 2018-07-16 13:32:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:32:16 --> Config Class Initialized
INFO - 2018-07-16 13:32:16 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:32:16 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:32:16 --> Utf8 Class Initialized
INFO - 2018-07-16 13:32:16 --> URI Class Initialized
INFO - 2018-07-16 13:32:16 --> Router Class Initialized
INFO - 2018-07-16 13:32:16 --> Output Class Initialized
INFO - 2018-07-16 13:32:16 --> Security Class Initialized
DEBUG - 2018-07-16 13:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:32:16 --> Input Class Initialized
INFO - 2018-07-16 13:32:16 --> Language Class Initialized
INFO - 2018-07-16 13:32:16 --> Loader Class Initialized
INFO - 2018-07-16 13:32:16 --> Controller Class Initialized
INFO - 2018-07-16 13:32:16 --> Database Driver Class Initialized
INFO - 2018-07-16 13:32:16 --> Model Class Initialized
INFO - 2018-07-16 13:32:16 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:32:16 --> Model Class Initialized
INFO - 2018-07-16 13:32:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:32:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 13:32:16 --> Final output sent to browser
DEBUG - 2018-07-16 13:32:16 --> Total execution time: 0.0581
ERROR - 2018-07-16 13:32:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:32:40 --> Config Class Initialized
INFO - 2018-07-16 13:32:40 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:32:40 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:32:40 --> Utf8 Class Initialized
INFO - 2018-07-16 13:32:40 --> URI Class Initialized
INFO - 2018-07-16 13:32:40 --> Router Class Initialized
INFO - 2018-07-16 13:32:40 --> Output Class Initialized
INFO - 2018-07-16 13:32:40 --> Security Class Initialized
DEBUG - 2018-07-16 13:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:32:40 --> Input Class Initialized
INFO - 2018-07-16 13:32:40 --> Language Class Initialized
INFO - 2018-07-16 13:32:40 --> Loader Class Initialized
INFO - 2018-07-16 13:32:40 --> Controller Class Initialized
INFO - 2018-07-16 13:32:40 --> Database Driver Class Initialized
INFO - 2018-07-16 13:32:40 --> Model Class Initialized
INFO - 2018-07-16 13:32:40 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:32:40 --> Model Class Initialized
ERROR - 2018-07-16 13:32:40 --> Query error: Table 'davidhood.tbl_answer' doesn't exist - Invalid query: INSERT INTO `tbl_answer` (`answer`, `isright`, `advertise_id`) VALUES ('sd', 0, 9)
INFO - 2018-07-16 13:32:40 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-16 13:33:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:33:32 --> Config Class Initialized
INFO - 2018-07-16 13:33:32 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:33:32 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:33:32 --> Utf8 Class Initialized
INFO - 2018-07-16 13:33:32 --> URI Class Initialized
INFO - 2018-07-16 13:33:32 --> Router Class Initialized
INFO - 2018-07-16 13:33:32 --> Output Class Initialized
INFO - 2018-07-16 13:33:32 --> Security Class Initialized
DEBUG - 2018-07-16 13:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:33:32 --> Input Class Initialized
INFO - 2018-07-16 13:33:32 --> Language Class Initialized
INFO - 2018-07-16 13:33:32 --> Loader Class Initialized
INFO - 2018-07-16 13:33:32 --> Controller Class Initialized
INFO - 2018-07-16 13:33:32 --> Database Driver Class Initialized
INFO - 2018-07-16 13:33:32 --> Model Class Initialized
INFO - 2018-07-16 13:33:32 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:33:32 --> Model Class Initialized
INFO - 2018-07-16 13:33:32 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:33:32 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 13:33:32 --> Final output sent to browser
DEBUG - 2018-07-16 13:33:32 --> Total execution time: 0.0578
ERROR - 2018-07-16 13:33:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:33:45 --> Config Class Initialized
INFO - 2018-07-16 13:33:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:33:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:33:45 --> Utf8 Class Initialized
INFO - 2018-07-16 13:33:45 --> URI Class Initialized
INFO - 2018-07-16 13:33:45 --> Router Class Initialized
INFO - 2018-07-16 13:33:45 --> Output Class Initialized
INFO - 2018-07-16 13:33:45 --> Security Class Initialized
DEBUG - 2018-07-16 13:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:33:45 --> Input Class Initialized
INFO - 2018-07-16 13:33:45 --> Language Class Initialized
INFO - 2018-07-16 13:33:45 --> Loader Class Initialized
INFO - 2018-07-16 13:33:45 --> Controller Class Initialized
INFO - 2018-07-16 13:33:45 --> Database Driver Class Initialized
INFO - 2018-07-16 13:33:45 --> Model Class Initialized
INFO - 2018-07-16 13:33:45 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:33:45 --> Model Class Initialized
INFO - 2018-07-16 13:33:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:33:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 13:33:45 --> Final output sent to browser
DEBUG - 2018-07-16 13:33:45 --> Total execution time: 0.0817
ERROR - 2018-07-16 13:34:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:34:22 --> Config Class Initialized
INFO - 2018-07-16 13:34:22 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:34:22 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:34:22 --> Utf8 Class Initialized
INFO - 2018-07-16 13:34:22 --> URI Class Initialized
INFO - 2018-07-16 13:34:22 --> Router Class Initialized
INFO - 2018-07-16 13:34:22 --> Output Class Initialized
INFO - 2018-07-16 13:34:22 --> Security Class Initialized
DEBUG - 2018-07-16 13:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:34:22 --> Input Class Initialized
INFO - 2018-07-16 13:34:22 --> Language Class Initialized
INFO - 2018-07-16 13:34:22 --> Loader Class Initialized
INFO - 2018-07-16 13:34:22 --> Controller Class Initialized
INFO - 2018-07-16 13:34:22 --> Database Driver Class Initialized
INFO - 2018-07-16 13:34:22 --> Model Class Initialized
INFO - 2018-07-16 13:34:22 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:34:22 --> Model Class Initialized
INFO - 2018-07-16 13:34:22 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:34:22 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 13:34:22 --> Final output sent to browser
DEBUG - 2018-07-16 13:34:22 --> Total execution time: 0.0487
ERROR - 2018-07-16 13:34:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:34:24 --> Config Class Initialized
INFO - 2018-07-16 13:34:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:34:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:34:24 --> Utf8 Class Initialized
INFO - 2018-07-16 13:34:24 --> URI Class Initialized
INFO - 2018-07-16 13:34:24 --> Router Class Initialized
INFO - 2018-07-16 13:34:25 --> Output Class Initialized
INFO - 2018-07-16 13:34:25 --> Security Class Initialized
DEBUG - 2018-07-16 13:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:34:25 --> Input Class Initialized
INFO - 2018-07-16 13:34:25 --> Language Class Initialized
INFO - 2018-07-16 13:34:25 --> Loader Class Initialized
INFO - 2018-07-16 13:34:25 --> Controller Class Initialized
INFO - 2018-07-16 13:34:25 --> Database Driver Class Initialized
INFO - 2018-07-16 13:34:25 --> Model Class Initialized
INFO - 2018-07-16 13:34:25 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:34:25 --> Model Class Initialized
INFO - 2018-07-16 13:34:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:34:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 13:34:25 --> Final output sent to browser
DEBUG - 2018-07-16 13:34:25 --> Total execution time: 0.0502
ERROR - 2018-07-16 13:34:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:34:58 --> Config Class Initialized
INFO - 2018-07-16 13:34:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:34:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:34:58 --> Utf8 Class Initialized
INFO - 2018-07-16 13:34:58 --> URI Class Initialized
INFO - 2018-07-16 13:34:58 --> Router Class Initialized
INFO - 2018-07-16 13:34:58 --> Output Class Initialized
INFO - 2018-07-16 13:34:58 --> Security Class Initialized
DEBUG - 2018-07-16 13:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:34:58 --> Input Class Initialized
INFO - 2018-07-16 13:34:58 --> Language Class Initialized
INFO - 2018-07-16 13:34:58 --> Loader Class Initialized
INFO - 2018-07-16 13:34:58 --> Controller Class Initialized
INFO - 2018-07-16 13:34:58 --> Database Driver Class Initialized
INFO - 2018-07-16 13:34:58 --> Model Class Initialized
INFO - 2018-07-16 13:34:58 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:34:58 --> Model Class Initialized
INFO - 2018-07-16 13:34:58 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:34:58 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 13:34:58 --> Final output sent to browser
DEBUG - 2018-07-16 13:34:58 --> Total execution time: 0.0563
ERROR - 2018-07-16 13:35:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:35:00 --> Config Class Initialized
INFO - 2018-07-16 13:35:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:35:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:35:00 --> Utf8 Class Initialized
INFO - 2018-07-16 13:35:00 --> URI Class Initialized
INFO - 2018-07-16 13:35:00 --> Router Class Initialized
INFO - 2018-07-16 13:35:00 --> Output Class Initialized
INFO - 2018-07-16 13:35:00 --> Security Class Initialized
DEBUG - 2018-07-16 13:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:35:00 --> Input Class Initialized
INFO - 2018-07-16 13:35:00 --> Language Class Initialized
INFO - 2018-07-16 13:35:00 --> Loader Class Initialized
INFO - 2018-07-16 13:35:00 --> Controller Class Initialized
INFO - 2018-07-16 13:35:00 --> Database Driver Class Initialized
INFO - 2018-07-16 13:35:00 --> Model Class Initialized
INFO - 2018-07-16 13:35:00 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:35:00 --> Model Class Initialized
ERROR - 2018-07-16 13:35:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:35:00 --> Config Class Initialized
INFO - 2018-07-16 13:35:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:35:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:35:00 --> Utf8 Class Initialized
INFO - 2018-07-16 13:35:00 --> URI Class Initialized
INFO - 2018-07-16 13:35:00 --> Router Class Initialized
INFO - 2018-07-16 13:35:00 --> Output Class Initialized
INFO - 2018-07-16 13:35:00 --> Security Class Initialized
DEBUG - 2018-07-16 13:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:35:00 --> Input Class Initialized
INFO - 2018-07-16 13:35:00 --> Language Class Initialized
INFO - 2018-07-16 13:35:00 --> Loader Class Initialized
INFO - 2018-07-16 13:35:00 --> Controller Class Initialized
INFO - 2018-07-16 13:35:00 --> Database Driver Class Initialized
INFO - 2018-07-16 13:35:00 --> Model Class Initialized
INFO - 2018-07-16 13:35:00 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:35:00 --> Model Class Initialized
INFO - 2018-07-16 13:35:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:35:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 13:35:00 --> Final output sent to browser
DEBUG - 2018-07-16 13:35:00 --> Total execution time: 0.0644
ERROR - 2018-07-16 13:35:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:35:02 --> Config Class Initialized
INFO - 2018-07-16 13:35:03 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:35:03 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:35:03 --> Utf8 Class Initialized
INFO - 2018-07-16 13:35:03 --> URI Class Initialized
INFO - 2018-07-16 13:35:03 --> Router Class Initialized
INFO - 2018-07-16 13:35:03 --> Output Class Initialized
INFO - 2018-07-16 13:35:03 --> Security Class Initialized
DEBUG - 2018-07-16 13:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:35:03 --> Input Class Initialized
INFO - 2018-07-16 13:35:03 --> Language Class Initialized
INFO - 2018-07-16 13:35:03 --> Loader Class Initialized
INFO - 2018-07-16 13:35:03 --> Controller Class Initialized
INFO - 2018-07-16 13:35:03 --> Database Driver Class Initialized
INFO - 2018-07-16 13:35:03 --> Model Class Initialized
INFO - 2018-07-16 13:35:03 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:35:03 --> Model Class Initialized
INFO - 2018-07-16 13:35:03 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:35:03 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 13:35:03 --> Final output sent to browser
DEBUG - 2018-07-16 13:35:03 --> Total execution time: 0.0616
ERROR - 2018-07-16 13:35:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:35:25 --> Config Class Initialized
INFO - 2018-07-16 13:35:25 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:35:25 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:35:25 --> Utf8 Class Initialized
INFO - 2018-07-16 13:35:25 --> URI Class Initialized
INFO - 2018-07-16 13:35:25 --> Router Class Initialized
INFO - 2018-07-16 13:35:25 --> Output Class Initialized
INFO - 2018-07-16 13:35:25 --> Security Class Initialized
DEBUG - 2018-07-16 13:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:35:25 --> Input Class Initialized
INFO - 2018-07-16 13:35:25 --> Language Class Initialized
INFO - 2018-07-16 13:35:25 --> Loader Class Initialized
INFO - 2018-07-16 13:35:25 --> Controller Class Initialized
INFO - 2018-07-16 13:35:25 --> Database Driver Class Initialized
INFO - 2018-07-16 13:35:25 --> Model Class Initialized
INFO - 2018-07-16 13:35:25 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:35:25 --> Model Class Initialized
INFO - 2018-07-16 13:35:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:35:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 13:35:25 --> Final output sent to browser
DEBUG - 2018-07-16 13:35:25 --> Total execution time: 0.1496
ERROR - 2018-07-16 13:35:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:35:49 --> Config Class Initialized
INFO - 2018-07-16 13:35:49 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:35:49 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:35:49 --> Utf8 Class Initialized
INFO - 2018-07-16 13:35:49 --> URI Class Initialized
INFO - 2018-07-16 13:35:49 --> Router Class Initialized
INFO - 2018-07-16 13:35:49 --> Output Class Initialized
INFO - 2018-07-16 13:35:49 --> Security Class Initialized
DEBUG - 2018-07-16 13:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:35:49 --> Input Class Initialized
INFO - 2018-07-16 13:35:49 --> Language Class Initialized
INFO - 2018-07-16 13:35:49 --> Loader Class Initialized
INFO - 2018-07-16 13:35:49 --> Controller Class Initialized
INFO - 2018-07-16 13:35:49 --> Database Driver Class Initialized
INFO - 2018-07-16 13:35:49 --> Model Class Initialized
INFO - 2018-07-16 13:35:49 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:35:49 --> Model Class Initialized
INFO - 2018-07-16 13:35:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:35:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 13:35:49 --> Final output sent to browser
DEBUG - 2018-07-16 13:35:49 --> Total execution time: 0.0725
ERROR - 2018-07-16 13:36:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:36:01 --> Config Class Initialized
INFO - 2018-07-16 13:36:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:36:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:36:01 --> Utf8 Class Initialized
INFO - 2018-07-16 13:36:01 --> URI Class Initialized
INFO - 2018-07-16 13:36:01 --> Router Class Initialized
INFO - 2018-07-16 13:36:01 --> Output Class Initialized
INFO - 2018-07-16 13:36:01 --> Security Class Initialized
DEBUG - 2018-07-16 13:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:36:01 --> Input Class Initialized
INFO - 2018-07-16 13:36:01 --> Language Class Initialized
INFO - 2018-07-16 13:36:01 --> Loader Class Initialized
INFO - 2018-07-16 13:36:01 --> Controller Class Initialized
INFO - 2018-07-16 13:36:01 --> Database Driver Class Initialized
INFO - 2018-07-16 13:36:01 --> Model Class Initialized
INFO - 2018-07-16 13:36:01 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:36:01 --> Model Class Initialized
ERROR - 2018-07-16 13:36:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:36:01 --> Config Class Initialized
INFO - 2018-07-16 13:36:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:36:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:36:01 --> Utf8 Class Initialized
INFO - 2018-07-16 13:36:01 --> URI Class Initialized
INFO - 2018-07-16 13:36:01 --> Router Class Initialized
INFO - 2018-07-16 13:36:01 --> Output Class Initialized
INFO - 2018-07-16 13:36:01 --> Security Class Initialized
DEBUG - 2018-07-16 13:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:36:01 --> Input Class Initialized
INFO - 2018-07-16 13:36:01 --> Language Class Initialized
INFO - 2018-07-16 13:36:01 --> Loader Class Initialized
INFO - 2018-07-16 13:36:01 --> Controller Class Initialized
INFO - 2018-07-16 13:36:01 --> Database Driver Class Initialized
INFO - 2018-07-16 13:36:01 --> Model Class Initialized
INFO - 2018-07-16 13:36:01 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:36:01 --> Model Class Initialized
INFO - 2018-07-16 13:36:01 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:36:01 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 13:36:01 --> Final output sent to browser
DEBUG - 2018-07-16 13:36:01 --> Total execution time: 0.0587
ERROR - 2018-07-16 13:37:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:37:40 --> Config Class Initialized
INFO - 2018-07-16 13:37:40 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:37:40 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:37:40 --> Utf8 Class Initialized
INFO - 2018-07-16 13:37:40 --> URI Class Initialized
INFO - 2018-07-16 13:37:40 --> Router Class Initialized
INFO - 2018-07-16 13:37:40 --> Output Class Initialized
INFO - 2018-07-16 13:37:40 --> Security Class Initialized
DEBUG - 2018-07-16 13:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:37:40 --> Input Class Initialized
INFO - 2018-07-16 13:37:40 --> Language Class Initialized
INFO - 2018-07-16 13:37:40 --> Loader Class Initialized
INFO - 2018-07-16 13:37:40 --> Controller Class Initialized
INFO - 2018-07-16 13:37:40 --> Database Driver Class Initialized
INFO - 2018-07-16 13:37:40 --> Model Class Initialized
INFO - 2018-07-16 13:37:40 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:37:40 --> Model Class Initialized
INFO - 2018-07-16 13:37:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:37:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 13:37:40 --> Final output sent to browser
DEBUG - 2018-07-16 13:37:40 --> Total execution time: 0.0546
ERROR - 2018-07-16 13:37:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:37:45 --> Config Class Initialized
INFO - 2018-07-16 13:37:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:37:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:37:45 --> Utf8 Class Initialized
INFO - 2018-07-16 13:37:45 --> URI Class Initialized
INFO - 2018-07-16 13:37:45 --> Router Class Initialized
INFO - 2018-07-16 13:37:45 --> Output Class Initialized
INFO - 2018-07-16 13:37:45 --> Security Class Initialized
DEBUG - 2018-07-16 13:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:37:45 --> Input Class Initialized
INFO - 2018-07-16 13:37:45 --> Language Class Initialized
INFO - 2018-07-16 13:37:45 --> Loader Class Initialized
INFO - 2018-07-16 13:37:45 --> Controller Class Initialized
INFO - 2018-07-16 13:37:45 --> Database Driver Class Initialized
INFO - 2018-07-16 13:37:45 --> Model Class Initialized
INFO - 2018-07-16 13:37:45 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:37:45 --> Model Class Initialized
INFO - 2018-07-16 13:37:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:37:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 13:37:45 --> Final output sent to browser
DEBUG - 2018-07-16 13:37:45 --> Total execution time: 0.0591
ERROR - 2018-07-16 13:38:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:38:08 --> Config Class Initialized
INFO - 2018-07-16 13:38:08 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:38:08 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:38:08 --> Utf8 Class Initialized
INFO - 2018-07-16 13:38:08 --> URI Class Initialized
INFO - 2018-07-16 13:38:08 --> Router Class Initialized
INFO - 2018-07-16 13:38:08 --> Output Class Initialized
INFO - 2018-07-16 13:38:08 --> Security Class Initialized
DEBUG - 2018-07-16 13:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:38:08 --> Input Class Initialized
INFO - 2018-07-16 13:38:08 --> Language Class Initialized
INFO - 2018-07-16 13:38:08 --> Loader Class Initialized
INFO - 2018-07-16 13:38:08 --> Controller Class Initialized
INFO - 2018-07-16 13:38:08 --> Database Driver Class Initialized
INFO - 2018-07-16 13:38:08 --> Model Class Initialized
INFO - 2018-07-16 13:38:08 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:38:08 --> Model Class Initialized
INFO - 2018-07-16 13:38:08 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:38:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 13:38:09 --> Final output sent to browser
DEBUG - 2018-07-16 13:38:09 --> Total execution time: 0.1836
ERROR - 2018-07-16 13:38:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:38:10 --> Config Class Initialized
INFO - 2018-07-16 13:38:10 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:38:10 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:38:10 --> Utf8 Class Initialized
INFO - 2018-07-16 13:38:10 --> URI Class Initialized
INFO - 2018-07-16 13:38:10 --> Router Class Initialized
INFO - 2018-07-16 13:38:10 --> Output Class Initialized
INFO - 2018-07-16 13:38:10 --> Security Class Initialized
DEBUG - 2018-07-16 13:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:38:10 --> Input Class Initialized
INFO - 2018-07-16 13:38:10 --> Language Class Initialized
INFO - 2018-07-16 13:38:10 --> Loader Class Initialized
INFO - 2018-07-16 13:38:10 --> Controller Class Initialized
INFO - 2018-07-16 13:38:10 --> Database Driver Class Initialized
INFO - 2018-07-16 13:38:10 --> Model Class Initialized
INFO - 2018-07-16 13:38:10 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:38:10 --> Model Class Initialized
INFO - 2018-07-16 13:38:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:38:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 13:38:10 --> Final output sent to browser
DEBUG - 2018-07-16 13:38:10 --> Total execution time: 0.0828
ERROR - 2018-07-16 13:38:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:38:20 --> Config Class Initialized
INFO - 2018-07-16 13:38:20 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:38:20 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:38:20 --> Utf8 Class Initialized
INFO - 2018-07-16 13:38:20 --> URI Class Initialized
INFO - 2018-07-16 13:38:20 --> Router Class Initialized
INFO - 2018-07-16 13:38:20 --> Output Class Initialized
INFO - 2018-07-16 13:38:20 --> Security Class Initialized
DEBUG - 2018-07-16 13:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:38:20 --> Input Class Initialized
INFO - 2018-07-16 13:38:20 --> Language Class Initialized
INFO - 2018-07-16 13:38:20 --> Loader Class Initialized
INFO - 2018-07-16 13:38:20 --> Controller Class Initialized
INFO - 2018-07-16 13:38:20 --> Database Driver Class Initialized
INFO - 2018-07-16 13:38:20 --> Model Class Initialized
INFO - 2018-07-16 13:38:20 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:38:20 --> Model Class Initialized
ERROR - 2018-07-16 13:38:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:38:20 --> Config Class Initialized
INFO - 2018-07-16 13:38:20 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:38:20 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:38:20 --> Utf8 Class Initialized
INFO - 2018-07-16 13:38:20 --> URI Class Initialized
INFO - 2018-07-16 13:38:20 --> Router Class Initialized
INFO - 2018-07-16 13:38:20 --> Output Class Initialized
INFO - 2018-07-16 13:38:20 --> Security Class Initialized
DEBUG - 2018-07-16 13:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:38:20 --> Input Class Initialized
INFO - 2018-07-16 13:38:20 --> Language Class Initialized
INFO - 2018-07-16 13:38:20 --> Loader Class Initialized
INFO - 2018-07-16 13:38:20 --> Controller Class Initialized
INFO - 2018-07-16 13:38:20 --> Database Driver Class Initialized
INFO - 2018-07-16 13:38:20 --> Model Class Initialized
INFO - 2018-07-16 13:38:20 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:38:20 --> Model Class Initialized
INFO - 2018-07-16 13:38:20 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:38:20 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 13:38:20 --> Final output sent to browser
DEBUG - 2018-07-16 13:38:20 --> Total execution time: 0.0668
ERROR - 2018-07-16 13:38:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:38:22 --> Config Class Initialized
INFO - 2018-07-16 13:38:22 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:38:22 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:38:22 --> Utf8 Class Initialized
INFO - 2018-07-16 13:38:22 --> URI Class Initialized
INFO - 2018-07-16 13:38:22 --> Router Class Initialized
INFO - 2018-07-16 13:38:22 --> Output Class Initialized
INFO - 2018-07-16 13:38:22 --> Security Class Initialized
DEBUG - 2018-07-16 13:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:38:22 --> Input Class Initialized
INFO - 2018-07-16 13:38:22 --> Language Class Initialized
INFO - 2018-07-16 13:38:23 --> Loader Class Initialized
INFO - 2018-07-16 13:38:23 --> Controller Class Initialized
INFO - 2018-07-16 13:38:23 --> Database Driver Class Initialized
INFO - 2018-07-16 13:38:23 --> Model Class Initialized
INFO - 2018-07-16 13:38:23 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:38:23 --> Model Class Initialized
INFO - 2018-07-16 13:38:23 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:38:23 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 13:38:23 --> Final output sent to browser
DEBUG - 2018-07-16 13:38:23 --> Total execution time: 0.0484
ERROR - 2018-07-16 13:39:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:39:38 --> Config Class Initialized
INFO - 2018-07-16 13:39:38 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:39:38 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:39:38 --> Utf8 Class Initialized
INFO - 2018-07-16 13:39:38 --> URI Class Initialized
INFO - 2018-07-16 13:39:38 --> Router Class Initialized
INFO - 2018-07-16 13:39:38 --> Output Class Initialized
INFO - 2018-07-16 13:39:38 --> Security Class Initialized
DEBUG - 2018-07-16 13:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:39:38 --> Input Class Initialized
INFO - 2018-07-16 13:39:38 --> Language Class Initialized
INFO - 2018-07-16 13:39:38 --> Loader Class Initialized
INFO - 2018-07-16 13:39:38 --> Controller Class Initialized
INFO - 2018-07-16 13:39:38 --> Database Driver Class Initialized
INFO - 2018-07-16 13:39:38 --> Model Class Initialized
INFO - 2018-07-16 13:39:38 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:39:38 --> Model Class Initialized
INFO - 2018-07-16 13:39:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:39:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-16 13:39:38 --> Final output sent to browser
DEBUG - 2018-07-16 13:39:38 --> Total execution time: 0.0576
ERROR - 2018-07-16 13:39:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:39:50 --> Config Class Initialized
INFO - 2018-07-16 13:39:50 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:39:50 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:39:50 --> Utf8 Class Initialized
INFO - 2018-07-16 13:39:50 --> URI Class Initialized
INFO - 2018-07-16 13:39:50 --> Router Class Initialized
INFO - 2018-07-16 13:39:50 --> Output Class Initialized
INFO - 2018-07-16 13:39:50 --> Security Class Initialized
DEBUG - 2018-07-16 13:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:39:50 --> Input Class Initialized
INFO - 2018-07-16 13:39:50 --> Language Class Initialized
INFO - 2018-07-16 13:39:50 --> Loader Class Initialized
INFO - 2018-07-16 13:39:50 --> Controller Class Initialized
INFO - 2018-07-16 13:39:50 --> Database Driver Class Initialized
INFO - 2018-07-16 13:39:50 --> Model Class Initialized
INFO - 2018-07-16 13:39:50 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:39:50 --> Model Class Initialized
INFO - 2018-07-16 13:39:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:39:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-16 13:39:50 --> Final output sent to browser
DEBUG - 2018-07-16 13:39:50 --> Total execution time: 0.0573
ERROR - 2018-07-16 13:39:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:39:54 --> Config Class Initialized
INFO - 2018-07-16 13:39:54 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:39:54 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:39:54 --> Utf8 Class Initialized
INFO - 2018-07-16 13:39:54 --> URI Class Initialized
INFO - 2018-07-16 13:39:54 --> Router Class Initialized
INFO - 2018-07-16 13:39:54 --> Output Class Initialized
INFO - 2018-07-16 13:39:54 --> Security Class Initialized
DEBUG - 2018-07-16 13:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:39:54 --> Input Class Initialized
INFO - 2018-07-16 13:39:54 --> Language Class Initialized
INFO - 2018-07-16 13:39:54 --> Loader Class Initialized
INFO - 2018-07-16 13:39:54 --> Controller Class Initialized
INFO - 2018-07-16 13:39:54 --> Database Driver Class Initialized
INFO - 2018-07-16 13:39:54 --> Model Class Initialized
INFO - 2018-07-16 13:39:54 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:39:54 --> Model Class Initialized
INFO - 2018-07-16 13:39:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:39:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 13:39:54 --> Final output sent to browser
DEBUG - 2018-07-16 13:39:54 --> Total execution time: 0.0571
ERROR - 2018-07-16 13:39:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 13:39:55 --> Config Class Initialized
INFO - 2018-07-16 13:39:55 --> Hooks Class Initialized
DEBUG - 2018-07-16 13:39:55 --> UTF-8 Support Enabled
INFO - 2018-07-16 13:39:55 --> Utf8 Class Initialized
INFO - 2018-07-16 13:39:55 --> URI Class Initialized
INFO - 2018-07-16 13:39:55 --> Router Class Initialized
INFO - 2018-07-16 13:39:55 --> Output Class Initialized
INFO - 2018-07-16 13:39:55 --> Security Class Initialized
DEBUG - 2018-07-16 13:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 13:39:55 --> Input Class Initialized
INFO - 2018-07-16 13:39:55 --> Language Class Initialized
INFO - 2018-07-16 13:39:55 --> Loader Class Initialized
INFO - 2018-07-16 13:39:55 --> Controller Class Initialized
INFO - 2018-07-16 13:39:55 --> Database Driver Class Initialized
INFO - 2018-07-16 13:39:55 --> Model Class Initialized
INFO - 2018-07-16 13:39:55 --> Helper loaded: url_helper
DEBUG - 2018-07-16 13:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 13:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 13:39:55 --> Model Class Initialized
INFO - 2018-07-16 13:39:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 13:39:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-16 13:39:55 --> Final output sent to browser
DEBUG - 2018-07-16 13:39:55 --> Total execution time: 0.0592
ERROR - 2018-07-16 14:14:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:14:16 --> Config Class Initialized
INFO - 2018-07-16 14:14:16 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:14:16 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:14:16 --> Utf8 Class Initialized
INFO - 2018-07-16 14:14:16 --> URI Class Initialized
INFO - 2018-07-16 14:14:16 --> Router Class Initialized
INFO - 2018-07-16 14:14:16 --> Output Class Initialized
INFO - 2018-07-16 14:14:16 --> Security Class Initialized
DEBUG - 2018-07-16 14:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:14:16 --> Input Class Initialized
INFO - 2018-07-16 14:14:16 --> Language Class Initialized
INFO - 2018-07-16 14:14:16 --> Loader Class Initialized
INFO - 2018-07-16 14:14:16 --> Controller Class Initialized
INFO - 2018-07-16 14:14:16 --> Database Driver Class Initialized
INFO - 2018-07-16 14:14:16 --> Model Class Initialized
INFO - 2018-07-16 14:14:16 --> Helper loaded: url_helper
INFO - 2018-07-16 14:14:16 --> Model Class Initialized
INFO - 2018-07-16 14:14:16 --> Final output sent to browser
DEBUG - 2018-07-16 14:14:16 --> Total execution time: 0.0538
ERROR - 2018-07-16 14:14:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:14:18 --> Config Class Initialized
INFO - 2018-07-16 14:14:18 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:14:18 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:14:18 --> Utf8 Class Initialized
INFO - 2018-07-16 14:14:18 --> URI Class Initialized
INFO - 2018-07-16 14:14:18 --> Router Class Initialized
INFO - 2018-07-16 14:14:18 --> Output Class Initialized
INFO - 2018-07-16 14:14:18 --> Security Class Initialized
DEBUG - 2018-07-16 14:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:14:18 --> Input Class Initialized
INFO - 2018-07-16 14:14:18 --> Language Class Initialized
INFO - 2018-07-16 14:14:18 --> Loader Class Initialized
INFO - 2018-07-16 14:14:18 --> Controller Class Initialized
INFO - 2018-07-16 14:14:18 --> Database Driver Class Initialized
INFO - 2018-07-16 14:14:18 --> Model Class Initialized
INFO - 2018-07-16 14:14:18 --> Helper loaded: url_helper
INFO - 2018-07-16 14:14:18 --> Model Class Initialized
INFO - 2018-07-16 14:14:18 --> Final output sent to browser
DEBUG - 2018-07-16 14:14:18 --> Total execution time: 0.0391
ERROR - 2018-07-16 14:14:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:14:18 --> Config Class Initialized
INFO - 2018-07-16 14:14:18 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:14:18 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:14:18 --> Utf8 Class Initialized
INFO - 2018-07-16 14:14:18 --> URI Class Initialized
INFO - 2018-07-16 14:14:18 --> Router Class Initialized
INFO - 2018-07-16 14:14:18 --> Output Class Initialized
INFO - 2018-07-16 14:14:18 --> Security Class Initialized
DEBUG - 2018-07-16 14:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:14:18 --> Input Class Initialized
INFO - 2018-07-16 14:14:18 --> Language Class Initialized
INFO - 2018-07-16 14:14:18 --> Loader Class Initialized
INFO - 2018-07-16 14:14:18 --> Controller Class Initialized
INFO - 2018-07-16 14:14:18 --> Database Driver Class Initialized
INFO - 2018-07-16 14:14:18 --> Model Class Initialized
INFO - 2018-07-16 14:14:18 --> Helper loaded: url_helper
INFO - 2018-07-16 14:14:18 --> Model Class Initialized
INFO - 2018-07-16 14:14:18 --> Final output sent to browser
DEBUG - 2018-07-16 14:14:18 --> Total execution time: 0.0388
ERROR - 2018-07-16 14:16:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:16:50 --> Config Class Initialized
INFO - 2018-07-16 14:16:50 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:16:50 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:16:50 --> Utf8 Class Initialized
INFO - 2018-07-16 14:16:50 --> URI Class Initialized
INFO - 2018-07-16 14:16:50 --> Router Class Initialized
INFO - 2018-07-16 14:16:50 --> Output Class Initialized
INFO - 2018-07-16 14:16:50 --> Security Class Initialized
DEBUG - 2018-07-16 14:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:16:50 --> Input Class Initialized
INFO - 2018-07-16 14:16:50 --> Language Class Initialized
INFO - 2018-07-16 14:16:50 --> Loader Class Initialized
INFO - 2018-07-16 14:16:50 --> Controller Class Initialized
INFO - 2018-07-16 14:16:50 --> Database Driver Class Initialized
INFO - 2018-07-16 14:16:50 --> Model Class Initialized
INFO - 2018-07-16 14:16:50 --> Helper loaded: url_helper
INFO - 2018-07-16 14:16:50 --> Model Class Initialized
INFO - 2018-07-16 14:16:50 --> Final output sent to browser
DEBUG - 2018-07-16 14:16:50 --> Total execution time: 0.0345
ERROR - 2018-07-16 14:16:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:16:51 --> Config Class Initialized
INFO - 2018-07-16 14:16:51 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:16:51 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:16:51 --> Utf8 Class Initialized
INFO - 2018-07-16 14:16:51 --> URI Class Initialized
INFO - 2018-07-16 14:16:51 --> Router Class Initialized
INFO - 2018-07-16 14:16:51 --> Output Class Initialized
INFO - 2018-07-16 14:16:51 --> Security Class Initialized
DEBUG - 2018-07-16 14:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:16:51 --> Input Class Initialized
INFO - 2018-07-16 14:16:51 --> Language Class Initialized
INFO - 2018-07-16 14:16:51 --> Loader Class Initialized
INFO - 2018-07-16 14:16:51 --> Controller Class Initialized
INFO - 2018-07-16 14:16:51 --> Database Driver Class Initialized
INFO - 2018-07-16 14:16:51 --> Model Class Initialized
INFO - 2018-07-16 14:16:51 --> Helper loaded: url_helper
INFO - 2018-07-16 14:16:51 --> Model Class Initialized
INFO - 2018-07-16 14:16:51 --> Final output sent to browser
DEBUG - 2018-07-16 14:16:51 --> Total execution time: 0.0402
ERROR - 2018-07-16 14:16:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:16:51 --> Config Class Initialized
INFO - 2018-07-16 14:16:51 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:16:51 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:16:51 --> Utf8 Class Initialized
INFO - 2018-07-16 14:16:51 --> URI Class Initialized
INFO - 2018-07-16 14:16:51 --> Router Class Initialized
INFO - 2018-07-16 14:16:51 --> Output Class Initialized
INFO - 2018-07-16 14:16:51 --> Security Class Initialized
DEBUG - 2018-07-16 14:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:16:51 --> Input Class Initialized
INFO - 2018-07-16 14:16:51 --> Language Class Initialized
INFO - 2018-07-16 14:16:51 --> Loader Class Initialized
INFO - 2018-07-16 14:16:51 --> Controller Class Initialized
INFO - 2018-07-16 14:16:51 --> Database Driver Class Initialized
INFO - 2018-07-16 14:16:51 --> Model Class Initialized
INFO - 2018-07-16 14:16:51 --> Helper loaded: url_helper
INFO - 2018-07-16 14:16:51 --> Model Class Initialized
INFO - 2018-07-16 14:16:51 --> Final output sent to browser
DEBUG - 2018-07-16 14:16:51 --> Total execution time: 0.0371
ERROR - 2018-07-16 14:18:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:18:39 --> Config Class Initialized
INFO - 2018-07-16 14:18:39 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:18:39 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:18:39 --> Utf8 Class Initialized
INFO - 2018-07-16 14:18:39 --> URI Class Initialized
INFO - 2018-07-16 14:18:39 --> Router Class Initialized
INFO - 2018-07-16 14:18:39 --> Output Class Initialized
INFO - 2018-07-16 14:18:39 --> Security Class Initialized
DEBUG - 2018-07-16 14:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:18:39 --> Input Class Initialized
INFO - 2018-07-16 14:18:39 --> Language Class Initialized
INFO - 2018-07-16 14:18:39 --> Loader Class Initialized
INFO - 2018-07-16 14:18:39 --> Controller Class Initialized
INFO - 2018-07-16 14:18:39 --> Database Driver Class Initialized
INFO - 2018-07-16 14:18:39 --> Model Class Initialized
INFO - 2018-07-16 14:18:39 --> Helper loaded: url_helper
INFO - 2018-07-16 14:18:39 --> Model Class Initialized
INFO - 2018-07-16 14:18:39 --> Final output sent to browser
DEBUG - 2018-07-16 14:18:39 --> Total execution time: 0.0391
ERROR - 2018-07-16 14:18:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:18:41 --> Config Class Initialized
INFO - 2018-07-16 14:18:41 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:18:41 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:18:41 --> Utf8 Class Initialized
INFO - 2018-07-16 14:18:41 --> URI Class Initialized
INFO - 2018-07-16 14:18:41 --> Router Class Initialized
INFO - 2018-07-16 14:18:41 --> Output Class Initialized
INFO - 2018-07-16 14:18:41 --> Security Class Initialized
DEBUG - 2018-07-16 14:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:18:41 --> Input Class Initialized
INFO - 2018-07-16 14:18:41 --> Language Class Initialized
INFO - 2018-07-16 14:18:41 --> Loader Class Initialized
INFO - 2018-07-16 14:18:41 --> Controller Class Initialized
INFO - 2018-07-16 14:18:41 --> Database Driver Class Initialized
INFO - 2018-07-16 14:18:41 --> Model Class Initialized
INFO - 2018-07-16 14:18:41 --> Helper loaded: url_helper
INFO - 2018-07-16 14:18:41 --> Model Class Initialized
INFO - 2018-07-16 14:18:41 --> Final output sent to browser
DEBUG - 2018-07-16 14:18:41 --> Total execution time: 0.0358
ERROR - 2018-07-16 14:18:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:18:41 --> Config Class Initialized
INFO - 2018-07-16 14:18:41 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:18:41 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:18:41 --> Utf8 Class Initialized
INFO - 2018-07-16 14:18:41 --> URI Class Initialized
INFO - 2018-07-16 14:18:41 --> Router Class Initialized
INFO - 2018-07-16 14:18:41 --> Output Class Initialized
INFO - 2018-07-16 14:18:41 --> Security Class Initialized
DEBUG - 2018-07-16 14:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:18:41 --> Input Class Initialized
INFO - 2018-07-16 14:18:41 --> Language Class Initialized
INFO - 2018-07-16 14:18:41 --> Loader Class Initialized
INFO - 2018-07-16 14:18:41 --> Controller Class Initialized
INFO - 2018-07-16 14:18:41 --> Database Driver Class Initialized
INFO - 2018-07-16 14:18:41 --> Model Class Initialized
INFO - 2018-07-16 14:18:41 --> Helper loaded: url_helper
INFO - 2018-07-16 14:18:41 --> Model Class Initialized
INFO - 2018-07-16 14:18:41 --> Final output sent to browser
DEBUG - 2018-07-16 14:18:41 --> Total execution time: 0.0411
ERROR - 2018-07-16 14:23:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:23:57 --> Config Class Initialized
INFO - 2018-07-16 14:23:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:23:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:23:57 --> Utf8 Class Initialized
INFO - 2018-07-16 14:23:57 --> URI Class Initialized
INFO - 2018-07-16 14:23:57 --> Router Class Initialized
INFO - 2018-07-16 14:23:57 --> Output Class Initialized
INFO - 2018-07-16 14:23:57 --> Security Class Initialized
DEBUG - 2018-07-16 14:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:23:57 --> Input Class Initialized
INFO - 2018-07-16 14:23:57 --> Language Class Initialized
INFO - 2018-07-16 14:23:57 --> Loader Class Initialized
INFO - 2018-07-16 14:23:57 --> Controller Class Initialized
INFO - 2018-07-16 14:23:57 --> Database Driver Class Initialized
INFO - 2018-07-16 14:23:57 --> Model Class Initialized
INFO - 2018-07-16 14:23:57 --> Helper loaded: url_helper
INFO - 2018-07-16 14:23:57 --> Model Class Initialized
INFO - 2018-07-16 14:23:57 --> Final output sent to browser
DEBUG - 2018-07-16 14:23:57 --> Total execution time: 0.0434
ERROR - 2018-07-16 14:23:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:23:58 --> Config Class Initialized
INFO - 2018-07-16 14:23:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:23:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:23:58 --> Utf8 Class Initialized
INFO - 2018-07-16 14:23:58 --> URI Class Initialized
INFO - 2018-07-16 14:23:58 --> Router Class Initialized
INFO - 2018-07-16 14:23:58 --> Output Class Initialized
INFO - 2018-07-16 14:23:58 --> Security Class Initialized
DEBUG - 2018-07-16 14:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:23:58 --> Input Class Initialized
INFO - 2018-07-16 14:23:58 --> Language Class Initialized
INFO - 2018-07-16 14:23:58 --> Loader Class Initialized
INFO - 2018-07-16 14:23:58 --> Controller Class Initialized
INFO - 2018-07-16 14:23:58 --> Database Driver Class Initialized
INFO - 2018-07-16 14:23:58 --> Model Class Initialized
INFO - 2018-07-16 14:23:58 --> Helper loaded: url_helper
INFO - 2018-07-16 14:23:58 --> Model Class Initialized
INFO - 2018-07-16 14:23:58 --> Final output sent to browser
DEBUG - 2018-07-16 14:23:58 --> Total execution time: 0.0388
ERROR - 2018-07-16 14:23:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:23:58 --> Config Class Initialized
INFO - 2018-07-16 14:23:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:23:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:23:58 --> Utf8 Class Initialized
INFO - 2018-07-16 14:23:58 --> URI Class Initialized
INFO - 2018-07-16 14:23:58 --> Router Class Initialized
INFO - 2018-07-16 14:23:58 --> Output Class Initialized
INFO - 2018-07-16 14:23:58 --> Security Class Initialized
DEBUG - 2018-07-16 14:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:23:58 --> Input Class Initialized
INFO - 2018-07-16 14:23:58 --> Language Class Initialized
INFO - 2018-07-16 14:23:58 --> Loader Class Initialized
INFO - 2018-07-16 14:23:58 --> Controller Class Initialized
INFO - 2018-07-16 14:23:58 --> Database Driver Class Initialized
INFO - 2018-07-16 14:23:58 --> Model Class Initialized
INFO - 2018-07-16 14:23:58 --> Helper loaded: url_helper
INFO - 2018-07-16 14:23:58 --> Model Class Initialized
INFO - 2018-07-16 14:23:58 --> Final output sent to browser
DEBUG - 2018-07-16 14:23:58 --> Total execution time: 0.0404
ERROR - 2018-07-16 14:24:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:24:40 --> Config Class Initialized
INFO - 2018-07-16 14:24:40 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:24:40 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:24:40 --> Utf8 Class Initialized
INFO - 2018-07-16 14:24:40 --> URI Class Initialized
INFO - 2018-07-16 14:24:40 --> Router Class Initialized
INFO - 2018-07-16 14:24:40 --> Output Class Initialized
INFO - 2018-07-16 14:24:40 --> Security Class Initialized
DEBUG - 2018-07-16 14:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:24:40 --> Input Class Initialized
INFO - 2018-07-16 14:24:40 --> Language Class Initialized
INFO - 2018-07-16 14:24:40 --> Loader Class Initialized
INFO - 2018-07-16 14:24:40 --> Controller Class Initialized
INFO - 2018-07-16 14:24:40 --> Database Driver Class Initialized
INFO - 2018-07-16 14:24:40 --> Model Class Initialized
INFO - 2018-07-16 14:24:40 --> Helper loaded: url_helper
INFO - 2018-07-16 14:24:40 --> Model Class Initialized
INFO - 2018-07-16 14:24:40 --> Final output sent to browser
DEBUG - 2018-07-16 14:24:40 --> Total execution time: 0.0343
ERROR - 2018-07-16 14:24:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:24:42 --> Config Class Initialized
INFO - 2018-07-16 14:24:42 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:24:42 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:24:42 --> Utf8 Class Initialized
INFO - 2018-07-16 14:24:42 --> URI Class Initialized
INFO - 2018-07-16 14:24:42 --> Router Class Initialized
INFO - 2018-07-16 14:24:42 --> Output Class Initialized
INFO - 2018-07-16 14:24:42 --> Security Class Initialized
DEBUG - 2018-07-16 14:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:24:42 --> Input Class Initialized
INFO - 2018-07-16 14:24:42 --> Language Class Initialized
INFO - 2018-07-16 14:24:42 --> Loader Class Initialized
INFO - 2018-07-16 14:24:42 --> Controller Class Initialized
INFO - 2018-07-16 14:24:42 --> Database Driver Class Initialized
INFO - 2018-07-16 14:24:42 --> Model Class Initialized
INFO - 2018-07-16 14:24:42 --> Helper loaded: url_helper
INFO - 2018-07-16 14:24:42 --> Model Class Initialized
INFO - 2018-07-16 14:24:42 --> Final output sent to browser
DEBUG - 2018-07-16 14:24:42 --> Total execution time: 0.0417
ERROR - 2018-07-16 14:25:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:25:16 --> Config Class Initialized
INFO - 2018-07-16 14:25:16 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:25:16 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:25:16 --> Utf8 Class Initialized
INFO - 2018-07-16 14:25:16 --> URI Class Initialized
INFO - 2018-07-16 14:25:16 --> Router Class Initialized
INFO - 2018-07-16 14:25:16 --> Output Class Initialized
INFO - 2018-07-16 14:25:16 --> Security Class Initialized
DEBUG - 2018-07-16 14:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:25:16 --> Input Class Initialized
INFO - 2018-07-16 14:25:16 --> Language Class Initialized
INFO - 2018-07-16 14:25:16 --> Loader Class Initialized
INFO - 2018-07-16 14:25:16 --> Controller Class Initialized
INFO - 2018-07-16 14:25:16 --> Database Driver Class Initialized
INFO - 2018-07-16 14:25:16 --> Model Class Initialized
INFO - 2018-07-16 14:25:16 --> Helper loaded: url_helper
INFO - 2018-07-16 14:25:16 --> Model Class Initialized
INFO - 2018-07-16 14:25:16 --> Final output sent to browser
DEBUG - 2018-07-16 14:25:16 --> Total execution time: 0.0383
ERROR - 2018-07-16 14:27:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:27:39 --> Config Class Initialized
INFO - 2018-07-16 14:27:39 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:27:39 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:27:39 --> Utf8 Class Initialized
INFO - 2018-07-16 14:27:39 --> URI Class Initialized
INFO - 2018-07-16 14:27:39 --> Router Class Initialized
INFO - 2018-07-16 14:27:39 --> Output Class Initialized
INFO - 2018-07-16 14:27:39 --> Security Class Initialized
DEBUG - 2018-07-16 14:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:27:39 --> Input Class Initialized
INFO - 2018-07-16 14:27:39 --> Language Class Initialized
INFO - 2018-07-16 14:27:39 --> Loader Class Initialized
INFO - 2018-07-16 14:27:39 --> Controller Class Initialized
INFO - 2018-07-16 14:27:39 --> Database Driver Class Initialized
INFO - 2018-07-16 14:27:39 --> Model Class Initialized
INFO - 2018-07-16 14:27:39 --> Helper loaded: url_helper
INFO - 2018-07-16 14:27:39 --> Model Class Initialized
INFO - 2018-07-16 14:27:39 --> Final output sent to browser
DEBUG - 2018-07-16 14:27:39 --> Total execution time: 0.0456
ERROR - 2018-07-16 14:27:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:27:40 --> Config Class Initialized
INFO - 2018-07-16 14:27:40 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:27:40 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:27:40 --> Utf8 Class Initialized
INFO - 2018-07-16 14:27:40 --> URI Class Initialized
INFO - 2018-07-16 14:27:40 --> Router Class Initialized
INFO - 2018-07-16 14:27:40 --> Output Class Initialized
INFO - 2018-07-16 14:27:40 --> Security Class Initialized
DEBUG - 2018-07-16 14:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:27:40 --> Input Class Initialized
INFO - 2018-07-16 14:27:40 --> Language Class Initialized
INFO - 2018-07-16 14:27:40 --> Loader Class Initialized
INFO - 2018-07-16 14:27:40 --> Controller Class Initialized
INFO - 2018-07-16 14:27:40 --> Database Driver Class Initialized
INFO - 2018-07-16 14:27:40 --> Model Class Initialized
INFO - 2018-07-16 14:27:40 --> Helper loaded: url_helper
INFO - 2018-07-16 14:27:40 --> Model Class Initialized
INFO - 2018-07-16 14:27:40 --> Final output sent to browser
DEBUG - 2018-07-16 14:27:40 --> Total execution time: 0.0362
ERROR - 2018-07-16 14:27:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:27:40 --> Config Class Initialized
INFO - 2018-07-16 14:27:40 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:27:40 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:27:40 --> Utf8 Class Initialized
INFO - 2018-07-16 14:27:40 --> URI Class Initialized
INFO - 2018-07-16 14:27:40 --> Router Class Initialized
INFO - 2018-07-16 14:27:40 --> Output Class Initialized
INFO - 2018-07-16 14:27:40 --> Security Class Initialized
DEBUG - 2018-07-16 14:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:27:40 --> Input Class Initialized
INFO - 2018-07-16 14:27:40 --> Language Class Initialized
INFO - 2018-07-16 14:27:40 --> Loader Class Initialized
INFO - 2018-07-16 14:27:40 --> Controller Class Initialized
INFO - 2018-07-16 14:27:40 --> Database Driver Class Initialized
INFO - 2018-07-16 14:27:40 --> Model Class Initialized
INFO - 2018-07-16 14:27:40 --> Helper loaded: url_helper
INFO - 2018-07-16 14:27:40 --> Model Class Initialized
INFO - 2018-07-16 14:27:40 --> Final output sent to browser
DEBUG - 2018-07-16 14:27:40 --> Total execution time: 0.0403
ERROR - 2018-07-16 14:29:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:29:20 --> Config Class Initialized
INFO - 2018-07-16 14:29:20 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:29:20 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:29:20 --> Utf8 Class Initialized
INFO - 2018-07-16 14:29:20 --> URI Class Initialized
INFO - 2018-07-16 14:29:20 --> Router Class Initialized
INFO - 2018-07-16 14:29:20 --> Output Class Initialized
INFO - 2018-07-16 14:29:20 --> Security Class Initialized
DEBUG - 2018-07-16 14:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:29:20 --> Input Class Initialized
INFO - 2018-07-16 14:29:20 --> Language Class Initialized
INFO - 2018-07-16 14:29:20 --> Loader Class Initialized
INFO - 2018-07-16 14:29:20 --> Controller Class Initialized
INFO - 2018-07-16 14:29:20 --> Database Driver Class Initialized
INFO - 2018-07-16 14:29:20 --> Model Class Initialized
INFO - 2018-07-16 14:29:20 --> Helper loaded: url_helper
INFO - 2018-07-16 14:29:20 --> Model Class Initialized
INFO - 2018-07-16 14:29:20 --> Final output sent to browser
DEBUG - 2018-07-16 14:29:20 --> Total execution time: 0.0476
ERROR - 2018-07-16 14:29:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:29:44 --> Config Class Initialized
INFO - 2018-07-16 14:29:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:29:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:29:44 --> Utf8 Class Initialized
INFO - 2018-07-16 14:29:44 --> URI Class Initialized
INFO - 2018-07-16 14:29:44 --> Router Class Initialized
INFO - 2018-07-16 14:29:44 --> Output Class Initialized
INFO - 2018-07-16 14:29:44 --> Security Class Initialized
DEBUG - 2018-07-16 14:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:29:44 --> Input Class Initialized
INFO - 2018-07-16 14:29:44 --> Language Class Initialized
INFO - 2018-07-16 14:29:44 --> Loader Class Initialized
INFO - 2018-07-16 14:29:44 --> Controller Class Initialized
INFO - 2018-07-16 14:29:44 --> Database Driver Class Initialized
INFO - 2018-07-16 14:29:44 --> Model Class Initialized
INFO - 2018-07-16 14:29:44 --> Helper loaded: url_helper
INFO - 2018-07-16 14:29:44 --> Model Class Initialized
INFO - 2018-07-16 14:29:44 --> Final output sent to browser
DEBUG - 2018-07-16 14:29:44 --> Total execution time: 0.0455
ERROR - 2018-07-16 14:29:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:29:45 --> Config Class Initialized
INFO - 2018-07-16 14:29:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:29:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:29:45 --> Utf8 Class Initialized
INFO - 2018-07-16 14:29:45 --> URI Class Initialized
INFO - 2018-07-16 14:29:45 --> Router Class Initialized
INFO - 2018-07-16 14:29:45 --> Output Class Initialized
INFO - 2018-07-16 14:29:45 --> Security Class Initialized
DEBUG - 2018-07-16 14:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:29:45 --> Input Class Initialized
INFO - 2018-07-16 14:29:45 --> Language Class Initialized
INFO - 2018-07-16 14:29:45 --> Loader Class Initialized
INFO - 2018-07-16 14:29:45 --> Controller Class Initialized
INFO - 2018-07-16 14:29:45 --> Database Driver Class Initialized
INFO - 2018-07-16 14:29:45 --> Model Class Initialized
INFO - 2018-07-16 14:29:45 --> Helper loaded: url_helper
INFO - 2018-07-16 14:29:45 --> Model Class Initialized
INFO - 2018-07-16 14:29:45 --> Final output sent to browser
DEBUG - 2018-07-16 14:29:45 --> Total execution time: 0.0367
ERROR - 2018-07-16 14:29:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:29:45 --> Config Class Initialized
INFO - 2018-07-16 14:29:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:29:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:29:45 --> Utf8 Class Initialized
INFO - 2018-07-16 14:29:45 --> URI Class Initialized
INFO - 2018-07-16 14:29:45 --> Router Class Initialized
INFO - 2018-07-16 14:29:45 --> Output Class Initialized
INFO - 2018-07-16 14:29:45 --> Security Class Initialized
DEBUG - 2018-07-16 14:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:29:45 --> Input Class Initialized
INFO - 2018-07-16 14:29:45 --> Language Class Initialized
INFO - 2018-07-16 14:29:45 --> Loader Class Initialized
INFO - 2018-07-16 14:29:45 --> Controller Class Initialized
INFO - 2018-07-16 14:29:45 --> Database Driver Class Initialized
INFO - 2018-07-16 14:29:45 --> Model Class Initialized
INFO - 2018-07-16 14:29:45 --> Helper loaded: url_helper
INFO - 2018-07-16 14:29:45 --> Model Class Initialized
INFO - 2018-07-16 14:29:45 --> Final output sent to browser
DEBUG - 2018-07-16 14:29:45 --> Total execution time: 0.0391
ERROR - 2018-07-16 14:32:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:32:47 --> Config Class Initialized
INFO - 2018-07-16 14:32:47 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:32:47 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:32:47 --> Utf8 Class Initialized
INFO - 2018-07-16 14:32:47 --> URI Class Initialized
INFO - 2018-07-16 14:32:47 --> Router Class Initialized
INFO - 2018-07-16 14:32:47 --> Output Class Initialized
INFO - 2018-07-16 14:32:47 --> Security Class Initialized
DEBUG - 2018-07-16 14:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:32:47 --> Input Class Initialized
INFO - 2018-07-16 14:32:47 --> Language Class Initialized
INFO - 2018-07-16 14:32:47 --> Loader Class Initialized
INFO - 2018-07-16 14:32:47 --> Controller Class Initialized
INFO - 2018-07-16 14:32:47 --> Database Driver Class Initialized
INFO - 2018-07-16 14:32:47 --> Model Class Initialized
INFO - 2018-07-16 14:32:47 --> Helper loaded: url_helper
INFO - 2018-07-16 14:32:47 --> Model Class Initialized
INFO - 2018-07-16 14:32:47 --> Final output sent to browser
DEBUG - 2018-07-16 14:32:47 --> Total execution time: 0.0448
ERROR - 2018-07-16 14:32:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:32:48 --> Config Class Initialized
INFO - 2018-07-16 14:32:48 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:32:48 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:32:48 --> Utf8 Class Initialized
INFO - 2018-07-16 14:32:48 --> URI Class Initialized
INFO - 2018-07-16 14:32:48 --> Router Class Initialized
INFO - 2018-07-16 14:32:48 --> Output Class Initialized
INFO - 2018-07-16 14:32:48 --> Security Class Initialized
DEBUG - 2018-07-16 14:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:32:48 --> Input Class Initialized
INFO - 2018-07-16 14:32:48 --> Language Class Initialized
INFO - 2018-07-16 14:32:48 --> Loader Class Initialized
INFO - 2018-07-16 14:32:48 --> Controller Class Initialized
INFO - 2018-07-16 14:32:48 --> Database Driver Class Initialized
INFO - 2018-07-16 14:32:48 --> Model Class Initialized
INFO - 2018-07-16 14:32:48 --> Helper loaded: url_helper
INFO - 2018-07-16 14:32:48 --> Model Class Initialized
INFO - 2018-07-16 14:32:48 --> Final output sent to browser
DEBUG - 2018-07-16 14:32:48 --> Total execution time: 0.0377
ERROR - 2018-07-16 14:32:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:32:48 --> Config Class Initialized
INFO - 2018-07-16 14:32:48 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:32:48 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:32:48 --> Utf8 Class Initialized
INFO - 2018-07-16 14:32:48 --> URI Class Initialized
INFO - 2018-07-16 14:32:48 --> Router Class Initialized
INFO - 2018-07-16 14:32:48 --> Output Class Initialized
INFO - 2018-07-16 14:32:48 --> Security Class Initialized
DEBUG - 2018-07-16 14:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:32:48 --> Input Class Initialized
INFO - 2018-07-16 14:32:48 --> Language Class Initialized
INFO - 2018-07-16 14:32:48 --> Loader Class Initialized
INFO - 2018-07-16 14:32:48 --> Controller Class Initialized
INFO - 2018-07-16 14:32:48 --> Database Driver Class Initialized
INFO - 2018-07-16 14:32:48 --> Model Class Initialized
INFO - 2018-07-16 14:32:48 --> Helper loaded: url_helper
INFO - 2018-07-16 14:32:48 --> Model Class Initialized
INFO - 2018-07-16 14:32:48 --> Final output sent to browser
DEBUG - 2018-07-16 14:32:48 --> Total execution time: 0.0418
ERROR - 2018-07-16 14:34:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:34:53 --> Config Class Initialized
INFO - 2018-07-16 14:34:53 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:34:53 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:34:53 --> Utf8 Class Initialized
INFO - 2018-07-16 14:34:53 --> URI Class Initialized
INFO - 2018-07-16 14:34:53 --> Router Class Initialized
INFO - 2018-07-16 14:34:53 --> Output Class Initialized
INFO - 2018-07-16 14:34:53 --> Security Class Initialized
DEBUG - 2018-07-16 14:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:34:53 --> Input Class Initialized
INFO - 2018-07-16 14:34:53 --> Language Class Initialized
INFO - 2018-07-16 14:34:53 --> Loader Class Initialized
INFO - 2018-07-16 14:34:53 --> Controller Class Initialized
INFO - 2018-07-16 14:34:53 --> Database Driver Class Initialized
INFO - 2018-07-16 14:34:53 --> Model Class Initialized
INFO - 2018-07-16 14:34:53 --> Helper loaded: url_helper
INFO - 2018-07-16 14:34:53 --> Model Class Initialized
INFO - 2018-07-16 14:34:53 --> Final output sent to browser
DEBUG - 2018-07-16 14:34:53 --> Total execution time: 0.0682
ERROR - 2018-07-16 14:34:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:34:54 --> Config Class Initialized
INFO - 2018-07-16 14:34:54 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:34:54 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:34:54 --> Utf8 Class Initialized
INFO - 2018-07-16 14:34:54 --> URI Class Initialized
INFO - 2018-07-16 14:34:54 --> Router Class Initialized
INFO - 2018-07-16 14:34:54 --> Output Class Initialized
INFO - 2018-07-16 14:34:54 --> Security Class Initialized
DEBUG - 2018-07-16 14:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:34:54 --> Input Class Initialized
INFO - 2018-07-16 14:34:54 --> Language Class Initialized
INFO - 2018-07-16 14:34:54 --> Loader Class Initialized
INFO - 2018-07-16 14:34:54 --> Controller Class Initialized
INFO - 2018-07-16 14:34:54 --> Database Driver Class Initialized
INFO - 2018-07-16 14:34:54 --> Model Class Initialized
INFO - 2018-07-16 14:34:54 --> Helper loaded: url_helper
INFO - 2018-07-16 14:34:54 --> Model Class Initialized
INFO - 2018-07-16 14:34:54 --> Final output sent to browser
DEBUG - 2018-07-16 14:34:54 --> Total execution time: 0.0375
ERROR - 2018-07-16 14:34:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:34:55 --> Config Class Initialized
INFO - 2018-07-16 14:34:55 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:34:55 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:34:55 --> Utf8 Class Initialized
INFO - 2018-07-16 14:34:55 --> URI Class Initialized
INFO - 2018-07-16 14:34:55 --> Router Class Initialized
INFO - 2018-07-16 14:34:55 --> Output Class Initialized
INFO - 2018-07-16 14:34:55 --> Security Class Initialized
DEBUG - 2018-07-16 14:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:34:55 --> Input Class Initialized
INFO - 2018-07-16 14:34:55 --> Language Class Initialized
INFO - 2018-07-16 14:34:55 --> Loader Class Initialized
INFO - 2018-07-16 14:34:55 --> Controller Class Initialized
INFO - 2018-07-16 14:34:55 --> Database Driver Class Initialized
INFO - 2018-07-16 14:34:55 --> Model Class Initialized
INFO - 2018-07-16 14:34:55 --> Helper loaded: url_helper
INFO - 2018-07-16 14:34:55 --> Model Class Initialized
INFO - 2018-07-16 14:34:55 --> Final output sent to browser
DEBUG - 2018-07-16 14:34:55 --> Total execution time: 0.0389
ERROR - 2018-07-16 14:35:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:35:44 --> Config Class Initialized
INFO - 2018-07-16 14:35:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:35:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:35:44 --> Utf8 Class Initialized
INFO - 2018-07-16 14:35:44 --> URI Class Initialized
INFO - 2018-07-16 14:35:44 --> Router Class Initialized
INFO - 2018-07-16 14:35:44 --> Output Class Initialized
INFO - 2018-07-16 14:35:44 --> Security Class Initialized
DEBUG - 2018-07-16 14:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:35:44 --> Input Class Initialized
INFO - 2018-07-16 14:35:44 --> Language Class Initialized
INFO - 2018-07-16 14:35:44 --> Loader Class Initialized
INFO - 2018-07-16 14:35:44 --> Controller Class Initialized
INFO - 2018-07-16 14:35:44 --> Database Driver Class Initialized
INFO - 2018-07-16 14:35:44 --> Model Class Initialized
INFO - 2018-07-16 14:35:44 --> Helper loaded: url_helper
INFO - 2018-07-16 14:35:44 --> Model Class Initialized
INFO - 2018-07-16 14:35:44 --> Final output sent to browser
DEBUG - 2018-07-16 14:35:44 --> Total execution time: 0.0477
ERROR - 2018-07-16 14:35:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:35:45 --> Config Class Initialized
INFO - 2018-07-16 14:35:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:35:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:35:45 --> Utf8 Class Initialized
INFO - 2018-07-16 14:35:45 --> URI Class Initialized
INFO - 2018-07-16 14:35:45 --> Router Class Initialized
INFO - 2018-07-16 14:35:45 --> Output Class Initialized
INFO - 2018-07-16 14:35:45 --> Security Class Initialized
DEBUG - 2018-07-16 14:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:35:45 --> Input Class Initialized
INFO - 2018-07-16 14:35:45 --> Language Class Initialized
INFO - 2018-07-16 14:35:45 --> Loader Class Initialized
INFO - 2018-07-16 14:35:45 --> Controller Class Initialized
INFO - 2018-07-16 14:35:45 --> Database Driver Class Initialized
INFO - 2018-07-16 14:35:45 --> Model Class Initialized
INFO - 2018-07-16 14:35:45 --> Helper loaded: url_helper
INFO - 2018-07-16 14:35:45 --> Model Class Initialized
INFO - 2018-07-16 14:35:45 --> Final output sent to browser
DEBUG - 2018-07-16 14:35:45 --> Total execution time: 0.0438
ERROR - 2018-07-16 14:35:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:35:45 --> Config Class Initialized
INFO - 2018-07-16 14:35:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:35:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:35:45 --> Utf8 Class Initialized
INFO - 2018-07-16 14:35:45 --> URI Class Initialized
INFO - 2018-07-16 14:35:45 --> Router Class Initialized
INFO - 2018-07-16 14:35:45 --> Output Class Initialized
INFO - 2018-07-16 14:35:45 --> Security Class Initialized
DEBUG - 2018-07-16 14:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:35:45 --> Input Class Initialized
INFO - 2018-07-16 14:35:45 --> Language Class Initialized
INFO - 2018-07-16 14:35:45 --> Loader Class Initialized
INFO - 2018-07-16 14:35:45 --> Controller Class Initialized
INFO - 2018-07-16 14:35:45 --> Database Driver Class Initialized
INFO - 2018-07-16 14:35:45 --> Model Class Initialized
INFO - 2018-07-16 14:35:45 --> Helper loaded: url_helper
INFO - 2018-07-16 14:35:45 --> Model Class Initialized
INFO - 2018-07-16 14:35:45 --> Final output sent to browser
DEBUG - 2018-07-16 14:35:45 --> Total execution time: 0.0372
ERROR - 2018-07-16 14:36:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:36:28 --> Config Class Initialized
INFO - 2018-07-16 14:36:28 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:36:28 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:36:28 --> Utf8 Class Initialized
INFO - 2018-07-16 14:36:28 --> URI Class Initialized
INFO - 2018-07-16 14:36:28 --> Router Class Initialized
INFO - 2018-07-16 14:36:28 --> Output Class Initialized
INFO - 2018-07-16 14:36:28 --> Security Class Initialized
DEBUG - 2018-07-16 14:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:36:28 --> Input Class Initialized
INFO - 2018-07-16 14:36:28 --> Language Class Initialized
INFO - 2018-07-16 14:36:28 --> Loader Class Initialized
INFO - 2018-07-16 14:36:28 --> Controller Class Initialized
INFO - 2018-07-16 14:36:28 --> Database Driver Class Initialized
INFO - 2018-07-16 14:36:28 --> Model Class Initialized
INFO - 2018-07-16 14:36:28 --> Helper loaded: url_helper
INFO - 2018-07-16 14:36:28 --> Model Class Initialized
INFO - 2018-07-16 14:36:28 --> Final output sent to browser
DEBUG - 2018-07-16 14:36:28 --> Total execution time: 0.0425
ERROR - 2018-07-16 14:36:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:36:30 --> Config Class Initialized
INFO - 2018-07-16 14:36:30 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:36:30 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:36:30 --> Utf8 Class Initialized
INFO - 2018-07-16 14:36:30 --> URI Class Initialized
INFO - 2018-07-16 14:36:30 --> Router Class Initialized
INFO - 2018-07-16 14:36:30 --> Output Class Initialized
INFO - 2018-07-16 14:36:30 --> Security Class Initialized
DEBUG - 2018-07-16 14:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:36:30 --> Input Class Initialized
INFO - 2018-07-16 14:36:30 --> Language Class Initialized
INFO - 2018-07-16 14:36:30 --> Loader Class Initialized
INFO - 2018-07-16 14:36:30 --> Controller Class Initialized
INFO - 2018-07-16 14:36:30 --> Database Driver Class Initialized
INFO - 2018-07-16 14:36:30 --> Model Class Initialized
INFO - 2018-07-16 14:36:30 --> Helper loaded: url_helper
INFO - 2018-07-16 14:36:30 --> Model Class Initialized
INFO - 2018-07-16 14:36:30 --> Final output sent to browser
DEBUG - 2018-07-16 14:36:30 --> Total execution time: 0.0526
ERROR - 2018-07-16 14:36:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:36:30 --> Config Class Initialized
INFO - 2018-07-16 14:36:30 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:36:30 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:36:30 --> Utf8 Class Initialized
INFO - 2018-07-16 14:36:30 --> URI Class Initialized
INFO - 2018-07-16 14:36:30 --> Router Class Initialized
INFO - 2018-07-16 14:36:30 --> Output Class Initialized
INFO - 2018-07-16 14:36:30 --> Security Class Initialized
DEBUG - 2018-07-16 14:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:36:30 --> Input Class Initialized
INFO - 2018-07-16 14:36:30 --> Language Class Initialized
INFO - 2018-07-16 14:36:30 --> Loader Class Initialized
INFO - 2018-07-16 14:36:30 --> Controller Class Initialized
INFO - 2018-07-16 14:36:30 --> Database Driver Class Initialized
INFO - 2018-07-16 14:36:30 --> Model Class Initialized
INFO - 2018-07-16 14:36:30 --> Helper loaded: url_helper
INFO - 2018-07-16 14:36:30 --> Model Class Initialized
INFO - 2018-07-16 14:36:30 --> Final output sent to browser
DEBUG - 2018-07-16 14:36:30 --> Total execution time: 0.0444
ERROR - 2018-07-16 14:40:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:40:11 --> Config Class Initialized
INFO - 2018-07-16 14:40:11 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:40:11 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:40:11 --> Utf8 Class Initialized
INFO - 2018-07-16 14:40:11 --> URI Class Initialized
INFO - 2018-07-16 14:40:11 --> Router Class Initialized
INFO - 2018-07-16 14:40:11 --> Output Class Initialized
INFO - 2018-07-16 14:40:11 --> Security Class Initialized
DEBUG - 2018-07-16 14:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:40:11 --> Input Class Initialized
INFO - 2018-07-16 14:40:11 --> Language Class Initialized
INFO - 2018-07-16 14:40:11 --> Loader Class Initialized
INFO - 2018-07-16 14:40:11 --> Controller Class Initialized
INFO - 2018-07-16 14:40:11 --> Database Driver Class Initialized
INFO - 2018-07-16 14:40:11 --> Model Class Initialized
INFO - 2018-07-16 14:40:11 --> Helper loaded: url_helper
INFO - 2018-07-16 14:40:11 --> Model Class Initialized
INFO - 2018-07-16 14:40:11 --> Final output sent to browser
DEBUG - 2018-07-16 14:40:11 --> Total execution time: 0.0514
ERROR - 2018-07-16 14:40:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:40:12 --> Config Class Initialized
INFO - 2018-07-16 14:40:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:40:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:40:12 --> Utf8 Class Initialized
INFO - 2018-07-16 14:40:12 --> URI Class Initialized
INFO - 2018-07-16 14:40:12 --> Router Class Initialized
INFO - 2018-07-16 14:40:12 --> Output Class Initialized
INFO - 2018-07-16 14:40:12 --> Security Class Initialized
DEBUG - 2018-07-16 14:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:40:12 --> Input Class Initialized
INFO - 2018-07-16 14:40:12 --> Language Class Initialized
INFO - 2018-07-16 14:40:12 --> Loader Class Initialized
INFO - 2018-07-16 14:40:12 --> Controller Class Initialized
INFO - 2018-07-16 14:40:12 --> Database Driver Class Initialized
INFO - 2018-07-16 14:40:12 --> Model Class Initialized
INFO - 2018-07-16 14:40:12 --> Helper loaded: url_helper
INFO - 2018-07-16 14:40:12 --> Model Class Initialized
INFO - 2018-07-16 14:40:12 --> Final output sent to browser
DEBUG - 2018-07-16 14:40:12 --> Total execution time: 0.0586
ERROR - 2018-07-16 14:40:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:40:12 --> Config Class Initialized
INFO - 2018-07-16 14:40:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:40:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:40:12 --> Utf8 Class Initialized
INFO - 2018-07-16 14:40:12 --> URI Class Initialized
INFO - 2018-07-16 14:40:12 --> Router Class Initialized
INFO - 2018-07-16 14:40:12 --> Output Class Initialized
INFO - 2018-07-16 14:40:12 --> Security Class Initialized
DEBUG - 2018-07-16 14:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:40:12 --> Input Class Initialized
INFO - 2018-07-16 14:40:12 --> Language Class Initialized
INFO - 2018-07-16 14:40:12 --> Loader Class Initialized
INFO - 2018-07-16 14:40:12 --> Controller Class Initialized
INFO - 2018-07-16 14:40:12 --> Database Driver Class Initialized
INFO - 2018-07-16 14:40:12 --> Model Class Initialized
INFO - 2018-07-16 14:40:12 --> Helper loaded: url_helper
INFO - 2018-07-16 14:40:12 --> Model Class Initialized
INFO - 2018-07-16 14:40:12 --> Final output sent to browser
DEBUG - 2018-07-16 14:40:12 --> Total execution time: 0.0358
ERROR - 2018-07-16 14:40:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:40:16 --> Config Class Initialized
INFO - 2018-07-16 14:40:16 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:40:16 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:40:16 --> Utf8 Class Initialized
INFO - 2018-07-16 14:40:16 --> URI Class Initialized
INFO - 2018-07-16 14:40:16 --> Router Class Initialized
INFO - 2018-07-16 14:40:16 --> Output Class Initialized
INFO - 2018-07-16 14:40:16 --> Security Class Initialized
DEBUG - 2018-07-16 14:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:40:16 --> Input Class Initialized
INFO - 2018-07-16 14:40:16 --> Language Class Initialized
INFO - 2018-07-16 14:40:16 --> Loader Class Initialized
INFO - 2018-07-16 14:40:16 --> Controller Class Initialized
INFO - 2018-07-16 14:40:16 --> Database Driver Class Initialized
INFO - 2018-07-16 14:40:16 --> Model Class Initialized
INFO - 2018-07-16 14:40:16 --> Helper loaded: url_helper
INFO - 2018-07-16 14:40:16 --> Model Class Initialized
INFO - 2018-07-16 14:40:16 --> Final output sent to browser
DEBUG - 2018-07-16 14:40:16 --> Total execution time: 0.0494
ERROR - 2018-07-16 14:40:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:40:42 --> Config Class Initialized
INFO - 2018-07-16 14:40:42 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:40:42 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:40:42 --> Utf8 Class Initialized
INFO - 2018-07-16 14:40:42 --> URI Class Initialized
INFO - 2018-07-16 14:40:42 --> Router Class Initialized
INFO - 2018-07-16 14:40:42 --> Output Class Initialized
INFO - 2018-07-16 14:40:42 --> Security Class Initialized
DEBUG - 2018-07-16 14:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:40:42 --> Input Class Initialized
INFO - 2018-07-16 14:40:42 --> Language Class Initialized
INFO - 2018-07-16 14:40:42 --> Loader Class Initialized
INFO - 2018-07-16 14:40:42 --> Controller Class Initialized
INFO - 2018-07-16 14:40:42 --> Database Driver Class Initialized
INFO - 2018-07-16 14:40:42 --> Model Class Initialized
INFO - 2018-07-16 14:40:42 --> Helper loaded: url_helper
INFO - 2018-07-16 14:40:42 --> Model Class Initialized
INFO - 2018-07-16 14:40:42 --> Final output sent to browser
DEBUG - 2018-07-16 14:40:42 --> Total execution time: 0.0484
ERROR - 2018-07-16 14:40:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:40:52 --> Config Class Initialized
INFO - 2018-07-16 14:40:52 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:40:52 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:40:52 --> Utf8 Class Initialized
INFO - 2018-07-16 14:40:52 --> URI Class Initialized
INFO - 2018-07-16 14:40:52 --> Router Class Initialized
INFO - 2018-07-16 14:40:52 --> Output Class Initialized
INFO - 2018-07-16 14:40:52 --> Security Class Initialized
DEBUG - 2018-07-16 14:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:40:52 --> Input Class Initialized
INFO - 2018-07-16 14:40:52 --> Language Class Initialized
INFO - 2018-07-16 14:40:52 --> Loader Class Initialized
INFO - 2018-07-16 14:40:52 --> Controller Class Initialized
INFO - 2018-07-16 14:40:52 --> Database Driver Class Initialized
INFO - 2018-07-16 14:40:52 --> Model Class Initialized
INFO - 2018-07-16 14:40:52 --> Helper loaded: url_helper
INFO - 2018-07-16 14:40:52 --> Model Class Initialized
INFO - 2018-07-16 14:40:52 --> Final output sent to browser
DEBUG - 2018-07-16 14:40:52 --> Total execution time: 0.0397
ERROR - 2018-07-16 14:42:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:42:00 --> Config Class Initialized
INFO - 2018-07-16 14:42:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:42:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:42:00 --> Utf8 Class Initialized
INFO - 2018-07-16 14:42:00 --> URI Class Initialized
INFO - 2018-07-16 14:42:00 --> Router Class Initialized
INFO - 2018-07-16 14:42:00 --> Output Class Initialized
INFO - 2018-07-16 14:42:00 --> Security Class Initialized
DEBUG - 2018-07-16 14:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:42:00 --> Input Class Initialized
INFO - 2018-07-16 14:42:00 --> Language Class Initialized
INFO - 2018-07-16 14:42:00 --> Loader Class Initialized
INFO - 2018-07-16 14:42:00 --> Controller Class Initialized
INFO - 2018-07-16 14:42:00 --> Database Driver Class Initialized
INFO - 2018-07-16 14:42:00 --> Model Class Initialized
INFO - 2018-07-16 14:42:00 --> Helper loaded: url_helper
INFO - 2018-07-16 14:42:00 --> Model Class Initialized
INFO - 2018-07-16 14:42:00 --> Final output sent to browser
DEBUG - 2018-07-16 14:42:00 --> Total execution time: 0.0527
ERROR - 2018-07-16 14:42:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:42:01 --> Config Class Initialized
INFO - 2018-07-16 14:42:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:42:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:42:01 --> Utf8 Class Initialized
INFO - 2018-07-16 14:42:01 --> URI Class Initialized
INFO - 2018-07-16 14:42:01 --> Router Class Initialized
INFO - 2018-07-16 14:42:01 --> Output Class Initialized
INFO - 2018-07-16 14:42:01 --> Security Class Initialized
DEBUG - 2018-07-16 14:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:42:01 --> Input Class Initialized
INFO - 2018-07-16 14:42:01 --> Language Class Initialized
INFO - 2018-07-16 14:42:01 --> Loader Class Initialized
INFO - 2018-07-16 14:42:01 --> Controller Class Initialized
INFO - 2018-07-16 14:42:01 --> Database Driver Class Initialized
INFO - 2018-07-16 14:42:01 --> Model Class Initialized
INFO - 2018-07-16 14:42:01 --> Helper loaded: url_helper
INFO - 2018-07-16 14:42:01 --> Model Class Initialized
INFO - 2018-07-16 14:42:01 --> Final output sent to browser
DEBUG - 2018-07-16 14:42:01 --> Total execution time: 0.0453
ERROR - 2018-07-16 14:42:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:42:01 --> Config Class Initialized
INFO - 2018-07-16 14:42:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:42:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:42:01 --> Utf8 Class Initialized
INFO - 2018-07-16 14:42:01 --> URI Class Initialized
INFO - 2018-07-16 14:42:01 --> Router Class Initialized
INFO - 2018-07-16 14:42:01 --> Output Class Initialized
INFO - 2018-07-16 14:42:01 --> Security Class Initialized
DEBUG - 2018-07-16 14:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:42:01 --> Input Class Initialized
INFO - 2018-07-16 14:42:01 --> Language Class Initialized
INFO - 2018-07-16 14:42:01 --> Loader Class Initialized
INFO - 2018-07-16 14:42:01 --> Controller Class Initialized
INFO - 2018-07-16 14:42:01 --> Database Driver Class Initialized
INFO - 2018-07-16 14:42:01 --> Model Class Initialized
INFO - 2018-07-16 14:42:01 --> Helper loaded: url_helper
INFO - 2018-07-16 14:42:01 --> Model Class Initialized
INFO - 2018-07-16 14:42:01 --> Final output sent to browser
DEBUG - 2018-07-16 14:42:01 --> Total execution time: 0.0470
ERROR - 2018-07-16 14:53:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:53:12 --> Config Class Initialized
INFO - 2018-07-16 14:53:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:53:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:53:12 --> Utf8 Class Initialized
INFO - 2018-07-16 14:53:12 --> URI Class Initialized
INFO - 2018-07-16 14:53:12 --> Router Class Initialized
INFO - 2018-07-16 14:53:12 --> Output Class Initialized
INFO - 2018-07-16 14:53:12 --> Security Class Initialized
DEBUG - 2018-07-16 14:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:53:12 --> Input Class Initialized
INFO - 2018-07-16 14:53:12 --> Language Class Initialized
INFO - 2018-07-16 14:53:12 --> Loader Class Initialized
INFO - 2018-07-16 14:53:12 --> Controller Class Initialized
INFO - 2018-07-16 14:53:12 --> Database Driver Class Initialized
INFO - 2018-07-16 14:53:12 --> Model Class Initialized
INFO - 2018-07-16 14:53:12 --> Helper loaded: url_helper
INFO - 2018-07-16 14:53:12 --> Model Class Initialized
INFO - 2018-07-16 14:53:12 --> Final output sent to browser
DEBUG - 2018-07-16 14:53:12 --> Total execution time: 0.0482
ERROR - 2018-07-16 14:53:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:53:12 --> Config Class Initialized
INFO - 2018-07-16 14:53:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:53:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:53:12 --> Utf8 Class Initialized
INFO - 2018-07-16 14:53:12 --> URI Class Initialized
INFO - 2018-07-16 14:53:12 --> Router Class Initialized
INFO - 2018-07-16 14:53:12 --> Output Class Initialized
INFO - 2018-07-16 14:53:12 --> Security Class Initialized
DEBUG - 2018-07-16 14:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:53:12 --> Input Class Initialized
INFO - 2018-07-16 14:53:12 --> Language Class Initialized
INFO - 2018-07-16 14:53:12 --> Loader Class Initialized
INFO - 2018-07-16 14:53:12 --> Controller Class Initialized
INFO - 2018-07-16 14:53:12 --> Database Driver Class Initialized
INFO - 2018-07-16 14:53:12 --> Model Class Initialized
INFO - 2018-07-16 14:53:12 --> Helper loaded: url_helper
INFO - 2018-07-16 14:53:12 --> Model Class Initialized
INFO - 2018-07-16 14:53:12 --> Final output sent to browser
DEBUG - 2018-07-16 14:53:12 --> Total execution time: 0.0430
ERROR - 2018-07-16 14:53:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:53:12 --> Config Class Initialized
INFO - 2018-07-16 14:53:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:53:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:53:12 --> Utf8 Class Initialized
INFO - 2018-07-16 14:53:12 --> URI Class Initialized
INFO - 2018-07-16 14:53:12 --> Router Class Initialized
INFO - 2018-07-16 14:53:12 --> Output Class Initialized
INFO - 2018-07-16 14:53:12 --> Security Class Initialized
DEBUG - 2018-07-16 14:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:53:12 --> Input Class Initialized
INFO - 2018-07-16 14:53:12 --> Language Class Initialized
INFO - 2018-07-16 14:53:12 --> Loader Class Initialized
INFO - 2018-07-16 14:53:12 --> Controller Class Initialized
INFO - 2018-07-16 14:53:12 --> Database Driver Class Initialized
INFO - 2018-07-16 14:53:12 --> Model Class Initialized
INFO - 2018-07-16 14:53:12 --> Helper loaded: url_helper
INFO - 2018-07-16 14:53:12 --> Model Class Initialized
INFO - 2018-07-16 14:53:12 --> Final output sent to browser
DEBUG - 2018-07-16 14:53:12 --> Total execution time: 0.0355
ERROR - 2018-07-16 14:55:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:55:09 --> Config Class Initialized
INFO - 2018-07-16 14:55:09 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:55:09 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:55:09 --> Utf8 Class Initialized
INFO - 2018-07-16 14:55:09 --> URI Class Initialized
INFO - 2018-07-16 14:55:09 --> Router Class Initialized
INFO - 2018-07-16 14:55:09 --> Output Class Initialized
INFO - 2018-07-16 14:55:09 --> Security Class Initialized
DEBUG - 2018-07-16 14:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:55:09 --> Input Class Initialized
INFO - 2018-07-16 14:55:09 --> Language Class Initialized
INFO - 2018-07-16 14:55:09 --> Loader Class Initialized
INFO - 2018-07-16 14:55:09 --> Controller Class Initialized
INFO - 2018-07-16 14:55:09 --> Database Driver Class Initialized
INFO - 2018-07-16 14:55:09 --> Model Class Initialized
INFO - 2018-07-16 14:55:09 --> Helper loaded: url_helper
INFO - 2018-07-16 14:55:09 --> Model Class Initialized
INFO - 2018-07-16 14:55:09 --> Final output sent to browser
DEBUG - 2018-07-16 14:55:09 --> Total execution time: 0.0554
ERROR - 2018-07-16 14:55:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:55:09 --> Config Class Initialized
INFO - 2018-07-16 14:55:09 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:55:09 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:55:09 --> Utf8 Class Initialized
INFO - 2018-07-16 14:55:09 --> URI Class Initialized
INFO - 2018-07-16 14:55:09 --> Router Class Initialized
INFO - 2018-07-16 14:55:09 --> Output Class Initialized
INFO - 2018-07-16 14:55:09 --> Security Class Initialized
DEBUG - 2018-07-16 14:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:55:09 --> Input Class Initialized
INFO - 2018-07-16 14:55:09 --> Language Class Initialized
INFO - 2018-07-16 14:55:09 --> Loader Class Initialized
INFO - 2018-07-16 14:55:09 --> Controller Class Initialized
INFO - 2018-07-16 14:55:09 --> Database Driver Class Initialized
INFO - 2018-07-16 14:55:09 --> Model Class Initialized
INFO - 2018-07-16 14:55:09 --> Helper loaded: url_helper
INFO - 2018-07-16 14:55:09 --> Model Class Initialized
INFO - 2018-07-16 14:55:09 --> Final output sent to browser
DEBUG - 2018-07-16 14:55:09 --> Total execution time: 0.0797
ERROR - 2018-07-16 14:55:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 14:55:09 --> Config Class Initialized
INFO - 2018-07-16 14:55:09 --> Hooks Class Initialized
DEBUG - 2018-07-16 14:55:09 --> UTF-8 Support Enabled
INFO - 2018-07-16 14:55:09 --> Utf8 Class Initialized
INFO - 2018-07-16 14:55:09 --> URI Class Initialized
INFO - 2018-07-16 14:55:09 --> Router Class Initialized
INFO - 2018-07-16 14:55:09 --> Output Class Initialized
INFO - 2018-07-16 14:55:09 --> Security Class Initialized
DEBUG - 2018-07-16 14:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 14:55:09 --> Input Class Initialized
INFO - 2018-07-16 14:55:09 --> Language Class Initialized
INFO - 2018-07-16 14:55:09 --> Loader Class Initialized
INFO - 2018-07-16 14:55:09 --> Controller Class Initialized
INFO - 2018-07-16 14:55:09 --> Database Driver Class Initialized
INFO - 2018-07-16 14:55:09 --> Model Class Initialized
INFO - 2018-07-16 14:55:09 --> Helper loaded: url_helper
INFO - 2018-07-16 14:55:09 --> Model Class Initialized
INFO - 2018-07-16 14:55:09 --> Final output sent to browser
DEBUG - 2018-07-16 14:55:09 --> Total execution time: 0.0687
ERROR - 2018-07-16 16:41:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 16:41:55 --> Config Class Initialized
INFO - 2018-07-16 16:41:55 --> Hooks Class Initialized
DEBUG - 2018-07-16 16:41:55 --> UTF-8 Support Enabled
INFO - 2018-07-16 16:41:55 --> Utf8 Class Initialized
INFO - 2018-07-16 16:41:55 --> URI Class Initialized
INFO - 2018-07-16 16:41:55 --> Router Class Initialized
INFO - 2018-07-16 16:41:55 --> Output Class Initialized
INFO - 2018-07-16 16:41:55 --> Security Class Initialized
DEBUG - 2018-07-16 16:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 16:41:55 --> Input Class Initialized
INFO - 2018-07-16 16:41:55 --> Language Class Initialized
INFO - 2018-07-16 16:41:55 --> Loader Class Initialized
INFO - 2018-07-16 16:41:55 --> Controller Class Initialized
INFO - 2018-07-16 16:41:55 --> Database Driver Class Initialized
INFO - 2018-07-16 16:41:55 --> Model Class Initialized
INFO - 2018-07-16 16:41:55 --> Helper loaded: url_helper
INFO - 2018-07-16 16:41:55 --> Model Class Initialized
INFO - 2018-07-16 16:41:55 --> Final output sent to browser
DEBUG - 2018-07-16 16:41:55 --> Total execution time: 0.0364
ERROR - 2018-07-16 16:41:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 16:41:56 --> Config Class Initialized
INFO - 2018-07-16 16:41:56 --> Hooks Class Initialized
DEBUG - 2018-07-16 16:41:56 --> UTF-8 Support Enabled
INFO - 2018-07-16 16:41:56 --> Utf8 Class Initialized
INFO - 2018-07-16 16:41:56 --> URI Class Initialized
INFO - 2018-07-16 16:41:56 --> Router Class Initialized
INFO - 2018-07-16 16:41:56 --> Output Class Initialized
INFO - 2018-07-16 16:41:56 --> Security Class Initialized
DEBUG - 2018-07-16 16:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 16:41:56 --> Input Class Initialized
INFO - 2018-07-16 16:41:56 --> Language Class Initialized
INFO - 2018-07-16 16:41:56 --> Loader Class Initialized
INFO - 2018-07-16 16:41:56 --> Controller Class Initialized
INFO - 2018-07-16 16:41:56 --> Database Driver Class Initialized
INFO - 2018-07-16 16:41:56 --> Model Class Initialized
INFO - 2018-07-16 16:41:56 --> Helper loaded: url_helper
INFO - 2018-07-16 16:41:56 --> Model Class Initialized
INFO - 2018-07-16 16:41:56 --> Final output sent to browser
DEBUG - 2018-07-16 16:41:56 --> Total execution time: 0.0391
ERROR - 2018-07-16 16:41:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 16:41:56 --> Config Class Initialized
INFO - 2018-07-16 16:41:56 --> Hooks Class Initialized
DEBUG - 2018-07-16 16:41:56 --> UTF-8 Support Enabled
INFO - 2018-07-16 16:41:56 --> Utf8 Class Initialized
INFO - 2018-07-16 16:41:56 --> URI Class Initialized
INFO - 2018-07-16 16:41:56 --> Router Class Initialized
INFO - 2018-07-16 16:41:56 --> Output Class Initialized
INFO - 2018-07-16 16:41:56 --> Security Class Initialized
DEBUG - 2018-07-16 16:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 16:41:56 --> Input Class Initialized
INFO - 2018-07-16 16:41:56 --> Language Class Initialized
INFO - 2018-07-16 16:41:56 --> Loader Class Initialized
INFO - 2018-07-16 16:41:56 --> Controller Class Initialized
INFO - 2018-07-16 16:41:56 --> Database Driver Class Initialized
INFO - 2018-07-16 16:41:56 --> Model Class Initialized
INFO - 2018-07-16 16:41:56 --> Helper loaded: url_helper
INFO - 2018-07-16 16:41:56 --> Model Class Initialized
INFO - 2018-07-16 16:41:56 --> Final output sent to browser
DEBUG - 2018-07-16 16:41:56 --> Total execution time: 0.0405
ERROR - 2018-07-16 16:42:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 16:42:57 --> Config Class Initialized
INFO - 2018-07-16 16:42:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 16:42:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 16:42:58 --> Utf8 Class Initialized
INFO - 2018-07-16 16:42:58 --> URI Class Initialized
INFO - 2018-07-16 16:42:58 --> Router Class Initialized
INFO - 2018-07-16 16:42:58 --> Output Class Initialized
INFO - 2018-07-16 16:42:58 --> Security Class Initialized
DEBUG - 2018-07-16 16:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 16:42:58 --> Input Class Initialized
INFO - 2018-07-16 16:42:58 --> Language Class Initialized
INFO - 2018-07-16 16:42:58 --> Loader Class Initialized
INFO - 2018-07-16 16:42:58 --> Controller Class Initialized
INFO - 2018-07-16 16:42:58 --> Database Driver Class Initialized
INFO - 2018-07-16 16:42:58 --> Model Class Initialized
INFO - 2018-07-16 16:42:58 --> Helper loaded: url_helper
INFO - 2018-07-16 16:42:58 --> Model Class Initialized
INFO - 2018-07-16 16:42:58 --> Final output sent to browser
DEBUG - 2018-07-16 16:42:58 --> Total execution time: 0.0399
ERROR - 2018-07-16 16:42:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 16:42:58 --> Config Class Initialized
INFO - 2018-07-16 16:42:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 16:42:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 16:42:58 --> Utf8 Class Initialized
INFO - 2018-07-16 16:42:58 --> URI Class Initialized
INFO - 2018-07-16 16:42:58 --> Router Class Initialized
INFO - 2018-07-16 16:42:58 --> Output Class Initialized
INFO - 2018-07-16 16:42:58 --> Security Class Initialized
DEBUG - 2018-07-16 16:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 16:42:58 --> Input Class Initialized
INFO - 2018-07-16 16:42:58 --> Language Class Initialized
INFO - 2018-07-16 16:42:58 --> Loader Class Initialized
INFO - 2018-07-16 16:42:58 --> Controller Class Initialized
INFO - 2018-07-16 16:42:58 --> Database Driver Class Initialized
INFO - 2018-07-16 16:42:58 --> Model Class Initialized
INFO - 2018-07-16 16:42:58 --> Helper loaded: url_helper
INFO - 2018-07-16 16:42:58 --> Model Class Initialized
INFO - 2018-07-16 16:42:58 --> Final output sent to browser
DEBUG - 2018-07-16 16:42:58 --> Total execution time: 0.0530
ERROR - 2018-07-16 16:42:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 16:42:58 --> Config Class Initialized
INFO - 2018-07-16 16:42:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 16:42:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 16:42:58 --> Utf8 Class Initialized
INFO - 2018-07-16 16:42:58 --> URI Class Initialized
INFO - 2018-07-16 16:42:58 --> Router Class Initialized
INFO - 2018-07-16 16:42:58 --> Output Class Initialized
INFO - 2018-07-16 16:42:58 --> Security Class Initialized
DEBUG - 2018-07-16 16:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 16:42:58 --> Input Class Initialized
INFO - 2018-07-16 16:42:58 --> Language Class Initialized
INFO - 2018-07-16 16:42:58 --> Loader Class Initialized
INFO - 2018-07-16 16:42:58 --> Controller Class Initialized
INFO - 2018-07-16 16:42:58 --> Database Driver Class Initialized
INFO - 2018-07-16 16:42:58 --> Model Class Initialized
INFO - 2018-07-16 16:42:58 --> Helper loaded: url_helper
INFO - 2018-07-16 16:42:58 --> Model Class Initialized
INFO - 2018-07-16 16:42:58 --> Final output sent to browser
DEBUG - 2018-07-16 16:42:58 --> Total execution time: 0.0495
ERROR - 2018-07-16 16:43:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 16:43:44 --> Config Class Initialized
INFO - 2018-07-16 16:43:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 16:43:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 16:43:44 --> Utf8 Class Initialized
INFO - 2018-07-16 16:43:44 --> URI Class Initialized
INFO - 2018-07-16 16:43:44 --> Router Class Initialized
INFO - 2018-07-16 16:43:44 --> Output Class Initialized
INFO - 2018-07-16 16:43:44 --> Security Class Initialized
DEBUG - 2018-07-16 16:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 16:43:44 --> Input Class Initialized
INFO - 2018-07-16 16:43:44 --> Language Class Initialized
INFO - 2018-07-16 16:43:44 --> Loader Class Initialized
INFO - 2018-07-16 16:43:44 --> Controller Class Initialized
INFO - 2018-07-16 16:43:44 --> Database Driver Class Initialized
INFO - 2018-07-16 16:43:44 --> Model Class Initialized
INFO - 2018-07-16 16:43:44 --> Helper loaded: url_helper
INFO - 2018-07-16 16:43:44 --> Model Class Initialized
INFO - 2018-07-16 16:43:44 --> Final output sent to browser
DEBUG - 2018-07-16 16:43:44 --> Total execution time: 0.0871
ERROR - 2018-07-16 16:43:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 16:43:44 --> Config Class Initialized
INFO - 2018-07-16 16:43:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 16:43:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 16:43:44 --> Utf8 Class Initialized
INFO - 2018-07-16 16:43:44 --> URI Class Initialized
INFO - 2018-07-16 16:43:44 --> Router Class Initialized
INFO - 2018-07-16 16:43:44 --> Output Class Initialized
INFO - 2018-07-16 16:43:44 --> Security Class Initialized
DEBUG - 2018-07-16 16:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 16:43:44 --> Input Class Initialized
INFO - 2018-07-16 16:43:44 --> Language Class Initialized
INFO - 2018-07-16 16:43:44 --> Loader Class Initialized
INFO - 2018-07-16 16:43:44 --> Controller Class Initialized
INFO - 2018-07-16 16:43:44 --> Database Driver Class Initialized
INFO - 2018-07-16 16:43:44 --> Model Class Initialized
INFO - 2018-07-16 16:43:44 --> Helper loaded: url_helper
INFO - 2018-07-16 16:43:44 --> Model Class Initialized
INFO - 2018-07-16 16:43:44 --> Final output sent to browser
DEBUG - 2018-07-16 16:43:44 --> Total execution time: 0.0592
ERROR - 2018-07-16 16:43:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 16:43:44 --> Config Class Initialized
INFO - 2018-07-16 16:43:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 16:43:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 16:43:44 --> Utf8 Class Initialized
INFO - 2018-07-16 16:43:44 --> URI Class Initialized
INFO - 2018-07-16 16:43:44 --> Router Class Initialized
INFO - 2018-07-16 16:43:44 --> Output Class Initialized
INFO - 2018-07-16 16:43:44 --> Security Class Initialized
DEBUG - 2018-07-16 16:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 16:43:44 --> Input Class Initialized
INFO - 2018-07-16 16:43:44 --> Language Class Initialized
INFO - 2018-07-16 16:43:44 --> Loader Class Initialized
INFO - 2018-07-16 16:43:44 --> Controller Class Initialized
INFO - 2018-07-16 16:43:44 --> Database Driver Class Initialized
INFO - 2018-07-16 16:43:44 --> Model Class Initialized
INFO - 2018-07-16 16:43:44 --> Helper loaded: url_helper
INFO - 2018-07-16 16:43:44 --> Model Class Initialized
INFO - 2018-07-16 16:43:44 --> Final output sent to browser
DEBUG - 2018-07-16 16:43:44 --> Total execution time: 0.0636
ERROR - 2018-07-16 16:46:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 16:46:17 --> Config Class Initialized
INFO - 2018-07-16 16:46:17 --> Hooks Class Initialized
DEBUG - 2018-07-16 16:46:17 --> UTF-8 Support Enabled
INFO - 2018-07-16 16:46:17 --> Utf8 Class Initialized
INFO - 2018-07-16 16:46:17 --> URI Class Initialized
INFO - 2018-07-16 16:46:17 --> Router Class Initialized
INFO - 2018-07-16 16:46:17 --> Output Class Initialized
INFO - 2018-07-16 16:46:17 --> Security Class Initialized
DEBUG - 2018-07-16 16:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 16:46:17 --> Input Class Initialized
INFO - 2018-07-16 16:46:17 --> Language Class Initialized
INFO - 2018-07-16 16:46:17 --> Loader Class Initialized
INFO - 2018-07-16 16:46:17 --> Controller Class Initialized
INFO - 2018-07-16 16:46:17 --> Database Driver Class Initialized
INFO - 2018-07-16 16:46:17 --> Model Class Initialized
INFO - 2018-07-16 16:46:17 --> Helper loaded: url_helper
INFO - 2018-07-16 16:46:17 --> Model Class Initialized
INFO - 2018-07-16 16:46:17 --> Final output sent to browser
DEBUG - 2018-07-16 16:46:17 --> Total execution time: 0.0752
ERROR - 2018-07-16 16:46:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 16:46:17 --> Config Class Initialized
INFO - 2018-07-16 16:46:17 --> Hooks Class Initialized
DEBUG - 2018-07-16 16:46:17 --> UTF-8 Support Enabled
INFO - 2018-07-16 16:46:17 --> Utf8 Class Initialized
INFO - 2018-07-16 16:46:17 --> URI Class Initialized
INFO - 2018-07-16 16:46:17 --> Router Class Initialized
INFO - 2018-07-16 16:46:17 --> Output Class Initialized
INFO - 2018-07-16 16:46:17 --> Security Class Initialized
DEBUG - 2018-07-16 16:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 16:46:17 --> Input Class Initialized
INFO - 2018-07-16 16:46:17 --> Language Class Initialized
INFO - 2018-07-16 16:46:17 --> Loader Class Initialized
INFO - 2018-07-16 16:46:17 --> Controller Class Initialized
INFO - 2018-07-16 16:46:17 --> Database Driver Class Initialized
INFO - 2018-07-16 16:46:17 --> Model Class Initialized
INFO - 2018-07-16 16:46:17 --> Helper loaded: url_helper
INFO - 2018-07-16 16:46:17 --> Model Class Initialized
INFO - 2018-07-16 16:46:17 --> Final output sent to browser
DEBUG - 2018-07-16 16:46:17 --> Total execution time: 0.0653
ERROR - 2018-07-16 16:46:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 16:46:17 --> Config Class Initialized
INFO - 2018-07-16 16:46:17 --> Hooks Class Initialized
DEBUG - 2018-07-16 16:46:17 --> UTF-8 Support Enabled
INFO - 2018-07-16 16:46:17 --> Utf8 Class Initialized
INFO - 2018-07-16 16:46:17 --> URI Class Initialized
INFO - 2018-07-16 16:46:17 --> Router Class Initialized
INFO - 2018-07-16 16:46:17 --> Output Class Initialized
INFO - 2018-07-16 16:46:17 --> Security Class Initialized
DEBUG - 2018-07-16 16:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 16:46:17 --> Input Class Initialized
INFO - 2018-07-16 16:46:17 --> Language Class Initialized
INFO - 2018-07-16 16:46:17 --> Loader Class Initialized
INFO - 2018-07-16 16:46:17 --> Controller Class Initialized
INFO - 2018-07-16 16:46:17 --> Database Driver Class Initialized
INFO - 2018-07-16 16:46:17 --> Model Class Initialized
INFO - 2018-07-16 16:46:17 --> Helper loaded: url_helper
INFO - 2018-07-16 16:46:17 --> Model Class Initialized
INFO - 2018-07-16 16:46:17 --> Final output sent to browser
DEBUG - 2018-07-16 16:46:17 --> Total execution time: 0.0659
ERROR - 2018-07-16 16:47:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 16:47:14 --> Config Class Initialized
INFO - 2018-07-16 16:47:14 --> Hooks Class Initialized
DEBUG - 2018-07-16 16:47:14 --> UTF-8 Support Enabled
INFO - 2018-07-16 16:47:14 --> Utf8 Class Initialized
INFO - 2018-07-16 16:47:14 --> URI Class Initialized
INFO - 2018-07-16 16:47:14 --> Router Class Initialized
INFO - 2018-07-16 16:47:14 --> Output Class Initialized
INFO - 2018-07-16 16:47:14 --> Security Class Initialized
DEBUG - 2018-07-16 16:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 16:47:14 --> Input Class Initialized
INFO - 2018-07-16 16:47:14 --> Language Class Initialized
INFO - 2018-07-16 16:47:14 --> Loader Class Initialized
INFO - 2018-07-16 16:47:14 --> Controller Class Initialized
INFO - 2018-07-16 16:47:14 --> Database Driver Class Initialized
INFO - 2018-07-16 16:47:14 --> Model Class Initialized
INFO - 2018-07-16 16:47:14 --> Helper loaded: url_helper
INFO - 2018-07-16 16:47:14 --> Model Class Initialized
INFO - 2018-07-16 16:47:14 --> Final output sent to browser
DEBUG - 2018-07-16 16:47:14 --> Total execution time: 0.0552
ERROR - 2018-07-16 16:47:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 16:47:14 --> Config Class Initialized
INFO - 2018-07-16 16:47:14 --> Hooks Class Initialized
DEBUG - 2018-07-16 16:47:14 --> UTF-8 Support Enabled
INFO - 2018-07-16 16:47:14 --> Utf8 Class Initialized
INFO - 2018-07-16 16:47:14 --> URI Class Initialized
INFO - 2018-07-16 16:47:14 --> Router Class Initialized
INFO - 2018-07-16 16:47:14 --> Output Class Initialized
INFO - 2018-07-16 16:47:14 --> Security Class Initialized
DEBUG - 2018-07-16 16:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 16:47:14 --> Input Class Initialized
INFO - 2018-07-16 16:47:14 --> Language Class Initialized
INFO - 2018-07-16 16:47:14 --> Loader Class Initialized
INFO - 2018-07-16 16:47:14 --> Controller Class Initialized
INFO - 2018-07-16 16:47:14 --> Database Driver Class Initialized
INFO - 2018-07-16 16:47:14 --> Model Class Initialized
INFO - 2018-07-16 16:47:14 --> Helper loaded: url_helper
INFO - 2018-07-16 16:47:14 --> Model Class Initialized
INFO - 2018-07-16 16:47:14 --> Final output sent to browser
DEBUG - 2018-07-16 16:47:14 --> Total execution time: 0.0547
ERROR - 2018-07-16 16:47:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 16:47:14 --> Config Class Initialized
INFO - 2018-07-16 16:47:14 --> Hooks Class Initialized
DEBUG - 2018-07-16 16:47:14 --> UTF-8 Support Enabled
INFO - 2018-07-16 16:47:14 --> Utf8 Class Initialized
INFO - 2018-07-16 16:47:14 --> URI Class Initialized
INFO - 2018-07-16 16:47:14 --> Router Class Initialized
INFO - 2018-07-16 16:47:14 --> Output Class Initialized
INFO - 2018-07-16 16:47:14 --> Security Class Initialized
DEBUG - 2018-07-16 16:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 16:47:14 --> Input Class Initialized
INFO - 2018-07-16 16:47:14 --> Language Class Initialized
INFO - 2018-07-16 16:47:14 --> Loader Class Initialized
INFO - 2018-07-16 16:47:14 --> Controller Class Initialized
INFO - 2018-07-16 16:47:14 --> Database Driver Class Initialized
INFO - 2018-07-16 16:47:14 --> Model Class Initialized
INFO - 2018-07-16 16:47:14 --> Helper loaded: url_helper
INFO - 2018-07-16 16:47:14 --> Model Class Initialized
INFO - 2018-07-16 16:47:14 --> Final output sent to browser
DEBUG - 2018-07-16 16:47:14 --> Total execution time: 0.0712
ERROR - 2018-07-16 17:58:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 17:58:17 --> Config Class Initialized
INFO - 2018-07-16 17:58:17 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:58:17 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:58:17 --> Utf8 Class Initialized
INFO - 2018-07-16 17:58:17 --> URI Class Initialized
INFO - 2018-07-16 17:58:17 --> Router Class Initialized
INFO - 2018-07-16 17:58:17 --> Output Class Initialized
INFO - 2018-07-16 17:58:17 --> Security Class Initialized
DEBUG - 2018-07-16 17:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:58:17 --> Input Class Initialized
INFO - 2018-07-16 17:58:17 --> Language Class Initialized
INFO - 2018-07-16 17:58:17 --> Loader Class Initialized
INFO - 2018-07-16 17:58:17 --> Controller Class Initialized
INFO - 2018-07-16 17:58:17 --> Database Driver Class Initialized
INFO - 2018-07-16 17:58:17 --> Model Class Initialized
INFO - 2018-07-16 17:58:17 --> Helper loaded: url_helper
INFO - 2018-07-16 17:58:17 --> Model Class Initialized
INFO - 2018-07-16 17:58:17 --> Final output sent to browser
DEBUG - 2018-07-16 17:58:17 --> Total execution time: 0.0512
ERROR - 2018-07-16 17:58:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 17:58:19 --> Config Class Initialized
INFO - 2018-07-16 17:58:19 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:58:19 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:58:19 --> Utf8 Class Initialized
INFO - 2018-07-16 17:58:19 --> URI Class Initialized
INFO - 2018-07-16 17:58:19 --> Router Class Initialized
INFO - 2018-07-16 17:58:19 --> Output Class Initialized
INFO - 2018-07-16 17:58:19 --> Security Class Initialized
DEBUG - 2018-07-16 17:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:58:19 --> Input Class Initialized
INFO - 2018-07-16 17:58:19 --> Language Class Initialized
INFO - 2018-07-16 17:58:19 --> Loader Class Initialized
INFO - 2018-07-16 17:58:19 --> Controller Class Initialized
INFO - 2018-07-16 17:58:19 --> Database Driver Class Initialized
INFO - 2018-07-16 17:58:19 --> Model Class Initialized
INFO - 2018-07-16 17:58:19 --> Helper loaded: url_helper
INFO - 2018-07-16 17:58:19 --> Model Class Initialized
INFO - 2018-07-16 17:58:19 --> Final output sent to browser
DEBUG - 2018-07-16 17:58:19 --> Total execution time: 0.0362
ERROR - 2018-07-16 17:58:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 17:58:19 --> Config Class Initialized
INFO - 2018-07-16 17:58:19 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:58:19 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:58:19 --> Utf8 Class Initialized
INFO - 2018-07-16 17:58:19 --> URI Class Initialized
INFO - 2018-07-16 17:58:19 --> Router Class Initialized
INFO - 2018-07-16 17:58:19 --> Output Class Initialized
INFO - 2018-07-16 17:58:19 --> Security Class Initialized
DEBUG - 2018-07-16 17:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:58:19 --> Input Class Initialized
INFO - 2018-07-16 17:58:19 --> Language Class Initialized
INFO - 2018-07-16 17:58:19 --> Loader Class Initialized
INFO - 2018-07-16 17:58:19 --> Controller Class Initialized
INFO - 2018-07-16 17:58:19 --> Database Driver Class Initialized
INFO - 2018-07-16 17:58:19 --> Model Class Initialized
INFO - 2018-07-16 17:58:19 --> Helper loaded: url_helper
INFO - 2018-07-16 17:58:19 --> Model Class Initialized
INFO - 2018-07-16 17:58:19 --> Final output sent to browser
DEBUG - 2018-07-16 17:58:19 --> Total execution time: 0.0368
ERROR - 2018-07-16 17:59:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 17:59:30 --> Config Class Initialized
INFO - 2018-07-16 17:59:30 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:59:30 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:59:30 --> Utf8 Class Initialized
INFO - 2018-07-16 17:59:30 --> URI Class Initialized
INFO - 2018-07-16 17:59:30 --> Router Class Initialized
INFO - 2018-07-16 17:59:30 --> Output Class Initialized
INFO - 2018-07-16 17:59:30 --> Security Class Initialized
DEBUG - 2018-07-16 17:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:59:30 --> Input Class Initialized
INFO - 2018-07-16 17:59:30 --> Language Class Initialized
INFO - 2018-07-16 17:59:30 --> Loader Class Initialized
INFO - 2018-07-16 17:59:30 --> Controller Class Initialized
INFO - 2018-07-16 17:59:30 --> Database Driver Class Initialized
INFO - 2018-07-16 17:59:30 --> Model Class Initialized
INFO - 2018-07-16 17:59:30 --> Helper loaded: url_helper
INFO - 2018-07-16 17:59:30 --> Model Class Initialized
INFO - 2018-07-16 17:59:30 --> Final output sent to browser
DEBUG - 2018-07-16 17:59:30 --> Total execution time: 0.0518
ERROR - 2018-07-16 17:59:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 17:59:30 --> Config Class Initialized
INFO - 2018-07-16 17:59:30 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:59:30 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:59:30 --> Utf8 Class Initialized
INFO - 2018-07-16 17:59:30 --> URI Class Initialized
INFO - 2018-07-16 17:59:30 --> Router Class Initialized
INFO - 2018-07-16 17:59:30 --> Output Class Initialized
INFO - 2018-07-16 17:59:30 --> Security Class Initialized
DEBUG - 2018-07-16 17:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:59:30 --> Input Class Initialized
INFO - 2018-07-16 17:59:30 --> Language Class Initialized
INFO - 2018-07-16 17:59:30 --> Loader Class Initialized
INFO - 2018-07-16 17:59:30 --> Controller Class Initialized
INFO - 2018-07-16 17:59:30 --> Database Driver Class Initialized
INFO - 2018-07-16 17:59:30 --> Model Class Initialized
INFO - 2018-07-16 17:59:30 --> Helper loaded: url_helper
INFO - 2018-07-16 17:59:30 --> Model Class Initialized
INFO - 2018-07-16 17:59:30 --> Final output sent to browser
DEBUG - 2018-07-16 17:59:30 --> Total execution time: 0.0357
ERROR - 2018-07-16 17:59:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 17:59:30 --> Config Class Initialized
INFO - 2018-07-16 17:59:30 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:59:30 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:59:30 --> Utf8 Class Initialized
INFO - 2018-07-16 17:59:30 --> URI Class Initialized
INFO - 2018-07-16 17:59:30 --> Router Class Initialized
INFO - 2018-07-16 17:59:30 --> Output Class Initialized
INFO - 2018-07-16 17:59:30 --> Security Class Initialized
DEBUG - 2018-07-16 17:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:59:30 --> Input Class Initialized
INFO - 2018-07-16 17:59:30 --> Language Class Initialized
INFO - 2018-07-16 17:59:31 --> Loader Class Initialized
INFO - 2018-07-16 17:59:31 --> Controller Class Initialized
INFO - 2018-07-16 17:59:31 --> Database Driver Class Initialized
INFO - 2018-07-16 17:59:31 --> Model Class Initialized
INFO - 2018-07-16 17:59:31 --> Helper loaded: url_helper
INFO - 2018-07-16 17:59:31 --> Model Class Initialized
INFO - 2018-07-16 17:59:31 --> Final output sent to browser
DEBUG - 2018-07-16 17:59:31 --> Total execution time: 0.0546
ERROR - 2018-07-16 17:59:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 17:59:56 --> Config Class Initialized
INFO - 2018-07-16 17:59:56 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:59:56 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:59:56 --> Utf8 Class Initialized
INFO - 2018-07-16 17:59:56 --> URI Class Initialized
INFO - 2018-07-16 17:59:56 --> Router Class Initialized
INFO - 2018-07-16 17:59:56 --> Output Class Initialized
INFO - 2018-07-16 17:59:56 --> Security Class Initialized
DEBUG - 2018-07-16 17:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:59:56 --> Input Class Initialized
INFO - 2018-07-16 17:59:56 --> Language Class Initialized
INFO - 2018-07-16 17:59:56 --> Loader Class Initialized
INFO - 2018-07-16 17:59:56 --> Controller Class Initialized
INFO - 2018-07-16 17:59:56 --> Database Driver Class Initialized
INFO - 2018-07-16 17:59:56 --> Model Class Initialized
INFO - 2018-07-16 17:59:56 --> Helper loaded: url_helper
DEBUG - 2018-07-16 17:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 17:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 17:59:56 --> Model Class Initialized
INFO - 2018-07-16 17:59:56 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 17:59:56 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 17:59:56 --> Final output sent to browser
DEBUG - 2018-07-16 17:59:56 --> Total execution time: 0.0707
ERROR - 2018-07-16 17:59:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 17:59:59 --> Config Class Initialized
INFO - 2018-07-16 17:59:59 --> Hooks Class Initialized
DEBUG - 2018-07-16 17:59:59 --> UTF-8 Support Enabled
INFO - 2018-07-16 17:59:59 --> Utf8 Class Initialized
INFO - 2018-07-16 17:59:59 --> URI Class Initialized
INFO - 2018-07-16 17:59:59 --> Router Class Initialized
INFO - 2018-07-16 17:59:59 --> Output Class Initialized
INFO - 2018-07-16 17:59:59 --> Security Class Initialized
DEBUG - 2018-07-16 17:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 17:59:59 --> Input Class Initialized
INFO - 2018-07-16 17:59:59 --> Language Class Initialized
INFO - 2018-07-16 17:59:59 --> Loader Class Initialized
INFO - 2018-07-16 17:59:59 --> Controller Class Initialized
INFO - 2018-07-16 17:59:59 --> Database Driver Class Initialized
INFO - 2018-07-16 17:59:59 --> Model Class Initialized
INFO - 2018-07-16 17:59:59 --> Helper loaded: url_helper
DEBUG - 2018-07-16 17:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 17:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 17:59:59 --> Model Class Initialized
INFO - 2018-07-16 17:59:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 17:59:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 17:59:59 --> Final output sent to browser
DEBUG - 2018-07-16 17:59:59 --> Total execution time: 0.0878
ERROR - 2018-07-16 18:00:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:00:00 --> Config Class Initialized
INFO - 2018-07-16 18:00:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:00:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:00:00 --> Utf8 Class Initialized
INFO - 2018-07-16 18:00:00 --> URI Class Initialized
INFO - 2018-07-16 18:00:00 --> Router Class Initialized
INFO - 2018-07-16 18:00:00 --> Output Class Initialized
INFO - 2018-07-16 18:00:00 --> Security Class Initialized
DEBUG - 2018-07-16 18:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:00:00 --> Input Class Initialized
INFO - 2018-07-16 18:00:00 --> Language Class Initialized
INFO - 2018-07-16 18:00:00 --> Loader Class Initialized
INFO - 2018-07-16 18:00:00 --> Controller Class Initialized
INFO - 2018-07-16 18:00:00 --> Database Driver Class Initialized
INFO - 2018-07-16 18:00:00 --> Model Class Initialized
INFO - 2018-07-16 18:00:00 --> Helper loaded: url_helper
DEBUG - 2018-07-16 18:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 18:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 18:00:00 --> Model Class Initialized
INFO - 2018-07-16 18:00:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 18:00:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 18:00:00 --> Final output sent to browser
DEBUG - 2018-07-16 18:00:00 --> Total execution time: 0.0479
ERROR - 2018-07-16 18:00:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:00:20 --> Config Class Initialized
INFO - 2018-07-16 18:00:20 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:00:20 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:00:20 --> Utf8 Class Initialized
INFO - 2018-07-16 18:00:20 --> URI Class Initialized
INFO - 2018-07-16 18:00:20 --> Router Class Initialized
INFO - 2018-07-16 18:00:20 --> Output Class Initialized
INFO - 2018-07-16 18:00:20 --> Security Class Initialized
DEBUG - 2018-07-16 18:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:00:20 --> Input Class Initialized
INFO - 2018-07-16 18:00:20 --> Language Class Initialized
INFO - 2018-07-16 18:00:20 --> Loader Class Initialized
INFO - 2018-07-16 18:00:20 --> Controller Class Initialized
INFO - 2018-07-16 18:00:20 --> Database Driver Class Initialized
INFO - 2018-07-16 18:00:20 --> Model Class Initialized
INFO - 2018-07-16 18:00:20 --> Helper loaded: url_helper
INFO - 2018-07-16 18:00:20 --> Model Class Initialized
INFO - 2018-07-16 18:00:20 --> Final output sent to browser
DEBUG - 2018-07-16 18:00:20 --> Total execution time: 0.0575
ERROR - 2018-07-16 18:00:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:00:20 --> Config Class Initialized
INFO - 2018-07-16 18:00:20 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:00:20 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:00:20 --> Utf8 Class Initialized
INFO - 2018-07-16 18:00:20 --> URI Class Initialized
INFO - 2018-07-16 18:00:20 --> Router Class Initialized
INFO - 2018-07-16 18:00:20 --> Output Class Initialized
INFO - 2018-07-16 18:00:20 --> Security Class Initialized
DEBUG - 2018-07-16 18:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:00:20 --> Input Class Initialized
INFO - 2018-07-16 18:00:20 --> Language Class Initialized
INFO - 2018-07-16 18:00:20 --> Loader Class Initialized
INFO - 2018-07-16 18:00:20 --> Controller Class Initialized
INFO - 2018-07-16 18:00:20 --> Database Driver Class Initialized
INFO - 2018-07-16 18:00:20 --> Model Class Initialized
INFO - 2018-07-16 18:00:20 --> Helper loaded: url_helper
INFO - 2018-07-16 18:00:20 --> Model Class Initialized
INFO - 2018-07-16 18:00:20 --> Final output sent to browser
DEBUG - 2018-07-16 18:00:20 --> Total execution time: 0.0362
ERROR - 2018-07-16 18:00:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:00:20 --> Config Class Initialized
INFO - 2018-07-16 18:00:20 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:00:20 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:00:20 --> Utf8 Class Initialized
INFO - 2018-07-16 18:00:20 --> URI Class Initialized
INFO - 2018-07-16 18:00:20 --> Router Class Initialized
INFO - 2018-07-16 18:00:20 --> Output Class Initialized
INFO - 2018-07-16 18:00:20 --> Security Class Initialized
DEBUG - 2018-07-16 18:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:00:20 --> Input Class Initialized
INFO - 2018-07-16 18:00:20 --> Language Class Initialized
INFO - 2018-07-16 18:00:20 --> Loader Class Initialized
INFO - 2018-07-16 18:00:20 --> Controller Class Initialized
INFO - 2018-07-16 18:00:20 --> Database Driver Class Initialized
INFO - 2018-07-16 18:00:20 --> Model Class Initialized
INFO - 2018-07-16 18:00:20 --> Helper loaded: url_helper
INFO - 2018-07-16 18:00:20 --> Model Class Initialized
INFO - 2018-07-16 18:00:20 --> Final output sent to browser
DEBUG - 2018-07-16 18:00:20 --> Total execution time: 0.0456
ERROR - 2018-07-16 18:00:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:00:47 --> Config Class Initialized
INFO - 2018-07-16 18:00:47 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:00:47 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:00:47 --> Utf8 Class Initialized
INFO - 2018-07-16 18:00:47 --> URI Class Initialized
INFO - 2018-07-16 18:00:47 --> Router Class Initialized
INFO - 2018-07-16 18:00:47 --> Output Class Initialized
INFO - 2018-07-16 18:00:47 --> Security Class Initialized
DEBUG - 2018-07-16 18:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:00:47 --> Input Class Initialized
INFO - 2018-07-16 18:00:47 --> Language Class Initialized
INFO - 2018-07-16 18:00:47 --> Loader Class Initialized
INFO - 2018-07-16 18:00:47 --> Controller Class Initialized
INFO - 2018-07-16 18:00:47 --> Database Driver Class Initialized
INFO - 2018-07-16 18:00:47 --> Model Class Initialized
INFO - 2018-07-16 18:00:47 --> Helper loaded: url_helper
INFO - 2018-07-16 18:00:47 --> Model Class Initialized
INFO - 2018-07-16 18:00:47 --> Final output sent to browser
DEBUG - 2018-07-16 18:00:47 --> Total execution time: 0.0658
ERROR - 2018-07-16 18:06:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:06:44 --> Config Class Initialized
INFO - 2018-07-16 18:06:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:06:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:06:44 --> Utf8 Class Initialized
INFO - 2018-07-16 18:06:44 --> URI Class Initialized
INFO - 2018-07-16 18:06:44 --> Router Class Initialized
INFO - 2018-07-16 18:06:44 --> Output Class Initialized
INFO - 2018-07-16 18:06:44 --> Security Class Initialized
DEBUG - 2018-07-16 18:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:06:44 --> Input Class Initialized
INFO - 2018-07-16 18:06:44 --> Language Class Initialized
INFO - 2018-07-16 18:06:44 --> Loader Class Initialized
INFO - 2018-07-16 18:06:44 --> Controller Class Initialized
INFO - 2018-07-16 18:06:44 --> Database Driver Class Initialized
INFO - 2018-07-16 18:06:44 --> Model Class Initialized
INFO - 2018-07-16 18:06:44 --> Helper loaded: url_helper
DEBUG - 2018-07-16 18:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 18:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 18:06:44 --> Model Class Initialized
INFO - 2018-07-16 18:06:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 18:06:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 18:06:44 --> Final output sent to browser
DEBUG - 2018-07-16 18:06:44 --> Total execution time: 0.0676
ERROR - 2018-07-16 18:13:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:13:03 --> Config Class Initialized
INFO - 2018-07-16 18:13:03 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:13:03 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:13:03 --> Utf8 Class Initialized
INFO - 2018-07-16 18:13:03 --> URI Class Initialized
INFO - 2018-07-16 18:13:03 --> Router Class Initialized
INFO - 2018-07-16 18:13:03 --> Output Class Initialized
INFO - 2018-07-16 18:13:03 --> Security Class Initialized
DEBUG - 2018-07-16 18:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:13:03 --> Input Class Initialized
INFO - 2018-07-16 18:13:03 --> Language Class Initialized
INFO - 2018-07-16 18:13:03 --> Loader Class Initialized
INFO - 2018-07-16 18:13:03 --> Controller Class Initialized
INFO - 2018-07-16 18:13:03 --> Database Driver Class Initialized
INFO - 2018-07-16 18:13:03 --> Model Class Initialized
INFO - 2018-07-16 18:13:03 --> Helper loaded: url_helper
INFO - 2018-07-16 18:13:03 --> Model Class Initialized
INFO - 2018-07-16 18:13:03 --> Final output sent to browser
DEBUG - 2018-07-16 18:13:03 --> Total execution time: 0.0501
ERROR - 2018-07-16 18:13:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:13:04 --> Config Class Initialized
INFO - 2018-07-16 18:13:04 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:13:05 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:13:05 --> Utf8 Class Initialized
INFO - 2018-07-16 18:13:05 --> URI Class Initialized
INFO - 2018-07-16 18:13:05 --> Router Class Initialized
INFO - 2018-07-16 18:13:05 --> Output Class Initialized
INFO - 2018-07-16 18:13:05 --> Security Class Initialized
DEBUG - 2018-07-16 18:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:13:05 --> Input Class Initialized
INFO - 2018-07-16 18:13:05 --> Language Class Initialized
INFO - 2018-07-16 18:13:05 --> Loader Class Initialized
INFO - 2018-07-16 18:13:05 --> Controller Class Initialized
INFO - 2018-07-16 18:13:05 --> Database Driver Class Initialized
INFO - 2018-07-16 18:13:05 --> Model Class Initialized
INFO - 2018-07-16 18:13:05 --> Helper loaded: url_helper
INFO - 2018-07-16 18:13:05 --> Model Class Initialized
INFO - 2018-07-16 18:13:05 --> Final output sent to browser
DEBUG - 2018-07-16 18:13:05 --> Total execution time: 0.0439
ERROR - 2018-07-16 18:13:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:13:05 --> Config Class Initialized
INFO - 2018-07-16 18:13:05 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:13:05 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:13:05 --> Utf8 Class Initialized
INFO - 2018-07-16 18:13:05 --> URI Class Initialized
INFO - 2018-07-16 18:13:05 --> Router Class Initialized
INFO - 2018-07-16 18:13:05 --> Output Class Initialized
INFO - 2018-07-16 18:13:05 --> Security Class Initialized
DEBUG - 2018-07-16 18:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:13:05 --> Input Class Initialized
INFO - 2018-07-16 18:13:05 --> Language Class Initialized
INFO - 2018-07-16 18:13:05 --> Loader Class Initialized
INFO - 2018-07-16 18:13:05 --> Controller Class Initialized
INFO - 2018-07-16 18:13:05 --> Database Driver Class Initialized
INFO - 2018-07-16 18:13:05 --> Model Class Initialized
INFO - 2018-07-16 18:13:05 --> Helper loaded: url_helper
INFO - 2018-07-16 18:13:05 --> Model Class Initialized
INFO - 2018-07-16 18:13:05 --> Final output sent to browser
DEBUG - 2018-07-16 18:13:05 --> Total execution time: 0.0546
ERROR - 2018-07-16 18:16:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:16:57 --> Config Class Initialized
INFO - 2018-07-16 18:16:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:16:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:16:57 --> Utf8 Class Initialized
INFO - 2018-07-16 18:16:57 --> URI Class Initialized
INFO - 2018-07-16 18:16:57 --> Router Class Initialized
INFO - 2018-07-16 18:16:57 --> Output Class Initialized
INFO - 2018-07-16 18:16:57 --> Security Class Initialized
DEBUG - 2018-07-16 18:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:16:57 --> Input Class Initialized
INFO - 2018-07-16 18:16:57 --> Language Class Initialized
INFO - 2018-07-16 18:16:57 --> Loader Class Initialized
INFO - 2018-07-16 18:16:57 --> Controller Class Initialized
INFO - 2018-07-16 18:16:57 --> Database Driver Class Initialized
INFO - 2018-07-16 18:16:57 --> Model Class Initialized
INFO - 2018-07-16 18:16:57 --> Helper loaded: url_helper
INFO - 2018-07-16 18:16:57 --> Model Class Initialized
INFO - 2018-07-16 18:16:57 --> Final output sent to browser
DEBUG - 2018-07-16 18:16:57 --> Total execution time: 0.0658
ERROR - 2018-07-16 18:16:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:16:59 --> Config Class Initialized
INFO - 2018-07-16 18:16:59 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:16:59 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:16:59 --> Utf8 Class Initialized
INFO - 2018-07-16 18:16:59 --> URI Class Initialized
INFO - 2018-07-16 18:16:59 --> Router Class Initialized
INFO - 2018-07-16 18:16:59 --> Output Class Initialized
INFO - 2018-07-16 18:16:59 --> Security Class Initialized
DEBUG - 2018-07-16 18:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:16:59 --> Input Class Initialized
INFO - 2018-07-16 18:16:59 --> Language Class Initialized
INFO - 2018-07-16 18:16:59 --> Loader Class Initialized
INFO - 2018-07-16 18:16:59 --> Controller Class Initialized
INFO - 2018-07-16 18:16:59 --> Database Driver Class Initialized
INFO - 2018-07-16 18:16:59 --> Model Class Initialized
INFO - 2018-07-16 18:16:59 --> Helper loaded: url_helper
INFO - 2018-07-16 18:16:59 --> Model Class Initialized
INFO - 2018-07-16 18:16:59 --> Final output sent to browser
DEBUG - 2018-07-16 18:16:59 --> Total execution time: 0.0551
ERROR - 2018-07-16 18:16:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:16:59 --> Config Class Initialized
INFO - 2018-07-16 18:16:59 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:16:59 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:16:59 --> Utf8 Class Initialized
INFO - 2018-07-16 18:16:59 --> URI Class Initialized
INFO - 2018-07-16 18:16:59 --> Router Class Initialized
INFO - 2018-07-16 18:16:59 --> Output Class Initialized
INFO - 2018-07-16 18:16:59 --> Security Class Initialized
DEBUG - 2018-07-16 18:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:16:59 --> Input Class Initialized
INFO - 2018-07-16 18:16:59 --> Language Class Initialized
INFO - 2018-07-16 18:16:59 --> Loader Class Initialized
INFO - 2018-07-16 18:16:59 --> Controller Class Initialized
INFO - 2018-07-16 18:16:59 --> Database Driver Class Initialized
INFO - 2018-07-16 18:16:59 --> Model Class Initialized
INFO - 2018-07-16 18:16:59 --> Helper loaded: url_helper
INFO - 2018-07-16 18:16:59 --> Model Class Initialized
INFO - 2018-07-16 18:16:59 --> Final output sent to browser
DEBUG - 2018-07-16 18:16:59 --> Total execution time: 0.0402
ERROR - 2018-07-16 18:26:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:26:11 --> Config Class Initialized
INFO - 2018-07-16 18:26:11 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:26:11 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:26:11 --> Utf8 Class Initialized
INFO - 2018-07-16 18:26:11 --> URI Class Initialized
INFO - 2018-07-16 18:26:11 --> Router Class Initialized
INFO - 2018-07-16 18:26:11 --> Output Class Initialized
INFO - 2018-07-16 18:26:11 --> Security Class Initialized
DEBUG - 2018-07-16 18:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:26:11 --> Input Class Initialized
INFO - 2018-07-16 18:26:11 --> Language Class Initialized
INFO - 2018-07-16 18:26:11 --> Loader Class Initialized
INFO - 2018-07-16 18:26:11 --> Controller Class Initialized
INFO - 2018-07-16 18:26:11 --> Database Driver Class Initialized
INFO - 2018-07-16 18:26:11 --> Model Class Initialized
INFO - 2018-07-16 18:26:11 --> Helper loaded: url_helper
INFO - 2018-07-16 18:26:11 --> Model Class Initialized
INFO - 2018-07-16 18:26:11 --> Final output sent to browser
DEBUG - 2018-07-16 18:26:11 --> Total execution time: 0.0501
ERROR - 2018-07-16 18:26:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:26:55 --> Config Class Initialized
INFO - 2018-07-16 18:26:55 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:26:55 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:26:55 --> Utf8 Class Initialized
INFO - 2018-07-16 18:26:55 --> URI Class Initialized
INFO - 2018-07-16 18:26:55 --> Router Class Initialized
INFO - 2018-07-16 18:26:55 --> Output Class Initialized
INFO - 2018-07-16 18:26:55 --> Security Class Initialized
DEBUG - 2018-07-16 18:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:26:55 --> Input Class Initialized
INFO - 2018-07-16 18:26:55 --> Language Class Initialized
INFO - 2018-07-16 18:26:55 --> Loader Class Initialized
INFO - 2018-07-16 18:26:55 --> Controller Class Initialized
INFO - 2018-07-16 18:26:55 --> Database Driver Class Initialized
INFO - 2018-07-16 18:26:55 --> Model Class Initialized
INFO - 2018-07-16 18:26:55 --> Helper loaded: url_helper
INFO - 2018-07-16 18:26:55 --> Model Class Initialized
INFO - 2018-07-16 18:26:55 --> Final output sent to browser
DEBUG - 2018-07-16 18:26:55 --> Total execution time: 0.0832
ERROR - 2018-07-16 18:28:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:28:54 --> Config Class Initialized
INFO - 2018-07-16 18:28:54 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:28:54 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:28:54 --> Utf8 Class Initialized
INFO - 2018-07-16 18:28:54 --> URI Class Initialized
INFO - 2018-07-16 18:28:54 --> Router Class Initialized
INFO - 2018-07-16 18:28:54 --> Output Class Initialized
INFO - 2018-07-16 18:28:54 --> Security Class Initialized
DEBUG - 2018-07-16 18:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:28:54 --> Input Class Initialized
INFO - 2018-07-16 18:28:54 --> Language Class Initialized
INFO - 2018-07-16 18:28:54 --> Loader Class Initialized
INFO - 2018-07-16 18:28:54 --> Controller Class Initialized
INFO - 2018-07-16 18:28:54 --> Database Driver Class Initialized
INFO - 2018-07-16 18:28:54 --> Model Class Initialized
INFO - 2018-07-16 18:28:54 --> Helper loaded: url_helper
INFO - 2018-07-16 18:28:54 --> Model Class Initialized
INFO - 2018-07-16 18:28:54 --> Final output sent to browser
DEBUG - 2018-07-16 18:28:54 --> Total execution time: 0.0480
ERROR - 2018-07-16 18:29:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:29:02 --> Config Class Initialized
INFO - 2018-07-16 18:29:02 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:29:02 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:29:02 --> Utf8 Class Initialized
INFO - 2018-07-16 18:29:02 --> URI Class Initialized
INFO - 2018-07-16 18:29:02 --> Router Class Initialized
INFO - 2018-07-16 18:29:02 --> Output Class Initialized
INFO - 2018-07-16 18:29:02 --> Security Class Initialized
DEBUG - 2018-07-16 18:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:29:02 --> Input Class Initialized
INFO - 2018-07-16 18:29:02 --> Language Class Initialized
INFO - 2018-07-16 18:29:02 --> Loader Class Initialized
INFO - 2018-07-16 18:29:02 --> Controller Class Initialized
INFO - 2018-07-16 18:29:02 --> Database Driver Class Initialized
INFO - 2018-07-16 18:29:03 --> Model Class Initialized
INFO - 2018-07-16 18:29:03 --> Helper loaded: url_helper
INFO - 2018-07-16 18:29:03 --> Model Class Initialized
INFO - 2018-07-16 18:29:03 --> Final output sent to browser
DEBUG - 2018-07-16 18:29:03 --> Total execution time: 0.0595
ERROR - 2018-07-16 18:29:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:29:36 --> Config Class Initialized
INFO - 2018-07-16 18:29:36 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:29:36 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:29:36 --> Utf8 Class Initialized
INFO - 2018-07-16 18:29:36 --> URI Class Initialized
INFO - 2018-07-16 18:29:36 --> Router Class Initialized
INFO - 2018-07-16 18:29:36 --> Output Class Initialized
INFO - 2018-07-16 18:29:36 --> Security Class Initialized
DEBUG - 2018-07-16 18:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:29:36 --> Input Class Initialized
INFO - 2018-07-16 18:29:36 --> Language Class Initialized
INFO - 2018-07-16 18:29:36 --> Loader Class Initialized
INFO - 2018-07-16 18:29:36 --> Controller Class Initialized
INFO - 2018-07-16 18:29:36 --> Database Driver Class Initialized
INFO - 2018-07-16 18:29:36 --> Model Class Initialized
INFO - 2018-07-16 18:29:36 --> Helper loaded: url_helper
INFO - 2018-07-16 18:29:36 --> Model Class Initialized
INFO - 2018-07-16 18:29:36 --> Final output sent to browser
DEBUG - 2018-07-16 18:29:36 --> Total execution time: 0.0428
ERROR - 2018-07-16 18:32:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:32:23 --> Config Class Initialized
INFO - 2018-07-16 18:32:23 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:32:23 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:32:23 --> Utf8 Class Initialized
INFO - 2018-07-16 18:32:23 --> URI Class Initialized
INFO - 2018-07-16 18:32:23 --> Router Class Initialized
INFO - 2018-07-16 18:32:23 --> Output Class Initialized
INFO - 2018-07-16 18:32:23 --> Security Class Initialized
DEBUG - 2018-07-16 18:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:32:23 --> Input Class Initialized
INFO - 2018-07-16 18:32:23 --> Language Class Initialized
INFO - 2018-07-16 18:32:23 --> Loader Class Initialized
INFO - 2018-07-16 18:32:23 --> Controller Class Initialized
INFO - 2018-07-16 18:32:23 --> Database Driver Class Initialized
INFO - 2018-07-16 18:32:23 --> Model Class Initialized
INFO - 2018-07-16 18:32:23 --> Helper loaded: url_helper
INFO - 2018-07-16 18:32:23 --> Model Class Initialized
INFO - 2018-07-16 18:32:23 --> Final output sent to browser
DEBUG - 2018-07-16 18:32:23 --> Total execution time: 0.0627
ERROR - 2018-07-16 18:32:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:32:24 --> Config Class Initialized
INFO - 2018-07-16 18:32:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:32:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:32:24 --> Utf8 Class Initialized
INFO - 2018-07-16 18:32:24 --> URI Class Initialized
INFO - 2018-07-16 18:32:24 --> Router Class Initialized
INFO - 2018-07-16 18:32:24 --> Output Class Initialized
INFO - 2018-07-16 18:32:24 --> Security Class Initialized
DEBUG - 2018-07-16 18:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:32:24 --> Input Class Initialized
INFO - 2018-07-16 18:32:24 --> Language Class Initialized
INFO - 2018-07-16 18:32:24 --> Loader Class Initialized
INFO - 2018-07-16 18:32:24 --> Controller Class Initialized
INFO - 2018-07-16 18:32:24 --> Database Driver Class Initialized
INFO - 2018-07-16 18:32:24 --> Model Class Initialized
INFO - 2018-07-16 18:32:24 --> Helper loaded: url_helper
INFO - 2018-07-16 18:32:24 --> Model Class Initialized
INFO - 2018-07-16 18:32:24 --> Final output sent to browser
DEBUG - 2018-07-16 18:32:24 --> Total execution time: 0.0629
ERROR - 2018-07-16 18:32:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:32:24 --> Config Class Initialized
INFO - 2018-07-16 18:32:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:32:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:32:24 --> Utf8 Class Initialized
INFO - 2018-07-16 18:32:24 --> URI Class Initialized
INFO - 2018-07-16 18:32:24 --> Router Class Initialized
INFO - 2018-07-16 18:32:24 --> Output Class Initialized
INFO - 2018-07-16 18:32:24 --> Security Class Initialized
DEBUG - 2018-07-16 18:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:32:24 --> Input Class Initialized
INFO - 2018-07-16 18:32:24 --> Language Class Initialized
INFO - 2018-07-16 18:32:24 --> Loader Class Initialized
INFO - 2018-07-16 18:32:24 --> Controller Class Initialized
INFO - 2018-07-16 18:32:24 --> Database Driver Class Initialized
INFO - 2018-07-16 18:32:24 --> Model Class Initialized
INFO - 2018-07-16 18:32:24 --> Helper loaded: url_helper
INFO - 2018-07-16 18:32:24 --> Model Class Initialized
INFO - 2018-07-16 18:32:24 --> Final output sent to browser
DEBUG - 2018-07-16 18:32:24 --> Total execution time: 0.0638
ERROR - 2018-07-16 18:33:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:33:29 --> Config Class Initialized
INFO - 2018-07-16 18:33:29 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:33:29 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:33:29 --> Utf8 Class Initialized
INFO - 2018-07-16 18:33:29 --> URI Class Initialized
INFO - 2018-07-16 18:33:29 --> Router Class Initialized
INFO - 2018-07-16 18:33:29 --> Output Class Initialized
INFO - 2018-07-16 18:33:29 --> Security Class Initialized
DEBUG - 2018-07-16 18:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:33:29 --> Input Class Initialized
INFO - 2018-07-16 18:33:29 --> Language Class Initialized
INFO - 2018-07-16 18:33:29 --> Loader Class Initialized
INFO - 2018-07-16 18:33:29 --> Controller Class Initialized
INFO - 2018-07-16 18:33:29 --> Database Driver Class Initialized
INFO - 2018-07-16 18:33:29 --> Model Class Initialized
INFO - 2018-07-16 18:33:29 --> Helper loaded: url_helper
INFO - 2018-07-16 18:33:29 --> Model Class Initialized
INFO - 2018-07-16 18:33:29 --> Final output sent to browser
DEBUG - 2018-07-16 18:33:29 --> Total execution time: 0.0740
ERROR - 2018-07-16 18:53:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:53:00 --> Config Class Initialized
INFO - 2018-07-16 18:53:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:53:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:53:00 --> Utf8 Class Initialized
INFO - 2018-07-16 18:53:00 --> URI Class Initialized
INFO - 2018-07-16 18:53:00 --> Router Class Initialized
INFO - 2018-07-16 18:53:00 --> Output Class Initialized
INFO - 2018-07-16 18:53:00 --> Security Class Initialized
DEBUG - 2018-07-16 18:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:53:00 --> Input Class Initialized
INFO - 2018-07-16 18:53:00 --> Language Class Initialized
INFO - 2018-07-16 18:53:00 --> Loader Class Initialized
INFO - 2018-07-16 18:53:00 --> Controller Class Initialized
INFO - 2018-07-16 18:53:00 --> Database Driver Class Initialized
INFO - 2018-07-16 18:53:00 --> Model Class Initialized
INFO - 2018-07-16 18:53:00 --> Helper loaded: url_helper
INFO - 2018-07-16 18:53:00 --> Model Class Initialized
INFO - 2018-07-16 18:53:00 --> Final output sent to browser
DEBUG - 2018-07-16 18:53:00 --> Total execution time: 0.0550
ERROR - 2018-07-16 18:53:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:53:01 --> Config Class Initialized
INFO - 2018-07-16 18:53:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:53:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:53:01 --> Utf8 Class Initialized
INFO - 2018-07-16 18:53:01 --> URI Class Initialized
INFO - 2018-07-16 18:53:01 --> Router Class Initialized
INFO - 2018-07-16 18:53:01 --> Output Class Initialized
INFO - 2018-07-16 18:53:01 --> Security Class Initialized
DEBUG - 2018-07-16 18:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:53:01 --> Input Class Initialized
INFO - 2018-07-16 18:53:01 --> Language Class Initialized
INFO - 2018-07-16 18:53:01 --> Loader Class Initialized
INFO - 2018-07-16 18:53:01 --> Controller Class Initialized
INFO - 2018-07-16 18:53:01 --> Database Driver Class Initialized
INFO - 2018-07-16 18:53:01 --> Model Class Initialized
INFO - 2018-07-16 18:53:01 --> Helper loaded: url_helper
INFO - 2018-07-16 18:53:01 --> Model Class Initialized
INFO - 2018-07-16 18:53:01 --> Final output sent to browser
DEBUG - 2018-07-16 18:53:01 --> Total execution time: 0.0695
ERROR - 2018-07-16 18:53:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:53:01 --> Config Class Initialized
INFO - 2018-07-16 18:53:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:53:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:53:01 --> Utf8 Class Initialized
INFO - 2018-07-16 18:53:01 --> URI Class Initialized
INFO - 2018-07-16 18:53:01 --> Router Class Initialized
INFO - 2018-07-16 18:53:01 --> Output Class Initialized
INFO - 2018-07-16 18:53:01 --> Security Class Initialized
DEBUG - 2018-07-16 18:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:53:01 --> Input Class Initialized
INFO - 2018-07-16 18:53:01 --> Language Class Initialized
INFO - 2018-07-16 18:53:01 --> Loader Class Initialized
INFO - 2018-07-16 18:53:01 --> Controller Class Initialized
INFO - 2018-07-16 18:53:01 --> Database Driver Class Initialized
INFO - 2018-07-16 18:53:01 --> Model Class Initialized
INFO - 2018-07-16 18:53:01 --> Helper loaded: url_helper
INFO - 2018-07-16 18:53:01 --> Model Class Initialized
INFO - 2018-07-16 18:53:01 --> Final output sent to browser
DEBUG - 2018-07-16 18:53:01 --> Total execution time: 0.0487
ERROR - 2018-07-16 18:54:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:54:57 --> Config Class Initialized
INFO - 2018-07-16 18:54:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:54:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:54:57 --> Utf8 Class Initialized
INFO - 2018-07-16 18:54:57 --> URI Class Initialized
INFO - 2018-07-16 18:54:57 --> Router Class Initialized
INFO - 2018-07-16 18:54:57 --> Output Class Initialized
INFO - 2018-07-16 18:54:57 --> Security Class Initialized
DEBUG - 2018-07-16 18:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:54:57 --> Input Class Initialized
INFO - 2018-07-16 18:54:57 --> Language Class Initialized
INFO - 2018-07-16 18:54:57 --> Loader Class Initialized
INFO - 2018-07-16 18:54:57 --> Controller Class Initialized
INFO - 2018-07-16 18:54:57 --> Database Driver Class Initialized
INFO - 2018-07-16 18:54:57 --> Model Class Initialized
INFO - 2018-07-16 18:54:57 --> Helper loaded: url_helper
INFO - 2018-07-16 18:54:57 --> Model Class Initialized
INFO - 2018-07-16 18:54:57 --> Final output sent to browser
DEBUG - 2018-07-16 18:54:57 --> Total execution time: 0.0621
ERROR - 2018-07-16 18:54:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:54:58 --> Config Class Initialized
INFO - 2018-07-16 18:54:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:54:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:54:58 --> Utf8 Class Initialized
INFO - 2018-07-16 18:54:58 --> URI Class Initialized
INFO - 2018-07-16 18:54:58 --> Router Class Initialized
INFO - 2018-07-16 18:54:58 --> Output Class Initialized
INFO - 2018-07-16 18:54:58 --> Security Class Initialized
DEBUG - 2018-07-16 18:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:54:58 --> Input Class Initialized
INFO - 2018-07-16 18:54:58 --> Language Class Initialized
INFO - 2018-07-16 18:54:58 --> Loader Class Initialized
INFO - 2018-07-16 18:54:58 --> Controller Class Initialized
INFO - 2018-07-16 18:54:58 --> Database Driver Class Initialized
INFO - 2018-07-16 18:54:58 --> Model Class Initialized
INFO - 2018-07-16 18:54:58 --> Helper loaded: url_helper
INFO - 2018-07-16 18:54:58 --> Model Class Initialized
INFO - 2018-07-16 18:54:58 --> Final output sent to browser
DEBUG - 2018-07-16 18:54:58 --> Total execution time: 0.0617
ERROR - 2018-07-16 18:54:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:54:58 --> Config Class Initialized
INFO - 2018-07-16 18:54:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:54:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:54:58 --> Utf8 Class Initialized
INFO - 2018-07-16 18:54:58 --> URI Class Initialized
INFO - 2018-07-16 18:54:58 --> Router Class Initialized
INFO - 2018-07-16 18:54:58 --> Output Class Initialized
INFO - 2018-07-16 18:54:58 --> Security Class Initialized
DEBUG - 2018-07-16 18:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:54:58 --> Input Class Initialized
INFO - 2018-07-16 18:54:58 --> Language Class Initialized
INFO - 2018-07-16 18:54:58 --> Loader Class Initialized
INFO - 2018-07-16 18:54:58 --> Controller Class Initialized
INFO - 2018-07-16 18:54:58 --> Database Driver Class Initialized
INFO - 2018-07-16 18:54:58 --> Model Class Initialized
INFO - 2018-07-16 18:54:58 --> Helper loaded: url_helper
INFO - 2018-07-16 18:54:58 --> Model Class Initialized
INFO - 2018-07-16 18:54:58 --> Final output sent to browser
DEBUG - 2018-07-16 18:54:58 --> Total execution time: 0.0675
ERROR - 2018-07-16 18:58:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:58:11 --> Config Class Initialized
INFO - 2018-07-16 18:58:11 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:58:11 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:58:11 --> Utf8 Class Initialized
INFO - 2018-07-16 18:58:11 --> URI Class Initialized
INFO - 2018-07-16 18:58:11 --> Router Class Initialized
INFO - 2018-07-16 18:58:11 --> Output Class Initialized
INFO - 2018-07-16 18:58:11 --> Security Class Initialized
DEBUG - 2018-07-16 18:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:58:11 --> Input Class Initialized
INFO - 2018-07-16 18:58:11 --> Language Class Initialized
INFO - 2018-07-16 18:58:11 --> Loader Class Initialized
INFO - 2018-07-16 18:58:11 --> Controller Class Initialized
INFO - 2018-07-16 18:58:11 --> Database Driver Class Initialized
INFO - 2018-07-16 18:58:11 --> Model Class Initialized
INFO - 2018-07-16 18:58:11 --> Helper loaded: url_helper
INFO - 2018-07-16 18:58:11 --> Model Class Initialized
INFO - 2018-07-16 18:58:11 --> Final output sent to browser
DEBUG - 2018-07-16 18:58:11 --> Total execution time: 0.0499
ERROR - 2018-07-16 18:58:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:58:12 --> Config Class Initialized
INFO - 2018-07-16 18:58:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:58:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:58:12 --> Utf8 Class Initialized
INFO - 2018-07-16 18:58:12 --> URI Class Initialized
INFO - 2018-07-16 18:58:12 --> Router Class Initialized
INFO - 2018-07-16 18:58:12 --> Output Class Initialized
INFO - 2018-07-16 18:58:12 --> Security Class Initialized
DEBUG - 2018-07-16 18:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:58:12 --> Input Class Initialized
INFO - 2018-07-16 18:58:12 --> Language Class Initialized
INFO - 2018-07-16 18:58:12 --> Loader Class Initialized
INFO - 2018-07-16 18:58:12 --> Controller Class Initialized
INFO - 2018-07-16 18:58:12 --> Database Driver Class Initialized
INFO - 2018-07-16 18:58:12 --> Model Class Initialized
INFO - 2018-07-16 18:58:12 --> Helper loaded: url_helper
INFO - 2018-07-16 18:58:12 --> Model Class Initialized
INFO - 2018-07-16 18:58:12 --> Final output sent to browser
DEBUG - 2018-07-16 18:58:12 --> Total execution time: 0.0533
ERROR - 2018-07-16 18:58:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:58:12 --> Config Class Initialized
INFO - 2018-07-16 18:58:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:58:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:58:12 --> Utf8 Class Initialized
INFO - 2018-07-16 18:58:12 --> URI Class Initialized
INFO - 2018-07-16 18:58:12 --> Router Class Initialized
INFO - 2018-07-16 18:58:12 --> Output Class Initialized
INFO - 2018-07-16 18:58:12 --> Security Class Initialized
DEBUG - 2018-07-16 18:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:58:12 --> Input Class Initialized
INFO - 2018-07-16 18:58:12 --> Language Class Initialized
INFO - 2018-07-16 18:58:12 --> Loader Class Initialized
INFO - 2018-07-16 18:58:12 --> Controller Class Initialized
INFO - 2018-07-16 18:58:12 --> Database Driver Class Initialized
INFO - 2018-07-16 18:58:12 --> Model Class Initialized
INFO - 2018-07-16 18:58:12 --> Helper loaded: url_helper
INFO - 2018-07-16 18:58:12 --> Model Class Initialized
INFO - 2018-07-16 18:58:12 --> Final output sent to browser
DEBUG - 2018-07-16 18:58:12 --> Total execution time: 0.0400
ERROR - 2018-07-16 18:58:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:58:35 --> Config Class Initialized
INFO - 2018-07-16 18:58:35 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:58:35 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:58:35 --> Utf8 Class Initialized
INFO - 2018-07-16 18:58:35 --> URI Class Initialized
INFO - 2018-07-16 18:58:35 --> Router Class Initialized
INFO - 2018-07-16 18:58:35 --> Output Class Initialized
INFO - 2018-07-16 18:58:35 --> Security Class Initialized
DEBUG - 2018-07-16 18:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:58:35 --> Input Class Initialized
INFO - 2018-07-16 18:58:35 --> Language Class Initialized
INFO - 2018-07-16 18:58:35 --> Loader Class Initialized
INFO - 2018-07-16 18:58:35 --> Controller Class Initialized
INFO - 2018-07-16 18:58:35 --> Database Driver Class Initialized
INFO - 2018-07-16 18:58:35 --> Model Class Initialized
INFO - 2018-07-16 18:58:35 --> Helper loaded: url_helper
INFO - 2018-07-16 18:58:35 --> Model Class Initialized
INFO - 2018-07-16 18:58:35 --> Final output sent to browser
DEBUG - 2018-07-16 18:58:35 --> Total execution time: 0.0854
ERROR - 2018-07-16 18:58:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:58:35 --> Config Class Initialized
INFO - 2018-07-16 18:58:35 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:58:35 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:58:35 --> Utf8 Class Initialized
INFO - 2018-07-16 18:58:35 --> URI Class Initialized
INFO - 2018-07-16 18:58:35 --> Router Class Initialized
INFO - 2018-07-16 18:58:35 --> Output Class Initialized
INFO - 2018-07-16 18:58:35 --> Security Class Initialized
DEBUG - 2018-07-16 18:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:58:35 --> Input Class Initialized
INFO - 2018-07-16 18:58:35 --> Language Class Initialized
INFO - 2018-07-16 18:58:35 --> Loader Class Initialized
INFO - 2018-07-16 18:58:35 --> Controller Class Initialized
INFO - 2018-07-16 18:58:35 --> Database Driver Class Initialized
INFO - 2018-07-16 18:58:35 --> Model Class Initialized
INFO - 2018-07-16 18:58:35 --> Helper loaded: url_helper
INFO - 2018-07-16 18:58:35 --> Model Class Initialized
INFO - 2018-07-16 18:58:35 --> Final output sent to browser
DEBUG - 2018-07-16 18:58:35 --> Total execution time: 0.0452
ERROR - 2018-07-16 18:58:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:58:35 --> Config Class Initialized
INFO - 2018-07-16 18:58:35 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:58:35 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:58:35 --> Utf8 Class Initialized
INFO - 2018-07-16 18:58:35 --> URI Class Initialized
INFO - 2018-07-16 18:58:35 --> Router Class Initialized
INFO - 2018-07-16 18:58:35 --> Output Class Initialized
INFO - 2018-07-16 18:58:35 --> Security Class Initialized
DEBUG - 2018-07-16 18:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:58:35 --> Input Class Initialized
INFO - 2018-07-16 18:58:35 --> Language Class Initialized
INFO - 2018-07-16 18:58:35 --> Loader Class Initialized
INFO - 2018-07-16 18:58:35 --> Controller Class Initialized
INFO - 2018-07-16 18:58:35 --> Database Driver Class Initialized
INFO - 2018-07-16 18:58:35 --> Model Class Initialized
INFO - 2018-07-16 18:58:35 --> Helper loaded: url_helper
INFO - 2018-07-16 18:58:35 --> Model Class Initialized
INFO - 2018-07-16 18:58:35 --> Final output sent to browser
DEBUG - 2018-07-16 18:58:35 --> Total execution time: 0.0390
ERROR - 2018-07-16 18:59:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:59:17 --> Config Class Initialized
INFO - 2018-07-16 18:59:17 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:59:17 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:59:17 --> Utf8 Class Initialized
INFO - 2018-07-16 18:59:17 --> URI Class Initialized
INFO - 2018-07-16 18:59:17 --> Router Class Initialized
INFO - 2018-07-16 18:59:17 --> Output Class Initialized
INFO - 2018-07-16 18:59:17 --> Security Class Initialized
DEBUG - 2018-07-16 18:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:59:17 --> Input Class Initialized
INFO - 2018-07-16 18:59:17 --> Language Class Initialized
INFO - 2018-07-16 18:59:17 --> Loader Class Initialized
INFO - 2018-07-16 18:59:17 --> Controller Class Initialized
INFO - 2018-07-16 18:59:17 --> Database Driver Class Initialized
INFO - 2018-07-16 18:59:17 --> Model Class Initialized
INFO - 2018-07-16 18:59:17 --> Helper loaded: url_helper
INFO - 2018-07-16 18:59:17 --> Model Class Initialized
INFO - 2018-07-16 18:59:17 --> Final output sent to browser
DEBUG - 2018-07-16 18:59:17 --> Total execution time: 0.0465
ERROR - 2018-07-16 18:59:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:59:17 --> Config Class Initialized
INFO - 2018-07-16 18:59:17 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:59:17 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:59:17 --> Utf8 Class Initialized
INFO - 2018-07-16 18:59:17 --> URI Class Initialized
INFO - 2018-07-16 18:59:17 --> Router Class Initialized
INFO - 2018-07-16 18:59:17 --> Output Class Initialized
INFO - 2018-07-16 18:59:17 --> Security Class Initialized
DEBUG - 2018-07-16 18:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:59:17 --> Input Class Initialized
INFO - 2018-07-16 18:59:17 --> Language Class Initialized
INFO - 2018-07-16 18:59:17 --> Loader Class Initialized
INFO - 2018-07-16 18:59:17 --> Controller Class Initialized
INFO - 2018-07-16 18:59:17 --> Database Driver Class Initialized
INFO - 2018-07-16 18:59:17 --> Model Class Initialized
INFO - 2018-07-16 18:59:17 --> Helper loaded: url_helper
INFO - 2018-07-16 18:59:17 --> Model Class Initialized
INFO - 2018-07-16 18:59:17 --> Final output sent to browser
DEBUG - 2018-07-16 18:59:17 --> Total execution time: 0.0646
ERROR - 2018-07-16 18:59:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 18:59:17 --> Config Class Initialized
INFO - 2018-07-16 18:59:17 --> Hooks Class Initialized
DEBUG - 2018-07-16 18:59:17 --> UTF-8 Support Enabled
INFO - 2018-07-16 18:59:17 --> Utf8 Class Initialized
INFO - 2018-07-16 18:59:17 --> URI Class Initialized
INFO - 2018-07-16 18:59:17 --> Router Class Initialized
INFO - 2018-07-16 18:59:17 --> Output Class Initialized
INFO - 2018-07-16 18:59:17 --> Security Class Initialized
DEBUG - 2018-07-16 18:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 18:59:17 --> Input Class Initialized
INFO - 2018-07-16 18:59:17 --> Language Class Initialized
INFO - 2018-07-16 18:59:17 --> Loader Class Initialized
INFO - 2018-07-16 18:59:17 --> Controller Class Initialized
INFO - 2018-07-16 18:59:17 --> Database Driver Class Initialized
INFO - 2018-07-16 18:59:17 --> Model Class Initialized
INFO - 2018-07-16 18:59:17 --> Helper loaded: url_helper
INFO - 2018-07-16 18:59:17 --> Model Class Initialized
INFO - 2018-07-16 18:59:17 --> Final output sent to browser
DEBUG - 2018-07-16 18:59:17 --> Total execution time: 0.0454
ERROR - 2018-07-16 19:00:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:00:40 --> Config Class Initialized
INFO - 2018-07-16 19:00:40 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:00:40 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:00:40 --> Utf8 Class Initialized
INFO - 2018-07-16 19:00:40 --> URI Class Initialized
INFO - 2018-07-16 19:00:40 --> Router Class Initialized
INFO - 2018-07-16 19:00:40 --> Output Class Initialized
INFO - 2018-07-16 19:00:40 --> Security Class Initialized
DEBUG - 2018-07-16 19:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:00:40 --> Input Class Initialized
INFO - 2018-07-16 19:00:40 --> Language Class Initialized
INFO - 2018-07-16 19:00:40 --> Loader Class Initialized
INFO - 2018-07-16 19:00:40 --> Controller Class Initialized
INFO - 2018-07-16 19:00:40 --> Database Driver Class Initialized
INFO - 2018-07-16 19:00:40 --> Model Class Initialized
INFO - 2018-07-16 19:00:40 --> Helper loaded: url_helper
INFO - 2018-07-16 19:00:40 --> Model Class Initialized
INFO - 2018-07-16 19:00:40 --> Final output sent to browser
DEBUG - 2018-07-16 19:00:40 --> Total execution time: 0.0566
ERROR - 2018-07-16 19:00:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:00:41 --> Config Class Initialized
INFO - 2018-07-16 19:00:41 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:00:41 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:00:41 --> Utf8 Class Initialized
INFO - 2018-07-16 19:00:41 --> URI Class Initialized
INFO - 2018-07-16 19:00:41 --> Router Class Initialized
INFO - 2018-07-16 19:00:41 --> Output Class Initialized
INFO - 2018-07-16 19:00:41 --> Security Class Initialized
DEBUG - 2018-07-16 19:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:00:41 --> Input Class Initialized
INFO - 2018-07-16 19:00:41 --> Language Class Initialized
INFO - 2018-07-16 19:00:41 --> Loader Class Initialized
INFO - 2018-07-16 19:00:41 --> Controller Class Initialized
INFO - 2018-07-16 19:00:41 --> Database Driver Class Initialized
INFO - 2018-07-16 19:00:41 --> Model Class Initialized
INFO - 2018-07-16 19:00:41 --> Helper loaded: url_helper
INFO - 2018-07-16 19:00:41 --> Model Class Initialized
INFO - 2018-07-16 19:00:41 --> Final output sent to browser
DEBUG - 2018-07-16 19:00:41 --> Total execution time: 0.0492
ERROR - 2018-07-16 19:00:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:00:41 --> Config Class Initialized
INFO - 2018-07-16 19:00:41 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:00:41 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:00:41 --> Utf8 Class Initialized
INFO - 2018-07-16 19:00:41 --> URI Class Initialized
INFO - 2018-07-16 19:00:41 --> Router Class Initialized
INFO - 2018-07-16 19:00:41 --> Output Class Initialized
INFO - 2018-07-16 19:00:41 --> Security Class Initialized
DEBUG - 2018-07-16 19:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:00:41 --> Input Class Initialized
INFO - 2018-07-16 19:00:41 --> Language Class Initialized
INFO - 2018-07-16 19:00:41 --> Loader Class Initialized
INFO - 2018-07-16 19:00:41 --> Controller Class Initialized
INFO - 2018-07-16 19:00:41 --> Database Driver Class Initialized
INFO - 2018-07-16 19:00:41 --> Model Class Initialized
INFO - 2018-07-16 19:00:41 --> Helper loaded: url_helper
INFO - 2018-07-16 19:00:41 --> Model Class Initialized
INFO - 2018-07-16 19:00:41 --> Final output sent to browser
DEBUG - 2018-07-16 19:00:41 --> Total execution time: 0.0485
ERROR - 2018-07-16 19:02:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:02:18 --> Config Class Initialized
INFO - 2018-07-16 19:02:18 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:02:18 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:02:18 --> Utf8 Class Initialized
INFO - 2018-07-16 19:02:18 --> URI Class Initialized
INFO - 2018-07-16 19:02:18 --> Router Class Initialized
INFO - 2018-07-16 19:02:18 --> Output Class Initialized
INFO - 2018-07-16 19:02:18 --> Security Class Initialized
DEBUG - 2018-07-16 19:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:02:18 --> Input Class Initialized
INFO - 2018-07-16 19:02:18 --> Language Class Initialized
INFO - 2018-07-16 19:02:18 --> Loader Class Initialized
INFO - 2018-07-16 19:02:18 --> Controller Class Initialized
INFO - 2018-07-16 19:02:18 --> Database Driver Class Initialized
INFO - 2018-07-16 19:02:18 --> Model Class Initialized
INFO - 2018-07-16 19:02:18 --> Helper loaded: url_helper
INFO - 2018-07-16 19:02:18 --> Model Class Initialized
INFO - 2018-07-16 19:02:18 --> Final output sent to browser
DEBUG - 2018-07-16 19:02:18 --> Total execution time: 0.0399
ERROR - 2018-07-16 19:02:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:02:19 --> Config Class Initialized
INFO - 2018-07-16 19:02:19 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:02:19 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:02:19 --> Utf8 Class Initialized
INFO - 2018-07-16 19:02:19 --> URI Class Initialized
INFO - 2018-07-16 19:02:19 --> Router Class Initialized
INFO - 2018-07-16 19:02:19 --> Output Class Initialized
INFO - 2018-07-16 19:02:19 --> Security Class Initialized
DEBUG - 2018-07-16 19:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:02:19 --> Input Class Initialized
INFO - 2018-07-16 19:02:19 --> Language Class Initialized
INFO - 2018-07-16 19:02:19 --> Loader Class Initialized
INFO - 2018-07-16 19:02:19 --> Controller Class Initialized
INFO - 2018-07-16 19:02:19 --> Database Driver Class Initialized
INFO - 2018-07-16 19:02:19 --> Model Class Initialized
INFO - 2018-07-16 19:02:19 --> Helper loaded: url_helper
INFO - 2018-07-16 19:02:19 --> Model Class Initialized
INFO - 2018-07-16 19:02:19 --> Final output sent to browser
DEBUG - 2018-07-16 19:02:19 --> Total execution time: 0.0709
ERROR - 2018-07-16 19:02:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:02:19 --> Config Class Initialized
INFO - 2018-07-16 19:02:19 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:02:19 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:02:19 --> Utf8 Class Initialized
INFO - 2018-07-16 19:02:19 --> URI Class Initialized
INFO - 2018-07-16 19:02:19 --> Router Class Initialized
INFO - 2018-07-16 19:02:19 --> Output Class Initialized
INFO - 2018-07-16 19:02:19 --> Security Class Initialized
DEBUG - 2018-07-16 19:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:02:19 --> Input Class Initialized
INFO - 2018-07-16 19:02:19 --> Language Class Initialized
INFO - 2018-07-16 19:02:19 --> Loader Class Initialized
INFO - 2018-07-16 19:02:19 --> Controller Class Initialized
INFO - 2018-07-16 19:02:19 --> Database Driver Class Initialized
INFO - 2018-07-16 19:02:19 --> Model Class Initialized
INFO - 2018-07-16 19:02:19 --> Helper loaded: url_helper
INFO - 2018-07-16 19:02:19 --> Model Class Initialized
INFO - 2018-07-16 19:02:19 --> Final output sent to browser
DEBUG - 2018-07-16 19:02:19 --> Total execution time: 0.0544
ERROR - 2018-07-16 19:02:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:02:23 --> Config Class Initialized
INFO - 2018-07-16 19:02:23 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:02:23 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:02:23 --> Utf8 Class Initialized
INFO - 2018-07-16 19:02:23 --> URI Class Initialized
INFO - 2018-07-16 19:02:23 --> Router Class Initialized
INFO - 2018-07-16 19:02:24 --> Output Class Initialized
INFO - 2018-07-16 19:02:24 --> Security Class Initialized
DEBUG - 2018-07-16 19:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:02:24 --> Input Class Initialized
INFO - 2018-07-16 19:02:24 --> Language Class Initialized
INFO - 2018-07-16 19:02:24 --> Loader Class Initialized
INFO - 2018-07-16 19:02:24 --> Controller Class Initialized
INFO - 2018-07-16 19:02:24 --> Database Driver Class Initialized
INFO - 2018-07-16 19:02:24 --> Model Class Initialized
INFO - 2018-07-16 19:02:24 --> Helper loaded: url_helper
INFO - 2018-07-16 19:02:24 --> Model Class Initialized
INFO - 2018-07-16 19:02:24 --> Final output sent to browser
DEBUG - 2018-07-16 19:02:24 --> Total execution time: 0.0506
ERROR - 2018-07-16 19:02:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:02:24 --> Config Class Initialized
INFO - 2018-07-16 19:02:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:02:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:02:24 --> Utf8 Class Initialized
INFO - 2018-07-16 19:02:24 --> URI Class Initialized
INFO - 2018-07-16 19:02:24 --> Router Class Initialized
INFO - 2018-07-16 19:02:24 --> Output Class Initialized
INFO - 2018-07-16 19:02:24 --> Security Class Initialized
DEBUG - 2018-07-16 19:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:02:24 --> Input Class Initialized
INFO - 2018-07-16 19:02:24 --> Language Class Initialized
INFO - 2018-07-16 19:02:24 --> Loader Class Initialized
INFO - 2018-07-16 19:02:24 --> Controller Class Initialized
INFO - 2018-07-16 19:02:24 --> Database Driver Class Initialized
INFO - 2018-07-16 19:02:24 --> Model Class Initialized
INFO - 2018-07-16 19:02:24 --> Helper loaded: url_helper
INFO - 2018-07-16 19:02:24 --> Model Class Initialized
INFO - 2018-07-16 19:02:24 --> Final output sent to browser
DEBUG - 2018-07-16 19:02:24 --> Total execution time: 0.0541
ERROR - 2018-07-16 19:02:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:02:24 --> Config Class Initialized
INFO - 2018-07-16 19:02:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:02:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:02:24 --> Utf8 Class Initialized
INFO - 2018-07-16 19:02:24 --> URI Class Initialized
INFO - 2018-07-16 19:02:24 --> Router Class Initialized
INFO - 2018-07-16 19:02:24 --> Output Class Initialized
INFO - 2018-07-16 19:02:24 --> Security Class Initialized
DEBUG - 2018-07-16 19:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:02:24 --> Input Class Initialized
INFO - 2018-07-16 19:02:24 --> Language Class Initialized
INFO - 2018-07-16 19:02:24 --> Loader Class Initialized
INFO - 2018-07-16 19:02:24 --> Controller Class Initialized
INFO - 2018-07-16 19:02:24 --> Database Driver Class Initialized
INFO - 2018-07-16 19:02:24 --> Model Class Initialized
INFO - 2018-07-16 19:02:24 --> Helper loaded: url_helper
INFO - 2018-07-16 19:02:24 --> Model Class Initialized
INFO - 2018-07-16 19:02:24 --> Final output sent to browser
DEBUG - 2018-07-16 19:02:24 --> Total execution time: 0.0389
ERROR - 2018-07-16 19:12:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:12:24 --> Config Class Initialized
INFO - 2018-07-16 19:12:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:12:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:12:24 --> Utf8 Class Initialized
INFO - 2018-07-16 19:12:24 --> URI Class Initialized
INFO - 2018-07-16 19:12:24 --> Router Class Initialized
INFO - 2018-07-16 19:12:24 --> Output Class Initialized
INFO - 2018-07-16 19:12:24 --> Security Class Initialized
DEBUG - 2018-07-16 19:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:12:24 --> Input Class Initialized
INFO - 2018-07-16 19:12:24 --> Language Class Initialized
INFO - 2018-07-16 19:12:24 --> Loader Class Initialized
INFO - 2018-07-16 19:12:24 --> Controller Class Initialized
INFO - 2018-07-16 19:12:24 --> Database Driver Class Initialized
INFO - 2018-07-16 19:12:24 --> Model Class Initialized
INFO - 2018-07-16 19:12:24 --> Helper loaded: url_helper
INFO - 2018-07-16 19:12:24 --> Model Class Initialized
INFO - 2018-07-16 19:12:24 --> Final output sent to browser
DEBUG - 2018-07-16 19:12:24 --> Total execution time: 0.0397
ERROR - 2018-07-16 19:12:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:12:26 --> Config Class Initialized
INFO - 2018-07-16 19:12:26 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:12:26 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:12:26 --> Utf8 Class Initialized
INFO - 2018-07-16 19:12:26 --> URI Class Initialized
INFO - 2018-07-16 19:12:26 --> Router Class Initialized
INFO - 2018-07-16 19:12:26 --> Output Class Initialized
INFO - 2018-07-16 19:12:26 --> Security Class Initialized
DEBUG - 2018-07-16 19:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:12:26 --> Input Class Initialized
INFO - 2018-07-16 19:12:26 --> Language Class Initialized
INFO - 2018-07-16 19:12:26 --> Loader Class Initialized
INFO - 2018-07-16 19:12:26 --> Controller Class Initialized
INFO - 2018-07-16 19:12:26 --> Database Driver Class Initialized
INFO - 2018-07-16 19:12:26 --> Model Class Initialized
INFO - 2018-07-16 19:12:26 --> Helper loaded: url_helper
INFO - 2018-07-16 19:12:26 --> Model Class Initialized
INFO - 2018-07-16 19:12:26 --> Final output sent to browser
DEBUG - 2018-07-16 19:12:26 --> Total execution time: 0.0697
ERROR - 2018-07-16 19:12:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:12:26 --> Config Class Initialized
INFO - 2018-07-16 19:12:26 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:12:26 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:12:26 --> Utf8 Class Initialized
INFO - 2018-07-16 19:12:26 --> URI Class Initialized
INFO - 2018-07-16 19:12:26 --> Router Class Initialized
INFO - 2018-07-16 19:12:26 --> Output Class Initialized
INFO - 2018-07-16 19:12:26 --> Security Class Initialized
DEBUG - 2018-07-16 19:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:12:26 --> Input Class Initialized
INFO - 2018-07-16 19:12:26 --> Language Class Initialized
INFO - 2018-07-16 19:12:26 --> Loader Class Initialized
INFO - 2018-07-16 19:12:26 --> Controller Class Initialized
INFO - 2018-07-16 19:12:26 --> Database Driver Class Initialized
INFO - 2018-07-16 19:12:26 --> Model Class Initialized
INFO - 2018-07-16 19:12:26 --> Helper loaded: url_helper
INFO - 2018-07-16 19:12:26 --> Model Class Initialized
INFO - 2018-07-16 19:12:26 --> Final output sent to browser
DEBUG - 2018-07-16 19:12:26 --> Total execution time: 0.0527
ERROR - 2018-07-16 19:17:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:17:51 --> Config Class Initialized
INFO - 2018-07-16 19:17:51 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:17:51 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:17:51 --> Utf8 Class Initialized
INFO - 2018-07-16 19:17:51 --> URI Class Initialized
INFO - 2018-07-16 19:17:51 --> Router Class Initialized
INFO - 2018-07-16 19:17:51 --> Output Class Initialized
INFO - 2018-07-16 19:17:51 --> Security Class Initialized
DEBUG - 2018-07-16 19:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:17:51 --> Input Class Initialized
INFO - 2018-07-16 19:17:51 --> Language Class Initialized
INFO - 2018-07-16 19:17:51 --> Loader Class Initialized
INFO - 2018-07-16 19:17:51 --> Controller Class Initialized
INFO - 2018-07-16 19:17:51 --> Database Driver Class Initialized
INFO - 2018-07-16 19:17:51 --> Model Class Initialized
INFO - 2018-07-16 19:17:51 --> Helper loaded: url_helper
INFO - 2018-07-16 19:17:51 --> Model Class Initialized
INFO - 2018-07-16 19:17:51 --> Final output sent to browser
DEBUG - 2018-07-16 19:17:51 --> Total execution time: 0.0449
ERROR - 2018-07-16 19:17:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:17:52 --> Config Class Initialized
INFO - 2018-07-16 19:17:52 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:17:52 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:17:52 --> Utf8 Class Initialized
INFO - 2018-07-16 19:17:52 --> URI Class Initialized
INFO - 2018-07-16 19:17:52 --> Router Class Initialized
INFO - 2018-07-16 19:17:52 --> Output Class Initialized
INFO - 2018-07-16 19:17:52 --> Security Class Initialized
DEBUG - 2018-07-16 19:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:17:52 --> Input Class Initialized
INFO - 2018-07-16 19:17:52 --> Language Class Initialized
INFO - 2018-07-16 19:17:52 --> Loader Class Initialized
INFO - 2018-07-16 19:17:52 --> Controller Class Initialized
INFO - 2018-07-16 19:17:52 --> Database Driver Class Initialized
INFO - 2018-07-16 19:17:52 --> Model Class Initialized
INFO - 2018-07-16 19:17:52 --> Helper loaded: url_helper
INFO - 2018-07-16 19:17:52 --> Model Class Initialized
INFO - 2018-07-16 19:17:52 --> Final output sent to browser
DEBUG - 2018-07-16 19:17:52 --> Total execution time: 0.0542
ERROR - 2018-07-16 19:17:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:17:52 --> Config Class Initialized
INFO - 2018-07-16 19:17:52 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:17:52 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:17:52 --> Utf8 Class Initialized
INFO - 2018-07-16 19:17:52 --> URI Class Initialized
INFO - 2018-07-16 19:17:52 --> Router Class Initialized
INFO - 2018-07-16 19:17:52 --> Output Class Initialized
INFO - 2018-07-16 19:17:52 --> Security Class Initialized
DEBUG - 2018-07-16 19:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:17:52 --> Input Class Initialized
INFO - 2018-07-16 19:17:52 --> Language Class Initialized
INFO - 2018-07-16 19:17:52 --> Loader Class Initialized
INFO - 2018-07-16 19:17:52 --> Controller Class Initialized
INFO - 2018-07-16 19:17:52 --> Database Driver Class Initialized
INFO - 2018-07-16 19:17:52 --> Model Class Initialized
INFO - 2018-07-16 19:17:52 --> Helper loaded: url_helper
INFO - 2018-07-16 19:17:52 --> Model Class Initialized
INFO - 2018-07-16 19:17:52 --> Final output sent to browser
DEBUG - 2018-07-16 19:17:52 --> Total execution time: 0.0641
ERROR - 2018-07-16 19:21:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:21:13 --> Config Class Initialized
INFO - 2018-07-16 19:21:13 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:21:13 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:21:13 --> Utf8 Class Initialized
INFO - 2018-07-16 19:21:13 --> URI Class Initialized
INFO - 2018-07-16 19:21:13 --> Router Class Initialized
INFO - 2018-07-16 19:21:13 --> Output Class Initialized
INFO - 2018-07-16 19:21:13 --> Security Class Initialized
DEBUG - 2018-07-16 19:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:21:13 --> Input Class Initialized
INFO - 2018-07-16 19:21:13 --> Language Class Initialized
INFO - 2018-07-16 19:21:13 --> Loader Class Initialized
INFO - 2018-07-16 19:21:13 --> Controller Class Initialized
INFO - 2018-07-16 19:21:13 --> Database Driver Class Initialized
INFO - 2018-07-16 19:21:14 --> Model Class Initialized
INFO - 2018-07-16 19:21:14 --> Helper loaded: url_helper
INFO - 2018-07-16 19:21:14 --> Model Class Initialized
INFO - 2018-07-16 19:21:14 --> Final output sent to browser
DEBUG - 2018-07-16 19:21:14 --> Total execution time: 0.0626
ERROR - 2018-07-16 19:21:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:21:14 --> Config Class Initialized
INFO - 2018-07-16 19:21:14 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:21:14 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:21:14 --> Utf8 Class Initialized
INFO - 2018-07-16 19:21:14 --> URI Class Initialized
INFO - 2018-07-16 19:21:14 --> Router Class Initialized
INFO - 2018-07-16 19:21:14 --> Output Class Initialized
INFO - 2018-07-16 19:21:14 --> Security Class Initialized
DEBUG - 2018-07-16 19:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:21:14 --> Input Class Initialized
INFO - 2018-07-16 19:21:14 --> Language Class Initialized
INFO - 2018-07-16 19:21:14 --> Loader Class Initialized
INFO - 2018-07-16 19:21:14 --> Controller Class Initialized
INFO - 2018-07-16 19:21:14 --> Database Driver Class Initialized
INFO - 2018-07-16 19:21:14 --> Model Class Initialized
INFO - 2018-07-16 19:21:14 --> Helper loaded: url_helper
INFO - 2018-07-16 19:21:14 --> Model Class Initialized
INFO - 2018-07-16 19:21:14 --> Final output sent to browser
DEBUG - 2018-07-16 19:21:14 --> Total execution time: 0.0570
ERROR - 2018-07-16 19:21:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:21:14 --> Config Class Initialized
INFO - 2018-07-16 19:21:14 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:21:14 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:21:14 --> Utf8 Class Initialized
INFO - 2018-07-16 19:21:14 --> URI Class Initialized
INFO - 2018-07-16 19:21:14 --> Router Class Initialized
INFO - 2018-07-16 19:21:14 --> Output Class Initialized
INFO - 2018-07-16 19:21:14 --> Security Class Initialized
DEBUG - 2018-07-16 19:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:21:14 --> Input Class Initialized
INFO - 2018-07-16 19:21:14 --> Language Class Initialized
INFO - 2018-07-16 19:21:14 --> Loader Class Initialized
INFO - 2018-07-16 19:21:14 --> Controller Class Initialized
INFO - 2018-07-16 19:21:14 --> Database Driver Class Initialized
INFO - 2018-07-16 19:21:14 --> Model Class Initialized
INFO - 2018-07-16 19:21:14 --> Helper loaded: url_helper
INFO - 2018-07-16 19:21:14 --> Model Class Initialized
INFO - 2018-07-16 19:21:14 --> Final output sent to browser
DEBUG - 2018-07-16 19:21:14 --> Total execution time: 0.0529
ERROR - 2018-07-16 19:25:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:25:52 --> Config Class Initialized
INFO - 2018-07-16 19:25:52 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:25:52 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:25:52 --> Utf8 Class Initialized
INFO - 2018-07-16 19:25:52 --> URI Class Initialized
INFO - 2018-07-16 19:25:52 --> Router Class Initialized
INFO - 2018-07-16 19:25:52 --> Output Class Initialized
INFO - 2018-07-16 19:25:52 --> Security Class Initialized
DEBUG - 2018-07-16 19:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:25:52 --> Input Class Initialized
INFO - 2018-07-16 19:25:52 --> Language Class Initialized
INFO - 2018-07-16 19:25:52 --> Loader Class Initialized
INFO - 2018-07-16 19:25:52 --> Controller Class Initialized
INFO - 2018-07-16 19:25:52 --> Database Driver Class Initialized
INFO - 2018-07-16 19:25:52 --> Model Class Initialized
INFO - 2018-07-16 19:25:52 --> Helper loaded: url_helper
INFO - 2018-07-16 19:25:52 --> Model Class Initialized
INFO - 2018-07-16 19:25:52 --> Final output sent to browser
DEBUG - 2018-07-16 19:25:52 --> Total execution time: 0.0537
ERROR - 2018-07-16 19:25:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:25:53 --> Config Class Initialized
INFO - 2018-07-16 19:25:53 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:25:53 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:25:53 --> Utf8 Class Initialized
INFO - 2018-07-16 19:25:53 --> URI Class Initialized
INFO - 2018-07-16 19:25:53 --> Router Class Initialized
INFO - 2018-07-16 19:25:53 --> Output Class Initialized
INFO - 2018-07-16 19:25:53 --> Security Class Initialized
DEBUG - 2018-07-16 19:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:25:53 --> Input Class Initialized
INFO - 2018-07-16 19:25:53 --> Language Class Initialized
INFO - 2018-07-16 19:25:53 --> Loader Class Initialized
INFO - 2018-07-16 19:25:53 --> Controller Class Initialized
INFO - 2018-07-16 19:25:53 --> Database Driver Class Initialized
INFO - 2018-07-16 19:25:53 --> Model Class Initialized
INFO - 2018-07-16 19:25:53 --> Helper loaded: url_helper
INFO - 2018-07-16 19:25:53 --> Model Class Initialized
INFO - 2018-07-16 19:25:53 --> Final output sent to browser
DEBUG - 2018-07-16 19:25:53 --> Total execution time: 0.0547
ERROR - 2018-07-16 19:25:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:25:53 --> Config Class Initialized
INFO - 2018-07-16 19:25:53 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:25:53 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:25:53 --> Utf8 Class Initialized
INFO - 2018-07-16 19:25:53 --> URI Class Initialized
INFO - 2018-07-16 19:25:53 --> Router Class Initialized
INFO - 2018-07-16 19:25:53 --> Output Class Initialized
INFO - 2018-07-16 19:25:53 --> Security Class Initialized
DEBUG - 2018-07-16 19:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:25:53 --> Input Class Initialized
INFO - 2018-07-16 19:25:53 --> Language Class Initialized
INFO - 2018-07-16 19:25:53 --> Loader Class Initialized
INFO - 2018-07-16 19:25:53 --> Controller Class Initialized
INFO - 2018-07-16 19:25:53 --> Database Driver Class Initialized
INFO - 2018-07-16 19:25:53 --> Model Class Initialized
INFO - 2018-07-16 19:25:53 --> Helper loaded: url_helper
INFO - 2018-07-16 19:25:53 --> Model Class Initialized
INFO - 2018-07-16 19:25:53 --> Final output sent to browser
DEBUG - 2018-07-16 19:25:53 --> Total execution time: 0.0502
ERROR - 2018-07-16 19:26:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:26:57 --> Config Class Initialized
INFO - 2018-07-16 19:26:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:26:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:26:57 --> Utf8 Class Initialized
INFO - 2018-07-16 19:26:57 --> URI Class Initialized
INFO - 2018-07-16 19:26:57 --> Router Class Initialized
INFO - 2018-07-16 19:26:57 --> Output Class Initialized
INFO - 2018-07-16 19:26:57 --> Security Class Initialized
DEBUG - 2018-07-16 19:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:26:57 --> Input Class Initialized
INFO - 2018-07-16 19:26:57 --> Language Class Initialized
INFO - 2018-07-16 19:26:57 --> Loader Class Initialized
INFO - 2018-07-16 19:26:57 --> Controller Class Initialized
INFO - 2018-07-16 19:26:57 --> Database Driver Class Initialized
INFO - 2018-07-16 19:26:57 --> Model Class Initialized
INFO - 2018-07-16 19:26:57 --> Helper loaded: url_helper
INFO - 2018-07-16 19:26:57 --> Model Class Initialized
INFO - 2018-07-16 19:26:57 --> Final output sent to browser
DEBUG - 2018-07-16 19:26:57 --> Total execution time: 0.0479
ERROR - 2018-07-16 19:26:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:26:58 --> Config Class Initialized
INFO - 2018-07-16 19:26:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:26:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:26:58 --> Utf8 Class Initialized
INFO - 2018-07-16 19:26:58 --> URI Class Initialized
INFO - 2018-07-16 19:26:58 --> Router Class Initialized
INFO - 2018-07-16 19:26:58 --> Output Class Initialized
INFO - 2018-07-16 19:26:58 --> Security Class Initialized
DEBUG - 2018-07-16 19:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:26:58 --> Input Class Initialized
INFO - 2018-07-16 19:26:58 --> Language Class Initialized
INFO - 2018-07-16 19:26:58 --> Loader Class Initialized
INFO - 2018-07-16 19:26:58 --> Controller Class Initialized
INFO - 2018-07-16 19:26:58 --> Database Driver Class Initialized
INFO - 2018-07-16 19:26:58 --> Model Class Initialized
INFO - 2018-07-16 19:26:58 --> Helper loaded: url_helper
INFO - 2018-07-16 19:26:58 --> Model Class Initialized
INFO - 2018-07-16 19:26:58 --> Final output sent to browser
DEBUG - 2018-07-16 19:26:58 --> Total execution time: 0.0553
ERROR - 2018-07-16 19:26:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:26:58 --> Config Class Initialized
INFO - 2018-07-16 19:26:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:26:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:26:58 --> Utf8 Class Initialized
INFO - 2018-07-16 19:26:58 --> URI Class Initialized
INFO - 2018-07-16 19:26:58 --> Router Class Initialized
INFO - 2018-07-16 19:26:58 --> Output Class Initialized
INFO - 2018-07-16 19:26:58 --> Security Class Initialized
DEBUG - 2018-07-16 19:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:26:58 --> Input Class Initialized
INFO - 2018-07-16 19:26:58 --> Language Class Initialized
INFO - 2018-07-16 19:26:58 --> Loader Class Initialized
INFO - 2018-07-16 19:26:58 --> Controller Class Initialized
INFO - 2018-07-16 19:26:58 --> Database Driver Class Initialized
INFO - 2018-07-16 19:26:58 --> Model Class Initialized
INFO - 2018-07-16 19:26:58 --> Helper loaded: url_helper
INFO - 2018-07-16 19:26:58 --> Model Class Initialized
INFO - 2018-07-16 19:26:58 --> Final output sent to browser
DEBUG - 2018-07-16 19:26:58 --> Total execution time: 0.0492
ERROR - 2018-07-16 19:45:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:45:24 --> Config Class Initialized
INFO - 2018-07-16 19:45:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:45:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:45:24 --> Utf8 Class Initialized
INFO - 2018-07-16 19:45:24 --> URI Class Initialized
INFO - 2018-07-16 19:45:24 --> Router Class Initialized
INFO - 2018-07-16 19:45:24 --> Output Class Initialized
INFO - 2018-07-16 19:45:24 --> Security Class Initialized
DEBUG - 2018-07-16 19:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:45:24 --> Input Class Initialized
INFO - 2018-07-16 19:45:24 --> Language Class Initialized
INFO - 2018-07-16 19:45:24 --> Loader Class Initialized
INFO - 2018-07-16 19:45:24 --> Controller Class Initialized
INFO - 2018-07-16 19:45:24 --> Database Driver Class Initialized
INFO - 2018-07-16 19:45:24 --> Model Class Initialized
INFO - 2018-07-16 19:45:24 --> Helper loaded: url_helper
INFO - 2018-07-16 19:45:24 --> Model Class Initialized
INFO - 2018-07-16 19:45:24 --> Final output sent to browser
DEBUG - 2018-07-16 19:45:24 --> Total execution time: 0.0590
ERROR - 2018-07-16 19:45:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:45:24 --> Config Class Initialized
INFO - 2018-07-16 19:45:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:45:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:45:24 --> Utf8 Class Initialized
INFO - 2018-07-16 19:45:24 --> URI Class Initialized
INFO - 2018-07-16 19:45:24 --> Router Class Initialized
INFO - 2018-07-16 19:45:24 --> Output Class Initialized
INFO - 2018-07-16 19:45:24 --> Security Class Initialized
DEBUG - 2018-07-16 19:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:45:24 --> Input Class Initialized
INFO - 2018-07-16 19:45:24 --> Language Class Initialized
INFO - 2018-07-16 19:45:24 --> Loader Class Initialized
INFO - 2018-07-16 19:45:24 --> Controller Class Initialized
INFO - 2018-07-16 19:45:24 --> Database Driver Class Initialized
INFO - 2018-07-16 19:45:24 --> Model Class Initialized
INFO - 2018-07-16 19:45:24 --> Helper loaded: url_helper
INFO - 2018-07-16 19:45:24 --> Model Class Initialized
INFO - 2018-07-16 19:45:24 --> Final output sent to browser
DEBUG - 2018-07-16 19:45:24 --> Total execution time: 0.0571
ERROR - 2018-07-16 19:45:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:45:24 --> Config Class Initialized
INFO - 2018-07-16 19:45:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:45:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:45:24 --> Utf8 Class Initialized
INFO - 2018-07-16 19:45:24 --> URI Class Initialized
INFO - 2018-07-16 19:45:24 --> Router Class Initialized
INFO - 2018-07-16 19:45:24 --> Output Class Initialized
INFO - 2018-07-16 19:45:24 --> Security Class Initialized
DEBUG - 2018-07-16 19:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:45:24 --> Input Class Initialized
INFO - 2018-07-16 19:45:24 --> Language Class Initialized
INFO - 2018-07-16 19:45:24 --> Loader Class Initialized
INFO - 2018-07-16 19:45:24 --> Controller Class Initialized
INFO - 2018-07-16 19:45:24 --> Database Driver Class Initialized
INFO - 2018-07-16 19:45:24 --> Model Class Initialized
INFO - 2018-07-16 19:45:24 --> Helper loaded: url_helper
INFO - 2018-07-16 19:45:24 --> Model Class Initialized
INFO - 2018-07-16 19:45:24 --> Final output sent to browser
DEBUG - 2018-07-16 19:45:24 --> Total execution time: 0.0413
ERROR - 2018-07-16 19:48:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:48:24 --> Config Class Initialized
INFO - 2018-07-16 19:48:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:48:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:48:24 --> Utf8 Class Initialized
INFO - 2018-07-16 19:48:24 --> URI Class Initialized
INFO - 2018-07-16 19:48:24 --> Router Class Initialized
INFO - 2018-07-16 19:48:24 --> Output Class Initialized
INFO - 2018-07-16 19:48:24 --> Security Class Initialized
DEBUG - 2018-07-16 19:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:48:24 --> Input Class Initialized
INFO - 2018-07-16 19:48:24 --> Language Class Initialized
INFO - 2018-07-16 19:48:24 --> Loader Class Initialized
INFO - 2018-07-16 19:48:24 --> Controller Class Initialized
INFO - 2018-07-16 19:48:24 --> Database Driver Class Initialized
INFO - 2018-07-16 19:48:24 --> Model Class Initialized
INFO - 2018-07-16 19:48:24 --> Helper loaded: url_helper
INFO - 2018-07-16 19:48:24 --> Model Class Initialized
INFO - 2018-07-16 19:48:24 --> Final output sent to browser
DEBUG - 2018-07-16 19:48:24 --> Total execution time: 0.0500
ERROR - 2018-07-16 19:48:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:48:25 --> Config Class Initialized
INFO - 2018-07-16 19:48:25 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:48:25 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:48:25 --> Utf8 Class Initialized
INFO - 2018-07-16 19:48:25 --> URI Class Initialized
INFO - 2018-07-16 19:48:25 --> Router Class Initialized
INFO - 2018-07-16 19:48:25 --> Output Class Initialized
INFO - 2018-07-16 19:48:25 --> Security Class Initialized
DEBUG - 2018-07-16 19:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:48:25 --> Input Class Initialized
INFO - 2018-07-16 19:48:25 --> Language Class Initialized
INFO - 2018-07-16 19:48:25 --> Loader Class Initialized
INFO - 2018-07-16 19:48:25 --> Controller Class Initialized
INFO - 2018-07-16 19:48:25 --> Database Driver Class Initialized
INFO - 2018-07-16 19:48:25 --> Model Class Initialized
INFO - 2018-07-16 19:48:25 --> Helper loaded: url_helper
INFO - 2018-07-16 19:48:25 --> Model Class Initialized
INFO - 2018-07-16 19:48:25 --> Final output sent to browser
DEBUG - 2018-07-16 19:48:25 --> Total execution time: 0.0454
ERROR - 2018-07-16 19:48:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:48:25 --> Config Class Initialized
INFO - 2018-07-16 19:48:25 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:48:25 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:48:25 --> Utf8 Class Initialized
INFO - 2018-07-16 19:48:25 --> URI Class Initialized
INFO - 2018-07-16 19:48:25 --> Router Class Initialized
INFO - 2018-07-16 19:48:25 --> Output Class Initialized
INFO - 2018-07-16 19:48:25 --> Security Class Initialized
DEBUG - 2018-07-16 19:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:48:25 --> Input Class Initialized
INFO - 2018-07-16 19:48:25 --> Language Class Initialized
INFO - 2018-07-16 19:48:25 --> Loader Class Initialized
INFO - 2018-07-16 19:48:25 --> Controller Class Initialized
INFO - 2018-07-16 19:48:25 --> Database Driver Class Initialized
INFO - 2018-07-16 19:48:25 --> Model Class Initialized
INFO - 2018-07-16 19:48:25 --> Helper loaded: url_helper
INFO - 2018-07-16 19:48:25 --> Model Class Initialized
INFO - 2018-07-16 19:48:25 --> Final output sent to browser
DEBUG - 2018-07-16 19:48:25 --> Total execution time: 0.0616
ERROR - 2018-07-16 19:51:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:51:59 --> Config Class Initialized
INFO - 2018-07-16 19:51:59 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:51:59 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:51:59 --> Utf8 Class Initialized
INFO - 2018-07-16 19:51:59 --> URI Class Initialized
INFO - 2018-07-16 19:51:59 --> Router Class Initialized
INFO - 2018-07-16 19:51:59 --> Output Class Initialized
INFO - 2018-07-16 19:51:59 --> Security Class Initialized
DEBUG - 2018-07-16 19:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:51:59 --> Input Class Initialized
INFO - 2018-07-16 19:51:59 --> Language Class Initialized
INFO - 2018-07-16 19:51:59 --> Loader Class Initialized
INFO - 2018-07-16 19:51:59 --> Controller Class Initialized
INFO - 2018-07-16 19:51:59 --> Database Driver Class Initialized
INFO - 2018-07-16 19:51:59 --> Model Class Initialized
INFO - 2018-07-16 19:51:59 --> Helper loaded: url_helper
INFO - 2018-07-16 19:51:59 --> Model Class Initialized
INFO - 2018-07-16 19:51:59 --> Final output sent to browser
DEBUG - 2018-07-16 19:51:59 --> Total execution time: 0.0490
ERROR - 2018-07-16 19:52:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:52:00 --> Config Class Initialized
INFO - 2018-07-16 19:52:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:52:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:52:00 --> Utf8 Class Initialized
INFO - 2018-07-16 19:52:00 --> URI Class Initialized
INFO - 2018-07-16 19:52:00 --> Router Class Initialized
INFO - 2018-07-16 19:52:00 --> Output Class Initialized
INFO - 2018-07-16 19:52:00 --> Security Class Initialized
DEBUG - 2018-07-16 19:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:52:00 --> Input Class Initialized
INFO - 2018-07-16 19:52:00 --> Language Class Initialized
INFO - 2018-07-16 19:52:00 --> Loader Class Initialized
INFO - 2018-07-16 19:52:00 --> Controller Class Initialized
INFO - 2018-07-16 19:52:00 --> Database Driver Class Initialized
INFO - 2018-07-16 19:52:00 --> Model Class Initialized
INFO - 2018-07-16 19:52:00 --> Helper loaded: url_helper
INFO - 2018-07-16 19:52:00 --> Model Class Initialized
INFO - 2018-07-16 19:52:00 --> Final output sent to browser
DEBUG - 2018-07-16 19:52:00 --> Total execution time: 0.0424
ERROR - 2018-07-16 19:52:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:52:00 --> Config Class Initialized
INFO - 2018-07-16 19:52:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:52:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:52:00 --> Utf8 Class Initialized
INFO - 2018-07-16 19:52:00 --> URI Class Initialized
INFO - 2018-07-16 19:52:00 --> Router Class Initialized
INFO - 2018-07-16 19:52:00 --> Output Class Initialized
INFO - 2018-07-16 19:52:00 --> Security Class Initialized
DEBUG - 2018-07-16 19:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:52:00 --> Input Class Initialized
INFO - 2018-07-16 19:52:00 --> Language Class Initialized
INFO - 2018-07-16 19:52:00 --> Loader Class Initialized
INFO - 2018-07-16 19:52:00 --> Controller Class Initialized
INFO - 2018-07-16 19:52:00 --> Database Driver Class Initialized
INFO - 2018-07-16 19:52:00 --> Model Class Initialized
INFO - 2018-07-16 19:52:00 --> Helper loaded: url_helper
INFO - 2018-07-16 19:52:00 --> Model Class Initialized
INFO - 2018-07-16 19:52:00 --> Final output sent to browser
DEBUG - 2018-07-16 19:52:00 --> Total execution time: 0.0567
ERROR - 2018-07-16 19:53:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:53:23 --> Config Class Initialized
INFO - 2018-07-16 19:53:23 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:53:23 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:53:23 --> Utf8 Class Initialized
INFO - 2018-07-16 19:53:23 --> URI Class Initialized
INFO - 2018-07-16 19:53:23 --> Router Class Initialized
INFO - 2018-07-16 19:53:23 --> Output Class Initialized
INFO - 2018-07-16 19:53:23 --> Security Class Initialized
DEBUG - 2018-07-16 19:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:53:23 --> Input Class Initialized
INFO - 2018-07-16 19:53:23 --> Language Class Initialized
INFO - 2018-07-16 19:53:23 --> Loader Class Initialized
INFO - 2018-07-16 19:53:23 --> Controller Class Initialized
INFO - 2018-07-16 19:53:23 --> Database Driver Class Initialized
INFO - 2018-07-16 19:53:23 --> Model Class Initialized
INFO - 2018-07-16 19:53:23 --> Helper loaded: url_helper
INFO - 2018-07-16 19:53:23 --> Model Class Initialized
INFO - 2018-07-16 19:53:23 --> Final output sent to browser
DEBUG - 2018-07-16 19:53:23 --> Total execution time: 0.0488
ERROR - 2018-07-16 19:53:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:53:24 --> Config Class Initialized
INFO - 2018-07-16 19:53:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:53:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:53:24 --> Utf8 Class Initialized
INFO - 2018-07-16 19:53:24 --> URI Class Initialized
INFO - 2018-07-16 19:53:24 --> Router Class Initialized
INFO - 2018-07-16 19:53:24 --> Output Class Initialized
INFO - 2018-07-16 19:53:24 --> Security Class Initialized
DEBUG - 2018-07-16 19:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:53:24 --> Input Class Initialized
INFO - 2018-07-16 19:53:24 --> Language Class Initialized
INFO - 2018-07-16 19:53:24 --> Loader Class Initialized
INFO - 2018-07-16 19:53:24 --> Controller Class Initialized
INFO - 2018-07-16 19:53:24 --> Database Driver Class Initialized
INFO - 2018-07-16 19:53:24 --> Model Class Initialized
INFO - 2018-07-16 19:53:24 --> Helper loaded: url_helper
INFO - 2018-07-16 19:53:24 --> Model Class Initialized
INFO - 2018-07-16 19:53:24 --> Final output sent to browser
DEBUG - 2018-07-16 19:53:24 --> Total execution time: 0.0386
ERROR - 2018-07-16 19:53:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:53:24 --> Config Class Initialized
INFO - 2018-07-16 19:53:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:53:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:53:24 --> Utf8 Class Initialized
INFO - 2018-07-16 19:53:24 --> URI Class Initialized
INFO - 2018-07-16 19:53:24 --> Router Class Initialized
INFO - 2018-07-16 19:53:24 --> Output Class Initialized
INFO - 2018-07-16 19:53:24 --> Security Class Initialized
DEBUG - 2018-07-16 19:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:53:24 --> Input Class Initialized
INFO - 2018-07-16 19:53:24 --> Language Class Initialized
INFO - 2018-07-16 19:53:24 --> Loader Class Initialized
INFO - 2018-07-16 19:53:24 --> Controller Class Initialized
INFO - 2018-07-16 19:53:24 --> Database Driver Class Initialized
INFO - 2018-07-16 19:53:24 --> Model Class Initialized
INFO - 2018-07-16 19:53:24 --> Helper loaded: url_helper
INFO - 2018-07-16 19:53:24 --> Model Class Initialized
INFO - 2018-07-16 19:53:24 --> Final output sent to browser
DEBUG - 2018-07-16 19:53:24 --> Total execution time: 0.0404
ERROR - 2018-07-16 19:57:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:57:01 --> Config Class Initialized
INFO - 2018-07-16 19:57:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:57:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:57:01 --> Utf8 Class Initialized
INFO - 2018-07-16 19:57:01 --> URI Class Initialized
INFO - 2018-07-16 19:57:01 --> Router Class Initialized
INFO - 2018-07-16 19:57:01 --> Output Class Initialized
INFO - 2018-07-16 19:57:01 --> Security Class Initialized
DEBUG - 2018-07-16 19:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:57:01 --> Input Class Initialized
INFO - 2018-07-16 19:57:01 --> Language Class Initialized
INFO - 2018-07-16 19:57:01 --> Loader Class Initialized
INFO - 2018-07-16 19:57:01 --> Controller Class Initialized
INFO - 2018-07-16 19:57:01 --> Database Driver Class Initialized
INFO - 2018-07-16 19:57:01 --> Model Class Initialized
INFO - 2018-07-16 19:57:01 --> Helper loaded: url_helper
INFO - 2018-07-16 19:57:01 --> Model Class Initialized
INFO - 2018-07-16 19:57:01 --> Final output sent to browser
DEBUG - 2018-07-16 19:57:01 --> Total execution time: 0.0550
ERROR - 2018-07-16 19:57:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:57:01 --> Config Class Initialized
INFO - 2018-07-16 19:57:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:57:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:57:01 --> Utf8 Class Initialized
INFO - 2018-07-16 19:57:01 --> URI Class Initialized
INFO - 2018-07-16 19:57:01 --> Router Class Initialized
INFO - 2018-07-16 19:57:01 --> Output Class Initialized
INFO - 2018-07-16 19:57:01 --> Security Class Initialized
DEBUG - 2018-07-16 19:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:57:01 --> Input Class Initialized
INFO - 2018-07-16 19:57:01 --> Language Class Initialized
INFO - 2018-07-16 19:57:01 --> Loader Class Initialized
INFO - 2018-07-16 19:57:01 --> Controller Class Initialized
INFO - 2018-07-16 19:57:01 --> Database Driver Class Initialized
INFO - 2018-07-16 19:57:01 --> Model Class Initialized
INFO - 2018-07-16 19:57:01 --> Helper loaded: url_helper
INFO - 2018-07-16 19:57:01 --> Model Class Initialized
INFO - 2018-07-16 19:57:01 --> Final output sent to browser
DEBUG - 2018-07-16 19:57:01 --> Total execution time: 0.0359
ERROR - 2018-07-16 19:57:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:57:01 --> Config Class Initialized
INFO - 2018-07-16 19:57:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:57:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:57:01 --> Utf8 Class Initialized
INFO - 2018-07-16 19:57:01 --> URI Class Initialized
INFO - 2018-07-16 19:57:01 --> Router Class Initialized
INFO - 2018-07-16 19:57:01 --> Output Class Initialized
INFO - 2018-07-16 19:57:01 --> Security Class Initialized
DEBUG - 2018-07-16 19:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:57:01 --> Input Class Initialized
INFO - 2018-07-16 19:57:01 --> Language Class Initialized
INFO - 2018-07-16 19:57:01 --> Loader Class Initialized
INFO - 2018-07-16 19:57:01 --> Controller Class Initialized
INFO - 2018-07-16 19:57:01 --> Database Driver Class Initialized
INFO - 2018-07-16 19:57:01 --> Model Class Initialized
INFO - 2018-07-16 19:57:01 --> Helper loaded: url_helper
INFO - 2018-07-16 19:57:01 --> Model Class Initialized
INFO - 2018-07-16 19:57:01 --> Final output sent to browser
DEBUG - 2018-07-16 19:57:01 --> Total execution time: 0.0629
ERROR - 2018-07-16 19:58:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:58:35 --> Config Class Initialized
INFO - 2018-07-16 19:58:35 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:58:35 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:58:35 --> Utf8 Class Initialized
INFO - 2018-07-16 19:58:35 --> URI Class Initialized
INFO - 2018-07-16 19:58:35 --> Router Class Initialized
INFO - 2018-07-16 19:58:35 --> Output Class Initialized
INFO - 2018-07-16 19:58:35 --> Security Class Initialized
DEBUG - 2018-07-16 19:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:58:35 --> Input Class Initialized
INFO - 2018-07-16 19:58:35 --> Language Class Initialized
INFO - 2018-07-16 19:58:35 --> Loader Class Initialized
INFO - 2018-07-16 19:58:35 --> Controller Class Initialized
INFO - 2018-07-16 19:58:35 --> Database Driver Class Initialized
INFO - 2018-07-16 19:58:35 --> Model Class Initialized
INFO - 2018-07-16 19:58:35 --> Helper loaded: url_helper
INFO - 2018-07-16 19:58:35 --> Model Class Initialized
INFO - 2018-07-16 19:58:35 --> Final output sent to browser
DEBUG - 2018-07-16 19:58:35 --> Total execution time: 0.0562
ERROR - 2018-07-16 19:58:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:58:35 --> Config Class Initialized
INFO - 2018-07-16 19:58:35 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:58:35 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:58:35 --> Utf8 Class Initialized
INFO - 2018-07-16 19:58:35 --> URI Class Initialized
INFO - 2018-07-16 19:58:35 --> Router Class Initialized
INFO - 2018-07-16 19:58:35 --> Output Class Initialized
INFO - 2018-07-16 19:58:35 --> Security Class Initialized
DEBUG - 2018-07-16 19:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:58:35 --> Input Class Initialized
INFO - 2018-07-16 19:58:35 --> Language Class Initialized
INFO - 2018-07-16 19:58:35 --> Loader Class Initialized
INFO - 2018-07-16 19:58:35 --> Controller Class Initialized
INFO - 2018-07-16 19:58:35 --> Database Driver Class Initialized
INFO - 2018-07-16 19:58:35 --> Model Class Initialized
INFO - 2018-07-16 19:58:35 --> Helper loaded: url_helper
INFO - 2018-07-16 19:58:35 --> Model Class Initialized
INFO - 2018-07-16 19:58:35 --> Final output sent to browser
DEBUG - 2018-07-16 19:58:35 --> Total execution time: 0.0453
ERROR - 2018-07-16 19:58:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 19:58:35 --> Config Class Initialized
INFO - 2018-07-16 19:58:35 --> Hooks Class Initialized
DEBUG - 2018-07-16 19:58:35 --> UTF-8 Support Enabled
INFO - 2018-07-16 19:58:35 --> Utf8 Class Initialized
INFO - 2018-07-16 19:58:35 --> URI Class Initialized
INFO - 2018-07-16 19:58:35 --> Router Class Initialized
INFO - 2018-07-16 19:58:35 --> Output Class Initialized
INFO - 2018-07-16 19:58:35 --> Security Class Initialized
DEBUG - 2018-07-16 19:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 19:58:35 --> Input Class Initialized
INFO - 2018-07-16 19:58:35 --> Language Class Initialized
INFO - 2018-07-16 19:58:35 --> Loader Class Initialized
INFO - 2018-07-16 19:58:35 --> Controller Class Initialized
INFO - 2018-07-16 19:58:35 --> Database Driver Class Initialized
INFO - 2018-07-16 19:58:35 --> Model Class Initialized
INFO - 2018-07-16 19:58:35 --> Helper loaded: url_helper
INFO - 2018-07-16 19:58:35 --> Model Class Initialized
INFO - 2018-07-16 19:58:35 --> Final output sent to browser
DEBUG - 2018-07-16 19:58:35 --> Total execution time: 0.0632
ERROR - 2018-07-16 20:00:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:00:55 --> Config Class Initialized
INFO - 2018-07-16 20:00:55 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:00:55 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:00:55 --> Utf8 Class Initialized
INFO - 2018-07-16 20:00:55 --> URI Class Initialized
INFO - 2018-07-16 20:00:55 --> Router Class Initialized
INFO - 2018-07-16 20:00:55 --> Output Class Initialized
INFO - 2018-07-16 20:00:55 --> Security Class Initialized
DEBUG - 2018-07-16 20:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:00:55 --> Input Class Initialized
INFO - 2018-07-16 20:00:55 --> Language Class Initialized
INFO - 2018-07-16 20:00:55 --> Loader Class Initialized
INFO - 2018-07-16 20:00:55 --> Controller Class Initialized
INFO - 2018-07-16 20:00:55 --> Database Driver Class Initialized
INFO - 2018-07-16 20:00:55 --> Model Class Initialized
INFO - 2018-07-16 20:00:55 --> Helper loaded: url_helper
INFO - 2018-07-16 20:00:55 --> Model Class Initialized
INFO - 2018-07-16 20:00:55 --> Final output sent to browser
DEBUG - 2018-07-16 20:00:55 --> Total execution time: 0.0482
ERROR - 2018-07-16 20:00:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:00:56 --> Config Class Initialized
INFO - 2018-07-16 20:00:56 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:00:56 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:00:56 --> Utf8 Class Initialized
INFO - 2018-07-16 20:00:56 --> URI Class Initialized
INFO - 2018-07-16 20:00:56 --> Router Class Initialized
INFO - 2018-07-16 20:00:56 --> Output Class Initialized
INFO - 2018-07-16 20:00:56 --> Security Class Initialized
DEBUG - 2018-07-16 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:00:56 --> Input Class Initialized
INFO - 2018-07-16 20:00:56 --> Language Class Initialized
INFO - 2018-07-16 20:00:56 --> Loader Class Initialized
INFO - 2018-07-16 20:00:56 --> Controller Class Initialized
INFO - 2018-07-16 20:00:56 --> Database Driver Class Initialized
INFO - 2018-07-16 20:00:56 --> Model Class Initialized
INFO - 2018-07-16 20:00:56 --> Helper loaded: url_helper
INFO - 2018-07-16 20:00:56 --> Model Class Initialized
INFO - 2018-07-16 20:00:56 --> Final output sent to browser
DEBUG - 2018-07-16 20:00:56 --> Total execution time: 0.0758
ERROR - 2018-07-16 20:00:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:00:56 --> Config Class Initialized
INFO - 2018-07-16 20:00:56 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:00:56 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:00:56 --> Utf8 Class Initialized
INFO - 2018-07-16 20:00:56 --> URI Class Initialized
INFO - 2018-07-16 20:00:56 --> Router Class Initialized
INFO - 2018-07-16 20:00:56 --> Output Class Initialized
INFO - 2018-07-16 20:00:56 --> Security Class Initialized
DEBUG - 2018-07-16 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:00:56 --> Input Class Initialized
INFO - 2018-07-16 20:00:56 --> Language Class Initialized
INFO - 2018-07-16 20:00:56 --> Loader Class Initialized
INFO - 2018-07-16 20:00:56 --> Controller Class Initialized
INFO - 2018-07-16 20:00:56 --> Database Driver Class Initialized
INFO - 2018-07-16 20:00:56 --> Model Class Initialized
INFO - 2018-07-16 20:00:56 --> Helper loaded: url_helper
INFO - 2018-07-16 20:00:56 --> Model Class Initialized
INFO - 2018-07-16 20:00:56 --> Final output sent to browser
DEBUG - 2018-07-16 20:00:56 --> Total execution time: 0.0487
ERROR - 2018-07-16 20:07:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:07:35 --> Config Class Initialized
INFO - 2018-07-16 20:07:35 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:07:35 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:07:35 --> Utf8 Class Initialized
INFO - 2018-07-16 20:07:35 --> URI Class Initialized
INFO - 2018-07-16 20:07:35 --> Router Class Initialized
INFO - 2018-07-16 20:07:35 --> Output Class Initialized
INFO - 2018-07-16 20:07:35 --> Security Class Initialized
DEBUG - 2018-07-16 20:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:07:35 --> Input Class Initialized
INFO - 2018-07-16 20:07:35 --> Language Class Initialized
INFO - 2018-07-16 20:07:35 --> Loader Class Initialized
INFO - 2018-07-16 20:07:35 --> Controller Class Initialized
INFO - 2018-07-16 20:07:35 --> Database Driver Class Initialized
INFO - 2018-07-16 20:07:35 --> Model Class Initialized
INFO - 2018-07-16 20:07:35 --> Helper loaded: url_helper
INFO - 2018-07-16 20:07:35 --> Model Class Initialized
INFO - 2018-07-16 20:07:35 --> Final output sent to browser
DEBUG - 2018-07-16 20:07:35 --> Total execution time: 0.0471
ERROR - 2018-07-16 20:07:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:07:36 --> Config Class Initialized
INFO - 2018-07-16 20:07:36 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:07:36 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:07:36 --> Utf8 Class Initialized
INFO - 2018-07-16 20:07:36 --> URI Class Initialized
INFO - 2018-07-16 20:07:36 --> Router Class Initialized
INFO - 2018-07-16 20:07:36 --> Output Class Initialized
INFO - 2018-07-16 20:07:36 --> Security Class Initialized
DEBUG - 2018-07-16 20:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:07:36 --> Input Class Initialized
INFO - 2018-07-16 20:07:36 --> Language Class Initialized
INFO - 2018-07-16 20:07:36 --> Loader Class Initialized
INFO - 2018-07-16 20:07:36 --> Controller Class Initialized
INFO - 2018-07-16 20:07:36 --> Database Driver Class Initialized
INFO - 2018-07-16 20:07:36 --> Model Class Initialized
INFO - 2018-07-16 20:07:36 --> Helper loaded: url_helper
INFO - 2018-07-16 20:07:36 --> Model Class Initialized
INFO - 2018-07-16 20:07:36 --> Final output sent to browser
DEBUG - 2018-07-16 20:07:36 --> Total execution time: 0.0477
ERROR - 2018-07-16 20:07:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:07:36 --> Config Class Initialized
INFO - 2018-07-16 20:07:36 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:07:36 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:07:36 --> Utf8 Class Initialized
INFO - 2018-07-16 20:07:36 --> URI Class Initialized
INFO - 2018-07-16 20:07:36 --> Router Class Initialized
INFO - 2018-07-16 20:07:36 --> Output Class Initialized
INFO - 2018-07-16 20:07:36 --> Security Class Initialized
DEBUG - 2018-07-16 20:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:07:36 --> Input Class Initialized
INFO - 2018-07-16 20:07:36 --> Language Class Initialized
INFO - 2018-07-16 20:07:36 --> Loader Class Initialized
INFO - 2018-07-16 20:07:36 --> Controller Class Initialized
INFO - 2018-07-16 20:07:36 --> Database Driver Class Initialized
INFO - 2018-07-16 20:07:36 --> Model Class Initialized
INFO - 2018-07-16 20:07:36 --> Helper loaded: url_helper
INFO - 2018-07-16 20:07:36 --> Model Class Initialized
INFO - 2018-07-16 20:07:36 --> Final output sent to browser
DEBUG - 2018-07-16 20:07:36 --> Total execution time: 0.0542
ERROR - 2018-07-16 20:08:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:08:42 --> Config Class Initialized
INFO - 2018-07-16 20:08:42 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:08:42 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:08:42 --> Utf8 Class Initialized
INFO - 2018-07-16 20:08:42 --> URI Class Initialized
INFO - 2018-07-16 20:08:42 --> Router Class Initialized
INFO - 2018-07-16 20:08:42 --> Output Class Initialized
INFO - 2018-07-16 20:08:42 --> Security Class Initialized
DEBUG - 2018-07-16 20:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:08:42 --> Input Class Initialized
INFO - 2018-07-16 20:08:42 --> Language Class Initialized
INFO - 2018-07-16 20:08:42 --> Loader Class Initialized
INFO - 2018-07-16 20:08:42 --> Controller Class Initialized
INFO - 2018-07-16 20:08:42 --> Database Driver Class Initialized
INFO - 2018-07-16 20:08:42 --> Model Class Initialized
INFO - 2018-07-16 20:08:42 --> Helper loaded: url_helper
INFO - 2018-07-16 20:08:42 --> Model Class Initialized
INFO - 2018-07-16 20:08:42 --> Final output sent to browser
DEBUG - 2018-07-16 20:08:42 --> Total execution time: 0.0564
ERROR - 2018-07-16 20:08:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:08:42 --> Config Class Initialized
INFO - 2018-07-16 20:08:42 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:08:42 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:08:42 --> Utf8 Class Initialized
INFO - 2018-07-16 20:08:42 --> URI Class Initialized
INFO - 2018-07-16 20:08:42 --> Router Class Initialized
INFO - 2018-07-16 20:08:42 --> Output Class Initialized
INFO - 2018-07-16 20:08:42 --> Security Class Initialized
DEBUG - 2018-07-16 20:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:08:42 --> Input Class Initialized
INFO - 2018-07-16 20:08:42 --> Language Class Initialized
INFO - 2018-07-16 20:08:42 --> Loader Class Initialized
INFO - 2018-07-16 20:08:42 --> Controller Class Initialized
INFO - 2018-07-16 20:08:42 --> Database Driver Class Initialized
INFO - 2018-07-16 20:08:42 --> Model Class Initialized
INFO - 2018-07-16 20:08:42 --> Helper loaded: url_helper
INFO - 2018-07-16 20:08:42 --> Model Class Initialized
INFO - 2018-07-16 20:08:42 --> Final output sent to browser
DEBUG - 2018-07-16 20:08:42 --> Total execution time: 0.0523
ERROR - 2018-07-16 20:08:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:08:42 --> Config Class Initialized
INFO - 2018-07-16 20:08:42 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:08:42 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:08:42 --> Utf8 Class Initialized
INFO - 2018-07-16 20:08:42 --> URI Class Initialized
INFO - 2018-07-16 20:08:42 --> Router Class Initialized
INFO - 2018-07-16 20:08:42 --> Output Class Initialized
INFO - 2018-07-16 20:08:42 --> Security Class Initialized
DEBUG - 2018-07-16 20:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:08:42 --> Input Class Initialized
INFO - 2018-07-16 20:08:42 --> Language Class Initialized
INFO - 2018-07-16 20:08:42 --> Loader Class Initialized
INFO - 2018-07-16 20:08:42 --> Controller Class Initialized
INFO - 2018-07-16 20:08:42 --> Database Driver Class Initialized
INFO - 2018-07-16 20:08:42 --> Model Class Initialized
INFO - 2018-07-16 20:08:42 --> Helper loaded: url_helper
INFO - 2018-07-16 20:08:42 --> Model Class Initialized
INFO - 2018-07-16 20:08:42 --> Final output sent to browser
DEBUG - 2018-07-16 20:08:42 --> Total execution time: 0.0611
ERROR - 2018-07-16 20:16:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:16:17 --> Config Class Initialized
INFO - 2018-07-16 20:16:17 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:16:17 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:16:17 --> Utf8 Class Initialized
INFO - 2018-07-16 20:16:17 --> URI Class Initialized
INFO - 2018-07-16 20:16:17 --> Router Class Initialized
INFO - 2018-07-16 20:16:17 --> Output Class Initialized
INFO - 2018-07-16 20:16:17 --> Security Class Initialized
DEBUG - 2018-07-16 20:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:16:17 --> Input Class Initialized
INFO - 2018-07-16 20:16:17 --> Language Class Initialized
INFO - 2018-07-16 20:16:17 --> Loader Class Initialized
INFO - 2018-07-16 20:16:17 --> Controller Class Initialized
INFO - 2018-07-16 20:16:17 --> Database Driver Class Initialized
INFO - 2018-07-16 20:16:17 --> Model Class Initialized
INFO - 2018-07-16 20:16:17 --> Helper loaded: url_helper
INFO - 2018-07-16 20:16:17 --> Model Class Initialized
INFO - 2018-07-16 20:16:17 --> Final output sent to browser
DEBUG - 2018-07-16 20:16:17 --> Total execution time: 0.0527
ERROR - 2018-07-16 20:16:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:16:19 --> Config Class Initialized
INFO - 2018-07-16 20:16:19 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:16:19 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:16:19 --> Utf8 Class Initialized
INFO - 2018-07-16 20:16:19 --> URI Class Initialized
INFO - 2018-07-16 20:16:19 --> Router Class Initialized
INFO - 2018-07-16 20:16:19 --> Output Class Initialized
INFO - 2018-07-16 20:16:19 --> Security Class Initialized
DEBUG - 2018-07-16 20:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:16:19 --> Input Class Initialized
INFO - 2018-07-16 20:16:19 --> Language Class Initialized
INFO - 2018-07-16 20:16:19 --> Loader Class Initialized
INFO - 2018-07-16 20:16:19 --> Controller Class Initialized
INFO - 2018-07-16 20:16:19 --> Database Driver Class Initialized
INFO - 2018-07-16 20:16:19 --> Model Class Initialized
INFO - 2018-07-16 20:16:19 --> Helper loaded: url_helper
INFO - 2018-07-16 20:16:19 --> Model Class Initialized
INFO - 2018-07-16 20:16:19 --> Final output sent to browser
DEBUG - 2018-07-16 20:16:19 --> Total execution time: 0.0492
ERROR - 2018-07-16 20:16:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:16:19 --> Config Class Initialized
INFO - 2018-07-16 20:16:19 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:16:19 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:16:19 --> Utf8 Class Initialized
INFO - 2018-07-16 20:16:19 --> URI Class Initialized
INFO - 2018-07-16 20:16:19 --> Router Class Initialized
INFO - 2018-07-16 20:16:19 --> Output Class Initialized
INFO - 2018-07-16 20:16:19 --> Security Class Initialized
DEBUG - 2018-07-16 20:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:16:19 --> Input Class Initialized
INFO - 2018-07-16 20:16:19 --> Language Class Initialized
INFO - 2018-07-16 20:16:19 --> Loader Class Initialized
INFO - 2018-07-16 20:16:19 --> Controller Class Initialized
INFO - 2018-07-16 20:16:19 --> Database Driver Class Initialized
INFO - 2018-07-16 20:16:19 --> Model Class Initialized
INFO - 2018-07-16 20:16:19 --> Helper loaded: url_helper
INFO - 2018-07-16 20:16:19 --> Model Class Initialized
INFO - 2018-07-16 20:16:19 --> Final output sent to browser
DEBUG - 2018-07-16 20:16:19 --> Total execution time: 0.0486
ERROR - 2018-07-16 20:17:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:17:51 --> Config Class Initialized
INFO - 2018-07-16 20:17:51 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:17:51 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:17:51 --> Utf8 Class Initialized
INFO - 2018-07-16 20:17:51 --> URI Class Initialized
INFO - 2018-07-16 20:17:51 --> Router Class Initialized
INFO - 2018-07-16 20:17:51 --> Output Class Initialized
INFO - 2018-07-16 20:17:51 --> Security Class Initialized
DEBUG - 2018-07-16 20:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:17:51 --> Input Class Initialized
INFO - 2018-07-16 20:17:51 --> Language Class Initialized
INFO - 2018-07-16 20:17:51 --> Loader Class Initialized
INFO - 2018-07-16 20:17:51 --> Controller Class Initialized
INFO - 2018-07-16 20:17:51 --> Database Driver Class Initialized
INFO - 2018-07-16 20:17:51 --> Model Class Initialized
INFO - 2018-07-16 20:17:51 --> Helper loaded: url_helper
INFO - 2018-07-16 20:17:51 --> Model Class Initialized
INFO - 2018-07-16 20:17:51 --> Final output sent to browser
DEBUG - 2018-07-16 20:17:51 --> Total execution time: 0.0628
ERROR - 2018-07-16 20:17:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:17:52 --> Config Class Initialized
INFO - 2018-07-16 20:17:52 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:17:52 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:17:52 --> Utf8 Class Initialized
INFO - 2018-07-16 20:17:52 --> URI Class Initialized
INFO - 2018-07-16 20:17:52 --> Router Class Initialized
INFO - 2018-07-16 20:17:52 --> Output Class Initialized
INFO - 2018-07-16 20:17:52 --> Security Class Initialized
DEBUG - 2018-07-16 20:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:17:52 --> Input Class Initialized
INFO - 2018-07-16 20:17:52 --> Language Class Initialized
INFO - 2018-07-16 20:17:52 --> Loader Class Initialized
INFO - 2018-07-16 20:17:52 --> Controller Class Initialized
INFO - 2018-07-16 20:17:52 --> Database Driver Class Initialized
INFO - 2018-07-16 20:17:52 --> Model Class Initialized
INFO - 2018-07-16 20:17:52 --> Helper loaded: url_helper
INFO - 2018-07-16 20:17:52 --> Model Class Initialized
INFO - 2018-07-16 20:17:52 --> Final output sent to browser
DEBUG - 2018-07-16 20:17:52 --> Total execution time: 0.0520
ERROR - 2018-07-16 20:17:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:17:52 --> Config Class Initialized
INFO - 2018-07-16 20:17:52 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:17:52 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:17:52 --> Utf8 Class Initialized
INFO - 2018-07-16 20:17:52 --> URI Class Initialized
INFO - 2018-07-16 20:17:52 --> Router Class Initialized
INFO - 2018-07-16 20:17:52 --> Output Class Initialized
INFO - 2018-07-16 20:17:52 --> Security Class Initialized
DEBUG - 2018-07-16 20:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:17:52 --> Input Class Initialized
INFO - 2018-07-16 20:17:52 --> Language Class Initialized
INFO - 2018-07-16 20:17:52 --> Loader Class Initialized
INFO - 2018-07-16 20:17:52 --> Controller Class Initialized
INFO - 2018-07-16 20:17:52 --> Database Driver Class Initialized
INFO - 2018-07-16 20:17:52 --> Model Class Initialized
INFO - 2018-07-16 20:17:52 --> Helper loaded: url_helper
INFO - 2018-07-16 20:17:52 --> Model Class Initialized
INFO - 2018-07-16 20:17:52 --> Final output sent to browser
DEBUG - 2018-07-16 20:17:52 --> Total execution time: 0.0506
ERROR - 2018-07-16 20:19:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:19:17 --> Config Class Initialized
INFO - 2018-07-16 20:19:17 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:19:17 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:19:17 --> Utf8 Class Initialized
INFO - 2018-07-16 20:19:17 --> URI Class Initialized
INFO - 2018-07-16 20:19:17 --> Router Class Initialized
INFO - 2018-07-16 20:19:17 --> Output Class Initialized
INFO - 2018-07-16 20:19:17 --> Security Class Initialized
DEBUG - 2018-07-16 20:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:19:17 --> Input Class Initialized
INFO - 2018-07-16 20:19:17 --> Language Class Initialized
INFO - 2018-07-16 20:19:17 --> Loader Class Initialized
INFO - 2018-07-16 20:19:17 --> Controller Class Initialized
INFO - 2018-07-16 20:19:17 --> Database Driver Class Initialized
INFO - 2018-07-16 20:19:17 --> Model Class Initialized
INFO - 2018-07-16 20:19:17 --> Helper loaded: url_helper
INFO - 2018-07-16 20:19:17 --> Model Class Initialized
INFO - 2018-07-16 20:19:17 --> Final output sent to browser
DEBUG - 2018-07-16 20:19:17 --> Total execution time: 0.0538
ERROR - 2018-07-16 20:19:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:19:19 --> Config Class Initialized
INFO - 2018-07-16 20:19:19 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:19:19 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:19:19 --> Utf8 Class Initialized
INFO - 2018-07-16 20:19:19 --> URI Class Initialized
INFO - 2018-07-16 20:19:19 --> Router Class Initialized
INFO - 2018-07-16 20:19:19 --> Output Class Initialized
INFO - 2018-07-16 20:19:19 --> Security Class Initialized
DEBUG - 2018-07-16 20:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:19:19 --> Input Class Initialized
INFO - 2018-07-16 20:19:19 --> Language Class Initialized
INFO - 2018-07-16 20:19:19 --> Loader Class Initialized
INFO - 2018-07-16 20:19:19 --> Controller Class Initialized
INFO - 2018-07-16 20:19:19 --> Database Driver Class Initialized
INFO - 2018-07-16 20:19:19 --> Model Class Initialized
INFO - 2018-07-16 20:19:19 --> Helper loaded: url_helper
INFO - 2018-07-16 20:19:19 --> Model Class Initialized
INFO - 2018-07-16 20:19:19 --> Final output sent to browser
DEBUG - 2018-07-16 20:19:19 --> Total execution time: 0.0595
ERROR - 2018-07-16 20:19:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:19:19 --> Config Class Initialized
INFO - 2018-07-16 20:19:19 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:19:19 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:19:19 --> Utf8 Class Initialized
INFO - 2018-07-16 20:19:19 --> URI Class Initialized
INFO - 2018-07-16 20:19:19 --> Router Class Initialized
INFO - 2018-07-16 20:19:19 --> Output Class Initialized
INFO - 2018-07-16 20:19:19 --> Security Class Initialized
DEBUG - 2018-07-16 20:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:19:19 --> Input Class Initialized
INFO - 2018-07-16 20:19:19 --> Language Class Initialized
INFO - 2018-07-16 20:19:19 --> Loader Class Initialized
INFO - 2018-07-16 20:19:19 --> Controller Class Initialized
INFO - 2018-07-16 20:19:19 --> Database Driver Class Initialized
INFO - 2018-07-16 20:19:19 --> Model Class Initialized
INFO - 2018-07-16 20:19:19 --> Helper loaded: url_helper
INFO - 2018-07-16 20:19:19 --> Model Class Initialized
INFO - 2018-07-16 20:19:19 --> Final output sent to browser
DEBUG - 2018-07-16 20:19:19 --> Total execution time: 0.0559
ERROR - 2018-07-16 20:40:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:40:26 --> Config Class Initialized
INFO - 2018-07-16 20:40:26 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:40:26 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:40:26 --> Utf8 Class Initialized
INFO - 2018-07-16 20:40:26 --> URI Class Initialized
INFO - 2018-07-16 20:40:26 --> Router Class Initialized
INFO - 2018-07-16 20:40:26 --> Output Class Initialized
INFO - 2018-07-16 20:40:26 --> Security Class Initialized
DEBUG - 2018-07-16 20:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:40:26 --> Input Class Initialized
INFO - 2018-07-16 20:40:26 --> Language Class Initialized
INFO - 2018-07-16 20:40:26 --> Loader Class Initialized
INFO - 2018-07-16 20:40:26 --> Controller Class Initialized
INFO - 2018-07-16 20:40:26 --> Database Driver Class Initialized
INFO - 2018-07-16 20:40:26 --> Model Class Initialized
INFO - 2018-07-16 20:40:26 --> Helper loaded: url_helper
INFO - 2018-07-16 20:40:26 --> Model Class Initialized
INFO - 2018-07-16 20:40:26 --> Final output sent to browser
DEBUG - 2018-07-16 20:40:26 --> Total execution time: 0.0684
ERROR - 2018-07-16 20:40:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:40:28 --> Config Class Initialized
INFO - 2018-07-16 20:40:28 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:40:28 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:40:28 --> Utf8 Class Initialized
INFO - 2018-07-16 20:40:28 --> URI Class Initialized
INFO - 2018-07-16 20:40:28 --> Router Class Initialized
INFO - 2018-07-16 20:40:28 --> Output Class Initialized
INFO - 2018-07-16 20:40:28 --> Security Class Initialized
DEBUG - 2018-07-16 20:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:40:28 --> Input Class Initialized
INFO - 2018-07-16 20:40:28 --> Language Class Initialized
INFO - 2018-07-16 20:40:28 --> Loader Class Initialized
INFO - 2018-07-16 20:40:28 --> Controller Class Initialized
INFO - 2018-07-16 20:40:28 --> Database Driver Class Initialized
INFO - 2018-07-16 20:40:28 --> Model Class Initialized
INFO - 2018-07-16 20:40:28 --> Helper loaded: url_helper
INFO - 2018-07-16 20:40:28 --> Model Class Initialized
INFO - 2018-07-16 20:40:28 --> Final output sent to browser
DEBUG - 2018-07-16 20:40:28 --> Total execution time: 0.0637
ERROR - 2018-07-16 20:40:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:40:28 --> Config Class Initialized
INFO - 2018-07-16 20:40:28 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:40:28 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:40:28 --> Utf8 Class Initialized
INFO - 2018-07-16 20:40:28 --> URI Class Initialized
INFO - 2018-07-16 20:40:28 --> Router Class Initialized
INFO - 2018-07-16 20:40:28 --> Output Class Initialized
INFO - 2018-07-16 20:40:28 --> Security Class Initialized
DEBUG - 2018-07-16 20:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:40:28 --> Input Class Initialized
INFO - 2018-07-16 20:40:28 --> Language Class Initialized
INFO - 2018-07-16 20:40:28 --> Loader Class Initialized
INFO - 2018-07-16 20:40:28 --> Controller Class Initialized
INFO - 2018-07-16 20:40:28 --> Database Driver Class Initialized
INFO - 2018-07-16 20:40:28 --> Model Class Initialized
INFO - 2018-07-16 20:40:28 --> Helper loaded: url_helper
INFO - 2018-07-16 20:40:28 --> Model Class Initialized
INFO - 2018-07-16 20:40:28 --> Final output sent to browser
DEBUG - 2018-07-16 20:40:28 --> Total execution time: 0.0536
ERROR - 2018-07-16 20:42:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:42:48 --> Config Class Initialized
INFO - 2018-07-16 20:42:48 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:42:48 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:42:48 --> Utf8 Class Initialized
INFO - 2018-07-16 20:42:48 --> URI Class Initialized
INFO - 2018-07-16 20:42:48 --> Router Class Initialized
INFO - 2018-07-16 20:42:48 --> Output Class Initialized
INFO - 2018-07-16 20:42:48 --> Security Class Initialized
DEBUG - 2018-07-16 20:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:42:48 --> Input Class Initialized
INFO - 2018-07-16 20:42:48 --> Language Class Initialized
INFO - 2018-07-16 20:42:48 --> Loader Class Initialized
INFO - 2018-07-16 20:42:48 --> Controller Class Initialized
INFO - 2018-07-16 20:42:48 --> Database Driver Class Initialized
INFO - 2018-07-16 20:42:48 --> Model Class Initialized
INFO - 2018-07-16 20:42:48 --> Helper loaded: url_helper
INFO - 2018-07-16 20:42:48 --> Model Class Initialized
INFO - 2018-07-16 20:42:48 --> Final output sent to browser
DEBUG - 2018-07-16 20:42:48 --> Total execution time: 0.0543
ERROR - 2018-07-16 20:42:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:42:54 --> Config Class Initialized
INFO - 2018-07-16 20:42:54 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:42:54 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:42:54 --> Utf8 Class Initialized
INFO - 2018-07-16 20:42:54 --> URI Class Initialized
INFO - 2018-07-16 20:42:54 --> Router Class Initialized
INFO - 2018-07-16 20:42:54 --> Output Class Initialized
INFO - 2018-07-16 20:42:54 --> Security Class Initialized
DEBUG - 2018-07-16 20:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:42:54 --> Input Class Initialized
INFO - 2018-07-16 20:42:54 --> Language Class Initialized
INFO - 2018-07-16 20:42:54 --> Loader Class Initialized
INFO - 2018-07-16 20:42:54 --> Controller Class Initialized
INFO - 2018-07-16 20:42:54 --> Database Driver Class Initialized
INFO - 2018-07-16 20:42:54 --> Model Class Initialized
INFO - 2018-07-16 20:42:54 --> Helper loaded: url_helper
INFO - 2018-07-16 20:42:54 --> Model Class Initialized
INFO - 2018-07-16 20:42:54 --> Final output sent to browser
DEBUG - 2018-07-16 20:42:54 --> Total execution time: 0.0992
ERROR - 2018-07-16 20:43:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:43:39 --> Config Class Initialized
INFO - 2018-07-16 20:43:39 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:43:39 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:43:39 --> Utf8 Class Initialized
INFO - 2018-07-16 20:43:39 --> URI Class Initialized
INFO - 2018-07-16 20:43:39 --> Router Class Initialized
INFO - 2018-07-16 20:43:39 --> Output Class Initialized
INFO - 2018-07-16 20:43:39 --> Security Class Initialized
DEBUG - 2018-07-16 20:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:43:39 --> Input Class Initialized
INFO - 2018-07-16 20:43:39 --> Language Class Initialized
INFO - 2018-07-16 20:43:39 --> Loader Class Initialized
INFO - 2018-07-16 20:43:39 --> Controller Class Initialized
INFO - 2018-07-16 20:43:39 --> Database Driver Class Initialized
INFO - 2018-07-16 20:43:39 --> Model Class Initialized
INFO - 2018-07-16 20:43:39 --> Helper loaded: url_helper
INFO - 2018-07-16 20:43:39 --> Model Class Initialized
INFO - 2018-07-16 20:43:39 --> Final output sent to browser
DEBUG - 2018-07-16 20:43:39 --> Total execution time: 0.1041
ERROR - 2018-07-16 20:43:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:43:46 --> Config Class Initialized
INFO - 2018-07-16 20:43:46 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:43:46 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:43:46 --> Utf8 Class Initialized
INFO - 2018-07-16 20:43:46 --> URI Class Initialized
INFO - 2018-07-16 20:43:46 --> Router Class Initialized
INFO - 2018-07-16 20:43:46 --> Output Class Initialized
INFO - 2018-07-16 20:43:46 --> Security Class Initialized
DEBUG - 2018-07-16 20:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:43:46 --> Input Class Initialized
INFO - 2018-07-16 20:43:46 --> Language Class Initialized
INFO - 2018-07-16 20:43:46 --> Loader Class Initialized
INFO - 2018-07-16 20:43:46 --> Controller Class Initialized
INFO - 2018-07-16 20:43:46 --> Database Driver Class Initialized
INFO - 2018-07-16 20:43:46 --> Model Class Initialized
INFO - 2018-07-16 20:43:46 --> Helper loaded: url_helper
INFO - 2018-07-16 20:43:46 --> Model Class Initialized
INFO - 2018-07-16 20:43:46 --> Final output sent to browser
DEBUG - 2018-07-16 20:43:46 --> Total execution time: 0.1579
ERROR - 2018-07-16 20:44:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:44:28 --> Config Class Initialized
INFO - 2018-07-16 20:44:28 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:44:28 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:44:28 --> Utf8 Class Initialized
INFO - 2018-07-16 20:44:28 --> URI Class Initialized
INFO - 2018-07-16 20:44:28 --> Router Class Initialized
INFO - 2018-07-16 20:44:28 --> Output Class Initialized
INFO - 2018-07-16 20:44:28 --> Security Class Initialized
DEBUG - 2018-07-16 20:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:44:28 --> Input Class Initialized
INFO - 2018-07-16 20:44:28 --> Language Class Initialized
INFO - 2018-07-16 20:44:28 --> Loader Class Initialized
INFO - 2018-07-16 20:44:28 --> Controller Class Initialized
INFO - 2018-07-16 20:44:28 --> Database Driver Class Initialized
INFO - 2018-07-16 20:44:28 --> Model Class Initialized
INFO - 2018-07-16 20:44:28 --> Helper loaded: url_helper
INFO - 2018-07-16 20:44:28 --> Model Class Initialized
INFO - 2018-07-16 20:44:28 --> Final output sent to browser
DEBUG - 2018-07-16 20:44:28 --> Total execution time: 0.1346
ERROR - 2018-07-16 20:45:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 20:45:09 --> Config Class Initialized
INFO - 2018-07-16 20:45:09 --> Hooks Class Initialized
DEBUG - 2018-07-16 20:45:09 --> UTF-8 Support Enabled
INFO - 2018-07-16 20:45:09 --> Utf8 Class Initialized
INFO - 2018-07-16 20:45:09 --> URI Class Initialized
INFO - 2018-07-16 20:45:09 --> Router Class Initialized
INFO - 2018-07-16 20:45:09 --> Output Class Initialized
INFO - 2018-07-16 20:45:09 --> Security Class Initialized
DEBUG - 2018-07-16 20:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 20:45:09 --> Input Class Initialized
INFO - 2018-07-16 20:45:09 --> Language Class Initialized
INFO - 2018-07-16 20:45:09 --> Loader Class Initialized
INFO - 2018-07-16 20:45:09 --> Controller Class Initialized
INFO - 2018-07-16 20:45:09 --> Database Driver Class Initialized
INFO - 2018-07-16 20:45:09 --> Model Class Initialized
INFO - 2018-07-16 20:45:09 --> Helper loaded: url_helper
INFO - 2018-07-16 20:45:09 --> Model Class Initialized
INFO - 2018-07-16 20:45:09 --> Final output sent to browser
DEBUG - 2018-07-16 20:45:09 --> Total execution time: 0.1129
ERROR - 2018-07-16 21:09:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:09:45 --> Config Class Initialized
INFO - 2018-07-16 21:09:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:09:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:09:45 --> Utf8 Class Initialized
INFO - 2018-07-16 21:09:45 --> URI Class Initialized
INFO - 2018-07-16 21:09:45 --> Router Class Initialized
INFO - 2018-07-16 21:09:45 --> Output Class Initialized
INFO - 2018-07-16 21:09:45 --> Security Class Initialized
DEBUG - 2018-07-16 21:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:09:45 --> Input Class Initialized
INFO - 2018-07-16 21:09:45 --> Language Class Initialized
INFO - 2018-07-16 21:09:45 --> Loader Class Initialized
INFO - 2018-07-16 21:09:45 --> Controller Class Initialized
INFO - 2018-07-16 21:09:45 --> Database Driver Class Initialized
INFO - 2018-07-16 21:09:45 --> Model Class Initialized
INFO - 2018-07-16 21:09:45 --> Helper loaded: url_helper
ERROR - 2018-07-16 21:09:45 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 93
ERROR - 2018-07-16 21:10:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:10:08 --> Config Class Initialized
INFO - 2018-07-16 21:10:08 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:10:08 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:10:08 --> Utf8 Class Initialized
INFO - 2018-07-16 21:10:08 --> URI Class Initialized
INFO - 2018-07-16 21:10:08 --> Router Class Initialized
INFO - 2018-07-16 21:10:08 --> Output Class Initialized
INFO - 2018-07-16 21:10:08 --> Security Class Initialized
DEBUG - 2018-07-16 21:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:10:08 --> Input Class Initialized
INFO - 2018-07-16 21:10:08 --> Language Class Initialized
INFO - 2018-07-16 21:10:08 --> Loader Class Initialized
INFO - 2018-07-16 21:10:08 --> Controller Class Initialized
INFO - 2018-07-16 21:10:08 --> Database Driver Class Initialized
INFO - 2018-07-16 21:10:08 --> Model Class Initialized
INFO - 2018-07-16 21:10:08 --> Helper loaded: url_helper
INFO - 2018-07-16 21:10:08 --> Model Class Initialized
INFO - 2018-07-16 21:10:08 --> Final output sent to browser
DEBUG - 2018-07-16 21:10:08 --> Total execution time: 0.1703
ERROR - 2018-07-16 21:10:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:10:25 --> Config Class Initialized
INFO - 2018-07-16 21:10:25 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:10:25 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:10:25 --> Utf8 Class Initialized
INFO - 2018-07-16 21:10:25 --> URI Class Initialized
INFO - 2018-07-16 21:10:25 --> Router Class Initialized
INFO - 2018-07-16 21:10:25 --> Output Class Initialized
INFO - 2018-07-16 21:10:25 --> Security Class Initialized
DEBUG - 2018-07-16 21:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:10:25 --> Input Class Initialized
INFO - 2018-07-16 21:10:25 --> Language Class Initialized
INFO - 2018-07-16 21:10:25 --> Loader Class Initialized
INFO - 2018-07-16 21:10:25 --> Controller Class Initialized
INFO - 2018-07-16 21:10:25 --> Database Driver Class Initialized
INFO - 2018-07-16 21:10:25 --> Model Class Initialized
INFO - 2018-07-16 21:10:25 --> Helper loaded: url_helper
INFO - 2018-07-16 21:10:25 --> Model Class Initialized
INFO - 2018-07-16 21:10:25 --> Final output sent to browser
DEBUG - 2018-07-16 21:10:25 --> Total execution time: 0.0924
ERROR - 2018-07-16 21:10:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:10:57 --> Config Class Initialized
INFO - 2018-07-16 21:10:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:10:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:10:57 --> Utf8 Class Initialized
INFO - 2018-07-16 21:10:57 --> URI Class Initialized
INFO - 2018-07-16 21:10:57 --> Router Class Initialized
INFO - 2018-07-16 21:10:57 --> Output Class Initialized
INFO - 2018-07-16 21:10:57 --> Security Class Initialized
DEBUG - 2018-07-16 21:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:10:57 --> Input Class Initialized
INFO - 2018-07-16 21:10:57 --> Language Class Initialized
INFO - 2018-07-16 21:10:57 --> Loader Class Initialized
INFO - 2018-07-16 21:10:57 --> Controller Class Initialized
INFO - 2018-07-16 21:10:57 --> Database Driver Class Initialized
INFO - 2018-07-16 21:10:57 --> Model Class Initialized
INFO - 2018-07-16 21:10:57 --> Helper loaded: url_helper
INFO - 2018-07-16 21:10:57 --> Model Class Initialized
INFO - 2018-07-16 21:10:57 --> Final output sent to browser
DEBUG - 2018-07-16 21:10:57 --> Total execution time: 0.0780
ERROR - 2018-07-16 21:13:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:13:01 --> Config Class Initialized
INFO - 2018-07-16 21:13:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:13:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:13:01 --> Utf8 Class Initialized
INFO - 2018-07-16 21:13:01 --> URI Class Initialized
INFO - 2018-07-16 21:13:01 --> Router Class Initialized
INFO - 2018-07-16 21:13:01 --> Output Class Initialized
INFO - 2018-07-16 21:13:01 --> Security Class Initialized
DEBUG - 2018-07-16 21:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:13:01 --> Input Class Initialized
INFO - 2018-07-16 21:13:01 --> Language Class Initialized
INFO - 2018-07-16 21:13:01 --> Loader Class Initialized
INFO - 2018-07-16 21:13:01 --> Controller Class Initialized
INFO - 2018-07-16 21:13:01 --> Database Driver Class Initialized
INFO - 2018-07-16 21:13:01 --> Model Class Initialized
INFO - 2018-07-16 21:13:01 --> Helper loaded: url_helper
INFO - 2018-07-16 21:13:01 --> Model Class Initialized
INFO - 2018-07-16 21:13:01 --> Final output sent to browser
DEBUG - 2018-07-16 21:13:01 --> Total execution time: 0.0669
ERROR - 2018-07-16 21:13:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:13:10 --> Config Class Initialized
INFO - 2018-07-16 21:13:10 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:13:10 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:13:10 --> Utf8 Class Initialized
INFO - 2018-07-16 21:13:10 --> URI Class Initialized
INFO - 2018-07-16 21:13:10 --> Router Class Initialized
INFO - 2018-07-16 21:13:10 --> Output Class Initialized
INFO - 2018-07-16 21:13:10 --> Security Class Initialized
DEBUG - 2018-07-16 21:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:13:10 --> Input Class Initialized
INFO - 2018-07-16 21:13:10 --> Language Class Initialized
INFO - 2018-07-16 21:13:10 --> Loader Class Initialized
INFO - 2018-07-16 21:13:10 --> Controller Class Initialized
INFO - 2018-07-16 21:13:10 --> Database Driver Class Initialized
INFO - 2018-07-16 21:13:10 --> Model Class Initialized
INFO - 2018-07-16 21:13:10 --> Helper loaded: url_helper
INFO - 2018-07-16 21:13:10 --> Model Class Initialized
INFO - 2018-07-16 21:13:10 --> Final output sent to browser
DEBUG - 2018-07-16 21:13:10 --> Total execution time: 0.0575
ERROR - 2018-07-16 21:13:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:13:14 --> Config Class Initialized
INFO - 2018-07-16 21:13:14 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:13:14 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:13:14 --> Utf8 Class Initialized
INFO - 2018-07-16 21:13:14 --> URI Class Initialized
INFO - 2018-07-16 21:13:14 --> Router Class Initialized
INFO - 2018-07-16 21:13:14 --> Output Class Initialized
INFO - 2018-07-16 21:13:14 --> Security Class Initialized
DEBUG - 2018-07-16 21:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:13:14 --> Input Class Initialized
INFO - 2018-07-16 21:13:14 --> Language Class Initialized
INFO - 2018-07-16 21:13:14 --> Loader Class Initialized
INFO - 2018-07-16 21:13:14 --> Controller Class Initialized
INFO - 2018-07-16 21:13:14 --> Database Driver Class Initialized
INFO - 2018-07-16 21:13:14 --> Model Class Initialized
INFO - 2018-07-16 21:13:14 --> Helper loaded: url_helper
INFO - 2018-07-16 21:13:14 --> Model Class Initialized
INFO - 2018-07-16 21:13:14 --> Final output sent to browser
DEBUG - 2018-07-16 21:13:14 --> Total execution time: 0.0518
ERROR - 2018-07-16 21:13:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:13:50 --> Config Class Initialized
INFO - 2018-07-16 21:13:50 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:13:50 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:13:50 --> Utf8 Class Initialized
INFO - 2018-07-16 21:13:50 --> URI Class Initialized
INFO - 2018-07-16 21:13:50 --> Router Class Initialized
INFO - 2018-07-16 21:13:50 --> Output Class Initialized
INFO - 2018-07-16 21:13:50 --> Security Class Initialized
DEBUG - 2018-07-16 21:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:13:50 --> Input Class Initialized
INFO - 2018-07-16 21:13:50 --> Language Class Initialized
INFO - 2018-07-16 21:13:50 --> Loader Class Initialized
INFO - 2018-07-16 21:13:50 --> Controller Class Initialized
INFO - 2018-07-16 21:13:50 --> Database Driver Class Initialized
INFO - 2018-07-16 21:13:50 --> Model Class Initialized
INFO - 2018-07-16 21:13:50 --> Helper loaded: url_helper
INFO - 2018-07-16 21:13:50 --> Model Class Initialized
INFO - 2018-07-16 21:13:50 --> Final output sent to browser
DEBUG - 2018-07-16 21:13:50 --> Total execution time: 0.0584
ERROR - 2018-07-16 21:13:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:13:52 --> Config Class Initialized
INFO - 2018-07-16 21:13:52 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:13:52 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:13:52 --> Utf8 Class Initialized
INFO - 2018-07-16 21:13:52 --> URI Class Initialized
INFO - 2018-07-16 21:13:52 --> Router Class Initialized
INFO - 2018-07-16 21:13:52 --> Output Class Initialized
INFO - 2018-07-16 21:13:52 --> Security Class Initialized
DEBUG - 2018-07-16 21:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:13:52 --> Input Class Initialized
INFO - 2018-07-16 21:13:52 --> Language Class Initialized
INFO - 2018-07-16 21:13:52 --> Loader Class Initialized
INFO - 2018-07-16 21:13:52 --> Controller Class Initialized
INFO - 2018-07-16 21:13:52 --> Database Driver Class Initialized
INFO - 2018-07-16 21:13:52 --> Model Class Initialized
INFO - 2018-07-16 21:13:52 --> Helper loaded: url_helper
INFO - 2018-07-16 21:13:52 --> Model Class Initialized
INFO - 2018-07-16 21:13:52 --> Final output sent to browser
DEBUG - 2018-07-16 21:13:52 --> Total execution time: 0.0627
ERROR - 2018-07-16 21:14:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:14:10 --> Config Class Initialized
INFO - 2018-07-16 21:14:10 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:14:10 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:14:10 --> Utf8 Class Initialized
INFO - 2018-07-16 21:14:10 --> URI Class Initialized
INFO - 2018-07-16 21:14:10 --> Router Class Initialized
INFO - 2018-07-16 21:14:10 --> Output Class Initialized
INFO - 2018-07-16 21:14:10 --> Security Class Initialized
DEBUG - 2018-07-16 21:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:14:10 --> Input Class Initialized
INFO - 2018-07-16 21:14:10 --> Language Class Initialized
INFO - 2018-07-16 21:14:10 --> Loader Class Initialized
INFO - 2018-07-16 21:14:10 --> Controller Class Initialized
INFO - 2018-07-16 21:14:10 --> Database Driver Class Initialized
INFO - 2018-07-16 21:14:10 --> Model Class Initialized
INFO - 2018-07-16 21:14:10 --> Helper loaded: url_helper
INFO - 2018-07-16 21:14:10 --> Model Class Initialized
INFO - 2018-07-16 21:14:10 --> Final output sent to browser
DEBUG - 2018-07-16 21:14:10 --> Total execution time: 0.0809
ERROR - 2018-07-16 21:14:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:14:33 --> Config Class Initialized
INFO - 2018-07-16 21:14:33 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:14:33 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:14:33 --> Utf8 Class Initialized
INFO - 2018-07-16 21:14:33 --> URI Class Initialized
INFO - 2018-07-16 21:14:33 --> Router Class Initialized
INFO - 2018-07-16 21:14:33 --> Output Class Initialized
INFO - 2018-07-16 21:14:33 --> Security Class Initialized
DEBUG - 2018-07-16 21:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:14:33 --> Input Class Initialized
INFO - 2018-07-16 21:14:33 --> Language Class Initialized
INFO - 2018-07-16 21:14:33 --> Loader Class Initialized
INFO - 2018-07-16 21:14:33 --> Controller Class Initialized
INFO - 2018-07-16 21:14:33 --> Database Driver Class Initialized
INFO - 2018-07-16 21:14:33 --> Model Class Initialized
INFO - 2018-07-16 21:14:33 --> Helper loaded: url_helper
INFO - 2018-07-16 21:14:33 --> Model Class Initialized
INFO - 2018-07-16 21:14:33 --> Final output sent to browser
DEBUG - 2018-07-16 21:14:33 --> Total execution time: 0.0502
ERROR - 2018-07-16 21:14:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:14:46 --> Config Class Initialized
INFO - 2018-07-16 21:14:46 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:14:46 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:14:46 --> Utf8 Class Initialized
INFO - 2018-07-16 21:14:46 --> URI Class Initialized
INFO - 2018-07-16 21:14:46 --> Router Class Initialized
INFO - 2018-07-16 21:14:46 --> Output Class Initialized
INFO - 2018-07-16 21:14:46 --> Security Class Initialized
DEBUG - 2018-07-16 21:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:14:46 --> Input Class Initialized
INFO - 2018-07-16 21:14:46 --> Language Class Initialized
INFO - 2018-07-16 21:14:46 --> Loader Class Initialized
INFO - 2018-07-16 21:14:46 --> Controller Class Initialized
INFO - 2018-07-16 21:14:46 --> Database Driver Class Initialized
INFO - 2018-07-16 21:14:46 --> Model Class Initialized
INFO - 2018-07-16 21:14:46 --> Helper loaded: url_helper
INFO - 2018-07-16 21:14:46 --> Model Class Initialized
INFO - 2018-07-16 21:14:46 --> Final output sent to browser
DEBUG - 2018-07-16 21:14:46 --> Total execution time: 0.0692
ERROR - 2018-07-16 21:15:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:15:44 --> Config Class Initialized
INFO - 2018-07-16 21:15:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:15:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:15:44 --> Utf8 Class Initialized
INFO - 2018-07-16 21:15:44 --> URI Class Initialized
INFO - 2018-07-16 21:15:44 --> Router Class Initialized
INFO - 2018-07-16 21:15:44 --> Output Class Initialized
INFO - 2018-07-16 21:15:44 --> Security Class Initialized
DEBUG - 2018-07-16 21:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:15:44 --> Input Class Initialized
INFO - 2018-07-16 21:15:44 --> Language Class Initialized
INFO - 2018-07-16 21:15:44 --> Loader Class Initialized
INFO - 2018-07-16 21:15:44 --> Controller Class Initialized
INFO - 2018-07-16 21:15:44 --> Database Driver Class Initialized
INFO - 2018-07-16 21:15:44 --> Model Class Initialized
INFO - 2018-07-16 21:15:44 --> Helper loaded: url_helper
INFO - 2018-07-16 21:15:44 --> Model Class Initialized
INFO - 2018-07-16 21:15:44 --> Final output sent to browser
DEBUG - 2018-07-16 21:15:44 --> Total execution time: 0.0669
ERROR - 2018-07-16 21:15:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:15:53 --> Config Class Initialized
INFO - 2018-07-16 21:15:53 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:15:53 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:15:53 --> Utf8 Class Initialized
INFO - 2018-07-16 21:15:53 --> URI Class Initialized
INFO - 2018-07-16 21:15:53 --> Router Class Initialized
INFO - 2018-07-16 21:15:53 --> Output Class Initialized
INFO - 2018-07-16 21:15:53 --> Security Class Initialized
DEBUG - 2018-07-16 21:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:15:53 --> Input Class Initialized
INFO - 2018-07-16 21:15:53 --> Language Class Initialized
INFO - 2018-07-16 21:15:53 --> Loader Class Initialized
INFO - 2018-07-16 21:15:53 --> Controller Class Initialized
INFO - 2018-07-16 21:15:53 --> Database Driver Class Initialized
INFO - 2018-07-16 21:15:53 --> Model Class Initialized
INFO - 2018-07-16 21:15:53 --> Helper loaded: url_helper
INFO - 2018-07-16 21:15:53 --> Model Class Initialized
INFO - 2018-07-16 21:15:53 --> Final output sent to browser
DEBUG - 2018-07-16 21:15:53 --> Total execution time: 0.0567
ERROR - 2018-07-16 21:16:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:16:20 --> Config Class Initialized
INFO - 2018-07-16 21:16:20 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:16:20 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:16:20 --> Utf8 Class Initialized
INFO - 2018-07-16 21:16:20 --> URI Class Initialized
INFO - 2018-07-16 21:16:20 --> Router Class Initialized
INFO - 2018-07-16 21:16:20 --> Output Class Initialized
INFO - 2018-07-16 21:16:20 --> Security Class Initialized
DEBUG - 2018-07-16 21:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:16:20 --> Input Class Initialized
INFO - 2018-07-16 21:16:20 --> Language Class Initialized
INFO - 2018-07-16 21:16:20 --> Loader Class Initialized
INFO - 2018-07-16 21:16:20 --> Controller Class Initialized
INFO - 2018-07-16 21:16:20 --> Database Driver Class Initialized
INFO - 2018-07-16 21:16:20 --> Model Class Initialized
INFO - 2018-07-16 21:16:20 --> Helper loaded: url_helper
INFO - 2018-07-16 21:16:20 --> Model Class Initialized
INFO - 2018-07-16 21:16:20 --> Final output sent to browser
DEBUG - 2018-07-16 21:16:20 --> Total execution time: 0.0647
ERROR - 2018-07-16 21:16:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:16:22 --> Config Class Initialized
INFO - 2018-07-16 21:16:22 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:16:22 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:16:22 --> Utf8 Class Initialized
INFO - 2018-07-16 21:16:22 --> URI Class Initialized
INFO - 2018-07-16 21:16:22 --> Router Class Initialized
INFO - 2018-07-16 21:16:22 --> Output Class Initialized
INFO - 2018-07-16 21:16:22 --> Security Class Initialized
DEBUG - 2018-07-16 21:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:16:22 --> Input Class Initialized
INFO - 2018-07-16 21:16:22 --> Language Class Initialized
INFO - 2018-07-16 21:16:22 --> Loader Class Initialized
INFO - 2018-07-16 21:16:22 --> Controller Class Initialized
INFO - 2018-07-16 21:16:22 --> Database Driver Class Initialized
INFO - 2018-07-16 21:16:22 --> Model Class Initialized
INFO - 2018-07-16 21:16:22 --> Helper loaded: url_helper
INFO - 2018-07-16 21:16:22 --> Model Class Initialized
INFO - 2018-07-16 21:16:22 --> Final output sent to browser
DEBUG - 2018-07-16 21:16:22 --> Total execution time: 0.0501
ERROR - 2018-07-16 21:16:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:16:48 --> Config Class Initialized
INFO - 2018-07-16 21:16:48 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:16:48 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:16:48 --> Utf8 Class Initialized
INFO - 2018-07-16 21:16:48 --> URI Class Initialized
INFO - 2018-07-16 21:16:48 --> Router Class Initialized
INFO - 2018-07-16 21:16:48 --> Output Class Initialized
INFO - 2018-07-16 21:16:48 --> Security Class Initialized
DEBUG - 2018-07-16 21:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:16:48 --> Input Class Initialized
INFO - 2018-07-16 21:16:48 --> Language Class Initialized
INFO - 2018-07-16 21:16:48 --> Loader Class Initialized
INFO - 2018-07-16 21:16:48 --> Controller Class Initialized
INFO - 2018-07-16 21:16:48 --> Database Driver Class Initialized
INFO - 2018-07-16 21:16:48 --> Model Class Initialized
INFO - 2018-07-16 21:16:48 --> Helper loaded: url_helper
INFO - 2018-07-16 21:16:48 --> Model Class Initialized
INFO - 2018-07-16 21:16:48 --> Final output sent to browser
DEBUG - 2018-07-16 21:16:48 --> Total execution time: 0.0437
ERROR - 2018-07-16 21:17:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:17:52 --> Config Class Initialized
INFO - 2018-07-16 21:17:52 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:17:52 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:17:52 --> Utf8 Class Initialized
INFO - 2018-07-16 21:17:52 --> URI Class Initialized
INFO - 2018-07-16 21:17:52 --> Router Class Initialized
INFO - 2018-07-16 21:17:52 --> Output Class Initialized
INFO - 2018-07-16 21:17:52 --> Security Class Initialized
DEBUG - 2018-07-16 21:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:17:52 --> Input Class Initialized
INFO - 2018-07-16 21:17:52 --> Language Class Initialized
INFO - 2018-07-16 21:17:52 --> Loader Class Initialized
INFO - 2018-07-16 21:17:52 --> Controller Class Initialized
INFO - 2018-07-16 21:17:52 --> Database Driver Class Initialized
INFO - 2018-07-16 21:17:52 --> Model Class Initialized
INFO - 2018-07-16 21:17:52 --> Helper loaded: url_helper
INFO - 2018-07-16 21:17:52 --> Model Class Initialized
INFO - 2018-07-16 21:17:52 --> Final output sent to browser
DEBUG - 2018-07-16 21:17:52 --> Total execution time: 0.0508
ERROR - 2018-07-16 21:18:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:18:15 --> Config Class Initialized
INFO - 2018-07-16 21:18:15 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:18:15 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:18:15 --> Utf8 Class Initialized
INFO - 2018-07-16 21:18:15 --> URI Class Initialized
INFO - 2018-07-16 21:18:15 --> Router Class Initialized
INFO - 2018-07-16 21:18:15 --> Output Class Initialized
INFO - 2018-07-16 21:18:15 --> Security Class Initialized
DEBUG - 2018-07-16 21:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:18:15 --> Input Class Initialized
INFO - 2018-07-16 21:18:15 --> Language Class Initialized
INFO - 2018-07-16 21:18:15 --> Loader Class Initialized
INFO - 2018-07-16 21:18:15 --> Controller Class Initialized
INFO - 2018-07-16 21:18:15 --> Database Driver Class Initialized
INFO - 2018-07-16 21:18:15 --> Model Class Initialized
INFO - 2018-07-16 21:18:15 --> Helper loaded: url_helper
INFO - 2018-07-16 21:18:15 --> Model Class Initialized
INFO - 2018-07-16 21:18:15 --> Final output sent to browser
DEBUG - 2018-07-16 21:18:15 --> Total execution time: 0.0504
ERROR - 2018-07-16 21:18:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:18:28 --> Config Class Initialized
INFO - 2018-07-16 21:18:28 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:18:28 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:18:28 --> Utf8 Class Initialized
INFO - 2018-07-16 21:18:28 --> URI Class Initialized
INFO - 2018-07-16 21:18:28 --> Router Class Initialized
INFO - 2018-07-16 21:18:28 --> Output Class Initialized
INFO - 2018-07-16 21:18:28 --> Security Class Initialized
DEBUG - 2018-07-16 21:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:18:28 --> Input Class Initialized
INFO - 2018-07-16 21:18:28 --> Language Class Initialized
INFO - 2018-07-16 21:18:28 --> Loader Class Initialized
INFO - 2018-07-16 21:18:28 --> Controller Class Initialized
INFO - 2018-07-16 21:18:28 --> Database Driver Class Initialized
INFO - 2018-07-16 21:18:28 --> Model Class Initialized
INFO - 2018-07-16 21:18:28 --> Helper loaded: url_helper
INFO - 2018-07-16 21:18:28 --> Model Class Initialized
INFO - 2018-07-16 21:18:28 --> Final output sent to browser
DEBUG - 2018-07-16 21:18:28 --> Total execution time: 0.0471
ERROR - 2018-07-16 21:22:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:22:03 --> Config Class Initialized
INFO - 2018-07-16 21:22:03 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:22:03 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:22:03 --> Utf8 Class Initialized
INFO - 2018-07-16 21:22:03 --> URI Class Initialized
INFO - 2018-07-16 21:22:03 --> Router Class Initialized
INFO - 2018-07-16 21:22:03 --> Output Class Initialized
INFO - 2018-07-16 21:22:03 --> Security Class Initialized
DEBUG - 2018-07-16 21:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:22:03 --> Input Class Initialized
INFO - 2018-07-16 21:22:03 --> Language Class Initialized
INFO - 2018-07-16 21:22:03 --> Loader Class Initialized
INFO - 2018-07-16 21:22:03 --> Controller Class Initialized
INFO - 2018-07-16 21:22:03 --> Database Driver Class Initialized
INFO - 2018-07-16 21:22:03 --> Model Class Initialized
INFO - 2018-07-16 21:22:03 --> Helper loaded: url_helper
ERROR - 2018-07-16 21:22:03 --> Severity: error --> Exception: syntax error, unexpected '1' (T_LNUMBER), expecting variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 42
ERROR - 2018-07-16 21:22:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:22:18 --> Config Class Initialized
INFO - 2018-07-16 21:22:18 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:22:18 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:22:18 --> Utf8 Class Initialized
INFO - 2018-07-16 21:22:18 --> URI Class Initialized
INFO - 2018-07-16 21:22:18 --> Router Class Initialized
INFO - 2018-07-16 21:22:18 --> Output Class Initialized
INFO - 2018-07-16 21:22:18 --> Security Class Initialized
DEBUG - 2018-07-16 21:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:22:18 --> Input Class Initialized
INFO - 2018-07-16 21:22:18 --> Language Class Initialized
INFO - 2018-07-16 21:22:18 --> Loader Class Initialized
INFO - 2018-07-16 21:22:18 --> Controller Class Initialized
INFO - 2018-07-16 21:22:18 --> Database Driver Class Initialized
INFO - 2018-07-16 21:22:18 --> Model Class Initialized
INFO - 2018-07-16 21:22:18 --> Helper loaded: url_helper
INFO - 2018-07-16 21:22:18 --> Model Class Initialized
INFO - 2018-07-16 21:22:18 --> Final output sent to browser
DEBUG - 2018-07-16 21:22:18 --> Total execution time: 0.0476
ERROR - 2018-07-16 21:22:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:22:26 --> Config Class Initialized
INFO - 2018-07-16 21:22:26 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:22:26 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:22:26 --> Utf8 Class Initialized
INFO - 2018-07-16 21:22:26 --> URI Class Initialized
INFO - 2018-07-16 21:22:26 --> Router Class Initialized
INFO - 2018-07-16 21:22:26 --> Output Class Initialized
INFO - 2018-07-16 21:22:26 --> Security Class Initialized
DEBUG - 2018-07-16 21:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:22:26 --> Input Class Initialized
INFO - 2018-07-16 21:22:26 --> Language Class Initialized
INFO - 2018-07-16 21:22:26 --> Loader Class Initialized
INFO - 2018-07-16 21:22:26 --> Controller Class Initialized
INFO - 2018-07-16 21:22:26 --> Database Driver Class Initialized
INFO - 2018-07-16 21:22:26 --> Model Class Initialized
INFO - 2018-07-16 21:22:26 --> Helper loaded: url_helper
INFO - 2018-07-16 21:22:26 --> Model Class Initialized
INFO - 2018-07-16 21:22:26 --> Final output sent to browser
DEBUG - 2018-07-16 21:22:26 --> Total execution time: 0.0458
ERROR - 2018-07-16 21:22:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:22:50 --> Config Class Initialized
INFO - 2018-07-16 21:22:51 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:22:51 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:22:51 --> Utf8 Class Initialized
INFO - 2018-07-16 21:22:51 --> URI Class Initialized
INFO - 2018-07-16 21:22:51 --> Router Class Initialized
INFO - 2018-07-16 21:22:51 --> Output Class Initialized
INFO - 2018-07-16 21:22:51 --> Security Class Initialized
DEBUG - 2018-07-16 21:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:22:51 --> Input Class Initialized
INFO - 2018-07-16 21:22:51 --> Language Class Initialized
INFO - 2018-07-16 21:22:51 --> Loader Class Initialized
INFO - 2018-07-16 21:22:51 --> Controller Class Initialized
INFO - 2018-07-16 21:22:51 --> Database Driver Class Initialized
INFO - 2018-07-16 21:22:51 --> Model Class Initialized
INFO - 2018-07-16 21:22:51 --> Helper loaded: url_helper
INFO - 2018-07-16 21:22:51 --> Model Class Initialized
INFO - 2018-07-16 21:22:51 --> Final output sent to browser
DEBUG - 2018-07-16 21:22:51 --> Total execution time: 0.0951
ERROR - 2018-07-16 21:22:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:22:54 --> Config Class Initialized
INFO - 2018-07-16 21:22:54 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:22:54 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:22:54 --> Utf8 Class Initialized
INFO - 2018-07-16 21:22:54 --> URI Class Initialized
INFO - 2018-07-16 21:22:54 --> Router Class Initialized
INFO - 2018-07-16 21:22:54 --> Output Class Initialized
INFO - 2018-07-16 21:22:54 --> Security Class Initialized
DEBUG - 2018-07-16 21:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:22:54 --> Input Class Initialized
INFO - 2018-07-16 21:22:54 --> Language Class Initialized
INFO - 2018-07-16 21:22:54 --> Loader Class Initialized
INFO - 2018-07-16 21:22:54 --> Controller Class Initialized
INFO - 2018-07-16 21:22:54 --> Database Driver Class Initialized
INFO - 2018-07-16 21:22:54 --> Model Class Initialized
INFO - 2018-07-16 21:22:54 --> Helper loaded: url_helper
INFO - 2018-07-16 21:22:54 --> Model Class Initialized
INFO - 2018-07-16 21:22:54 --> Final output sent to browser
DEBUG - 2018-07-16 21:22:54 --> Total execution time: 0.1273
ERROR - 2018-07-16 21:22:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:22:57 --> Config Class Initialized
INFO - 2018-07-16 21:22:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:22:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:22:57 --> Utf8 Class Initialized
INFO - 2018-07-16 21:22:57 --> URI Class Initialized
INFO - 2018-07-16 21:22:57 --> Router Class Initialized
INFO - 2018-07-16 21:22:57 --> Output Class Initialized
INFO - 2018-07-16 21:22:57 --> Security Class Initialized
DEBUG - 2018-07-16 21:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:22:57 --> Input Class Initialized
INFO - 2018-07-16 21:22:57 --> Language Class Initialized
INFO - 2018-07-16 21:22:57 --> Loader Class Initialized
INFO - 2018-07-16 21:22:57 --> Controller Class Initialized
INFO - 2018-07-16 21:22:58 --> Database Driver Class Initialized
INFO - 2018-07-16 21:22:58 --> Model Class Initialized
INFO - 2018-07-16 21:22:58 --> Helper loaded: url_helper
INFO - 2018-07-16 21:22:58 --> Model Class Initialized
INFO - 2018-07-16 21:22:58 --> Final output sent to browser
DEBUG - 2018-07-16 21:22:58 --> Total execution time: 0.2758
ERROR - 2018-07-16 21:23:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:23:31 --> Config Class Initialized
INFO - 2018-07-16 21:23:31 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:23:31 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:23:31 --> Utf8 Class Initialized
INFO - 2018-07-16 21:23:31 --> URI Class Initialized
INFO - 2018-07-16 21:23:31 --> Router Class Initialized
INFO - 2018-07-16 21:23:31 --> Output Class Initialized
INFO - 2018-07-16 21:23:31 --> Security Class Initialized
DEBUG - 2018-07-16 21:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:23:31 --> Input Class Initialized
INFO - 2018-07-16 21:23:31 --> Language Class Initialized
INFO - 2018-07-16 21:23:31 --> Loader Class Initialized
INFO - 2018-07-16 21:23:31 --> Controller Class Initialized
INFO - 2018-07-16 21:23:31 --> Database Driver Class Initialized
INFO - 2018-07-16 21:23:31 --> Model Class Initialized
INFO - 2018-07-16 21:23:31 --> Helper loaded: url_helper
INFO - 2018-07-16 21:23:31 --> Model Class Initialized
INFO - 2018-07-16 21:23:31 --> Final output sent to browser
DEBUG - 2018-07-16 21:23:31 --> Total execution time: 0.0803
ERROR - 2018-07-16 21:30:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:30:11 --> Config Class Initialized
INFO - 2018-07-16 21:30:11 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:30:11 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:30:11 --> Utf8 Class Initialized
INFO - 2018-07-16 21:30:11 --> URI Class Initialized
INFO - 2018-07-16 21:30:11 --> Router Class Initialized
INFO - 2018-07-16 21:30:11 --> Output Class Initialized
INFO - 2018-07-16 21:30:11 --> Security Class Initialized
DEBUG - 2018-07-16 21:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:30:11 --> Input Class Initialized
INFO - 2018-07-16 21:30:11 --> Language Class Initialized
INFO - 2018-07-16 21:30:11 --> Loader Class Initialized
INFO - 2018-07-16 21:30:11 --> Controller Class Initialized
INFO - 2018-07-16 21:30:11 --> Database Driver Class Initialized
INFO - 2018-07-16 21:30:11 --> Model Class Initialized
INFO - 2018-07-16 21:30:11 --> Helper loaded: url_helper
INFO - 2018-07-16 21:30:11 --> Model Class Initialized
INFO - 2018-07-16 21:30:11 --> Final output sent to browser
DEBUG - 2018-07-16 21:30:11 --> Total execution time: 0.0399
ERROR - 2018-07-16 21:30:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:30:14 --> Config Class Initialized
INFO - 2018-07-16 21:30:14 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:30:14 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:30:14 --> Utf8 Class Initialized
INFO - 2018-07-16 21:30:14 --> URI Class Initialized
INFO - 2018-07-16 21:30:14 --> Router Class Initialized
INFO - 2018-07-16 21:30:14 --> Output Class Initialized
INFO - 2018-07-16 21:30:14 --> Security Class Initialized
DEBUG - 2018-07-16 21:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:30:14 --> Input Class Initialized
INFO - 2018-07-16 21:30:14 --> Language Class Initialized
INFO - 2018-07-16 21:30:14 --> Loader Class Initialized
INFO - 2018-07-16 21:30:14 --> Controller Class Initialized
INFO - 2018-07-16 21:30:14 --> Database Driver Class Initialized
INFO - 2018-07-16 21:30:14 --> Model Class Initialized
INFO - 2018-07-16 21:30:14 --> Helper loaded: url_helper
INFO - 2018-07-16 21:30:14 --> Model Class Initialized
INFO - 2018-07-16 21:30:14 --> Final output sent to browser
DEBUG - 2018-07-16 21:30:14 --> Total execution time: 0.0469
ERROR - 2018-07-16 21:30:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:30:14 --> Config Class Initialized
INFO - 2018-07-16 21:30:14 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:30:14 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:30:14 --> Utf8 Class Initialized
INFO - 2018-07-16 21:30:14 --> URI Class Initialized
INFO - 2018-07-16 21:30:14 --> Router Class Initialized
INFO - 2018-07-16 21:30:14 --> Output Class Initialized
INFO - 2018-07-16 21:30:14 --> Security Class Initialized
DEBUG - 2018-07-16 21:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:30:14 --> Input Class Initialized
INFO - 2018-07-16 21:30:14 --> Language Class Initialized
INFO - 2018-07-16 21:30:14 --> Loader Class Initialized
INFO - 2018-07-16 21:30:14 --> Controller Class Initialized
INFO - 2018-07-16 21:30:14 --> Database Driver Class Initialized
INFO - 2018-07-16 21:30:14 --> Model Class Initialized
INFO - 2018-07-16 21:30:14 --> Helper loaded: url_helper
INFO - 2018-07-16 21:30:14 --> Model Class Initialized
INFO - 2018-07-16 21:30:14 --> Final output sent to browser
DEBUG - 2018-07-16 21:30:14 --> Total execution time: 0.0461
ERROR - 2018-07-16 21:30:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:30:58 --> Config Class Initialized
INFO - 2018-07-16 21:30:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:30:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:30:58 --> Utf8 Class Initialized
INFO - 2018-07-16 21:30:58 --> URI Class Initialized
INFO - 2018-07-16 21:30:58 --> Router Class Initialized
INFO - 2018-07-16 21:30:58 --> Output Class Initialized
INFO - 2018-07-16 21:30:58 --> Security Class Initialized
DEBUG - 2018-07-16 21:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:30:58 --> Input Class Initialized
INFO - 2018-07-16 21:30:58 --> Language Class Initialized
INFO - 2018-07-16 21:30:58 --> Loader Class Initialized
INFO - 2018-07-16 21:30:58 --> Controller Class Initialized
INFO - 2018-07-16 21:30:58 --> Database Driver Class Initialized
INFO - 2018-07-16 21:30:59 --> Model Class Initialized
INFO - 2018-07-16 21:30:59 --> Helper loaded: url_helper
INFO - 2018-07-16 21:30:59 --> Model Class Initialized
INFO - 2018-07-16 21:30:59 --> Final output sent to browser
DEBUG - 2018-07-16 21:30:59 --> Total execution time: 0.0433
ERROR - 2018-07-16 21:31:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:31:00 --> Config Class Initialized
INFO - 2018-07-16 21:31:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:31:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:31:00 --> Utf8 Class Initialized
INFO - 2018-07-16 21:31:00 --> URI Class Initialized
INFO - 2018-07-16 21:31:00 --> Router Class Initialized
INFO - 2018-07-16 21:31:00 --> Output Class Initialized
INFO - 2018-07-16 21:31:00 --> Security Class Initialized
DEBUG - 2018-07-16 21:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:31:00 --> Input Class Initialized
INFO - 2018-07-16 21:31:00 --> Language Class Initialized
INFO - 2018-07-16 21:31:00 --> Loader Class Initialized
INFO - 2018-07-16 21:31:00 --> Controller Class Initialized
INFO - 2018-07-16 21:31:00 --> Database Driver Class Initialized
INFO - 2018-07-16 21:31:00 --> Model Class Initialized
INFO - 2018-07-16 21:31:00 --> Helper loaded: url_helper
INFO - 2018-07-16 21:31:00 --> Model Class Initialized
INFO - 2018-07-16 21:31:00 --> Final output sent to browser
DEBUG - 2018-07-16 21:31:00 --> Total execution time: 0.0522
ERROR - 2018-07-16 21:31:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:31:00 --> Config Class Initialized
INFO - 2018-07-16 21:31:00 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:31:00 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:31:00 --> Utf8 Class Initialized
INFO - 2018-07-16 21:31:00 --> URI Class Initialized
INFO - 2018-07-16 21:31:00 --> Router Class Initialized
INFO - 2018-07-16 21:31:00 --> Output Class Initialized
INFO - 2018-07-16 21:31:00 --> Security Class Initialized
DEBUG - 2018-07-16 21:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:31:00 --> Input Class Initialized
INFO - 2018-07-16 21:31:00 --> Language Class Initialized
INFO - 2018-07-16 21:31:00 --> Loader Class Initialized
INFO - 2018-07-16 21:31:00 --> Controller Class Initialized
INFO - 2018-07-16 21:31:01 --> Database Driver Class Initialized
INFO - 2018-07-16 21:31:01 --> Model Class Initialized
INFO - 2018-07-16 21:31:01 --> Helper loaded: url_helper
INFO - 2018-07-16 21:31:01 --> Model Class Initialized
INFO - 2018-07-16 21:31:01 --> Final output sent to browser
DEBUG - 2018-07-16 21:31:01 --> Total execution time: 0.0456
ERROR - 2018-07-16 21:32:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:32:01 --> Config Class Initialized
INFO - 2018-07-16 21:32:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:32:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:32:01 --> Utf8 Class Initialized
INFO - 2018-07-16 21:32:01 --> URI Class Initialized
INFO - 2018-07-16 21:32:01 --> Router Class Initialized
INFO - 2018-07-16 21:32:01 --> Output Class Initialized
INFO - 2018-07-16 21:32:01 --> Security Class Initialized
DEBUG - 2018-07-16 21:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:32:01 --> Input Class Initialized
INFO - 2018-07-16 21:32:01 --> Language Class Initialized
INFO - 2018-07-16 21:32:01 --> Loader Class Initialized
INFO - 2018-07-16 21:32:01 --> Controller Class Initialized
INFO - 2018-07-16 21:32:01 --> Database Driver Class Initialized
INFO - 2018-07-16 21:32:01 --> Model Class Initialized
INFO - 2018-07-16 21:32:01 --> Helper loaded: url_helper
INFO - 2018-07-16 21:32:01 --> Model Class Initialized
INFO - 2018-07-16 21:32:01 --> Final output sent to browser
DEBUG - 2018-07-16 21:32:01 --> Total execution time: 0.1275
ERROR - 2018-07-16 21:33:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:33:52 --> Config Class Initialized
INFO - 2018-07-16 21:33:52 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:33:52 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:33:52 --> Utf8 Class Initialized
INFO - 2018-07-16 21:33:52 --> URI Class Initialized
INFO - 2018-07-16 21:33:52 --> Router Class Initialized
INFO - 2018-07-16 21:33:52 --> Output Class Initialized
INFO - 2018-07-16 21:33:52 --> Security Class Initialized
DEBUG - 2018-07-16 21:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:33:52 --> Input Class Initialized
INFO - 2018-07-16 21:33:52 --> Language Class Initialized
INFO - 2018-07-16 21:33:52 --> Loader Class Initialized
INFO - 2018-07-16 21:33:52 --> Controller Class Initialized
INFO - 2018-07-16 21:33:52 --> Database Driver Class Initialized
INFO - 2018-07-16 21:33:52 --> Model Class Initialized
INFO - 2018-07-16 21:33:52 --> Helper loaded: url_helper
INFO - 2018-07-16 21:33:52 --> Model Class Initialized
INFO - 2018-07-16 21:33:52 --> Final output sent to browser
DEBUG - 2018-07-16 21:33:52 --> Total execution time: 0.0523
ERROR - 2018-07-16 21:33:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:33:54 --> Config Class Initialized
INFO - 2018-07-16 21:33:54 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:33:54 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:33:54 --> Utf8 Class Initialized
INFO - 2018-07-16 21:33:54 --> URI Class Initialized
INFO - 2018-07-16 21:33:54 --> Router Class Initialized
INFO - 2018-07-16 21:33:54 --> Output Class Initialized
INFO - 2018-07-16 21:33:54 --> Security Class Initialized
DEBUG - 2018-07-16 21:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:33:54 --> Input Class Initialized
INFO - 2018-07-16 21:33:54 --> Language Class Initialized
INFO - 2018-07-16 21:33:54 --> Loader Class Initialized
INFO - 2018-07-16 21:33:54 --> Controller Class Initialized
INFO - 2018-07-16 21:33:54 --> Database Driver Class Initialized
INFO - 2018-07-16 21:33:54 --> Model Class Initialized
INFO - 2018-07-16 21:33:54 --> Helper loaded: url_helper
INFO - 2018-07-16 21:33:54 --> Model Class Initialized
INFO - 2018-07-16 21:33:54 --> Final output sent to browser
DEBUG - 2018-07-16 21:33:54 --> Total execution time: 0.0519
ERROR - 2018-07-16 21:33:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:33:54 --> Config Class Initialized
INFO - 2018-07-16 21:33:54 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:33:54 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:33:54 --> Utf8 Class Initialized
INFO - 2018-07-16 21:33:54 --> URI Class Initialized
INFO - 2018-07-16 21:33:54 --> Router Class Initialized
INFO - 2018-07-16 21:33:54 --> Output Class Initialized
INFO - 2018-07-16 21:33:54 --> Security Class Initialized
DEBUG - 2018-07-16 21:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:33:54 --> Input Class Initialized
INFO - 2018-07-16 21:33:54 --> Language Class Initialized
INFO - 2018-07-16 21:33:54 --> Loader Class Initialized
INFO - 2018-07-16 21:33:54 --> Controller Class Initialized
INFO - 2018-07-16 21:33:54 --> Database Driver Class Initialized
INFO - 2018-07-16 21:33:54 --> Model Class Initialized
INFO - 2018-07-16 21:33:54 --> Helper loaded: url_helper
INFO - 2018-07-16 21:33:54 --> Model Class Initialized
INFO - 2018-07-16 21:33:54 --> Final output sent to browser
DEBUG - 2018-07-16 21:33:54 --> Total execution time: 0.0451
ERROR - 2018-07-16 21:46:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:46:05 --> Config Class Initialized
INFO - 2018-07-16 21:46:05 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:46:05 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:46:05 --> Utf8 Class Initialized
INFO - 2018-07-16 21:46:05 --> URI Class Initialized
INFO - 2018-07-16 21:46:05 --> Router Class Initialized
INFO - 2018-07-16 21:46:05 --> Output Class Initialized
INFO - 2018-07-16 21:46:05 --> Security Class Initialized
DEBUG - 2018-07-16 21:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:46:05 --> Input Class Initialized
INFO - 2018-07-16 21:46:05 --> Language Class Initialized
INFO - 2018-07-16 21:46:05 --> Loader Class Initialized
INFO - 2018-07-16 21:46:05 --> Controller Class Initialized
INFO - 2018-07-16 21:46:05 --> Database Driver Class Initialized
INFO - 2018-07-16 21:46:05 --> Model Class Initialized
INFO - 2018-07-16 21:46:05 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:46:05 --> Model Class Initialized
INFO - 2018-07-16 21:46:05 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:46:05 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 21:46:05 --> Final output sent to browser
DEBUG - 2018-07-16 21:46:05 --> Total execution time: 0.1289
ERROR - 2018-07-16 21:46:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:46:08 --> Config Class Initialized
INFO - 2018-07-16 21:46:08 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:46:08 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:46:08 --> Utf8 Class Initialized
INFO - 2018-07-16 21:46:08 --> URI Class Initialized
INFO - 2018-07-16 21:46:08 --> Router Class Initialized
INFO - 2018-07-16 21:46:08 --> Output Class Initialized
INFO - 2018-07-16 21:46:08 --> Security Class Initialized
DEBUG - 2018-07-16 21:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:46:08 --> Input Class Initialized
INFO - 2018-07-16 21:46:08 --> Language Class Initialized
INFO - 2018-07-16 21:46:08 --> Loader Class Initialized
INFO - 2018-07-16 21:46:08 --> Controller Class Initialized
INFO - 2018-07-16 21:46:08 --> Database Driver Class Initialized
INFO - 2018-07-16 21:46:08 --> Model Class Initialized
INFO - 2018-07-16 21:46:08 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:46:08 --> Model Class Initialized
INFO - 2018-07-16 21:46:08 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:46:08 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 21:46:08 --> Final output sent to browser
DEBUG - 2018-07-16 21:46:08 --> Total execution time: 0.0708
ERROR - 2018-07-16 21:46:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:46:25 --> Config Class Initialized
INFO - 2018-07-16 21:46:25 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:46:25 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:46:25 --> Utf8 Class Initialized
INFO - 2018-07-16 21:46:25 --> URI Class Initialized
INFO - 2018-07-16 21:46:25 --> Router Class Initialized
INFO - 2018-07-16 21:46:25 --> Output Class Initialized
INFO - 2018-07-16 21:46:25 --> Security Class Initialized
DEBUG - 2018-07-16 21:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:46:25 --> Input Class Initialized
INFO - 2018-07-16 21:46:25 --> Language Class Initialized
INFO - 2018-07-16 21:46:25 --> Loader Class Initialized
INFO - 2018-07-16 21:46:25 --> Controller Class Initialized
INFO - 2018-07-16 21:46:25 --> Database Driver Class Initialized
INFO - 2018-07-16 21:46:25 --> Model Class Initialized
INFO - 2018-07-16 21:46:25 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:46:25 --> Model Class Initialized
INFO - 2018-07-16 21:46:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:46:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 21:46:25 --> Final output sent to browser
DEBUG - 2018-07-16 21:46:25 --> Total execution time: 0.1332
ERROR - 2018-07-16 21:46:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:46:44 --> Config Class Initialized
INFO - 2018-07-16 21:46:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:46:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:46:44 --> Utf8 Class Initialized
INFO - 2018-07-16 21:46:44 --> URI Class Initialized
INFO - 2018-07-16 21:46:44 --> Router Class Initialized
INFO - 2018-07-16 21:46:44 --> Output Class Initialized
INFO - 2018-07-16 21:46:44 --> Security Class Initialized
DEBUG - 2018-07-16 21:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:46:44 --> Input Class Initialized
INFO - 2018-07-16 21:46:44 --> Language Class Initialized
INFO - 2018-07-16 21:46:44 --> Loader Class Initialized
INFO - 2018-07-16 21:46:44 --> Controller Class Initialized
INFO - 2018-07-16 21:46:44 --> Database Driver Class Initialized
INFO - 2018-07-16 21:46:44 --> Model Class Initialized
INFO - 2018-07-16 21:46:44 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:46:44 --> Model Class Initialized
INFO - 2018-07-16 21:46:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:46:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 21:46:44 --> Final output sent to browser
DEBUG - 2018-07-16 21:46:44 --> Total execution time: 0.0651
ERROR - 2018-07-16 21:46:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:46:47 --> Config Class Initialized
INFO - 2018-07-16 21:46:47 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:46:47 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:46:47 --> Utf8 Class Initialized
INFO - 2018-07-16 21:46:47 --> URI Class Initialized
INFO - 2018-07-16 21:46:47 --> Router Class Initialized
INFO - 2018-07-16 21:46:47 --> Output Class Initialized
INFO - 2018-07-16 21:46:47 --> Security Class Initialized
DEBUG - 2018-07-16 21:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:46:47 --> Input Class Initialized
INFO - 2018-07-16 21:46:47 --> Language Class Initialized
INFO - 2018-07-16 21:46:47 --> Loader Class Initialized
INFO - 2018-07-16 21:46:47 --> Controller Class Initialized
INFO - 2018-07-16 21:46:47 --> Database Driver Class Initialized
INFO - 2018-07-16 21:46:47 --> Model Class Initialized
INFO - 2018-07-16 21:46:47 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:46:47 --> Model Class Initialized
ERROR - 2018-07-16 21:46:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:46:47 --> Config Class Initialized
INFO - 2018-07-16 21:46:47 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:46:47 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:46:47 --> Utf8 Class Initialized
INFO - 2018-07-16 21:46:47 --> URI Class Initialized
INFO - 2018-07-16 21:46:47 --> Router Class Initialized
INFO - 2018-07-16 21:46:47 --> Output Class Initialized
INFO - 2018-07-16 21:46:47 --> Security Class Initialized
DEBUG - 2018-07-16 21:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:46:47 --> Input Class Initialized
INFO - 2018-07-16 21:46:47 --> Language Class Initialized
INFO - 2018-07-16 21:46:47 --> Loader Class Initialized
INFO - 2018-07-16 21:46:47 --> Controller Class Initialized
INFO - 2018-07-16 21:46:47 --> Database Driver Class Initialized
INFO - 2018-07-16 21:46:47 --> Model Class Initialized
INFO - 2018-07-16 21:46:47 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:46:47 --> Model Class Initialized
INFO - 2018-07-16 21:46:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:46:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 21:46:47 --> Final output sent to browser
DEBUG - 2018-07-16 21:46:47 --> Total execution time: 0.0601
ERROR - 2018-07-16 21:46:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:46:54 --> Config Class Initialized
INFO - 2018-07-16 21:46:54 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:46:54 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:46:54 --> Utf8 Class Initialized
INFO - 2018-07-16 21:46:54 --> URI Class Initialized
INFO - 2018-07-16 21:46:54 --> Router Class Initialized
INFO - 2018-07-16 21:46:54 --> Output Class Initialized
INFO - 2018-07-16 21:46:54 --> Security Class Initialized
DEBUG - 2018-07-16 21:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:46:54 --> Input Class Initialized
INFO - 2018-07-16 21:46:54 --> Language Class Initialized
INFO - 2018-07-16 21:46:54 --> Loader Class Initialized
INFO - 2018-07-16 21:46:54 --> Controller Class Initialized
INFO - 2018-07-16 21:46:54 --> Database Driver Class Initialized
INFO - 2018-07-16 21:46:54 --> Model Class Initialized
INFO - 2018-07-16 21:46:54 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:46:54 --> Model Class Initialized
INFO - 2018-07-16 21:46:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:46:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 21:46:54 --> Final output sent to browser
DEBUG - 2018-07-16 21:46:54 --> Total execution time: 0.0635
ERROR - 2018-07-16 21:48:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:48:20 --> Config Class Initialized
INFO - 2018-07-16 21:48:20 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:48:20 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:48:20 --> Utf8 Class Initialized
INFO - 2018-07-16 21:48:20 --> URI Class Initialized
INFO - 2018-07-16 21:48:20 --> Router Class Initialized
INFO - 2018-07-16 21:48:20 --> Output Class Initialized
INFO - 2018-07-16 21:48:20 --> Security Class Initialized
DEBUG - 2018-07-16 21:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:48:20 --> Input Class Initialized
INFO - 2018-07-16 21:48:20 --> Language Class Initialized
INFO - 2018-07-16 21:48:20 --> Loader Class Initialized
INFO - 2018-07-16 21:48:20 --> Controller Class Initialized
INFO - 2018-07-16 21:48:20 --> Database Driver Class Initialized
INFO - 2018-07-16 21:48:20 --> Model Class Initialized
INFO - 2018-07-16 21:48:20 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:48:20 --> Model Class Initialized
INFO - 2018-07-16 21:48:20 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:48:20 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 21:48:20 --> Final output sent to browser
DEBUG - 2018-07-16 21:48:20 --> Total execution time: 0.0474
ERROR - 2018-07-16 21:48:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:48:31 --> Config Class Initialized
INFO - 2018-07-16 21:48:31 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:48:31 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:48:31 --> Utf8 Class Initialized
INFO - 2018-07-16 21:48:31 --> URI Class Initialized
INFO - 2018-07-16 21:48:31 --> Router Class Initialized
INFO - 2018-07-16 21:48:31 --> Output Class Initialized
INFO - 2018-07-16 21:48:31 --> Security Class Initialized
DEBUG - 2018-07-16 21:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:48:31 --> Input Class Initialized
INFO - 2018-07-16 21:48:31 --> Language Class Initialized
INFO - 2018-07-16 21:48:31 --> Loader Class Initialized
INFO - 2018-07-16 21:48:31 --> Controller Class Initialized
INFO - 2018-07-16 21:48:31 --> Database Driver Class Initialized
INFO - 2018-07-16 21:48:31 --> Model Class Initialized
INFO - 2018-07-16 21:48:31 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:48:31 --> Model Class Initialized
INFO - 2018-07-16 21:48:31 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:48:31 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 21:48:31 --> Final output sent to browser
DEBUG - 2018-07-16 21:48:31 --> Total execution time: 0.0518
ERROR - 2018-07-16 21:48:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:48:43 --> Config Class Initialized
INFO - 2018-07-16 21:48:43 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:48:43 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:48:43 --> Utf8 Class Initialized
INFO - 2018-07-16 21:48:43 --> URI Class Initialized
INFO - 2018-07-16 21:48:43 --> Router Class Initialized
INFO - 2018-07-16 21:48:43 --> Output Class Initialized
INFO - 2018-07-16 21:48:43 --> Security Class Initialized
DEBUG - 2018-07-16 21:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:48:43 --> Input Class Initialized
INFO - 2018-07-16 21:48:43 --> Language Class Initialized
INFO - 2018-07-16 21:48:43 --> Loader Class Initialized
INFO - 2018-07-16 21:48:43 --> Controller Class Initialized
INFO - 2018-07-16 21:48:43 --> Database Driver Class Initialized
INFO - 2018-07-16 21:48:43 --> Model Class Initialized
INFO - 2018-07-16 21:48:43 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:48:43 --> Model Class Initialized
INFO - 2018-07-16 21:48:43 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:48:43 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 21:48:43 --> Final output sent to browser
DEBUG - 2018-07-16 21:48:43 --> Total execution time: 0.0667
ERROR - 2018-07-16 21:50:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:50:02 --> Config Class Initialized
INFO - 2018-07-16 21:50:02 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:50:02 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:50:02 --> Utf8 Class Initialized
INFO - 2018-07-16 21:50:02 --> URI Class Initialized
INFO - 2018-07-16 21:50:02 --> Router Class Initialized
INFO - 2018-07-16 21:50:02 --> Output Class Initialized
INFO - 2018-07-16 21:50:02 --> Security Class Initialized
DEBUG - 2018-07-16 21:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:50:02 --> Input Class Initialized
INFO - 2018-07-16 21:50:02 --> Language Class Initialized
INFO - 2018-07-16 21:50:02 --> Loader Class Initialized
INFO - 2018-07-16 21:50:02 --> Controller Class Initialized
INFO - 2018-07-16 21:50:02 --> Database Driver Class Initialized
INFO - 2018-07-16 21:50:02 --> Model Class Initialized
INFO - 2018-07-16 21:50:02 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:50:02 --> Model Class Initialized
INFO - 2018-07-16 21:50:02 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:50:02 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 21:50:02 --> Final output sent to browser
DEBUG - 2018-07-16 21:50:02 --> Total execution time: 0.0535
ERROR - 2018-07-16 21:50:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:50:10 --> Config Class Initialized
INFO - 2018-07-16 21:50:10 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:50:10 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:50:10 --> Utf8 Class Initialized
INFO - 2018-07-16 21:50:10 --> URI Class Initialized
INFO - 2018-07-16 21:50:10 --> Router Class Initialized
INFO - 2018-07-16 21:50:10 --> Output Class Initialized
INFO - 2018-07-16 21:50:10 --> Security Class Initialized
DEBUG - 2018-07-16 21:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:50:10 --> Input Class Initialized
INFO - 2018-07-16 21:50:10 --> Language Class Initialized
INFO - 2018-07-16 21:50:10 --> Loader Class Initialized
INFO - 2018-07-16 21:50:10 --> Controller Class Initialized
INFO - 2018-07-16 21:50:10 --> Database Driver Class Initialized
INFO - 2018-07-16 21:50:10 --> Model Class Initialized
INFO - 2018-07-16 21:50:10 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:50:10 --> Model Class Initialized
INFO - 2018-07-16 21:50:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:50:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 21:50:10 --> Final output sent to browser
DEBUG - 2018-07-16 21:50:10 --> Total execution time: 0.0660
ERROR - 2018-07-16 21:50:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:50:44 --> Config Class Initialized
INFO - 2018-07-16 21:50:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:50:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:50:44 --> Utf8 Class Initialized
INFO - 2018-07-16 21:50:44 --> URI Class Initialized
INFO - 2018-07-16 21:50:44 --> Router Class Initialized
INFO - 2018-07-16 21:50:44 --> Output Class Initialized
INFO - 2018-07-16 21:50:44 --> Security Class Initialized
DEBUG - 2018-07-16 21:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:50:44 --> Input Class Initialized
INFO - 2018-07-16 21:50:44 --> Language Class Initialized
INFO - 2018-07-16 21:50:44 --> Loader Class Initialized
INFO - 2018-07-16 21:50:44 --> Controller Class Initialized
INFO - 2018-07-16 21:50:44 --> Database Driver Class Initialized
INFO - 2018-07-16 21:50:44 --> Model Class Initialized
INFO - 2018-07-16 21:50:44 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:50:44 --> Model Class Initialized
INFO - 2018-07-16 21:50:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:50:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 21:50:44 --> Final output sent to browser
DEBUG - 2018-07-16 21:50:44 --> Total execution time: 0.2063
ERROR - 2018-07-16 21:51:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:51:34 --> Config Class Initialized
INFO - 2018-07-16 21:51:34 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:51:34 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:51:34 --> Utf8 Class Initialized
INFO - 2018-07-16 21:51:34 --> URI Class Initialized
INFO - 2018-07-16 21:51:34 --> Router Class Initialized
INFO - 2018-07-16 21:51:34 --> Output Class Initialized
INFO - 2018-07-16 21:51:34 --> Security Class Initialized
DEBUG - 2018-07-16 21:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:51:34 --> Input Class Initialized
INFO - 2018-07-16 21:51:34 --> Language Class Initialized
INFO - 2018-07-16 21:51:34 --> Loader Class Initialized
INFO - 2018-07-16 21:51:34 --> Controller Class Initialized
INFO - 2018-07-16 21:51:34 --> Database Driver Class Initialized
INFO - 2018-07-16 21:51:34 --> Model Class Initialized
INFO - 2018-07-16 21:51:34 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:51:34 --> Model Class Initialized
INFO - 2018-07-16 21:51:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:51:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 21:51:34 --> Final output sent to browser
DEBUG - 2018-07-16 21:51:34 --> Total execution time: 0.0724
ERROR - 2018-07-16 21:51:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:51:50 --> Config Class Initialized
INFO - 2018-07-16 21:51:50 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:51:50 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:51:50 --> Utf8 Class Initialized
INFO - 2018-07-16 21:51:50 --> URI Class Initialized
INFO - 2018-07-16 21:51:50 --> Router Class Initialized
INFO - 2018-07-16 21:51:50 --> Output Class Initialized
INFO - 2018-07-16 21:51:50 --> Security Class Initialized
DEBUG - 2018-07-16 21:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:51:50 --> Input Class Initialized
INFO - 2018-07-16 21:51:50 --> Language Class Initialized
INFO - 2018-07-16 21:51:50 --> Loader Class Initialized
INFO - 2018-07-16 21:51:50 --> Controller Class Initialized
INFO - 2018-07-16 21:51:50 --> Database Driver Class Initialized
INFO - 2018-07-16 21:51:50 --> Model Class Initialized
INFO - 2018-07-16 21:51:50 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:51:50 --> Model Class Initialized
INFO - 2018-07-16 21:51:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:51:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 21:51:50 --> Final output sent to browser
DEBUG - 2018-07-16 21:51:50 --> Total execution time: 0.1291
ERROR - 2018-07-16 21:51:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:51:53 --> Config Class Initialized
INFO - 2018-07-16 21:51:53 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:51:53 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:51:53 --> Utf8 Class Initialized
INFO - 2018-07-16 21:51:53 --> URI Class Initialized
INFO - 2018-07-16 21:51:53 --> Router Class Initialized
INFO - 2018-07-16 21:51:53 --> Output Class Initialized
INFO - 2018-07-16 21:51:53 --> Security Class Initialized
DEBUG - 2018-07-16 21:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:51:53 --> Input Class Initialized
INFO - 2018-07-16 21:51:53 --> Language Class Initialized
INFO - 2018-07-16 21:51:53 --> Loader Class Initialized
INFO - 2018-07-16 21:51:53 --> Controller Class Initialized
INFO - 2018-07-16 21:51:53 --> Database Driver Class Initialized
INFO - 2018-07-16 21:51:53 --> Model Class Initialized
INFO - 2018-07-16 21:51:53 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:51:53 --> Model Class Initialized
INFO - 2018-07-16 21:51:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:51:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 21:51:53 --> Final output sent to browser
DEBUG - 2018-07-16 21:51:53 --> Total execution time: 0.0577
ERROR - 2018-07-16 21:51:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:51:57 --> Config Class Initialized
INFO - 2018-07-16 21:51:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:51:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:51:57 --> Utf8 Class Initialized
INFO - 2018-07-16 21:51:57 --> URI Class Initialized
INFO - 2018-07-16 21:51:57 --> Router Class Initialized
INFO - 2018-07-16 21:51:57 --> Output Class Initialized
INFO - 2018-07-16 21:51:57 --> Security Class Initialized
DEBUG - 2018-07-16 21:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:51:57 --> Input Class Initialized
INFO - 2018-07-16 21:51:57 --> Language Class Initialized
INFO - 2018-07-16 21:51:57 --> Loader Class Initialized
INFO - 2018-07-16 21:51:57 --> Controller Class Initialized
INFO - 2018-07-16 21:51:57 --> Database Driver Class Initialized
INFO - 2018-07-16 21:51:57 --> Model Class Initialized
INFO - 2018-07-16 21:51:57 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:51:57 --> Model Class Initialized
ERROR - 2018-07-16 21:51:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:51:57 --> Config Class Initialized
INFO - 2018-07-16 21:51:57 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:51:57 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:51:57 --> Utf8 Class Initialized
INFO - 2018-07-16 21:51:57 --> URI Class Initialized
INFO - 2018-07-16 21:51:57 --> Router Class Initialized
INFO - 2018-07-16 21:51:57 --> Output Class Initialized
INFO - 2018-07-16 21:51:57 --> Security Class Initialized
DEBUG - 2018-07-16 21:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:51:57 --> Input Class Initialized
INFO - 2018-07-16 21:51:57 --> Language Class Initialized
INFO - 2018-07-16 21:51:57 --> Loader Class Initialized
INFO - 2018-07-16 21:51:57 --> Controller Class Initialized
INFO - 2018-07-16 21:51:57 --> Database Driver Class Initialized
INFO - 2018-07-16 21:51:57 --> Model Class Initialized
INFO - 2018-07-16 21:51:57 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:51:57 --> Model Class Initialized
INFO - 2018-07-16 21:51:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:51:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 21:51:57 --> Final output sent to browser
DEBUG - 2018-07-16 21:51:57 --> Total execution time: 0.0776
ERROR - 2018-07-16 21:51:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:51:59 --> Config Class Initialized
INFO - 2018-07-16 21:51:59 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:51:59 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:51:59 --> Utf8 Class Initialized
INFO - 2018-07-16 21:51:59 --> URI Class Initialized
INFO - 2018-07-16 21:51:59 --> Router Class Initialized
INFO - 2018-07-16 21:51:59 --> Output Class Initialized
INFO - 2018-07-16 21:51:59 --> Security Class Initialized
DEBUG - 2018-07-16 21:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:51:59 --> Input Class Initialized
INFO - 2018-07-16 21:51:59 --> Language Class Initialized
INFO - 2018-07-16 21:51:59 --> Loader Class Initialized
INFO - 2018-07-16 21:51:59 --> Controller Class Initialized
INFO - 2018-07-16 21:51:59 --> Database Driver Class Initialized
INFO - 2018-07-16 21:51:59 --> Model Class Initialized
INFO - 2018-07-16 21:51:59 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:51:59 --> Model Class Initialized
ERROR - 2018-07-16 21:51:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:51:59 --> Config Class Initialized
INFO - 2018-07-16 21:51:59 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:51:59 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:51:59 --> Utf8 Class Initialized
INFO - 2018-07-16 21:51:59 --> URI Class Initialized
INFO - 2018-07-16 21:51:59 --> Router Class Initialized
INFO - 2018-07-16 21:51:59 --> Output Class Initialized
INFO - 2018-07-16 21:51:59 --> Security Class Initialized
DEBUG - 2018-07-16 21:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:51:59 --> Input Class Initialized
INFO - 2018-07-16 21:51:59 --> Language Class Initialized
INFO - 2018-07-16 21:51:59 --> Loader Class Initialized
INFO - 2018-07-16 21:51:59 --> Controller Class Initialized
INFO - 2018-07-16 21:51:59 --> Database Driver Class Initialized
INFO - 2018-07-16 21:51:59 --> Model Class Initialized
INFO - 2018-07-16 21:51:59 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:51:59 --> Model Class Initialized
INFO - 2018-07-16 21:51:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:51:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 21:51:59 --> Final output sent to browser
DEBUG - 2018-07-16 21:51:59 --> Total execution time: 0.0658
ERROR - 2018-07-16 21:52:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:52:24 --> Config Class Initialized
INFO - 2018-07-16 21:52:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:52:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:52:24 --> Utf8 Class Initialized
INFO - 2018-07-16 21:52:24 --> URI Class Initialized
INFO - 2018-07-16 21:52:24 --> Router Class Initialized
INFO - 2018-07-16 21:52:24 --> Output Class Initialized
INFO - 2018-07-16 21:52:24 --> Security Class Initialized
DEBUG - 2018-07-16 21:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:52:24 --> Input Class Initialized
INFO - 2018-07-16 21:52:24 --> Language Class Initialized
INFO - 2018-07-16 21:52:24 --> Loader Class Initialized
INFO - 2018-07-16 21:52:24 --> Controller Class Initialized
INFO - 2018-07-16 21:52:24 --> Database Driver Class Initialized
INFO - 2018-07-16 21:52:24 --> Model Class Initialized
INFO - 2018-07-16 21:52:24 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:52:24 --> Model Class Initialized
INFO - 2018-07-16 21:52:24 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:52:24 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 21:52:24 --> Final output sent to browser
DEBUG - 2018-07-16 21:52:24 --> Total execution time: 0.0485
ERROR - 2018-07-16 21:53:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:53:06 --> Config Class Initialized
INFO - 2018-07-16 21:53:06 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:53:06 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:53:06 --> Utf8 Class Initialized
INFO - 2018-07-16 21:53:06 --> URI Class Initialized
INFO - 2018-07-16 21:53:06 --> Router Class Initialized
INFO - 2018-07-16 21:53:06 --> Output Class Initialized
INFO - 2018-07-16 21:53:06 --> Security Class Initialized
DEBUG - 2018-07-16 21:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:53:06 --> Input Class Initialized
INFO - 2018-07-16 21:53:06 --> Language Class Initialized
INFO - 2018-07-16 21:53:06 --> Loader Class Initialized
INFO - 2018-07-16 21:53:06 --> Controller Class Initialized
INFO - 2018-07-16 21:53:06 --> Database Driver Class Initialized
INFO - 2018-07-16 21:53:06 --> Model Class Initialized
INFO - 2018-07-16 21:53:06 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:53:07 --> Model Class Initialized
INFO - 2018-07-16 21:53:07 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:53:07 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 21:53:07 --> Final output sent to browser
DEBUG - 2018-07-16 21:53:07 --> Total execution time: 0.3295
ERROR - 2018-07-16 21:53:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:53:32 --> Config Class Initialized
INFO - 2018-07-16 21:53:32 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:53:32 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:53:32 --> Utf8 Class Initialized
INFO - 2018-07-16 21:53:32 --> URI Class Initialized
INFO - 2018-07-16 21:53:32 --> Router Class Initialized
INFO - 2018-07-16 21:53:32 --> Output Class Initialized
INFO - 2018-07-16 21:53:32 --> Security Class Initialized
DEBUG - 2018-07-16 21:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:53:32 --> Input Class Initialized
INFO - 2018-07-16 21:53:32 --> Language Class Initialized
INFO - 2018-07-16 21:53:32 --> Loader Class Initialized
INFO - 2018-07-16 21:53:32 --> Controller Class Initialized
INFO - 2018-07-16 21:53:32 --> Database Driver Class Initialized
INFO - 2018-07-16 21:53:32 --> Model Class Initialized
INFO - 2018-07-16 21:53:32 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:53:32 --> Model Class Initialized
INFO - 2018-07-16 21:53:32 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:53:32 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 21:53:32 --> Final output sent to browser
DEBUG - 2018-07-16 21:53:32 --> Total execution time: 0.0667
ERROR - 2018-07-16 21:54:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:54:30 --> Config Class Initialized
INFO - 2018-07-16 21:54:30 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:54:30 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:54:30 --> Utf8 Class Initialized
INFO - 2018-07-16 21:54:30 --> URI Class Initialized
INFO - 2018-07-16 21:54:30 --> Router Class Initialized
INFO - 2018-07-16 21:54:30 --> Output Class Initialized
INFO - 2018-07-16 21:54:30 --> Security Class Initialized
DEBUG - 2018-07-16 21:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:54:30 --> Input Class Initialized
INFO - 2018-07-16 21:54:30 --> Language Class Initialized
INFO - 2018-07-16 21:54:30 --> Loader Class Initialized
INFO - 2018-07-16 21:54:30 --> Controller Class Initialized
INFO - 2018-07-16 21:54:30 --> Database Driver Class Initialized
INFO - 2018-07-16 21:54:30 --> Model Class Initialized
INFO - 2018-07-16 21:54:30 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:54:30 --> Model Class Initialized
INFO - 2018-07-16 21:54:30 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:54:30 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 21:54:30 --> Final output sent to browser
DEBUG - 2018-07-16 21:54:30 --> Total execution time: 0.0744
ERROR - 2018-07-16 21:54:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:54:37 --> Config Class Initialized
INFO - 2018-07-16 21:54:37 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:54:37 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:54:37 --> Utf8 Class Initialized
INFO - 2018-07-16 21:54:37 --> URI Class Initialized
INFO - 2018-07-16 21:54:37 --> Router Class Initialized
INFO - 2018-07-16 21:54:37 --> Output Class Initialized
INFO - 2018-07-16 21:54:37 --> Security Class Initialized
DEBUG - 2018-07-16 21:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:54:37 --> Input Class Initialized
INFO - 2018-07-16 21:54:37 --> Language Class Initialized
INFO - 2018-07-16 21:54:37 --> Loader Class Initialized
INFO - 2018-07-16 21:54:37 --> Controller Class Initialized
INFO - 2018-07-16 21:54:37 --> Database Driver Class Initialized
INFO - 2018-07-16 21:54:37 --> Model Class Initialized
INFO - 2018-07-16 21:54:37 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:54:37 --> Model Class Initialized
INFO - 2018-07-16 21:54:37 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:54:37 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-16 21:54:37 --> Final output sent to browser
DEBUG - 2018-07-16 21:54:37 --> Total execution time: 0.0788
ERROR - 2018-07-16 21:54:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:54:50 --> Config Class Initialized
INFO - 2018-07-16 21:54:50 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:54:50 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:54:50 --> Utf8 Class Initialized
INFO - 2018-07-16 21:54:50 --> URI Class Initialized
INFO - 2018-07-16 21:54:50 --> Router Class Initialized
INFO - 2018-07-16 21:54:50 --> Output Class Initialized
INFO - 2018-07-16 21:54:50 --> Security Class Initialized
DEBUG - 2018-07-16 21:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:54:50 --> Input Class Initialized
INFO - 2018-07-16 21:54:50 --> Language Class Initialized
INFO - 2018-07-16 21:54:50 --> Loader Class Initialized
INFO - 2018-07-16 21:54:50 --> Controller Class Initialized
INFO - 2018-07-16 21:54:50 --> Database Driver Class Initialized
INFO - 2018-07-16 21:54:50 --> Model Class Initialized
INFO - 2018-07-16 21:54:50 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:54:50 --> Model Class Initialized
INFO - 2018-07-16 21:54:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:54:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 21:54:50 --> Final output sent to browser
DEBUG - 2018-07-16 21:54:50 --> Total execution time: 0.0582
ERROR - 2018-07-16 21:54:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:54:54 --> Config Class Initialized
INFO - 2018-07-16 21:54:54 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:54:54 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:54:54 --> Utf8 Class Initialized
INFO - 2018-07-16 21:54:54 --> URI Class Initialized
INFO - 2018-07-16 21:54:54 --> Router Class Initialized
INFO - 2018-07-16 21:54:54 --> Output Class Initialized
INFO - 2018-07-16 21:54:54 --> Security Class Initialized
DEBUG - 2018-07-16 21:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:54:54 --> Input Class Initialized
INFO - 2018-07-16 21:54:54 --> Language Class Initialized
INFO - 2018-07-16 21:54:54 --> Loader Class Initialized
INFO - 2018-07-16 21:54:54 --> Controller Class Initialized
INFO - 2018-07-16 21:54:54 --> Database Driver Class Initialized
INFO - 2018-07-16 21:54:54 --> Model Class Initialized
INFO - 2018-07-16 21:54:54 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:54:54 --> Model Class Initialized
ERROR - 2018-07-16 21:54:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:54:54 --> Config Class Initialized
INFO - 2018-07-16 21:54:54 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:54:54 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:54:54 --> Utf8 Class Initialized
INFO - 2018-07-16 21:54:54 --> URI Class Initialized
INFO - 2018-07-16 21:54:54 --> Router Class Initialized
INFO - 2018-07-16 21:54:54 --> Output Class Initialized
INFO - 2018-07-16 21:54:54 --> Security Class Initialized
DEBUG - 2018-07-16 21:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:54:54 --> Input Class Initialized
INFO - 2018-07-16 21:54:54 --> Language Class Initialized
INFO - 2018-07-16 21:54:54 --> Loader Class Initialized
INFO - 2018-07-16 21:54:54 --> Controller Class Initialized
INFO - 2018-07-16 21:54:54 --> Database Driver Class Initialized
INFO - 2018-07-16 21:54:54 --> Model Class Initialized
INFO - 2018-07-16 21:54:54 --> Helper loaded: url_helper
DEBUG - 2018-07-16 21:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 21:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 21:54:54 --> Model Class Initialized
INFO - 2018-07-16 21:54:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 21:54:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 21:54:54 --> Final output sent to browser
DEBUG - 2018-07-16 21:54:54 --> Total execution time: 0.0621
ERROR - 2018-07-16 21:57:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:57:44 --> Config Class Initialized
INFO - 2018-07-16 21:57:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:57:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:57:44 --> Utf8 Class Initialized
INFO - 2018-07-16 21:57:44 --> URI Class Initialized
INFO - 2018-07-16 21:57:44 --> Router Class Initialized
INFO - 2018-07-16 21:57:44 --> Output Class Initialized
INFO - 2018-07-16 21:57:44 --> Security Class Initialized
DEBUG - 2018-07-16 21:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:57:44 --> Input Class Initialized
INFO - 2018-07-16 21:57:44 --> Language Class Initialized
INFO - 2018-07-16 21:57:44 --> Loader Class Initialized
INFO - 2018-07-16 21:57:44 --> Controller Class Initialized
INFO - 2018-07-16 21:57:44 --> Database Driver Class Initialized
INFO - 2018-07-16 21:57:44 --> Model Class Initialized
INFO - 2018-07-16 21:57:44 --> Helper loaded: url_helper
INFO - 2018-07-16 21:57:44 --> Model Class Initialized
INFO - 2018-07-16 21:57:44 --> Final output sent to browser
DEBUG - 2018-07-16 21:57:44 --> Total execution time: 0.0585
ERROR - 2018-07-16 21:57:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:57:46 --> Config Class Initialized
INFO - 2018-07-16 21:57:46 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:57:46 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:57:46 --> Utf8 Class Initialized
INFO - 2018-07-16 21:57:46 --> URI Class Initialized
INFO - 2018-07-16 21:57:46 --> Router Class Initialized
INFO - 2018-07-16 21:57:46 --> Output Class Initialized
INFO - 2018-07-16 21:57:46 --> Security Class Initialized
DEBUG - 2018-07-16 21:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:57:46 --> Input Class Initialized
INFO - 2018-07-16 21:57:46 --> Language Class Initialized
INFO - 2018-07-16 21:57:46 --> Loader Class Initialized
INFO - 2018-07-16 21:57:46 --> Controller Class Initialized
INFO - 2018-07-16 21:57:46 --> Database Driver Class Initialized
INFO - 2018-07-16 21:57:46 --> Model Class Initialized
INFO - 2018-07-16 21:57:46 --> Helper loaded: url_helper
INFO - 2018-07-16 21:57:46 --> Model Class Initialized
INFO - 2018-07-16 21:57:46 --> Final output sent to browser
DEBUG - 2018-07-16 21:57:46 --> Total execution time: 0.0580
ERROR - 2018-07-16 21:57:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:57:46 --> Config Class Initialized
INFO - 2018-07-16 21:57:46 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:57:46 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:57:46 --> Utf8 Class Initialized
INFO - 2018-07-16 21:57:46 --> URI Class Initialized
INFO - 2018-07-16 21:57:46 --> Router Class Initialized
INFO - 2018-07-16 21:57:46 --> Output Class Initialized
INFO - 2018-07-16 21:57:46 --> Security Class Initialized
DEBUG - 2018-07-16 21:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:57:46 --> Input Class Initialized
INFO - 2018-07-16 21:57:46 --> Language Class Initialized
INFO - 2018-07-16 21:57:46 --> Loader Class Initialized
INFO - 2018-07-16 21:57:46 --> Controller Class Initialized
INFO - 2018-07-16 21:57:46 --> Database Driver Class Initialized
INFO - 2018-07-16 21:57:46 --> Model Class Initialized
INFO - 2018-07-16 21:57:46 --> Helper loaded: url_helper
INFO - 2018-07-16 21:57:46 --> Model Class Initialized
INFO - 2018-07-16 21:57:46 --> Final output sent to browser
DEBUG - 2018-07-16 21:57:46 --> Total execution time: 0.0450
ERROR - 2018-07-16 21:58:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 21:58:35 --> Config Class Initialized
INFO - 2018-07-16 21:58:35 --> Hooks Class Initialized
DEBUG - 2018-07-16 21:58:35 --> UTF-8 Support Enabled
INFO - 2018-07-16 21:58:35 --> Utf8 Class Initialized
INFO - 2018-07-16 21:58:35 --> URI Class Initialized
INFO - 2018-07-16 21:58:35 --> Router Class Initialized
INFO - 2018-07-16 21:58:35 --> Output Class Initialized
INFO - 2018-07-16 21:58:35 --> Security Class Initialized
DEBUG - 2018-07-16 21:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 21:58:35 --> Input Class Initialized
INFO - 2018-07-16 21:58:35 --> Language Class Initialized
INFO - 2018-07-16 21:58:35 --> Loader Class Initialized
INFO - 2018-07-16 21:58:35 --> Controller Class Initialized
INFO - 2018-07-16 21:58:35 --> Database Driver Class Initialized
INFO - 2018-07-16 21:58:35 --> Model Class Initialized
INFO - 2018-07-16 21:58:35 --> Helper loaded: url_helper
INFO - 2018-07-16 21:58:35 --> Model Class Initialized
INFO - 2018-07-16 21:58:35 --> Final output sent to browser
DEBUG - 2018-07-16 21:58:35 --> Total execution time: 0.0676
ERROR - 2018-07-16 22:00:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:00:16 --> Config Class Initialized
INFO - 2018-07-16 22:00:16 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:00:16 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:00:16 --> Utf8 Class Initialized
INFO - 2018-07-16 22:00:16 --> URI Class Initialized
INFO - 2018-07-16 22:00:16 --> Router Class Initialized
INFO - 2018-07-16 22:00:16 --> Output Class Initialized
INFO - 2018-07-16 22:00:16 --> Security Class Initialized
DEBUG - 2018-07-16 22:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:00:16 --> Input Class Initialized
INFO - 2018-07-16 22:00:16 --> Language Class Initialized
INFO - 2018-07-16 22:00:16 --> Loader Class Initialized
INFO - 2018-07-16 22:00:16 --> Controller Class Initialized
INFO - 2018-07-16 22:00:16 --> Database Driver Class Initialized
INFO - 2018-07-16 22:00:16 --> Model Class Initialized
INFO - 2018-07-16 22:00:16 --> Helper loaded: url_helper
INFO - 2018-07-16 22:00:16 --> Model Class Initialized
INFO - 2018-07-16 22:00:16 --> Final output sent to browser
DEBUG - 2018-07-16 22:00:16 --> Total execution time: 0.0534
ERROR - 2018-07-16 22:00:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:00:30 --> Config Class Initialized
INFO - 2018-07-16 22:00:30 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:00:30 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:00:30 --> Utf8 Class Initialized
INFO - 2018-07-16 22:00:30 --> URI Class Initialized
INFO - 2018-07-16 22:00:30 --> Router Class Initialized
INFO - 2018-07-16 22:00:30 --> Output Class Initialized
INFO - 2018-07-16 22:00:30 --> Security Class Initialized
DEBUG - 2018-07-16 22:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:00:30 --> Input Class Initialized
INFO - 2018-07-16 22:00:30 --> Language Class Initialized
INFO - 2018-07-16 22:00:30 --> Loader Class Initialized
INFO - 2018-07-16 22:00:30 --> Controller Class Initialized
INFO - 2018-07-16 22:00:30 --> Database Driver Class Initialized
INFO - 2018-07-16 22:00:30 --> Model Class Initialized
INFO - 2018-07-16 22:00:30 --> Helper loaded: url_helper
INFO - 2018-07-16 22:00:30 --> Model Class Initialized
INFO - 2018-07-16 22:00:30 --> Final output sent to browser
DEBUG - 2018-07-16 22:00:30 --> Total execution time: 0.0489
ERROR - 2018-07-16 22:03:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:03:35 --> Config Class Initialized
INFO - 2018-07-16 22:03:35 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:03:35 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:03:35 --> Utf8 Class Initialized
INFO - 2018-07-16 22:03:35 --> URI Class Initialized
INFO - 2018-07-16 22:03:36 --> Router Class Initialized
INFO - 2018-07-16 22:03:36 --> Output Class Initialized
INFO - 2018-07-16 22:03:36 --> Security Class Initialized
DEBUG - 2018-07-16 22:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:03:36 --> Input Class Initialized
INFO - 2018-07-16 22:03:36 --> Language Class Initialized
INFO - 2018-07-16 22:03:36 --> Loader Class Initialized
INFO - 2018-07-16 22:03:36 --> Controller Class Initialized
INFO - 2018-07-16 22:03:36 --> Database Driver Class Initialized
INFO - 2018-07-16 22:03:36 --> Model Class Initialized
INFO - 2018-07-16 22:03:36 --> Helper loaded: url_helper
INFO - 2018-07-16 22:03:36 --> Model Class Initialized
INFO - 2018-07-16 22:03:36 --> Final output sent to browser
DEBUG - 2018-07-16 22:03:36 --> Total execution time: 0.0527
ERROR - 2018-07-16 22:04:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:04:12 --> Config Class Initialized
INFO - 2018-07-16 22:04:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:04:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:04:12 --> Utf8 Class Initialized
INFO - 2018-07-16 22:04:12 --> URI Class Initialized
INFO - 2018-07-16 22:04:12 --> Router Class Initialized
INFO - 2018-07-16 22:04:12 --> Output Class Initialized
INFO - 2018-07-16 22:04:12 --> Security Class Initialized
DEBUG - 2018-07-16 22:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:04:12 --> Input Class Initialized
INFO - 2018-07-16 22:04:12 --> Language Class Initialized
INFO - 2018-07-16 22:04:12 --> Loader Class Initialized
INFO - 2018-07-16 22:04:12 --> Controller Class Initialized
INFO - 2018-07-16 22:04:12 --> Database Driver Class Initialized
INFO - 2018-07-16 22:04:12 --> Model Class Initialized
INFO - 2018-07-16 22:04:12 --> Helper loaded: url_helper
INFO - 2018-07-16 22:04:12 --> Model Class Initialized
INFO - 2018-07-16 22:04:12 --> Final output sent to browser
DEBUG - 2018-07-16 22:04:12 --> Total execution time: 0.0410
ERROR - 2018-07-16 22:04:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:04:20 --> Config Class Initialized
INFO - 2018-07-16 22:04:20 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:04:20 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:04:20 --> Utf8 Class Initialized
INFO - 2018-07-16 22:04:20 --> URI Class Initialized
INFO - 2018-07-16 22:04:20 --> Router Class Initialized
INFO - 2018-07-16 22:04:20 --> Output Class Initialized
INFO - 2018-07-16 22:04:20 --> Security Class Initialized
DEBUG - 2018-07-16 22:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:04:20 --> Input Class Initialized
INFO - 2018-07-16 22:04:20 --> Language Class Initialized
INFO - 2018-07-16 22:04:20 --> Loader Class Initialized
INFO - 2018-07-16 22:04:20 --> Controller Class Initialized
INFO - 2018-07-16 22:04:20 --> Database Driver Class Initialized
INFO - 2018-07-16 22:04:20 --> Model Class Initialized
INFO - 2018-07-16 22:04:20 --> Helper loaded: url_helper
INFO - 2018-07-16 22:04:20 --> Model Class Initialized
INFO - 2018-07-16 22:04:20 --> Final output sent to browser
DEBUG - 2018-07-16 22:04:20 --> Total execution time: 0.0561
ERROR - 2018-07-16 22:04:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:04:50 --> Config Class Initialized
INFO - 2018-07-16 22:04:50 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:04:50 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:04:50 --> Utf8 Class Initialized
INFO - 2018-07-16 22:04:50 --> URI Class Initialized
INFO - 2018-07-16 22:04:50 --> Router Class Initialized
INFO - 2018-07-16 22:04:50 --> Output Class Initialized
INFO - 2018-07-16 22:04:50 --> Security Class Initialized
DEBUG - 2018-07-16 22:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:04:50 --> Input Class Initialized
INFO - 2018-07-16 22:04:50 --> Language Class Initialized
INFO - 2018-07-16 22:04:50 --> Loader Class Initialized
INFO - 2018-07-16 22:04:50 --> Controller Class Initialized
INFO - 2018-07-16 22:04:50 --> Database Driver Class Initialized
INFO - 2018-07-16 22:04:50 --> Model Class Initialized
INFO - 2018-07-16 22:04:50 --> Helper loaded: url_helper
INFO - 2018-07-16 22:04:50 --> Model Class Initialized
INFO - 2018-07-16 22:04:50 --> Final output sent to browser
DEBUG - 2018-07-16 22:04:50 --> Total execution time: 0.0480
ERROR - 2018-07-16 22:05:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:05:13 --> Config Class Initialized
INFO - 2018-07-16 22:05:13 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:05:13 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:05:13 --> Utf8 Class Initialized
INFO - 2018-07-16 22:05:13 --> URI Class Initialized
INFO - 2018-07-16 22:05:13 --> Router Class Initialized
INFO - 2018-07-16 22:05:13 --> Output Class Initialized
INFO - 2018-07-16 22:05:13 --> Security Class Initialized
DEBUG - 2018-07-16 22:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:05:13 --> Input Class Initialized
INFO - 2018-07-16 22:05:13 --> Language Class Initialized
INFO - 2018-07-16 22:05:13 --> Loader Class Initialized
INFO - 2018-07-16 22:05:13 --> Controller Class Initialized
INFO - 2018-07-16 22:05:13 --> Database Driver Class Initialized
INFO - 2018-07-16 22:05:13 --> Model Class Initialized
INFO - 2018-07-16 22:05:13 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:05:13 --> Model Class Initialized
INFO - 2018-07-16 22:05:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 22:05:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-16 22:05:13 --> Final output sent to browser
DEBUG - 2018-07-16 22:05:13 --> Total execution time: 0.0548
ERROR - 2018-07-16 22:05:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:05:16 --> Config Class Initialized
INFO - 2018-07-16 22:05:16 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:05:16 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:05:16 --> Utf8 Class Initialized
INFO - 2018-07-16 22:05:16 --> URI Class Initialized
INFO - 2018-07-16 22:05:16 --> Router Class Initialized
INFO - 2018-07-16 22:05:16 --> Output Class Initialized
INFO - 2018-07-16 22:05:16 --> Security Class Initialized
DEBUG - 2018-07-16 22:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:05:16 --> Input Class Initialized
INFO - 2018-07-16 22:05:16 --> Language Class Initialized
INFO - 2018-07-16 22:05:16 --> Loader Class Initialized
INFO - 2018-07-16 22:05:16 --> Controller Class Initialized
INFO - 2018-07-16 22:05:16 --> Database Driver Class Initialized
INFO - 2018-07-16 22:05:16 --> Model Class Initialized
INFO - 2018-07-16 22:05:16 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:05:16 --> Model Class Initialized
INFO - 2018-07-16 22:05:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 22:05:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-16 22:05:16 --> Final output sent to browser
DEBUG - 2018-07-16 22:05:16 --> Total execution time: 0.0750
ERROR - 2018-07-16 22:05:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:05:18 --> Config Class Initialized
INFO - 2018-07-16 22:05:18 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:05:18 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:05:18 --> Utf8 Class Initialized
INFO - 2018-07-16 22:05:18 --> URI Class Initialized
INFO - 2018-07-16 22:05:18 --> Router Class Initialized
INFO - 2018-07-16 22:05:18 --> Output Class Initialized
INFO - 2018-07-16 22:05:18 --> Security Class Initialized
DEBUG - 2018-07-16 22:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:05:18 --> Input Class Initialized
INFO - 2018-07-16 22:05:18 --> Language Class Initialized
INFO - 2018-07-16 22:05:18 --> Loader Class Initialized
INFO - 2018-07-16 22:05:18 --> Controller Class Initialized
INFO - 2018-07-16 22:05:18 --> Database Driver Class Initialized
INFO - 2018-07-16 22:05:18 --> Model Class Initialized
INFO - 2018-07-16 22:05:18 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:05:18 --> Model Class Initialized
INFO - 2018-07-16 22:05:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 22:05:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-16 22:05:18 --> Final output sent to browser
DEBUG - 2018-07-16 22:05:18 --> Total execution time: 0.0611
ERROR - 2018-07-16 22:06:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:06:41 --> Config Class Initialized
INFO - 2018-07-16 22:06:41 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:06:41 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:06:41 --> Utf8 Class Initialized
INFO - 2018-07-16 22:06:41 --> URI Class Initialized
INFO - 2018-07-16 22:06:41 --> Router Class Initialized
INFO - 2018-07-16 22:06:41 --> Output Class Initialized
INFO - 2018-07-16 22:06:41 --> Security Class Initialized
DEBUG - 2018-07-16 22:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:06:41 --> Input Class Initialized
INFO - 2018-07-16 22:06:41 --> Language Class Initialized
INFO - 2018-07-16 22:06:41 --> Loader Class Initialized
INFO - 2018-07-16 22:06:41 --> Controller Class Initialized
INFO - 2018-07-16 22:06:41 --> Database Driver Class Initialized
INFO - 2018-07-16 22:06:41 --> Model Class Initialized
INFO - 2018-07-16 22:06:41 --> Helper loaded: url_helper
INFO - 2018-07-16 22:06:41 --> Model Class Initialized
INFO - 2018-07-16 22:06:41 --> Final output sent to browser
DEBUG - 2018-07-16 22:06:41 --> Total execution time: 0.0962
ERROR - 2018-07-16 22:07:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:07:37 --> Config Class Initialized
INFO - 2018-07-16 22:07:37 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:07:37 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:07:37 --> Utf8 Class Initialized
INFO - 2018-07-16 22:07:37 --> URI Class Initialized
INFO - 2018-07-16 22:07:37 --> Router Class Initialized
INFO - 2018-07-16 22:07:37 --> Output Class Initialized
INFO - 2018-07-16 22:07:37 --> Security Class Initialized
DEBUG - 2018-07-16 22:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:07:37 --> Input Class Initialized
INFO - 2018-07-16 22:07:37 --> Language Class Initialized
INFO - 2018-07-16 22:07:37 --> Loader Class Initialized
INFO - 2018-07-16 22:07:37 --> Controller Class Initialized
INFO - 2018-07-16 22:07:37 --> Database Driver Class Initialized
INFO - 2018-07-16 22:07:37 --> Model Class Initialized
INFO - 2018-07-16 22:07:37 --> Helper loaded: url_helper
INFO - 2018-07-16 22:07:37 --> Model Class Initialized
INFO - 2018-07-16 22:07:37 --> Final output sent to browser
DEBUG - 2018-07-16 22:07:37 --> Total execution time: 0.0481
ERROR - 2018-07-16 22:07:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:07:44 --> Config Class Initialized
INFO - 2018-07-16 22:07:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:07:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:07:44 --> Utf8 Class Initialized
INFO - 2018-07-16 22:07:44 --> URI Class Initialized
INFO - 2018-07-16 22:07:44 --> Router Class Initialized
INFO - 2018-07-16 22:07:44 --> Output Class Initialized
INFO - 2018-07-16 22:07:44 --> Security Class Initialized
DEBUG - 2018-07-16 22:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:07:44 --> Input Class Initialized
INFO - 2018-07-16 22:07:44 --> Language Class Initialized
INFO - 2018-07-16 22:07:44 --> Loader Class Initialized
INFO - 2018-07-16 22:07:44 --> Controller Class Initialized
INFO - 2018-07-16 22:07:44 --> Database Driver Class Initialized
INFO - 2018-07-16 22:07:44 --> Model Class Initialized
INFO - 2018-07-16 22:07:44 --> Helper loaded: url_helper
INFO - 2018-07-16 22:07:44 --> Model Class Initialized
INFO - 2018-07-16 22:07:44 --> Final output sent to browser
DEBUG - 2018-07-16 22:07:44 --> Total execution time: 0.0590
ERROR - 2018-07-16 22:07:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:07:47 --> Config Class Initialized
INFO - 2018-07-16 22:07:47 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:07:47 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:07:47 --> Utf8 Class Initialized
INFO - 2018-07-16 22:07:47 --> URI Class Initialized
INFO - 2018-07-16 22:07:47 --> Router Class Initialized
INFO - 2018-07-16 22:07:47 --> Output Class Initialized
INFO - 2018-07-16 22:07:47 --> Security Class Initialized
DEBUG - 2018-07-16 22:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:07:47 --> Input Class Initialized
INFO - 2018-07-16 22:07:47 --> Language Class Initialized
INFO - 2018-07-16 22:07:47 --> Loader Class Initialized
INFO - 2018-07-16 22:07:47 --> Controller Class Initialized
INFO - 2018-07-16 22:07:47 --> Database Driver Class Initialized
INFO - 2018-07-16 22:07:47 --> Model Class Initialized
INFO - 2018-07-16 22:07:47 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:07:47 --> Model Class Initialized
INFO - 2018-07-16 22:07:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 22:07:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-16 22:07:47 --> Final output sent to browser
DEBUG - 2018-07-16 22:07:47 --> Total execution time: 0.0601
ERROR - 2018-07-16 22:07:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:07:49 --> Config Class Initialized
INFO - 2018-07-16 22:07:49 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:07:49 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:07:49 --> Utf8 Class Initialized
INFO - 2018-07-16 22:07:49 --> URI Class Initialized
INFO - 2018-07-16 22:07:49 --> Router Class Initialized
INFO - 2018-07-16 22:07:49 --> Output Class Initialized
INFO - 2018-07-16 22:07:49 --> Security Class Initialized
DEBUG - 2018-07-16 22:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:07:49 --> Input Class Initialized
INFO - 2018-07-16 22:07:49 --> Language Class Initialized
INFO - 2018-07-16 22:07:49 --> Loader Class Initialized
INFO - 2018-07-16 22:07:49 --> Controller Class Initialized
INFO - 2018-07-16 22:07:49 --> Database Driver Class Initialized
INFO - 2018-07-16 22:07:49 --> Model Class Initialized
INFO - 2018-07-16 22:07:49 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:07:49 --> Model Class Initialized
ERROR - 2018-07-16 22:07:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:07:49 --> Config Class Initialized
INFO - 2018-07-16 22:07:49 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:07:49 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:07:49 --> Utf8 Class Initialized
INFO - 2018-07-16 22:07:49 --> URI Class Initialized
INFO - 2018-07-16 22:07:49 --> Router Class Initialized
INFO - 2018-07-16 22:07:49 --> Output Class Initialized
INFO - 2018-07-16 22:07:49 --> Security Class Initialized
DEBUG - 2018-07-16 22:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:07:49 --> Input Class Initialized
INFO - 2018-07-16 22:07:49 --> Language Class Initialized
INFO - 2018-07-16 22:07:49 --> Loader Class Initialized
INFO - 2018-07-16 22:07:49 --> Controller Class Initialized
INFO - 2018-07-16 22:07:49 --> Database Driver Class Initialized
INFO - 2018-07-16 22:07:49 --> Model Class Initialized
INFO - 2018-07-16 22:07:49 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:07:49 --> Model Class Initialized
INFO - 2018-07-16 22:07:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 22:07:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-16 22:07:49 --> Final output sent to browser
DEBUG - 2018-07-16 22:07:49 --> Total execution time: 0.0598
ERROR - 2018-07-16 22:07:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:07:52 --> Config Class Initialized
INFO - 2018-07-16 22:07:52 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:07:52 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:07:52 --> Utf8 Class Initialized
INFO - 2018-07-16 22:07:52 --> URI Class Initialized
INFO - 2018-07-16 22:07:52 --> Router Class Initialized
INFO - 2018-07-16 22:07:52 --> Output Class Initialized
INFO - 2018-07-16 22:07:52 --> Security Class Initialized
DEBUG - 2018-07-16 22:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:07:52 --> Input Class Initialized
INFO - 2018-07-16 22:07:52 --> Language Class Initialized
INFO - 2018-07-16 22:07:52 --> Loader Class Initialized
INFO - 2018-07-16 22:07:52 --> Controller Class Initialized
INFO - 2018-07-16 22:07:52 --> Database Driver Class Initialized
INFO - 2018-07-16 22:07:52 --> Model Class Initialized
INFO - 2018-07-16 22:07:52 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:07:52 --> Model Class Initialized
ERROR - 2018-07-16 22:07:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:07:53 --> Config Class Initialized
INFO - 2018-07-16 22:07:53 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:07:53 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:07:53 --> Utf8 Class Initialized
INFO - 2018-07-16 22:07:53 --> URI Class Initialized
INFO - 2018-07-16 22:07:53 --> Router Class Initialized
INFO - 2018-07-16 22:07:53 --> Output Class Initialized
INFO - 2018-07-16 22:07:53 --> Security Class Initialized
DEBUG - 2018-07-16 22:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:07:53 --> Input Class Initialized
INFO - 2018-07-16 22:07:53 --> Language Class Initialized
INFO - 2018-07-16 22:07:53 --> Loader Class Initialized
INFO - 2018-07-16 22:07:53 --> Controller Class Initialized
INFO - 2018-07-16 22:07:53 --> Database Driver Class Initialized
INFO - 2018-07-16 22:07:53 --> Model Class Initialized
INFO - 2018-07-16 22:07:53 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:07:53 --> Model Class Initialized
INFO - 2018-07-16 22:07:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 22:07:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-16 22:07:53 --> Final output sent to browser
DEBUG - 2018-07-16 22:07:53 --> Total execution time: 0.0591
ERROR - 2018-07-16 22:07:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:07:58 --> Config Class Initialized
INFO - 2018-07-16 22:07:58 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:07:58 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:07:58 --> Utf8 Class Initialized
INFO - 2018-07-16 22:07:58 --> URI Class Initialized
INFO - 2018-07-16 22:07:58 --> Router Class Initialized
INFO - 2018-07-16 22:07:58 --> Output Class Initialized
INFO - 2018-07-16 22:07:58 --> Security Class Initialized
DEBUG - 2018-07-16 22:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:07:58 --> Input Class Initialized
INFO - 2018-07-16 22:07:58 --> Language Class Initialized
INFO - 2018-07-16 22:07:58 --> Loader Class Initialized
INFO - 2018-07-16 22:07:58 --> Controller Class Initialized
INFO - 2018-07-16 22:07:58 --> Database Driver Class Initialized
INFO - 2018-07-16 22:07:58 --> Model Class Initialized
INFO - 2018-07-16 22:07:58 --> Helper loaded: url_helper
INFO - 2018-07-16 22:07:58 --> Model Class Initialized
INFO - 2018-07-16 22:07:58 --> Final output sent to browser
DEBUG - 2018-07-16 22:07:58 --> Total execution time: 0.0519
ERROR - 2018-07-16 22:08:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:08:26 --> Config Class Initialized
INFO - 2018-07-16 22:08:26 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:08:26 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:08:26 --> Utf8 Class Initialized
INFO - 2018-07-16 22:08:26 --> URI Class Initialized
INFO - 2018-07-16 22:08:26 --> Router Class Initialized
INFO - 2018-07-16 22:08:26 --> Output Class Initialized
INFO - 2018-07-16 22:08:26 --> Security Class Initialized
DEBUG - 2018-07-16 22:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:08:26 --> Input Class Initialized
INFO - 2018-07-16 22:08:26 --> Language Class Initialized
INFO - 2018-07-16 22:08:26 --> Loader Class Initialized
INFO - 2018-07-16 22:08:26 --> Controller Class Initialized
INFO - 2018-07-16 22:08:26 --> Database Driver Class Initialized
INFO - 2018-07-16 22:08:26 --> Model Class Initialized
INFO - 2018-07-16 22:08:26 --> Helper loaded: url_helper
INFO - 2018-07-16 22:08:26 --> Model Class Initialized
INFO - 2018-07-16 22:08:26 --> Final output sent to browser
DEBUG - 2018-07-16 22:08:26 --> Total execution time: 0.1029
ERROR - 2018-07-16 22:08:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:08:35 --> Config Class Initialized
INFO - 2018-07-16 22:08:35 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:08:35 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:08:35 --> Utf8 Class Initialized
INFO - 2018-07-16 22:08:35 --> URI Class Initialized
INFO - 2018-07-16 22:08:35 --> Router Class Initialized
INFO - 2018-07-16 22:08:35 --> Output Class Initialized
INFO - 2018-07-16 22:08:35 --> Security Class Initialized
DEBUG - 2018-07-16 22:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:08:35 --> Input Class Initialized
INFO - 2018-07-16 22:08:35 --> Language Class Initialized
INFO - 2018-07-16 22:08:35 --> Loader Class Initialized
INFO - 2018-07-16 22:08:35 --> Controller Class Initialized
INFO - 2018-07-16 22:08:35 --> Database Driver Class Initialized
INFO - 2018-07-16 22:08:35 --> Model Class Initialized
INFO - 2018-07-16 22:08:35 --> Helper loaded: url_helper
INFO - 2018-07-16 22:08:35 --> Model Class Initialized
INFO - 2018-07-16 22:08:35 --> Final output sent to browser
DEBUG - 2018-07-16 22:08:35 --> Total execution time: 0.0456
ERROR - 2018-07-16 22:09:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:09:06 --> Config Class Initialized
INFO - 2018-07-16 22:09:06 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:09:06 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:09:06 --> Utf8 Class Initialized
INFO - 2018-07-16 22:09:06 --> URI Class Initialized
INFO - 2018-07-16 22:09:06 --> Router Class Initialized
INFO - 2018-07-16 22:09:06 --> Output Class Initialized
INFO - 2018-07-16 22:09:06 --> Security Class Initialized
DEBUG - 2018-07-16 22:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:09:06 --> Input Class Initialized
INFO - 2018-07-16 22:09:06 --> Language Class Initialized
INFO - 2018-07-16 22:09:06 --> Loader Class Initialized
INFO - 2018-07-16 22:09:06 --> Controller Class Initialized
INFO - 2018-07-16 22:09:06 --> Database Driver Class Initialized
INFO - 2018-07-16 22:09:06 --> Model Class Initialized
INFO - 2018-07-16 22:09:06 --> Helper loaded: url_helper
INFO - 2018-07-16 22:09:06 --> Model Class Initialized
INFO - 2018-07-16 22:09:06 --> Final output sent to browser
DEBUG - 2018-07-16 22:09:06 --> Total execution time: 0.0512
ERROR - 2018-07-16 22:10:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:10:24 --> Config Class Initialized
INFO - 2018-07-16 22:10:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:10:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:10:24 --> Utf8 Class Initialized
INFO - 2018-07-16 22:10:24 --> URI Class Initialized
INFO - 2018-07-16 22:10:24 --> Router Class Initialized
INFO - 2018-07-16 22:10:24 --> Output Class Initialized
INFO - 2018-07-16 22:10:24 --> Security Class Initialized
DEBUG - 2018-07-16 22:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:10:24 --> Input Class Initialized
INFO - 2018-07-16 22:10:24 --> Language Class Initialized
INFO - 2018-07-16 22:10:24 --> Loader Class Initialized
INFO - 2018-07-16 22:10:24 --> Controller Class Initialized
INFO - 2018-07-16 22:10:24 --> Database Driver Class Initialized
INFO - 2018-07-16 22:10:24 --> Model Class Initialized
INFO - 2018-07-16 22:10:24 --> Helper loaded: url_helper
INFO - 2018-07-16 22:10:24 --> Model Class Initialized
INFO - 2018-07-16 22:10:24 --> Final output sent to browser
DEBUG - 2018-07-16 22:10:24 --> Total execution time: 0.1053
ERROR - 2018-07-16 22:10:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:10:27 --> Config Class Initialized
INFO - 2018-07-16 22:10:27 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:10:27 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:10:27 --> Utf8 Class Initialized
INFO - 2018-07-16 22:10:27 --> URI Class Initialized
INFO - 2018-07-16 22:10:27 --> Router Class Initialized
INFO - 2018-07-16 22:10:27 --> Output Class Initialized
INFO - 2018-07-16 22:10:27 --> Security Class Initialized
DEBUG - 2018-07-16 22:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:10:27 --> Input Class Initialized
INFO - 2018-07-16 22:10:27 --> Language Class Initialized
INFO - 2018-07-16 22:10:27 --> Loader Class Initialized
INFO - 2018-07-16 22:10:27 --> Controller Class Initialized
INFO - 2018-07-16 22:10:27 --> Database Driver Class Initialized
INFO - 2018-07-16 22:10:27 --> Model Class Initialized
INFO - 2018-07-16 22:10:27 --> Helper loaded: url_helper
INFO - 2018-07-16 22:10:27 --> Model Class Initialized
INFO - 2018-07-16 22:10:27 --> Final output sent to browser
DEBUG - 2018-07-16 22:10:27 --> Total execution time: 0.0518
ERROR - 2018-07-16 22:13:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:13:51 --> Config Class Initialized
INFO - 2018-07-16 22:13:51 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:13:51 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:13:51 --> Utf8 Class Initialized
INFO - 2018-07-16 22:13:51 --> URI Class Initialized
INFO - 2018-07-16 22:13:51 --> Router Class Initialized
INFO - 2018-07-16 22:13:51 --> Output Class Initialized
INFO - 2018-07-16 22:13:51 --> Security Class Initialized
DEBUG - 2018-07-16 22:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:13:51 --> Input Class Initialized
INFO - 2018-07-16 22:13:51 --> Language Class Initialized
INFO - 2018-07-16 22:13:51 --> Loader Class Initialized
INFO - 2018-07-16 22:13:51 --> Controller Class Initialized
INFO - 2018-07-16 22:13:51 --> Database Driver Class Initialized
INFO - 2018-07-16 22:13:51 --> Model Class Initialized
INFO - 2018-07-16 22:13:51 --> Helper loaded: url_helper
INFO - 2018-07-16 22:13:51 --> Model Class Initialized
INFO - 2018-07-16 22:13:51 --> Final output sent to browser
DEBUG - 2018-07-16 22:13:51 --> Total execution time: 0.0453
ERROR - 2018-07-16 22:13:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:13:52 --> Config Class Initialized
INFO - 2018-07-16 22:13:52 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:13:52 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:13:52 --> Utf8 Class Initialized
INFO - 2018-07-16 22:13:52 --> URI Class Initialized
INFO - 2018-07-16 22:13:52 --> Router Class Initialized
INFO - 2018-07-16 22:13:52 --> Output Class Initialized
INFO - 2018-07-16 22:13:52 --> Security Class Initialized
DEBUG - 2018-07-16 22:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:13:52 --> Input Class Initialized
INFO - 2018-07-16 22:13:52 --> Language Class Initialized
INFO - 2018-07-16 22:13:52 --> Loader Class Initialized
INFO - 2018-07-16 22:13:52 --> Controller Class Initialized
INFO - 2018-07-16 22:13:52 --> Database Driver Class Initialized
INFO - 2018-07-16 22:13:52 --> Model Class Initialized
INFO - 2018-07-16 22:13:52 --> Helper loaded: url_helper
INFO - 2018-07-16 22:13:52 --> Model Class Initialized
INFO - 2018-07-16 22:13:52 --> Final output sent to browser
DEBUG - 2018-07-16 22:13:52 --> Total execution time: 0.0448
ERROR - 2018-07-16 22:13:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:13:52 --> Config Class Initialized
INFO - 2018-07-16 22:13:52 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:13:52 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:13:52 --> Utf8 Class Initialized
INFO - 2018-07-16 22:13:52 --> URI Class Initialized
INFO - 2018-07-16 22:13:52 --> Router Class Initialized
INFO - 2018-07-16 22:13:52 --> Output Class Initialized
INFO - 2018-07-16 22:13:52 --> Security Class Initialized
DEBUG - 2018-07-16 22:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:13:52 --> Input Class Initialized
INFO - 2018-07-16 22:13:52 --> Language Class Initialized
INFO - 2018-07-16 22:13:52 --> Loader Class Initialized
INFO - 2018-07-16 22:13:52 --> Controller Class Initialized
INFO - 2018-07-16 22:13:52 --> Database Driver Class Initialized
INFO - 2018-07-16 22:13:52 --> Model Class Initialized
INFO - 2018-07-16 22:13:52 --> Helper loaded: url_helper
INFO - 2018-07-16 22:13:52 --> Model Class Initialized
INFO - 2018-07-16 22:13:52 --> Final output sent to browser
DEBUG - 2018-07-16 22:13:52 --> Total execution time: 0.0443
ERROR - 2018-07-16 22:15:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:15:01 --> Config Class Initialized
INFO - 2018-07-16 22:15:01 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:15:01 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:15:01 --> Utf8 Class Initialized
INFO - 2018-07-16 22:15:01 --> URI Class Initialized
INFO - 2018-07-16 22:15:01 --> Router Class Initialized
INFO - 2018-07-16 22:15:01 --> Output Class Initialized
INFO - 2018-07-16 22:15:01 --> Security Class Initialized
DEBUG - 2018-07-16 22:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:15:01 --> Input Class Initialized
INFO - 2018-07-16 22:15:01 --> Language Class Initialized
INFO - 2018-07-16 22:15:01 --> Loader Class Initialized
INFO - 2018-07-16 22:15:01 --> Controller Class Initialized
INFO - 2018-07-16 22:15:01 --> Database Driver Class Initialized
INFO - 2018-07-16 22:15:01 --> Model Class Initialized
INFO - 2018-07-16 22:15:01 --> Helper loaded: url_helper
INFO - 2018-07-16 22:15:01 --> Model Class Initialized
INFO - 2018-07-16 22:15:01 --> Final output sent to browser
DEBUG - 2018-07-16 22:15:01 --> Total execution time: 0.0452
ERROR - 2018-07-16 22:15:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:15:03 --> Config Class Initialized
INFO - 2018-07-16 22:15:03 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:15:03 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:15:03 --> Utf8 Class Initialized
INFO - 2018-07-16 22:15:03 --> URI Class Initialized
INFO - 2018-07-16 22:15:03 --> Router Class Initialized
INFO - 2018-07-16 22:15:03 --> Output Class Initialized
INFO - 2018-07-16 22:15:03 --> Security Class Initialized
DEBUG - 2018-07-16 22:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:15:03 --> Input Class Initialized
INFO - 2018-07-16 22:15:03 --> Language Class Initialized
INFO - 2018-07-16 22:15:03 --> Loader Class Initialized
INFO - 2018-07-16 22:15:03 --> Controller Class Initialized
INFO - 2018-07-16 22:15:03 --> Database Driver Class Initialized
INFO - 2018-07-16 22:15:03 --> Model Class Initialized
INFO - 2018-07-16 22:15:03 --> Helper loaded: url_helper
INFO - 2018-07-16 22:15:03 --> Model Class Initialized
INFO - 2018-07-16 22:15:03 --> Final output sent to browser
DEBUG - 2018-07-16 22:15:03 --> Total execution time: 0.0391
ERROR - 2018-07-16 22:15:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:15:03 --> Config Class Initialized
INFO - 2018-07-16 22:15:03 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:15:03 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:15:03 --> Utf8 Class Initialized
INFO - 2018-07-16 22:15:03 --> URI Class Initialized
INFO - 2018-07-16 22:15:03 --> Router Class Initialized
INFO - 2018-07-16 22:15:03 --> Output Class Initialized
INFO - 2018-07-16 22:15:03 --> Security Class Initialized
DEBUG - 2018-07-16 22:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:15:03 --> Input Class Initialized
INFO - 2018-07-16 22:15:03 --> Language Class Initialized
INFO - 2018-07-16 22:15:03 --> Loader Class Initialized
INFO - 2018-07-16 22:15:03 --> Controller Class Initialized
INFO - 2018-07-16 22:15:03 --> Database Driver Class Initialized
INFO - 2018-07-16 22:15:03 --> Model Class Initialized
INFO - 2018-07-16 22:15:03 --> Helper loaded: url_helper
INFO - 2018-07-16 22:15:03 --> Model Class Initialized
INFO - 2018-07-16 22:15:03 --> Final output sent to browser
DEBUG - 2018-07-16 22:15:03 --> Total execution time: 0.0448
ERROR - 2018-07-16 22:15:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:15:03 --> Config Class Initialized
INFO - 2018-07-16 22:15:03 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:15:03 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:15:03 --> Utf8 Class Initialized
INFO - 2018-07-16 22:15:03 --> URI Class Initialized
INFO - 2018-07-16 22:15:03 --> Router Class Initialized
INFO - 2018-07-16 22:15:03 --> Output Class Initialized
INFO - 2018-07-16 22:15:03 --> Security Class Initialized
DEBUG - 2018-07-16 22:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:15:03 --> Input Class Initialized
INFO - 2018-07-16 22:15:03 --> Language Class Initialized
INFO - 2018-07-16 22:15:03 --> Loader Class Initialized
INFO - 2018-07-16 22:15:03 --> Controller Class Initialized
INFO - 2018-07-16 22:15:03 --> Database Driver Class Initialized
INFO - 2018-07-16 22:15:03 --> Model Class Initialized
INFO - 2018-07-16 22:15:03 --> Helper loaded: url_helper
INFO - 2018-07-16 22:15:03 --> Model Class Initialized
INFO - 2018-07-16 22:15:03 --> Final output sent to browser
DEBUG - 2018-07-16 22:15:03 --> Total execution time: 0.0407
ERROR - 2018-07-16 22:15:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:15:26 --> Config Class Initialized
INFO - 2018-07-16 22:15:26 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:15:26 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:15:26 --> Utf8 Class Initialized
INFO - 2018-07-16 22:15:26 --> URI Class Initialized
INFO - 2018-07-16 22:15:26 --> Router Class Initialized
INFO - 2018-07-16 22:15:26 --> Output Class Initialized
INFO - 2018-07-16 22:15:26 --> Security Class Initialized
DEBUG - 2018-07-16 22:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:15:26 --> Input Class Initialized
INFO - 2018-07-16 22:15:26 --> Language Class Initialized
INFO - 2018-07-16 22:15:26 --> Loader Class Initialized
INFO - 2018-07-16 22:15:26 --> Controller Class Initialized
INFO - 2018-07-16 22:15:26 --> Database Driver Class Initialized
INFO - 2018-07-16 22:15:26 --> Model Class Initialized
INFO - 2018-07-16 22:15:26 --> Helper loaded: url_helper
INFO - 2018-07-16 22:15:26 --> Model Class Initialized
INFO - 2018-07-16 22:15:26 --> Final output sent to browser
DEBUG - 2018-07-16 22:15:26 --> Total execution time: 0.0578
ERROR - 2018-07-16 22:17:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:17:14 --> Config Class Initialized
INFO - 2018-07-16 22:17:14 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:17:14 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:17:14 --> Utf8 Class Initialized
INFO - 2018-07-16 22:17:14 --> URI Class Initialized
INFO - 2018-07-16 22:17:14 --> Router Class Initialized
INFO - 2018-07-16 22:17:14 --> Output Class Initialized
INFO - 2018-07-16 22:17:14 --> Security Class Initialized
DEBUG - 2018-07-16 22:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:17:14 --> Input Class Initialized
INFO - 2018-07-16 22:17:14 --> Language Class Initialized
INFO - 2018-07-16 22:17:14 --> Loader Class Initialized
INFO - 2018-07-16 22:17:14 --> Controller Class Initialized
INFO - 2018-07-16 22:17:14 --> Database Driver Class Initialized
INFO - 2018-07-16 22:17:14 --> Model Class Initialized
INFO - 2018-07-16 22:17:14 --> Helper loaded: url_helper
INFO - 2018-07-16 22:17:14 --> Model Class Initialized
INFO - 2018-07-16 22:17:14 --> Final output sent to browser
DEBUG - 2018-07-16 22:17:14 --> Total execution time: 0.0382
ERROR - 2018-07-16 22:17:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:17:15 --> Config Class Initialized
INFO - 2018-07-16 22:17:15 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:17:15 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:17:15 --> Utf8 Class Initialized
INFO - 2018-07-16 22:17:15 --> URI Class Initialized
INFO - 2018-07-16 22:17:15 --> Router Class Initialized
INFO - 2018-07-16 22:17:15 --> Output Class Initialized
INFO - 2018-07-16 22:17:15 --> Security Class Initialized
DEBUG - 2018-07-16 22:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:17:15 --> Input Class Initialized
INFO - 2018-07-16 22:17:15 --> Language Class Initialized
INFO - 2018-07-16 22:17:15 --> Loader Class Initialized
INFO - 2018-07-16 22:17:15 --> Controller Class Initialized
INFO - 2018-07-16 22:17:15 --> Database Driver Class Initialized
INFO - 2018-07-16 22:17:15 --> Model Class Initialized
INFO - 2018-07-16 22:17:15 --> Helper loaded: url_helper
INFO - 2018-07-16 22:17:15 --> Model Class Initialized
INFO - 2018-07-16 22:17:15 --> Final output sent to browser
DEBUG - 2018-07-16 22:17:15 --> Total execution time: 0.0446
ERROR - 2018-07-16 22:17:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:17:16 --> Config Class Initialized
INFO - 2018-07-16 22:17:16 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:17:16 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:17:16 --> Utf8 Class Initialized
INFO - 2018-07-16 22:17:16 --> URI Class Initialized
INFO - 2018-07-16 22:17:16 --> Router Class Initialized
INFO - 2018-07-16 22:17:16 --> Output Class Initialized
INFO - 2018-07-16 22:17:16 --> Security Class Initialized
DEBUG - 2018-07-16 22:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:17:16 --> Input Class Initialized
INFO - 2018-07-16 22:17:16 --> Language Class Initialized
INFO - 2018-07-16 22:17:16 --> Loader Class Initialized
INFO - 2018-07-16 22:17:16 --> Controller Class Initialized
INFO - 2018-07-16 22:17:16 --> Database Driver Class Initialized
INFO - 2018-07-16 22:17:16 --> Model Class Initialized
INFO - 2018-07-16 22:17:16 --> Helper loaded: url_helper
INFO - 2018-07-16 22:17:16 --> Model Class Initialized
INFO - 2018-07-16 22:17:16 --> Final output sent to browser
DEBUG - 2018-07-16 22:17:16 --> Total execution time: 0.0479
ERROR - 2018-07-16 22:17:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:17:16 --> Config Class Initialized
INFO - 2018-07-16 22:17:16 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:17:16 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:17:16 --> Utf8 Class Initialized
INFO - 2018-07-16 22:17:16 --> URI Class Initialized
INFO - 2018-07-16 22:17:16 --> Router Class Initialized
INFO - 2018-07-16 22:17:16 --> Output Class Initialized
INFO - 2018-07-16 22:17:16 --> Security Class Initialized
DEBUG - 2018-07-16 22:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:17:16 --> Input Class Initialized
INFO - 2018-07-16 22:17:16 --> Language Class Initialized
INFO - 2018-07-16 22:17:16 --> Loader Class Initialized
INFO - 2018-07-16 22:17:16 --> Controller Class Initialized
INFO - 2018-07-16 22:17:16 --> Database Driver Class Initialized
INFO - 2018-07-16 22:17:16 --> Model Class Initialized
INFO - 2018-07-16 22:17:16 --> Helper loaded: url_helper
INFO - 2018-07-16 22:17:16 --> Model Class Initialized
INFO - 2018-07-16 22:17:16 --> Final output sent to browser
DEBUG - 2018-07-16 22:17:16 --> Total execution time: 0.0427
ERROR - 2018-07-16 22:17:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:17:20 --> Config Class Initialized
INFO - 2018-07-16 22:17:20 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:17:20 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:17:20 --> Utf8 Class Initialized
INFO - 2018-07-16 22:17:20 --> URI Class Initialized
INFO - 2018-07-16 22:17:20 --> Router Class Initialized
INFO - 2018-07-16 22:17:20 --> Output Class Initialized
INFO - 2018-07-16 22:17:20 --> Security Class Initialized
DEBUG - 2018-07-16 22:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:17:20 --> Input Class Initialized
INFO - 2018-07-16 22:17:20 --> Language Class Initialized
INFO - 2018-07-16 22:17:20 --> Loader Class Initialized
INFO - 2018-07-16 22:17:20 --> Controller Class Initialized
INFO - 2018-07-16 22:17:20 --> Database Driver Class Initialized
INFO - 2018-07-16 22:17:20 --> Model Class Initialized
INFO - 2018-07-16 22:17:20 --> Helper loaded: url_helper
INFO - 2018-07-16 22:17:20 --> Model Class Initialized
INFO - 2018-07-16 22:17:20 --> Final output sent to browser
DEBUG - 2018-07-16 22:17:20 --> Total execution time: 0.0563
ERROR - 2018-07-16 22:17:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:17:33 --> Config Class Initialized
INFO - 2018-07-16 22:17:33 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:17:33 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:17:33 --> Utf8 Class Initialized
INFO - 2018-07-16 22:17:33 --> URI Class Initialized
INFO - 2018-07-16 22:17:33 --> Router Class Initialized
INFO - 2018-07-16 22:17:33 --> Output Class Initialized
INFO - 2018-07-16 22:17:33 --> Security Class Initialized
DEBUG - 2018-07-16 22:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:17:33 --> Input Class Initialized
INFO - 2018-07-16 22:17:33 --> Language Class Initialized
INFO - 2018-07-16 22:17:33 --> Loader Class Initialized
INFO - 2018-07-16 22:17:33 --> Controller Class Initialized
INFO - 2018-07-16 22:17:34 --> Database Driver Class Initialized
INFO - 2018-07-16 22:17:34 --> Model Class Initialized
INFO - 2018-07-16 22:17:34 --> Helper loaded: url_helper
INFO - 2018-07-16 22:17:34 --> Model Class Initialized
INFO - 2018-07-16 22:17:34 --> Final output sent to browser
DEBUG - 2018-07-16 22:17:34 --> Total execution time: 0.0614
ERROR - 2018-07-16 22:18:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:18:22 --> Config Class Initialized
INFO - 2018-07-16 22:18:22 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:18:22 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:18:22 --> Utf8 Class Initialized
INFO - 2018-07-16 22:18:22 --> URI Class Initialized
INFO - 2018-07-16 22:18:22 --> Router Class Initialized
INFO - 2018-07-16 22:18:22 --> Output Class Initialized
INFO - 2018-07-16 22:18:22 --> Security Class Initialized
DEBUG - 2018-07-16 22:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:18:22 --> Input Class Initialized
INFO - 2018-07-16 22:18:22 --> Language Class Initialized
INFO - 2018-07-16 22:18:22 --> Loader Class Initialized
INFO - 2018-07-16 22:18:22 --> Controller Class Initialized
INFO - 2018-07-16 22:18:22 --> Database Driver Class Initialized
INFO - 2018-07-16 22:18:22 --> Model Class Initialized
INFO - 2018-07-16 22:18:22 --> Helper loaded: url_helper
INFO - 2018-07-16 22:18:22 --> Model Class Initialized
INFO - 2018-07-16 22:18:22 --> Final output sent to browser
DEBUG - 2018-07-16 22:18:22 --> Total execution time: 0.0666
ERROR - 2018-07-16 22:18:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:18:23 --> Config Class Initialized
INFO - 2018-07-16 22:18:23 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:18:23 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:18:23 --> Utf8 Class Initialized
INFO - 2018-07-16 22:18:23 --> URI Class Initialized
INFO - 2018-07-16 22:18:23 --> Router Class Initialized
INFO - 2018-07-16 22:18:23 --> Output Class Initialized
INFO - 2018-07-16 22:18:23 --> Security Class Initialized
DEBUG - 2018-07-16 22:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:18:23 --> Input Class Initialized
INFO - 2018-07-16 22:18:23 --> Language Class Initialized
INFO - 2018-07-16 22:18:23 --> Loader Class Initialized
INFO - 2018-07-16 22:18:23 --> Controller Class Initialized
INFO - 2018-07-16 22:18:23 --> Database Driver Class Initialized
INFO - 2018-07-16 22:18:23 --> Model Class Initialized
INFO - 2018-07-16 22:18:23 --> Helper loaded: url_helper
INFO - 2018-07-16 22:18:23 --> Model Class Initialized
INFO - 2018-07-16 22:18:23 --> Final output sent to browser
DEBUG - 2018-07-16 22:18:23 --> Total execution time: 0.0458
ERROR - 2018-07-16 22:18:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:18:24 --> Config Class Initialized
INFO - 2018-07-16 22:18:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:18:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:18:24 --> Utf8 Class Initialized
INFO - 2018-07-16 22:18:24 --> URI Class Initialized
INFO - 2018-07-16 22:18:24 --> Router Class Initialized
INFO - 2018-07-16 22:18:24 --> Output Class Initialized
INFO - 2018-07-16 22:18:24 --> Security Class Initialized
DEBUG - 2018-07-16 22:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:18:24 --> Input Class Initialized
INFO - 2018-07-16 22:18:24 --> Language Class Initialized
INFO - 2018-07-16 22:18:24 --> Loader Class Initialized
INFO - 2018-07-16 22:18:24 --> Controller Class Initialized
INFO - 2018-07-16 22:18:24 --> Database Driver Class Initialized
INFO - 2018-07-16 22:18:24 --> Model Class Initialized
INFO - 2018-07-16 22:18:24 --> Helper loaded: url_helper
INFO - 2018-07-16 22:18:24 --> Model Class Initialized
INFO - 2018-07-16 22:18:24 --> Final output sent to browser
DEBUG - 2018-07-16 22:18:24 --> Total execution time: 0.0490
ERROR - 2018-07-16 22:18:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:18:24 --> Config Class Initialized
INFO - 2018-07-16 22:18:24 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:18:24 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:18:24 --> Utf8 Class Initialized
INFO - 2018-07-16 22:18:24 --> URI Class Initialized
INFO - 2018-07-16 22:18:24 --> Router Class Initialized
INFO - 2018-07-16 22:18:24 --> Output Class Initialized
INFO - 2018-07-16 22:18:24 --> Security Class Initialized
DEBUG - 2018-07-16 22:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:18:24 --> Input Class Initialized
INFO - 2018-07-16 22:18:24 --> Language Class Initialized
INFO - 2018-07-16 22:18:24 --> Loader Class Initialized
INFO - 2018-07-16 22:18:24 --> Controller Class Initialized
INFO - 2018-07-16 22:18:24 --> Database Driver Class Initialized
INFO - 2018-07-16 22:18:24 --> Model Class Initialized
INFO - 2018-07-16 22:18:24 --> Helper loaded: url_helper
INFO - 2018-07-16 22:18:24 --> Model Class Initialized
INFO - 2018-07-16 22:18:24 --> Final output sent to browser
DEBUG - 2018-07-16 22:18:24 --> Total execution time: 0.0500
ERROR - 2018-07-16 22:19:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:19:51 --> Config Class Initialized
INFO - 2018-07-16 22:19:51 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:19:51 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:19:51 --> Utf8 Class Initialized
INFO - 2018-07-16 22:19:51 --> URI Class Initialized
INFO - 2018-07-16 22:19:51 --> Router Class Initialized
INFO - 2018-07-16 22:19:51 --> Output Class Initialized
INFO - 2018-07-16 22:19:51 --> Security Class Initialized
DEBUG - 2018-07-16 22:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:19:51 --> Input Class Initialized
INFO - 2018-07-16 22:19:51 --> Language Class Initialized
INFO - 2018-07-16 22:19:51 --> Loader Class Initialized
INFO - 2018-07-16 22:19:51 --> Controller Class Initialized
INFO - 2018-07-16 22:19:51 --> Database Driver Class Initialized
INFO - 2018-07-16 22:19:51 --> Model Class Initialized
INFO - 2018-07-16 22:19:51 --> Helper loaded: url_helper
INFO - 2018-07-16 22:19:51 --> Model Class Initialized
INFO - 2018-07-16 22:19:51 --> Final output sent to browser
DEBUG - 2018-07-16 22:19:51 --> Total execution time: 0.1210
ERROR - 2018-07-16 22:19:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:19:54 --> Config Class Initialized
INFO - 2018-07-16 22:19:54 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:19:54 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:19:54 --> Utf8 Class Initialized
INFO - 2018-07-16 22:19:54 --> URI Class Initialized
INFO - 2018-07-16 22:19:54 --> Router Class Initialized
INFO - 2018-07-16 22:19:54 --> Output Class Initialized
INFO - 2018-07-16 22:19:54 --> Security Class Initialized
DEBUG - 2018-07-16 22:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:19:54 --> Input Class Initialized
INFO - 2018-07-16 22:19:54 --> Language Class Initialized
INFO - 2018-07-16 22:19:54 --> Loader Class Initialized
INFO - 2018-07-16 22:19:54 --> Controller Class Initialized
INFO - 2018-07-16 22:19:54 --> Database Driver Class Initialized
INFO - 2018-07-16 22:19:54 --> Model Class Initialized
INFO - 2018-07-16 22:19:54 --> Helper loaded: url_helper
INFO - 2018-07-16 22:19:54 --> Model Class Initialized
INFO - 2018-07-16 22:19:54 --> Final output sent to browser
DEBUG - 2018-07-16 22:19:54 --> Total execution time: 0.0495
ERROR - 2018-07-16 22:19:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:19:54 --> Config Class Initialized
INFO - 2018-07-16 22:19:54 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:19:54 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:19:54 --> Utf8 Class Initialized
INFO - 2018-07-16 22:19:54 --> URI Class Initialized
INFO - 2018-07-16 22:19:54 --> Router Class Initialized
INFO - 2018-07-16 22:19:54 --> Output Class Initialized
INFO - 2018-07-16 22:19:54 --> Security Class Initialized
DEBUG - 2018-07-16 22:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:19:54 --> Input Class Initialized
INFO - 2018-07-16 22:19:54 --> Language Class Initialized
INFO - 2018-07-16 22:19:54 --> Loader Class Initialized
INFO - 2018-07-16 22:19:54 --> Controller Class Initialized
INFO - 2018-07-16 22:19:54 --> Database Driver Class Initialized
INFO - 2018-07-16 22:19:54 --> Model Class Initialized
INFO - 2018-07-16 22:19:54 --> Helper loaded: url_helper
INFO - 2018-07-16 22:19:54 --> Model Class Initialized
INFO - 2018-07-16 22:19:54 --> Final output sent to browser
DEBUG - 2018-07-16 22:19:54 --> Total execution time: 0.0506
ERROR - 2018-07-16 22:20:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:20:44 --> Config Class Initialized
INFO - 2018-07-16 22:20:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:20:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:20:44 --> Utf8 Class Initialized
INFO - 2018-07-16 22:20:44 --> URI Class Initialized
INFO - 2018-07-16 22:20:44 --> Router Class Initialized
INFO - 2018-07-16 22:20:44 --> Output Class Initialized
INFO - 2018-07-16 22:20:44 --> Security Class Initialized
DEBUG - 2018-07-16 22:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:20:44 --> Input Class Initialized
INFO - 2018-07-16 22:20:44 --> Language Class Initialized
INFO - 2018-07-16 22:20:44 --> Loader Class Initialized
INFO - 2018-07-16 22:20:44 --> Controller Class Initialized
INFO - 2018-07-16 22:20:44 --> Database Driver Class Initialized
INFO - 2018-07-16 22:20:44 --> Model Class Initialized
INFO - 2018-07-16 22:20:44 --> Helper loaded: url_helper
INFO - 2018-07-16 22:20:44 --> Model Class Initialized
INFO - 2018-07-16 22:20:44 --> Final output sent to browser
DEBUG - 2018-07-16 22:20:44 --> Total execution time: 0.0558
ERROR - 2018-07-16 22:24:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:24:32 --> Config Class Initialized
INFO - 2018-07-16 22:24:32 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:24:32 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:24:32 --> Utf8 Class Initialized
INFO - 2018-07-16 22:24:32 --> URI Class Initialized
INFO - 2018-07-16 22:24:32 --> Router Class Initialized
INFO - 2018-07-16 22:24:32 --> Output Class Initialized
INFO - 2018-07-16 22:24:32 --> Security Class Initialized
DEBUG - 2018-07-16 22:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:24:32 --> Input Class Initialized
INFO - 2018-07-16 22:24:32 --> Language Class Initialized
INFO - 2018-07-16 22:24:32 --> Loader Class Initialized
INFO - 2018-07-16 22:24:32 --> Controller Class Initialized
INFO - 2018-07-16 22:24:32 --> Database Driver Class Initialized
INFO - 2018-07-16 22:24:32 --> Model Class Initialized
INFO - 2018-07-16 22:24:32 --> Helper loaded: url_helper
INFO - 2018-07-16 22:24:32 --> Model Class Initialized
INFO - 2018-07-16 22:24:32 --> Final output sent to browser
DEBUG - 2018-07-16 22:24:32 --> Total execution time: 0.0463
ERROR - 2018-07-16 22:24:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:24:34 --> Config Class Initialized
INFO - 2018-07-16 22:24:34 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:24:34 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:24:34 --> Utf8 Class Initialized
INFO - 2018-07-16 22:24:34 --> URI Class Initialized
INFO - 2018-07-16 22:24:34 --> Router Class Initialized
INFO - 2018-07-16 22:24:34 --> Output Class Initialized
INFO - 2018-07-16 22:24:34 --> Security Class Initialized
DEBUG - 2018-07-16 22:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:24:34 --> Input Class Initialized
INFO - 2018-07-16 22:24:34 --> Language Class Initialized
INFO - 2018-07-16 22:24:34 --> Loader Class Initialized
INFO - 2018-07-16 22:24:34 --> Controller Class Initialized
INFO - 2018-07-16 22:24:34 --> Database Driver Class Initialized
INFO - 2018-07-16 22:24:34 --> Model Class Initialized
INFO - 2018-07-16 22:24:34 --> Helper loaded: url_helper
INFO - 2018-07-16 22:24:34 --> Model Class Initialized
INFO - 2018-07-16 22:24:34 --> Final output sent to browser
DEBUG - 2018-07-16 22:24:34 --> Total execution time: 0.0486
ERROR - 2018-07-16 22:24:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:24:34 --> Config Class Initialized
INFO - 2018-07-16 22:24:34 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:24:34 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:24:34 --> Utf8 Class Initialized
INFO - 2018-07-16 22:24:34 --> URI Class Initialized
INFO - 2018-07-16 22:24:34 --> Router Class Initialized
INFO - 2018-07-16 22:24:34 --> Output Class Initialized
INFO - 2018-07-16 22:24:34 --> Security Class Initialized
DEBUG - 2018-07-16 22:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:24:34 --> Input Class Initialized
INFO - 2018-07-16 22:24:34 --> Language Class Initialized
INFO - 2018-07-16 22:24:34 --> Loader Class Initialized
INFO - 2018-07-16 22:24:34 --> Controller Class Initialized
INFO - 2018-07-16 22:24:34 --> Database Driver Class Initialized
INFO - 2018-07-16 22:24:34 --> Model Class Initialized
INFO - 2018-07-16 22:24:34 --> Helper loaded: url_helper
INFO - 2018-07-16 22:24:34 --> Model Class Initialized
INFO - 2018-07-16 22:24:34 --> Final output sent to browser
DEBUG - 2018-07-16 22:24:34 --> Total execution time: 0.0551
ERROR - 2018-07-16 22:24:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:24:34 --> Config Class Initialized
INFO - 2018-07-16 22:24:34 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:24:34 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:24:34 --> Utf8 Class Initialized
INFO - 2018-07-16 22:24:34 --> URI Class Initialized
INFO - 2018-07-16 22:24:34 --> Router Class Initialized
INFO - 2018-07-16 22:24:34 --> Output Class Initialized
INFO - 2018-07-16 22:24:34 --> Security Class Initialized
DEBUG - 2018-07-16 22:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:24:34 --> Input Class Initialized
INFO - 2018-07-16 22:24:34 --> Language Class Initialized
INFO - 2018-07-16 22:24:34 --> Loader Class Initialized
INFO - 2018-07-16 22:24:34 --> Controller Class Initialized
INFO - 2018-07-16 22:24:34 --> Database Driver Class Initialized
INFO - 2018-07-16 22:24:34 --> Model Class Initialized
INFO - 2018-07-16 22:24:34 --> Helper loaded: url_helper
INFO - 2018-07-16 22:24:34 --> Model Class Initialized
INFO - 2018-07-16 22:24:34 --> Final output sent to browser
DEBUG - 2018-07-16 22:24:34 --> Total execution time: 0.0537
ERROR - 2018-07-16 22:24:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:24:44 --> Config Class Initialized
INFO - 2018-07-16 22:24:44 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:24:44 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:24:44 --> Utf8 Class Initialized
INFO - 2018-07-16 22:24:44 --> URI Class Initialized
INFO - 2018-07-16 22:24:44 --> Router Class Initialized
INFO - 2018-07-16 22:24:44 --> Output Class Initialized
INFO - 2018-07-16 22:24:44 --> Security Class Initialized
DEBUG - 2018-07-16 22:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:24:44 --> Input Class Initialized
INFO - 2018-07-16 22:24:44 --> Language Class Initialized
INFO - 2018-07-16 22:24:44 --> Loader Class Initialized
INFO - 2018-07-16 22:24:44 --> Controller Class Initialized
INFO - 2018-07-16 22:24:44 --> Database Driver Class Initialized
INFO - 2018-07-16 22:24:44 --> Model Class Initialized
INFO - 2018-07-16 22:24:44 --> Helper loaded: url_helper
INFO - 2018-07-16 22:24:44 --> Model Class Initialized
INFO - 2018-07-16 22:24:44 --> Final output sent to browser
DEBUG - 2018-07-16 22:24:44 --> Total execution time: 0.0955
ERROR - 2018-07-16 22:24:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:24:49 --> Config Class Initialized
INFO - 2018-07-16 22:24:49 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:24:49 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:24:49 --> Utf8 Class Initialized
INFO - 2018-07-16 22:24:49 --> URI Class Initialized
INFO - 2018-07-16 22:24:49 --> Router Class Initialized
INFO - 2018-07-16 22:24:49 --> Output Class Initialized
INFO - 2018-07-16 22:24:49 --> Security Class Initialized
DEBUG - 2018-07-16 22:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:24:49 --> Input Class Initialized
INFO - 2018-07-16 22:24:49 --> Language Class Initialized
INFO - 2018-07-16 22:24:49 --> Loader Class Initialized
INFO - 2018-07-16 22:24:49 --> Controller Class Initialized
INFO - 2018-07-16 22:24:49 --> Database Driver Class Initialized
INFO - 2018-07-16 22:24:49 --> Model Class Initialized
INFO - 2018-07-16 22:24:49 --> Helper loaded: url_helper
INFO - 2018-07-16 22:24:49 --> Model Class Initialized
INFO - 2018-07-16 22:24:49 --> Final output sent to browser
DEBUG - 2018-07-16 22:24:49 --> Total execution time: 0.0542
ERROR - 2018-07-16 22:24:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:24:50 --> Config Class Initialized
INFO - 2018-07-16 22:24:50 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:24:50 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:24:50 --> Utf8 Class Initialized
INFO - 2018-07-16 22:24:50 --> URI Class Initialized
INFO - 2018-07-16 22:24:50 --> Router Class Initialized
INFO - 2018-07-16 22:24:50 --> Output Class Initialized
INFO - 2018-07-16 22:24:50 --> Security Class Initialized
DEBUG - 2018-07-16 22:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:24:50 --> Input Class Initialized
INFO - 2018-07-16 22:24:50 --> Language Class Initialized
INFO - 2018-07-16 22:24:50 --> Loader Class Initialized
INFO - 2018-07-16 22:24:50 --> Controller Class Initialized
INFO - 2018-07-16 22:24:50 --> Database Driver Class Initialized
INFO - 2018-07-16 22:24:50 --> Model Class Initialized
INFO - 2018-07-16 22:24:50 --> Helper loaded: url_helper
INFO - 2018-07-16 22:24:50 --> Model Class Initialized
INFO - 2018-07-16 22:24:50 --> Final output sent to browser
DEBUG - 2018-07-16 22:24:50 --> Total execution time: 0.0670
ERROR - 2018-07-16 22:26:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:26:45 --> Config Class Initialized
INFO - 2018-07-16 22:26:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:26:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:26:45 --> Utf8 Class Initialized
INFO - 2018-07-16 22:26:45 --> URI Class Initialized
INFO - 2018-07-16 22:26:45 --> Router Class Initialized
INFO - 2018-07-16 22:26:45 --> Output Class Initialized
INFO - 2018-07-16 22:26:45 --> Security Class Initialized
DEBUG - 2018-07-16 22:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:26:45 --> Input Class Initialized
INFO - 2018-07-16 22:26:45 --> Language Class Initialized
INFO - 2018-07-16 22:26:45 --> Loader Class Initialized
INFO - 2018-07-16 22:26:45 --> Controller Class Initialized
INFO - 2018-07-16 22:26:45 --> Database Driver Class Initialized
INFO - 2018-07-16 22:26:45 --> Model Class Initialized
INFO - 2018-07-16 22:26:45 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:26:45 --> Model Class Initialized
INFO - 2018-07-16 22:26:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 22:26:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-16 22:26:45 --> Final output sent to browser
DEBUG - 2018-07-16 22:26:45 --> Total execution time: 0.0865
ERROR - 2018-07-16 22:26:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:26:48 --> Config Class Initialized
INFO - 2018-07-16 22:26:48 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:26:48 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:26:48 --> Utf8 Class Initialized
INFO - 2018-07-16 22:26:48 --> URI Class Initialized
INFO - 2018-07-16 22:26:48 --> Router Class Initialized
INFO - 2018-07-16 22:26:48 --> Output Class Initialized
INFO - 2018-07-16 22:26:48 --> Security Class Initialized
DEBUG - 2018-07-16 22:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:26:48 --> Input Class Initialized
INFO - 2018-07-16 22:26:48 --> Language Class Initialized
INFO - 2018-07-16 22:26:48 --> Loader Class Initialized
INFO - 2018-07-16 22:26:48 --> Controller Class Initialized
INFO - 2018-07-16 22:26:48 --> Database Driver Class Initialized
INFO - 2018-07-16 22:26:48 --> Model Class Initialized
INFO - 2018-07-16 22:26:48 --> Helper loaded: url_helper
INFO - 2018-07-16 22:26:48 --> Model Class Initialized
INFO - 2018-07-16 22:26:48 --> Final output sent to browser
DEBUG - 2018-07-16 22:26:48 --> Total execution time: 0.0643
ERROR - 2018-07-16 22:26:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:26:50 --> Config Class Initialized
INFO - 2018-07-16 22:26:50 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:26:50 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:26:50 --> Utf8 Class Initialized
INFO - 2018-07-16 22:26:50 --> URI Class Initialized
INFO - 2018-07-16 22:26:50 --> Router Class Initialized
INFO - 2018-07-16 22:26:50 --> Output Class Initialized
INFO - 2018-07-16 22:26:50 --> Security Class Initialized
DEBUG - 2018-07-16 22:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:26:50 --> Input Class Initialized
INFO - 2018-07-16 22:26:50 --> Language Class Initialized
INFO - 2018-07-16 22:26:50 --> Loader Class Initialized
INFO - 2018-07-16 22:26:50 --> Controller Class Initialized
INFO - 2018-07-16 22:26:50 --> Database Driver Class Initialized
INFO - 2018-07-16 22:26:50 --> Model Class Initialized
INFO - 2018-07-16 22:26:50 --> Helper loaded: url_helper
INFO - 2018-07-16 22:26:50 --> Model Class Initialized
INFO - 2018-07-16 22:26:50 --> Final output sent to browser
DEBUG - 2018-07-16 22:26:50 --> Total execution time: 0.0518
ERROR - 2018-07-16 22:26:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:26:50 --> Config Class Initialized
INFO - 2018-07-16 22:26:50 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:26:50 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:26:50 --> Utf8 Class Initialized
INFO - 2018-07-16 22:26:50 --> URI Class Initialized
INFO - 2018-07-16 22:26:50 --> Router Class Initialized
INFO - 2018-07-16 22:26:50 --> Output Class Initialized
INFO - 2018-07-16 22:26:50 --> Security Class Initialized
DEBUG - 2018-07-16 22:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:26:50 --> Input Class Initialized
INFO - 2018-07-16 22:26:50 --> Language Class Initialized
INFO - 2018-07-16 22:26:50 --> Loader Class Initialized
INFO - 2018-07-16 22:26:50 --> Controller Class Initialized
INFO - 2018-07-16 22:26:50 --> Database Driver Class Initialized
INFO - 2018-07-16 22:26:50 --> Model Class Initialized
INFO - 2018-07-16 22:26:50 --> Helper loaded: url_helper
INFO - 2018-07-16 22:26:50 --> Model Class Initialized
INFO - 2018-07-16 22:26:50 --> Final output sent to browser
DEBUG - 2018-07-16 22:26:50 --> Total execution time: 0.0571
ERROR - 2018-07-16 22:26:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:26:51 --> Config Class Initialized
INFO - 2018-07-16 22:26:51 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:26:51 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:26:51 --> Utf8 Class Initialized
INFO - 2018-07-16 22:26:51 --> URI Class Initialized
INFO - 2018-07-16 22:26:51 --> Router Class Initialized
INFO - 2018-07-16 22:26:51 --> Output Class Initialized
INFO - 2018-07-16 22:26:51 --> Security Class Initialized
DEBUG - 2018-07-16 22:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:26:51 --> Input Class Initialized
INFO - 2018-07-16 22:26:51 --> Language Class Initialized
INFO - 2018-07-16 22:26:51 --> Loader Class Initialized
INFO - 2018-07-16 22:26:51 --> Controller Class Initialized
INFO - 2018-07-16 22:26:51 --> Database Driver Class Initialized
INFO - 2018-07-16 22:26:51 --> Model Class Initialized
INFO - 2018-07-16 22:26:51 --> Helper loaded: url_helper
INFO - 2018-07-16 22:26:51 --> Model Class Initialized
INFO - 2018-07-16 22:26:51 --> Final output sent to browser
DEBUG - 2018-07-16 22:26:51 --> Total execution time: 0.0536
ERROR - 2018-07-16 22:27:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:27:06 --> Config Class Initialized
INFO - 2018-07-16 22:27:06 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:27:06 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:27:06 --> Utf8 Class Initialized
INFO - 2018-07-16 22:27:06 --> URI Class Initialized
INFO - 2018-07-16 22:27:06 --> Router Class Initialized
INFO - 2018-07-16 22:27:06 --> Output Class Initialized
INFO - 2018-07-16 22:27:06 --> Security Class Initialized
DEBUG - 2018-07-16 22:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:27:06 --> Input Class Initialized
INFO - 2018-07-16 22:27:06 --> Language Class Initialized
INFO - 2018-07-16 22:27:06 --> Loader Class Initialized
INFO - 2018-07-16 22:27:06 --> Controller Class Initialized
INFO - 2018-07-16 22:27:06 --> Database Driver Class Initialized
INFO - 2018-07-16 22:27:06 --> Model Class Initialized
INFO - 2018-07-16 22:27:06 --> Helper loaded: url_helper
INFO - 2018-07-16 22:27:06 --> Model Class Initialized
INFO - 2018-07-16 22:27:06 --> Final output sent to browser
DEBUG - 2018-07-16 22:27:06 --> Total execution time: 0.0504
ERROR - 2018-07-16 22:27:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:27:09 --> Config Class Initialized
INFO - 2018-07-16 22:27:09 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:27:09 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:27:09 --> Utf8 Class Initialized
INFO - 2018-07-16 22:27:09 --> URI Class Initialized
INFO - 2018-07-16 22:27:09 --> Router Class Initialized
INFO - 2018-07-16 22:27:09 --> Output Class Initialized
INFO - 2018-07-16 22:27:09 --> Security Class Initialized
DEBUG - 2018-07-16 22:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:27:09 --> Input Class Initialized
INFO - 2018-07-16 22:27:09 --> Language Class Initialized
INFO - 2018-07-16 22:27:09 --> Loader Class Initialized
INFO - 2018-07-16 22:27:09 --> Controller Class Initialized
INFO - 2018-07-16 22:27:09 --> Database Driver Class Initialized
INFO - 2018-07-16 22:27:09 --> Model Class Initialized
INFO - 2018-07-16 22:27:09 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:27:09 --> Model Class Initialized
ERROR - 2018-07-16 22:27:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:27:09 --> Config Class Initialized
INFO - 2018-07-16 22:27:09 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:27:09 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:27:09 --> Utf8 Class Initialized
INFO - 2018-07-16 22:27:09 --> URI Class Initialized
INFO - 2018-07-16 22:27:09 --> Router Class Initialized
INFO - 2018-07-16 22:27:09 --> Output Class Initialized
INFO - 2018-07-16 22:27:09 --> Security Class Initialized
DEBUG - 2018-07-16 22:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:27:09 --> Input Class Initialized
INFO - 2018-07-16 22:27:09 --> Language Class Initialized
INFO - 2018-07-16 22:27:09 --> Loader Class Initialized
INFO - 2018-07-16 22:27:09 --> Controller Class Initialized
INFO - 2018-07-16 22:27:09 --> Database Driver Class Initialized
INFO - 2018-07-16 22:27:09 --> Model Class Initialized
INFO - 2018-07-16 22:27:09 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:27:09 --> Model Class Initialized
INFO - 2018-07-16 22:27:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 22:27:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-16 22:27:09 --> Final output sent to browser
DEBUG - 2018-07-16 22:27:09 --> Total execution time: 0.0579
ERROR - 2018-07-16 22:27:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:27:13 --> Config Class Initialized
INFO - 2018-07-16 22:27:13 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:27:13 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:27:13 --> Utf8 Class Initialized
INFO - 2018-07-16 22:27:13 --> URI Class Initialized
INFO - 2018-07-16 22:27:13 --> Router Class Initialized
INFO - 2018-07-16 22:27:13 --> Output Class Initialized
INFO - 2018-07-16 22:27:13 --> Security Class Initialized
DEBUG - 2018-07-16 22:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:27:13 --> Input Class Initialized
INFO - 2018-07-16 22:27:13 --> Language Class Initialized
INFO - 2018-07-16 22:27:13 --> Loader Class Initialized
INFO - 2018-07-16 22:27:13 --> Controller Class Initialized
INFO - 2018-07-16 22:27:13 --> Database Driver Class Initialized
INFO - 2018-07-16 22:27:13 --> Model Class Initialized
INFO - 2018-07-16 22:27:13 --> Helper loaded: url_helper
INFO - 2018-07-16 22:27:13 --> Model Class Initialized
INFO - 2018-07-16 22:27:13 --> Final output sent to browser
DEBUG - 2018-07-16 22:27:13 --> Total execution time: 0.0663
ERROR - 2018-07-16 22:27:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:27:19 --> Config Class Initialized
INFO - 2018-07-16 22:27:19 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:27:19 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:27:19 --> Utf8 Class Initialized
INFO - 2018-07-16 22:27:19 --> URI Class Initialized
INFO - 2018-07-16 22:27:19 --> Router Class Initialized
INFO - 2018-07-16 22:27:19 --> Output Class Initialized
INFO - 2018-07-16 22:27:19 --> Security Class Initialized
DEBUG - 2018-07-16 22:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:27:19 --> Input Class Initialized
INFO - 2018-07-16 22:27:19 --> Language Class Initialized
INFO - 2018-07-16 22:27:19 --> Loader Class Initialized
INFO - 2018-07-16 22:27:19 --> Controller Class Initialized
INFO - 2018-07-16 22:27:19 --> Database Driver Class Initialized
INFO - 2018-07-16 22:27:19 --> Model Class Initialized
INFO - 2018-07-16 22:27:19 --> Helper loaded: url_helper
INFO - 2018-07-16 22:27:19 --> Model Class Initialized
INFO - 2018-07-16 22:27:19 --> Final output sent to browser
DEBUG - 2018-07-16 22:27:19 --> Total execution time: 0.0532
ERROR - 2018-07-16 22:28:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:28:16 --> Config Class Initialized
INFO - 2018-07-16 22:28:16 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:28:16 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:28:16 --> Utf8 Class Initialized
INFO - 2018-07-16 22:28:16 --> URI Class Initialized
INFO - 2018-07-16 22:28:16 --> Router Class Initialized
INFO - 2018-07-16 22:28:16 --> Output Class Initialized
INFO - 2018-07-16 22:28:16 --> Security Class Initialized
DEBUG - 2018-07-16 22:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:28:16 --> Input Class Initialized
INFO - 2018-07-16 22:28:16 --> Language Class Initialized
INFO - 2018-07-16 22:28:16 --> Loader Class Initialized
INFO - 2018-07-16 22:28:16 --> Controller Class Initialized
INFO - 2018-07-16 22:28:16 --> Database Driver Class Initialized
INFO - 2018-07-16 22:28:16 --> Model Class Initialized
INFO - 2018-07-16 22:28:16 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:28:16 --> Model Class Initialized
INFO - 2018-07-16 22:28:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 22:28:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-16 22:28:16 --> Final output sent to browser
DEBUG - 2018-07-16 22:28:16 --> Total execution time: 0.0526
ERROR - 2018-07-16 22:28:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:28:41 --> Config Class Initialized
INFO - 2018-07-16 22:28:41 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:28:41 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:28:41 --> Utf8 Class Initialized
INFO - 2018-07-16 22:28:41 --> URI Class Initialized
INFO - 2018-07-16 22:28:41 --> Router Class Initialized
INFO - 2018-07-16 22:28:41 --> Output Class Initialized
INFO - 2018-07-16 22:28:41 --> Security Class Initialized
DEBUG - 2018-07-16 22:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:28:41 --> Input Class Initialized
INFO - 2018-07-16 22:28:41 --> Language Class Initialized
INFO - 2018-07-16 22:28:41 --> Loader Class Initialized
INFO - 2018-07-16 22:28:41 --> Controller Class Initialized
INFO - 2018-07-16 22:28:41 --> Database Driver Class Initialized
INFO - 2018-07-16 22:28:41 --> Model Class Initialized
INFO - 2018-07-16 22:28:41 --> Helper loaded: url_helper
INFO - 2018-07-16 22:28:41 --> Model Class Initialized
INFO - 2018-07-16 22:28:41 --> Final output sent to browser
DEBUG - 2018-07-16 22:28:41 --> Total execution time: 0.0514
ERROR - 2018-07-16 22:28:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:28:51 --> Config Class Initialized
INFO - 2018-07-16 22:28:51 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:28:51 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:28:51 --> Utf8 Class Initialized
INFO - 2018-07-16 22:28:51 --> URI Class Initialized
INFO - 2018-07-16 22:28:51 --> Router Class Initialized
INFO - 2018-07-16 22:28:51 --> Output Class Initialized
INFO - 2018-07-16 22:28:51 --> Security Class Initialized
DEBUG - 2018-07-16 22:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:28:51 --> Input Class Initialized
INFO - 2018-07-16 22:28:51 --> Language Class Initialized
INFO - 2018-07-16 22:28:51 --> Loader Class Initialized
INFO - 2018-07-16 22:28:51 --> Controller Class Initialized
INFO - 2018-07-16 22:28:51 --> Database Driver Class Initialized
INFO - 2018-07-16 22:28:51 --> Model Class Initialized
INFO - 2018-07-16 22:28:51 --> Helper loaded: url_helper
INFO - 2018-07-16 22:28:51 --> Model Class Initialized
INFO - 2018-07-16 22:28:51 --> Final output sent to browser
DEBUG - 2018-07-16 22:28:51 --> Total execution time: 0.0594
ERROR - 2018-07-16 22:29:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:29:20 --> Config Class Initialized
INFO - 2018-07-16 22:29:20 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:29:20 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:29:20 --> Utf8 Class Initialized
INFO - 2018-07-16 22:29:20 --> URI Class Initialized
INFO - 2018-07-16 22:29:20 --> Router Class Initialized
INFO - 2018-07-16 22:29:20 --> Output Class Initialized
INFO - 2018-07-16 22:29:20 --> Security Class Initialized
DEBUG - 2018-07-16 22:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:29:20 --> Input Class Initialized
INFO - 2018-07-16 22:29:20 --> Language Class Initialized
INFO - 2018-07-16 22:29:20 --> Loader Class Initialized
INFO - 2018-07-16 22:29:20 --> Controller Class Initialized
INFO - 2018-07-16 22:29:20 --> Database Driver Class Initialized
INFO - 2018-07-16 22:29:20 --> Model Class Initialized
INFO - 2018-07-16 22:29:20 --> Helper loaded: url_helper
INFO - 2018-07-16 22:29:20 --> Model Class Initialized
INFO - 2018-07-16 22:29:20 --> Final output sent to browser
DEBUG - 2018-07-16 22:29:20 --> Total execution time: 0.0457
ERROR - 2018-07-16 22:29:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:29:37 --> Config Class Initialized
INFO - 2018-07-16 22:29:37 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:29:37 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:29:37 --> Utf8 Class Initialized
INFO - 2018-07-16 22:29:37 --> URI Class Initialized
INFO - 2018-07-16 22:29:37 --> Router Class Initialized
INFO - 2018-07-16 22:29:37 --> Output Class Initialized
INFO - 2018-07-16 22:29:37 --> Security Class Initialized
DEBUG - 2018-07-16 22:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:29:37 --> Input Class Initialized
INFO - 2018-07-16 22:29:37 --> Language Class Initialized
INFO - 2018-07-16 22:29:37 --> Loader Class Initialized
INFO - 2018-07-16 22:29:37 --> Controller Class Initialized
INFO - 2018-07-16 22:29:37 --> Database Driver Class Initialized
INFO - 2018-07-16 22:29:37 --> Model Class Initialized
INFO - 2018-07-16 22:29:37 --> Helper loaded: url_helper
INFO - 2018-07-16 22:29:37 --> Model Class Initialized
INFO - 2018-07-16 22:29:37 --> Final output sent to browser
DEBUG - 2018-07-16 22:29:37 --> Total execution time: 0.0557
ERROR - 2018-07-16 22:29:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:29:39 --> Config Class Initialized
INFO - 2018-07-16 22:29:39 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:29:39 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:29:39 --> Utf8 Class Initialized
INFO - 2018-07-16 22:29:39 --> URI Class Initialized
INFO - 2018-07-16 22:29:39 --> Router Class Initialized
INFO - 2018-07-16 22:29:39 --> Output Class Initialized
INFO - 2018-07-16 22:29:39 --> Security Class Initialized
DEBUG - 2018-07-16 22:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:29:39 --> Input Class Initialized
INFO - 2018-07-16 22:29:39 --> Language Class Initialized
INFO - 2018-07-16 22:29:39 --> Loader Class Initialized
INFO - 2018-07-16 22:29:39 --> Controller Class Initialized
INFO - 2018-07-16 22:29:39 --> Database Driver Class Initialized
INFO - 2018-07-16 22:29:39 --> Model Class Initialized
INFO - 2018-07-16 22:29:39 --> Helper loaded: url_helper
INFO - 2018-07-16 22:29:39 --> Model Class Initialized
INFO - 2018-07-16 22:29:39 --> Final output sent to browser
DEBUG - 2018-07-16 22:29:39 --> Total execution time: 0.0468
ERROR - 2018-07-16 22:29:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:29:39 --> Config Class Initialized
INFO - 2018-07-16 22:29:39 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:29:39 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:29:39 --> Utf8 Class Initialized
INFO - 2018-07-16 22:29:39 --> URI Class Initialized
INFO - 2018-07-16 22:29:39 --> Router Class Initialized
INFO - 2018-07-16 22:29:39 --> Output Class Initialized
INFO - 2018-07-16 22:29:39 --> Security Class Initialized
DEBUG - 2018-07-16 22:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:29:39 --> Input Class Initialized
INFO - 2018-07-16 22:29:39 --> Language Class Initialized
INFO - 2018-07-16 22:29:39 --> Loader Class Initialized
INFO - 2018-07-16 22:29:39 --> Controller Class Initialized
INFO - 2018-07-16 22:29:39 --> Database Driver Class Initialized
INFO - 2018-07-16 22:29:39 --> Model Class Initialized
INFO - 2018-07-16 22:29:39 --> Helper loaded: url_helper
INFO - 2018-07-16 22:29:39 --> Model Class Initialized
INFO - 2018-07-16 22:29:39 --> Final output sent to browser
DEBUG - 2018-07-16 22:29:39 --> Total execution time: 0.0452
ERROR - 2018-07-16 22:29:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:29:39 --> Config Class Initialized
INFO - 2018-07-16 22:29:39 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:29:39 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:29:39 --> Utf8 Class Initialized
INFO - 2018-07-16 22:29:39 --> URI Class Initialized
INFO - 2018-07-16 22:29:39 --> Router Class Initialized
INFO - 2018-07-16 22:29:39 --> Output Class Initialized
INFO - 2018-07-16 22:29:39 --> Security Class Initialized
DEBUG - 2018-07-16 22:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:29:39 --> Input Class Initialized
INFO - 2018-07-16 22:29:39 --> Language Class Initialized
INFO - 2018-07-16 22:29:39 --> Loader Class Initialized
INFO - 2018-07-16 22:29:39 --> Controller Class Initialized
INFO - 2018-07-16 22:29:39 --> Database Driver Class Initialized
INFO - 2018-07-16 22:29:39 --> Model Class Initialized
INFO - 2018-07-16 22:29:39 --> Helper loaded: url_helper
INFO - 2018-07-16 22:29:39 --> Model Class Initialized
INFO - 2018-07-16 22:29:39 --> Final output sent to browser
DEBUG - 2018-07-16 22:29:39 --> Total execution time: 0.0414
ERROR - 2018-07-16 22:30:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:30:04 --> Config Class Initialized
INFO - 2018-07-16 22:30:04 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:30:04 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:30:04 --> Utf8 Class Initialized
INFO - 2018-07-16 22:30:04 --> URI Class Initialized
INFO - 2018-07-16 22:30:04 --> Router Class Initialized
INFO - 2018-07-16 22:30:04 --> Output Class Initialized
INFO - 2018-07-16 22:30:04 --> Security Class Initialized
DEBUG - 2018-07-16 22:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:30:04 --> Input Class Initialized
INFO - 2018-07-16 22:30:04 --> Language Class Initialized
INFO - 2018-07-16 22:30:04 --> Loader Class Initialized
INFO - 2018-07-16 22:30:04 --> Controller Class Initialized
INFO - 2018-07-16 22:30:04 --> Database Driver Class Initialized
INFO - 2018-07-16 22:30:04 --> Model Class Initialized
INFO - 2018-07-16 22:30:04 --> Helper loaded: url_helper
INFO - 2018-07-16 22:30:04 --> Model Class Initialized
INFO - 2018-07-16 22:30:04 --> Final output sent to browser
DEBUG - 2018-07-16 22:30:04 --> Total execution time: 0.0762
ERROR - 2018-07-16 22:30:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:30:10 --> Config Class Initialized
INFO - 2018-07-16 22:30:10 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:30:10 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:30:10 --> Utf8 Class Initialized
INFO - 2018-07-16 22:30:10 --> URI Class Initialized
INFO - 2018-07-16 22:30:10 --> Router Class Initialized
INFO - 2018-07-16 22:30:10 --> Output Class Initialized
INFO - 2018-07-16 22:30:10 --> Security Class Initialized
DEBUG - 2018-07-16 22:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:30:10 --> Input Class Initialized
INFO - 2018-07-16 22:30:10 --> Language Class Initialized
INFO - 2018-07-16 22:30:10 --> Loader Class Initialized
INFO - 2018-07-16 22:30:10 --> Controller Class Initialized
INFO - 2018-07-16 22:30:10 --> Database Driver Class Initialized
INFO - 2018-07-16 22:30:10 --> Model Class Initialized
INFO - 2018-07-16 22:30:10 --> Helper loaded: url_helper
INFO - 2018-07-16 22:30:10 --> Model Class Initialized
INFO - 2018-07-16 22:30:10 --> Final output sent to browser
DEBUG - 2018-07-16 22:30:10 --> Total execution time: 0.0543
ERROR - 2018-07-16 22:30:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:30:16 --> Config Class Initialized
INFO - 2018-07-16 22:30:16 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:30:16 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:30:16 --> Utf8 Class Initialized
INFO - 2018-07-16 22:30:16 --> URI Class Initialized
INFO - 2018-07-16 22:30:16 --> Router Class Initialized
INFO - 2018-07-16 22:30:16 --> Output Class Initialized
INFO - 2018-07-16 22:30:16 --> Security Class Initialized
DEBUG - 2018-07-16 22:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:30:16 --> Input Class Initialized
INFO - 2018-07-16 22:30:16 --> Language Class Initialized
INFO - 2018-07-16 22:30:16 --> Loader Class Initialized
INFO - 2018-07-16 22:30:16 --> Controller Class Initialized
INFO - 2018-07-16 22:30:16 --> Database Driver Class Initialized
INFO - 2018-07-16 22:30:16 --> Model Class Initialized
INFO - 2018-07-16 22:30:16 --> Helper loaded: url_helper
INFO - 2018-07-16 22:30:16 --> Model Class Initialized
INFO - 2018-07-16 22:30:16 --> Final output sent to browser
DEBUG - 2018-07-16 22:30:16 --> Total execution time: 0.0552
ERROR - 2018-07-16 22:30:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:30:32 --> Config Class Initialized
INFO - 2018-07-16 22:30:32 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:30:32 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:30:32 --> Utf8 Class Initialized
INFO - 2018-07-16 22:30:32 --> URI Class Initialized
INFO - 2018-07-16 22:30:32 --> Router Class Initialized
INFO - 2018-07-16 22:30:32 --> Output Class Initialized
INFO - 2018-07-16 22:30:32 --> Security Class Initialized
DEBUG - 2018-07-16 22:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:30:32 --> Input Class Initialized
INFO - 2018-07-16 22:30:32 --> Language Class Initialized
INFO - 2018-07-16 22:30:32 --> Loader Class Initialized
INFO - 2018-07-16 22:30:32 --> Controller Class Initialized
INFO - 2018-07-16 22:30:32 --> Database Driver Class Initialized
INFO - 2018-07-16 22:30:32 --> Model Class Initialized
INFO - 2018-07-16 22:30:32 --> Helper loaded: url_helper
INFO - 2018-07-16 22:30:32 --> Model Class Initialized
INFO - 2018-07-16 22:30:32 --> Final output sent to browser
DEBUG - 2018-07-16 22:30:32 --> Total execution time: 0.0547
ERROR - 2018-07-16 22:30:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:30:45 --> Config Class Initialized
INFO - 2018-07-16 22:30:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:30:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:30:45 --> Utf8 Class Initialized
INFO - 2018-07-16 22:30:45 --> URI Class Initialized
INFO - 2018-07-16 22:30:45 --> Router Class Initialized
INFO - 2018-07-16 22:30:45 --> Output Class Initialized
INFO - 2018-07-16 22:30:45 --> Security Class Initialized
DEBUG - 2018-07-16 22:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:30:45 --> Input Class Initialized
INFO - 2018-07-16 22:30:45 --> Language Class Initialized
INFO - 2018-07-16 22:30:45 --> Loader Class Initialized
INFO - 2018-07-16 22:30:45 --> Controller Class Initialized
INFO - 2018-07-16 22:30:45 --> Database Driver Class Initialized
INFO - 2018-07-16 22:30:45 --> Model Class Initialized
INFO - 2018-07-16 22:30:45 --> Helper loaded: url_helper
INFO - 2018-07-16 22:30:45 --> Model Class Initialized
INFO - 2018-07-16 22:30:45 --> Final output sent to browser
DEBUG - 2018-07-16 22:30:45 --> Total execution time: 0.0531
ERROR - 2018-07-16 22:30:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:30:56 --> Config Class Initialized
INFO - 2018-07-16 22:30:56 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:30:56 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:30:56 --> Utf8 Class Initialized
INFO - 2018-07-16 22:30:56 --> URI Class Initialized
INFO - 2018-07-16 22:30:56 --> Router Class Initialized
INFO - 2018-07-16 22:30:56 --> Output Class Initialized
INFO - 2018-07-16 22:30:56 --> Security Class Initialized
DEBUG - 2018-07-16 22:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:30:56 --> Input Class Initialized
INFO - 2018-07-16 22:30:56 --> Language Class Initialized
INFO - 2018-07-16 22:30:56 --> Loader Class Initialized
INFO - 2018-07-16 22:30:56 --> Controller Class Initialized
INFO - 2018-07-16 22:30:56 --> Database Driver Class Initialized
INFO - 2018-07-16 22:30:56 --> Model Class Initialized
INFO - 2018-07-16 22:30:56 --> Helper loaded: url_helper
INFO - 2018-07-16 22:30:56 --> Model Class Initialized
INFO - 2018-07-16 22:30:56 --> Final output sent to browser
DEBUG - 2018-07-16 22:30:56 --> Total execution time: 0.0491
ERROR - 2018-07-16 22:30:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:30:56 --> Config Class Initialized
INFO - 2018-07-16 22:30:56 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:30:56 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:30:56 --> Utf8 Class Initialized
INFO - 2018-07-16 22:30:56 --> URI Class Initialized
INFO - 2018-07-16 22:30:56 --> Router Class Initialized
INFO - 2018-07-16 22:30:56 --> Output Class Initialized
INFO - 2018-07-16 22:30:56 --> Security Class Initialized
DEBUG - 2018-07-16 22:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:30:56 --> Input Class Initialized
INFO - 2018-07-16 22:30:56 --> Language Class Initialized
INFO - 2018-07-16 22:30:56 --> Loader Class Initialized
INFO - 2018-07-16 22:30:56 --> Controller Class Initialized
INFO - 2018-07-16 22:30:56 --> Database Driver Class Initialized
INFO - 2018-07-16 22:30:56 --> Model Class Initialized
INFO - 2018-07-16 22:30:56 --> Helper loaded: url_helper
INFO - 2018-07-16 22:30:56 --> Model Class Initialized
INFO - 2018-07-16 22:30:56 --> Final output sent to browser
DEBUG - 2018-07-16 22:30:56 --> Total execution time: 0.0553
ERROR - 2018-07-16 22:31:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:31:04 --> Config Class Initialized
INFO - 2018-07-16 22:31:04 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:31:04 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:31:04 --> Utf8 Class Initialized
INFO - 2018-07-16 22:31:04 --> URI Class Initialized
INFO - 2018-07-16 22:31:04 --> Router Class Initialized
INFO - 2018-07-16 22:31:04 --> Output Class Initialized
INFO - 2018-07-16 22:31:04 --> Security Class Initialized
DEBUG - 2018-07-16 22:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:31:04 --> Input Class Initialized
INFO - 2018-07-16 22:31:04 --> Language Class Initialized
INFO - 2018-07-16 22:31:04 --> Loader Class Initialized
INFO - 2018-07-16 22:31:04 --> Controller Class Initialized
INFO - 2018-07-16 22:31:04 --> Database Driver Class Initialized
INFO - 2018-07-16 22:31:04 --> Model Class Initialized
INFO - 2018-07-16 22:31:04 --> Helper loaded: url_helper
INFO - 2018-07-16 22:31:04 --> Model Class Initialized
INFO - 2018-07-16 22:31:04 --> Final output sent to browser
DEBUG - 2018-07-16 22:31:04 --> Total execution time: 0.0546
ERROR - 2018-07-16 22:31:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:31:12 --> Config Class Initialized
INFO - 2018-07-16 22:31:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:31:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:31:12 --> Utf8 Class Initialized
INFO - 2018-07-16 22:31:12 --> URI Class Initialized
INFO - 2018-07-16 22:31:12 --> Router Class Initialized
INFO - 2018-07-16 22:31:12 --> Output Class Initialized
INFO - 2018-07-16 22:31:12 --> Security Class Initialized
DEBUG - 2018-07-16 22:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:31:12 --> Input Class Initialized
INFO - 2018-07-16 22:31:12 --> Language Class Initialized
INFO - 2018-07-16 22:31:12 --> Loader Class Initialized
INFO - 2018-07-16 22:31:12 --> Controller Class Initialized
INFO - 2018-07-16 22:31:12 --> Database Driver Class Initialized
INFO - 2018-07-16 22:31:12 --> Model Class Initialized
INFO - 2018-07-16 22:31:12 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:31:12 --> Model Class Initialized
INFO - 2018-07-16 22:31:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 22:31:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-16 22:31:12 --> Final output sent to browser
DEBUG - 2018-07-16 22:31:12 --> Total execution time: 0.0813
ERROR - 2018-07-16 22:31:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:31:12 --> Config Class Initialized
INFO - 2018-07-16 22:31:12 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:31:12 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:31:12 --> Utf8 Class Initialized
INFO - 2018-07-16 22:31:13 --> URI Class Initialized
INFO - 2018-07-16 22:31:13 --> Router Class Initialized
INFO - 2018-07-16 22:31:13 --> Output Class Initialized
INFO - 2018-07-16 22:31:13 --> Security Class Initialized
DEBUG - 2018-07-16 22:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:31:13 --> Input Class Initialized
INFO - 2018-07-16 22:31:13 --> Language Class Initialized
INFO - 2018-07-16 22:31:13 --> Loader Class Initialized
INFO - 2018-07-16 22:31:13 --> Controller Class Initialized
INFO - 2018-07-16 22:31:13 --> Database Driver Class Initialized
INFO - 2018-07-16 22:31:13 --> Model Class Initialized
INFO - 2018-07-16 22:31:13 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:31:13 --> Model Class Initialized
INFO - 2018-07-16 22:31:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 22:31:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-16 22:31:13 --> Final output sent to browser
DEBUG - 2018-07-16 22:31:13 --> Total execution time: 0.0663
ERROR - 2018-07-16 22:31:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:31:14 --> Config Class Initialized
INFO - 2018-07-16 22:31:14 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:31:14 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:31:14 --> Utf8 Class Initialized
INFO - 2018-07-16 22:31:14 --> URI Class Initialized
INFO - 2018-07-16 22:31:14 --> Router Class Initialized
INFO - 2018-07-16 22:31:14 --> Output Class Initialized
INFO - 2018-07-16 22:31:14 --> Security Class Initialized
DEBUG - 2018-07-16 22:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:31:14 --> Input Class Initialized
INFO - 2018-07-16 22:31:14 --> Language Class Initialized
INFO - 2018-07-16 22:31:14 --> Loader Class Initialized
INFO - 2018-07-16 22:31:14 --> Controller Class Initialized
INFO - 2018-07-16 22:31:14 --> Database Driver Class Initialized
INFO - 2018-07-16 22:31:14 --> Model Class Initialized
INFO - 2018-07-16 22:31:14 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:31:14 --> Model Class Initialized
ERROR - 2018-07-16 22:31:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:31:14 --> Config Class Initialized
INFO - 2018-07-16 22:31:14 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:31:14 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:31:14 --> Utf8 Class Initialized
INFO - 2018-07-16 22:31:14 --> URI Class Initialized
INFO - 2018-07-16 22:31:14 --> Router Class Initialized
INFO - 2018-07-16 22:31:14 --> Output Class Initialized
INFO - 2018-07-16 22:31:14 --> Security Class Initialized
DEBUG - 2018-07-16 22:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:31:14 --> Input Class Initialized
INFO - 2018-07-16 22:31:14 --> Language Class Initialized
INFO - 2018-07-16 22:31:14 --> Loader Class Initialized
INFO - 2018-07-16 22:31:14 --> Controller Class Initialized
INFO - 2018-07-16 22:31:14 --> Database Driver Class Initialized
INFO - 2018-07-16 22:31:14 --> Model Class Initialized
INFO - 2018-07-16 22:31:14 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:31:14 --> Model Class Initialized
INFO - 2018-07-16 22:31:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 22:31:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-16 22:31:14 --> Final output sent to browser
DEBUG - 2018-07-16 22:31:14 --> Total execution time: 0.0633
ERROR - 2018-07-16 22:31:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:31:23 --> Config Class Initialized
INFO - 2018-07-16 22:31:23 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:31:23 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:31:23 --> Utf8 Class Initialized
INFO - 2018-07-16 22:31:23 --> URI Class Initialized
INFO - 2018-07-16 22:31:23 --> Router Class Initialized
INFO - 2018-07-16 22:31:23 --> Output Class Initialized
INFO - 2018-07-16 22:31:23 --> Security Class Initialized
DEBUG - 2018-07-16 22:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:31:23 --> Input Class Initialized
INFO - 2018-07-16 22:31:23 --> Language Class Initialized
INFO - 2018-07-16 22:31:23 --> Loader Class Initialized
INFO - 2018-07-16 22:31:23 --> Controller Class Initialized
INFO - 2018-07-16 22:31:23 --> Database Driver Class Initialized
INFO - 2018-07-16 22:31:23 --> Model Class Initialized
INFO - 2018-07-16 22:31:23 --> Helper loaded: url_helper
INFO - 2018-07-16 22:31:23 --> Model Class Initialized
INFO - 2018-07-16 22:31:23 --> Final output sent to browser
DEBUG - 2018-07-16 22:31:23 --> Total execution time: 0.0572
ERROR - 2018-07-16 22:32:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:32:17 --> Config Class Initialized
INFO - 2018-07-16 22:32:17 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:32:17 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:32:17 --> Utf8 Class Initialized
INFO - 2018-07-16 22:32:17 --> URI Class Initialized
INFO - 2018-07-16 22:32:17 --> Router Class Initialized
INFO - 2018-07-16 22:32:17 --> Output Class Initialized
INFO - 2018-07-16 22:32:17 --> Security Class Initialized
DEBUG - 2018-07-16 22:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:32:17 --> Input Class Initialized
INFO - 2018-07-16 22:32:17 --> Language Class Initialized
INFO - 2018-07-16 22:32:17 --> Loader Class Initialized
INFO - 2018-07-16 22:32:17 --> Controller Class Initialized
INFO - 2018-07-16 22:32:17 --> Database Driver Class Initialized
INFO - 2018-07-16 22:32:17 --> Model Class Initialized
INFO - 2018-07-16 22:32:17 --> Helper loaded: url_helper
INFO - 2018-07-16 22:32:17 --> Model Class Initialized
INFO - 2018-07-16 22:32:17 --> Final output sent to browser
DEBUG - 2018-07-16 22:32:17 --> Total execution time: 0.0903
ERROR - 2018-07-16 22:33:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:33:05 --> Config Class Initialized
INFO - 2018-07-16 22:33:05 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:33:05 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:33:05 --> Utf8 Class Initialized
INFO - 2018-07-16 22:33:05 --> URI Class Initialized
INFO - 2018-07-16 22:33:05 --> Router Class Initialized
INFO - 2018-07-16 22:33:05 --> Output Class Initialized
INFO - 2018-07-16 22:33:05 --> Security Class Initialized
DEBUG - 2018-07-16 22:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:33:05 --> Input Class Initialized
INFO - 2018-07-16 22:33:05 --> Language Class Initialized
INFO - 2018-07-16 22:33:05 --> Loader Class Initialized
INFO - 2018-07-16 22:33:05 --> Controller Class Initialized
INFO - 2018-07-16 22:33:05 --> Database Driver Class Initialized
INFO - 2018-07-16 22:33:05 --> Model Class Initialized
INFO - 2018-07-16 22:33:05 --> Helper loaded: url_helper
INFO - 2018-07-16 22:33:05 --> Model Class Initialized
INFO - 2018-07-16 22:33:05 --> Final output sent to browser
DEBUG - 2018-07-16 22:33:05 --> Total execution time: 0.1368
ERROR - 2018-07-16 22:33:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:33:18 --> Config Class Initialized
INFO - 2018-07-16 22:33:18 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:33:18 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:33:18 --> Utf8 Class Initialized
INFO - 2018-07-16 22:33:18 --> URI Class Initialized
INFO - 2018-07-16 22:33:18 --> Router Class Initialized
INFO - 2018-07-16 22:33:18 --> Output Class Initialized
INFO - 2018-07-16 22:33:18 --> Security Class Initialized
DEBUG - 2018-07-16 22:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:33:18 --> Input Class Initialized
INFO - 2018-07-16 22:33:18 --> Language Class Initialized
INFO - 2018-07-16 22:33:18 --> Loader Class Initialized
INFO - 2018-07-16 22:33:18 --> Controller Class Initialized
INFO - 2018-07-16 22:33:18 --> Database Driver Class Initialized
INFO - 2018-07-16 22:33:18 --> Model Class Initialized
INFO - 2018-07-16 22:33:18 --> Helper loaded: url_helper
INFO - 2018-07-16 22:33:18 --> Model Class Initialized
INFO - 2018-07-16 22:33:18 --> Final output sent to browser
DEBUG - 2018-07-16 22:33:18 --> Total execution time: 0.0516
ERROR - 2018-07-16 22:33:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:33:18 --> Config Class Initialized
INFO - 2018-07-16 22:33:18 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:33:18 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:33:18 --> Utf8 Class Initialized
INFO - 2018-07-16 22:33:18 --> URI Class Initialized
INFO - 2018-07-16 22:33:18 --> Router Class Initialized
INFO - 2018-07-16 22:33:18 --> Output Class Initialized
INFO - 2018-07-16 22:33:18 --> Security Class Initialized
DEBUG - 2018-07-16 22:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:33:18 --> Input Class Initialized
INFO - 2018-07-16 22:33:18 --> Language Class Initialized
INFO - 2018-07-16 22:33:18 --> Loader Class Initialized
INFO - 2018-07-16 22:33:18 --> Controller Class Initialized
INFO - 2018-07-16 22:33:18 --> Database Driver Class Initialized
INFO - 2018-07-16 22:33:18 --> Model Class Initialized
INFO - 2018-07-16 22:33:18 --> Helper loaded: url_helper
INFO - 2018-07-16 22:33:18 --> Model Class Initialized
INFO - 2018-07-16 22:33:18 --> Final output sent to browser
DEBUG - 2018-07-16 22:33:18 --> Total execution time: 0.0602
ERROR - 2018-07-16 22:33:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:33:30 --> Config Class Initialized
INFO - 2018-07-16 22:33:30 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:33:30 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:33:30 --> Utf8 Class Initialized
INFO - 2018-07-16 22:33:30 --> URI Class Initialized
INFO - 2018-07-16 22:33:30 --> Router Class Initialized
INFO - 2018-07-16 22:33:30 --> Output Class Initialized
INFO - 2018-07-16 22:33:30 --> Security Class Initialized
DEBUG - 2018-07-16 22:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:33:30 --> Input Class Initialized
INFO - 2018-07-16 22:33:30 --> Language Class Initialized
INFO - 2018-07-16 22:33:30 --> Loader Class Initialized
INFO - 2018-07-16 22:33:30 --> Controller Class Initialized
INFO - 2018-07-16 22:33:30 --> Database Driver Class Initialized
INFO - 2018-07-16 22:33:30 --> Model Class Initialized
INFO - 2018-07-16 22:33:30 --> Helper loaded: url_helper
INFO - 2018-07-16 22:33:30 --> Model Class Initialized
INFO - 2018-07-16 22:33:30 --> Final output sent to browser
DEBUG - 2018-07-16 22:33:30 --> Total execution time: 0.1845
ERROR - 2018-07-16 22:33:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:33:52 --> Config Class Initialized
INFO - 2018-07-16 22:33:52 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:33:52 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:33:52 --> Utf8 Class Initialized
INFO - 2018-07-16 22:33:52 --> URI Class Initialized
INFO - 2018-07-16 22:33:52 --> Router Class Initialized
INFO - 2018-07-16 22:33:52 --> Output Class Initialized
INFO - 2018-07-16 22:33:52 --> Security Class Initialized
DEBUG - 2018-07-16 22:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:33:52 --> Input Class Initialized
INFO - 2018-07-16 22:33:52 --> Language Class Initialized
INFO - 2018-07-16 22:33:52 --> Loader Class Initialized
INFO - 2018-07-16 22:33:52 --> Controller Class Initialized
INFO - 2018-07-16 22:33:52 --> Database Driver Class Initialized
INFO - 2018-07-16 22:33:52 --> Model Class Initialized
INFO - 2018-07-16 22:33:52 --> Helper loaded: url_helper
INFO - 2018-07-16 22:33:52 --> Model Class Initialized
INFO - 2018-07-16 22:33:52 --> Final output sent to browser
DEBUG - 2018-07-16 22:33:52 --> Total execution time: 0.0454
ERROR - 2018-07-16 22:37:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:37:13 --> Config Class Initialized
INFO - 2018-07-16 22:37:13 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:37:13 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:37:13 --> Utf8 Class Initialized
INFO - 2018-07-16 22:37:13 --> URI Class Initialized
INFO - 2018-07-16 22:37:13 --> Router Class Initialized
INFO - 2018-07-16 22:37:13 --> Output Class Initialized
INFO - 2018-07-16 22:37:13 --> Security Class Initialized
DEBUG - 2018-07-16 22:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:37:13 --> Input Class Initialized
INFO - 2018-07-16 22:37:13 --> Language Class Initialized
INFO - 2018-07-16 22:37:13 --> Loader Class Initialized
INFO - 2018-07-16 22:37:13 --> Controller Class Initialized
INFO - 2018-07-16 22:37:13 --> Database Driver Class Initialized
INFO - 2018-07-16 22:37:13 --> Model Class Initialized
INFO - 2018-07-16 22:37:13 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:37:13 --> Model Class Initialized
INFO - 2018-07-16 22:37:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 22:37:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-16 22:37:13 --> Final output sent to browser
DEBUG - 2018-07-16 22:37:13 --> Total execution time: 0.0719
ERROR - 2018-07-16 22:37:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:37:21 --> Config Class Initialized
INFO - 2018-07-16 22:37:21 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:37:21 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:37:21 --> Utf8 Class Initialized
INFO - 2018-07-16 22:37:21 --> URI Class Initialized
INFO - 2018-07-16 22:37:21 --> Router Class Initialized
INFO - 2018-07-16 22:37:21 --> Output Class Initialized
INFO - 2018-07-16 22:37:21 --> Security Class Initialized
DEBUG - 2018-07-16 22:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:37:21 --> Input Class Initialized
INFO - 2018-07-16 22:37:21 --> Language Class Initialized
INFO - 2018-07-16 22:37:21 --> Loader Class Initialized
INFO - 2018-07-16 22:37:21 --> Controller Class Initialized
INFO - 2018-07-16 22:37:21 --> Database Driver Class Initialized
INFO - 2018-07-16 22:37:21 --> Model Class Initialized
INFO - 2018-07-16 22:37:21 --> Helper loaded: url_helper
INFO - 2018-07-16 22:37:21 --> Model Class Initialized
INFO - 2018-07-16 22:37:21 --> Final output sent to browser
DEBUG - 2018-07-16 22:37:21 --> Total execution time: 0.5103
ERROR - 2018-07-16 22:37:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:37:23 --> Config Class Initialized
INFO - 2018-07-16 22:37:23 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:37:23 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:37:23 --> Utf8 Class Initialized
INFO - 2018-07-16 22:37:23 --> URI Class Initialized
INFO - 2018-07-16 22:37:23 --> Router Class Initialized
INFO - 2018-07-16 22:37:23 --> Output Class Initialized
INFO - 2018-07-16 22:37:23 --> Security Class Initialized
DEBUG - 2018-07-16 22:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:37:23 --> Input Class Initialized
INFO - 2018-07-16 22:37:23 --> Language Class Initialized
INFO - 2018-07-16 22:37:23 --> Loader Class Initialized
INFO - 2018-07-16 22:37:23 --> Controller Class Initialized
INFO - 2018-07-16 22:37:23 --> Database Driver Class Initialized
INFO - 2018-07-16 22:37:23 --> Model Class Initialized
INFO - 2018-07-16 22:37:23 --> Helper loaded: url_helper
INFO - 2018-07-16 22:37:23 --> Model Class Initialized
INFO - 2018-07-16 22:37:23 --> Final output sent to browser
DEBUG - 2018-07-16 22:37:23 --> Total execution time: 0.0502
ERROR - 2018-07-16 22:37:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:37:23 --> Config Class Initialized
INFO - 2018-07-16 22:37:23 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:37:23 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:37:23 --> Utf8 Class Initialized
INFO - 2018-07-16 22:37:23 --> URI Class Initialized
INFO - 2018-07-16 22:37:23 --> Router Class Initialized
INFO - 2018-07-16 22:37:23 --> Output Class Initialized
INFO - 2018-07-16 22:37:23 --> Security Class Initialized
DEBUG - 2018-07-16 22:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:37:23 --> Input Class Initialized
INFO - 2018-07-16 22:37:23 --> Language Class Initialized
INFO - 2018-07-16 22:37:23 --> Loader Class Initialized
INFO - 2018-07-16 22:37:23 --> Controller Class Initialized
INFO - 2018-07-16 22:37:23 --> Database Driver Class Initialized
INFO - 2018-07-16 22:37:23 --> Model Class Initialized
INFO - 2018-07-16 22:37:23 --> Helper loaded: url_helper
INFO - 2018-07-16 22:37:23 --> Model Class Initialized
INFO - 2018-07-16 22:37:23 --> Final output sent to browser
DEBUG - 2018-07-16 22:37:23 --> Total execution time: 0.0463
ERROR - 2018-07-16 22:37:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:37:28 --> Config Class Initialized
INFO - 2018-07-16 22:37:28 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:37:28 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:37:28 --> Utf8 Class Initialized
INFO - 2018-07-16 22:37:28 --> URI Class Initialized
INFO - 2018-07-16 22:37:28 --> Router Class Initialized
INFO - 2018-07-16 22:37:28 --> Output Class Initialized
INFO - 2018-07-16 22:37:28 --> Security Class Initialized
DEBUG - 2018-07-16 22:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:37:28 --> Input Class Initialized
INFO - 2018-07-16 22:37:28 --> Language Class Initialized
INFO - 2018-07-16 22:37:28 --> Loader Class Initialized
INFO - 2018-07-16 22:37:28 --> Controller Class Initialized
INFO - 2018-07-16 22:37:28 --> Database Driver Class Initialized
INFO - 2018-07-16 22:37:28 --> Model Class Initialized
INFO - 2018-07-16 22:37:28 --> Helper loaded: url_helper
INFO - 2018-07-16 22:37:28 --> Model Class Initialized
INFO - 2018-07-16 22:37:28 --> Final output sent to browser
DEBUG - 2018-07-16 22:37:28 --> Total execution time: 0.0529
ERROR - 2018-07-16 22:37:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:37:36 --> Config Class Initialized
INFO - 2018-07-16 22:37:36 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:37:36 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:37:36 --> Utf8 Class Initialized
INFO - 2018-07-16 22:37:36 --> URI Class Initialized
INFO - 2018-07-16 22:37:36 --> Router Class Initialized
INFO - 2018-07-16 22:37:36 --> Output Class Initialized
INFO - 2018-07-16 22:37:36 --> Security Class Initialized
DEBUG - 2018-07-16 22:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:37:36 --> Input Class Initialized
INFO - 2018-07-16 22:37:36 --> Language Class Initialized
INFO - 2018-07-16 22:37:36 --> Loader Class Initialized
INFO - 2018-07-16 22:37:36 --> Controller Class Initialized
INFO - 2018-07-16 22:37:36 --> Database Driver Class Initialized
INFO - 2018-07-16 22:37:36 --> Model Class Initialized
INFO - 2018-07-16 22:37:36 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:37:36 --> Model Class Initialized
ERROR - 2018-07-16 22:37:37 --> Severity: Notice --> Undefined property: Main::$d C:\xampp\htdocs\davidhood\system\core\Model.php 77
ERROR - 2018-07-16 22:37:37 --> Severity: error --> Exception: Call to a member function get_where() on null C:\xampp\htdocs\davidhood\application\models\Model.php 75
ERROR - 2018-07-16 22:38:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:38:21 --> Config Class Initialized
INFO - 2018-07-16 22:38:21 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:38:21 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:38:21 --> Utf8 Class Initialized
INFO - 2018-07-16 22:38:21 --> URI Class Initialized
INFO - 2018-07-16 22:38:21 --> Router Class Initialized
INFO - 2018-07-16 22:38:21 --> Output Class Initialized
INFO - 2018-07-16 22:38:21 --> Security Class Initialized
DEBUG - 2018-07-16 22:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:38:21 --> Input Class Initialized
INFO - 2018-07-16 22:38:21 --> Language Class Initialized
INFO - 2018-07-16 22:38:21 --> Loader Class Initialized
INFO - 2018-07-16 22:38:21 --> Controller Class Initialized
INFO - 2018-07-16 22:38:21 --> Database Driver Class Initialized
INFO - 2018-07-16 22:38:21 --> Model Class Initialized
INFO - 2018-07-16 22:38:21 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:38:21 --> Model Class Initialized
ERROR - 2018-07-16 22:38:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:38:21 --> Config Class Initialized
INFO - 2018-07-16 22:38:21 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:38:21 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:38:21 --> Utf8 Class Initialized
INFO - 2018-07-16 22:38:21 --> URI Class Initialized
INFO - 2018-07-16 22:38:21 --> Router Class Initialized
INFO - 2018-07-16 22:38:21 --> Output Class Initialized
INFO - 2018-07-16 22:38:21 --> Security Class Initialized
DEBUG - 2018-07-16 22:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:38:21 --> Input Class Initialized
INFO - 2018-07-16 22:38:21 --> Language Class Initialized
INFO - 2018-07-16 22:38:21 --> Loader Class Initialized
INFO - 2018-07-16 22:38:21 --> Controller Class Initialized
INFO - 2018-07-16 22:38:21 --> Database Driver Class Initialized
INFO - 2018-07-16 22:38:21 --> Model Class Initialized
INFO - 2018-07-16 22:38:21 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:38:21 --> Model Class Initialized
INFO - 2018-07-16 22:38:21 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 22:38:21 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-16 22:38:21 --> Final output sent to browser
DEBUG - 2018-07-16 22:38:21 --> Total execution time: 0.0545
ERROR - 2018-07-16 22:38:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:38:26 --> Config Class Initialized
INFO - 2018-07-16 22:38:26 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:38:26 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:38:26 --> Utf8 Class Initialized
INFO - 2018-07-16 22:38:26 --> URI Class Initialized
INFO - 2018-07-16 22:38:26 --> Router Class Initialized
INFO - 2018-07-16 22:38:26 --> Output Class Initialized
INFO - 2018-07-16 22:38:26 --> Security Class Initialized
DEBUG - 2018-07-16 22:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:38:26 --> Input Class Initialized
INFO - 2018-07-16 22:38:26 --> Language Class Initialized
INFO - 2018-07-16 22:38:26 --> Loader Class Initialized
INFO - 2018-07-16 22:38:26 --> Controller Class Initialized
INFO - 2018-07-16 22:38:26 --> Database Driver Class Initialized
INFO - 2018-07-16 22:38:26 --> Model Class Initialized
INFO - 2018-07-16 22:38:26 --> Helper loaded: url_helper
INFO - 2018-07-16 22:38:26 --> Model Class Initialized
INFO - 2018-07-16 22:38:26 --> Final output sent to browser
DEBUG - 2018-07-16 22:38:26 --> Total execution time: 0.0541
ERROR - 2018-07-16 22:38:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:38:35 --> Config Class Initialized
INFO - 2018-07-16 22:38:35 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:38:35 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:38:35 --> Utf8 Class Initialized
INFO - 2018-07-16 22:38:35 --> URI Class Initialized
INFO - 2018-07-16 22:38:35 --> Router Class Initialized
INFO - 2018-07-16 22:38:35 --> Output Class Initialized
INFO - 2018-07-16 22:38:35 --> Security Class Initialized
DEBUG - 2018-07-16 22:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:38:35 --> Input Class Initialized
INFO - 2018-07-16 22:38:35 --> Language Class Initialized
INFO - 2018-07-16 22:38:35 --> Loader Class Initialized
INFO - 2018-07-16 22:38:35 --> Controller Class Initialized
INFO - 2018-07-16 22:38:35 --> Database Driver Class Initialized
INFO - 2018-07-16 22:38:35 --> Model Class Initialized
INFO - 2018-07-16 22:38:35 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:38:35 --> Model Class Initialized
INFO - 2018-07-16 22:38:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 22:38:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-16 22:38:35 --> Final output sent to browser
DEBUG - 2018-07-16 22:38:35 --> Total execution time: 0.4555
ERROR - 2018-07-16 22:38:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:38:45 --> Config Class Initialized
INFO - 2018-07-16 22:38:45 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:38:45 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:38:45 --> Utf8 Class Initialized
INFO - 2018-07-16 22:38:45 --> URI Class Initialized
INFO - 2018-07-16 22:38:45 --> Router Class Initialized
INFO - 2018-07-16 22:38:45 --> Output Class Initialized
INFO - 2018-07-16 22:38:45 --> Security Class Initialized
DEBUG - 2018-07-16 22:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:38:45 --> Input Class Initialized
INFO - 2018-07-16 22:38:45 --> Language Class Initialized
INFO - 2018-07-16 22:38:45 --> Loader Class Initialized
INFO - 2018-07-16 22:38:45 --> Controller Class Initialized
INFO - 2018-07-16 22:38:45 --> Database Driver Class Initialized
INFO - 2018-07-16 22:38:45 --> Model Class Initialized
INFO - 2018-07-16 22:38:45 --> Helper loaded: url_helper
DEBUG - 2018-07-16 22:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-16 22:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-16 22:38:45 --> Model Class Initialized
INFO - 2018-07-16 22:38:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-16 22:38:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-16 22:38:45 --> Final output sent to browser
DEBUG - 2018-07-16 22:38:45 --> Total execution time: 0.0594
ERROR - 2018-07-16 22:39:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:39:17 --> Config Class Initialized
INFO - 2018-07-16 22:39:17 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:39:17 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:39:17 --> Utf8 Class Initialized
INFO - 2018-07-16 22:39:17 --> URI Class Initialized
INFO - 2018-07-16 22:39:17 --> Router Class Initialized
INFO - 2018-07-16 22:39:17 --> Output Class Initialized
INFO - 2018-07-16 22:39:17 --> Security Class Initialized
DEBUG - 2018-07-16 22:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:39:17 --> Input Class Initialized
INFO - 2018-07-16 22:39:17 --> Language Class Initialized
INFO - 2018-07-16 22:39:17 --> Loader Class Initialized
INFO - 2018-07-16 22:39:17 --> Controller Class Initialized
INFO - 2018-07-16 22:39:17 --> Database Driver Class Initialized
INFO - 2018-07-16 22:39:17 --> Model Class Initialized
INFO - 2018-07-16 22:39:17 --> Helper loaded: url_helper
INFO - 2018-07-16 22:39:17 --> Model Class Initialized
INFO - 2018-07-16 22:39:17 --> Final output sent to browser
DEBUG - 2018-07-16 22:39:17 --> Total execution time: 0.0424
ERROR - 2018-07-16 22:39:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:39:18 --> Config Class Initialized
INFO - 2018-07-16 22:39:18 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:39:18 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:39:18 --> Utf8 Class Initialized
INFO - 2018-07-16 22:39:18 --> URI Class Initialized
INFO - 2018-07-16 22:39:18 --> Router Class Initialized
INFO - 2018-07-16 22:39:18 --> Output Class Initialized
INFO - 2018-07-16 22:39:18 --> Security Class Initialized
DEBUG - 2018-07-16 22:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:39:18 --> Input Class Initialized
INFO - 2018-07-16 22:39:18 --> Language Class Initialized
INFO - 2018-07-16 22:39:18 --> Loader Class Initialized
INFO - 2018-07-16 22:39:18 --> Controller Class Initialized
INFO - 2018-07-16 22:39:18 --> Database Driver Class Initialized
INFO - 2018-07-16 22:39:18 --> Model Class Initialized
INFO - 2018-07-16 22:39:18 --> Helper loaded: url_helper
INFO - 2018-07-16 22:39:18 --> Model Class Initialized
INFO - 2018-07-16 22:39:18 --> Final output sent to browser
DEBUG - 2018-07-16 22:39:18 --> Total execution time: 0.0494
ERROR - 2018-07-16 22:39:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:39:18 --> Config Class Initialized
INFO - 2018-07-16 22:39:18 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:39:18 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:39:18 --> Utf8 Class Initialized
INFO - 2018-07-16 22:39:18 --> URI Class Initialized
INFO - 2018-07-16 22:39:18 --> Router Class Initialized
INFO - 2018-07-16 22:39:18 --> Output Class Initialized
INFO - 2018-07-16 22:39:18 --> Security Class Initialized
DEBUG - 2018-07-16 22:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:39:18 --> Input Class Initialized
INFO - 2018-07-16 22:39:18 --> Language Class Initialized
INFO - 2018-07-16 22:39:18 --> Loader Class Initialized
INFO - 2018-07-16 22:39:18 --> Controller Class Initialized
INFO - 2018-07-16 22:39:19 --> Database Driver Class Initialized
INFO - 2018-07-16 22:39:19 --> Model Class Initialized
INFO - 2018-07-16 22:39:19 --> Helper loaded: url_helper
INFO - 2018-07-16 22:39:19 --> Model Class Initialized
INFO - 2018-07-16 22:39:19 --> Final output sent to browser
DEBUG - 2018-07-16 22:39:19 --> Total execution time: 0.0494
ERROR - 2018-07-16 22:39:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-16 22:39:19 --> Config Class Initialized
INFO - 2018-07-16 22:39:19 --> Hooks Class Initialized
DEBUG - 2018-07-16 22:39:19 --> UTF-8 Support Enabled
INFO - 2018-07-16 22:39:19 --> Utf8 Class Initialized
INFO - 2018-07-16 22:39:19 --> URI Class Initialized
INFO - 2018-07-16 22:39:19 --> Router Class Initialized
INFO - 2018-07-16 22:39:19 --> Output Class Initialized
INFO - 2018-07-16 22:39:19 --> Security Class Initialized
DEBUG - 2018-07-16 22:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-16 22:39:19 --> Input Class Initialized
INFO - 2018-07-16 22:39:19 --> Language Class Initialized
INFO - 2018-07-16 22:39:19 --> Loader Class Initialized
INFO - 2018-07-16 22:39:19 --> Controller Class Initialized
INFO - 2018-07-16 22:39:19 --> Database Driver Class Initialized
INFO - 2018-07-16 22:39:19 --> Model Class Initialized
INFO - 2018-07-16 22:39:19 --> Helper loaded: url_helper
INFO - 2018-07-16 22:39:19 --> Model Class Initialized
INFO - 2018-07-16 22:39:19 --> Final output sent to browser
DEBUG - 2018-07-16 22:39:19 --> Total execution time: 0.0448
