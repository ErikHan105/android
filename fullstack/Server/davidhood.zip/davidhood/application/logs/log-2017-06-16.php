<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-16 05:21:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-16 05:21:55 --> Config Class Initialized
INFO - 2017-06-16 05:21:55 --> Hooks Class Initialized
DEBUG - 2017-06-16 05:21:55 --> UTF-8 Support Enabled
INFO - 2017-06-16 05:21:55 --> Utf8 Class Initialized
INFO - 2017-06-16 05:21:55 --> URI Class Initialized
INFO - 2017-06-16 05:21:55 --> Router Class Initialized
INFO - 2017-06-16 05:21:55 --> Output Class Initialized
INFO - 2017-06-16 05:21:55 --> Security Class Initialized
DEBUG - 2017-06-16 05:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-16 05:21:55 --> Input Class Initialized
INFO - 2017-06-16 05:21:55 --> Language Class Initialized
INFO - 2017-06-16 05:21:55 --> Loader Class Initialized
INFO - 2017-06-16 05:21:55 --> Controller Class Initialized
INFO - 2017-06-16 05:21:55 --> Database Driver Class Initialized
INFO - 2017-06-16 05:21:55 --> Model Class Initialized
INFO - 2017-06-16 05:21:55 --> Helper loaded: form_helper
INFO - 2017-06-16 05:21:55 --> Helper loaded: url_helper
INFO - 2017-06-16 05:21:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-06-16 05:21:55 --> Final output sent to browser
DEBUG - 2017-06-16 05:21:55 --> Total execution time: 0.0580
ERROR - 2017-06-16 05:21:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-16 05:21:57 --> Config Class Initialized
INFO - 2017-06-16 05:21:57 --> Hooks Class Initialized
DEBUG - 2017-06-16 05:21:57 --> UTF-8 Support Enabled
INFO - 2017-06-16 05:21:57 --> Utf8 Class Initialized
INFO - 2017-06-16 05:21:57 --> URI Class Initialized
INFO - 2017-06-16 05:21:57 --> Router Class Initialized
INFO - 2017-06-16 05:21:57 --> Output Class Initialized
INFO - 2017-06-16 05:21:57 --> Security Class Initialized
DEBUG - 2017-06-16 05:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-16 05:21:57 --> Input Class Initialized
INFO - 2017-06-16 05:21:57 --> Language Class Initialized
INFO - 2017-06-16 05:21:57 --> Loader Class Initialized
INFO - 2017-06-16 05:21:57 --> Controller Class Initialized
INFO - 2017-06-16 05:21:57 --> Database Driver Class Initialized
INFO - 2017-06-16 05:21:57 --> Model Class Initialized
INFO - 2017-06-16 05:21:57 --> Helper loaded: form_helper
INFO - 2017-06-16 05:21:57 --> Helper loaded: url_helper
INFO - 2017-06-16 05:21:57 --> Model Class Initialized
ERROR - 2017-06-16 05:21:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-16 05:21:57 --> Config Class Initialized
INFO - 2017-06-16 05:21:57 --> Hooks Class Initialized
DEBUG - 2017-06-16 05:21:57 --> UTF-8 Support Enabled
INFO - 2017-06-16 05:21:57 --> Utf8 Class Initialized
INFO - 2017-06-16 05:21:57 --> URI Class Initialized
INFO - 2017-06-16 05:21:57 --> Router Class Initialized
INFO - 2017-06-16 05:21:57 --> Output Class Initialized
INFO - 2017-06-16 05:21:57 --> Security Class Initialized
DEBUG - 2017-06-16 05:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-16 05:21:57 --> Input Class Initialized
INFO - 2017-06-16 05:21:57 --> Language Class Initialized
INFO - 2017-06-16 05:21:57 --> Loader Class Initialized
INFO - 2017-06-16 05:21:57 --> Controller Class Initialized
INFO - 2017-06-16 05:21:57 --> Database Driver Class Initialized
INFO - 2017-06-16 05:21:57 --> Model Class Initialized
INFO - 2017-06-16 05:21:57 --> Helper loaded: form_helper
INFO - 2017-06-16 05:21:57 --> Helper loaded: url_helper
INFO - 2017-06-16 05:21:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-16 05:21:57 --> Model Class Initialized
INFO - 2017-06-16 05:21:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-16 05:21:57 --> Final output sent to browser
DEBUG - 2017-06-16 05:21:57 --> Total execution time: 0.0500
ERROR - 2017-06-16 05:22:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-16 05:22:00 --> Config Class Initialized
INFO - 2017-06-16 05:22:00 --> Hooks Class Initialized
DEBUG - 2017-06-16 05:22:00 --> UTF-8 Support Enabled
INFO - 2017-06-16 05:22:00 --> Utf8 Class Initialized
INFO - 2017-06-16 05:22:00 --> URI Class Initialized
INFO - 2017-06-16 05:22:00 --> Router Class Initialized
INFO - 2017-06-16 05:22:00 --> Output Class Initialized
INFO - 2017-06-16 05:22:00 --> Security Class Initialized
DEBUG - 2017-06-16 05:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-16 05:22:00 --> Input Class Initialized
INFO - 2017-06-16 05:22:00 --> Language Class Initialized
INFO - 2017-06-16 05:22:00 --> Loader Class Initialized
INFO - 2017-06-16 05:22:00 --> Controller Class Initialized
INFO - 2017-06-16 05:22:00 --> Database Driver Class Initialized
INFO - 2017-06-16 05:22:00 --> Model Class Initialized
INFO - 2017-06-16 05:22:00 --> Helper loaded: form_helper
INFO - 2017-06-16 05:22:00 --> Helper loaded: url_helper
INFO - 2017-06-16 05:22:00 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-16 05:22:00 --> Model Class Initialized
INFO - 2017-06-16 05:22:00 --> File loaded: C:\xampp\htdocs\mystage\application\views\users.php
INFO - 2017-06-16 05:22:00 --> Final output sent to browser
DEBUG - 2017-06-16 05:22:00 --> Total execution time: 0.0550
ERROR - 2017-06-16 05:22:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-16 05:22:03 --> Config Class Initialized
INFO - 2017-06-16 05:22:03 --> Hooks Class Initialized
DEBUG - 2017-06-16 05:22:03 --> UTF-8 Support Enabled
INFO - 2017-06-16 05:22:03 --> Utf8 Class Initialized
INFO - 2017-06-16 05:22:03 --> URI Class Initialized
INFO - 2017-06-16 05:22:03 --> Router Class Initialized
INFO - 2017-06-16 05:22:03 --> Output Class Initialized
INFO - 2017-06-16 05:22:03 --> Security Class Initialized
DEBUG - 2017-06-16 05:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-16 05:22:03 --> Input Class Initialized
INFO - 2017-06-16 05:22:03 --> Language Class Initialized
INFO - 2017-06-16 05:22:03 --> Loader Class Initialized
INFO - 2017-06-16 05:22:03 --> Controller Class Initialized
INFO - 2017-06-16 05:22:03 --> Database Driver Class Initialized
INFO - 2017-06-16 05:22:03 --> Model Class Initialized
INFO - 2017-06-16 05:22:03 --> Helper loaded: form_helper
INFO - 2017-06-16 05:22:03 --> Helper loaded: url_helper
INFO - 2017-06-16 05:22:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-16 05:22:03 --> Model Class Initialized
INFO - 2017-06-16 05:22:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-16 05:22:03 --> Final output sent to browser
DEBUG - 2017-06-16 05:22:03 --> Total execution time: 0.0670
ERROR - 2017-06-16 05:31:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-16 05:31:28 --> Config Class Initialized
INFO - 2017-06-16 05:31:28 --> Hooks Class Initialized
DEBUG - 2017-06-16 05:31:28 --> UTF-8 Support Enabled
INFO - 2017-06-16 05:31:28 --> Utf8 Class Initialized
INFO - 2017-06-16 05:31:28 --> URI Class Initialized
INFO - 2017-06-16 05:31:28 --> Router Class Initialized
INFO - 2017-06-16 05:31:28 --> Output Class Initialized
INFO - 2017-06-16 05:31:28 --> Security Class Initialized
DEBUG - 2017-06-16 05:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-16 05:31:28 --> Input Class Initialized
INFO - 2017-06-16 05:31:28 --> Language Class Initialized
INFO - 2017-06-16 05:31:28 --> Loader Class Initialized
INFO - 2017-06-16 05:31:28 --> Controller Class Initialized
INFO - 2017-06-16 05:31:28 --> Database Driver Class Initialized
INFO - 2017-06-16 05:31:28 --> Model Class Initialized
INFO - 2017-06-16 05:31:28 --> Helper loaded: form_helper
INFO - 2017-06-16 05:31:28 --> Helper loaded: url_helper
INFO - 2017-06-16 05:31:28 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-16 05:31:28 --> Model Class Initialized
INFO - 2017-06-16 05:31:28 --> File loaded: C:\xampp\htdocs\mystage\application\views\users.php
INFO - 2017-06-16 05:31:28 --> Final output sent to browser
DEBUG - 2017-06-16 05:31:28 --> Total execution time: 0.0570
ERROR - 2017-06-16 05:31:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-16 05:31:30 --> Config Class Initialized
INFO - 2017-06-16 05:31:30 --> Hooks Class Initialized
DEBUG - 2017-06-16 05:31:30 --> UTF-8 Support Enabled
INFO - 2017-06-16 05:31:30 --> Utf8 Class Initialized
INFO - 2017-06-16 05:31:30 --> URI Class Initialized
INFO - 2017-06-16 05:31:30 --> Router Class Initialized
INFO - 2017-06-16 05:31:30 --> Output Class Initialized
INFO - 2017-06-16 05:31:30 --> Security Class Initialized
DEBUG - 2017-06-16 05:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-16 05:31:30 --> Input Class Initialized
INFO - 2017-06-16 05:31:30 --> Language Class Initialized
INFO - 2017-06-16 05:31:30 --> Loader Class Initialized
INFO - 2017-06-16 05:31:30 --> Controller Class Initialized
INFO - 2017-06-16 05:31:30 --> Database Driver Class Initialized
INFO - 2017-06-16 05:31:30 --> Model Class Initialized
INFO - 2017-06-16 05:31:30 --> Helper loaded: form_helper
INFO - 2017-06-16 05:31:30 --> Helper loaded: url_helper
INFO - 2017-06-16 05:31:30 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-16 05:31:30 --> Model Class Initialized
INFO - 2017-06-16 05:31:30 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-16 05:31:30 --> Final output sent to browser
DEBUG - 2017-06-16 05:31:30 --> Total execution time: 0.0710
ERROR - 2017-06-16 05:31:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-16 05:31:31 --> Config Class Initialized
INFO - 2017-06-16 05:31:31 --> Hooks Class Initialized
DEBUG - 2017-06-16 05:31:31 --> UTF-8 Support Enabled
INFO - 2017-06-16 05:31:31 --> Utf8 Class Initialized
INFO - 2017-06-16 05:31:31 --> URI Class Initialized
INFO - 2017-06-16 05:31:31 --> Router Class Initialized
INFO - 2017-06-16 05:31:31 --> Output Class Initialized
INFO - 2017-06-16 05:31:31 --> Security Class Initialized
DEBUG - 2017-06-16 05:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-16 05:31:31 --> Input Class Initialized
INFO - 2017-06-16 05:31:31 --> Language Class Initialized
INFO - 2017-06-16 05:31:31 --> Loader Class Initialized
INFO - 2017-06-16 05:31:31 --> Controller Class Initialized
INFO - 2017-06-16 05:31:31 --> Database Driver Class Initialized
INFO - 2017-06-16 05:31:31 --> Model Class Initialized
INFO - 2017-06-16 05:31:31 --> Helper loaded: form_helper
INFO - 2017-06-16 05:31:31 --> Helper loaded: url_helper
INFO - 2017-06-16 05:31:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-16 05:31:31 --> Model Class Initialized
INFO - 2017-06-16 05:31:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-16 05:31:31 --> Final output sent to browser
DEBUG - 2017-06-16 05:31:31 --> Total execution time: 0.0720
ERROR - 2017-06-16 05:31:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-16 05:31:33 --> Config Class Initialized
INFO - 2017-06-16 05:31:33 --> Hooks Class Initialized
DEBUG - 2017-06-16 05:31:33 --> UTF-8 Support Enabled
INFO - 2017-06-16 05:31:33 --> Utf8 Class Initialized
INFO - 2017-06-16 05:31:34 --> URI Class Initialized
INFO - 2017-06-16 05:31:34 --> Router Class Initialized
INFO - 2017-06-16 05:31:34 --> Output Class Initialized
INFO - 2017-06-16 05:31:34 --> Security Class Initialized
DEBUG - 2017-06-16 05:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-16 05:31:34 --> Input Class Initialized
INFO - 2017-06-16 05:31:34 --> Language Class Initialized
INFO - 2017-06-16 05:31:34 --> Loader Class Initialized
INFO - 2017-06-16 05:31:34 --> Controller Class Initialized
INFO - 2017-06-16 05:31:34 --> Database Driver Class Initialized
INFO - 2017-06-16 05:31:34 --> Model Class Initialized
INFO - 2017-06-16 05:31:34 --> Helper loaded: form_helper
INFO - 2017-06-16 05:31:34 --> Helper loaded: url_helper
INFO - 2017-06-16 05:31:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-16 05:31:34 --> Model Class Initialized
INFO - 2017-06-16 05:31:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-06-16 05:31:34 --> Final output sent to browser
DEBUG - 2017-06-16 05:31:34 --> Total execution time: 0.0770
ERROR - 2017-06-16 05:31:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-16 05:31:38 --> Config Class Initialized
INFO - 2017-06-16 05:31:38 --> Hooks Class Initialized
DEBUG - 2017-06-16 05:31:38 --> UTF-8 Support Enabled
INFO - 2017-06-16 05:31:38 --> Utf8 Class Initialized
INFO - 2017-06-16 05:31:38 --> URI Class Initialized
INFO - 2017-06-16 05:31:38 --> Router Class Initialized
INFO - 2017-06-16 05:31:38 --> Output Class Initialized
INFO - 2017-06-16 05:31:38 --> Security Class Initialized
DEBUG - 2017-06-16 05:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-16 05:31:38 --> Input Class Initialized
INFO - 2017-06-16 05:31:38 --> Language Class Initialized
INFO - 2017-06-16 05:31:38 --> Loader Class Initialized
INFO - 2017-06-16 05:31:38 --> Controller Class Initialized
INFO - 2017-06-16 05:31:38 --> Database Driver Class Initialized
INFO - 2017-06-16 05:31:38 --> Model Class Initialized
INFO - 2017-06-16 05:31:38 --> Helper loaded: form_helper
INFO - 2017-06-16 05:31:38 --> Helper loaded: url_helper
INFO - 2017-06-16 05:31:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-16 05:31:38 --> Model Class Initialized
INFO - 2017-06-16 05:31:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-06-16 05:31:38 --> Final output sent to browser
DEBUG - 2017-06-16 05:31:38 --> Total execution time: 0.0630
ERROR - 2017-06-16 05:31:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-16 05:31:40 --> Config Class Initialized
INFO - 2017-06-16 05:31:40 --> Hooks Class Initialized
DEBUG - 2017-06-16 05:31:40 --> UTF-8 Support Enabled
INFO - 2017-06-16 05:31:40 --> Utf8 Class Initialized
INFO - 2017-06-16 05:31:40 --> URI Class Initialized
INFO - 2017-06-16 05:31:40 --> Router Class Initialized
INFO - 2017-06-16 05:31:40 --> Output Class Initialized
INFO - 2017-06-16 05:31:40 --> Security Class Initialized
DEBUG - 2017-06-16 05:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-16 05:31:40 --> Input Class Initialized
INFO - 2017-06-16 05:31:40 --> Language Class Initialized
INFO - 2017-06-16 05:31:40 --> Loader Class Initialized
INFO - 2017-06-16 05:31:40 --> Controller Class Initialized
INFO - 2017-06-16 05:31:40 --> Database Driver Class Initialized
INFO - 2017-06-16 05:31:40 --> Model Class Initialized
INFO - 2017-06-16 05:31:40 --> Helper loaded: form_helper
INFO - 2017-06-16 05:31:40 --> Helper loaded: url_helper
INFO - 2017-06-16 05:31:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-16 05:31:40 --> Model Class Initialized
INFO - 2017-06-16 05:31:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-06-16 05:31:40 --> Final output sent to browser
DEBUG - 2017-06-16 05:31:40 --> Total execution time: 0.0530
ERROR - 2017-06-16 05:31:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-16 05:31:40 --> Config Class Initialized
INFO - 2017-06-16 05:31:40 --> Hooks Class Initialized
DEBUG - 2017-06-16 05:31:41 --> UTF-8 Support Enabled
INFO - 2017-06-16 05:31:41 --> Utf8 Class Initialized
INFO - 2017-06-16 05:31:41 --> URI Class Initialized
INFO - 2017-06-16 05:31:41 --> Router Class Initialized
INFO - 2017-06-16 05:31:41 --> Output Class Initialized
INFO - 2017-06-16 05:31:41 --> Security Class Initialized
DEBUG - 2017-06-16 05:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-16 05:31:41 --> Input Class Initialized
INFO - 2017-06-16 05:31:41 --> Language Class Initialized
INFO - 2017-06-16 05:31:41 --> Loader Class Initialized
INFO - 2017-06-16 05:31:41 --> Controller Class Initialized
INFO - 2017-06-16 05:31:41 --> Database Driver Class Initialized
INFO - 2017-06-16 05:31:41 --> Model Class Initialized
INFO - 2017-06-16 05:31:41 --> Helper loaded: form_helper
INFO - 2017-06-16 05:31:41 --> Helper loaded: url_helper
INFO - 2017-06-16 05:31:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-16 05:31:41 --> Model Class Initialized
INFO - 2017-06-16 05:31:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-06-16 05:31:41 --> Final output sent to browser
DEBUG - 2017-06-16 05:31:41 --> Total execution time: 0.0640
ERROR - 2017-06-16 05:31:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-16 05:31:42 --> Config Class Initialized
INFO - 2017-06-16 05:31:42 --> Hooks Class Initialized
DEBUG - 2017-06-16 05:31:42 --> UTF-8 Support Enabled
INFO - 2017-06-16 05:31:42 --> Utf8 Class Initialized
INFO - 2017-06-16 05:31:42 --> URI Class Initialized
INFO - 2017-06-16 05:31:42 --> Router Class Initialized
INFO - 2017-06-16 05:31:42 --> Output Class Initialized
INFO - 2017-06-16 05:31:42 --> Security Class Initialized
DEBUG - 2017-06-16 05:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-16 05:31:42 --> Input Class Initialized
INFO - 2017-06-16 05:31:42 --> Language Class Initialized
INFO - 2017-06-16 05:31:42 --> Loader Class Initialized
INFO - 2017-06-16 05:31:42 --> Controller Class Initialized
INFO - 2017-06-16 05:31:42 --> Database Driver Class Initialized
INFO - 2017-06-16 05:31:42 --> Model Class Initialized
INFO - 2017-06-16 05:31:42 --> Helper loaded: form_helper
INFO - 2017-06-16 05:31:42 --> Helper loaded: url_helper
INFO - 2017-06-16 05:31:42 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-16 05:31:42 --> Model Class Initialized
INFO - 2017-06-16 05:31:42 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-06-16 05:31:42 --> Final output sent to browser
DEBUG - 2017-06-16 05:31:42 --> Total execution time: 0.0620
ERROR - 2017-06-16 05:31:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-16 05:31:43 --> Config Class Initialized
INFO - 2017-06-16 05:31:43 --> Hooks Class Initialized
DEBUG - 2017-06-16 05:31:43 --> UTF-8 Support Enabled
INFO - 2017-06-16 05:31:43 --> Utf8 Class Initialized
INFO - 2017-06-16 05:31:43 --> URI Class Initialized
INFO - 2017-06-16 05:31:43 --> Router Class Initialized
INFO - 2017-06-16 05:31:43 --> Output Class Initialized
INFO - 2017-06-16 05:31:43 --> Security Class Initialized
DEBUG - 2017-06-16 05:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-16 05:31:43 --> Input Class Initialized
INFO - 2017-06-16 05:31:43 --> Language Class Initialized
INFO - 2017-06-16 05:31:43 --> Loader Class Initialized
INFO - 2017-06-16 05:31:43 --> Controller Class Initialized
INFO - 2017-06-16 05:31:43 --> Database Driver Class Initialized
INFO - 2017-06-16 05:31:43 --> Model Class Initialized
INFO - 2017-06-16 05:31:43 --> Helper loaded: form_helper
INFO - 2017-06-16 05:31:43 --> Helper loaded: url_helper
INFO - 2017-06-16 05:31:43 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-16 05:31:43 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-06-16 05:31:43 --> Final output sent to browser
DEBUG - 2017-06-16 05:31:43 --> Total execution time: 0.0570
ERROR - 2017-06-16 05:44:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-16 05:44:56 --> Config Class Initialized
INFO - 2017-06-16 05:44:56 --> Hooks Class Initialized
DEBUG - 2017-06-16 05:44:56 --> UTF-8 Support Enabled
INFO - 2017-06-16 05:44:56 --> Utf8 Class Initialized
INFO - 2017-06-16 05:44:56 --> URI Class Initialized
INFO - 2017-06-16 05:44:56 --> Router Class Initialized
INFO - 2017-06-16 05:44:56 --> Output Class Initialized
INFO - 2017-06-16 05:44:56 --> Security Class Initialized
DEBUG - 2017-06-16 05:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-16 05:44:56 --> Input Class Initialized
INFO - 2017-06-16 05:44:56 --> Language Class Initialized
INFO - 2017-06-16 05:44:56 --> Loader Class Initialized
INFO - 2017-06-16 05:44:56 --> Controller Class Initialized
INFO - 2017-06-16 05:44:56 --> Database Driver Class Initialized
INFO - 2017-06-16 05:44:56 --> Model Class Initialized
INFO - 2017-06-16 05:44:56 --> Helper loaded: form_helper
INFO - 2017-06-16 05:44:56 --> Helper loaded: url_helper
INFO - 2017-06-16 05:44:56 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-16 05:44:56 --> Model Class Initialized
INFO - 2017-06-16 05:44:56 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-16 05:44:56 --> Final output sent to browser
DEBUG - 2017-06-16 05:44:56 --> Total execution time: 0.0970
ERROR - 2017-06-16 05:45:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-16 05:45:02 --> Config Class Initialized
INFO - 2017-06-16 05:45:02 --> Hooks Class Initialized
DEBUG - 2017-06-16 05:45:02 --> UTF-8 Support Enabled
INFO - 2017-06-16 05:45:02 --> Utf8 Class Initialized
INFO - 2017-06-16 05:45:02 --> URI Class Initialized
INFO - 2017-06-16 05:45:02 --> Router Class Initialized
INFO - 2017-06-16 05:45:03 --> Output Class Initialized
INFO - 2017-06-16 05:45:03 --> Security Class Initialized
DEBUG - 2017-06-16 05:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-16 05:45:03 --> Input Class Initialized
INFO - 2017-06-16 05:45:03 --> Language Class Initialized
INFO - 2017-06-16 05:45:03 --> Loader Class Initialized
INFO - 2017-06-16 05:45:03 --> Controller Class Initialized
INFO - 2017-06-16 05:45:03 --> Database Driver Class Initialized
INFO - 2017-06-16 05:45:03 --> Model Class Initialized
INFO - 2017-06-16 05:45:03 --> Helper loaded: form_helper
INFO - 2017-06-16 05:45:03 --> Helper loaded: url_helper
INFO - 2017-06-16 05:45:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-16 05:45:03 --> Model Class Initialized
INFO - 2017-06-16 05:45:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\users.php
INFO - 2017-06-16 05:45:03 --> Final output sent to browser
DEBUG - 2017-06-16 05:45:03 --> Total execution time: 0.0770
