<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-20 04:51:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 04:51:15 --> Config Class Initialized
INFO - 2018-07-20 04:51:15 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:51:15 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:51:15 --> Utf8 Class Initialized
INFO - 2018-07-20 04:51:15 --> URI Class Initialized
DEBUG - 2018-07-20 04:51:15 --> No URI present. Default controller set.
INFO - 2018-07-20 04:51:15 --> Router Class Initialized
INFO - 2018-07-20 04:51:15 --> Output Class Initialized
INFO - 2018-07-20 04:51:15 --> Security Class Initialized
DEBUG - 2018-07-20 04:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:51:15 --> Input Class Initialized
INFO - 2018-07-20 04:51:15 --> Language Class Initialized
INFO - 2018-07-20 04:51:15 --> Loader Class Initialized
INFO - 2018-07-20 04:51:15 --> Controller Class Initialized
INFO - 2018-07-20 04:51:15 --> Database Driver Class Initialized
INFO - 2018-07-20 04:51:15 --> Model Class Initialized
INFO - 2018-07-20 04:51:15 --> Helper loaded: url_helper
DEBUG - 2018-07-20 04:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:51:15 --> Model Class Initialized
INFO - 2018-07-20 04:51:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-20 04:51:15 --> Final output sent to browser
DEBUG - 2018-07-20 04:51:15 --> Total execution time: 0.3239
ERROR - 2018-07-20 04:51:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 04:51:21 --> Config Class Initialized
INFO - 2018-07-20 04:51:21 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:51:21 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:51:21 --> Utf8 Class Initialized
INFO - 2018-07-20 04:51:21 --> URI Class Initialized
DEBUG - 2018-07-20 04:51:21 --> No URI present. Default controller set.
INFO - 2018-07-20 04:51:21 --> Router Class Initialized
INFO - 2018-07-20 04:51:21 --> Output Class Initialized
INFO - 2018-07-20 04:51:21 --> Security Class Initialized
DEBUG - 2018-07-20 04:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:51:21 --> Input Class Initialized
INFO - 2018-07-20 04:51:21 --> Language Class Initialized
INFO - 2018-07-20 04:51:21 --> Loader Class Initialized
INFO - 2018-07-20 04:51:21 --> Controller Class Initialized
INFO - 2018-07-20 04:51:21 --> Database Driver Class Initialized
INFO - 2018-07-20 04:51:21 --> Model Class Initialized
INFO - 2018-07-20 04:51:21 --> Helper loaded: url_helper
DEBUG - 2018-07-20 04:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:51:21 --> Model Class Initialized
INFO - 2018-07-20 04:51:21 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-20 04:51:21 --> Final output sent to browser
DEBUG - 2018-07-20 04:51:21 --> Total execution time: 0.0352
ERROR - 2018-07-20 04:51:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 04:51:22 --> Config Class Initialized
INFO - 2018-07-20 04:51:22 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:51:22 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:51:22 --> Utf8 Class Initialized
INFO - 2018-07-20 04:51:22 --> URI Class Initialized
DEBUG - 2018-07-20 04:51:22 --> No URI present. Default controller set.
INFO - 2018-07-20 04:51:22 --> Router Class Initialized
INFO - 2018-07-20 04:51:22 --> Output Class Initialized
INFO - 2018-07-20 04:51:22 --> Security Class Initialized
DEBUG - 2018-07-20 04:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:51:22 --> Input Class Initialized
INFO - 2018-07-20 04:51:22 --> Language Class Initialized
INFO - 2018-07-20 04:51:22 --> Loader Class Initialized
INFO - 2018-07-20 04:51:22 --> Controller Class Initialized
INFO - 2018-07-20 04:51:22 --> Database Driver Class Initialized
INFO - 2018-07-20 04:51:22 --> Model Class Initialized
INFO - 2018-07-20 04:51:22 --> Helper loaded: url_helper
DEBUG - 2018-07-20 04:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:51:22 --> Model Class Initialized
INFO - 2018-07-20 04:51:22 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-20 04:51:22 --> Final output sent to browser
DEBUG - 2018-07-20 04:51:22 --> Total execution time: 0.0393
ERROR - 2018-07-20 04:51:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 04:51:25 --> Config Class Initialized
INFO - 2018-07-20 04:51:25 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:51:25 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:51:25 --> Utf8 Class Initialized
INFO - 2018-07-20 04:51:25 --> URI Class Initialized
INFO - 2018-07-20 04:51:25 --> Router Class Initialized
INFO - 2018-07-20 04:51:25 --> Output Class Initialized
INFO - 2018-07-20 04:51:25 --> Security Class Initialized
DEBUG - 2018-07-20 04:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:51:25 --> Input Class Initialized
INFO - 2018-07-20 04:51:25 --> Language Class Initialized
INFO - 2018-07-20 04:51:25 --> Loader Class Initialized
INFO - 2018-07-20 04:51:25 --> Controller Class Initialized
INFO - 2018-07-20 04:51:25 --> Database Driver Class Initialized
INFO - 2018-07-20 04:51:25 --> Model Class Initialized
INFO - 2018-07-20 04:51:25 --> Helper loaded: url_helper
DEBUG - 2018-07-20 04:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:51:25 --> Model Class Initialized
ERROR - 2018-07-20 04:51:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 04:51:25 --> Config Class Initialized
INFO - 2018-07-20 04:51:25 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:51:25 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:51:25 --> Utf8 Class Initialized
INFO - 2018-07-20 04:51:25 --> URI Class Initialized
INFO - 2018-07-20 04:51:25 --> Router Class Initialized
INFO - 2018-07-20 04:51:25 --> Output Class Initialized
INFO - 2018-07-20 04:51:25 --> Security Class Initialized
DEBUG - 2018-07-20 04:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:51:25 --> Input Class Initialized
INFO - 2018-07-20 04:51:25 --> Language Class Initialized
INFO - 2018-07-20 04:51:25 --> Loader Class Initialized
INFO - 2018-07-20 04:51:25 --> Controller Class Initialized
INFO - 2018-07-20 04:51:25 --> Database Driver Class Initialized
INFO - 2018-07-20 04:51:25 --> Model Class Initialized
INFO - 2018-07-20 04:51:25 --> Helper loaded: url_helper
DEBUG - 2018-07-20 04:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:51:25 --> Model Class Initialized
INFO - 2018-07-20 04:51:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 04:51:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-20 04:51:25 --> Final output sent to browser
DEBUG - 2018-07-20 04:51:25 --> Total execution time: 0.1180
ERROR - 2018-07-20 04:51:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 04:51:30 --> Config Class Initialized
INFO - 2018-07-20 04:51:30 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:51:30 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:51:30 --> Utf8 Class Initialized
INFO - 2018-07-20 04:51:30 --> URI Class Initialized
INFO - 2018-07-20 04:51:30 --> Router Class Initialized
INFO - 2018-07-20 04:51:30 --> Output Class Initialized
INFO - 2018-07-20 04:51:30 --> Security Class Initialized
DEBUG - 2018-07-20 04:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:51:30 --> Input Class Initialized
INFO - 2018-07-20 04:51:30 --> Language Class Initialized
INFO - 2018-07-20 04:51:30 --> Loader Class Initialized
INFO - 2018-07-20 04:51:30 --> Controller Class Initialized
INFO - 2018-07-20 04:51:30 --> Database Driver Class Initialized
INFO - 2018-07-20 04:51:30 --> Model Class Initialized
INFO - 2018-07-20 04:51:30 --> Helper loaded: url_helper
DEBUG - 2018-07-20 04:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:51:30 --> Model Class Initialized
INFO - 2018-07-20 04:51:30 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 04:51:30 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-20 04:51:30 --> Final output sent to browser
DEBUG - 2018-07-20 04:51:30 --> Total execution time: 0.0396
ERROR - 2018-07-20 04:51:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 04:51:33 --> Config Class Initialized
INFO - 2018-07-20 04:51:33 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:51:33 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:51:33 --> Utf8 Class Initialized
INFO - 2018-07-20 04:51:33 --> URI Class Initialized
INFO - 2018-07-20 04:51:33 --> Router Class Initialized
INFO - 2018-07-20 04:51:33 --> Output Class Initialized
INFO - 2018-07-20 04:51:33 --> Security Class Initialized
DEBUG - 2018-07-20 04:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:51:33 --> Input Class Initialized
INFO - 2018-07-20 04:51:33 --> Language Class Initialized
INFO - 2018-07-20 04:51:33 --> Loader Class Initialized
INFO - 2018-07-20 04:51:33 --> Controller Class Initialized
INFO - 2018-07-20 04:51:33 --> Database Driver Class Initialized
INFO - 2018-07-20 04:51:33 --> Model Class Initialized
INFO - 2018-07-20 04:51:33 --> Helper loaded: url_helper
DEBUG - 2018-07-20 04:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:51:33 --> Model Class Initialized
INFO - 2018-07-20 04:51:33 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 04:51:33 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-20 04:51:33 --> Final output sent to browser
DEBUG - 2018-07-20 04:51:33 --> Total execution time: 0.0538
ERROR - 2018-07-20 04:53:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 04:53:18 --> Config Class Initialized
INFO - 2018-07-20 04:53:18 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:53:18 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:53:18 --> Utf8 Class Initialized
INFO - 2018-07-20 04:53:18 --> URI Class Initialized
INFO - 2018-07-20 04:53:18 --> Router Class Initialized
INFO - 2018-07-20 04:53:18 --> Output Class Initialized
INFO - 2018-07-20 04:53:18 --> Security Class Initialized
DEBUG - 2018-07-20 04:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:53:18 --> Input Class Initialized
INFO - 2018-07-20 04:53:18 --> Language Class Initialized
INFO - 2018-07-20 04:53:18 --> Loader Class Initialized
INFO - 2018-07-20 04:53:18 --> Controller Class Initialized
INFO - 2018-07-20 04:53:18 --> Database Driver Class Initialized
INFO - 2018-07-20 04:53:18 --> Model Class Initialized
INFO - 2018-07-20 04:53:18 --> Helper loaded: url_helper
DEBUG - 2018-07-20 04:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:53:18 --> Model Class Initialized
INFO - 2018-07-20 04:53:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 04:53:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-20 04:53:18 --> Final output sent to browser
DEBUG - 2018-07-20 04:53:18 --> Total execution time: 0.0393
ERROR - 2018-07-20 04:53:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 04:53:27 --> Config Class Initialized
INFO - 2018-07-20 04:53:27 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:53:27 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:53:27 --> Utf8 Class Initialized
INFO - 2018-07-20 04:53:27 --> URI Class Initialized
INFO - 2018-07-20 04:53:27 --> Router Class Initialized
INFO - 2018-07-20 04:53:27 --> Output Class Initialized
INFO - 2018-07-20 04:53:27 --> Security Class Initialized
DEBUG - 2018-07-20 04:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:53:27 --> Input Class Initialized
INFO - 2018-07-20 04:53:27 --> Language Class Initialized
INFO - 2018-07-20 04:53:27 --> Loader Class Initialized
INFO - 2018-07-20 04:53:27 --> Controller Class Initialized
INFO - 2018-07-20 04:53:27 --> Database Driver Class Initialized
INFO - 2018-07-20 04:53:27 --> Model Class Initialized
INFO - 2018-07-20 04:53:27 --> Helper loaded: url_helper
DEBUG - 2018-07-20 04:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:53:27 --> Model Class Initialized
INFO - 2018-07-20 04:53:27 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 04:53:27 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-20 04:53:27 --> Final output sent to browser
DEBUG - 2018-07-20 04:53:27 --> Total execution time: 0.0439
ERROR - 2018-07-20 04:53:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 04:53:41 --> Config Class Initialized
INFO - 2018-07-20 04:53:41 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:53:41 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:53:41 --> Utf8 Class Initialized
INFO - 2018-07-20 04:53:41 --> URI Class Initialized
INFO - 2018-07-20 04:53:42 --> Router Class Initialized
INFO - 2018-07-20 04:53:42 --> Output Class Initialized
INFO - 2018-07-20 04:53:42 --> Security Class Initialized
DEBUG - 2018-07-20 04:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:53:42 --> Input Class Initialized
INFO - 2018-07-20 04:53:42 --> Language Class Initialized
INFO - 2018-07-20 04:53:42 --> Loader Class Initialized
INFO - 2018-07-20 04:53:42 --> Controller Class Initialized
INFO - 2018-07-20 04:53:42 --> Database Driver Class Initialized
INFO - 2018-07-20 04:53:42 --> Model Class Initialized
INFO - 2018-07-20 04:53:42 --> Helper loaded: url_helper
DEBUG - 2018-07-20 04:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:53:42 --> Model Class Initialized
INFO - 2018-07-20 04:53:42 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 04:53:42 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-20 04:53:42 --> Final output sent to browser
DEBUG - 2018-07-20 04:53:42 --> Total execution time: 0.0552
ERROR - 2018-07-20 04:53:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 04:53:58 --> Config Class Initialized
INFO - 2018-07-20 04:53:58 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:53:58 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:53:58 --> Utf8 Class Initialized
INFO - 2018-07-20 04:53:58 --> URI Class Initialized
INFO - 2018-07-20 04:53:58 --> Router Class Initialized
INFO - 2018-07-20 04:53:58 --> Output Class Initialized
INFO - 2018-07-20 04:53:58 --> Security Class Initialized
DEBUG - 2018-07-20 04:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:53:58 --> Input Class Initialized
INFO - 2018-07-20 04:53:58 --> Language Class Initialized
INFO - 2018-07-20 04:53:58 --> Loader Class Initialized
INFO - 2018-07-20 04:53:58 --> Controller Class Initialized
INFO - 2018-07-20 04:53:58 --> Database Driver Class Initialized
INFO - 2018-07-20 04:53:58 --> Model Class Initialized
INFO - 2018-07-20 04:53:58 --> Helper loaded: url_helper
DEBUG - 2018-07-20 04:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:53:58 --> Model Class Initialized
INFO - 2018-07-20 04:53:58 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 04:53:58 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-20 04:53:58 --> Final output sent to browser
DEBUG - 2018-07-20 04:53:58 --> Total execution time: 0.0487
ERROR - 2018-07-20 04:54:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 04:54:36 --> Config Class Initialized
INFO - 2018-07-20 04:54:36 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:54:36 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:54:36 --> Utf8 Class Initialized
INFO - 2018-07-20 04:54:36 --> URI Class Initialized
INFO - 2018-07-20 04:54:36 --> Router Class Initialized
INFO - 2018-07-20 04:54:36 --> Output Class Initialized
INFO - 2018-07-20 04:54:36 --> Security Class Initialized
DEBUG - 2018-07-20 04:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:54:36 --> Input Class Initialized
INFO - 2018-07-20 04:54:36 --> Language Class Initialized
INFO - 2018-07-20 04:54:36 --> Loader Class Initialized
INFO - 2018-07-20 04:54:36 --> Controller Class Initialized
INFO - 2018-07-20 04:54:36 --> Database Driver Class Initialized
INFO - 2018-07-20 04:54:36 --> Model Class Initialized
INFO - 2018-07-20 04:54:36 --> Helper loaded: url_helper
DEBUG - 2018-07-20 04:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:54:36 --> Model Class Initialized
INFO - 2018-07-20 04:54:36 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 04:54:36 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-20 04:54:36 --> Final output sent to browser
DEBUG - 2018-07-20 04:54:36 --> Total execution time: 0.0530
ERROR - 2018-07-20 04:57:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 04:57:12 --> Config Class Initialized
INFO - 2018-07-20 04:57:12 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:57:12 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:57:12 --> Utf8 Class Initialized
INFO - 2018-07-20 04:57:12 --> URI Class Initialized
INFO - 2018-07-20 04:57:12 --> Router Class Initialized
INFO - 2018-07-20 04:57:12 --> Output Class Initialized
INFO - 2018-07-20 04:57:12 --> Security Class Initialized
DEBUG - 2018-07-20 04:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:57:12 --> Input Class Initialized
INFO - 2018-07-20 04:57:12 --> Language Class Initialized
INFO - 2018-07-20 04:57:12 --> Loader Class Initialized
INFO - 2018-07-20 04:57:12 --> Controller Class Initialized
INFO - 2018-07-20 04:57:12 --> Database Driver Class Initialized
INFO - 2018-07-20 04:57:12 --> Model Class Initialized
INFO - 2018-07-20 04:57:12 --> Helper loaded: url_helper
DEBUG - 2018-07-20 04:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:57:12 --> Model Class Initialized
INFO - 2018-07-20 04:57:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 04:57:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-20 04:57:12 --> Final output sent to browser
DEBUG - 2018-07-20 04:57:12 --> Total execution time: 0.0497
ERROR - 2018-07-20 04:58:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 04:58:05 --> Config Class Initialized
INFO - 2018-07-20 04:58:05 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:58:05 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:58:05 --> Utf8 Class Initialized
INFO - 2018-07-20 04:58:05 --> URI Class Initialized
INFO - 2018-07-20 04:58:05 --> Router Class Initialized
INFO - 2018-07-20 04:58:05 --> Output Class Initialized
INFO - 2018-07-20 04:58:05 --> Security Class Initialized
DEBUG - 2018-07-20 04:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:58:05 --> Input Class Initialized
INFO - 2018-07-20 04:58:05 --> Language Class Initialized
INFO - 2018-07-20 04:58:05 --> Loader Class Initialized
INFO - 2018-07-20 04:58:05 --> Controller Class Initialized
INFO - 2018-07-20 04:58:05 --> Database Driver Class Initialized
INFO - 2018-07-20 04:58:05 --> Model Class Initialized
INFO - 2018-07-20 04:58:05 --> Helper loaded: url_helper
DEBUG - 2018-07-20 04:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:58:05 --> Model Class Initialized
INFO - 2018-07-20 04:58:05 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 04:58:05 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-20 04:58:05 --> Final output sent to browser
DEBUG - 2018-07-20 04:58:05 --> Total execution time: 0.0370
ERROR - 2018-07-20 04:58:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 04:58:07 --> Config Class Initialized
INFO - 2018-07-20 04:58:07 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:58:07 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:58:07 --> Utf8 Class Initialized
INFO - 2018-07-20 04:58:07 --> URI Class Initialized
INFO - 2018-07-20 04:58:07 --> Router Class Initialized
INFO - 2018-07-20 04:58:07 --> Output Class Initialized
INFO - 2018-07-20 04:58:07 --> Security Class Initialized
DEBUG - 2018-07-20 04:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:58:07 --> Input Class Initialized
INFO - 2018-07-20 04:58:07 --> Language Class Initialized
INFO - 2018-07-20 04:58:07 --> Loader Class Initialized
INFO - 2018-07-20 04:58:07 --> Controller Class Initialized
INFO - 2018-07-20 04:58:07 --> Database Driver Class Initialized
INFO - 2018-07-20 04:58:07 --> Model Class Initialized
INFO - 2018-07-20 04:58:07 --> Helper loaded: url_helper
DEBUG - 2018-07-20 04:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:58:07 --> Model Class Initialized
INFO - 2018-07-20 04:58:07 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 04:58:07 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-20 04:58:07 --> Final output sent to browser
DEBUG - 2018-07-20 04:58:07 --> Total execution time: 0.1435
ERROR - 2018-07-20 04:58:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 04:58:34 --> Config Class Initialized
INFO - 2018-07-20 04:58:34 --> Hooks Class Initialized
DEBUG - 2018-07-20 04:58:34 --> UTF-8 Support Enabled
INFO - 2018-07-20 04:58:34 --> Utf8 Class Initialized
INFO - 2018-07-20 04:58:34 --> URI Class Initialized
INFO - 2018-07-20 04:58:34 --> Router Class Initialized
INFO - 2018-07-20 04:58:34 --> Output Class Initialized
INFO - 2018-07-20 04:58:34 --> Security Class Initialized
DEBUG - 2018-07-20 04:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 04:58:34 --> Input Class Initialized
INFO - 2018-07-20 04:58:34 --> Language Class Initialized
INFO - 2018-07-20 04:58:34 --> Loader Class Initialized
INFO - 2018-07-20 04:58:34 --> Controller Class Initialized
INFO - 2018-07-20 04:58:34 --> Database Driver Class Initialized
INFO - 2018-07-20 04:58:34 --> Model Class Initialized
INFO - 2018-07-20 04:58:34 --> Helper loaded: url_helper
DEBUG - 2018-07-20 04:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 04:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 04:58:34 --> Model Class Initialized
INFO - 2018-07-20 04:58:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 04:58:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-20 04:58:34 --> Final output sent to browser
DEBUG - 2018-07-20 04:58:34 --> Total execution time: 0.0655
ERROR - 2018-07-20 05:08:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 05:08:26 --> Config Class Initialized
INFO - 2018-07-20 05:08:26 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:08:26 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:08:26 --> Utf8 Class Initialized
INFO - 2018-07-20 05:08:26 --> URI Class Initialized
INFO - 2018-07-20 05:08:26 --> Router Class Initialized
INFO - 2018-07-20 05:08:26 --> Output Class Initialized
INFO - 2018-07-20 05:08:26 --> Security Class Initialized
DEBUG - 2018-07-20 05:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:08:26 --> Input Class Initialized
INFO - 2018-07-20 05:08:26 --> Language Class Initialized
INFO - 2018-07-20 05:08:26 --> Loader Class Initialized
INFO - 2018-07-20 05:08:26 --> Controller Class Initialized
INFO - 2018-07-20 05:08:26 --> Database Driver Class Initialized
INFO - 2018-07-20 05:08:26 --> Model Class Initialized
INFO - 2018-07-20 05:08:26 --> Helper loaded: url_helper
INFO - 2018-07-20 05:08:26 --> Model Class Initialized
ERROR - 2018-07-20 05:08:27 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 16
INFO - 2018-07-20 05:08:27 --> Final output sent to browser
DEBUG - 2018-07-20 05:08:27 --> Total execution time: 0.2092
ERROR - 2018-07-20 05:08:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 05:08:37 --> Config Class Initialized
INFO - 2018-07-20 05:08:37 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:08:37 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:08:37 --> Utf8 Class Initialized
INFO - 2018-07-20 05:08:37 --> URI Class Initialized
INFO - 2018-07-20 05:08:37 --> Router Class Initialized
INFO - 2018-07-20 05:08:37 --> Output Class Initialized
INFO - 2018-07-20 05:08:37 --> Security Class Initialized
DEBUG - 2018-07-20 05:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:08:37 --> Input Class Initialized
INFO - 2018-07-20 05:08:37 --> Language Class Initialized
INFO - 2018-07-20 05:08:37 --> Loader Class Initialized
INFO - 2018-07-20 05:08:37 --> Controller Class Initialized
INFO - 2018-07-20 05:08:37 --> Database Driver Class Initialized
INFO - 2018-07-20 05:08:37 --> Model Class Initialized
INFO - 2018-07-20 05:08:37 --> Helper loaded: url_helper
INFO - 2018-07-20 05:08:37 --> Model Class Initialized
ERROR - 2018-07-20 05:08:39 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 75
INFO - 2018-07-20 05:08:39 --> Final output sent to browser
DEBUG - 2018-07-20 05:08:39 --> Total execution time: 1.1673
ERROR - 2018-07-20 05:11:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 05:11:53 --> Config Class Initialized
INFO - 2018-07-20 05:11:53 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:11:53 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:11:53 --> Utf8 Class Initialized
INFO - 2018-07-20 05:11:53 --> URI Class Initialized
INFO - 2018-07-20 05:11:53 --> Router Class Initialized
INFO - 2018-07-20 05:11:53 --> Output Class Initialized
INFO - 2018-07-20 05:11:53 --> Security Class Initialized
DEBUG - 2018-07-20 05:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:11:53 --> Input Class Initialized
INFO - 2018-07-20 05:11:53 --> Language Class Initialized
ERROR - 2018-07-20 05:11:53 --> Severity: Compile Error --> Cannot redeclare Main::question() C:\xampp\htdocs\davidhood\application\controllers\Main.php 154
ERROR - 2018-07-20 05:12:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 05:12:26 --> Config Class Initialized
INFO - 2018-07-20 05:12:26 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:12:26 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:12:26 --> Utf8 Class Initialized
INFO - 2018-07-20 05:12:26 --> URI Class Initialized
INFO - 2018-07-20 05:12:26 --> Router Class Initialized
INFO - 2018-07-20 05:12:26 --> Output Class Initialized
INFO - 2018-07-20 05:12:26 --> Security Class Initialized
DEBUG - 2018-07-20 05:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:12:26 --> Input Class Initialized
INFO - 2018-07-20 05:12:26 --> Language Class Initialized
INFO - 2018-07-20 05:12:26 --> Loader Class Initialized
INFO - 2018-07-20 05:12:26 --> Controller Class Initialized
INFO - 2018-07-20 05:12:26 --> Database Driver Class Initialized
INFO - 2018-07-20 05:12:26 --> Model Class Initialized
INFO - 2018-07-20 05:12:26 --> Helper loaded: url_helper
DEBUG - 2018-07-20 05:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:12:26 --> Model Class Initialized
INFO - 2018-07-20 05:12:26 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 05:12:26 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-20 05:12:26 --> Final output sent to browser
DEBUG - 2018-07-20 05:12:26 --> Total execution time: 0.0870
ERROR - 2018-07-20 05:12:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 05:12:28 --> Config Class Initialized
INFO - 2018-07-20 05:12:28 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:12:28 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:12:28 --> Utf8 Class Initialized
INFO - 2018-07-20 05:12:28 --> URI Class Initialized
INFO - 2018-07-20 05:12:28 --> Router Class Initialized
INFO - 2018-07-20 05:12:28 --> Output Class Initialized
INFO - 2018-07-20 05:12:28 --> Security Class Initialized
DEBUG - 2018-07-20 05:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:12:28 --> Input Class Initialized
INFO - 2018-07-20 05:12:28 --> Language Class Initialized
INFO - 2018-07-20 05:12:28 --> Loader Class Initialized
INFO - 2018-07-20 05:12:28 --> Controller Class Initialized
INFO - 2018-07-20 05:12:28 --> Database Driver Class Initialized
INFO - 2018-07-20 05:12:28 --> Model Class Initialized
INFO - 2018-07-20 05:12:28 --> Helper loaded: url_helper
DEBUG - 2018-07-20 05:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:12:28 --> Model Class Initialized
INFO - 2018-07-20 05:12:28 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-20 05:12:28 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\davidhood\application\views\question.php 58
INFO - 2018-07-20 05:12:28 --> File loaded: C:\xampp\htdocs\davidhood\application\views\question.php
INFO - 2018-07-20 05:12:28 --> Final output sent to browser
DEBUG - 2018-07-20 05:12:28 --> Total execution time: 0.0466
ERROR - 2018-07-20 05:12:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 05:12:53 --> Config Class Initialized
INFO - 2018-07-20 05:12:53 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:12:53 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:12:53 --> Utf8 Class Initialized
INFO - 2018-07-20 05:12:53 --> URI Class Initialized
INFO - 2018-07-20 05:12:53 --> Router Class Initialized
INFO - 2018-07-20 05:12:53 --> Output Class Initialized
INFO - 2018-07-20 05:12:53 --> Security Class Initialized
DEBUG - 2018-07-20 05:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:12:53 --> Input Class Initialized
INFO - 2018-07-20 05:12:53 --> Language Class Initialized
INFO - 2018-07-20 05:12:53 --> Loader Class Initialized
INFO - 2018-07-20 05:12:53 --> Controller Class Initialized
INFO - 2018-07-20 05:12:53 --> Database Driver Class Initialized
INFO - 2018-07-20 05:12:53 --> Model Class Initialized
INFO - 2018-07-20 05:12:53 --> Helper loaded: url_helper
DEBUG - 2018-07-20 05:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:12:53 --> Model Class Initialized
INFO - 2018-07-20 05:12:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 05:12:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\question.php
INFO - 2018-07-20 05:12:53 --> Final output sent to browser
DEBUG - 2018-07-20 05:12:53 --> Total execution time: 0.0626
ERROR - 2018-07-20 05:13:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 05:13:09 --> Config Class Initialized
INFO - 2018-07-20 05:13:09 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:13:09 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:13:09 --> Utf8 Class Initialized
INFO - 2018-07-20 05:13:09 --> URI Class Initialized
INFO - 2018-07-20 05:13:09 --> Router Class Initialized
INFO - 2018-07-20 05:13:09 --> Output Class Initialized
INFO - 2018-07-20 05:13:09 --> Security Class Initialized
DEBUG - 2018-07-20 05:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:13:09 --> Input Class Initialized
INFO - 2018-07-20 05:13:09 --> Language Class Initialized
INFO - 2018-07-20 05:13:09 --> Loader Class Initialized
INFO - 2018-07-20 05:13:09 --> Controller Class Initialized
INFO - 2018-07-20 05:13:09 --> Database Driver Class Initialized
INFO - 2018-07-20 05:13:09 --> Model Class Initialized
INFO - 2018-07-20 05:13:09 --> Helper loaded: url_helper
INFO - 2018-07-20 05:13:09 --> Model Class Initialized
ERROR - 2018-07-20 05:13:10 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 75
INFO - 2018-07-20 05:13:10 --> Final output sent to browser
DEBUG - 2018-07-20 05:13:10 --> Total execution time: 1.1619
ERROR - 2018-07-20 05:13:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 05:13:13 --> Config Class Initialized
INFO - 2018-07-20 05:13:13 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:13:13 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:13:13 --> Utf8 Class Initialized
INFO - 2018-07-20 05:13:13 --> URI Class Initialized
INFO - 2018-07-20 05:13:13 --> Router Class Initialized
INFO - 2018-07-20 05:13:13 --> Output Class Initialized
INFO - 2018-07-20 05:13:13 --> Security Class Initialized
DEBUG - 2018-07-20 05:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:13:13 --> Input Class Initialized
INFO - 2018-07-20 05:13:13 --> Language Class Initialized
INFO - 2018-07-20 05:13:13 --> Loader Class Initialized
INFO - 2018-07-20 05:13:13 --> Controller Class Initialized
INFO - 2018-07-20 05:13:13 --> Database Driver Class Initialized
INFO - 2018-07-20 05:13:13 --> Model Class Initialized
INFO - 2018-07-20 05:13:13 --> Helper loaded: url_helper
DEBUG - 2018-07-20 05:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:13:13 --> Model Class Initialized
INFO - 2018-07-20 05:13:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 05:13:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\question.php
INFO - 2018-07-20 05:13:13 --> Final output sent to browser
DEBUG - 2018-07-20 05:13:13 --> Total execution time: 0.0566
ERROR - 2018-07-20 05:13:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 05:13:16 --> Config Class Initialized
INFO - 2018-07-20 05:13:16 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:13:16 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:13:16 --> Utf8 Class Initialized
INFO - 2018-07-20 05:13:16 --> URI Class Initialized
INFO - 2018-07-20 05:13:16 --> Router Class Initialized
INFO - 2018-07-20 05:13:16 --> Output Class Initialized
INFO - 2018-07-20 05:13:16 --> Security Class Initialized
DEBUG - 2018-07-20 05:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:13:16 --> Input Class Initialized
INFO - 2018-07-20 05:13:16 --> Language Class Initialized
INFO - 2018-07-20 05:13:16 --> Loader Class Initialized
INFO - 2018-07-20 05:13:16 --> Controller Class Initialized
INFO - 2018-07-20 05:13:16 --> Database Driver Class Initialized
INFO - 2018-07-20 05:13:16 --> Model Class Initialized
INFO - 2018-07-20 05:13:16 --> Helper loaded: url_helper
DEBUG - 2018-07-20 05:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:13:16 --> Model Class Initialized
INFO - 2018-07-20 05:13:16 --> Final output sent to browser
DEBUG - 2018-07-20 05:13:16 --> Total execution time: 0.0595
ERROR - 2018-07-20 05:14:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 05:14:07 --> Config Class Initialized
INFO - 2018-07-20 05:14:07 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:14:07 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:14:07 --> Utf8 Class Initialized
INFO - 2018-07-20 05:14:07 --> URI Class Initialized
INFO - 2018-07-20 05:14:07 --> Router Class Initialized
INFO - 2018-07-20 05:14:07 --> Output Class Initialized
INFO - 2018-07-20 05:14:07 --> Security Class Initialized
DEBUG - 2018-07-20 05:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:14:07 --> Input Class Initialized
INFO - 2018-07-20 05:14:07 --> Language Class Initialized
INFO - 2018-07-20 05:14:07 --> Loader Class Initialized
INFO - 2018-07-20 05:14:07 --> Controller Class Initialized
INFO - 2018-07-20 05:14:07 --> Database Driver Class Initialized
INFO - 2018-07-20 05:14:07 --> Model Class Initialized
INFO - 2018-07-20 05:14:07 --> Helper loaded: url_helper
INFO - 2018-07-20 05:14:07 --> Model Class Initialized
ERROR - 2018-07-20 05:14:08 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 75
INFO - 2018-07-20 05:14:08 --> Final output sent to browser
DEBUG - 2018-07-20 05:14:08 --> Total execution time: 1.2668
ERROR - 2018-07-20 05:14:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 05:14:15 --> Config Class Initialized
INFO - 2018-07-20 05:14:15 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:14:15 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:14:15 --> Utf8 Class Initialized
INFO - 2018-07-20 05:14:15 --> URI Class Initialized
INFO - 2018-07-20 05:14:15 --> Router Class Initialized
INFO - 2018-07-20 05:14:15 --> Output Class Initialized
INFO - 2018-07-20 05:14:15 --> Security Class Initialized
DEBUG - 2018-07-20 05:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:14:15 --> Input Class Initialized
INFO - 2018-07-20 05:14:15 --> Language Class Initialized
INFO - 2018-07-20 05:14:15 --> Loader Class Initialized
INFO - 2018-07-20 05:14:15 --> Controller Class Initialized
INFO - 2018-07-20 05:14:15 --> Database Driver Class Initialized
INFO - 2018-07-20 05:14:15 --> Model Class Initialized
INFO - 2018-07-20 05:14:15 --> Helper loaded: url_helper
DEBUG - 2018-07-20 05:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:14:15 --> Model Class Initialized
INFO - 2018-07-20 05:14:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 05:14:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\question.php
INFO - 2018-07-20 05:14:15 --> Final output sent to browser
DEBUG - 2018-07-20 05:14:15 --> Total execution time: 0.0570
ERROR - 2018-07-20 05:14:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 05:14:16 --> Config Class Initialized
INFO - 2018-07-20 05:14:16 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:14:16 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:14:16 --> Utf8 Class Initialized
INFO - 2018-07-20 05:14:16 --> URI Class Initialized
INFO - 2018-07-20 05:14:16 --> Router Class Initialized
INFO - 2018-07-20 05:14:16 --> Output Class Initialized
INFO - 2018-07-20 05:14:16 --> Security Class Initialized
DEBUG - 2018-07-20 05:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:14:16 --> Input Class Initialized
INFO - 2018-07-20 05:14:16 --> Language Class Initialized
INFO - 2018-07-20 05:14:16 --> Loader Class Initialized
INFO - 2018-07-20 05:14:16 --> Controller Class Initialized
INFO - 2018-07-20 05:14:16 --> Database Driver Class Initialized
INFO - 2018-07-20 05:14:16 --> Model Class Initialized
INFO - 2018-07-20 05:14:16 --> Helper loaded: url_helper
DEBUG - 2018-07-20 05:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:14:16 --> Model Class Initialized
INFO - 2018-07-20 05:14:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 05:14:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\question.php
INFO - 2018-07-20 05:14:16 --> Final output sent to browser
DEBUG - 2018-07-20 05:14:16 --> Total execution time: 0.0460
ERROR - 2018-07-20 05:14:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 05:14:21 --> Config Class Initialized
INFO - 2018-07-20 05:14:21 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:14:21 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:14:21 --> Utf8 Class Initialized
INFO - 2018-07-20 05:14:21 --> URI Class Initialized
INFO - 2018-07-20 05:14:21 --> Router Class Initialized
INFO - 2018-07-20 05:14:21 --> Output Class Initialized
INFO - 2018-07-20 05:14:21 --> Security Class Initialized
DEBUG - 2018-07-20 05:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:14:21 --> Input Class Initialized
INFO - 2018-07-20 05:14:21 --> Language Class Initialized
INFO - 2018-07-20 05:14:21 --> Loader Class Initialized
INFO - 2018-07-20 05:14:21 --> Controller Class Initialized
INFO - 2018-07-20 05:14:21 --> Database Driver Class Initialized
INFO - 2018-07-20 05:14:21 --> Model Class Initialized
INFO - 2018-07-20 05:14:21 --> Helper loaded: url_helper
DEBUG - 2018-07-20 05:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:14:21 --> Model Class Initialized
ERROR - 2018-07-20 05:14:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 05:14:21 --> Config Class Initialized
INFO - 2018-07-20 05:14:21 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:14:21 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:14:21 --> Utf8 Class Initialized
INFO - 2018-07-20 05:14:21 --> URI Class Initialized
INFO - 2018-07-20 05:14:21 --> Router Class Initialized
INFO - 2018-07-20 05:14:21 --> Output Class Initialized
INFO - 2018-07-20 05:14:21 --> Security Class Initialized
DEBUG - 2018-07-20 05:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:14:21 --> Input Class Initialized
INFO - 2018-07-20 05:14:21 --> Language Class Initialized
INFO - 2018-07-20 05:14:21 --> Loader Class Initialized
INFO - 2018-07-20 05:14:21 --> Controller Class Initialized
INFO - 2018-07-20 05:14:21 --> Database Driver Class Initialized
INFO - 2018-07-20 05:14:21 --> Model Class Initialized
INFO - 2018-07-20 05:14:21 --> Helper loaded: url_helper
DEBUG - 2018-07-20 05:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:14:21 --> Model Class Initialized
INFO - 2018-07-20 05:14:21 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 05:14:21 --> File loaded: C:\xampp\htdocs\davidhood\application\views\question.php
INFO - 2018-07-20 05:14:21 --> Final output sent to browser
DEBUG - 2018-07-20 05:14:21 --> Total execution time: 0.0821
ERROR - 2018-07-20 05:14:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 05:14:24 --> Config Class Initialized
INFO - 2018-07-20 05:14:24 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:14:24 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:14:24 --> Utf8 Class Initialized
INFO - 2018-07-20 05:14:24 --> URI Class Initialized
INFO - 2018-07-20 05:14:24 --> Router Class Initialized
INFO - 2018-07-20 05:14:24 --> Output Class Initialized
INFO - 2018-07-20 05:14:24 --> Security Class Initialized
DEBUG - 2018-07-20 05:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:14:24 --> Input Class Initialized
INFO - 2018-07-20 05:14:24 --> Language Class Initialized
INFO - 2018-07-20 05:14:24 --> Loader Class Initialized
INFO - 2018-07-20 05:14:24 --> Controller Class Initialized
INFO - 2018-07-20 05:14:24 --> Database Driver Class Initialized
INFO - 2018-07-20 05:14:24 --> Model Class Initialized
INFO - 2018-07-20 05:14:24 --> Helper loaded: url_helper
DEBUG - 2018-07-20 05:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:14:24 --> Model Class Initialized
ERROR - 2018-07-20 05:14:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 05:14:24 --> Config Class Initialized
INFO - 2018-07-20 05:14:24 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:14:24 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:14:24 --> Utf8 Class Initialized
INFO - 2018-07-20 05:14:24 --> URI Class Initialized
INFO - 2018-07-20 05:14:24 --> Router Class Initialized
INFO - 2018-07-20 05:14:24 --> Output Class Initialized
INFO - 2018-07-20 05:14:24 --> Security Class Initialized
DEBUG - 2018-07-20 05:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:14:24 --> Input Class Initialized
INFO - 2018-07-20 05:14:24 --> Language Class Initialized
INFO - 2018-07-20 05:14:24 --> Loader Class Initialized
INFO - 2018-07-20 05:14:24 --> Controller Class Initialized
INFO - 2018-07-20 05:14:24 --> Database Driver Class Initialized
INFO - 2018-07-20 05:14:24 --> Model Class Initialized
INFO - 2018-07-20 05:14:24 --> Helper loaded: url_helper
DEBUG - 2018-07-20 05:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:14:24 --> Model Class Initialized
INFO - 2018-07-20 05:14:24 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 05:14:24 --> File loaded: C:\xampp\htdocs\davidhood\application\views\question.php
INFO - 2018-07-20 05:14:24 --> Final output sent to browser
DEBUG - 2018-07-20 05:14:24 --> Total execution time: 0.0460
ERROR - 2018-07-20 05:14:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 05:14:26 --> Config Class Initialized
INFO - 2018-07-20 05:14:26 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:14:26 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:14:26 --> Utf8 Class Initialized
INFO - 2018-07-20 05:14:26 --> URI Class Initialized
INFO - 2018-07-20 05:14:26 --> Router Class Initialized
INFO - 2018-07-20 05:14:26 --> Output Class Initialized
INFO - 2018-07-20 05:14:26 --> Security Class Initialized
DEBUG - 2018-07-20 05:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:14:26 --> Input Class Initialized
INFO - 2018-07-20 05:14:26 --> Language Class Initialized
INFO - 2018-07-20 05:14:26 --> Loader Class Initialized
INFO - 2018-07-20 05:14:26 --> Controller Class Initialized
INFO - 2018-07-20 05:14:26 --> Database Driver Class Initialized
INFO - 2018-07-20 05:14:26 --> Model Class Initialized
INFO - 2018-07-20 05:14:26 --> Helper loaded: url_helper
DEBUG - 2018-07-20 05:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:14:26 --> Model Class Initialized
INFO - 2018-07-20 05:14:26 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 05:14:26 --> File loaded: C:\xampp\htdocs\davidhood\application\views\question.php
INFO - 2018-07-20 05:14:26 --> Final output sent to browser
DEBUG - 2018-07-20 05:14:26 --> Total execution time: 0.0551
ERROR - 2018-07-20 05:14:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 05:14:47 --> Config Class Initialized
INFO - 2018-07-20 05:14:47 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:14:47 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:14:47 --> Utf8 Class Initialized
INFO - 2018-07-20 05:14:47 --> URI Class Initialized
INFO - 2018-07-20 05:14:47 --> Router Class Initialized
INFO - 2018-07-20 05:14:47 --> Output Class Initialized
INFO - 2018-07-20 05:14:47 --> Security Class Initialized
DEBUG - 2018-07-20 05:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:14:47 --> Input Class Initialized
INFO - 2018-07-20 05:14:47 --> Language Class Initialized
INFO - 2018-07-20 05:14:47 --> Loader Class Initialized
INFO - 2018-07-20 05:14:47 --> Controller Class Initialized
INFO - 2018-07-20 05:14:47 --> Database Driver Class Initialized
INFO - 2018-07-20 05:14:47 --> Model Class Initialized
INFO - 2018-07-20 05:14:47 --> Helper loaded: url_helper
DEBUG - 2018-07-20 05:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:14:47 --> Model Class Initialized
INFO - 2018-07-20 05:14:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 05:14:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\question.php
INFO - 2018-07-20 05:14:47 --> Final output sent to browser
DEBUG - 2018-07-20 05:14:47 --> Total execution time: 0.0622
ERROR - 2018-07-20 05:14:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-20 05:14:48 --> Config Class Initialized
INFO - 2018-07-20 05:14:48 --> Hooks Class Initialized
DEBUG - 2018-07-20 05:14:48 --> UTF-8 Support Enabled
INFO - 2018-07-20 05:14:48 --> Utf8 Class Initialized
INFO - 2018-07-20 05:14:48 --> URI Class Initialized
INFO - 2018-07-20 05:14:48 --> Router Class Initialized
INFO - 2018-07-20 05:14:48 --> Output Class Initialized
INFO - 2018-07-20 05:14:48 --> Security Class Initialized
DEBUG - 2018-07-20 05:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-20 05:14:48 --> Input Class Initialized
INFO - 2018-07-20 05:14:48 --> Language Class Initialized
INFO - 2018-07-20 05:14:48 --> Loader Class Initialized
INFO - 2018-07-20 05:14:48 --> Controller Class Initialized
INFO - 2018-07-20 05:14:48 --> Database Driver Class Initialized
INFO - 2018-07-20 05:14:49 --> Model Class Initialized
INFO - 2018-07-20 05:14:49 --> Helper loaded: url_helper
DEBUG - 2018-07-20 05:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-20 05:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-20 05:14:49 --> Model Class Initialized
INFO - 2018-07-20 05:14:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-20 05:14:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-20 05:14:49 --> Final output sent to browser
DEBUG - 2018-07-20 05:14:49 --> Total execution time: 0.0521
