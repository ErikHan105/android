<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-22 13:13:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-22 13:13:52 --> Config Class Initialized
INFO - 2018-07-22 13:13:52 --> Hooks Class Initialized
DEBUG - 2018-07-22 13:13:52 --> UTF-8 Support Enabled
INFO - 2018-07-22 13:13:52 --> Utf8 Class Initialized
INFO - 2018-07-22 13:13:52 --> URI Class Initialized
DEBUG - 2018-07-22 13:13:52 --> No URI present. Default controller set.
INFO - 2018-07-22 13:13:52 --> Router Class Initialized
INFO - 2018-07-22 13:13:52 --> Output Class Initialized
INFO - 2018-07-22 13:13:52 --> Security Class Initialized
DEBUG - 2018-07-22 13:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 13:13:52 --> Input Class Initialized
INFO - 2018-07-22 13:13:52 --> Language Class Initialized
INFO - 2018-07-22 13:13:52 --> Loader Class Initialized
INFO - 2018-07-22 13:13:52 --> Controller Class Initialized
INFO - 2018-07-22 13:13:52 --> Database Driver Class Initialized
INFO - 2018-07-22 13:13:52 --> Model Class Initialized
INFO - 2018-07-22 13:13:52 --> Helper loaded: url_helper
DEBUG - 2018-07-22 13:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-22 13:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-22 13:13:52 --> Model Class Initialized
INFO - 2018-07-22 13:13:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-22 13:13:52 --> Final output sent to browser
DEBUG - 2018-07-22 13:13:52 --> Total execution time: 0.0708
ERROR - 2018-07-22 17:55:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-22 17:55:12 --> Config Class Initialized
INFO - 2018-07-22 17:55:12 --> Hooks Class Initialized
DEBUG - 2018-07-22 17:55:12 --> UTF-8 Support Enabled
INFO - 2018-07-22 17:55:12 --> Utf8 Class Initialized
INFO - 2018-07-22 17:55:12 --> URI Class Initialized
INFO - 2018-07-22 17:55:12 --> Router Class Initialized
INFO - 2018-07-22 17:55:12 --> Output Class Initialized
INFO - 2018-07-22 17:55:12 --> Security Class Initialized
DEBUG - 2018-07-22 17:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 17:55:12 --> Input Class Initialized
INFO - 2018-07-22 17:55:12 --> Language Class Initialized
INFO - 2018-07-22 17:55:12 --> Loader Class Initialized
INFO - 2018-07-22 17:55:12 --> Controller Class Initialized
INFO - 2018-07-22 17:55:12 --> Database Driver Class Initialized
INFO - 2018-07-22 17:55:12 --> Model Class Initialized
INFO - 2018-07-22 17:55:12 --> Helper loaded: url_helper
INFO - 2018-07-22 17:55:12 --> Model Class Initialized
ERROR - 2018-07-22 17:55:12 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 16
INFO - 2018-07-22 17:55:12 --> Final output sent to browser
DEBUG - 2018-07-22 17:55:12 --> Total execution time: 0.0596
ERROR - 2018-07-22 17:55:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-22 17:55:40 --> Config Class Initialized
INFO - 2018-07-22 17:55:40 --> Hooks Class Initialized
DEBUG - 2018-07-22 17:55:40 --> UTF-8 Support Enabled
INFO - 2018-07-22 17:55:40 --> Utf8 Class Initialized
INFO - 2018-07-22 17:55:40 --> URI Class Initialized
INFO - 2018-07-22 17:55:40 --> Router Class Initialized
INFO - 2018-07-22 17:55:40 --> Output Class Initialized
INFO - 2018-07-22 17:55:40 --> Security Class Initialized
DEBUG - 2018-07-22 17:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 17:55:40 --> Input Class Initialized
INFO - 2018-07-22 17:55:40 --> Language Class Initialized
INFO - 2018-07-22 17:55:40 --> Loader Class Initialized
INFO - 2018-07-22 17:55:40 --> Controller Class Initialized
INFO - 2018-07-22 17:55:40 --> Database Driver Class Initialized
INFO - 2018-07-22 17:55:40 --> Model Class Initialized
INFO - 2018-07-22 17:55:40 --> Helper loaded: url_helper
INFO - 2018-07-22 17:55:40 --> Model Class Initialized
INFO - 2018-07-22 17:55:40 --> Final output sent to browser
DEBUG - 2018-07-22 17:55:40 --> Total execution time: 0.0406
ERROR - 2018-07-22 17:56:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-22 17:56:34 --> Config Class Initialized
INFO - 2018-07-22 17:56:34 --> Hooks Class Initialized
DEBUG - 2018-07-22 17:56:34 --> UTF-8 Support Enabled
INFO - 2018-07-22 17:56:34 --> Utf8 Class Initialized
INFO - 2018-07-22 17:56:34 --> URI Class Initialized
INFO - 2018-07-22 17:56:34 --> Router Class Initialized
INFO - 2018-07-22 17:56:34 --> Output Class Initialized
INFO - 2018-07-22 17:56:34 --> Security Class Initialized
DEBUG - 2018-07-22 17:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 17:56:34 --> Input Class Initialized
INFO - 2018-07-22 17:56:34 --> Language Class Initialized
INFO - 2018-07-22 17:56:34 --> Loader Class Initialized
INFO - 2018-07-22 17:56:34 --> Controller Class Initialized
INFO - 2018-07-22 17:56:34 --> Database Driver Class Initialized
INFO - 2018-07-22 17:56:34 --> Model Class Initialized
INFO - 2018-07-22 17:56:34 --> Helper loaded: url_helper
INFO - 2018-07-22 17:56:34 --> Model Class Initialized
INFO - 2018-07-22 17:56:34 --> Final output sent to browser
DEBUG - 2018-07-22 17:56:34 --> Total execution time: 0.1050
ERROR - 2018-07-22 17:57:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-22 17:57:52 --> Config Class Initialized
INFO - 2018-07-22 17:57:52 --> Hooks Class Initialized
DEBUG - 2018-07-22 17:57:52 --> UTF-8 Support Enabled
INFO - 2018-07-22 17:57:52 --> Utf8 Class Initialized
INFO - 2018-07-22 17:57:52 --> URI Class Initialized
INFO - 2018-07-22 17:57:52 --> Router Class Initialized
INFO - 2018-07-22 17:57:52 --> Output Class Initialized
INFO - 2018-07-22 17:57:52 --> Security Class Initialized
DEBUG - 2018-07-22 17:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 17:57:52 --> Input Class Initialized
INFO - 2018-07-22 17:57:52 --> Language Class Initialized
INFO - 2018-07-22 17:57:52 --> Loader Class Initialized
INFO - 2018-07-22 17:57:52 --> Controller Class Initialized
INFO - 2018-07-22 17:57:52 --> Database Driver Class Initialized
INFO - 2018-07-22 17:57:52 --> Model Class Initialized
INFO - 2018-07-22 17:57:52 --> Helper loaded: url_helper
INFO - 2018-07-22 17:57:52 --> Model Class Initialized
INFO - 2018-07-22 17:57:52 --> Final output sent to browser
DEBUG - 2018-07-22 17:57:52 --> Total execution time: 0.0502
ERROR - 2018-07-22 17:58:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-22 17:58:10 --> Config Class Initialized
INFO - 2018-07-22 17:58:10 --> Hooks Class Initialized
DEBUG - 2018-07-22 17:58:10 --> UTF-8 Support Enabled
INFO - 2018-07-22 17:58:10 --> Utf8 Class Initialized
INFO - 2018-07-22 17:58:10 --> URI Class Initialized
INFO - 2018-07-22 17:58:10 --> Router Class Initialized
INFO - 2018-07-22 17:58:10 --> Output Class Initialized
INFO - 2018-07-22 17:58:10 --> Security Class Initialized
DEBUG - 2018-07-22 17:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 17:58:10 --> Input Class Initialized
INFO - 2018-07-22 17:58:10 --> Language Class Initialized
INFO - 2018-07-22 17:58:10 --> Loader Class Initialized
INFO - 2018-07-22 17:58:10 --> Controller Class Initialized
INFO - 2018-07-22 17:58:10 --> Database Driver Class Initialized
INFO - 2018-07-22 17:58:10 --> Model Class Initialized
INFO - 2018-07-22 17:58:10 --> Helper loaded: url_helper
INFO - 2018-07-22 17:58:10 --> Model Class Initialized
INFO - 2018-07-22 17:58:10 --> Final output sent to browser
DEBUG - 2018-07-22 17:58:10 --> Total execution time: 0.1731
ERROR - 2018-07-22 18:02:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-22 18:02:14 --> Config Class Initialized
INFO - 2018-07-22 18:02:14 --> Hooks Class Initialized
DEBUG - 2018-07-22 18:02:14 --> UTF-8 Support Enabled
INFO - 2018-07-22 18:02:14 --> Utf8 Class Initialized
INFO - 2018-07-22 18:02:14 --> URI Class Initialized
INFO - 2018-07-22 18:02:14 --> Router Class Initialized
INFO - 2018-07-22 18:02:14 --> Output Class Initialized
INFO - 2018-07-22 18:02:14 --> Security Class Initialized
DEBUG - 2018-07-22 18:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-22 18:02:14 --> Input Class Initialized
INFO - 2018-07-22 18:02:14 --> Language Class Initialized
INFO - 2018-07-22 18:02:14 --> Loader Class Initialized
INFO - 2018-07-22 18:02:14 --> Controller Class Initialized
INFO - 2018-07-22 18:02:14 --> Database Driver Class Initialized
INFO - 2018-07-22 18:02:14 --> Model Class Initialized
INFO - 2018-07-22 18:02:14 --> Helper loaded: url_helper
INFO - 2018-07-22 18:02:14 --> Model Class Initialized
INFO - 2018-07-22 18:02:14 --> Final output sent to browser
DEBUG - 2018-07-22 18:02:14 --> Total execution time: 0.1314
