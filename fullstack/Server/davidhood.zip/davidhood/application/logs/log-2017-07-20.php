<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-20 02:00:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 02:00:41 --> Config Class Initialized
INFO - 2017-07-20 02:00:41 --> Hooks Class Initialized
DEBUG - 2017-07-20 02:00:41 --> UTF-8 Support Enabled
INFO - 2017-07-20 02:00:41 --> Utf8 Class Initialized
INFO - 2017-07-20 02:00:41 --> URI Class Initialized
INFO - 2017-07-20 02:00:41 --> Router Class Initialized
INFO - 2017-07-20 02:00:41 --> Output Class Initialized
INFO - 2017-07-20 02:00:41 --> Security Class Initialized
DEBUG - 2017-07-20 02:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 02:00:41 --> Input Class Initialized
INFO - 2017-07-20 02:00:41 --> Language Class Initialized
INFO - 2017-07-20 02:00:41 --> Loader Class Initialized
INFO - 2017-07-20 02:00:41 --> Controller Class Initialized
INFO - 2017-07-20 02:00:41 --> Database Driver Class Initialized
INFO - 2017-07-20 02:00:41 --> Model Class Initialized
INFO - 2017-07-20 02:00:41 --> Helper loaded: form_helper
INFO - 2017-07-20 02:00:41 --> Helper loaded: url_helper
INFO - 2017-07-20 02:00:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-20 02:00:41 --> Model Class Initialized
INFO - 2017-07-20 02:00:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-20 02:00:41 --> Final output sent to browser
DEBUG - 2017-07-20 02:00:41 --> Total execution time: 0.0730
ERROR - 2017-07-20 02:38:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 02:38:34 --> Config Class Initialized
INFO - 2017-07-20 02:38:34 --> Hooks Class Initialized
DEBUG - 2017-07-20 02:38:34 --> UTF-8 Support Enabled
INFO - 2017-07-20 02:38:34 --> Utf8 Class Initialized
INFO - 2017-07-20 02:38:34 --> URI Class Initialized
INFO - 2017-07-20 02:38:34 --> Router Class Initialized
INFO - 2017-07-20 02:38:34 --> Output Class Initialized
INFO - 2017-07-20 02:38:34 --> Security Class Initialized
DEBUG - 2017-07-20 02:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 02:38:34 --> Input Class Initialized
INFO - 2017-07-20 02:38:34 --> Language Class Initialized
INFO - 2017-07-20 02:38:34 --> Loader Class Initialized
INFO - 2017-07-20 02:38:34 --> Controller Class Initialized
INFO - 2017-07-20 02:38:34 --> Database Driver Class Initialized
INFO - 2017-07-20 02:38:34 --> Model Class Initialized
INFO - 2017-07-20 02:38:34 --> Helper loaded: form_helper
INFO - 2017-07-20 02:38:34 --> Helper loaded: url_helper
INFO - 2017-07-20 02:38:34 --> Model Class Initialized
INFO - 2017-07-20 02:38:34 --> Final output sent to browser
DEBUG - 2017-07-20 02:38:34 --> Total execution time: 0.0813
ERROR - 2017-07-20 02:39:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 02:39:09 --> Config Class Initialized
INFO - 2017-07-20 02:39:09 --> Hooks Class Initialized
DEBUG - 2017-07-20 02:39:09 --> UTF-8 Support Enabled
INFO - 2017-07-20 02:39:09 --> Utf8 Class Initialized
INFO - 2017-07-20 02:39:09 --> URI Class Initialized
INFO - 2017-07-20 02:39:09 --> Router Class Initialized
INFO - 2017-07-20 02:39:09 --> Output Class Initialized
INFO - 2017-07-20 02:39:09 --> Security Class Initialized
DEBUG - 2017-07-20 02:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 02:39:09 --> Input Class Initialized
INFO - 2017-07-20 02:39:09 --> Language Class Initialized
INFO - 2017-07-20 02:39:09 --> Loader Class Initialized
INFO - 2017-07-20 02:39:09 --> Controller Class Initialized
INFO - 2017-07-20 02:39:09 --> Database Driver Class Initialized
INFO - 2017-07-20 02:39:09 --> Model Class Initialized
INFO - 2017-07-20 02:39:09 --> Helper loaded: form_helper
INFO - 2017-07-20 02:39:09 --> Helper loaded: url_helper
INFO - 2017-07-20 02:39:09 --> Model Class Initialized
INFO - 2017-07-20 02:39:09 --> Final output sent to browser
DEBUG - 2017-07-20 02:39:09 --> Total execution time: 0.1100
ERROR - 2017-07-20 02:39:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 02:39:10 --> Config Class Initialized
INFO - 2017-07-20 02:39:10 --> Hooks Class Initialized
DEBUG - 2017-07-20 02:39:10 --> UTF-8 Support Enabled
INFO - 2017-07-20 02:39:10 --> Utf8 Class Initialized
INFO - 2017-07-20 02:39:10 --> URI Class Initialized
INFO - 2017-07-20 02:39:10 --> Router Class Initialized
INFO - 2017-07-20 02:39:10 --> Output Class Initialized
INFO - 2017-07-20 02:39:10 --> Security Class Initialized
DEBUG - 2017-07-20 02:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 02:39:10 --> Input Class Initialized
INFO - 2017-07-20 02:39:10 --> Language Class Initialized
INFO - 2017-07-20 02:39:10 --> Loader Class Initialized
INFO - 2017-07-20 02:39:10 --> Controller Class Initialized
INFO - 2017-07-20 02:39:10 --> Database Driver Class Initialized
INFO - 2017-07-20 02:39:10 --> Model Class Initialized
INFO - 2017-07-20 02:39:10 --> Helper loaded: form_helper
INFO - 2017-07-20 02:39:10 --> Helper loaded: url_helper
INFO - 2017-07-20 02:39:10 --> Model Class Initialized
INFO - 2017-07-20 02:39:10 --> Final output sent to browser
DEBUG - 2017-07-20 02:39:10 --> Total execution time: 0.0788
ERROR - 2017-07-20 02:40:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 02:40:28 --> Config Class Initialized
INFO - 2017-07-20 02:40:28 --> Hooks Class Initialized
DEBUG - 2017-07-20 02:40:28 --> UTF-8 Support Enabled
INFO - 2017-07-20 02:40:28 --> Utf8 Class Initialized
INFO - 2017-07-20 02:40:28 --> URI Class Initialized
INFO - 2017-07-20 02:40:28 --> Router Class Initialized
INFO - 2017-07-20 02:40:28 --> Output Class Initialized
INFO - 2017-07-20 02:40:28 --> Security Class Initialized
DEBUG - 2017-07-20 02:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 02:40:28 --> Input Class Initialized
INFO - 2017-07-20 02:40:28 --> Language Class Initialized
INFO - 2017-07-20 02:40:28 --> Loader Class Initialized
INFO - 2017-07-20 02:40:28 --> Controller Class Initialized
INFO - 2017-07-20 02:40:28 --> Database Driver Class Initialized
INFO - 2017-07-20 02:40:28 --> Model Class Initialized
INFO - 2017-07-20 02:40:28 --> Helper loaded: form_helper
INFO - 2017-07-20 02:40:28 --> Helper loaded: url_helper
INFO - 2017-07-20 02:40:28 --> Model Class Initialized
INFO - 2017-07-20 02:40:29 --> Final output sent to browser
DEBUG - 2017-07-20 02:40:29 --> Total execution time: 0.1088
ERROR - 2017-07-20 02:41:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 02:41:39 --> Config Class Initialized
INFO - 2017-07-20 02:41:39 --> Hooks Class Initialized
DEBUG - 2017-07-20 02:41:39 --> UTF-8 Support Enabled
INFO - 2017-07-20 02:41:39 --> Utf8 Class Initialized
INFO - 2017-07-20 02:41:39 --> URI Class Initialized
INFO - 2017-07-20 02:41:39 --> Router Class Initialized
INFO - 2017-07-20 02:41:39 --> Output Class Initialized
INFO - 2017-07-20 02:41:39 --> Security Class Initialized
DEBUG - 2017-07-20 02:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 02:41:39 --> Input Class Initialized
INFO - 2017-07-20 02:41:39 --> Language Class Initialized
INFO - 2017-07-20 02:41:39 --> Loader Class Initialized
INFO - 2017-07-20 02:41:39 --> Controller Class Initialized
INFO - 2017-07-20 02:41:39 --> Database Driver Class Initialized
INFO - 2017-07-20 02:41:39 --> Model Class Initialized
INFO - 2017-07-20 02:41:39 --> Helper loaded: form_helper
INFO - 2017-07-20 02:41:39 --> Helper loaded: url_helper
INFO - 2017-07-20 02:41:39 --> Model Class Initialized
INFO - 2017-07-20 02:41:39 --> Final output sent to browser
DEBUG - 2017-07-20 02:41:39 --> Total execution time: 0.1025
ERROR - 2017-07-20 02:56:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 02:56:22 --> Config Class Initialized
INFO - 2017-07-20 02:56:22 --> Hooks Class Initialized
DEBUG - 2017-07-20 02:56:22 --> UTF-8 Support Enabled
INFO - 2017-07-20 02:56:22 --> Utf8 Class Initialized
INFO - 2017-07-20 02:56:22 --> URI Class Initialized
INFO - 2017-07-20 02:56:22 --> Router Class Initialized
INFO - 2017-07-20 02:56:22 --> Output Class Initialized
INFO - 2017-07-20 02:56:22 --> Security Class Initialized
DEBUG - 2017-07-20 02:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 02:56:22 --> Input Class Initialized
INFO - 2017-07-20 02:56:22 --> Language Class Initialized
INFO - 2017-07-20 02:56:22 --> Loader Class Initialized
INFO - 2017-07-20 02:56:22 --> Controller Class Initialized
INFO - 2017-07-20 02:56:22 --> Database Driver Class Initialized
INFO - 2017-07-20 02:56:22 --> Model Class Initialized
INFO - 2017-07-20 02:56:22 --> Helper loaded: form_helper
INFO - 2017-07-20 02:56:22 --> Helper loaded: url_helper
INFO - 2017-07-20 02:56:22 --> Model Class Initialized
INFO - 2017-07-20 02:56:22 --> Final output sent to browser
DEBUG - 2017-07-20 02:56:22 --> Total execution time: 0.1145
ERROR - 2017-07-20 02:56:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 02:56:51 --> Config Class Initialized
INFO - 2017-07-20 02:56:51 --> Hooks Class Initialized
DEBUG - 2017-07-20 02:56:51 --> UTF-8 Support Enabled
INFO - 2017-07-20 02:56:51 --> Utf8 Class Initialized
INFO - 2017-07-20 02:56:51 --> URI Class Initialized
INFO - 2017-07-20 02:56:51 --> Router Class Initialized
INFO - 2017-07-20 02:56:51 --> Output Class Initialized
INFO - 2017-07-20 02:56:51 --> Security Class Initialized
DEBUG - 2017-07-20 02:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 02:56:51 --> Input Class Initialized
INFO - 2017-07-20 02:56:51 --> Language Class Initialized
INFO - 2017-07-20 02:56:51 --> Loader Class Initialized
INFO - 2017-07-20 02:56:51 --> Controller Class Initialized
INFO - 2017-07-20 02:56:51 --> Database Driver Class Initialized
INFO - 2017-07-20 02:56:51 --> Model Class Initialized
INFO - 2017-07-20 02:56:51 --> Helper loaded: form_helper
INFO - 2017-07-20 02:56:51 --> Helper loaded: url_helper
INFO - 2017-07-20 02:56:51 --> Model Class Initialized
INFO - 2017-07-20 02:56:51 --> Final output sent to browser
DEBUG - 2017-07-20 02:56:51 --> Total execution time: 0.1063
ERROR - 2017-07-20 03:01:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:01:26 --> Config Class Initialized
INFO - 2017-07-20 03:01:26 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:01:26 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:01:26 --> Utf8 Class Initialized
INFO - 2017-07-20 03:01:26 --> URI Class Initialized
INFO - 2017-07-20 03:01:26 --> Router Class Initialized
INFO - 2017-07-20 03:01:26 --> Output Class Initialized
INFO - 2017-07-20 03:01:26 --> Security Class Initialized
DEBUG - 2017-07-20 03:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:01:26 --> Input Class Initialized
INFO - 2017-07-20 03:01:26 --> Language Class Initialized
INFO - 2017-07-20 03:01:26 --> Loader Class Initialized
INFO - 2017-07-20 03:01:26 --> Controller Class Initialized
INFO - 2017-07-20 03:01:26 --> Database Driver Class Initialized
INFO - 2017-07-20 03:01:26 --> Model Class Initialized
INFO - 2017-07-20 03:01:26 --> Helper loaded: form_helper
INFO - 2017-07-20 03:01:26 --> Helper loaded: url_helper
INFO - 2017-07-20 03:01:26 --> Model Class Initialized
INFO - 2017-07-20 03:01:26 --> Final output sent to browser
DEBUG - 2017-07-20 03:01:26 --> Total execution time: 0.0950
ERROR - 2017-07-20 03:04:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:04:05 --> Config Class Initialized
INFO - 2017-07-20 03:04:05 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:04:05 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:04:05 --> Utf8 Class Initialized
INFO - 2017-07-20 03:04:05 --> URI Class Initialized
INFO - 2017-07-20 03:04:05 --> Router Class Initialized
INFO - 2017-07-20 03:04:05 --> Output Class Initialized
INFO - 2017-07-20 03:04:05 --> Security Class Initialized
DEBUG - 2017-07-20 03:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:04:05 --> Input Class Initialized
INFO - 2017-07-20 03:04:05 --> Language Class Initialized
INFO - 2017-07-20 03:04:05 --> Loader Class Initialized
INFO - 2017-07-20 03:04:05 --> Controller Class Initialized
INFO - 2017-07-20 03:04:05 --> Database Driver Class Initialized
INFO - 2017-07-20 03:04:05 --> Model Class Initialized
INFO - 2017-07-20 03:04:05 --> Helper loaded: form_helper
INFO - 2017-07-20 03:04:05 --> Helper loaded: url_helper
INFO - 2017-07-20 03:04:05 --> Model Class Initialized
INFO - 2017-07-20 03:04:05 --> Final output sent to browser
DEBUG - 2017-07-20 03:04:05 --> Total execution time: 0.0838
ERROR - 2017-07-20 03:05:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:05:18 --> Config Class Initialized
INFO - 2017-07-20 03:05:18 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:05:18 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:05:18 --> Utf8 Class Initialized
INFO - 2017-07-20 03:05:18 --> URI Class Initialized
INFO - 2017-07-20 03:05:18 --> Router Class Initialized
INFO - 2017-07-20 03:05:18 --> Output Class Initialized
INFO - 2017-07-20 03:05:18 --> Security Class Initialized
DEBUG - 2017-07-20 03:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:05:18 --> Input Class Initialized
INFO - 2017-07-20 03:05:18 --> Language Class Initialized
INFO - 2017-07-20 03:05:18 --> Loader Class Initialized
INFO - 2017-07-20 03:05:18 --> Controller Class Initialized
INFO - 2017-07-20 03:05:18 --> Database Driver Class Initialized
INFO - 2017-07-20 03:05:18 --> Model Class Initialized
INFO - 2017-07-20 03:05:18 --> Helper loaded: form_helper
INFO - 2017-07-20 03:05:18 --> Helper loaded: url_helper
INFO - 2017-07-20 03:05:18 --> Model Class Initialized
INFO - 2017-07-20 03:05:18 --> Final output sent to browser
DEBUG - 2017-07-20 03:05:18 --> Total execution time: 0.0775
ERROR - 2017-07-20 03:06:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:06:15 --> Config Class Initialized
INFO - 2017-07-20 03:06:15 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:06:15 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:06:15 --> Utf8 Class Initialized
INFO - 2017-07-20 03:06:15 --> URI Class Initialized
INFO - 2017-07-20 03:06:15 --> Router Class Initialized
INFO - 2017-07-20 03:06:15 --> Output Class Initialized
INFO - 2017-07-20 03:06:15 --> Security Class Initialized
DEBUG - 2017-07-20 03:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:06:15 --> Input Class Initialized
INFO - 2017-07-20 03:06:15 --> Language Class Initialized
INFO - 2017-07-20 03:06:15 --> Loader Class Initialized
INFO - 2017-07-20 03:06:15 --> Controller Class Initialized
INFO - 2017-07-20 03:06:15 --> Database Driver Class Initialized
INFO - 2017-07-20 03:06:15 --> Model Class Initialized
INFO - 2017-07-20 03:06:15 --> Helper loaded: form_helper
INFO - 2017-07-20 03:06:15 --> Helper loaded: url_helper
INFO - 2017-07-20 03:06:15 --> Model Class Initialized
INFO - 2017-07-20 03:06:15 --> Final output sent to browser
DEBUG - 2017-07-20 03:06:15 --> Total execution time: 0.0788
ERROR - 2017-07-20 03:08:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:08:16 --> Config Class Initialized
INFO - 2017-07-20 03:08:16 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:08:16 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:08:16 --> Utf8 Class Initialized
INFO - 2017-07-20 03:08:16 --> URI Class Initialized
INFO - 2017-07-20 03:08:16 --> Router Class Initialized
INFO - 2017-07-20 03:08:16 --> Output Class Initialized
INFO - 2017-07-20 03:08:16 --> Security Class Initialized
DEBUG - 2017-07-20 03:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:08:16 --> Input Class Initialized
INFO - 2017-07-20 03:08:16 --> Language Class Initialized
INFO - 2017-07-20 03:08:16 --> Loader Class Initialized
INFO - 2017-07-20 03:08:16 --> Controller Class Initialized
INFO - 2017-07-20 03:08:16 --> Database Driver Class Initialized
INFO - 2017-07-20 03:08:16 --> Model Class Initialized
INFO - 2017-07-20 03:08:16 --> Helper loaded: form_helper
INFO - 2017-07-20 03:08:16 --> Helper loaded: url_helper
INFO - 2017-07-20 03:08:16 --> Model Class Initialized
INFO - 2017-07-20 03:08:16 --> Final output sent to browser
DEBUG - 2017-07-20 03:08:16 --> Total execution time: 0.0913
ERROR - 2017-07-20 03:09:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:09:13 --> Config Class Initialized
INFO - 2017-07-20 03:09:13 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:09:13 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:09:13 --> Utf8 Class Initialized
INFO - 2017-07-20 03:09:13 --> URI Class Initialized
INFO - 2017-07-20 03:09:13 --> Router Class Initialized
INFO - 2017-07-20 03:09:13 --> Output Class Initialized
INFO - 2017-07-20 03:09:13 --> Security Class Initialized
DEBUG - 2017-07-20 03:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:09:13 --> Input Class Initialized
INFO - 2017-07-20 03:09:13 --> Language Class Initialized
INFO - 2017-07-20 03:09:13 --> Loader Class Initialized
INFO - 2017-07-20 03:09:13 --> Controller Class Initialized
INFO - 2017-07-20 03:09:13 --> Database Driver Class Initialized
INFO - 2017-07-20 03:09:13 --> Model Class Initialized
INFO - 2017-07-20 03:09:13 --> Helper loaded: form_helper
INFO - 2017-07-20 03:09:13 --> Helper loaded: url_helper
INFO - 2017-07-20 03:09:13 --> Model Class Initialized
INFO - 2017-07-20 03:09:13 --> Final output sent to browser
DEBUG - 2017-07-20 03:09:13 --> Total execution time: 0.1013
ERROR - 2017-07-20 03:10:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:10:02 --> Config Class Initialized
INFO - 2017-07-20 03:10:02 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:10:02 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:10:02 --> Utf8 Class Initialized
INFO - 2017-07-20 03:10:02 --> URI Class Initialized
INFO - 2017-07-20 03:10:02 --> Router Class Initialized
INFO - 2017-07-20 03:10:02 --> Output Class Initialized
INFO - 2017-07-20 03:10:02 --> Security Class Initialized
DEBUG - 2017-07-20 03:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:10:02 --> Input Class Initialized
INFO - 2017-07-20 03:10:02 --> Language Class Initialized
INFO - 2017-07-20 03:10:02 --> Loader Class Initialized
INFO - 2017-07-20 03:10:02 --> Controller Class Initialized
INFO - 2017-07-20 03:10:02 --> Database Driver Class Initialized
INFO - 2017-07-20 03:10:02 --> Model Class Initialized
INFO - 2017-07-20 03:10:02 --> Helper loaded: form_helper
INFO - 2017-07-20 03:10:02 --> Helper loaded: url_helper
INFO - 2017-07-20 03:10:02 --> Model Class Initialized
INFO - 2017-07-20 03:10:02 --> Final output sent to browser
DEBUG - 2017-07-20 03:10:02 --> Total execution time: 0.0850
ERROR - 2017-07-20 03:11:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:11:38 --> Config Class Initialized
INFO - 2017-07-20 03:11:38 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:11:38 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:11:38 --> Utf8 Class Initialized
INFO - 2017-07-20 03:11:38 --> URI Class Initialized
INFO - 2017-07-20 03:11:38 --> Router Class Initialized
INFO - 2017-07-20 03:11:38 --> Output Class Initialized
INFO - 2017-07-20 03:11:38 --> Security Class Initialized
DEBUG - 2017-07-20 03:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:11:38 --> Input Class Initialized
INFO - 2017-07-20 03:11:38 --> Language Class Initialized
INFO - 2017-07-20 03:11:38 --> Loader Class Initialized
INFO - 2017-07-20 03:11:38 --> Controller Class Initialized
INFO - 2017-07-20 03:11:38 --> Database Driver Class Initialized
INFO - 2017-07-20 03:11:38 --> Model Class Initialized
INFO - 2017-07-20 03:11:38 --> Helper loaded: form_helper
INFO - 2017-07-20 03:11:38 --> Helper loaded: url_helper
INFO - 2017-07-20 03:11:38 --> Model Class Initialized
INFO - 2017-07-20 03:11:39 --> Final output sent to browser
DEBUG - 2017-07-20 03:11:39 --> Total execution time: 0.1288
ERROR - 2017-07-20 03:11:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:11:39 --> Config Class Initialized
INFO - 2017-07-20 03:11:39 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:11:39 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:11:39 --> Utf8 Class Initialized
INFO - 2017-07-20 03:11:39 --> URI Class Initialized
INFO - 2017-07-20 03:11:39 --> Router Class Initialized
INFO - 2017-07-20 03:11:39 --> Output Class Initialized
INFO - 2017-07-20 03:11:39 --> Security Class Initialized
DEBUG - 2017-07-20 03:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:11:39 --> Input Class Initialized
INFO - 2017-07-20 03:11:39 --> Language Class Initialized
INFO - 2017-07-20 03:11:39 --> Loader Class Initialized
INFO - 2017-07-20 03:11:39 --> Controller Class Initialized
INFO - 2017-07-20 03:11:39 --> Database Driver Class Initialized
INFO - 2017-07-20 03:11:39 --> Model Class Initialized
INFO - 2017-07-20 03:11:39 --> Helper loaded: form_helper
INFO - 2017-07-20 03:11:39 --> Helper loaded: url_helper
INFO - 2017-07-20 03:11:39 --> Model Class Initialized
INFO - 2017-07-20 03:11:39 --> Final output sent to browser
DEBUG - 2017-07-20 03:11:39 --> Total execution time: 0.0735
ERROR - 2017-07-20 03:11:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:11:45 --> Config Class Initialized
INFO - 2017-07-20 03:11:45 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:11:45 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:11:45 --> Utf8 Class Initialized
INFO - 2017-07-20 03:11:45 --> URI Class Initialized
INFO - 2017-07-20 03:11:45 --> Router Class Initialized
INFO - 2017-07-20 03:11:45 --> Output Class Initialized
INFO - 2017-07-20 03:11:45 --> Security Class Initialized
DEBUG - 2017-07-20 03:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:11:45 --> Input Class Initialized
INFO - 2017-07-20 03:11:45 --> Language Class Initialized
INFO - 2017-07-20 03:11:45 --> Loader Class Initialized
INFO - 2017-07-20 03:11:45 --> Controller Class Initialized
INFO - 2017-07-20 03:11:45 --> Database Driver Class Initialized
INFO - 2017-07-20 03:11:45 --> Model Class Initialized
INFO - 2017-07-20 03:11:45 --> Helper loaded: form_helper
INFO - 2017-07-20 03:11:45 --> Helper loaded: url_helper
INFO - 2017-07-20 03:11:45 --> Model Class Initialized
INFO - 2017-07-20 03:11:45 --> Final output sent to browser
DEBUG - 2017-07-20 03:11:45 --> Total execution time: 0.0963
ERROR - 2017-07-20 03:11:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:11:55 --> Config Class Initialized
INFO - 2017-07-20 03:11:55 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:11:55 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:11:55 --> Utf8 Class Initialized
INFO - 2017-07-20 03:11:55 --> URI Class Initialized
INFO - 2017-07-20 03:11:55 --> Router Class Initialized
INFO - 2017-07-20 03:11:55 --> Output Class Initialized
INFO - 2017-07-20 03:11:55 --> Security Class Initialized
DEBUG - 2017-07-20 03:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:11:55 --> Input Class Initialized
INFO - 2017-07-20 03:11:55 --> Language Class Initialized
INFO - 2017-07-20 03:11:55 --> Loader Class Initialized
INFO - 2017-07-20 03:11:55 --> Controller Class Initialized
INFO - 2017-07-20 03:11:55 --> Database Driver Class Initialized
INFO - 2017-07-20 03:11:55 --> Model Class Initialized
INFO - 2017-07-20 03:11:55 --> Helper loaded: form_helper
INFO - 2017-07-20 03:11:55 --> Helper loaded: url_helper
INFO - 2017-07-20 03:11:55 --> Model Class Initialized
INFO - 2017-07-20 03:11:55 --> Final output sent to browser
DEBUG - 2017-07-20 03:11:55 --> Total execution time: 0.1075
ERROR - 2017-07-20 03:13:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:13:12 --> Config Class Initialized
INFO - 2017-07-20 03:13:12 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:13:12 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:13:12 --> Utf8 Class Initialized
INFO - 2017-07-20 03:13:12 --> URI Class Initialized
INFO - 2017-07-20 03:13:12 --> Router Class Initialized
INFO - 2017-07-20 03:13:12 --> Output Class Initialized
INFO - 2017-07-20 03:13:12 --> Security Class Initialized
DEBUG - 2017-07-20 03:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:13:12 --> Input Class Initialized
INFO - 2017-07-20 03:13:12 --> Language Class Initialized
INFO - 2017-07-20 03:13:12 --> Loader Class Initialized
INFO - 2017-07-20 03:13:12 --> Controller Class Initialized
INFO - 2017-07-20 03:13:12 --> Database Driver Class Initialized
INFO - 2017-07-20 03:13:12 --> Model Class Initialized
INFO - 2017-07-20 03:13:12 --> Helper loaded: form_helper
INFO - 2017-07-20 03:13:12 --> Helper loaded: url_helper
INFO - 2017-07-20 03:13:12 --> Model Class Initialized
INFO - 2017-07-20 03:13:12 --> Final output sent to browser
DEBUG - 2017-07-20 03:13:12 --> Total execution time: 0.0950
ERROR - 2017-07-20 03:13:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:13:49 --> Config Class Initialized
INFO - 2017-07-20 03:13:49 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:13:49 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:13:49 --> Utf8 Class Initialized
INFO - 2017-07-20 03:13:49 --> URI Class Initialized
INFO - 2017-07-20 03:13:49 --> Router Class Initialized
INFO - 2017-07-20 03:13:49 --> Output Class Initialized
INFO - 2017-07-20 03:13:49 --> Security Class Initialized
DEBUG - 2017-07-20 03:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:13:49 --> Input Class Initialized
INFO - 2017-07-20 03:13:49 --> Language Class Initialized
INFO - 2017-07-20 03:13:49 --> Loader Class Initialized
INFO - 2017-07-20 03:13:49 --> Controller Class Initialized
INFO - 2017-07-20 03:13:49 --> Database Driver Class Initialized
INFO - 2017-07-20 03:13:49 --> Model Class Initialized
INFO - 2017-07-20 03:13:49 --> Helper loaded: form_helper
INFO - 2017-07-20 03:13:49 --> Helper loaded: url_helper
INFO - 2017-07-20 03:13:49 --> Model Class Initialized
INFO - 2017-07-20 03:13:49 --> Final output sent to browser
DEBUG - 2017-07-20 03:13:49 --> Total execution time: 0.0925
ERROR - 2017-07-20 03:14:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:14:38 --> Config Class Initialized
INFO - 2017-07-20 03:14:38 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:14:38 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:14:38 --> Utf8 Class Initialized
INFO - 2017-07-20 03:14:38 --> URI Class Initialized
INFO - 2017-07-20 03:14:38 --> Router Class Initialized
INFO - 2017-07-20 03:14:38 --> Output Class Initialized
INFO - 2017-07-20 03:14:38 --> Security Class Initialized
DEBUG - 2017-07-20 03:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:14:38 --> Input Class Initialized
INFO - 2017-07-20 03:14:38 --> Language Class Initialized
INFO - 2017-07-20 03:14:38 --> Loader Class Initialized
INFO - 2017-07-20 03:14:38 --> Controller Class Initialized
INFO - 2017-07-20 03:14:38 --> Database Driver Class Initialized
INFO - 2017-07-20 03:14:38 --> Model Class Initialized
INFO - 2017-07-20 03:14:38 --> Helper loaded: form_helper
INFO - 2017-07-20 03:14:38 --> Helper loaded: url_helper
INFO - 2017-07-20 03:14:38 --> Model Class Initialized
INFO - 2017-07-20 03:14:38 --> Final output sent to browser
DEBUG - 2017-07-20 03:14:38 --> Total execution time: 0.1200
ERROR - 2017-07-20 03:15:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:15:21 --> Config Class Initialized
INFO - 2017-07-20 03:15:21 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:15:21 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:15:21 --> Utf8 Class Initialized
INFO - 2017-07-20 03:15:21 --> URI Class Initialized
INFO - 2017-07-20 03:15:21 --> Router Class Initialized
INFO - 2017-07-20 03:15:21 --> Output Class Initialized
INFO - 2017-07-20 03:15:21 --> Security Class Initialized
DEBUG - 2017-07-20 03:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:15:21 --> Input Class Initialized
INFO - 2017-07-20 03:15:21 --> Language Class Initialized
INFO - 2017-07-20 03:15:21 --> Loader Class Initialized
INFO - 2017-07-20 03:15:21 --> Controller Class Initialized
INFO - 2017-07-20 03:15:21 --> Database Driver Class Initialized
INFO - 2017-07-20 03:15:21 --> Model Class Initialized
INFO - 2017-07-20 03:15:21 --> Helper loaded: form_helper
INFO - 2017-07-20 03:15:21 --> Helper loaded: url_helper
INFO - 2017-07-20 03:15:21 --> Model Class Initialized
INFO - 2017-07-20 03:15:21 --> Final output sent to browser
DEBUG - 2017-07-20 03:15:21 --> Total execution time: 0.0875
ERROR - 2017-07-20 03:17:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:17:28 --> Config Class Initialized
INFO - 2017-07-20 03:17:28 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:17:28 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:17:28 --> Utf8 Class Initialized
INFO - 2017-07-20 03:17:28 --> URI Class Initialized
INFO - 2017-07-20 03:17:28 --> Router Class Initialized
INFO - 2017-07-20 03:17:28 --> Output Class Initialized
INFO - 2017-07-20 03:17:28 --> Security Class Initialized
DEBUG - 2017-07-20 03:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:17:28 --> Input Class Initialized
INFO - 2017-07-20 03:17:28 --> Language Class Initialized
INFO - 2017-07-20 03:17:28 --> Loader Class Initialized
INFO - 2017-07-20 03:17:28 --> Controller Class Initialized
INFO - 2017-07-20 03:17:28 --> Database Driver Class Initialized
INFO - 2017-07-20 03:17:29 --> Model Class Initialized
INFO - 2017-07-20 03:17:29 --> Helper loaded: form_helper
INFO - 2017-07-20 03:17:29 --> Helper loaded: url_helper
INFO - 2017-07-20 03:17:29 --> Model Class Initialized
INFO - 2017-07-20 03:17:29 --> Final output sent to browser
DEBUG - 2017-07-20 03:17:29 --> Total execution time: 0.0825
ERROR - 2017-07-20 03:18:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:18:20 --> Config Class Initialized
INFO - 2017-07-20 03:18:20 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:18:20 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:18:20 --> Utf8 Class Initialized
INFO - 2017-07-20 03:18:20 --> URI Class Initialized
INFO - 2017-07-20 03:18:20 --> Router Class Initialized
INFO - 2017-07-20 03:18:20 --> Output Class Initialized
INFO - 2017-07-20 03:18:20 --> Security Class Initialized
DEBUG - 2017-07-20 03:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:18:20 --> Input Class Initialized
INFO - 2017-07-20 03:18:20 --> Language Class Initialized
INFO - 2017-07-20 03:18:20 --> Loader Class Initialized
INFO - 2017-07-20 03:18:20 --> Controller Class Initialized
INFO - 2017-07-20 03:18:20 --> Database Driver Class Initialized
INFO - 2017-07-20 03:18:20 --> Model Class Initialized
INFO - 2017-07-20 03:18:20 --> Helper loaded: form_helper
INFO - 2017-07-20 03:18:20 --> Helper loaded: url_helper
INFO - 2017-07-20 03:18:20 --> Model Class Initialized
INFO - 2017-07-20 03:18:20 --> Final output sent to browser
DEBUG - 2017-07-20 03:18:20 --> Total execution time: 0.0675
ERROR - 2017-07-20 03:37:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:37:16 --> Config Class Initialized
INFO - 2017-07-20 03:37:16 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:37:16 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:37:16 --> Utf8 Class Initialized
INFO - 2017-07-20 03:37:16 --> URI Class Initialized
INFO - 2017-07-20 03:37:16 --> Router Class Initialized
INFO - 2017-07-20 03:37:16 --> Output Class Initialized
INFO - 2017-07-20 03:37:16 --> Security Class Initialized
DEBUG - 2017-07-20 03:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:37:16 --> Input Class Initialized
INFO - 2017-07-20 03:37:16 --> Language Class Initialized
INFO - 2017-07-20 03:37:16 --> Loader Class Initialized
INFO - 2017-07-20 03:37:16 --> Controller Class Initialized
INFO - 2017-07-20 03:37:16 --> Database Driver Class Initialized
INFO - 2017-07-20 03:37:16 --> Model Class Initialized
INFO - 2017-07-20 03:37:16 --> Helper loaded: form_helper
INFO - 2017-07-20 03:37:16 --> Helper loaded: url_helper
INFO - 2017-07-20 03:37:16 --> Model Class Initialized
INFO - 2017-07-20 03:37:16 --> Final output sent to browser
DEBUG - 2017-07-20 03:37:16 --> Total execution time: 0.0725
ERROR - 2017-07-20 03:38:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:38:19 --> Config Class Initialized
INFO - 2017-07-20 03:38:19 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:38:19 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:38:19 --> Utf8 Class Initialized
INFO - 2017-07-20 03:38:19 --> URI Class Initialized
INFO - 2017-07-20 03:38:19 --> Router Class Initialized
INFO - 2017-07-20 03:38:19 --> Output Class Initialized
INFO - 2017-07-20 03:38:19 --> Security Class Initialized
DEBUG - 2017-07-20 03:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:38:19 --> Input Class Initialized
INFO - 2017-07-20 03:38:19 --> Language Class Initialized
INFO - 2017-07-20 03:38:19 --> Loader Class Initialized
INFO - 2017-07-20 03:38:19 --> Controller Class Initialized
INFO - 2017-07-20 03:38:19 --> Database Driver Class Initialized
INFO - 2017-07-20 03:38:19 --> Model Class Initialized
INFO - 2017-07-20 03:38:19 --> Helper loaded: form_helper
INFO - 2017-07-20 03:38:19 --> Helper loaded: url_helper
INFO - 2017-07-20 03:38:19 --> Model Class Initialized
INFO - 2017-07-20 03:38:19 --> Final output sent to browser
DEBUG - 2017-07-20 03:38:19 --> Total execution time: 0.1000
ERROR - 2017-07-20 03:38:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:38:50 --> Config Class Initialized
INFO - 2017-07-20 03:38:50 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:38:50 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:38:50 --> Utf8 Class Initialized
INFO - 2017-07-20 03:38:50 --> URI Class Initialized
INFO - 2017-07-20 03:38:50 --> Router Class Initialized
INFO - 2017-07-20 03:38:50 --> Output Class Initialized
INFO - 2017-07-20 03:38:50 --> Security Class Initialized
DEBUG - 2017-07-20 03:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:38:50 --> Input Class Initialized
INFO - 2017-07-20 03:38:50 --> Language Class Initialized
INFO - 2017-07-20 03:38:50 --> Loader Class Initialized
INFO - 2017-07-20 03:38:50 --> Controller Class Initialized
INFO - 2017-07-20 03:38:50 --> Database Driver Class Initialized
INFO - 2017-07-20 03:38:50 --> Model Class Initialized
INFO - 2017-07-20 03:38:50 --> Helper loaded: form_helper
INFO - 2017-07-20 03:38:50 --> Helper loaded: url_helper
INFO - 2017-07-20 03:38:50 --> Model Class Initialized
INFO - 2017-07-20 03:38:50 --> Final output sent to browser
DEBUG - 2017-07-20 03:38:50 --> Total execution time: 0.0600
ERROR - 2017-07-20 03:38:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:38:52 --> Config Class Initialized
INFO - 2017-07-20 03:38:52 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:38:52 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:38:52 --> Utf8 Class Initialized
INFO - 2017-07-20 03:38:52 --> URI Class Initialized
INFO - 2017-07-20 03:38:52 --> Router Class Initialized
INFO - 2017-07-20 03:38:52 --> Output Class Initialized
INFO - 2017-07-20 03:38:52 --> Security Class Initialized
DEBUG - 2017-07-20 03:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:38:52 --> Input Class Initialized
INFO - 2017-07-20 03:38:52 --> Language Class Initialized
INFO - 2017-07-20 03:38:52 --> Loader Class Initialized
INFO - 2017-07-20 03:38:52 --> Controller Class Initialized
INFO - 2017-07-20 03:38:52 --> Database Driver Class Initialized
INFO - 2017-07-20 03:38:53 --> Model Class Initialized
INFO - 2017-07-20 03:38:53 --> Helper loaded: form_helper
INFO - 2017-07-20 03:38:53 --> Helper loaded: url_helper
INFO - 2017-07-20 03:38:53 --> Model Class Initialized
INFO - 2017-07-20 03:38:53 --> Final output sent to browser
DEBUG - 2017-07-20 03:38:53 --> Total execution time: 0.0900
ERROR - 2017-07-20 03:38:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:38:59 --> Config Class Initialized
INFO - 2017-07-20 03:38:59 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:38:59 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:38:59 --> Utf8 Class Initialized
INFO - 2017-07-20 03:38:59 --> URI Class Initialized
INFO - 2017-07-20 03:38:59 --> Router Class Initialized
INFO - 2017-07-20 03:38:59 --> Output Class Initialized
INFO - 2017-07-20 03:38:59 --> Security Class Initialized
DEBUG - 2017-07-20 03:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:38:59 --> Input Class Initialized
INFO - 2017-07-20 03:38:59 --> Language Class Initialized
INFO - 2017-07-20 03:38:59 --> Loader Class Initialized
INFO - 2017-07-20 03:38:59 --> Controller Class Initialized
INFO - 2017-07-20 03:38:59 --> Database Driver Class Initialized
INFO - 2017-07-20 03:38:59 --> Model Class Initialized
INFO - 2017-07-20 03:38:59 --> Helper loaded: form_helper
INFO - 2017-07-20 03:38:59 --> Helper loaded: url_helper
INFO - 2017-07-20 03:38:59 --> Model Class Initialized
INFO - 2017-07-20 03:38:59 --> Final output sent to browser
DEBUG - 2017-07-20 03:38:59 --> Total execution time: 0.1100
ERROR - 2017-07-20 03:39:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:39:33 --> Config Class Initialized
INFO - 2017-07-20 03:39:33 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:39:33 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:39:33 --> Utf8 Class Initialized
INFO - 2017-07-20 03:39:33 --> URI Class Initialized
INFO - 2017-07-20 03:39:33 --> Router Class Initialized
INFO - 2017-07-20 03:39:33 --> Output Class Initialized
INFO - 2017-07-20 03:39:33 --> Security Class Initialized
DEBUG - 2017-07-20 03:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:39:33 --> Input Class Initialized
INFO - 2017-07-20 03:39:33 --> Language Class Initialized
INFO - 2017-07-20 03:39:33 --> Loader Class Initialized
INFO - 2017-07-20 03:39:33 --> Controller Class Initialized
INFO - 2017-07-20 03:39:33 --> Database Driver Class Initialized
INFO - 2017-07-20 03:39:33 --> Model Class Initialized
INFO - 2017-07-20 03:39:33 --> Helper loaded: form_helper
INFO - 2017-07-20 03:39:33 --> Helper loaded: url_helper
INFO - 2017-07-20 03:39:33 --> Model Class Initialized
INFO - 2017-07-20 03:39:33 --> Final output sent to browser
DEBUG - 2017-07-20 03:39:33 --> Total execution time: 0.0925
ERROR - 2017-07-20 03:40:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:40:07 --> Config Class Initialized
INFO - 2017-07-20 03:40:07 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:40:07 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:40:07 --> Utf8 Class Initialized
INFO - 2017-07-20 03:40:07 --> URI Class Initialized
INFO - 2017-07-20 03:40:07 --> Router Class Initialized
INFO - 2017-07-20 03:40:07 --> Output Class Initialized
INFO - 2017-07-20 03:40:07 --> Security Class Initialized
DEBUG - 2017-07-20 03:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:40:07 --> Input Class Initialized
INFO - 2017-07-20 03:40:07 --> Language Class Initialized
INFO - 2017-07-20 03:40:07 --> Loader Class Initialized
INFO - 2017-07-20 03:40:07 --> Controller Class Initialized
INFO - 2017-07-20 03:40:07 --> Database Driver Class Initialized
INFO - 2017-07-20 03:40:07 --> Model Class Initialized
INFO - 2017-07-20 03:40:07 --> Helper loaded: form_helper
INFO - 2017-07-20 03:40:07 --> Helper loaded: url_helper
INFO - 2017-07-20 03:40:07 --> Model Class Initialized
INFO - 2017-07-20 03:40:07 --> Final output sent to browser
DEBUG - 2017-07-20 03:40:07 --> Total execution time: 0.0700
ERROR - 2017-07-20 03:40:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:40:16 --> Config Class Initialized
INFO - 2017-07-20 03:40:16 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:40:16 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:40:16 --> Utf8 Class Initialized
INFO - 2017-07-20 03:40:16 --> URI Class Initialized
INFO - 2017-07-20 03:40:16 --> Router Class Initialized
INFO - 2017-07-20 03:40:16 --> Output Class Initialized
INFO - 2017-07-20 03:40:16 --> Security Class Initialized
DEBUG - 2017-07-20 03:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:40:16 --> Input Class Initialized
INFO - 2017-07-20 03:40:16 --> Language Class Initialized
INFO - 2017-07-20 03:40:16 --> Loader Class Initialized
INFO - 2017-07-20 03:40:16 --> Controller Class Initialized
INFO - 2017-07-20 03:40:16 --> Database Driver Class Initialized
INFO - 2017-07-20 03:40:16 --> Model Class Initialized
INFO - 2017-07-20 03:40:16 --> Helper loaded: form_helper
INFO - 2017-07-20 03:40:16 --> Helper loaded: url_helper
INFO - 2017-07-20 03:40:16 --> Model Class Initialized
INFO - 2017-07-20 03:40:16 --> Final output sent to browser
DEBUG - 2017-07-20 03:40:16 --> Total execution time: 0.0800
ERROR - 2017-07-20 03:45:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:45:06 --> Config Class Initialized
INFO - 2017-07-20 03:45:06 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:45:06 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:45:06 --> Utf8 Class Initialized
INFO - 2017-07-20 03:45:06 --> URI Class Initialized
INFO - 2017-07-20 03:45:06 --> Router Class Initialized
INFO - 2017-07-20 03:45:06 --> Output Class Initialized
INFO - 2017-07-20 03:45:06 --> Security Class Initialized
DEBUG - 2017-07-20 03:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:45:06 --> Input Class Initialized
INFO - 2017-07-20 03:45:06 --> Language Class Initialized
INFO - 2017-07-20 03:45:06 --> Loader Class Initialized
INFO - 2017-07-20 03:45:06 --> Controller Class Initialized
INFO - 2017-07-20 03:45:06 --> Database Driver Class Initialized
INFO - 2017-07-20 03:45:06 --> Model Class Initialized
INFO - 2017-07-20 03:45:06 --> Helper loaded: form_helper
INFO - 2017-07-20 03:45:06 --> Helper loaded: url_helper
INFO - 2017-07-20 03:45:06 --> Model Class Initialized
INFO - 2017-07-20 03:45:06 --> Final output sent to browser
DEBUG - 2017-07-20 03:45:06 --> Total execution time: 0.1100
ERROR - 2017-07-20 03:45:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:45:06 --> Config Class Initialized
INFO - 2017-07-20 03:45:06 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:45:06 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:45:06 --> Utf8 Class Initialized
INFO - 2017-07-20 03:45:06 --> URI Class Initialized
INFO - 2017-07-20 03:45:06 --> Router Class Initialized
INFO - 2017-07-20 03:45:06 --> Output Class Initialized
INFO - 2017-07-20 03:45:06 --> Security Class Initialized
DEBUG - 2017-07-20 03:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:45:06 --> Input Class Initialized
INFO - 2017-07-20 03:45:06 --> Language Class Initialized
INFO - 2017-07-20 03:45:06 --> Loader Class Initialized
INFO - 2017-07-20 03:45:06 --> Controller Class Initialized
INFO - 2017-07-20 03:45:06 --> Database Driver Class Initialized
INFO - 2017-07-20 03:45:06 --> Model Class Initialized
INFO - 2017-07-20 03:45:06 --> Helper loaded: form_helper
INFO - 2017-07-20 03:45:06 --> Helper loaded: url_helper
INFO - 2017-07-20 03:45:06 --> Model Class Initialized
INFO - 2017-07-20 03:45:06 --> Final output sent to browser
DEBUG - 2017-07-20 03:45:06 --> Total execution time: 0.0550
ERROR - 2017-07-20 03:45:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:45:19 --> Config Class Initialized
INFO - 2017-07-20 03:45:19 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:45:19 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:45:19 --> Utf8 Class Initialized
INFO - 2017-07-20 03:45:19 --> URI Class Initialized
INFO - 2017-07-20 03:45:19 --> Router Class Initialized
INFO - 2017-07-20 03:45:19 --> Output Class Initialized
INFO - 2017-07-20 03:45:19 --> Security Class Initialized
DEBUG - 2017-07-20 03:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:45:19 --> Input Class Initialized
INFO - 2017-07-20 03:45:19 --> Language Class Initialized
INFO - 2017-07-20 03:45:19 --> Loader Class Initialized
INFO - 2017-07-20 03:45:19 --> Controller Class Initialized
INFO - 2017-07-20 03:45:19 --> Database Driver Class Initialized
INFO - 2017-07-20 03:45:19 --> Model Class Initialized
INFO - 2017-07-20 03:45:19 --> Helper loaded: form_helper
INFO - 2017-07-20 03:45:19 --> Helper loaded: url_helper
INFO - 2017-07-20 03:45:19 --> Model Class Initialized
INFO - 2017-07-20 03:45:19 --> Final output sent to browser
DEBUG - 2017-07-20 03:45:19 --> Total execution time: 0.0575
ERROR - 2017-07-20 03:47:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:47:13 --> Config Class Initialized
INFO - 2017-07-20 03:47:13 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:47:13 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:47:13 --> Utf8 Class Initialized
INFO - 2017-07-20 03:47:13 --> URI Class Initialized
INFO - 2017-07-20 03:47:13 --> Router Class Initialized
INFO - 2017-07-20 03:47:13 --> Output Class Initialized
INFO - 2017-07-20 03:47:13 --> Security Class Initialized
DEBUG - 2017-07-20 03:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:47:13 --> Input Class Initialized
INFO - 2017-07-20 03:47:13 --> Language Class Initialized
INFO - 2017-07-20 03:47:13 --> Loader Class Initialized
INFO - 2017-07-20 03:47:13 --> Controller Class Initialized
INFO - 2017-07-20 03:47:13 --> Database Driver Class Initialized
INFO - 2017-07-20 03:47:13 --> Model Class Initialized
INFO - 2017-07-20 03:47:13 --> Helper loaded: form_helper
INFO - 2017-07-20 03:47:13 --> Helper loaded: url_helper
INFO - 2017-07-20 03:47:13 --> Model Class Initialized
INFO - 2017-07-20 03:47:13 --> Final output sent to browser
DEBUG - 2017-07-20 03:47:13 --> Total execution time: 0.0850
ERROR - 2017-07-20 03:47:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:47:14 --> Config Class Initialized
INFO - 2017-07-20 03:47:14 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:47:14 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:47:14 --> Utf8 Class Initialized
INFO - 2017-07-20 03:47:14 --> URI Class Initialized
INFO - 2017-07-20 03:47:14 --> Router Class Initialized
INFO - 2017-07-20 03:47:14 --> Output Class Initialized
INFO - 2017-07-20 03:47:14 --> Security Class Initialized
DEBUG - 2017-07-20 03:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:47:14 --> Input Class Initialized
INFO - 2017-07-20 03:47:14 --> Language Class Initialized
INFO - 2017-07-20 03:47:14 --> Loader Class Initialized
INFO - 2017-07-20 03:47:14 --> Controller Class Initialized
INFO - 2017-07-20 03:47:14 --> Database Driver Class Initialized
INFO - 2017-07-20 03:47:14 --> Model Class Initialized
INFO - 2017-07-20 03:47:14 --> Helper loaded: form_helper
INFO - 2017-07-20 03:47:14 --> Helper loaded: url_helper
INFO - 2017-07-20 03:47:14 --> Model Class Initialized
INFO - 2017-07-20 03:47:14 --> Final output sent to browser
DEBUG - 2017-07-20 03:47:14 --> Total execution time: 0.0675
ERROR - 2017-07-20 03:47:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:47:27 --> Config Class Initialized
INFO - 2017-07-20 03:47:27 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:47:27 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:47:27 --> Utf8 Class Initialized
INFO - 2017-07-20 03:47:27 --> URI Class Initialized
INFO - 2017-07-20 03:47:27 --> Router Class Initialized
INFO - 2017-07-20 03:47:27 --> Output Class Initialized
INFO - 2017-07-20 03:47:27 --> Security Class Initialized
DEBUG - 2017-07-20 03:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:47:27 --> Input Class Initialized
INFO - 2017-07-20 03:47:27 --> Language Class Initialized
INFO - 2017-07-20 03:47:27 --> Loader Class Initialized
INFO - 2017-07-20 03:47:27 --> Controller Class Initialized
INFO - 2017-07-20 03:47:27 --> Database Driver Class Initialized
INFO - 2017-07-20 03:47:27 --> Model Class Initialized
INFO - 2017-07-20 03:47:27 --> Helper loaded: form_helper
INFO - 2017-07-20 03:47:27 --> Helper loaded: url_helper
INFO - 2017-07-20 03:47:27 --> Model Class Initialized
INFO - 2017-07-20 03:47:27 --> Final output sent to browser
DEBUG - 2017-07-20 03:47:27 --> Total execution time: 0.0562
ERROR - 2017-07-20 03:49:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:49:46 --> Config Class Initialized
INFO - 2017-07-20 03:49:46 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:49:46 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:49:46 --> Utf8 Class Initialized
INFO - 2017-07-20 03:49:46 --> URI Class Initialized
INFO - 2017-07-20 03:49:46 --> Router Class Initialized
INFO - 2017-07-20 03:49:46 --> Output Class Initialized
INFO - 2017-07-20 03:49:46 --> Security Class Initialized
DEBUG - 2017-07-20 03:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:49:46 --> Input Class Initialized
INFO - 2017-07-20 03:49:46 --> Language Class Initialized
INFO - 2017-07-20 03:49:46 --> Loader Class Initialized
INFO - 2017-07-20 03:49:46 --> Controller Class Initialized
INFO - 2017-07-20 03:49:46 --> Database Driver Class Initialized
INFO - 2017-07-20 03:49:46 --> Model Class Initialized
INFO - 2017-07-20 03:49:47 --> Helper loaded: form_helper
INFO - 2017-07-20 03:49:47 --> Helper loaded: url_helper
INFO - 2017-07-20 03:49:47 --> Model Class Initialized
INFO - 2017-07-20 03:49:47 --> Final output sent to browser
DEBUG - 2017-07-20 03:49:47 --> Total execution time: 0.0575
ERROR - 2017-07-20 03:57:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:57:27 --> Config Class Initialized
INFO - 2017-07-20 03:57:27 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:57:27 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:57:27 --> Utf8 Class Initialized
INFO - 2017-07-20 03:57:27 --> URI Class Initialized
INFO - 2017-07-20 03:57:27 --> Router Class Initialized
INFO - 2017-07-20 03:57:27 --> Output Class Initialized
INFO - 2017-07-20 03:57:27 --> Security Class Initialized
DEBUG - 2017-07-20 03:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:57:27 --> Input Class Initialized
INFO - 2017-07-20 03:57:27 --> Language Class Initialized
INFO - 2017-07-20 03:57:27 --> Loader Class Initialized
INFO - 2017-07-20 03:57:27 --> Controller Class Initialized
INFO - 2017-07-20 03:57:27 --> Database Driver Class Initialized
INFO - 2017-07-20 03:57:27 --> Model Class Initialized
INFO - 2017-07-20 03:57:27 --> Helper loaded: form_helper
INFO - 2017-07-20 03:57:27 --> Helper loaded: url_helper
INFO - 2017-07-20 03:57:27 --> Model Class Initialized
INFO - 2017-07-20 03:57:27 --> Final output sent to browser
DEBUG - 2017-07-20 03:57:27 --> Total execution time: 0.0775
ERROR - 2017-07-20 03:57:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:57:28 --> Config Class Initialized
INFO - 2017-07-20 03:57:28 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:57:28 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:57:28 --> Utf8 Class Initialized
INFO - 2017-07-20 03:57:28 --> URI Class Initialized
INFO - 2017-07-20 03:57:28 --> Router Class Initialized
INFO - 2017-07-20 03:57:28 --> Output Class Initialized
INFO - 2017-07-20 03:57:28 --> Security Class Initialized
DEBUG - 2017-07-20 03:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:57:28 --> Input Class Initialized
INFO - 2017-07-20 03:57:28 --> Language Class Initialized
INFO - 2017-07-20 03:57:28 --> Loader Class Initialized
INFO - 2017-07-20 03:57:28 --> Controller Class Initialized
INFO - 2017-07-20 03:57:28 --> Database Driver Class Initialized
INFO - 2017-07-20 03:57:28 --> Model Class Initialized
INFO - 2017-07-20 03:57:28 --> Helper loaded: form_helper
INFO - 2017-07-20 03:57:28 --> Helper loaded: url_helper
INFO - 2017-07-20 03:57:28 --> Model Class Initialized
INFO - 2017-07-20 03:57:28 --> Final output sent to browser
DEBUG - 2017-07-20 03:57:28 --> Total execution time: 0.0550
ERROR - 2017-07-20 03:57:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 03:57:45 --> Config Class Initialized
INFO - 2017-07-20 03:57:45 --> Hooks Class Initialized
DEBUG - 2017-07-20 03:57:45 --> UTF-8 Support Enabled
INFO - 2017-07-20 03:57:45 --> Utf8 Class Initialized
INFO - 2017-07-20 03:57:45 --> URI Class Initialized
INFO - 2017-07-20 03:57:45 --> Router Class Initialized
INFO - 2017-07-20 03:57:45 --> Output Class Initialized
INFO - 2017-07-20 03:57:45 --> Security Class Initialized
DEBUG - 2017-07-20 03:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 03:57:45 --> Input Class Initialized
INFO - 2017-07-20 03:57:45 --> Language Class Initialized
INFO - 2017-07-20 03:57:45 --> Loader Class Initialized
INFO - 2017-07-20 03:57:45 --> Controller Class Initialized
INFO - 2017-07-20 03:57:45 --> Database Driver Class Initialized
INFO - 2017-07-20 03:57:45 --> Model Class Initialized
INFO - 2017-07-20 03:57:45 --> Helper loaded: form_helper
INFO - 2017-07-20 03:57:45 --> Helper loaded: url_helper
INFO - 2017-07-20 03:57:45 --> Model Class Initialized
INFO - 2017-07-20 03:57:45 --> Final output sent to browser
DEBUG - 2017-07-20 03:57:45 --> Total execution time: 0.0475
ERROR - 2017-07-20 04:00:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:00:26 --> Config Class Initialized
INFO - 2017-07-20 04:00:26 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:00:26 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:00:26 --> Utf8 Class Initialized
INFO - 2017-07-20 04:00:26 --> URI Class Initialized
INFO - 2017-07-20 04:00:26 --> Router Class Initialized
INFO - 2017-07-20 04:00:26 --> Output Class Initialized
INFO - 2017-07-20 04:00:26 --> Security Class Initialized
DEBUG - 2017-07-20 04:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:00:26 --> Input Class Initialized
INFO - 2017-07-20 04:00:26 --> Language Class Initialized
INFO - 2017-07-20 04:00:26 --> Loader Class Initialized
INFO - 2017-07-20 04:00:26 --> Controller Class Initialized
INFO - 2017-07-20 04:00:26 --> Database Driver Class Initialized
INFO - 2017-07-20 04:00:26 --> Model Class Initialized
INFO - 2017-07-20 04:00:26 --> Helper loaded: form_helper
INFO - 2017-07-20 04:00:26 --> Helper loaded: url_helper
INFO - 2017-07-20 04:00:26 --> Model Class Initialized
INFO - 2017-07-20 04:00:26 --> Final output sent to browser
DEBUG - 2017-07-20 04:00:26 --> Total execution time: 0.0900
ERROR - 2017-07-20 04:00:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:00:27 --> Config Class Initialized
INFO - 2017-07-20 04:00:27 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:00:27 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:00:27 --> Utf8 Class Initialized
INFO - 2017-07-20 04:00:27 --> URI Class Initialized
INFO - 2017-07-20 04:00:27 --> Router Class Initialized
INFO - 2017-07-20 04:00:27 --> Output Class Initialized
INFO - 2017-07-20 04:00:27 --> Security Class Initialized
DEBUG - 2017-07-20 04:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:00:27 --> Input Class Initialized
INFO - 2017-07-20 04:00:27 --> Language Class Initialized
INFO - 2017-07-20 04:00:27 --> Loader Class Initialized
INFO - 2017-07-20 04:00:27 --> Controller Class Initialized
INFO - 2017-07-20 04:00:27 --> Database Driver Class Initialized
INFO - 2017-07-20 04:00:27 --> Model Class Initialized
INFO - 2017-07-20 04:00:27 --> Helper loaded: form_helper
INFO - 2017-07-20 04:00:27 --> Helper loaded: url_helper
INFO - 2017-07-20 04:00:27 --> Model Class Initialized
INFO - 2017-07-20 04:00:27 --> Final output sent to browser
DEBUG - 2017-07-20 04:00:27 --> Total execution time: 0.0625
ERROR - 2017-07-20 04:00:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:00:36 --> Config Class Initialized
INFO - 2017-07-20 04:00:36 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:00:36 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:00:36 --> Utf8 Class Initialized
INFO - 2017-07-20 04:00:36 --> URI Class Initialized
INFO - 2017-07-20 04:00:36 --> Router Class Initialized
INFO - 2017-07-20 04:00:36 --> Output Class Initialized
INFO - 2017-07-20 04:00:36 --> Security Class Initialized
DEBUG - 2017-07-20 04:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:00:36 --> Input Class Initialized
INFO - 2017-07-20 04:00:36 --> Language Class Initialized
INFO - 2017-07-20 04:00:36 --> Loader Class Initialized
INFO - 2017-07-20 04:00:36 --> Controller Class Initialized
INFO - 2017-07-20 04:00:36 --> Database Driver Class Initialized
INFO - 2017-07-20 04:00:36 --> Model Class Initialized
INFO - 2017-07-20 04:00:36 --> Helper loaded: form_helper
INFO - 2017-07-20 04:00:36 --> Helper loaded: url_helper
INFO - 2017-07-20 04:00:36 --> Model Class Initialized
INFO - 2017-07-20 04:00:36 --> Final output sent to browser
DEBUG - 2017-07-20 04:00:36 --> Total execution time: 0.0563
ERROR - 2017-07-20 04:01:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:01:34 --> Config Class Initialized
INFO - 2017-07-20 04:01:34 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:01:34 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:01:34 --> Utf8 Class Initialized
INFO - 2017-07-20 04:01:34 --> URI Class Initialized
INFO - 2017-07-20 04:01:34 --> Router Class Initialized
INFO - 2017-07-20 04:01:34 --> Output Class Initialized
INFO - 2017-07-20 04:01:34 --> Security Class Initialized
DEBUG - 2017-07-20 04:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:01:34 --> Input Class Initialized
INFO - 2017-07-20 04:01:34 --> Language Class Initialized
INFO - 2017-07-20 04:01:34 --> Loader Class Initialized
INFO - 2017-07-20 04:01:34 --> Controller Class Initialized
INFO - 2017-07-20 04:01:34 --> Database Driver Class Initialized
INFO - 2017-07-20 04:01:34 --> Model Class Initialized
INFO - 2017-07-20 04:01:34 --> Helper loaded: form_helper
INFO - 2017-07-20 04:01:34 --> Helper loaded: url_helper
INFO - 2017-07-20 04:01:34 --> Model Class Initialized
INFO - 2017-07-20 04:01:34 --> Final output sent to browser
DEBUG - 2017-07-20 04:01:34 --> Total execution time: 0.0925
ERROR - 2017-07-20 04:01:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:01:35 --> Config Class Initialized
INFO - 2017-07-20 04:01:35 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:01:35 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:01:35 --> Utf8 Class Initialized
INFO - 2017-07-20 04:01:35 --> URI Class Initialized
INFO - 2017-07-20 04:01:35 --> Router Class Initialized
INFO - 2017-07-20 04:01:35 --> Output Class Initialized
INFO - 2017-07-20 04:01:35 --> Security Class Initialized
DEBUG - 2017-07-20 04:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:01:35 --> Input Class Initialized
INFO - 2017-07-20 04:01:35 --> Language Class Initialized
INFO - 2017-07-20 04:01:35 --> Loader Class Initialized
INFO - 2017-07-20 04:01:35 --> Controller Class Initialized
INFO - 2017-07-20 04:01:35 --> Database Driver Class Initialized
INFO - 2017-07-20 04:01:35 --> Model Class Initialized
INFO - 2017-07-20 04:01:35 --> Helper loaded: form_helper
INFO - 2017-07-20 04:01:35 --> Helper loaded: url_helper
INFO - 2017-07-20 04:01:35 --> Model Class Initialized
INFO - 2017-07-20 04:01:35 --> Final output sent to browser
DEBUG - 2017-07-20 04:01:35 --> Total execution time: 0.0475
ERROR - 2017-07-20 04:01:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:01:43 --> Config Class Initialized
INFO - 2017-07-20 04:01:43 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:01:43 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:01:43 --> Utf8 Class Initialized
INFO - 2017-07-20 04:01:43 --> URI Class Initialized
INFO - 2017-07-20 04:01:43 --> Router Class Initialized
INFO - 2017-07-20 04:01:43 --> Output Class Initialized
INFO - 2017-07-20 04:01:43 --> Security Class Initialized
DEBUG - 2017-07-20 04:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:01:43 --> Input Class Initialized
INFO - 2017-07-20 04:01:43 --> Language Class Initialized
INFO - 2017-07-20 04:01:43 --> Loader Class Initialized
INFO - 2017-07-20 04:01:43 --> Controller Class Initialized
INFO - 2017-07-20 04:01:43 --> Database Driver Class Initialized
INFO - 2017-07-20 04:01:43 --> Model Class Initialized
INFO - 2017-07-20 04:01:43 --> Helper loaded: form_helper
INFO - 2017-07-20 04:01:43 --> Helper loaded: url_helper
INFO - 2017-07-20 04:01:43 --> Model Class Initialized
INFO - 2017-07-20 04:01:43 --> Final output sent to browser
DEBUG - 2017-07-20 04:01:43 --> Total execution time: 0.0525
ERROR - 2017-07-20 04:02:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:02:36 --> Config Class Initialized
INFO - 2017-07-20 04:02:36 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:02:36 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:02:36 --> Utf8 Class Initialized
INFO - 2017-07-20 04:02:36 --> URI Class Initialized
INFO - 2017-07-20 04:02:36 --> Router Class Initialized
INFO - 2017-07-20 04:02:36 --> Output Class Initialized
INFO - 2017-07-20 04:02:36 --> Security Class Initialized
DEBUG - 2017-07-20 04:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:02:36 --> Input Class Initialized
INFO - 2017-07-20 04:02:36 --> Language Class Initialized
INFO - 2017-07-20 04:02:36 --> Loader Class Initialized
INFO - 2017-07-20 04:02:36 --> Controller Class Initialized
INFO - 2017-07-20 04:02:36 --> Database Driver Class Initialized
INFO - 2017-07-20 04:02:36 --> Model Class Initialized
INFO - 2017-07-20 04:02:36 --> Helper loaded: form_helper
INFO - 2017-07-20 04:02:36 --> Helper loaded: url_helper
INFO - 2017-07-20 04:02:36 --> Model Class Initialized
INFO - 2017-07-20 04:02:36 --> Final output sent to browser
DEBUG - 2017-07-20 04:02:36 --> Total execution time: 0.0825
ERROR - 2017-07-20 04:02:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:02:37 --> Config Class Initialized
INFO - 2017-07-20 04:02:37 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:02:37 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:02:37 --> Utf8 Class Initialized
INFO - 2017-07-20 04:02:37 --> URI Class Initialized
INFO - 2017-07-20 04:02:37 --> Router Class Initialized
INFO - 2017-07-20 04:02:37 --> Output Class Initialized
INFO - 2017-07-20 04:02:37 --> Security Class Initialized
DEBUG - 2017-07-20 04:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:02:37 --> Input Class Initialized
INFO - 2017-07-20 04:02:37 --> Language Class Initialized
INFO - 2017-07-20 04:02:37 --> Loader Class Initialized
INFO - 2017-07-20 04:02:37 --> Controller Class Initialized
INFO - 2017-07-20 04:02:37 --> Database Driver Class Initialized
INFO - 2017-07-20 04:02:37 --> Model Class Initialized
INFO - 2017-07-20 04:02:37 --> Helper loaded: form_helper
INFO - 2017-07-20 04:02:37 --> Helper loaded: url_helper
INFO - 2017-07-20 04:02:37 --> Model Class Initialized
INFO - 2017-07-20 04:02:37 --> Final output sent to browser
DEBUG - 2017-07-20 04:02:37 --> Total execution time: 0.0575
ERROR - 2017-07-20 04:02:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:02:51 --> Config Class Initialized
INFO - 2017-07-20 04:02:51 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:02:51 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:02:51 --> Utf8 Class Initialized
INFO - 2017-07-20 04:02:51 --> URI Class Initialized
INFO - 2017-07-20 04:02:51 --> Router Class Initialized
INFO - 2017-07-20 04:02:51 --> Output Class Initialized
INFO - 2017-07-20 04:02:51 --> Security Class Initialized
DEBUG - 2017-07-20 04:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:02:51 --> Input Class Initialized
INFO - 2017-07-20 04:02:51 --> Language Class Initialized
INFO - 2017-07-20 04:02:51 --> Loader Class Initialized
INFO - 2017-07-20 04:02:51 --> Controller Class Initialized
INFO - 2017-07-20 04:02:51 --> Database Driver Class Initialized
INFO - 2017-07-20 04:02:51 --> Model Class Initialized
INFO - 2017-07-20 04:02:51 --> Helper loaded: form_helper
INFO - 2017-07-20 04:02:51 --> Helper loaded: url_helper
INFO - 2017-07-20 04:02:51 --> Model Class Initialized
INFO - 2017-07-20 04:02:51 --> Final output sent to browser
DEBUG - 2017-07-20 04:02:51 --> Total execution time: 0.0550
ERROR - 2017-07-20 04:04:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:04:56 --> Config Class Initialized
INFO - 2017-07-20 04:04:56 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:04:56 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:04:56 --> Utf8 Class Initialized
INFO - 2017-07-20 04:04:56 --> URI Class Initialized
INFO - 2017-07-20 04:04:56 --> Router Class Initialized
INFO - 2017-07-20 04:04:56 --> Output Class Initialized
INFO - 2017-07-20 04:04:56 --> Security Class Initialized
DEBUG - 2017-07-20 04:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:04:57 --> Input Class Initialized
INFO - 2017-07-20 04:04:57 --> Language Class Initialized
INFO - 2017-07-20 04:04:57 --> Loader Class Initialized
INFO - 2017-07-20 04:04:57 --> Controller Class Initialized
INFO - 2017-07-20 04:04:57 --> Database Driver Class Initialized
INFO - 2017-07-20 04:04:57 --> Model Class Initialized
INFO - 2017-07-20 04:04:57 --> Helper loaded: form_helper
INFO - 2017-07-20 04:04:57 --> Helper loaded: url_helper
INFO - 2017-07-20 04:04:57 --> Model Class Initialized
INFO - 2017-07-20 04:04:57 --> Final output sent to browser
DEBUG - 2017-07-20 04:04:57 --> Total execution time: 0.0975
ERROR - 2017-07-20 04:04:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:04:58 --> Config Class Initialized
INFO - 2017-07-20 04:04:58 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:04:58 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:04:58 --> Utf8 Class Initialized
INFO - 2017-07-20 04:04:58 --> URI Class Initialized
INFO - 2017-07-20 04:04:58 --> Router Class Initialized
INFO - 2017-07-20 04:04:58 --> Output Class Initialized
INFO - 2017-07-20 04:04:58 --> Security Class Initialized
DEBUG - 2017-07-20 04:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:04:58 --> Input Class Initialized
INFO - 2017-07-20 04:04:58 --> Language Class Initialized
INFO - 2017-07-20 04:04:58 --> Loader Class Initialized
INFO - 2017-07-20 04:04:58 --> Controller Class Initialized
INFO - 2017-07-20 04:04:58 --> Database Driver Class Initialized
INFO - 2017-07-20 04:04:58 --> Model Class Initialized
INFO - 2017-07-20 04:04:58 --> Helper loaded: form_helper
INFO - 2017-07-20 04:04:58 --> Helper loaded: url_helper
INFO - 2017-07-20 04:04:58 --> Model Class Initialized
INFO - 2017-07-20 04:04:58 --> Final output sent to browser
DEBUG - 2017-07-20 04:04:58 --> Total execution time: 0.0475
ERROR - 2017-07-20 04:05:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:05:11 --> Config Class Initialized
INFO - 2017-07-20 04:05:11 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:05:11 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:05:11 --> Utf8 Class Initialized
INFO - 2017-07-20 04:05:11 --> URI Class Initialized
INFO - 2017-07-20 04:05:11 --> Router Class Initialized
INFO - 2017-07-20 04:05:11 --> Output Class Initialized
INFO - 2017-07-20 04:05:11 --> Security Class Initialized
DEBUG - 2017-07-20 04:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:05:11 --> Input Class Initialized
INFO - 2017-07-20 04:05:11 --> Language Class Initialized
INFO - 2017-07-20 04:05:11 --> Loader Class Initialized
INFO - 2017-07-20 04:05:11 --> Controller Class Initialized
INFO - 2017-07-20 04:05:11 --> Database Driver Class Initialized
INFO - 2017-07-20 04:05:11 --> Model Class Initialized
INFO - 2017-07-20 04:05:11 --> Helper loaded: form_helper
INFO - 2017-07-20 04:05:11 --> Helper loaded: url_helper
INFO - 2017-07-20 04:05:11 --> Model Class Initialized
INFO - 2017-07-20 04:05:11 --> Final output sent to browser
DEBUG - 2017-07-20 04:05:11 --> Total execution time: 0.0688
ERROR - 2017-07-20 04:06:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:06:43 --> Config Class Initialized
INFO - 2017-07-20 04:06:43 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:06:43 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:06:43 --> Utf8 Class Initialized
INFO - 2017-07-20 04:06:43 --> URI Class Initialized
INFO - 2017-07-20 04:06:43 --> Router Class Initialized
INFO - 2017-07-20 04:06:43 --> Output Class Initialized
INFO - 2017-07-20 04:06:43 --> Security Class Initialized
DEBUG - 2017-07-20 04:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:06:43 --> Input Class Initialized
INFO - 2017-07-20 04:06:43 --> Language Class Initialized
INFO - 2017-07-20 04:06:43 --> Loader Class Initialized
INFO - 2017-07-20 04:06:43 --> Controller Class Initialized
INFO - 2017-07-20 04:06:43 --> Database Driver Class Initialized
INFO - 2017-07-20 04:06:43 --> Model Class Initialized
INFO - 2017-07-20 04:06:43 --> Helper loaded: form_helper
INFO - 2017-07-20 04:06:43 --> Helper loaded: url_helper
INFO - 2017-07-20 04:06:43 --> Model Class Initialized
INFO - 2017-07-20 04:06:43 --> Final output sent to browser
DEBUG - 2017-07-20 04:06:43 --> Total execution time: 0.0900
ERROR - 2017-07-20 04:06:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:06:48 --> Config Class Initialized
INFO - 2017-07-20 04:06:48 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:06:48 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:06:48 --> Utf8 Class Initialized
INFO - 2017-07-20 04:06:48 --> URI Class Initialized
INFO - 2017-07-20 04:06:48 --> Router Class Initialized
INFO - 2017-07-20 04:06:48 --> Output Class Initialized
INFO - 2017-07-20 04:06:48 --> Security Class Initialized
DEBUG - 2017-07-20 04:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:06:48 --> Input Class Initialized
INFO - 2017-07-20 04:06:48 --> Language Class Initialized
INFO - 2017-07-20 04:06:48 --> Loader Class Initialized
INFO - 2017-07-20 04:06:48 --> Controller Class Initialized
INFO - 2017-07-20 04:06:48 --> Database Driver Class Initialized
INFO - 2017-07-20 04:06:48 --> Model Class Initialized
INFO - 2017-07-20 04:06:48 --> Helper loaded: form_helper
INFO - 2017-07-20 04:06:48 --> Helper loaded: url_helper
INFO - 2017-07-20 04:06:48 --> Model Class Initialized
INFO - 2017-07-20 04:06:48 --> Final output sent to browser
DEBUG - 2017-07-20 04:06:48 --> Total execution time: 0.0800
ERROR - 2017-07-20 04:06:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:06:58 --> Config Class Initialized
INFO - 2017-07-20 04:06:58 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:06:58 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:06:58 --> Utf8 Class Initialized
INFO - 2017-07-20 04:06:58 --> URI Class Initialized
INFO - 2017-07-20 04:06:58 --> Router Class Initialized
INFO - 2017-07-20 04:06:58 --> Output Class Initialized
INFO - 2017-07-20 04:06:58 --> Security Class Initialized
DEBUG - 2017-07-20 04:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:06:58 --> Input Class Initialized
INFO - 2017-07-20 04:06:58 --> Language Class Initialized
INFO - 2017-07-20 04:06:58 --> Loader Class Initialized
INFO - 2017-07-20 04:06:58 --> Controller Class Initialized
INFO - 2017-07-20 04:06:58 --> Database Driver Class Initialized
INFO - 2017-07-20 04:06:58 --> Model Class Initialized
INFO - 2017-07-20 04:06:58 --> Helper loaded: form_helper
INFO - 2017-07-20 04:06:58 --> Helper loaded: url_helper
INFO - 2017-07-20 04:06:58 --> Model Class Initialized
INFO - 2017-07-20 04:06:58 --> Final output sent to browser
DEBUG - 2017-07-20 04:06:58 --> Total execution time: 0.0425
ERROR - 2017-07-20 04:07:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:07:08 --> Config Class Initialized
INFO - 2017-07-20 04:07:08 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:07:08 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:07:08 --> Utf8 Class Initialized
INFO - 2017-07-20 04:07:08 --> URI Class Initialized
INFO - 2017-07-20 04:07:08 --> Router Class Initialized
INFO - 2017-07-20 04:07:08 --> Output Class Initialized
INFO - 2017-07-20 04:07:08 --> Security Class Initialized
DEBUG - 2017-07-20 04:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:07:08 --> Input Class Initialized
INFO - 2017-07-20 04:07:08 --> Language Class Initialized
INFO - 2017-07-20 04:07:08 --> Loader Class Initialized
INFO - 2017-07-20 04:07:08 --> Controller Class Initialized
INFO - 2017-07-20 04:07:08 --> Database Driver Class Initialized
INFO - 2017-07-20 04:07:08 --> Model Class Initialized
INFO - 2017-07-20 04:07:08 --> Helper loaded: form_helper
INFO - 2017-07-20 04:07:08 --> Helper loaded: url_helper
INFO - 2017-07-20 04:07:08 --> Model Class Initialized
INFO - 2017-07-20 04:07:08 --> Final output sent to browser
DEBUG - 2017-07-20 04:07:08 --> Total execution time: 0.1720
ERROR - 2017-07-20 04:07:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:07:09 --> Config Class Initialized
INFO - 2017-07-20 04:07:09 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:07:09 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:07:09 --> Utf8 Class Initialized
INFO - 2017-07-20 04:07:09 --> URI Class Initialized
INFO - 2017-07-20 04:07:09 --> Router Class Initialized
INFO - 2017-07-20 04:07:09 --> Output Class Initialized
INFO - 2017-07-20 04:07:09 --> Security Class Initialized
DEBUG - 2017-07-20 04:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:07:09 --> Input Class Initialized
INFO - 2017-07-20 04:07:09 --> Language Class Initialized
INFO - 2017-07-20 04:07:09 --> Loader Class Initialized
INFO - 2017-07-20 04:07:09 --> Controller Class Initialized
INFO - 2017-07-20 04:07:09 --> Database Driver Class Initialized
INFO - 2017-07-20 04:07:09 --> Model Class Initialized
INFO - 2017-07-20 04:07:09 --> Helper loaded: form_helper
INFO - 2017-07-20 04:07:09 --> Helper loaded: url_helper
INFO - 2017-07-20 04:07:09 --> Model Class Initialized
INFO - 2017-07-20 04:07:09 --> Final output sent to browser
DEBUG - 2017-07-20 04:07:09 --> Total execution time: 0.0425
ERROR - 2017-07-20 04:07:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:07:22 --> Config Class Initialized
INFO - 2017-07-20 04:07:22 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:07:22 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:07:22 --> Utf8 Class Initialized
INFO - 2017-07-20 04:07:22 --> URI Class Initialized
INFO - 2017-07-20 04:07:22 --> Router Class Initialized
INFO - 2017-07-20 04:07:22 --> Output Class Initialized
INFO - 2017-07-20 04:07:22 --> Security Class Initialized
DEBUG - 2017-07-20 04:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:07:22 --> Input Class Initialized
INFO - 2017-07-20 04:07:22 --> Language Class Initialized
INFO - 2017-07-20 04:07:22 --> Loader Class Initialized
INFO - 2017-07-20 04:07:22 --> Controller Class Initialized
INFO - 2017-07-20 04:07:22 --> Database Driver Class Initialized
INFO - 2017-07-20 04:07:22 --> Model Class Initialized
INFO - 2017-07-20 04:07:22 --> Helper loaded: form_helper
INFO - 2017-07-20 04:07:22 --> Helper loaded: url_helper
INFO - 2017-07-20 04:07:22 --> Model Class Initialized
INFO - 2017-07-20 04:07:22 --> Final output sent to browser
DEBUG - 2017-07-20 04:07:22 --> Total execution time: 0.0608
ERROR - 2017-07-20 04:08:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:08:40 --> Config Class Initialized
INFO - 2017-07-20 04:08:40 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:08:40 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:08:40 --> Utf8 Class Initialized
INFO - 2017-07-20 04:08:40 --> URI Class Initialized
INFO - 2017-07-20 04:08:40 --> Router Class Initialized
INFO - 2017-07-20 04:08:40 --> Output Class Initialized
INFO - 2017-07-20 04:08:40 --> Security Class Initialized
DEBUG - 2017-07-20 04:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:08:40 --> Input Class Initialized
INFO - 2017-07-20 04:08:40 --> Language Class Initialized
INFO - 2017-07-20 04:08:40 --> Loader Class Initialized
INFO - 2017-07-20 04:08:40 --> Controller Class Initialized
INFO - 2017-07-20 04:08:40 --> Database Driver Class Initialized
INFO - 2017-07-20 04:08:40 --> Model Class Initialized
INFO - 2017-07-20 04:08:40 --> Helper loaded: form_helper
INFO - 2017-07-20 04:08:40 --> Helper loaded: url_helper
INFO - 2017-07-20 04:08:40 --> Model Class Initialized
INFO - 2017-07-20 04:08:40 --> Final output sent to browser
DEBUG - 2017-07-20 04:08:40 --> Total execution time: 0.0835
ERROR - 2017-07-20 04:08:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:08:41 --> Config Class Initialized
INFO - 2017-07-20 04:08:41 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:08:41 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:08:41 --> Utf8 Class Initialized
INFO - 2017-07-20 04:08:41 --> URI Class Initialized
INFO - 2017-07-20 04:08:41 --> Router Class Initialized
INFO - 2017-07-20 04:08:41 --> Output Class Initialized
INFO - 2017-07-20 04:08:41 --> Security Class Initialized
DEBUG - 2017-07-20 04:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:08:41 --> Input Class Initialized
INFO - 2017-07-20 04:08:41 --> Language Class Initialized
INFO - 2017-07-20 04:08:41 --> Loader Class Initialized
INFO - 2017-07-20 04:08:41 --> Controller Class Initialized
INFO - 2017-07-20 04:08:41 --> Database Driver Class Initialized
INFO - 2017-07-20 04:08:41 --> Model Class Initialized
INFO - 2017-07-20 04:08:41 --> Helper loaded: form_helper
INFO - 2017-07-20 04:08:41 --> Helper loaded: url_helper
INFO - 2017-07-20 04:08:41 --> Model Class Initialized
INFO - 2017-07-20 04:08:41 --> Final output sent to browser
DEBUG - 2017-07-20 04:08:41 --> Total execution time: 0.0550
ERROR - 2017-07-20 04:08:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:08:56 --> Config Class Initialized
INFO - 2017-07-20 04:08:56 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:08:56 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:08:56 --> Utf8 Class Initialized
INFO - 2017-07-20 04:08:56 --> URI Class Initialized
INFO - 2017-07-20 04:08:56 --> Router Class Initialized
INFO - 2017-07-20 04:08:56 --> Output Class Initialized
INFO - 2017-07-20 04:08:56 --> Security Class Initialized
DEBUG - 2017-07-20 04:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:08:56 --> Input Class Initialized
INFO - 2017-07-20 04:08:56 --> Language Class Initialized
INFO - 2017-07-20 04:08:57 --> Loader Class Initialized
INFO - 2017-07-20 04:08:57 --> Controller Class Initialized
INFO - 2017-07-20 04:08:57 --> Database Driver Class Initialized
INFO - 2017-07-20 04:08:57 --> Model Class Initialized
INFO - 2017-07-20 04:08:57 --> Helper loaded: form_helper
INFO - 2017-07-20 04:08:57 --> Helper loaded: url_helper
INFO - 2017-07-20 04:08:57 --> Model Class Initialized
INFO - 2017-07-20 04:08:57 --> Final output sent to browser
DEBUG - 2017-07-20 04:08:57 --> Total execution time: 0.0593
ERROR - 2017-07-20 04:23:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:23:01 --> Config Class Initialized
INFO - 2017-07-20 04:23:01 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:23:01 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:23:01 --> Utf8 Class Initialized
INFO - 2017-07-20 04:23:01 --> URI Class Initialized
INFO - 2017-07-20 04:23:01 --> Router Class Initialized
INFO - 2017-07-20 04:23:01 --> Output Class Initialized
INFO - 2017-07-20 04:23:01 --> Security Class Initialized
DEBUG - 2017-07-20 04:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:23:01 --> Input Class Initialized
INFO - 2017-07-20 04:23:01 --> Language Class Initialized
INFO - 2017-07-20 04:23:01 --> Loader Class Initialized
INFO - 2017-07-20 04:23:01 --> Controller Class Initialized
INFO - 2017-07-20 04:23:01 --> Database Driver Class Initialized
INFO - 2017-07-20 04:23:01 --> Model Class Initialized
INFO - 2017-07-20 04:23:01 --> Helper loaded: form_helper
INFO - 2017-07-20 04:23:01 --> Helper loaded: url_helper
INFO - 2017-07-20 04:23:01 --> Model Class Initialized
INFO - 2017-07-20 04:23:01 --> Final output sent to browser
DEBUG - 2017-07-20 04:23:01 --> Total execution time: 0.0750
ERROR - 2017-07-20 04:23:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:23:02 --> Config Class Initialized
INFO - 2017-07-20 04:23:02 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:23:02 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:23:02 --> Utf8 Class Initialized
INFO - 2017-07-20 04:23:02 --> URI Class Initialized
INFO - 2017-07-20 04:23:02 --> Router Class Initialized
INFO - 2017-07-20 04:23:02 --> Output Class Initialized
INFO - 2017-07-20 04:23:02 --> Security Class Initialized
DEBUG - 2017-07-20 04:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:23:02 --> Input Class Initialized
INFO - 2017-07-20 04:23:02 --> Language Class Initialized
INFO - 2017-07-20 04:23:02 --> Loader Class Initialized
INFO - 2017-07-20 04:23:02 --> Controller Class Initialized
INFO - 2017-07-20 04:23:02 --> Database Driver Class Initialized
INFO - 2017-07-20 04:23:02 --> Model Class Initialized
INFO - 2017-07-20 04:23:02 --> Helper loaded: form_helper
INFO - 2017-07-20 04:23:02 --> Helper loaded: url_helper
INFO - 2017-07-20 04:23:02 --> Model Class Initialized
INFO - 2017-07-20 04:23:02 --> Final output sent to browser
DEBUG - 2017-07-20 04:23:02 --> Total execution time: 0.0695
ERROR - 2017-07-20 04:23:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:23:09 --> Config Class Initialized
INFO - 2017-07-20 04:23:09 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:23:09 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:23:09 --> Utf8 Class Initialized
INFO - 2017-07-20 04:23:09 --> URI Class Initialized
INFO - 2017-07-20 04:23:09 --> Router Class Initialized
INFO - 2017-07-20 04:23:09 --> Output Class Initialized
INFO - 2017-07-20 04:23:09 --> Security Class Initialized
DEBUG - 2017-07-20 04:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:23:09 --> Input Class Initialized
INFO - 2017-07-20 04:23:09 --> Language Class Initialized
INFO - 2017-07-20 04:23:09 --> Loader Class Initialized
INFO - 2017-07-20 04:23:09 --> Controller Class Initialized
INFO - 2017-07-20 04:23:09 --> Database Driver Class Initialized
INFO - 2017-07-20 04:23:09 --> Model Class Initialized
INFO - 2017-07-20 04:23:09 --> Helper loaded: form_helper
INFO - 2017-07-20 04:23:09 --> Helper loaded: url_helper
INFO - 2017-07-20 04:23:09 --> Model Class Initialized
INFO - 2017-07-20 04:23:09 --> Final output sent to browser
DEBUG - 2017-07-20 04:23:09 --> Total execution time: 0.0558
ERROR - 2017-07-20 04:57:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:57:38 --> Config Class Initialized
INFO - 2017-07-20 04:57:38 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:57:38 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:57:38 --> Utf8 Class Initialized
INFO - 2017-07-20 04:57:38 --> URI Class Initialized
DEBUG - 2017-07-20 04:57:38 --> No URI present. Default controller set.
INFO - 2017-07-20 04:57:38 --> Router Class Initialized
INFO - 2017-07-20 04:57:38 --> Output Class Initialized
INFO - 2017-07-20 04:57:38 --> Security Class Initialized
DEBUG - 2017-07-20 04:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:57:38 --> Input Class Initialized
INFO - 2017-07-20 04:57:38 --> Language Class Initialized
INFO - 2017-07-20 04:57:38 --> Loader Class Initialized
INFO - 2017-07-20 04:57:38 --> Controller Class Initialized
INFO - 2017-07-20 04:57:38 --> Database Driver Class Initialized
INFO - 2017-07-20 04:57:38 --> Model Class Initialized
INFO - 2017-07-20 04:57:38 --> Helper loaded: form_helper
INFO - 2017-07-20 04:57:38 --> Helper loaded: url_helper
INFO - 2017-07-20 04:57:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-20 04:57:38 --> Final output sent to browser
DEBUG - 2017-07-20 04:57:38 --> Total execution time: 0.2140
ERROR - 2017-07-20 04:58:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:58:05 --> Config Class Initialized
INFO - 2017-07-20 04:58:05 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:58:05 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:58:05 --> Utf8 Class Initialized
INFO - 2017-07-20 04:58:05 --> URI Class Initialized
INFO - 2017-07-20 04:58:05 --> Router Class Initialized
INFO - 2017-07-20 04:58:05 --> Output Class Initialized
INFO - 2017-07-20 04:58:05 --> Security Class Initialized
DEBUG - 2017-07-20 04:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:58:05 --> Input Class Initialized
INFO - 2017-07-20 04:58:05 --> Language Class Initialized
INFO - 2017-07-20 04:58:05 --> Loader Class Initialized
INFO - 2017-07-20 04:58:05 --> Controller Class Initialized
INFO - 2017-07-20 04:58:05 --> Database Driver Class Initialized
INFO - 2017-07-20 04:58:05 --> Model Class Initialized
INFO - 2017-07-20 04:58:05 --> Helper loaded: form_helper
INFO - 2017-07-20 04:58:05 --> Helper loaded: url_helper
INFO - 2017-07-20 04:58:05 --> Model Class Initialized
INFO - 2017-07-20 04:58:05 --> Final output sent to browser
DEBUG - 2017-07-20 04:58:05 --> Total execution time: 0.0670
ERROR - 2017-07-20 04:58:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 04:58:07 --> Config Class Initialized
INFO - 2017-07-20 04:58:07 --> Hooks Class Initialized
DEBUG - 2017-07-20 04:58:07 --> UTF-8 Support Enabled
INFO - 2017-07-20 04:58:07 --> Utf8 Class Initialized
INFO - 2017-07-20 04:58:07 --> URI Class Initialized
INFO - 2017-07-20 04:58:07 --> Router Class Initialized
INFO - 2017-07-20 04:58:07 --> Output Class Initialized
INFO - 2017-07-20 04:58:07 --> Security Class Initialized
DEBUG - 2017-07-20 04:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 04:58:07 --> Input Class Initialized
INFO - 2017-07-20 04:58:07 --> Language Class Initialized
INFO - 2017-07-20 04:58:07 --> Loader Class Initialized
INFO - 2017-07-20 04:58:07 --> Controller Class Initialized
INFO - 2017-07-20 04:58:07 --> Database Driver Class Initialized
INFO - 2017-07-20 04:58:07 --> Model Class Initialized
INFO - 2017-07-20 04:58:07 --> Helper loaded: form_helper
INFO - 2017-07-20 04:58:07 --> Helper loaded: url_helper
INFO - 2017-07-20 04:58:07 --> Model Class Initialized
INFO - 2017-07-20 04:58:07 --> Final output sent to browser
DEBUG - 2017-07-20 04:58:07 --> Total execution time: 0.0480
ERROR - 2017-07-20 07:45:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 07:45:11 --> Config Class Initialized
INFO - 2017-07-20 07:45:11 --> Hooks Class Initialized
DEBUG - 2017-07-20 07:45:11 --> UTF-8 Support Enabled
INFO - 2017-07-20 07:45:11 --> Utf8 Class Initialized
INFO - 2017-07-20 07:45:11 --> URI Class Initialized
INFO - 2017-07-20 07:45:11 --> Router Class Initialized
INFO - 2017-07-20 07:45:11 --> Output Class Initialized
INFO - 2017-07-20 07:45:11 --> Security Class Initialized
DEBUG - 2017-07-20 07:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 07:45:11 --> Input Class Initialized
INFO - 2017-07-20 07:45:11 --> Language Class Initialized
INFO - 2017-07-20 07:45:11 --> Loader Class Initialized
INFO - 2017-07-20 07:45:11 --> Controller Class Initialized
INFO - 2017-07-20 07:45:11 --> Database Driver Class Initialized
INFO - 2017-07-20 07:45:11 --> Model Class Initialized
INFO - 2017-07-20 07:45:11 --> Helper loaded: form_helper
INFO - 2017-07-20 07:45:11 --> Helper loaded: url_helper
INFO - 2017-07-20 07:45:11 --> Model Class Initialized
ERROR - 2017-07-20 07:45:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 07:45:11 --> Config Class Initialized
INFO - 2017-07-20 07:45:11 --> Hooks Class Initialized
DEBUG - 2017-07-20 07:45:11 --> UTF-8 Support Enabled
INFO - 2017-07-20 07:45:11 --> Utf8 Class Initialized
INFO - 2017-07-20 07:45:11 --> URI Class Initialized
INFO - 2017-07-20 07:45:11 --> Router Class Initialized
INFO - 2017-07-20 07:45:11 --> Output Class Initialized
INFO - 2017-07-20 07:45:11 --> Security Class Initialized
DEBUG - 2017-07-20 07:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 07:45:11 --> Input Class Initialized
INFO - 2017-07-20 07:45:11 --> Language Class Initialized
INFO - 2017-07-20 07:45:11 --> Loader Class Initialized
INFO - 2017-07-20 07:45:11 --> Controller Class Initialized
INFO - 2017-07-20 07:45:11 --> Database Driver Class Initialized
INFO - 2017-07-20 07:45:11 --> Model Class Initialized
INFO - 2017-07-20 07:45:11 --> Helper loaded: form_helper
INFO - 2017-07-20 07:45:11 --> Helper loaded: url_helper
INFO - 2017-07-20 07:45:11 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-20 07:45:11 --> Model Class Initialized
INFO - 2017-07-20 07:45:11 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-20 07:45:11 --> Final output sent to browser
DEBUG - 2017-07-20 07:45:11 --> Total execution time: 0.3310
ERROR - 2017-07-20 07:45:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 07:45:13 --> Config Class Initialized
INFO - 2017-07-20 07:45:13 --> Hooks Class Initialized
DEBUG - 2017-07-20 07:45:13 --> UTF-8 Support Enabled
INFO - 2017-07-20 07:45:13 --> Utf8 Class Initialized
INFO - 2017-07-20 07:45:13 --> URI Class Initialized
INFO - 2017-07-20 07:45:13 --> Router Class Initialized
INFO - 2017-07-20 07:45:13 --> Output Class Initialized
INFO - 2017-07-20 07:45:13 --> Security Class Initialized
DEBUG - 2017-07-20 07:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 07:45:13 --> Input Class Initialized
INFO - 2017-07-20 07:45:13 --> Language Class Initialized
INFO - 2017-07-20 07:45:13 --> Loader Class Initialized
INFO - 2017-07-20 07:45:13 --> Controller Class Initialized
INFO - 2017-07-20 07:45:13 --> Database Driver Class Initialized
INFO - 2017-07-20 07:45:13 --> Model Class Initialized
INFO - 2017-07-20 07:45:13 --> Helper loaded: form_helper
INFO - 2017-07-20 07:45:13 --> Helper loaded: url_helper
INFO - 2017-07-20 07:45:13 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-20 07:45:13 --> Model Class Initialized
INFO - 2017-07-20 07:45:14 --> File loaded: C:\xampp\htdocs\mystage\application\views\users.php
INFO - 2017-07-20 07:45:14 --> Final output sent to browser
DEBUG - 2017-07-20 07:45:14 --> Total execution time: 0.0650
ERROR - 2017-07-20 07:45:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 07:45:15 --> Config Class Initialized
INFO - 2017-07-20 07:45:15 --> Hooks Class Initialized
DEBUG - 2017-07-20 07:45:15 --> UTF-8 Support Enabled
INFO - 2017-07-20 07:45:15 --> Utf8 Class Initialized
INFO - 2017-07-20 07:45:15 --> URI Class Initialized
INFO - 2017-07-20 07:45:15 --> Router Class Initialized
INFO - 2017-07-20 07:45:15 --> Output Class Initialized
INFO - 2017-07-20 07:45:15 --> Security Class Initialized
DEBUG - 2017-07-20 07:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 07:45:15 --> Input Class Initialized
INFO - 2017-07-20 07:45:15 --> Language Class Initialized
INFO - 2017-07-20 07:45:15 --> Loader Class Initialized
INFO - 2017-07-20 07:45:15 --> Controller Class Initialized
INFO - 2017-07-20 07:45:15 --> Database Driver Class Initialized
INFO - 2017-07-20 07:45:15 --> Model Class Initialized
INFO - 2017-07-20 07:45:15 --> Helper loaded: form_helper
INFO - 2017-07-20 07:45:15 --> Helper loaded: url_helper
INFO - 2017-07-20 07:45:15 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-20 07:45:15 --> Model Class Initialized
INFO - 2017-07-20 07:45:15 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-20 07:45:15 --> Final output sent to browser
DEBUG - 2017-07-20 07:45:15 --> Total execution time: 0.0510
ERROR - 2017-07-20 07:45:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 07:45:18 --> Config Class Initialized
INFO - 2017-07-20 07:45:18 --> Hooks Class Initialized
DEBUG - 2017-07-20 07:45:18 --> UTF-8 Support Enabled
INFO - 2017-07-20 07:45:18 --> Utf8 Class Initialized
INFO - 2017-07-20 07:45:18 --> URI Class Initialized
INFO - 2017-07-20 07:45:18 --> Router Class Initialized
INFO - 2017-07-20 07:45:18 --> Output Class Initialized
INFO - 2017-07-20 07:45:18 --> Security Class Initialized
DEBUG - 2017-07-20 07:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 07:45:18 --> Input Class Initialized
INFO - 2017-07-20 07:45:18 --> Language Class Initialized
INFO - 2017-07-20 07:45:18 --> Loader Class Initialized
INFO - 2017-07-20 07:45:18 --> Controller Class Initialized
INFO - 2017-07-20 07:45:18 --> Database Driver Class Initialized
INFO - 2017-07-20 07:45:18 --> Model Class Initialized
INFO - 2017-07-20 07:45:18 --> Helper loaded: form_helper
INFO - 2017-07-20 07:45:18 --> Helper loaded: url_helper
INFO - 2017-07-20 07:45:18 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-20 07:45:18 --> Model Class Initialized
INFO - 2017-07-20 07:45:18 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-20 07:45:18 --> Final output sent to browser
DEBUG - 2017-07-20 07:45:18 --> Total execution time: 0.1130
ERROR - 2017-07-20 07:45:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-20 07:45:25 --> Config Class Initialized
INFO - 2017-07-20 07:45:25 --> Hooks Class Initialized
DEBUG - 2017-07-20 07:45:25 --> UTF-8 Support Enabled
INFO - 2017-07-20 07:45:25 --> Utf8 Class Initialized
INFO - 2017-07-20 07:45:25 --> URI Class Initialized
INFO - 2017-07-20 07:45:25 --> Router Class Initialized
INFO - 2017-07-20 07:45:25 --> Output Class Initialized
INFO - 2017-07-20 07:45:25 --> Security Class Initialized
DEBUG - 2017-07-20 07:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-20 07:45:25 --> Input Class Initialized
INFO - 2017-07-20 07:45:25 --> Language Class Initialized
INFO - 2017-07-20 07:45:25 --> Loader Class Initialized
INFO - 2017-07-20 07:45:25 --> Controller Class Initialized
INFO - 2017-07-20 07:45:25 --> Database Driver Class Initialized
INFO - 2017-07-20 07:45:26 --> Model Class Initialized
INFO - 2017-07-20 07:45:26 --> Helper loaded: form_helper
INFO - 2017-07-20 07:45:26 --> Helper loaded: url_helper
INFO - 2017-07-20 07:45:26 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-20 07:45:26 --> Model Class Initialized
INFO - 2017-07-20 07:45:26 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-07-20 07:45:26 --> Final output sent to browser
DEBUG - 2017-07-20 07:45:26 --> Total execution time: 0.1280
