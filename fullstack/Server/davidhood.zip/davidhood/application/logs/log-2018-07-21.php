<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-21 19:28:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:28:01 --> Config Class Initialized
INFO - 2018-07-21 19:28:01 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:28:01 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:28:01 --> Utf8 Class Initialized
INFO - 2018-07-21 19:28:01 --> URI Class Initialized
DEBUG - 2018-07-21 19:28:01 --> No URI present. Default controller set.
INFO - 2018-07-21 19:28:01 --> Router Class Initialized
INFO - 2018-07-21 19:28:01 --> Output Class Initialized
INFO - 2018-07-21 19:28:01 --> Security Class Initialized
DEBUG - 2018-07-21 19:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:28:01 --> Input Class Initialized
INFO - 2018-07-21 19:28:01 --> Language Class Initialized
INFO - 2018-07-21 19:28:01 --> Loader Class Initialized
INFO - 2018-07-21 19:28:01 --> Controller Class Initialized
INFO - 2018-07-21 19:28:01 --> Database Driver Class Initialized
INFO - 2018-07-21 19:28:01 --> Model Class Initialized
INFO - 2018-07-21 19:28:01 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:28:01 --> Model Class Initialized
INFO - 2018-07-21 19:28:01 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-21 19:28:01 --> Final output sent to browser
DEBUG - 2018-07-21 19:28:01 --> Total execution time: 0.0395
ERROR - 2018-07-21 19:28:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:28:01 --> Config Class Initialized
INFO - 2018-07-21 19:28:01 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:28:01 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:28:01 --> Utf8 Class Initialized
INFO - 2018-07-21 19:28:01 --> URI Class Initialized
DEBUG - 2018-07-21 19:28:01 --> No URI present. Default controller set.
INFO - 2018-07-21 19:28:01 --> Router Class Initialized
INFO - 2018-07-21 19:28:01 --> Output Class Initialized
INFO - 2018-07-21 19:28:01 --> Security Class Initialized
DEBUG - 2018-07-21 19:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:28:01 --> Input Class Initialized
INFO - 2018-07-21 19:28:01 --> Language Class Initialized
INFO - 2018-07-21 19:28:01 --> Loader Class Initialized
INFO - 2018-07-21 19:28:01 --> Controller Class Initialized
INFO - 2018-07-21 19:28:01 --> Database Driver Class Initialized
INFO - 2018-07-21 19:28:01 --> Model Class Initialized
INFO - 2018-07-21 19:28:01 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:28:01 --> Model Class Initialized
INFO - 2018-07-21 19:28:01 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-21 19:28:01 --> Final output sent to browser
DEBUG - 2018-07-21 19:28:01 --> Total execution time: 0.0516
ERROR - 2018-07-21 19:28:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:28:03 --> Config Class Initialized
INFO - 2018-07-21 19:28:03 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:28:03 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:28:03 --> Utf8 Class Initialized
INFO - 2018-07-21 19:28:03 --> URI Class Initialized
INFO - 2018-07-21 19:28:03 --> Router Class Initialized
INFO - 2018-07-21 19:28:03 --> Output Class Initialized
INFO - 2018-07-21 19:28:03 --> Security Class Initialized
DEBUG - 2018-07-21 19:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:28:03 --> Input Class Initialized
INFO - 2018-07-21 19:28:03 --> Language Class Initialized
INFO - 2018-07-21 19:28:03 --> Loader Class Initialized
INFO - 2018-07-21 19:28:03 --> Controller Class Initialized
INFO - 2018-07-21 19:28:03 --> Database Driver Class Initialized
INFO - 2018-07-21 19:28:03 --> Model Class Initialized
INFO - 2018-07-21 19:28:03 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:28:03 --> Model Class Initialized
ERROR - 2018-07-21 19:28:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:28:03 --> Config Class Initialized
INFO - 2018-07-21 19:28:03 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:28:03 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:28:03 --> Utf8 Class Initialized
INFO - 2018-07-21 19:28:03 --> URI Class Initialized
INFO - 2018-07-21 19:28:03 --> Router Class Initialized
INFO - 2018-07-21 19:28:03 --> Output Class Initialized
INFO - 2018-07-21 19:28:03 --> Security Class Initialized
DEBUG - 2018-07-21 19:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:28:03 --> Input Class Initialized
INFO - 2018-07-21 19:28:03 --> Language Class Initialized
INFO - 2018-07-21 19:28:03 --> Loader Class Initialized
INFO - 2018-07-21 19:28:03 --> Controller Class Initialized
INFO - 2018-07-21 19:28:03 --> Database Driver Class Initialized
INFO - 2018-07-21 19:28:03 --> Model Class Initialized
INFO - 2018-07-21 19:28:03 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:28:03 --> Model Class Initialized
INFO - 2018-07-21 19:28:03 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:28:03 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 19:28:03 --> Final output sent to browser
DEBUG - 2018-07-21 19:28:03 --> Total execution time: 0.0477
ERROR - 2018-07-21 19:28:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:28:08 --> Config Class Initialized
INFO - 2018-07-21 19:28:08 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:28:08 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:28:08 --> Utf8 Class Initialized
INFO - 2018-07-21 19:28:08 --> URI Class Initialized
INFO - 2018-07-21 19:28:08 --> Router Class Initialized
INFO - 2018-07-21 19:28:08 --> Output Class Initialized
INFO - 2018-07-21 19:28:08 --> Security Class Initialized
DEBUG - 2018-07-21 19:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:28:08 --> Input Class Initialized
INFO - 2018-07-21 19:28:08 --> Language Class Initialized
INFO - 2018-07-21 19:28:08 --> Loader Class Initialized
INFO - 2018-07-21 19:28:08 --> Controller Class Initialized
INFO - 2018-07-21 19:28:08 --> Database Driver Class Initialized
INFO - 2018-07-21 19:28:08 --> Model Class Initialized
INFO - 2018-07-21 19:28:08 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:28:08 --> Model Class Initialized
INFO - 2018-07-21 19:28:08 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:28:08 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 19:28:08 --> Final output sent to browser
DEBUG - 2018-07-21 19:28:08 --> Total execution time: 0.0464
ERROR - 2018-07-21 19:29:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:29:44 --> Config Class Initialized
INFO - 2018-07-21 19:29:44 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:29:44 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:29:44 --> Utf8 Class Initialized
INFO - 2018-07-21 19:29:44 --> URI Class Initialized
INFO - 2018-07-21 19:29:44 --> Router Class Initialized
INFO - 2018-07-21 19:29:44 --> Output Class Initialized
INFO - 2018-07-21 19:29:44 --> Security Class Initialized
DEBUG - 2018-07-21 19:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:29:44 --> Input Class Initialized
INFO - 2018-07-21 19:29:44 --> Language Class Initialized
INFO - 2018-07-21 19:29:44 --> Loader Class Initialized
INFO - 2018-07-21 19:29:44 --> Controller Class Initialized
INFO - 2018-07-21 19:29:44 --> Database Driver Class Initialized
INFO - 2018-07-21 19:29:44 --> Model Class Initialized
INFO - 2018-07-21 19:29:44 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:29:44 --> Model Class Initialized
INFO - 2018-07-21 19:29:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:29:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 19:29:44 --> Final output sent to browser
DEBUG - 2018-07-21 19:29:44 --> Total execution time: 0.0416
ERROR - 2018-07-21 19:29:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:29:55 --> Config Class Initialized
INFO - 2018-07-21 19:29:55 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:29:55 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:29:55 --> Utf8 Class Initialized
INFO - 2018-07-21 19:29:55 --> URI Class Initialized
INFO - 2018-07-21 19:29:55 --> Router Class Initialized
INFO - 2018-07-21 19:29:55 --> Output Class Initialized
INFO - 2018-07-21 19:29:55 --> Security Class Initialized
DEBUG - 2018-07-21 19:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:29:55 --> Input Class Initialized
INFO - 2018-07-21 19:29:55 --> Language Class Initialized
INFO - 2018-07-21 19:29:55 --> Loader Class Initialized
INFO - 2018-07-21 19:29:55 --> Controller Class Initialized
INFO - 2018-07-21 19:29:55 --> Database Driver Class Initialized
INFO - 2018-07-21 19:29:55 --> Model Class Initialized
INFO - 2018-07-21 19:29:55 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:29:55 --> Model Class Initialized
INFO - 2018-07-21 19:29:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:29:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 19:29:55 --> Final output sent to browser
DEBUG - 2018-07-21 19:29:55 --> Total execution time: 0.0560
ERROR - 2018-07-21 19:31:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:31:25 --> Config Class Initialized
INFO - 2018-07-21 19:31:25 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:31:25 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:31:25 --> Utf8 Class Initialized
INFO - 2018-07-21 19:31:25 --> URI Class Initialized
INFO - 2018-07-21 19:31:25 --> Router Class Initialized
INFO - 2018-07-21 19:31:25 --> Output Class Initialized
INFO - 2018-07-21 19:31:25 --> Security Class Initialized
DEBUG - 2018-07-21 19:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:31:25 --> Input Class Initialized
INFO - 2018-07-21 19:31:25 --> Language Class Initialized
INFO - 2018-07-21 19:31:25 --> Loader Class Initialized
INFO - 2018-07-21 19:31:25 --> Controller Class Initialized
INFO - 2018-07-21 19:31:25 --> Database Driver Class Initialized
INFO - 2018-07-21 19:31:25 --> Model Class Initialized
INFO - 2018-07-21 19:31:25 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:31:25 --> Model Class Initialized
INFO - 2018-07-21 19:31:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:31:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 19:31:25 --> Final output sent to browser
DEBUG - 2018-07-21 19:31:25 --> Total execution time: 0.0524
ERROR - 2018-07-21 19:32:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:32:51 --> Config Class Initialized
INFO - 2018-07-21 19:32:51 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:32:51 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:32:51 --> Utf8 Class Initialized
INFO - 2018-07-21 19:32:51 --> URI Class Initialized
INFO - 2018-07-21 19:32:51 --> Router Class Initialized
INFO - 2018-07-21 19:32:51 --> Output Class Initialized
INFO - 2018-07-21 19:32:51 --> Security Class Initialized
DEBUG - 2018-07-21 19:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:32:51 --> Input Class Initialized
INFO - 2018-07-21 19:32:51 --> Language Class Initialized
INFO - 2018-07-21 19:32:51 --> Loader Class Initialized
INFO - 2018-07-21 19:32:51 --> Controller Class Initialized
INFO - 2018-07-21 19:32:51 --> Database Driver Class Initialized
INFO - 2018-07-21 19:32:51 --> Model Class Initialized
INFO - 2018-07-21 19:32:51 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:32:51 --> Model Class Initialized
INFO - 2018-07-21 19:32:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:32:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 19:32:51 --> Final output sent to browser
DEBUG - 2018-07-21 19:32:51 --> Total execution time: 0.0667
ERROR - 2018-07-21 19:33:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:33:58 --> Config Class Initialized
INFO - 2018-07-21 19:33:58 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:33:58 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:33:58 --> Utf8 Class Initialized
INFO - 2018-07-21 19:33:58 --> URI Class Initialized
INFO - 2018-07-21 19:33:58 --> Router Class Initialized
INFO - 2018-07-21 19:33:58 --> Output Class Initialized
INFO - 2018-07-21 19:33:58 --> Security Class Initialized
DEBUG - 2018-07-21 19:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:33:58 --> Input Class Initialized
INFO - 2018-07-21 19:33:58 --> Language Class Initialized
INFO - 2018-07-21 19:33:58 --> Loader Class Initialized
INFO - 2018-07-21 19:33:58 --> Controller Class Initialized
INFO - 2018-07-21 19:33:58 --> Database Driver Class Initialized
INFO - 2018-07-21 19:33:58 --> Model Class Initialized
INFO - 2018-07-21 19:33:58 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:33:58 --> Model Class Initialized
INFO - 2018-07-21 19:33:58 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:33:58 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 19:33:58 --> Final output sent to browser
DEBUG - 2018-07-21 19:33:58 --> Total execution time: 0.0469
ERROR - 2018-07-21 19:35:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:35:47 --> Config Class Initialized
INFO - 2018-07-21 19:35:47 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:35:47 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:35:47 --> Utf8 Class Initialized
INFO - 2018-07-21 19:35:47 --> URI Class Initialized
INFO - 2018-07-21 19:35:47 --> Router Class Initialized
INFO - 2018-07-21 19:35:47 --> Output Class Initialized
INFO - 2018-07-21 19:35:47 --> Security Class Initialized
DEBUG - 2018-07-21 19:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:35:47 --> Input Class Initialized
INFO - 2018-07-21 19:35:47 --> Language Class Initialized
INFO - 2018-07-21 19:35:47 --> Loader Class Initialized
INFO - 2018-07-21 19:35:47 --> Controller Class Initialized
INFO - 2018-07-21 19:35:47 --> Database Driver Class Initialized
INFO - 2018-07-21 19:35:47 --> Model Class Initialized
INFO - 2018-07-21 19:35:47 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:35:47 --> Model Class Initialized
INFO - 2018-07-21 19:35:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:35:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 19:35:47 --> Final output sent to browser
DEBUG - 2018-07-21 19:35:47 --> Total execution time: 0.0429
ERROR - 2018-07-21 19:37:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:37:25 --> Config Class Initialized
INFO - 2018-07-21 19:37:25 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:37:25 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:37:25 --> Utf8 Class Initialized
INFO - 2018-07-21 19:37:25 --> URI Class Initialized
INFO - 2018-07-21 19:37:25 --> Router Class Initialized
INFO - 2018-07-21 19:37:25 --> Output Class Initialized
INFO - 2018-07-21 19:37:25 --> Security Class Initialized
DEBUG - 2018-07-21 19:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:37:25 --> Input Class Initialized
INFO - 2018-07-21 19:37:25 --> Language Class Initialized
INFO - 2018-07-21 19:37:25 --> Loader Class Initialized
INFO - 2018-07-21 19:37:25 --> Controller Class Initialized
INFO - 2018-07-21 19:37:25 --> Database Driver Class Initialized
INFO - 2018-07-21 19:37:25 --> Model Class Initialized
INFO - 2018-07-21 19:37:25 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:37:25 --> Model Class Initialized
INFO - 2018-07-21 19:37:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:37:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 19:37:25 --> Final output sent to browser
DEBUG - 2018-07-21 19:37:25 --> Total execution time: 0.0652
ERROR - 2018-07-21 19:38:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:38:24 --> Config Class Initialized
INFO - 2018-07-21 19:38:24 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:38:24 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:38:24 --> Utf8 Class Initialized
INFO - 2018-07-21 19:38:24 --> URI Class Initialized
INFO - 2018-07-21 19:38:24 --> Router Class Initialized
INFO - 2018-07-21 19:38:24 --> Output Class Initialized
INFO - 2018-07-21 19:38:24 --> Security Class Initialized
DEBUG - 2018-07-21 19:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:38:24 --> Input Class Initialized
INFO - 2018-07-21 19:38:24 --> Language Class Initialized
INFO - 2018-07-21 19:38:24 --> Loader Class Initialized
INFO - 2018-07-21 19:38:24 --> Controller Class Initialized
INFO - 2018-07-21 19:38:24 --> Database Driver Class Initialized
INFO - 2018-07-21 19:38:24 --> Model Class Initialized
INFO - 2018-07-21 19:38:24 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:38:24 --> Model Class Initialized
INFO - 2018-07-21 19:38:24 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-21 19:38:24 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE), expecting '(' C:\xampp\htdocs\davidhood\application\views\add_advertisement.php 101
ERROR - 2018-07-21 19:38:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:38:43 --> Config Class Initialized
INFO - 2018-07-21 19:38:43 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:38:43 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:38:43 --> Utf8 Class Initialized
INFO - 2018-07-21 19:38:43 --> URI Class Initialized
INFO - 2018-07-21 19:38:43 --> Router Class Initialized
INFO - 2018-07-21 19:38:43 --> Output Class Initialized
INFO - 2018-07-21 19:38:43 --> Security Class Initialized
DEBUG - 2018-07-21 19:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:38:43 --> Input Class Initialized
INFO - 2018-07-21 19:38:43 --> Language Class Initialized
INFO - 2018-07-21 19:38:43 --> Loader Class Initialized
INFO - 2018-07-21 19:38:43 --> Controller Class Initialized
INFO - 2018-07-21 19:38:43 --> Database Driver Class Initialized
INFO - 2018-07-21 19:38:43 --> Model Class Initialized
INFO - 2018-07-21 19:38:43 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:38:43 --> Model Class Initialized
INFO - 2018-07-21 19:38:43 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:38:43 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 19:38:43 --> Final output sent to browser
DEBUG - 2018-07-21 19:38:43 --> Total execution time: 0.0461
ERROR - 2018-07-21 19:42:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:42:20 --> Config Class Initialized
INFO - 2018-07-21 19:42:20 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:42:20 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:42:20 --> Utf8 Class Initialized
INFO - 2018-07-21 19:42:20 --> URI Class Initialized
INFO - 2018-07-21 19:42:20 --> Router Class Initialized
INFO - 2018-07-21 19:42:20 --> Output Class Initialized
INFO - 2018-07-21 19:42:20 --> Security Class Initialized
DEBUG - 2018-07-21 19:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:42:20 --> Input Class Initialized
INFO - 2018-07-21 19:42:20 --> Language Class Initialized
INFO - 2018-07-21 19:42:20 --> Loader Class Initialized
INFO - 2018-07-21 19:42:20 --> Controller Class Initialized
INFO - 2018-07-21 19:42:20 --> Database Driver Class Initialized
INFO - 2018-07-21 19:42:20 --> Model Class Initialized
INFO - 2018-07-21 19:42:20 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:42:20 --> Model Class Initialized
INFO - 2018-07-21 19:42:20 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:42:20 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 19:42:20 --> Final output sent to browser
DEBUG - 2018-07-21 19:42:20 --> Total execution time: 0.0395
ERROR - 2018-07-21 19:43:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:43:45 --> Config Class Initialized
INFO - 2018-07-21 19:43:45 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:43:45 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:43:45 --> Utf8 Class Initialized
INFO - 2018-07-21 19:43:45 --> URI Class Initialized
INFO - 2018-07-21 19:43:45 --> Router Class Initialized
INFO - 2018-07-21 19:43:45 --> Output Class Initialized
INFO - 2018-07-21 19:43:45 --> Security Class Initialized
DEBUG - 2018-07-21 19:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:43:45 --> Input Class Initialized
INFO - 2018-07-21 19:43:45 --> Language Class Initialized
INFO - 2018-07-21 19:43:45 --> Loader Class Initialized
INFO - 2018-07-21 19:43:45 --> Controller Class Initialized
INFO - 2018-07-21 19:43:45 --> Database Driver Class Initialized
INFO - 2018-07-21 19:43:45 --> Model Class Initialized
INFO - 2018-07-21 19:43:45 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:43:45 --> Model Class Initialized
INFO - 2018-07-21 19:43:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:43:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 19:43:45 --> Final output sent to browser
DEBUG - 2018-07-21 19:43:45 --> Total execution time: 0.0541
ERROR - 2018-07-21 19:43:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:43:56 --> Config Class Initialized
INFO - 2018-07-21 19:43:56 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:43:56 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:43:56 --> Utf8 Class Initialized
INFO - 2018-07-21 19:43:56 --> URI Class Initialized
INFO - 2018-07-21 19:43:56 --> Router Class Initialized
INFO - 2018-07-21 19:43:56 --> Output Class Initialized
INFO - 2018-07-21 19:43:56 --> Security Class Initialized
DEBUG - 2018-07-21 19:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:43:56 --> Input Class Initialized
INFO - 2018-07-21 19:43:56 --> Language Class Initialized
INFO - 2018-07-21 19:43:56 --> Loader Class Initialized
INFO - 2018-07-21 19:43:56 --> Controller Class Initialized
INFO - 2018-07-21 19:43:56 --> Database Driver Class Initialized
INFO - 2018-07-21 19:43:56 --> Model Class Initialized
INFO - 2018-07-21 19:43:56 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:43:56 --> Model Class Initialized
INFO - 2018-07-21 19:43:56 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:43:56 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 19:43:56 --> Final output sent to browser
DEBUG - 2018-07-21 19:43:56 --> Total execution time: 0.0521
ERROR - 2018-07-21 19:44:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:44:05 --> Config Class Initialized
INFO - 2018-07-21 19:44:05 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:44:05 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:44:05 --> Utf8 Class Initialized
INFO - 2018-07-21 19:44:05 --> URI Class Initialized
INFO - 2018-07-21 19:44:05 --> Router Class Initialized
INFO - 2018-07-21 19:44:05 --> Output Class Initialized
INFO - 2018-07-21 19:44:05 --> Security Class Initialized
DEBUG - 2018-07-21 19:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:44:05 --> Input Class Initialized
INFO - 2018-07-21 19:44:05 --> Language Class Initialized
INFO - 2018-07-21 19:44:05 --> Loader Class Initialized
INFO - 2018-07-21 19:44:05 --> Controller Class Initialized
INFO - 2018-07-21 19:44:05 --> Database Driver Class Initialized
INFO - 2018-07-21 19:44:05 --> Model Class Initialized
INFO - 2018-07-21 19:44:05 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:44:05 --> Model Class Initialized
INFO - 2018-07-21 19:44:05 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:44:05 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 19:44:05 --> Final output sent to browser
DEBUG - 2018-07-21 19:44:05 --> Total execution time: 0.0480
ERROR - 2018-07-21 19:44:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:44:07 --> Config Class Initialized
INFO - 2018-07-21 19:44:07 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:44:07 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:44:07 --> Utf8 Class Initialized
INFO - 2018-07-21 19:44:07 --> URI Class Initialized
INFO - 2018-07-21 19:44:07 --> Router Class Initialized
INFO - 2018-07-21 19:44:07 --> Output Class Initialized
INFO - 2018-07-21 19:44:07 --> Security Class Initialized
DEBUG - 2018-07-21 19:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:44:07 --> Input Class Initialized
INFO - 2018-07-21 19:44:07 --> Language Class Initialized
INFO - 2018-07-21 19:44:07 --> Loader Class Initialized
INFO - 2018-07-21 19:44:07 --> Controller Class Initialized
INFO - 2018-07-21 19:44:07 --> Database Driver Class Initialized
INFO - 2018-07-21 19:44:07 --> Model Class Initialized
INFO - 2018-07-21 19:44:07 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:44:07 --> Model Class Initialized
INFO - 2018-07-21 19:44:07 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:44:07 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 19:44:07 --> Final output sent to browser
DEBUG - 2018-07-21 19:44:07 --> Total execution time: 0.0464
ERROR - 2018-07-21 19:44:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:44:56 --> Config Class Initialized
INFO - 2018-07-21 19:44:56 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:44:56 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:44:56 --> Utf8 Class Initialized
INFO - 2018-07-21 19:44:56 --> URI Class Initialized
INFO - 2018-07-21 19:44:56 --> Router Class Initialized
INFO - 2018-07-21 19:44:56 --> Output Class Initialized
INFO - 2018-07-21 19:44:56 --> Security Class Initialized
DEBUG - 2018-07-21 19:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:44:56 --> Input Class Initialized
INFO - 2018-07-21 19:44:56 --> Language Class Initialized
INFO - 2018-07-21 19:44:56 --> Loader Class Initialized
INFO - 2018-07-21 19:44:56 --> Controller Class Initialized
INFO - 2018-07-21 19:44:56 --> Database Driver Class Initialized
INFO - 2018-07-21 19:44:56 --> Model Class Initialized
INFO - 2018-07-21 19:44:56 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:44:56 --> Model Class Initialized
INFO - 2018-07-21 19:44:56 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:44:56 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 19:44:56 --> Final output sent to browser
DEBUG - 2018-07-21 19:44:56 --> Total execution time: 0.0536
ERROR - 2018-07-21 19:45:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:45:00 --> Config Class Initialized
INFO - 2018-07-21 19:45:00 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:45:00 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:45:00 --> Utf8 Class Initialized
INFO - 2018-07-21 19:45:00 --> URI Class Initialized
INFO - 2018-07-21 19:45:00 --> Router Class Initialized
INFO - 2018-07-21 19:45:00 --> Output Class Initialized
INFO - 2018-07-21 19:45:00 --> Security Class Initialized
DEBUG - 2018-07-21 19:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:45:00 --> Input Class Initialized
INFO - 2018-07-21 19:45:00 --> Language Class Initialized
INFO - 2018-07-21 19:45:00 --> Loader Class Initialized
INFO - 2018-07-21 19:45:00 --> Controller Class Initialized
INFO - 2018-07-21 19:45:00 --> Database Driver Class Initialized
INFO - 2018-07-21 19:45:00 --> Model Class Initialized
INFO - 2018-07-21 19:45:00 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:45:00 --> Model Class Initialized
INFO - 2018-07-21 19:45:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:45:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 19:45:00 --> Final output sent to browser
DEBUG - 2018-07-21 19:45:00 --> Total execution time: 0.0497
ERROR - 2018-07-21 19:45:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:45:07 --> Config Class Initialized
INFO - 2018-07-21 19:45:07 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:45:07 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:45:07 --> Utf8 Class Initialized
INFO - 2018-07-21 19:45:07 --> URI Class Initialized
INFO - 2018-07-21 19:45:07 --> Router Class Initialized
INFO - 2018-07-21 19:45:07 --> Output Class Initialized
INFO - 2018-07-21 19:45:07 --> Security Class Initialized
DEBUG - 2018-07-21 19:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:45:07 --> Input Class Initialized
INFO - 2018-07-21 19:45:07 --> Language Class Initialized
INFO - 2018-07-21 19:45:07 --> Loader Class Initialized
INFO - 2018-07-21 19:45:07 --> Controller Class Initialized
INFO - 2018-07-21 19:45:07 --> Database Driver Class Initialized
INFO - 2018-07-21 19:45:07 --> Model Class Initialized
INFO - 2018-07-21 19:45:07 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:45:07 --> Model Class Initialized
INFO - 2018-07-21 19:45:07 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:45:07 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 19:45:07 --> Final output sent to browser
DEBUG - 2018-07-21 19:45:07 --> Total execution time: 0.0825
ERROR - 2018-07-21 19:45:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:45:47 --> Config Class Initialized
INFO - 2018-07-21 19:45:47 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:45:47 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:45:47 --> Utf8 Class Initialized
INFO - 2018-07-21 19:45:47 --> URI Class Initialized
INFO - 2018-07-21 19:45:47 --> Router Class Initialized
INFO - 2018-07-21 19:45:47 --> Output Class Initialized
INFO - 2018-07-21 19:45:47 --> Security Class Initialized
DEBUG - 2018-07-21 19:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:45:47 --> Input Class Initialized
INFO - 2018-07-21 19:45:47 --> Language Class Initialized
INFO - 2018-07-21 19:45:47 --> Loader Class Initialized
INFO - 2018-07-21 19:45:47 --> Controller Class Initialized
INFO - 2018-07-21 19:45:47 --> Database Driver Class Initialized
INFO - 2018-07-21 19:45:47 --> Model Class Initialized
INFO - 2018-07-21 19:45:47 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:45:47 --> Model Class Initialized
INFO - 2018-07-21 19:45:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:45:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 19:45:47 --> Final output sent to browser
DEBUG - 2018-07-21 19:45:47 --> Total execution time: 0.0613
ERROR - 2018-07-21 19:46:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:46:41 --> Config Class Initialized
INFO - 2018-07-21 19:46:41 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:46:41 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:46:41 --> Utf8 Class Initialized
INFO - 2018-07-21 19:46:41 --> URI Class Initialized
INFO - 2018-07-21 19:46:41 --> Router Class Initialized
INFO - 2018-07-21 19:46:41 --> Output Class Initialized
INFO - 2018-07-21 19:46:41 --> Security Class Initialized
DEBUG - 2018-07-21 19:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:46:41 --> Input Class Initialized
INFO - 2018-07-21 19:46:41 --> Language Class Initialized
INFO - 2018-07-21 19:46:41 --> Loader Class Initialized
INFO - 2018-07-21 19:46:41 --> Controller Class Initialized
INFO - 2018-07-21 19:46:41 --> Database Driver Class Initialized
INFO - 2018-07-21 19:46:41 --> Model Class Initialized
INFO - 2018-07-21 19:46:41 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:46:41 --> Model Class Initialized
INFO - 2018-07-21 19:46:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:46:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 19:46:41 --> Final output sent to browser
DEBUG - 2018-07-21 19:46:41 --> Total execution time: 0.0593
ERROR - 2018-07-21 19:52:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:52:59 --> Config Class Initialized
INFO - 2018-07-21 19:52:59 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:52:59 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:52:59 --> Utf8 Class Initialized
INFO - 2018-07-21 19:52:59 --> URI Class Initialized
INFO - 2018-07-21 19:52:59 --> Router Class Initialized
INFO - 2018-07-21 19:52:59 --> Output Class Initialized
INFO - 2018-07-21 19:52:59 --> Security Class Initialized
DEBUG - 2018-07-21 19:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:52:59 --> Input Class Initialized
INFO - 2018-07-21 19:52:59 --> Language Class Initialized
INFO - 2018-07-21 19:52:59 --> Loader Class Initialized
INFO - 2018-07-21 19:52:59 --> Controller Class Initialized
INFO - 2018-07-21 19:52:59 --> Database Driver Class Initialized
INFO - 2018-07-21 19:52:59 --> Model Class Initialized
INFO - 2018-07-21 19:52:59 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:52:59 --> Model Class Initialized
INFO - 2018-07-21 19:52:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:52:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 19:52:59 --> Final output sent to browser
DEBUG - 2018-07-21 19:52:59 --> Total execution time: 0.0411
ERROR - 2018-07-21 19:53:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:53:00 --> Config Class Initialized
INFO - 2018-07-21 19:53:00 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:53:00 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:53:00 --> Utf8 Class Initialized
INFO - 2018-07-21 19:53:00 --> URI Class Initialized
INFO - 2018-07-21 19:53:00 --> Router Class Initialized
INFO - 2018-07-21 19:53:00 --> Output Class Initialized
INFO - 2018-07-21 19:53:00 --> Security Class Initialized
DEBUG - 2018-07-21 19:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:53:00 --> Input Class Initialized
INFO - 2018-07-21 19:53:00 --> Language Class Initialized
INFO - 2018-07-21 19:53:00 --> Loader Class Initialized
INFO - 2018-07-21 19:53:00 --> Controller Class Initialized
INFO - 2018-07-21 19:53:00 --> Database Driver Class Initialized
INFO - 2018-07-21 19:53:00 --> Model Class Initialized
INFO - 2018-07-21 19:53:00 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:53:00 --> Model Class Initialized
INFO - 2018-07-21 19:53:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:53:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 19:53:00 --> Final output sent to browser
DEBUG - 2018-07-21 19:53:00 --> Total execution time: 0.0501
ERROR - 2018-07-21 19:53:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:53:34 --> Config Class Initialized
INFO - 2018-07-21 19:53:34 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:53:34 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:53:34 --> Utf8 Class Initialized
INFO - 2018-07-21 19:53:34 --> URI Class Initialized
INFO - 2018-07-21 19:53:34 --> Router Class Initialized
INFO - 2018-07-21 19:53:34 --> Output Class Initialized
INFO - 2018-07-21 19:53:34 --> Security Class Initialized
DEBUG - 2018-07-21 19:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:53:34 --> Input Class Initialized
INFO - 2018-07-21 19:53:34 --> Language Class Initialized
INFO - 2018-07-21 19:53:34 --> Loader Class Initialized
INFO - 2018-07-21 19:53:34 --> Controller Class Initialized
INFO - 2018-07-21 19:53:34 --> Database Driver Class Initialized
INFO - 2018-07-21 19:53:34 --> Model Class Initialized
INFO - 2018-07-21 19:53:34 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:53:34 --> Model Class Initialized
INFO - 2018-07-21 19:53:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:53:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 19:53:34 --> Final output sent to browser
DEBUG - 2018-07-21 19:53:34 --> Total execution time: 0.1176
ERROR - 2018-07-21 19:53:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:53:37 --> Config Class Initialized
INFO - 2018-07-21 19:53:37 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:53:37 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:53:37 --> Utf8 Class Initialized
INFO - 2018-07-21 19:53:37 --> URI Class Initialized
INFO - 2018-07-21 19:53:37 --> Router Class Initialized
INFO - 2018-07-21 19:53:37 --> Output Class Initialized
INFO - 2018-07-21 19:53:37 --> Security Class Initialized
DEBUG - 2018-07-21 19:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:53:37 --> Input Class Initialized
INFO - 2018-07-21 19:53:37 --> Language Class Initialized
INFO - 2018-07-21 19:53:37 --> Loader Class Initialized
INFO - 2018-07-21 19:53:37 --> Controller Class Initialized
INFO - 2018-07-21 19:53:37 --> Database Driver Class Initialized
INFO - 2018-07-21 19:53:37 --> Model Class Initialized
INFO - 2018-07-21 19:53:37 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:53:37 --> Model Class Initialized
INFO - 2018-07-21 19:53:37 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:53:37 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 19:53:37 --> Final output sent to browser
DEBUG - 2018-07-21 19:53:37 --> Total execution time: 0.0473
ERROR - 2018-07-21 19:53:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:53:45 --> Config Class Initialized
INFO - 2018-07-21 19:53:45 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:53:45 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:53:45 --> Utf8 Class Initialized
INFO - 2018-07-21 19:53:45 --> URI Class Initialized
INFO - 2018-07-21 19:53:45 --> Router Class Initialized
INFO - 2018-07-21 19:53:45 --> Output Class Initialized
INFO - 2018-07-21 19:53:45 --> Security Class Initialized
DEBUG - 2018-07-21 19:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:53:45 --> Input Class Initialized
INFO - 2018-07-21 19:53:45 --> Language Class Initialized
INFO - 2018-07-21 19:53:45 --> Loader Class Initialized
INFO - 2018-07-21 19:53:45 --> Controller Class Initialized
INFO - 2018-07-21 19:53:45 --> Database Driver Class Initialized
INFO - 2018-07-21 19:53:45 --> Model Class Initialized
INFO - 2018-07-21 19:53:45 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:53:45 --> Model Class Initialized
INFO - 2018-07-21 19:53:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:53:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 19:53:45 --> Final output sent to browser
DEBUG - 2018-07-21 19:53:45 --> Total execution time: 0.0652
ERROR - 2018-07-21 19:57:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:57:53 --> Config Class Initialized
INFO - 2018-07-21 19:57:53 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:57:53 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:57:53 --> Utf8 Class Initialized
INFO - 2018-07-21 19:57:53 --> URI Class Initialized
INFO - 2018-07-21 19:57:53 --> Router Class Initialized
INFO - 2018-07-21 19:57:53 --> Output Class Initialized
INFO - 2018-07-21 19:57:53 --> Security Class Initialized
DEBUG - 2018-07-21 19:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:57:53 --> Input Class Initialized
INFO - 2018-07-21 19:57:53 --> Language Class Initialized
INFO - 2018-07-21 19:57:53 --> Loader Class Initialized
INFO - 2018-07-21 19:57:53 --> Controller Class Initialized
INFO - 2018-07-21 19:57:53 --> Database Driver Class Initialized
INFO - 2018-07-21 19:57:53 --> Model Class Initialized
INFO - 2018-07-21 19:57:53 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:57:53 --> Model Class Initialized
INFO - 2018-07-21 19:57:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:57:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 19:57:53 --> Final output sent to browser
DEBUG - 2018-07-21 19:57:53 --> Total execution time: 0.0481
ERROR - 2018-07-21 19:58:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 19:58:29 --> Config Class Initialized
INFO - 2018-07-21 19:58:29 --> Hooks Class Initialized
DEBUG - 2018-07-21 19:58:29 --> UTF-8 Support Enabled
INFO - 2018-07-21 19:58:29 --> Utf8 Class Initialized
INFO - 2018-07-21 19:58:29 --> URI Class Initialized
INFO - 2018-07-21 19:58:29 --> Router Class Initialized
INFO - 2018-07-21 19:58:29 --> Output Class Initialized
INFO - 2018-07-21 19:58:29 --> Security Class Initialized
DEBUG - 2018-07-21 19:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 19:58:29 --> Input Class Initialized
INFO - 2018-07-21 19:58:29 --> Language Class Initialized
INFO - 2018-07-21 19:58:29 --> Loader Class Initialized
INFO - 2018-07-21 19:58:29 --> Controller Class Initialized
INFO - 2018-07-21 19:58:29 --> Database Driver Class Initialized
INFO - 2018-07-21 19:58:29 --> Model Class Initialized
INFO - 2018-07-21 19:58:29 --> Helper loaded: url_helper
DEBUG - 2018-07-21 19:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 19:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 19:58:29 --> Model Class Initialized
INFO - 2018-07-21 19:58:29 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 19:58:29 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 19:58:29 --> Final output sent to browser
DEBUG - 2018-07-21 19:58:29 --> Total execution time: 0.0489
ERROR - 2018-07-21 20:04:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:04:11 --> Config Class Initialized
INFO - 2018-07-21 20:04:11 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:04:11 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:04:11 --> Utf8 Class Initialized
INFO - 2018-07-21 20:04:11 --> URI Class Initialized
INFO - 2018-07-21 20:04:11 --> Router Class Initialized
INFO - 2018-07-21 20:04:11 --> Output Class Initialized
INFO - 2018-07-21 20:04:11 --> Security Class Initialized
DEBUG - 2018-07-21 20:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:04:11 --> Input Class Initialized
INFO - 2018-07-21 20:04:11 --> Language Class Initialized
INFO - 2018-07-21 20:04:11 --> Loader Class Initialized
INFO - 2018-07-21 20:04:11 --> Controller Class Initialized
INFO - 2018-07-21 20:04:11 --> Database Driver Class Initialized
INFO - 2018-07-21 20:04:11 --> Model Class Initialized
INFO - 2018-07-21 20:04:11 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:04:11 --> Model Class Initialized
INFO - 2018-07-21 20:04:11 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:04:11 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 20:04:11 --> Final output sent to browser
DEBUG - 2018-07-21 20:04:11 --> Total execution time: 0.0397
ERROR - 2018-07-21 20:04:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:04:23 --> Config Class Initialized
INFO - 2018-07-21 20:04:23 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:04:23 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:04:23 --> Utf8 Class Initialized
INFO - 2018-07-21 20:04:23 --> URI Class Initialized
INFO - 2018-07-21 20:04:23 --> Router Class Initialized
INFO - 2018-07-21 20:04:23 --> Output Class Initialized
INFO - 2018-07-21 20:04:23 --> Security Class Initialized
DEBUG - 2018-07-21 20:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:04:23 --> Input Class Initialized
INFO - 2018-07-21 20:04:23 --> Language Class Initialized
INFO - 2018-07-21 20:04:23 --> Loader Class Initialized
INFO - 2018-07-21 20:04:23 --> Controller Class Initialized
INFO - 2018-07-21 20:04:23 --> Database Driver Class Initialized
INFO - 2018-07-21 20:04:23 --> Model Class Initialized
INFO - 2018-07-21 20:04:23 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:04:23 --> Model Class Initialized
INFO - 2018-07-21 20:04:23 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:04:23 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 20:04:23 --> Final output sent to browser
DEBUG - 2018-07-21 20:04:23 --> Total execution time: 0.1576
ERROR - 2018-07-21 20:04:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:04:25 --> Config Class Initialized
INFO - 2018-07-21 20:04:25 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:04:25 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:04:25 --> Utf8 Class Initialized
INFO - 2018-07-21 20:04:25 --> URI Class Initialized
INFO - 2018-07-21 20:04:25 --> Router Class Initialized
INFO - 2018-07-21 20:04:25 --> Output Class Initialized
INFO - 2018-07-21 20:04:25 --> Security Class Initialized
DEBUG - 2018-07-21 20:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:04:25 --> Input Class Initialized
INFO - 2018-07-21 20:04:25 --> Language Class Initialized
INFO - 2018-07-21 20:04:25 --> Loader Class Initialized
INFO - 2018-07-21 20:04:25 --> Controller Class Initialized
INFO - 2018-07-21 20:04:25 --> Database Driver Class Initialized
INFO - 2018-07-21 20:04:25 --> Model Class Initialized
INFO - 2018-07-21 20:04:25 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:04:25 --> Model Class Initialized
INFO - 2018-07-21 20:04:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:04:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 20:04:25 --> Final output sent to browser
DEBUG - 2018-07-21 20:04:25 --> Total execution time: 0.0416
ERROR - 2018-07-21 20:04:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:04:30 --> Config Class Initialized
INFO - 2018-07-21 20:04:30 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:04:30 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:04:30 --> Utf8 Class Initialized
INFO - 2018-07-21 20:04:30 --> URI Class Initialized
INFO - 2018-07-21 20:04:30 --> Router Class Initialized
INFO - 2018-07-21 20:04:30 --> Output Class Initialized
INFO - 2018-07-21 20:04:30 --> Security Class Initialized
DEBUG - 2018-07-21 20:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:04:30 --> Input Class Initialized
INFO - 2018-07-21 20:04:30 --> Language Class Initialized
INFO - 2018-07-21 20:04:30 --> Loader Class Initialized
INFO - 2018-07-21 20:04:30 --> Controller Class Initialized
INFO - 2018-07-21 20:04:30 --> Database Driver Class Initialized
INFO - 2018-07-21 20:04:30 --> Model Class Initialized
INFO - 2018-07-21 20:04:30 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:04:30 --> Model Class Initialized
INFO - 2018-07-21 20:04:30 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:04:30 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 20:04:30 --> Final output sent to browser
DEBUG - 2018-07-21 20:04:30 --> Total execution time: 0.0578
ERROR - 2018-07-21 20:04:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:04:59 --> Config Class Initialized
INFO - 2018-07-21 20:04:59 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:04:59 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:04:59 --> Utf8 Class Initialized
INFO - 2018-07-21 20:04:59 --> URI Class Initialized
INFO - 2018-07-21 20:04:59 --> Router Class Initialized
INFO - 2018-07-21 20:04:59 --> Output Class Initialized
INFO - 2018-07-21 20:04:59 --> Security Class Initialized
DEBUG - 2018-07-21 20:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:04:59 --> Input Class Initialized
INFO - 2018-07-21 20:04:59 --> Language Class Initialized
INFO - 2018-07-21 20:04:59 --> Loader Class Initialized
INFO - 2018-07-21 20:04:59 --> Controller Class Initialized
INFO - 2018-07-21 20:04:59 --> Database Driver Class Initialized
INFO - 2018-07-21 20:04:59 --> Model Class Initialized
INFO - 2018-07-21 20:04:59 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:04:59 --> Model Class Initialized
ERROR - 2018-07-21 20:04:59 --> Severity: Notice --> Undefined index: cnt C:\xampp\htdocs\davidhood\application\controllers\Main.php 43
INFO - 2018-07-21 20:04:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:04:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 20:04:59 --> Final output sent to browser
DEBUG - 2018-07-21 20:04:59 --> Total execution time: 0.0669
ERROR - 2018-07-21 20:06:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:06:43 --> Config Class Initialized
INFO - 2018-07-21 20:06:43 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:06:43 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:06:43 --> Utf8 Class Initialized
INFO - 2018-07-21 20:06:43 --> URI Class Initialized
INFO - 2018-07-21 20:06:43 --> Router Class Initialized
INFO - 2018-07-21 20:06:43 --> Output Class Initialized
INFO - 2018-07-21 20:06:43 --> Security Class Initialized
DEBUG - 2018-07-21 20:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:06:43 --> Input Class Initialized
INFO - 2018-07-21 20:06:43 --> Language Class Initialized
INFO - 2018-07-21 20:06:43 --> Loader Class Initialized
INFO - 2018-07-21 20:06:43 --> Controller Class Initialized
INFO - 2018-07-21 20:06:43 --> Database Driver Class Initialized
INFO - 2018-07-21 20:06:43 --> Model Class Initialized
INFO - 2018-07-21 20:06:43 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:06:43 --> Model Class Initialized
INFO - 2018-07-21 20:06:43 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:06:43 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 20:06:43 --> Final output sent to browser
DEBUG - 2018-07-21 20:06:43 --> Total execution time: 0.1774
ERROR - 2018-07-21 20:06:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:06:50 --> Config Class Initialized
INFO - 2018-07-21 20:06:50 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:06:50 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:06:50 --> Utf8 Class Initialized
INFO - 2018-07-21 20:06:50 --> URI Class Initialized
INFO - 2018-07-21 20:06:50 --> Router Class Initialized
INFO - 2018-07-21 20:06:50 --> Output Class Initialized
INFO - 2018-07-21 20:06:50 --> Security Class Initialized
DEBUG - 2018-07-21 20:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:06:50 --> Input Class Initialized
INFO - 2018-07-21 20:06:50 --> Language Class Initialized
INFO - 2018-07-21 20:06:50 --> Loader Class Initialized
INFO - 2018-07-21 20:06:50 --> Controller Class Initialized
INFO - 2018-07-21 20:06:50 --> Database Driver Class Initialized
INFO - 2018-07-21 20:06:50 --> Model Class Initialized
INFO - 2018-07-21 20:06:50 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:06:50 --> Model Class Initialized
INFO - 2018-07-21 20:06:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:06:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 20:06:50 --> Final output sent to browser
DEBUG - 2018-07-21 20:06:50 --> Total execution time: 0.0390
ERROR - 2018-07-21 20:07:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:07:15 --> Config Class Initialized
INFO - 2018-07-21 20:07:15 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:07:15 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:07:15 --> Utf8 Class Initialized
INFO - 2018-07-21 20:07:15 --> URI Class Initialized
INFO - 2018-07-21 20:07:15 --> Router Class Initialized
INFO - 2018-07-21 20:07:15 --> Output Class Initialized
INFO - 2018-07-21 20:07:15 --> Security Class Initialized
DEBUG - 2018-07-21 20:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:07:15 --> Input Class Initialized
INFO - 2018-07-21 20:07:15 --> Language Class Initialized
INFO - 2018-07-21 20:07:15 --> Loader Class Initialized
INFO - 2018-07-21 20:07:15 --> Controller Class Initialized
INFO - 2018-07-21 20:07:15 --> Database Driver Class Initialized
INFO - 2018-07-21 20:07:15 --> Model Class Initialized
INFO - 2018-07-21 20:07:15 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:07:15 --> Model Class Initialized
INFO - 2018-07-21 20:07:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:07:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 20:07:15 --> Final output sent to browser
DEBUG - 2018-07-21 20:07:15 --> Total execution time: 0.0685
ERROR - 2018-07-21 20:07:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:07:22 --> Config Class Initialized
INFO - 2018-07-21 20:07:22 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:07:22 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:07:22 --> Utf8 Class Initialized
INFO - 2018-07-21 20:07:22 --> URI Class Initialized
INFO - 2018-07-21 20:07:22 --> Router Class Initialized
INFO - 2018-07-21 20:07:22 --> Output Class Initialized
INFO - 2018-07-21 20:07:22 --> Security Class Initialized
DEBUG - 2018-07-21 20:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:07:22 --> Input Class Initialized
INFO - 2018-07-21 20:07:22 --> Language Class Initialized
INFO - 2018-07-21 20:07:22 --> Loader Class Initialized
INFO - 2018-07-21 20:07:22 --> Controller Class Initialized
INFO - 2018-07-21 20:07:22 --> Database Driver Class Initialized
INFO - 2018-07-21 20:07:22 --> Model Class Initialized
INFO - 2018-07-21 20:07:22 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:07:22 --> Model Class Initialized
INFO - 2018-07-21 20:07:22 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:07:22 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-21 20:07:22 --> Final output sent to browser
DEBUG - 2018-07-21 20:07:22 --> Total execution time: 0.0653
ERROR - 2018-07-21 20:07:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:07:28 --> Config Class Initialized
INFO - 2018-07-21 20:07:28 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:07:28 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:07:28 --> Utf8 Class Initialized
INFO - 2018-07-21 20:07:28 --> URI Class Initialized
INFO - 2018-07-21 20:07:28 --> Router Class Initialized
INFO - 2018-07-21 20:07:28 --> Output Class Initialized
INFO - 2018-07-21 20:07:28 --> Security Class Initialized
DEBUG - 2018-07-21 20:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:07:28 --> Input Class Initialized
INFO - 2018-07-21 20:07:28 --> Language Class Initialized
INFO - 2018-07-21 20:07:28 --> Loader Class Initialized
INFO - 2018-07-21 20:07:28 --> Controller Class Initialized
INFO - 2018-07-21 20:07:28 --> Database Driver Class Initialized
INFO - 2018-07-21 20:07:28 --> Model Class Initialized
INFO - 2018-07-21 20:07:28 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:07:28 --> Model Class Initialized
INFO - 2018-07-21 20:07:28 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:07:28 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-21 20:07:28 --> Final output sent to browser
DEBUG - 2018-07-21 20:07:28 --> Total execution time: 0.0428
ERROR - 2018-07-21 20:07:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:07:33 --> Config Class Initialized
INFO - 2018-07-21 20:07:33 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:07:33 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:07:33 --> Utf8 Class Initialized
INFO - 2018-07-21 20:07:33 --> URI Class Initialized
INFO - 2018-07-21 20:07:33 --> Router Class Initialized
INFO - 2018-07-21 20:07:33 --> Output Class Initialized
INFO - 2018-07-21 20:07:33 --> Security Class Initialized
DEBUG - 2018-07-21 20:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:07:33 --> Input Class Initialized
INFO - 2018-07-21 20:07:33 --> Language Class Initialized
INFO - 2018-07-21 20:07:33 --> Loader Class Initialized
INFO - 2018-07-21 20:07:33 --> Controller Class Initialized
INFO - 2018-07-21 20:07:33 --> Database Driver Class Initialized
INFO - 2018-07-21 20:07:33 --> Model Class Initialized
INFO - 2018-07-21 20:07:33 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:07:33 --> Model Class Initialized
INFO - 2018-07-21 20:07:33 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:07:33 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 20:07:33 --> Final output sent to browser
DEBUG - 2018-07-21 20:07:33 --> Total execution time: 0.0477
ERROR - 2018-07-21 20:07:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:07:34 --> Config Class Initialized
INFO - 2018-07-21 20:07:34 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:07:34 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:07:34 --> Utf8 Class Initialized
INFO - 2018-07-21 20:07:34 --> URI Class Initialized
INFO - 2018-07-21 20:07:34 --> Router Class Initialized
INFO - 2018-07-21 20:07:34 --> Output Class Initialized
INFO - 2018-07-21 20:07:34 --> Security Class Initialized
DEBUG - 2018-07-21 20:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:07:34 --> Input Class Initialized
INFO - 2018-07-21 20:07:34 --> Language Class Initialized
INFO - 2018-07-21 20:07:34 --> Loader Class Initialized
INFO - 2018-07-21 20:07:34 --> Controller Class Initialized
INFO - 2018-07-21 20:07:34 --> Database Driver Class Initialized
INFO - 2018-07-21 20:07:34 --> Model Class Initialized
INFO - 2018-07-21 20:07:34 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:07:34 --> Model Class Initialized
INFO - 2018-07-21 20:07:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:07:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 20:07:34 --> Final output sent to browser
DEBUG - 2018-07-21 20:07:34 --> Total execution time: 0.0402
ERROR - 2018-07-21 20:07:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:07:36 --> Config Class Initialized
INFO - 2018-07-21 20:07:36 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:07:36 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:07:36 --> Utf8 Class Initialized
INFO - 2018-07-21 20:07:36 --> URI Class Initialized
INFO - 2018-07-21 20:07:36 --> Router Class Initialized
INFO - 2018-07-21 20:07:36 --> Output Class Initialized
INFO - 2018-07-21 20:07:36 --> Security Class Initialized
DEBUG - 2018-07-21 20:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:07:36 --> Input Class Initialized
INFO - 2018-07-21 20:07:36 --> Language Class Initialized
INFO - 2018-07-21 20:07:36 --> Loader Class Initialized
INFO - 2018-07-21 20:07:36 --> Controller Class Initialized
INFO - 2018-07-21 20:07:36 --> Database Driver Class Initialized
INFO - 2018-07-21 20:07:36 --> Model Class Initialized
INFO - 2018-07-21 20:07:36 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:07:36 --> Model Class Initialized
INFO - 2018-07-21 20:07:36 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:07:36 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 20:07:36 --> Final output sent to browser
DEBUG - 2018-07-21 20:07:36 --> Total execution time: 0.0544
ERROR - 2018-07-21 20:17:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:17:47 --> Config Class Initialized
INFO - 2018-07-21 20:17:47 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:17:47 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:17:47 --> Utf8 Class Initialized
INFO - 2018-07-21 20:17:47 --> URI Class Initialized
INFO - 2018-07-21 20:17:47 --> Router Class Initialized
INFO - 2018-07-21 20:17:47 --> Output Class Initialized
INFO - 2018-07-21 20:17:47 --> Security Class Initialized
DEBUG - 2018-07-21 20:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:17:47 --> Input Class Initialized
INFO - 2018-07-21 20:17:47 --> Language Class Initialized
INFO - 2018-07-21 20:17:47 --> Loader Class Initialized
INFO - 2018-07-21 20:17:47 --> Controller Class Initialized
INFO - 2018-07-21 20:17:47 --> Database Driver Class Initialized
INFO - 2018-07-21 20:17:47 --> Model Class Initialized
INFO - 2018-07-21 20:17:47 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:17:47 --> Model Class Initialized
INFO - 2018-07-21 20:17:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:17:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 20:17:47 --> Final output sent to browser
DEBUG - 2018-07-21 20:17:47 --> Total execution time: 0.0552
ERROR - 2018-07-21 20:19:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:19:52 --> Config Class Initialized
INFO - 2018-07-21 20:19:52 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:19:52 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:19:52 --> Utf8 Class Initialized
INFO - 2018-07-21 20:19:52 --> URI Class Initialized
INFO - 2018-07-21 20:19:52 --> Router Class Initialized
INFO - 2018-07-21 20:19:52 --> Output Class Initialized
INFO - 2018-07-21 20:19:52 --> Security Class Initialized
DEBUG - 2018-07-21 20:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:19:52 --> Input Class Initialized
INFO - 2018-07-21 20:19:52 --> Language Class Initialized
INFO - 2018-07-21 20:19:52 --> Loader Class Initialized
INFO - 2018-07-21 20:19:52 --> Controller Class Initialized
INFO - 2018-07-21 20:19:52 --> Database Driver Class Initialized
INFO - 2018-07-21 20:19:52 --> Model Class Initialized
INFO - 2018-07-21 20:19:52 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:19:52 --> Model Class Initialized
INFO - 2018-07-21 20:19:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:19:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 20:19:52 --> Final output sent to browser
DEBUG - 2018-07-21 20:19:52 --> Total execution time: 0.0403
ERROR - 2018-07-21 20:20:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:20:05 --> Config Class Initialized
INFO - 2018-07-21 20:20:05 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:20:05 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:20:05 --> Utf8 Class Initialized
INFO - 2018-07-21 20:20:05 --> URI Class Initialized
INFO - 2018-07-21 20:20:05 --> Router Class Initialized
INFO - 2018-07-21 20:20:05 --> Output Class Initialized
INFO - 2018-07-21 20:20:05 --> Security Class Initialized
DEBUG - 2018-07-21 20:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:20:05 --> Input Class Initialized
INFO - 2018-07-21 20:20:05 --> Language Class Initialized
INFO - 2018-07-21 20:20:05 --> Loader Class Initialized
INFO - 2018-07-21 20:20:05 --> Controller Class Initialized
INFO - 2018-07-21 20:20:05 --> Database Driver Class Initialized
INFO - 2018-07-21 20:20:05 --> Model Class Initialized
INFO - 2018-07-21 20:20:05 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:20:05 --> Model Class Initialized
INFO - 2018-07-21 20:20:05 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:20:05 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 20:20:05 --> Final output sent to browser
DEBUG - 2018-07-21 20:20:05 --> Total execution time: 0.0510
ERROR - 2018-07-21 20:20:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:20:10 --> Config Class Initialized
INFO - 2018-07-21 20:20:10 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:20:10 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:20:10 --> Utf8 Class Initialized
INFO - 2018-07-21 20:20:10 --> URI Class Initialized
INFO - 2018-07-21 20:20:10 --> Router Class Initialized
INFO - 2018-07-21 20:20:10 --> Output Class Initialized
INFO - 2018-07-21 20:20:10 --> Security Class Initialized
DEBUG - 2018-07-21 20:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:20:10 --> Input Class Initialized
INFO - 2018-07-21 20:20:10 --> Language Class Initialized
INFO - 2018-07-21 20:20:10 --> Loader Class Initialized
INFO - 2018-07-21 20:20:10 --> Controller Class Initialized
INFO - 2018-07-21 20:20:10 --> Database Driver Class Initialized
INFO - 2018-07-21 20:20:10 --> Model Class Initialized
INFO - 2018-07-21 20:20:10 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:20:10 --> Model Class Initialized
INFO - 2018-07-21 20:20:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:20:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 20:20:10 --> Final output sent to browser
DEBUG - 2018-07-21 20:20:10 --> Total execution time: 0.0715
ERROR - 2018-07-21 20:20:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:20:52 --> Config Class Initialized
INFO - 2018-07-21 20:20:52 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:20:52 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:20:52 --> Utf8 Class Initialized
INFO - 2018-07-21 20:20:52 --> URI Class Initialized
INFO - 2018-07-21 20:20:52 --> Router Class Initialized
INFO - 2018-07-21 20:20:52 --> Output Class Initialized
INFO - 2018-07-21 20:20:52 --> Security Class Initialized
DEBUG - 2018-07-21 20:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:20:52 --> Input Class Initialized
INFO - 2018-07-21 20:20:52 --> Language Class Initialized
INFO - 2018-07-21 20:20:52 --> Loader Class Initialized
INFO - 2018-07-21 20:20:52 --> Controller Class Initialized
INFO - 2018-07-21 20:20:52 --> Database Driver Class Initialized
INFO - 2018-07-21 20:20:52 --> Model Class Initialized
INFO - 2018-07-21 20:20:52 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:20:52 --> Model Class Initialized
INFO - 2018-07-21 20:20:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:20:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-21 20:20:52 --> Final output sent to browser
DEBUG - 2018-07-21 20:20:52 --> Total execution time: 0.0506
ERROR - 2018-07-21 20:21:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:21:02 --> Config Class Initialized
INFO - 2018-07-21 20:21:02 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:21:02 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:21:02 --> Utf8 Class Initialized
INFO - 2018-07-21 20:21:02 --> URI Class Initialized
INFO - 2018-07-21 20:21:02 --> Router Class Initialized
INFO - 2018-07-21 20:21:02 --> Output Class Initialized
INFO - 2018-07-21 20:21:02 --> Security Class Initialized
DEBUG - 2018-07-21 20:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:21:02 --> Input Class Initialized
INFO - 2018-07-21 20:21:02 --> Language Class Initialized
INFO - 2018-07-21 20:21:02 --> Loader Class Initialized
INFO - 2018-07-21 20:21:02 --> Controller Class Initialized
INFO - 2018-07-21 20:21:02 --> Database Driver Class Initialized
INFO - 2018-07-21 20:21:02 --> Model Class Initialized
INFO - 2018-07-21 20:21:02 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:21:02 --> Model Class Initialized
INFO - 2018-07-21 20:21:02 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:21:02 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 20:21:02 --> Final output sent to browser
DEBUG - 2018-07-21 20:21:02 --> Total execution time: 0.0595
ERROR - 2018-07-21 20:21:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:21:40 --> Config Class Initialized
INFO - 2018-07-21 20:21:40 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:21:40 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:21:40 --> Utf8 Class Initialized
INFO - 2018-07-21 20:21:40 --> URI Class Initialized
INFO - 2018-07-21 20:21:40 --> Router Class Initialized
INFO - 2018-07-21 20:21:41 --> Output Class Initialized
INFO - 2018-07-21 20:21:41 --> Security Class Initialized
DEBUG - 2018-07-21 20:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:21:41 --> Input Class Initialized
INFO - 2018-07-21 20:21:41 --> Language Class Initialized
INFO - 2018-07-21 20:21:41 --> Loader Class Initialized
INFO - 2018-07-21 20:21:41 --> Controller Class Initialized
INFO - 2018-07-21 20:21:41 --> Database Driver Class Initialized
INFO - 2018-07-21 20:21:41 --> Model Class Initialized
INFO - 2018-07-21 20:21:41 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:21:41 --> Model Class Initialized
INFO - 2018-07-21 20:21:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:21:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 20:21:41 --> Final output sent to browser
DEBUG - 2018-07-21 20:21:41 --> Total execution time: 0.0516
ERROR - 2018-07-21 20:23:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:23:34 --> Config Class Initialized
INFO - 2018-07-21 20:23:34 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:23:34 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:23:34 --> Utf8 Class Initialized
INFO - 2018-07-21 20:23:34 --> URI Class Initialized
INFO - 2018-07-21 20:23:34 --> Router Class Initialized
INFO - 2018-07-21 20:23:34 --> Output Class Initialized
INFO - 2018-07-21 20:23:34 --> Security Class Initialized
DEBUG - 2018-07-21 20:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:23:34 --> Input Class Initialized
INFO - 2018-07-21 20:23:34 --> Language Class Initialized
INFO - 2018-07-21 20:23:34 --> Loader Class Initialized
INFO - 2018-07-21 20:23:34 --> Controller Class Initialized
INFO - 2018-07-21 20:23:34 --> Database Driver Class Initialized
INFO - 2018-07-21 20:23:34 --> Model Class Initialized
INFO - 2018-07-21 20:23:34 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:23:34 --> Model Class Initialized
INFO - 2018-07-21 20:23:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:23:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 20:23:34 --> Final output sent to browser
DEBUG - 2018-07-21 20:23:34 --> Total execution time: 0.0770
ERROR - 2018-07-21 20:23:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:23:35 --> Config Class Initialized
INFO - 2018-07-21 20:23:35 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:23:35 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:23:35 --> Utf8 Class Initialized
INFO - 2018-07-21 20:23:35 --> URI Class Initialized
INFO - 2018-07-21 20:23:35 --> Router Class Initialized
INFO - 2018-07-21 20:23:35 --> Output Class Initialized
INFO - 2018-07-21 20:23:35 --> Security Class Initialized
DEBUG - 2018-07-21 20:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:23:35 --> Input Class Initialized
INFO - 2018-07-21 20:23:35 --> Language Class Initialized
INFO - 2018-07-21 20:23:35 --> Loader Class Initialized
INFO - 2018-07-21 20:23:35 --> Controller Class Initialized
INFO - 2018-07-21 20:23:35 --> Database Driver Class Initialized
INFO - 2018-07-21 20:23:35 --> Model Class Initialized
INFO - 2018-07-21 20:23:35 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:23:35 --> Model Class Initialized
INFO - 2018-07-21 20:23:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:23:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 20:23:35 --> Final output sent to browser
DEBUG - 2018-07-21 20:23:35 --> Total execution time: 0.0526
ERROR - 2018-07-21 20:23:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:23:59 --> Config Class Initialized
INFO - 2018-07-21 20:23:59 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:23:59 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:23:59 --> Utf8 Class Initialized
INFO - 2018-07-21 20:23:59 --> URI Class Initialized
INFO - 2018-07-21 20:23:59 --> Router Class Initialized
INFO - 2018-07-21 20:23:59 --> Output Class Initialized
INFO - 2018-07-21 20:23:59 --> Security Class Initialized
DEBUG - 2018-07-21 20:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:23:59 --> Input Class Initialized
INFO - 2018-07-21 20:23:59 --> Language Class Initialized
INFO - 2018-07-21 20:23:59 --> Loader Class Initialized
INFO - 2018-07-21 20:23:59 --> Controller Class Initialized
INFO - 2018-07-21 20:23:59 --> Database Driver Class Initialized
INFO - 2018-07-21 20:23:59 --> Model Class Initialized
INFO - 2018-07-21 20:23:59 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:23:59 --> Model Class Initialized
INFO - 2018-07-21 20:23:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:23:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 20:23:59 --> Final output sent to browser
DEBUG - 2018-07-21 20:23:59 --> Total execution time: 0.1614
ERROR - 2018-07-21 20:24:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:24:30 --> Config Class Initialized
INFO - 2018-07-21 20:24:30 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:24:30 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:24:30 --> Utf8 Class Initialized
INFO - 2018-07-21 20:24:30 --> URI Class Initialized
INFO - 2018-07-21 20:24:30 --> Router Class Initialized
INFO - 2018-07-21 20:24:30 --> Output Class Initialized
INFO - 2018-07-21 20:24:30 --> Security Class Initialized
DEBUG - 2018-07-21 20:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:24:30 --> Input Class Initialized
INFO - 2018-07-21 20:24:30 --> Language Class Initialized
INFO - 2018-07-21 20:24:30 --> Loader Class Initialized
INFO - 2018-07-21 20:24:30 --> Controller Class Initialized
INFO - 2018-07-21 20:24:30 --> Database Driver Class Initialized
INFO - 2018-07-21 20:24:30 --> Model Class Initialized
INFO - 2018-07-21 20:24:30 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:24:30 --> Model Class Initialized
INFO - 2018-07-21 20:24:30 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:24:30 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 20:24:30 --> Final output sent to browser
DEBUG - 2018-07-21 20:24:30 --> Total execution time: 0.0391
ERROR - 2018-07-21 20:40:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:40:15 --> Config Class Initialized
INFO - 2018-07-21 20:40:15 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:40:15 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:40:15 --> Utf8 Class Initialized
INFO - 2018-07-21 20:40:15 --> URI Class Initialized
INFO - 2018-07-21 20:40:15 --> Router Class Initialized
INFO - 2018-07-21 20:40:15 --> Output Class Initialized
INFO - 2018-07-21 20:40:15 --> Security Class Initialized
DEBUG - 2018-07-21 20:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:40:15 --> Input Class Initialized
INFO - 2018-07-21 20:40:15 --> Language Class Initialized
INFO - 2018-07-21 20:40:15 --> Loader Class Initialized
INFO - 2018-07-21 20:40:15 --> Controller Class Initialized
INFO - 2018-07-21 20:40:15 --> Database Driver Class Initialized
INFO - 2018-07-21 20:40:16 --> Model Class Initialized
INFO - 2018-07-21 20:40:16 --> Helper loaded: url_helper
INFO - 2018-07-21 20:40:16 --> Model Class Initialized
ERROR - 2018-07-21 20:40:16 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 16
INFO - 2018-07-21 20:40:16 --> Final output sent to browser
DEBUG - 2018-07-21 20:40:16 --> Total execution time: 0.0513
ERROR - 2018-07-21 20:42:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:42:24 --> Config Class Initialized
INFO - 2018-07-21 20:42:24 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:42:24 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:42:24 --> Utf8 Class Initialized
INFO - 2018-07-21 20:42:24 --> URI Class Initialized
INFO - 2018-07-21 20:42:24 --> Router Class Initialized
INFO - 2018-07-21 20:42:24 --> Output Class Initialized
INFO - 2018-07-21 20:42:24 --> Security Class Initialized
DEBUG - 2018-07-21 20:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:42:24 --> Input Class Initialized
INFO - 2018-07-21 20:42:24 --> Language Class Initialized
INFO - 2018-07-21 20:42:24 --> Loader Class Initialized
INFO - 2018-07-21 20:42:24 --> Controller Class Initialized
INFO - 2018-07-21 20:42:24 --> Database Driver Class Initialized
INFO - 2018-07-21 20:42:24 --> Model Class Initialized
INFO - 2018-07-21 20:42:24 --> Helper loaded: url_helper
INFO - 2018-07-21 20:42:24 --> Model Class Initialized
ERROR - 2018-07-21 20:42:24 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 16
INFO - 2018-07-21 20:42:24 --> Final output sent to browser
DEBUG - 2018-07-21 20:42:24 --> Total execution time: 0.0512
ERROR - 2018-07-21 20:42:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:42:29 --> Config Class Initialized
INFO - 2018-07-21 20:42:29 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:42:29 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:42:29 --> Utf8 Class Initialized
INFO - 2018-07-21 20:42:29 --> URI Class Initialized
INFO - 2018-07-21 20:42:29 --> Router Class Initialized
INFO - 2018-07-21 20:42:29 --> Output Class Initialized
INFO - 2018-07-21 20:42:29 --> Security Class Initialized
DEBUG - 2018-07-21 20:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:42:29 --> Input Class Initialized
INFO - 2018-07-21 20:42:29 --> Language Class Initialized
INFO - 2018-07-21 20:42:29 --> Loader Class Initialized
INFO - 2018-07-21 20:42:29 --> Controller Class Initialized
INFO - 2018-07-21 20:42:29 --> Database Driver Class Initialized
INFO - 2018-07-21 20:42:29 --> Model Class Initialized
INFO - 2018-07-21 20:42:29 --> Helper loaded: url_helper
INFO - 2018-07-21 20:42:29 --> Model Class Initialized
INFO - 2018-07-21 20:42:29 --> Final output sent to browser
DEBUG - 2018-07-21 20:42:29 --> Total execution time: 0.0432
ERROR - 2018-07-21 20:45:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:45:06 --> Config Class Initialized
INFO - 2018-07-21 20:45:06 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:45:06 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:45:06 --> Utf8 Class Initialized
INFO - 2018-07-21 20:45:06 --> URI Class Initialized
INFO - 2018-07-21 20:45:06 --> Router Class Initialized
INFO - 2018-07-21 20:45:06 --> Output Class Initialized
INFO - 2018-07-21 20:45:06 --> Security Class Initialized
DEBUG - 2018-07-21 20:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:45:06 --> Input Class Initialized
INFO - 2018-07-21 20:45:06 --> Language Class Initialized
INFO - 2018-07-21 20:45:06 --> Loader Class Initialized
INFO - 2018-07-21 20:45:06 --> Controller Class Initialized
INFO - 2018-07-21 20:45:06 --> Database Driver Class Initialized
INFO - 2018-07-21 20:45:06 --> Model Class Initialized
INFO - 2018-07-21 20:45:06 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:45:06 --> Model Class Initialized
INFO - 2018-07-21 20:45:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:45:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 20:45:06 --> Final output sent to browser
DEBUG - 2018-07-21 20:45:06 --> Total execution time: 0.0598
ERROR - 2018-07-21 20:45:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:45:32 --> Config Class Initialized
INFO - 2018-07-21 20:45:32 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:45:32 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:45:32 --> Utf8 Class Initialized
INFO - 2018-07-21 20:45:32 --> URI Class Initialized
INFO - 2018-07-21 20:45:32 --> Router Class Initialized
INFO - 2018-07-21 20:45:32 --> Output Class Initialized
INFO - 2018-07-21 20:45:32 --> Security Class Initialized
DEBUG - 2018-07-21 20:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:45:32 --> Input Class Initialized
INFO - 2018-07-21 20:45:32 --> Language Class Initialized
INFO - 2018-07-21 20:45:32 --> Loader Class Initialized
INFO - 2018-07-21 20:45:32 --> Controller Class Initialized
INFO - 2018-07-21 20:45:32 --> Database Driver Class Initialized
INFO - 2018-07-21 20:45:32 --> Model Class Initialized
INFO - 2018-07-21 20:45:32 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:45:32 --> Model Class Initialized
INFO - 2018-07-21 20:45:32 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:45:32 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 20:45:32 --> Final output sent to browser
DEBUG - 2018-07-21 20:45:32 --> Total execution time: 0.1270
ERROR - 2018-07-21 20:46:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:46:52 --> Config Class Initialized
INFO - 2018-07-21 20:46:52 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:46:52 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:46:52 --> Utf8 Class Initialized
INFO - 2018-07-21 20:46:52 --> URI Class Initialized
INFO - 2018-07-21 20:46:52 --> Router Class Initialized
INFO - 2018-07-21 20:46:52 --> Output Class Initialized
INFO - 2018-07-21 20:46:52 --> Security Class Initialized
DEBUG - 2018-07-21 20:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:46:52 --> Input Class Initialized
INFO - 2018-07-21 20:46:52 --> Language Class Initialized
INFO - 2018-07-21 20:46:52 --> Loader Class Initialized
INFO - 2018-07-21 20:46:52 --> Controller Class Initialized
INFO - 2018-07-21 20:46:52 --> Database Driver Class Initialized
INFO - 2018-07-21 20:46:52 --> Model Class Initialized
INFO - 2018-07-21 20:46:52 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:46:52 --> Model Class Initialized
INFO - 2018-07-21 20:46:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:46:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 20:46:52 --> Final output sent to browser
DEBUG - 2018-07-21 20:46:52 --> Total execution time: 0.0564
ERROR - 2018-07-21 20:48:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:48:36 --> Config Class Initialized
INFO - 2018-07-21 20:48:36 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:48:36 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:48:36 --> Utf8 Class Initialized
INFO - 2018-07-21 20:48:36 --> URI Class Initialized
INFO - 2018-07-21 20:48:36 --> Router Class Initialized
INFO - 2018-07-21 20:48:36 --> Output Class Initialized
INFO - 2018-07-21 20:48:36 --> Security Class Initialized
DEBUG - 2018-07-21 20:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:48:36 --> Input Class Initialized
INFO - 2018-07-21 20:48:36 --> Language Class Initialized
INFO - 2018-07-21 20:48:36 --> Loader Class Initialized
INFO - 2018-07-21 20:48:36 --> Controller Class Initialized
INFO - 2018-07-21 20:48:36 --> Database Driver Class Initialized
INFO - 2018-07-21 20:48:36 --> Model Class Initialized
INFO - 2018-07-21 20:48:36 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:48:36 --> Model Class Initialized
ERROR - 2018-07-21 20:48:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\davidhood\application\controllers\Main.php 75
INFO - 2018-07-21 20:48:36 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:48:36 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 20:48:36 --> Final output sent to browser
DEBUG - 2018-07-21 20:48:36 --> Total execution time: 0.0477
ERROR - 2018-07-21 20:51:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:51:10 --> Config Class Initialized
INFO - 2018-07-21 20:51:10 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:51:10 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:51:10 --> Utf8 Class Initialized
INFO - 2018-07-21 20:51:10 --> URI Class Initialized
INFO - 2018-07-21 20:51:10 --> Router Class Initialized
INFO - 2018-07-21 20:51:10 --> Output Class Initialized
INFO - 2018-07-21 20:51:10 --> Security Class Initialized
DEBUG - 2018-07-21 20:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:51:10 --> Input Class Initialized
INFO - 2018-07-21 20:51:10 --> Language Class Initialized
INFO - 2018-07-21 20:51:10 --> Loader Class Initialized
INFO - 2018-07-21 20:51:10 --> Controller Class Initialized
INFO - 2018-07-21 20:51:10 --> Database Driver Class Initialized
INFO - 2018-07-21 20:51:10 --> Model Class Initialized
INFO - 2018-07-21 20:51:10 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:51:10 --> Model Class Initialized
ERROR - 2018-07-21 20:51:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\davidhood\application\controllers\Main.php 76
INFO - 2018-07-21 20:51:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:51:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 20:51:10 --> Final output sent to browser
DEBUG - 2018-07-21 20:51:10 --> Total execution time: 0.0544
ERROR - 2018-07-21 20:51:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:51:38 --> Config Class Initialized
INFO - 2018-07-21 20:51:38 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:51:38 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:51:38 --> Utf8 Class Initialized
INFO - 2018-07-21 20:51:38 --> URI Class Initialized
INFO - 2018-07-21 20:51:38 --> Router Class Initialized
INFO - 2018-07-21 20:51:38 --> Output Class Initialized
INFO - 2018-07-21 20:51:38 --> Security Class Initialized
DEBUG - 2018-07-21 20:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:51:38 --> Input Class Initialized
INFO - 2018-07-21 20:51:38 --> Language Class Initialized
INFO - 2018-07-21 20:51:38 --> Loader Class Initialized
INFO - 2018-07-21 20:51:38 --> Controller Class Initialized
INFO - 2018-07-21 20:51:38 --> Database Driver Class Initialized
INFO - 2018-07-21 20:51:38 --> Model Class Initialized
INFO - 2018-07-21 20:51:38 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:51:38 --> Model Class Initialized
INFO - 2018-07-21 20:51:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:51:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 20:51:38 --> Final output sent to browser
DEBUG - 2018-07-21 20:51:38 --> Total execution time: 0.0487
ERROR - 2018-07-21 20:51:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:51:57 --> Config Class Initialized
INFO - 2018-07-21 20:51:57 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:51:57 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:51:57 --> Utf8 Class Initialized
INFO - 2018-07-21 20:51:57 --> URI Class Initialized
INFO - 2018-07-21 20:51:57 --> Router Class Initialized
INFO - 2018-07-21 20:51:57 --> Output Class Initialized
INFO - 2018-07-21 20:51:57 --> Security Class Initialized
DEBUG - 2018-07-21 20:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:51:57 --> Input Class Initialized
INFO - 2018-07-21 20:51:57 --> Language Class Initialized
INFO - 2018-07-21 20:51:57 --> Loader Class Initialized
INFO - 2018-07-21 20:51:57 --> Controller Class Initialized
INFO - 2018-07-21 20:51:57 --> Database Driver Class Initialized
INFO - 2018-07-21 20:51:57 --> Model Class Initialized
INFO - 2018-07-21 20:51:57 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:51:57 --> Model Class Initialized
ERROR - 2018-07-21 20:51:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\davidhood\application\controllers\Main.php 73
ERROR - 2018-07-21 20:51:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\davidhood\application\controllers\Main.php 81
INFO - 2018-07-21 20:51:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:51:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 20:51:57 --> Final output sent to browser
DEBUG - 2018-07-21 20:51:57 --> Total execution time: 0.1087
ERROR - 2018-07-21 20:52:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:52:27 --> Config Class Initialized
INFO - 2018-07-21 20:52:27 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:52:27 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:52:27 --> Utf8 Class Initialized
INFO - 2018-07-21 20:52:27 --> URI Class Initialized
INFO - 2018-07-21 20:52:27 --> Router Class Initialized
INFO - 2018-07-21 20:52:27 --> Output Class Initialized
INFO - 2018-07-21 20:52:27 --> Security Class Initialized
DEBUG - 2018-07-21 20:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:52:27 --> Input Class Initialized
INFO - 2018-07-21 20:52:27 --> Language Class Initialized
INFO - 2018-07-21 20:52:27 --> Loader Class Initialized
INFO - 2018-07-21 20:52:27 --> Controller Class Initialized
INFO - 2018-07-21 20:52:27 --> Database Driver Class Initialized
INFO - 2018-07-21 20:52:27 --> Model Class Initialized
INFO - 2018-07-21 20:52:27 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:52:27 --> Model Class Initialized
ERROR - 2018-07-21 20:52:27 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\davidhood\application\controllers\Main.php 37
ERROR - 2018-07-21 20:52:27 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\davidhood\application\controllers\Main.php 38
ERROR - 2018-07-21 20:52:27 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\davidhood\application\controllers\Main.php 39
ERROR - 2018-07-21 20:52:27 --> Severity: Notice --> Undefined index: url C:\xampp\htdocs\davidhood\application\controllers\Main.php 40
ERROR - 2018-07-21 20:52:27 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\davidhood\application\controllers\Main.php 41
ERROR - 2018-07-21 20:52:27 --> Severity: Notice --> Undefined index: company_url C:\xampp\htdocs\davidhood\application\controllers\Main.php 42
ERROR - 2018-07-21 20:52:27 --> Severity: Notice --> Undefined index: lang C:\xampp\htdocs\davidhood\application\controllers\Main.php 47
ERROR - 2018-07-21 20:52:27 --> Severity: Notice --> Undefined index: limits C:\xampp\htdocs\davidhood\application\controllers\Main.php 48
INFO - 2018-07-21 20:52:27 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:52:27 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 20:52:27 --> Final output sent to browser
DEBUG - 2018-07-21 20:52:27 --> Total execution time: 0.0657
ERROR - 2018-07-21 20:52:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:52:29 --> Config Class Initialized
INFO - 2018-07-21 20:52:29 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:52:29 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:52:29 --> Utf8 Class Initialized
INFO - 2018-07-21 20:52:29 --> URI Class Initialized
INFO - 2018-07-21 20:52:29 --> Router Class Initialized
INFO - 2018-07-21 20:52:29 --> Output Class Initialized
INFO - 2018-07-21 20:52:29 --> Security Class Initialized
DEBUG - 2018-07-21 20:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:52:29 --> Input Class Initialized
INFO - 2018-07-21 20:52:29 --> Language Class Initialized
INFO - 2018-07-21 20:52:29 --> Loader Class Initialized
INFO - 2018-07-21 20:52:29 --> Controller Class Initialized
INFO - 2018-07-21 20:52:29 --> Database Driver Class Initialized
INFO - 2018-07-21 20:52:29 --> Model Class Initialized
INFO - 2018-07-21 20:52:29 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:52:29 --> Model Class Initialized
ERROR - 2018-07-21 20:52:29 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\davidhood\application\controllers\Main.php 37
ERROR - 2018-07-21 20:52:29 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\davidhood\application\controllers\Main.php 38
ERROR - 2018-07-21 20:52:29 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\davidhood\application\controllers\Main.php 39
ERROR - 2018-07-21 20:52:29 --> Severity: Notice --> Undefined index: url C:\xampp\htdocs\davidhood\application\controllers\Main.php 40
ERROR - 2018-07-21 20:52:29 --> Severity: Notice --> Undefined index: type C:\xampp\htdocs\davidhood\application\controllers\Main.php 41
ERROR - 2018-07-21 20:52:29 --> Severity: Notice --> Undefined index: company_url C:\xampp\htdocs\davidhood\application\controllers\Main.php 42
ERROR - 2018-07-21 20:52:29 --> Severity: Notice --> Undefined index: lang C:\xampp\htdocs\davidhood\application\controllers\Main.php 47
ERROR - 2018-07-21 20:52:29 --> Severity: Notice --> Undefined index: limits C:\xampp\htdocs\davidhood\application\controllers\Main.php 48
INFO - 2018-07-21 20:52:29 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:52:29 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 20:52:29 --> Final output sent to browser
DEBUG - 2018-07-21 20:52:29 --> Total execution time: 0.0650
ERROR - 2018-07-21 20:52:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:52:35 --> Config Class Initialized
INFO - 2018-07-21 20:52:35 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:52:35 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:52:35 --> Utf8 Class Initialized
INFO - 2018-07-21 20:52:35 --> URI Class Initialized
DEBUG - 2018-07-21 20:52:35 --> No URI present. Default controller set.
INFO - 2018-07-21 20:52:35 --> Router Class Initialized
INFO - 2018-07-21 20:52:35 --> Output Class Initialized
INFO - 2018-07-21 20:52:35 --> Security Class Initialized
DEBUG - 2018-07-21 20:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:52:35 --> Input Class Initialized
INFO - 2018-07-21 20:52:35 --> Language Class Initialized
INFO - 2018-07-21 20:52:35 --> Loader Class Initialized
INFO - 2018-07-21 20:52:35 --> Controller Class Initialized
INFO - 2018-07-21 20:52:35 --> Database Driver Class Initialized
INFO - 2018-07-21 20:52:35 --> Model Class Initialized
INFO - 2018-07-21 20:52:35 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:52:35 --> Model Class Initialized
INFO - 2018-07-21 20:52:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-21 20:52:35 --> Final output sent to browser
DEBUG - 2018-07-21 20:52:35 --> Total execution time: 0.0562
ERROR - 2018-07-21 20:52:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:52:36 --> Config Class Initialized
INFO - 2018-07-21 20:52:36 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:52:36 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:52:36 --> Utf8 Class Initialized
INFO - 2018-07-21 20:52:36 --> URI Class Initialized
DEBUG - 2018-07-21 20:52:36 --> No URI present. Default controller set.
INFO - 2018-07-21 20:52:36 --> Router Class Initialized
INFO - 2018-07-21 20:52:36 --> Output Class Initialized
INFO - 2018-07-21 20:52:36 --> Security Class Initialized
DEBUG - 2018-07-21 20:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:52:36 --> Input Class Initialized
INFO - 2018-07-21 20:52:36 --> Language Class Initialized
INFO - 2018-07-21 20:52:36 --> Loader Class Initialized
INFO - 2018-07-21 20:52:36 --> Controller Class Initialized
INFO - 2018-07-21 20:52:36 --> Database Driver Class Initialized
INFO - 2018-07-21 20:52:36 --> Model Class Initialized
INFO - 2018-07-21 20:52:36 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:52:36 --> Model Class Initialized
INFO - 2018-07-21 20:52:36 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-21 20:52:36 --> Final output sent to browser
DEBUG - 2018-07-21 20:52:36 --> Total execution time: 0.0433
ERROR - 2018-07-21 20:52:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:52:38 --> Config Class Initialized
INFO - 2018-07-21 20:52:38 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:52:38 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:52:38 --> Utf8 Class Initialized
INFO - 2018-07-21 20:52:38 --> URI Class Initialized
INFO - 2018-07-21 20:52:38 --> Router Class Initialized
INFO - 2018-07-21 20:52:38 --> Output Class Initialized
INFO - 2018-07-21 20:52:38 --> Security Class Initialized
DEBUG - 2018-07-21 20:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:52:38 --> Input Class Initialized
INFO - 2018-07-21 20:52:38 --> Language Class Initialized
INFO - 2018-07-21 20:52:38 --> Loader Class Initialized
INFO - 2018-07-21 20:52:38 --> Controller Class Initialized
INFO - 2018-07-21 20:52:38 --> Database Driver Class Initialized
INFO - 2018-07-21 20:52:38 --> Model Class Initialized
INFO - 2018-07-21 20:52:38 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:52:38 --> Model Class Initialized
ERROR - 2018-07-21 20:52:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:52:38 --> Config Class Initialized
INFO - 2018-07-21 20:52:38 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:52:38 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:52:38 --> Utf8 Class Initialized
INFO - 2018-07-21 20:52:38 --> URI Class Initialized
INFO - 2018-07-21 20:52:38 --> Router Class Initialized
INFO - 2018-07-21 20:52:38 --> Output Class Initialized
INFO - 2018-07-21 20:52:38 --> Security Class Initialized
DEBUG - 2018-07-21 20:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:52:38 --> Input Class Initialized
INFO - 2018-07-21 20:52:38 --> Language Class Initialized
INFO - 2018-07-21 20:52:38 --> Loader Class Initialized
INFO - 2018-07-21 20:52:38 --> Controller Class Initialized
INFO - 2018-07-21 20:52:38 --> Database Driver Class Initialized
INFO - 2018-07-21 20:52:38 --> Model Class Initialized
INFO - 2018-07-21 20:52:38 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:52:38 --> Model Class Initialized
INFO - 2018-07-21 20:52:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:52:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 20:52:38 --> Final output sent to browser
DEBUG - 2018-07-21 20:52:38 --> Total execution time: 0.0610
ERROR - 2018-07-21 20:52:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:52:39 --> Config Class Initialized
INFO - 2018-07-21 20:52:39 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:52:39 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:52:39 --> Utf8 Class Initialized
INFO - 2018-07-21 20:52:39 --> URI Class Initialized
INFO - 2018-07-21 20:52:39 --> Router Class Initialized
INFO - 2018-07-21 20:52:39 --> Output Class Initialized
INFO - 2018-07-21 20:52:39 --> Security Class Initialized
DEBUG - 2018-07-21 20:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:52:39 --> Input Class Initialized
INFO - 2018-07-21 20:52:39 --> Language Class Initialized
INFO - 2018-07-21 20:52:39 --> Loader Class Initialized
INFO - 2018-07-21 20:52:39 --> Controller Class Initialized
INFO - 2018-07-21 20:52:39 --> Database Driver Class Initialized
INFO - 2018-07-21 20:52:39 --> Model Class Initialized
INFO - 2018-07-21 20:52:39 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:52:39 --> Model Class Initialized
INFO - 2018-07-21 20:52:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:52:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 20:52:39 --> Final output sent to browser
DEBUG - 2018-07-21 20:52:39 --> Total execution time: 0.0546
ERROR - 2018-07-21 20:52:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:52:55 --> Config Class Initialized
INFO - 2018-07-21 20:52:55 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:52:55 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:52:55 --> Utf8 Class Initialized
INFO - 2018-07-21 20:52:55 --> URI Class Initialized
INFO - 2018-07-21 20:52:55 --> Router Class Initialized
INFO - 2018-07-21 20:52:55 --> Output Class Initialized
INFO - 2018-07-21 20:52:55 --> Security Class Initialized
DEBUG - 2018-07-21 20:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:52:55 --> Input Class Initialized
INFO - 2018-07-21 20:52:55 --> Language Class Initialized
INFO - 2018-07-21 20:52:55 --> Loader Class Initialized
INFO - 2018-07-21 20:52:55 --> Controller Class Initialized
INFO - 2018-07-21 20:52:55 --> Database Driver Class Initialized
INFO - 2018-07-21 20:52:55 --> Model Class Initialized
INFO - 2018-07-21 20:52:55 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:52:55 --> Model Class Initialized
INFO - 2018-07-21 20:52:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:52:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-21 20:52:55 --> Final output sent to browser
DEBUG - 2018-07-21 20:52:55 --> Total execution time: 0.1162
ERROR - 2018-07-21 20:53:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:53:13 --> Config Class Initialized
INFO - 2018-07-21 20:53:13 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:53:13 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:53:13 --> Utf8 Class Initialized
INFO - 2018-07-21 20:53:13 --> URI Class Initialized
INFO - 2018-07-21 20:53:13 --> Router Class Initialized
INFO - 2018-07-21 20:53:13 --> Output Class Initialized
INFO - 2018-07-21 20:53:13 --> Security Class Initialized
DEBUG - 2018-07-21 20:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:53:13 --> Input Class Initialized
INFO - 2018-07-21 20:53:13 --> Language Class Initialized
INFO - 2018-07-21 20:53:13 --> Loader Class Initialized
INFO - 2018-07-21 20:53:13 --> Controller Class Initialized
INFO - 2018-07-21 20:53:13 --> Database Driver Class Initialized
INFO - 2018-07-21 20:53:13 --> Model Class Initialized
INFO - 2018-07-21 20:53:13 --> Helper loaded: url_helper
DEBUG - 2018-07-21 20:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-21 20:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-21 20:53:13 --> Model Class Initialized
INFO - 2018-07-21 20:53:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-21 20:53:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-21 20:53:13 --> Final output sent to browser
DEBUG - 2018-07-21 20:53:13 --> Total execution time: 0.0472
ERROR - 2018-07-21 20:54:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:54:47 --> Config Class Initialized
INFO - 2018-07-21 20:54:47 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:54:47 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:54:47 --> Utf8 Class Initialized
INFO - 2018-07-21 20:54:47 --> URI Class Initialized
INFO - 2018-07-21 20:54:47 --> Router Class Initialized
INFO - 2018-07-21 20:54:47 --> Output Class Initialized
INFO - 2018-07-21 20:54:47 --> Security Class Initialized
DEBUG - 2018-07-21 20:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:54:47 --> Input Class Initialized
INFO - 2018-07-21 20:54:47 --> Language Class Initialized
INFO - 2018-07-21 20:54:47 --> Loader Class Initialized
INFO - 2018-07-21 20:54:47 --> Controller Class Initialized
INFO - 2018-07-21 20:54:47 --> Database Driver Class Initialized
INFO - 2018-07-21 20:54:47 --> Model Class Initialized
INFO - 2018-07-21 20:54:47 --> Helper loaded: url_helper
INFO - 2018-07-21 20:54:47 --> Model Class Initialized
INFO - 2018-07-21 20:54:47 --> Final output sent to browser
DEBUG - 2018-07-21 20:54:47 --> Total execution time: 0.0522
ERROR - 2018-07-21 20:54:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:54:53 --> Config Class Initialized
INFO - 2018-07-21 20:54:53 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:54:53 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:54:53 --> Utf8 Class Initialized
INFO - 2018-07-21 20:54:53 --> URI Class Initialized
INFO - 2018-07-21 20:54:54 --> Router Class Initialized
INFO - 2018-07-21 20:54:54 --> Output Class Initialized
INFO - 2018-07-21 20:54:54 --> Security Class Initialized
DEBUG - 2018-07-21 20:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:54:54 --> Input Class Initialized
INFO - 2018-07-21 20:54:54 --> Language Class Initialized
INFO - 2018-07-21 20:54:54 --> Loader Class Initialized
INFO - 2018-07-21 20:54:54 --> Controller Class Initialized
INFO - 2018-07-21 20:54:54 --> Database Driver Class Initialized
INFO - 2018-07-21 20:54:54 --> Model Class Initialized
INFO - 2018-07-21 20:54:54 --> Helper loaded: url_helper
INFO - 2018-07-21 20:54:54 --> Model Class Initialized
INFO - 2018-07-21 20:54:54 --> Final output sent to browser
DEBUG - 2018-07-21 20:54:54 --> Total execution time: 0.0455
ERROR - 2018-07-21 20:55:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 20:55:36 --> Config Class Initialized
INFO - 2018-07-21 20:55:36 --> Hooks Class Initialized
DEBUG - 2018-07-21 20:55:36 --> UTF-8 Support Enabled
INFO - 2018-07-21 20:55:36 --> Utf8 Class Initialized
INFO - 2018-07-21 20:55:36 --> URI Class Initialized
INFO - 2018-07-21 20:55:36 --> Router Class Initialized
INFO - 2018-07-21 20:55:36 --> Output Class Initialized
INFO - 2018-07-21 20:55:36 --> Security Class Initialized
DEBUG - 2018-07-21 20:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 20:55:36 --> Input Class Initialized
INFO - 2018-07-21 20:55:36 --> Language Class Initialized
INFO - 2018-07-21 20:55:36 --> Loader Class Initialized
INFO - 2018-07-21 20:55:36 --> Controller Class Initialized
INFO - 2018-07-21 20:55:36 --> Database Driver Class Initialized
INFO - 2018-07-21 20:55:36 --> Model Class Initialized
INFO - 2018-07-21 20:55:36 --> Helper loaded: url_helper
INFO - 2018-07-21 20:55:36 --> Model Class Initialized
INFO - 2018-07-21 20:55:36 --> Final output sent to browser
DEBUG - 2018-07-21 20:55:36 --> Total execution time: 0.0386
ERROR - 2018-07-21 21:06:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:06:01 --> Config Class Initialized
INFO - 2018-07-21 21:06:01 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:06:01 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:06:01 --> Utf8 Class Initialized
INFO - 2018-07-21 21:06:01 --> URI Class Initialized
INFO - 2018-07-21 21:06:01 --> Router Class Initialized
INFO - 2018-07-21 21:06:01 --> Output Class Initialized
INFO - 2018-07-21 21:06:01 --> Security Class Initialized
DEBUG - 2018-07-21 21:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:06:01 --> Input Class Initialized
INFO - 2018-07-21 21:06:01 --> Language Class Initialized
INFO - 2018-07-21 21:06:01 --> Loader Class Initialized
INFO - 2018-07-21 21:06:01 --> Controller Class Initialized
INFO - 2018-07-21 21:06:01 --> Database Driver Class Initialized
INFO - 2018-07-21 21:06:01 --> Model Class Initialized
INFO - 2018-07-21 21:06:01 --> Helper loaded: url_helper
INFO - 2018-07-21 21:06:01 --> Model Class Initialized
ERROR - 2018-07-21 21:06:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 56
ERROR - 2018-07-21 21:06:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 55
ERROR - 2018-07-21 21:06:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 56
INFO - 2018-07-21 21:06:01 --> Final output sent to browser
DEBUG - 2018-07-21 21:06:01 --> Total execution time: 0.0564
ERROR - 2018-07-21 21:06:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:06:55 --> Config Class Initialized
INFO - 2018-07-21 21:06:55 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:06:55 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:06:55 --> Utf8 Class Initialized
INFO - 2018-07-21 21:06:55 --> URI Class Initialized
INFO - 2018-07-21 21:06:55 --> Router Class Initialized
INFO - 2018-07-21 21:06:55 --> Output Class Initialized
INFO - 2018-07-21 21:06:55 --> Security Class Initialized
DEBUG - 2018-07-21 21:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:06:55 --> Input Class Initialized
INFO - 2018-07-21 21:06:55 --> Language Class Initialized
INFO - 2018-07-21 21:06:55 --> Loader Class Initialized
INFO - 2018-07-21 21:06:55 --> Controller Class Initialized
INFO - 2018-07-21 21:06:55 --> Database Driver Class Initialized
INFO - 2018-07-21 21:06:55 --> Model Class Initialized
INFO - 2018-07-21 21:06:55 --> Helper loaded: url_helper
INFO - 2018-07-21 21:06:55 --> Model Class Initialized
ERROR - 2018-07-21 21:06:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 55
ERROR - 2018-07-21 21:06:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 56
INFO - 2018-07-21 21:06:55 --> Final output sent to browser
DEBUG - 2018-07-21 21:06:55 --> Total execution time: 0.0586
ERROR - 2018-07-21 21:06:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:06:58 --> Config Class Initialized
INFO - 2018-07-21 21:06:58 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:06:58 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:06:58 --> Utf8 Class Initialized
INFO - 2018-07-21 21:06:58 --> URI Class Initialized
INFO - 2018-07-21 21:06:58 --> Router Class Initialized
INFO - 2018-07-21 21:06:58 --> Output Class Initialized
INFO - 2018-07-21 21:06:58 --> Security Class Initialized
DEBUG - 2018-07-21 21:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:06:58 --> Input Class Initialized
INFO - 2018-07-21 21:06:58 --> Language Class Initialized
INFO - 2018-07-21 21:06:58 --> Loader Class Initialized
INFO - 2018-07-21 21:06:58 --> Controller Class Initialized
INFO - 2018-07-21 21:06:58 --> Database Driver Class Initialized
INFO - 2018-07-21 21:06:58 --> Model Class Initialized
INFO - 2018-07-21 21:06:58 --> Helper loaded: url_helper
INFO - 2018-07-21 21:06:58 --> Model Class Initialized
ERROR - 2018-07-21 21:06:58 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 56
ERROR - 2018-07-21 21:06:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 55
ERROR - 2018-07-21 21:06:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 56
INFO - 2018-07-21 21:06:58 --> Final output sent to browser
DEBUG - 2018-07-21 21:06:58 --> Total execution time: 0.0623
ERROR - 2018-07-21 21:08:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:08:29 --> Config Class Initialized
INFO - 2018-07-21 21:08:29 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:08:29 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:08:29 --> Utf8 Class Initialized
INFO - 2018-07-21 21:08:29 --> URI Class Initialized
INFO - 2018-07-21 21:08:29 --> Router Class Initialized
INFO - 2018-07-21 21:08:29 --> Output Class Initialized
INFO - 2018-07-21 21:08:29 --> Security Class Initialized
DEBUG - 2018-07-21 21:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:08:29 --> Input Class Initialized
INFO - 2018-07-21 21:08:29 --> Language Class Initialized
INFO - 2018-07-21 21:08:29 --> Loader Class Initialized
INFO - 2018-07-21 21:08:29 --> Controller Class Initialized
INFO - 2018-07-21 21:08:29 --> Database Driver Class Initialized
INFO - 2018-07-21 21:08:29 --> Model Class Initialized
INFO - 2018-07-21 21:08:29 --> Helper loaded: url_helper
INFO - 2018-07-21 21:08:29 --> Model Class Initialized
ERROR - 2018-07-21 21:08:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 55
ERROR - 2018-07-21 21:08:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 55
ERROR - 2018-07-21 21:08:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 56
INFO - 2018-07-21 21:08:29 --> Final output sent to browser
DEBUG - 2018-07-21 21:08:29 --> Total execution time: 0.0523
ERROR - 2018-07-21 21:08:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:08:57 --> Config Class Initialized
INFO - 2018-07-21 21:08:57 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:08:57 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:08:57 --> Utf8 Class Initialized
INFO - 2018-07-21 21:08:57 --> URI Class Initialized
INFO - 2018-07-21 21:08:57 --> Router Class Initialized
INFO - 2018-07-21 21:08:57 --> Output Class Initialized
INFO - 2018-07-21 21:08:57 --> Security Class Initialized
DEBUG - 2018-07-21 21:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:08:57 --> Input Class Initialized
INFO - 2018-07-21 21:08:57 --> Language Class Initialized
INFO - 2018-07-21 21:08:57 --> Loader Class Initialized
INFO - 2018-07-21 21:08:57 --> Controller Class Initialized
INFO - 2018-07-21 21:08:57 --> Database Driver Class Initialized
INFO - 2018-07-21 21:08:57 --> Model Class Initialized
INFO - 2018-07-21 21:08:57 --> Helper loaded: url_helper
INFO - 2018-07-21 21:08:57 --> Model Class Initialized
ERROR - 2018-07-21 21:08:57 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 55
ERROR - 2018-07-21 21:08:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 55
ERROR - 2018-07-21 21:08:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 56
INFO - 2018-07-21 21:08:57 --> Final output sent to browser
DEBUG - 2018-07-21 21:08:58 --> Total execution time: 0.0474
ERROR - 2018-07-21 21:09:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:09:18 --> Config Class Initialized
INFO - 2018-07-21 21:09:18 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:09:18 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:09:18 --> Utf8 Class Initialized
INFO - 2018-07-21 21:09:18 --> URI Class Initialized
INFO - 2018-07-21 21:09:18 --> Router Class Initialized
INFO - 2018-07-21 21:09:18 --> Output Class Initialized
INFO - 2018-07-21 21:09:18 --> Security Class Initialized
DEBUG - 2018-07-21 21:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:09:18 --> Input Class Initialized
INFO - 2018-07-21 21:09:18 --> Language Class Initialized
INFO - 2018-07-21 21:09:18 --> Loader Class Initialized
INFO - 2018-07-21 21:09:18 --> Controller Class Initialized
INFO - 2018-07-21 21:09:19 --> Database Driver Class Initialized
INFO - 2018-07-21 21:09:19 --> Model Class Initialized
INFO - 2018-07-21 21:09:19 --> Helper loaded: url_helper
INFO - 2018-07-21 21:09:19 --> Model Class Initialized
ERROR - 2018-07-21 21:09:19 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 55
ERROR - 2018-07-21 21:09:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 56
INFO - 2018-07-21 21:09:19 --> Final output sent to browser
DEBUG - 2018-07-21 21:09:19 --> Total execution time: 0.0637
ERROR - 2018-07-21 21:15:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:15:00 --> Config Class Initialized
INFO - 2018-07-21 21:15:00 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:15:00 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:15:00 --> Utf8 Class Initialized
INFO - 2018-07-21 21:15:00 --> URI Class Initialized
INFO - 2018-07-21 21:15:00 --> Router Class Initialized
INFO - 2018-07-21 21:15:00 --> Output Class Initialized
INFO - 2018-07-21 21:15:00 --> Security Class Initialized
DEBUG - 2018-07-21 21:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:15:00 --> Input Class Initialized
INFO - 2018-07-21 21:15:00 --> Language Class Initialized
INFO - 2018-07-21 21:15:00 --> Loader Class Initialized
INFO - 2018-07-21 21:15:00 --> Controller Class Initialized
INFO - 2018-07-21 21:15:00 --> Database Driver Class Initialized
INFO - 2018-07-21 21:15:00 --> Model Class Initialized
INFO - 2018-07-21 21:15:00 --> Helper loaded: url_helper
INFO - 2018-07-21 21:15:00 --> Model Class Initialized
INFO - 2018-07-21 21:15:00 --> Final output sent to browser
DEBUG - 2018-07-21 21:15:00 --> Total execution time: 0.0427
ERROR - 2018-07-21 21:15:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:15:12 --> Config Class Initialized
INFO - 2018-07-21 21:15:12 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:15:12 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:15:12 --> Utf8 Class Initialized
INFO - 2018-07-21 21:15:12 --> URI Class Initialized
INFO - 2018-07-21 21:15:12 --> Router Class Initialized
INFO - 2018-07-21 21:15:12 --> Output Class Initialized
INFO - 2018-07-21 21:15:12 --> Security Class Initialized
DEBUG - 2018-07-21 21:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:15:12 --> Input Class Initialized
INFO - 2018-07-21 21:15:12 --> Language Class Initialized
INFO - 2018-07-21 21:15:12 --> Loader Class Initialized
INFO - 2018-07-21 21:15:12 --> Controller Class Initialized
INFO - 2018-07-21 21:15:12 --> Database Driver Class Initialized
INFO - 2018-07-21 21:15:12 --> Model Class Initialized
INFO - 2018-07-21 21:15:12 --> Helper loaded: url_helper
INFO - 2018-07-21 21:15:12 --> Model Class Initialized
INFO - 2018-07-21 21:15:12 --> Final output sent to browser
DEBUG - 2018-07-21 21:15:12 --> Total execution time: 0.0462
ERROR - 2018-07-21 21:15:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:15:13 --> Config Class Initialized
INFO - 2018-07-21 21:15:13 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:15:13 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:15:13 --> Utf8 Class Initialized
INFO - 2018-07-21 21:15:13 --> URI Class Initialized
INFO - 2018-07-21 21:15:13 --> Router Class Initialized
INFO - 2018-07-21 21:15:13 --> Output Class Initialized
INFO - 2018-07-21 21:15:13 --> Security Class Initialized
DEBUG - 2018-07-21 21:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:15:13 --> Input Class Initialized
INFO - 2018-07-21 21:15:13 --> Language Class Initialized
INFO - 2018-07-21 21:15:13 --> Loader Class Initialized
INFO - 2018-07-21 21:15:13 --> Controller Class Initialized
INFO - 2018-07-21 21:15:13 --> Database Driver Class Initialized
INFO - 2018-07-21 21:15:13 --> Model Class Initialized
INFO - 2018-07-21 21:15:13 --> Helper loaded: url_helper
INFO - 2018-07-21 21:15:13 --> Model Class Initialized
INFO - 2018-07-21 21:15:13 --> Final output sent to browser
DEBUG - 2018-07-21 21:15:13 --> Total execution time: 0.0522
ERROR - 2018-07-21 21:15:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:15:14 --> Config Class Initialized
INFO - 2018-07-21 21:15:14 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:15:14 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:15:14 --> Utf8 Class Initialized
INFO - 2018-07-21 21:15:14 --> URI Class Initialized
INFO - 2018-07-21 21:15:14 --> Router Class Initialized
INFO - 2018-07-21 21:15:14 --> Output Class Initialized
INFO - 2018-07-21 21:15:14 --> Security Class Initialized
DEBUG - 2018-07-21 21:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:15:14 --> Input Class Initialized
INFO - 2018-07-21 21:15:14 --> Language Class Initialized
INFO - 2018-07-21 21:15:14 --> Loader Class Initialized
INFO - 2018-07-21 21:15:14 --> Controller Class Initialized
INFO - 2018-07-21 21:15:14 --> Database Driver Class Initialized
INFO - 2018-07-21 21:15:14 --> Model Class Initialized
INFO - 2018-07-21 21:15:14 --> Helper loaded: url_helper
INFO - 2018-07-21 21:15:14 --> Model Class Initialized
INFO - 2018-07-21 21:15:14 --> Final output sent to browser
DEBUG - 2018-07-21 21:15:14 --> Total execution time: 0.0444
ERROR - 2018-07-21 21:15:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:15:16 --> Config Class Initialized
INFO - 2018-07-21 21:15:16 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:15:16 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:15:16 --> Utf8 Class Initialized
INFO - 2018-07-21 21:15:16 --> URI Class Initialized
INFO - 2018-07-21 21:15:16 --> Router Class Initialized
INFO - 2018-07-21 21:15:16 --> Output Class Initialized
INFO - 2018-07-21 21:15:16 --> Security Class Initialized
DEBUG - 2018-07-21 21:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:15:16 --> Input Class Initialized
INFO - 2018-07-21 21:15:16 --> Language Class Initialized
INFO - 2018-07-21 21:15:16 --> Loader Class Initialized
INFO - 2018-07-21 21:15:16 --> Controller Class Initialized
INFO - 2018-07-21 21:15:16 --> Database Driver Class Initialized
INFO - 2018-07-21 21:15:16 --> Model Class Initialized
INFO - 2018-07-21 21:15:16 --> Helper loaded: url_helper
INFO - 2018-07-21 21:15:16 --> Model Class Initialized
INFO - 2018-07-21 21:15:16 --> Final output sent to browser
DEBUG - 2018-07-21 21:15:16 --> Total execution time: 0.0488
ERROR - 2018-07-21 21:15:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:15:19 --> Config Class Initialized
INFO - 2018-07-21 21:15:19 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:15:19 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:15:19 --> Utf8 Class Initialized
INFO - 2018-07-21 21:15:19 --> URI Class Initialized
INFO - 2018-07-21 21:15:19 --> Router Class Initialized
INFO - 2018-07-21 21:15:19 --> Output Class Initialized
INFO - 2018-07-21 21:15:19 --> Security Class Initialized
DEBUG - 2018-07-21 21:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:15:19 --> Input Class Initialized
INFO - 2018-07-21 21:15:19 --> Language Class Initialized
INFO - 2018-07-21 21:15:19 --> Loader Class Initialized
INFO - 2018-07-21 21:15:19 --> Controller Class Initialized
INFO - 2018-07-21 21:15:19 --> Database Driver Class Initialized
INFO - 2018-07-21 21:15:19 --> Model Class Initialized
INFO - 2018-07-21 21:15:19 --> Helper loaded: url_helper
INFO - 2018-07-21 21:15:19 --> Model Class Initialized
INFO - 2018-07-21 21:15:19 --> Final output sent to browser
DEBUG - 2018-07-21 21:15:19 --> Total execution time: 0.0454
ERROR - 2018-07-21 21:15:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:15:21 --> Config Class Initialized
INFO - 2018-07-21 21:15:21 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:15:21 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:15:21 --> Utf8 Class Initialized
INFO - 2018-07-21 21:15:21 --> URI Class Initialized
INFO - 2018-07-21 21:15:21 --> Router Class Initialized
INFO - 2018-07-21 21:15:21 --> Output Class Initialized
INFO - 2018-07-21 21:15:21 --> Security Class Initialized
DEBUG - 2018-07-21 21:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:15:21 --> Input Class Initialized
INFO - 2018-07-21 21:15:21 --> Language Class Initialized
INFO - 2018-07-21 21:15:21 --> Loader Class Initialized
INFO - 2018-07-21 21:15:21 --> Controller Class Initialized
INFO - 2018-07-21 21:15:21 --> Database Driver Class Initialized
INFO - 2018-07-21 21:15:21 --> Model Class Initialized
INFO - 2018-07-21 21:15:21 --> Helper loaded: url_helper
INFO - 2018-07-21 21:15:21 --> Model Class Initialized
INFO - 2018-07-21 21:15:21 --> Final output sent to browser
DEBUG - 2018-07-21 21:15:21 --> Total execution time: 0.0457
ERROR - 2018-07-21 21:15:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:15:22 --> Config Class Initialized
INFO - 2018-07-21 21:15:22 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:15:22 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:15:22 --> Utf8 Class Initialized
INFO - 2018-07-21 21:15:22 --> URI Class Initialized
INFO - 2018-07-21 21:15:22 --> Router Class Initialized
INFO - 2018-07-21 21:15:22 --> Output Class Initialized
INFO - 2018-07-21 21:15:22 --> Security Class Initialized
DEBUG - 2018-07-21 21:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:15:22 --> Input Class Initialized
INFO - 2018-07-21 21:15:22 --> Language Class Initialized
INFO - 2018-07-21 21:15:22 --> Loader Class Initialized
INFO - 2018-07-21 21:15:22 --> Controller Class Initialized
INFO - 2018-07-21 21:15:22 --> Database Driver Class Initialized
INFO - 2018-07-21 21:15:22 --> Model Class Initialized
INFO - 2018-07-21 21:15:22 --> Helper loaded: url_helper
INFO - 2018-07-21 21:15:22 --> Model Class Initialized
INFO - 2018-07-21 21:15:22 --> Final output sent to browser
DEBUG - 2018-07-21 21:15:22 --> Total execution time: 0.0493
ERROR - 2018-07-21 21:15:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:15:29 --> Config Class Initialized
INFO - 2018-07-21 21:15:29 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:15:29 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:15:29 --> Utf8 Class Initialized
INFO - 2018-07-21 21:15:29 --> URI Class Initialized
INFO - 2018-07-21 21:15:29 --> Router Class Initialized
INFO - 2018-07-21 21:15:29 --> Output Class Initialized
INFO - 2018-07-21 21:15:29 --> Security Class Initialized
DEBUG - 2018-07-21 21:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:15:29 --> Input Class Initialized
INFO - 2018-07-21 21:15:29 --> Language Class Initialized
INFO - 2018-07-21 21:15:29 --> Loader Class Initialized
INFO - 2018-07-21 21:15:29 --> Controller Class Initialized
INFO - 2018-07-21 21:15:29 --> Database Driver Class Initialized
INFO - 2018-07-21 21:15:29 --> Model Class Initialized
INFO - 2018-07-21 21:15:29 --> Helper loaded: url_helper
INFO - 2018-07-21 21:15:29 --> Model Class Initialized
INFO - 2018-07-21 21:15:29 --> Final output sent to browser
DEBUG - 2018-07-21 21:15:29 --> Total execution time: 0.0477
ERROR - 2018-07-21 21:15:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:15:31 --> Config Class Initialized
INFO - 2018-07-21 21:15:31 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:15:31 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:15:31 --> Utf8 Class Initialized
INFO - 2018-07-21 21:15:31 --> URI Class Initialized
INFO - 2018-07-21 21:15:31 --> Router Class Initialized
INFO - 2018-07-21 21:15:31 --> Output Class Initialized
INFO - 2018-07-21 21:15:31 --> Security Class Initialized
DEBUG - 2018-07-21 21:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:15:31 --> Input Class Initialized
INFO - 2018-07-21 21:15:31 --> Language Class Initialized
INFO - 2018-07-21 21:15:31 --> Loader Class Initialized
INFO - 2018-07-21 21:15:31 --> Controller Class Initialized
INFO - 2018-07-21 21:15:31 --> Database Driver Class Initialized
INFO - 2018-07-21 21:15:31 --> Model Class Initialized
INFO - 2018-07-21 21:15:31 --> Helper loaded: url_helper
INFO - 2018-07-21 21:15:31 --> Model Class Initialized
INFO - 2018-07-21 21:15:31 --> Final output sent to browser
DEBUG - 2018-07-21 21:15:31 --> Total execution time: 0.0461
ERROR - 2018-07-21 21:15:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:15:33 --> Config Class Initialized
INFO - 2018-07-21 21:15:33 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:15:33 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:15:33 --> Utf8 Class Initialized
INFO - 2018-07-21 21:15:33 --> URI Class Initialized
INFO - 2018-07-21 21:15:33 --> Router Class Initialized
INFO - 2018-07-21 21:15:33 --> Output Class Initialized
INFO - 2018-07-21 21:15:33 --> Security Class Initialized
DEBUG - 2018-07-21 21:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:15:33 --> Input Class Initialized
INFO - 2018-07-21 21:15:33 --> Language Class Initialized
INFO - 2018-07-21 21:15:33 --> Loader Class Initialized
INFO - 2018-07-21 21:15:33 --> Controller Class Initialized
INFO - 2018-07-21 21:15:33 --> Database Driver Class Initialized
INFO - 2018-07-21 21:15:33 --> Model Class Initialized
INFO - 2018-07-21 21:15:33 --> Helper loaded: url_helper
INFO - 2018-07-21 21:15:33 --> Model Class Initialized
INFO - 2018-07-21 21:15:33 --> Final output sent to browser
DEBUG - 2018-07-21 21:15:33 --> Total execution time: 0.0462
ERROR - 2018-07-21 21:15:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:15:34 --> Config Class Initialized
INFO - 2018-07-21 21:15:34 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:15:34 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:15:34 --> Utf8 Class Initialized
INFO - 2018-07-21 21:15:34 --> URI Class Initialized
INFO - 2018-07-21 21:15:34 --> Router Class Initialized
INFO - 2018-07-21 21:15:34 --> Output Class Initialized
INFO - 2018-07-21 21:15:34 --> Security Class Initialized
DEBUG - 2018-07-21 21:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:15:34 --> Input Class Initialized
INFO - 2018-07-21 21:15:34 --> Language Class Initialized
INFO - 2018-07-21 21:15:34 --> Loader Class Initialized
INFO - 2018-07-21 21:15:34 --> Controller Class Initialized
INFO - 2018-07-21 21:15:34 --> Database Driver Class Initialized
INFO - 2018-07-21 21:15:34 --> Model Class Initialized
INFO - 2018-07-21 21:15:34 --> Helper loaded: url_helper
INFO - 2018-07-21 21:15:34 --> Model Class Initialized
INFO - 2018-07-21 21:15:34 --> Final output sent to browser
DEBUG - 2018-07-21 21:15:34 --> Total execution time: 0.0473
ERROR - 2018-07-21 21:16:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:16:04 --> Config Class Initialized
INFO - 2018-07-21 21:16:04 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:16:04 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:16:04 --> Utf8 Class Initialized
INFO - 2018-07-21 21:16:04 --> URI Class Initialized
INFO - 2018-07-21 21:16:04 --> Router Class Initialized
INFO - 2018-07-21 21:16:04 --> Output Class Initialized
INFO - 2018-07-21 21:16:04 --> Security Class Initialized
DEBUG - 2018-07-21 21:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:16:04 --> Input Class Initialized
INFO - 2018-07-21 21:16:04 --> Language Class Initialized
INFO - 2018-07-21 21:16:04 --> Loader Class Initialized
INFO - 2018-07-21 21:16:04 --> Controller Class Initialized
INFO - 2018-07-21 21:16:04 --> Database Driver Class Initialized
INFO - 2018-07-21 21:16:04 --> Model Class Initialized
INFO - 2018-07-21 21:16:04 --> Helper loaded: url_helper
INFO - 2018-07-21 21:16:04 --> Model Class Initialized
INFO - 2018-07-21 21:16:04 --> Final output sent to browser
DEBUG - 2018-07-21 21:16:04 --> Total execution time: 0.0450
ERROR - 2018-07-21 21:16:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:16:07 --> Config Class Initialized
INFO - 2018-07-21 21:16:07 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:16:07 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:16:07 --> Utf8 Class Initialized
INFO - 2018-07-21 21:16:07 --> URI Class Initialized
INFO - 2018-07-21 21:16:07 --> Router Class Initialized
INFO - 2018-07-21 21:16:07 --> Output Class Initialized
INFO - 2018-07-21 21:16:07 --> Security Class Initialized
DEBUG - 2018-07-21 21:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:16:07 --> Input Class Initialized
INFO - 2018-07-21 21:16:07 --> Language Class Initialized
INFO - 2018-07-21 21:16:07 --> Loader Class Initialized
INFO - 2018-07-21 21:16:07 --> Controller Class Initialized
INFO - 2018-07-21 21:16:07 --> Database Driver Class Initialized
INFO - 2018-07-21 21:16:07 --> Model Class Initialized
INFO - 2018-07-21 21:16:07 --> Helper loaded: url_helper
INFO - 2018-07-21 21:16:07 --> Model Class Initialized
INFO - 2018-07-21 21:16:07 --> Final output sent to browser
DEBUG - 2018-07-21 21:16:07 --> Total execution time: 0.0566
ERROR - 2018-07-21 21:16:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:16:08 --> Config Class Initialized
INFO - 2018-07-21 21:16:08 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:16:08 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:16:08 --> Utf8 Class Initialized
INFO - 2018-07-21 21:16:08 --> URI Class Initialized
INFO - 2018-07-21 21:16:08 --> Router Class Initialized
INFO - 2018-07-21 21:16:08 --> Output Class Initialized
INFO - 2018-07-21 21:16:08 --> Security Class Initialized
DEBUG - 2018-07-21 21:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:16:08 --> Input Class Initialized
INFO - 2018-07-21 21:16:08 --> Language Class Initialized
INFO - 2018-07-21 21:16:08 --> Loader Class Initialized
INFO - 2018-07-21 21:16:08 --> Controller Class Initialized
INFO - 2018-07-21 21:16:08 --> Database Driver Class Initialized
INFO - 2018-07-21 21:16:08 --> Model Class Initialized
INFO - 2018-07-21 21:16:08 --> Helper loaded: url_helper
INFO - 2018-07-21 21:16:08 --> Model Class Initialized
INFO - 2018-07-21 21:16:08 --> Final output sent to browser
DEBUG - 2018-07-21 21:16:08 --> Total execution time: 0.0594
ERROR - 2018-07-21 21:16:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:16:10 --> Config Class Initialized
INFO - 2018-07-21 21:16:10 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:16:10 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:16:10 --> Utf8 Class Initialized
INFO - 2018-07-21 21:16:10 --> URI Class Initialized
INFO - 2018-07-21 21:16:10 --> Router Class Initialized
INFO - 2018-07-21 21:16:10 --> Output Class Initialized
INFO - 2018-07-21 21:16:10 --> Security Class Initialized
DEBUG - 2018-07-21 21:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:16:10 --> Input Class Initialized
INFO - 2018-07-21 21:16:10 --> Language Class Initialized
INFO - 2018-07-21 21:16:10 --> Loader Class Initialized
INFO - 2018-07-21 21:16:10 --> Controller Class Initialized
INFO - 2018-07-21 21:16:10 --> Database Driver Class Initialized
INFO - 2018-07-21 21:16:10 --> Model Class Initialized
INFO - 2018-07-21 21:16:10 --> Helper loaded: url_helper
INFO - 2018-07-21 21:16:10 --> Model Class Initialized
INFO - 2018-07-21 21:16:10 --> Final output sent to browser
DEBUG - 2018-07-21 21:16:10 --> Total execution time: 0.0454
ERROR - 2018-07-21 21:16:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:16:11 --> Config Class Initialized
INFO - 2018-07-21 21:16:11 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:16:11 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:16:11 --> Utf8 Class Initialized
INFO - 2018-07-21 21:16:11 --> URI Class Initialized
INFO - 2018-07-21 21:16:11 --> Router Class Initialized
INFO - 2018-07-21 21:16:11 --> Output Class Initialized
INFO - 2018-07-21 21:16:11 --> Security Class Initialized
DEBUG - 2018-07-21 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:16:11 --> Input Class Initialized
INFO - 2018-07-21 21:16:11 --> Language Class Initialized
INFO - 2018-07-21 21:16:11 --> Loader Class Initialized
INFO - 2018-07-21 21:16:11 --> Controller Class Initialized
INFO - 2018-07-21 21:16:11 --> Database Driver Class Initialized
INFO - 2018-07-21 21:16:11 --> Model Class Initialized
INFO - 2018-07-21 21:16:11 --> Helper loaded: url_helper
INFO - 2018-07-21 21:16:11 --> Model Class Initialized
INFO - 2018-07-21 21:16:11 --> Final output sent to browser
DEBUG - 2018-07-21 21:16:11 --> Total execution time: 0.0478
ERROR - 2018-07-21 21:16:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:16:12 --> Config Class Initialized
INFO - 2018-07-21 21:16:12 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:16:12 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:16:12 --> Utf8 Class Initialized
INFO - 2018-07-21 21:16:12 --> URI Class Initialized
INFO - 2018-07-21 21:16:12 --> Router Class Initialized
INFO - 2018-07-21 21:16:12 --> Output Class Initialized
INFO - 2018-07-21 21:16:12 --> Security Class Initialized
DEBUG - 2018-07-21 21:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:16:12 --> Input Class Initialized
INFO - 2018-07-21 21:16:12 --> Language Class Initialized
INFO - 2018-07-21 21:16:12 --> Loader Class Initialized
INFO - 2018-07-21 21:16:12 --> Controller Class Initialized
INFO - 2018-07-21 21:16:12 --> Database Driver Class Initialized
INFO - 2018-07-21 21:16:12 --> Model Class Initialized
INFO - 2018-07-21 21:16:12 --> Helper loaded: url_helper
INFO - 2018-07-21 21:16:12 --> Model Class Initialized
INFO - 2018-07-21 21:16:12 --> Final output sent to browser
DEBUG - 2018-07-21 21:16:12 --> Total execution time: 0.0454
ERROR - 2018-07-21 21:16:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:16:13 --> Config Class Initialized
INFO - 2018-07-21 21:16:13 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:16:13 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:16:13 --> Utf8 Class Initialized
INFO - 2018-07-21 21:16:13 --> URI Class Initialized
INFO - 2018-07-21 21:16:13 --> Router Class Initialized
INFO - 2018-07-21 21:16:13 --> Output Class Initialized
INFO - 2018-07-21 21:16:13 --> Security Class Initialized
DEBUG - 2018-07-21 21:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:16:13 --> Input Class Initialized
INFO - 2018-07-21 21:16:13 --> Language Class Initialized
INFO - 2018-07-21 21:16:13 --> Loader Class Initialized
INFO - 2018-07-21 21:16:13 --> Controller Class Initialized
INFO - 2018-07-21 21:16:13 --> Database Driver Class Initialized
INFO - 2018-07-21 21:16:13 --> Model Class Initialized
INFO - 2018-07-21 21:16:13 --> Helper loaded: url_helper
INFO - 2018-07-21 21:16:13 --> Model Class Initialized
INFO - 2018-07-21 21:16:13 --> Final output sent to browser
DEBUG - 2018-07-21 21:16:13 --> Total execution time: 0.0525
ERROR - 2018-07-21 21:16:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:16:13 --> Config Class Initialized
INFO - 2018-07-21 21:16:13 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:16:13 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:16:13 --> Utf8 Class Initialized
INFO - 2018-07-21 21:16:13 --> URI Class Initialized
INFO - 2018-07-21 21:16:13 --> Router Class Initialized
INFO - 2018-07-21 21:16:13 --> Output Class Initialized
INFO - 2018-07-21 21:16:13 --> Security Class Initialized
DEBUG - 2018-07-21 21:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:16:13 --> Input Class Initialized
INFO - 2018-07-21 21:16:13 --> Language Class Initialized
INFO - 2018-07-21 21:16:13 --> Loader Class Initialized
INFO - 2018-07-21 21:16:13 --> Controller Class Initialized
INFO - 2018-07-21 21:16:13 --> Database Driver Class Initialized
INFO - 2018-07-21 21:16:13 --> Model Class Initialized
INFO - 2018-07-21 21:16:13 --> Helper loaded: url_helper
INFO - 2018-07-21 21:16:13 --> Model Class Initialized
INFO - 2018-07-21 21:16:13 --> Final output sent to browser
DEBUG - 2018-07-21 21:16:13 --> Total execution time: 0.0460
ERROR - 2018-07-21 21:16:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:16:14 --> Config Class Initialized
INFO - 2018-07-21 21:16:14 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:16:14 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:16:14 --> Utf8 Class Initialized
INFO - 2018-07-21 21:16:14 --> URI Class Initialized
INFO - 2018-07-21 21:16:14 --> Router Class Initialized
INFO - 2018-07-21 21:16:14 --> Output Class Initialized
INFO - 2018-07-21 21:16:14 --> Security Class Initialized
DEBUG - 2018-07-21 21:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:16:14 --> Input Class Initialized
INFO - 2018-07-21 21:16:14 --> Language Class Initialized
INFO - 2018-07-21 21:16:14 --> Loader Class Initialized
INFO - 2018-07-21 21:16:14 --> Controller Class Initialized
INFO - 2018-07-21 21:16:14 --> Database Driver Class Initialized
INFO - 2018-07-21 21:16:14 --> Model Class Initialized
INFO - 2018-07-21 21:16:14 --> Helper loaded: url_helper
INFO - 2018-07-21 21:16:14 --> Model Class Initialized
INFO - 2018-07-21 21:16:14 --> Final output sent to browser
DEBUG - 2018-07-21 21:16:14 --> Total execution time: 0.0603
ERROR - 2018-07-21 21:16:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:16:15 --> Config Class Initialized
INFO - 2018-07-21 21:16:15 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:16:15 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:16:15 --> Utf8 Class Initialized
INFO - 2018-07-21 21:16:15 --> URI Class Initialized
INFO - 2018-07-21 21:16:15 --> Router Class Initialized
INFO - 2018-07-21 21:16:15 --> Output Class Initialized
INFO - 2018-07-21 21:16:15 --> Security Class Initialized
DEBUG - 2018-07-21 21:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:16:15 --> Input Class Initialized
INFO - 2018-07-21 21:16:15 --> Language Class Initialized
INFO - 2018-07-21 21:16:15 --> Loader Class Initialized
INFO - 2018-07-21 21:16:15 --> Controller Class Initialized
INFO - 2018-07-21 21:16:15 --> Database Driver Class Initialized
INFO - 2018-07-21 21:16:15 --> Model Class Initialized
INFO - 2018-07-21 21:16:15 --> Helper loaded: url_helper
INFO - 2018-07-21 21:16:15 --> Model Class Initialized
INFO - 2018-07-21 21:16:15 --> Final output sent to browser
DEBUG - 2018-07-21 21:16:15 --> Total execution time: 0.0546
ERROR - 2018-07-21 21:16:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:16:17 --> Config Class Initialized
INFO - 2018-07-21 21:16:17 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:16:17 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:16:17 --> Utf8 Class Initialized
INFO - 2018-07-21 21:16:17 --> URI Class Initialized
INFO - 2018-07-21 21:16:17 --> Router Class Initialized
INFO - 2018-07-21 21:16:17 --> Output Class Initialized
INFO - 2018-07-21 21:16:17 --> Security Class Initialized
DEBUG - 2018-07-21 21:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:16:17 --> Input Class Initialized
INFO - 2018-07-21 21:16:17 --> Language Class Initialized
INFO - 2018-07-21 21:16:17 --> Loader Class Initialized
INFO - 2018-07-21 21:16:17 --> Controller Class Initialized
INFO - 2018-07-21 21:16:17 --> Database Driver Class Initialized
INFO - 2018-07-21 21:16:17 --> Model Class Initialized
INFO - 2018-07-21 21:16:17 --> Helper loaded: url_helper
INFO - 2018-07-21 21:16:17 --> Model Class Initialized
INFO - 2018-07-21 21:16:17 --> Final output sent to browser
DEBUG - 2018-07-21 21:16:17 --> Total execution time: 0.0454
ERROR - 2018-07-21 21:16:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:16:35 --> Config Class Initialized
INFO - 2018-07-21 21:16:35 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:16:35 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:16:35 --> Utf8 Class Initialized
INFO - 2018-07-21 21:16:35 --> URI Class Initialized
INFO - 2018-07-21 21:16:35 --> Router Class Initialized
INFO - 2018-07-21 21:16:35 --> Output Class Initialized
INFO - 2018-07-21 21:16:35 --> Security Class Initialized
DEBUG - 2018-07-21 21:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:16:35 --> Input Class Initialized
INFO - 2018-07-21 21:16:35 --> Language Class Initialized
INFO - 2018-07-21 21:16:35 --> Loader Class Initialized
INFO - 2018-07-21 21:16:35 --> Controller Class Initialized
INFO - 2018-07-21 21:16:35 --> Database Driver Class Initialized
INFO - 2018-07-21 21:16:35 --> Model Class Initialized
INFO - 2018-07-21 21:16:35 --> Helper loaded: url_helper
INFO - 2018-07-21 21:16:35 --> Model Class Initialized
INFO - 2018-07-21 21:16:35 --> Final output sent to browser
DEBUG - 2018-07-21 21:16:35 --> Total execution time: 0.0647
ERROR - 2018-07-21 21:16:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:16:36 --> Config Class Initialized
INFO - 2018-07-21 21:16:36 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:16:36 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:16:36 --> Utf8 Class Initialized
INFO - 2018-07-21 21:16:36 --> URI Class Initialized
INFO - 2018-07-21 21:16:36 --> Router Class Initialized
INFO - 2018-07-21 21:16:36 --> Output Class Initialized
INFO - 2018-07-21 21:16:36 --> Security Class Initialized
DEBUG - 2018-07-21 21:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:16:36 --> Input Class Initialized
INFO - 2018-07-21 21:16:36 --> Language Class Initialized
INFO - 2018-07-21 21:16:36 --> Loader Class Initialized
INFO - 2018-07-21 21:16:36 --> Controller Class Initialized
INFO - 2018-07-21 21:16:36 --> Database Driver Class Initialized
INFO - 2018-07-21 21:16:36 --> Model Class Initialized
INFO - 2018-07-21 21:16:36 --> Helper loaded: url_helper
INFO - 2018-07-21 21:16:36 --> Model Class Initialized
INFO - 2018-07-21 21:16:36 --> Final output sent to browser
DEBUG - 2018-07-21 21:16:36 --> Total execution time: 0.0607
ERROR - 2018-07-21 21:16:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:16:36 --> Config Class Initialized
INFO - 2018-07-21 21:16:36 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:16:36 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:16:36 --> Utf8 Class Initialized
INFO - 2018-07-21 21:16:36 --> URI Class Initialized
INFO - 2018-07-21 21:16:36 --> Router Class Initialized
INFO - 2018-07-21 21:16:36 --> Output Class Initialized
INFO - 2018-07-21 21:16:36 --> Security Class Initialized
DEBUG - 2018-07-21 21:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:16:36 --> Input Class Initialized
INFO - 2018-07-21 21:16:36 --> Language Class Initialized
INFO - 2018-07-21 21:16:36 --> Loader Class Initialized
INFO - 2018-07-21 21:16:36 --> Controller Class Initialized
INFO - 2018-07-21 21:16:36 --> Database Driver Class Initialized
INFO - 2018-07-21 21:16:36 --> Model Class Initialized
INFO - 2018-07-21 21:16:36 --> Helper loaded: url_helper
INFO - 2018-07-21 21:16:36 --> Model Class Initialized
INFO - 2018-07-21 21:16:36 --> Final output sent to browser
DEBUG - 2018-07-21 21:16:36 --> Total execution time: 0.0434
ERROR - 2018-07-21 21:16:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:16:37 --> Config Class Initialized
INFO - 2018-07-21 21:16:37 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:16:37 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:16:37 --> Utf8 Class Initialized
INFO - 2018-07-21 21:16:37 --> URI Class Initialized
INFO - 2018-07-21 21:16:37 --> Router Class Initialized
INFO - 2018-07-21 21:16:37 --> Output Class Initialized
INFO - 2018-07-21 21:16:37 --> Security Class Initialized
DEBUG - 2018-07-21 21:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:16:37 --> Input Class Initialized
INFO - 2018-07-21 21:16:37 --> Language Class Initialized
INFO - 2018-07-21 21:16:37 --> Loader Class Initialized
INFO - 2018-07-21 21:16:37 --> Controller Class Initialized
INFO - 2018-07-21 21:16:37 --> Database Driver Class Initialized
INFO - 2018-07-21 21:16:37 --> Model Class Initialized
INFO - 2018-07-21 21:16:37 --> Helper loaded: url_helper
INFO - 2018-07-21 21:16:37 --> Model Class Initialized
INFO - 2018-07-21 21:16:37 --> Final output sent to browser
DEBUG - 2018-07-21 21:16:37 --> Total execution time: 0.0419
ERROR - 2018-07-21 21:16:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:16:38 --> Config Class Initialized
INFO - 2018-07-21 21:16:38 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:16:38 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:16:38 --> Utf8 Class Initialized
INFO - 2018-07-21 21:16:38 --> URI Class Initialized
INFO - 2018-07-21 21:16:38 --> Router Class Initialized
INFO - 2018-07-21 21:16:38 --> Output Class Initialized
INFO - 2018-07-21 21:16:38 --> Security Class Initialized
DEBUG - 2018-07-21 21:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:16:38 --> Input Class Initialized
INFO - 2018-07-21 21:16:38 --> Language Class Initialized
INFO - 2018-07-21 21:16:38 --> Loader Class Initialized
INFO - 2018-07-21 21:16:38 --> Controller Class Initialized
INFO - 2018-07-21 21:16:38 --> Database Driver Class Initialized
INFO - 2018-07-21 21:16:38 --> Model Class Initialized
INFO - 2018-07-21 21:16:38 --> Helper loaded: url_helper
INFO - 2018-07-21 21:16:38 --> Model Class Initialized
INFO - 2018-07-21 21:16:38 --> Final output sent to browser
DEBUG - 2018-07-21 21:16:38 --> Total execution time: 0.0409
ERROR - 2018-07-21 21:16:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:16:39 --> Config Class Initialized
INFO - 2018-07-21 21:16:39 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:16:39 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:16:39 --> Utf8 Class Initialized
INFO - 2018-07-21 21:16:39 --> URI Class Initialized
INFO - 2018-07-21 21:16:39 --> Router Class Initialized
INFO - 2018-07-21 21:16:39 --> Output Class Initialized
INFO - 2018-07-21 21:16:39 --> Security Class Initialized
DEBUG - 2018-07-21 21:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:16:39 --> Input Class Initialized
INFO - 2018-07-21 21:16:39 --> Language Class Initialized
INFO - 2018-07-21 21:16:39 --> Loader Class Initialized
INFO - 2018-07-21 21:16:39 --> Controller Class Initialized
INFO - 2018-07-21 21:16:39 --> Database Driver Class Initialized
INFO - 2018-07-21 21:16:39 --> Model Class Initialized
INFO - 2018-07-21 21:16:39 --> Helper loaded: url_helper
INFO - 2018-07-21 21:16:39 --> Model Class Initialized
INFO - 2018-07-21 21:16:39 --> Final output sent to browser
DEBUG - 2018-07-21 21:16:39 --> Total execution time: 0.0414
ERROR - 2018-07-21 21:16:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:16:39 --> Config Class Initialized
INFO - 2018-07-21 21:16:39 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:16:39 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:16:39 --> Utf8 Class Initialized
INFO - 2018-07-21 21:16:39 --> URI Class Initialized
INFO - 2018-07-21 21:16:39 --> Router Class Initialized
INFO - 2018-07-21 21:16:39 --> Output Class Initialized
INFO - 2018-07-21 21:16:39 --> Security Class Initialized
DEBUG - 2018-07-21 21:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:16:39 --> Input Class Initialized
INFO - 2018-07-21 21:16:39 --> Language Class Initialized
INFO - 2018-07-21 21:16:39 --> Loader Class Initialized
INFO - 2018-07-21 21:16:39 --> Controller Class Initialized
INFO - 2018-07-21 21:16:39 --> Database Driver Class Initialized
INFO - 2018-07-21 21:16:39 --> Model Class Initialized
INFO - 2018-07-21 21:16:39 --> Helper loaded: url_helper
INFO - 2018-07-21 21:16:39 --> Model Class Initialized
INFO - 2018-07-21 21:16:39 --> Final output sent to browser
DEBUG - 2018-07-21 21:16:39 --> Total execution time: 0.0429
ERROR - 2018-07-21 21:20:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:20:06 --> Config Class Initialized
INFO - 2018-07-21 21:20:06 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:20:06 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:20:06 --> Utf8 Class Initialized
INFO - 2018-07-21 21:20:06 --> URI Class Initialized
INFO - 2018-07-21 21:20:06 --> Router Class Initialized
INFO - 2018-07-21 21:20:06 --> Output Class Initialized
INFO - 2018-07-21 21:20:06 --> Security Class Initialized
DEBUG - 2018-07-21 21:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:20:06 --> Input Class Initialized
INFO - 2018-07-21 21:20:06 --> Language Class Initialized
INFO - 2018-07-21 21:20:06 --> Loader Class Initialized
INFO - 2018-07-21 21:20:06 --> Controller Class Initialized
INFO - 2018-07-21 21:20:06 --> Database Driver Class Initialized
INFO - 2018-07-21 21:20:06 --> Model Class Initialized
INFO - 2018-07-21 21:20:06 --> Helper loaded: url_helper
INFO - 2018-07-21 21:20:06 --> Model Class Initialized
INFO - 2018-07-21 21:20:06 --> Final output sent to browser
DEBUG - 2018-07-21 21:20:06 --> Total execution time: 0.0460
ERROR - 2018-07-21 21:20:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:20:07 --> Config Class Initialized
INFO - 2018-07-21 21:20:07 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:20:07 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:20:07 --> Utf8 Class Initialized
INFO - 2018-07-21 21:20:07 --> URI Class Initialized
INFO - 2018-07-21 21:20:07 --> Router Class Initialized
INFO - 2018-07-21 21:20:07 --> Output Class Initialized
INFO - 2018-07-21 21:20:07 --> Security Class Initialized
DEBUG - 2018-07-21 21:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:20:07 --> Input Class Initialized
INFO - 2018-07-21 21:20:07 --> Language Class Initialized
INFO - 2018-07-21 21:20:07 --> Loader Class Initialized
INFO - 2018-07-21 21:20:07 --> Controller Class Initialized
INFO - 2018-07-21 21:20:07 --> Database Driver Class Initialized
INFO - 2018-07-21 21:20:07 --> Model Class Initialized
INFO - 2018-07-21 21:20:07 --> Helper loaded: url_helper
INFO - 2018-07-21 21:20:07 --> Model Class Initialized
INFO - 2018-07-21 21:20:07 --> Final output sent to browser
DEBUG - 2018-07-21 21:20:07 --> Total execution time: 0.0507
ERROR - 2018-07-21 21:20:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:20:08 --> Config Class Initialized
INFO - 2018-07-21 21:20:08 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:20:08 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:20:08 --> Utf8 Class Initialized
INFO - 2018-07-21 21:20:08 --> URI Class Initialized
INFO - 2018-07-21 21:20:08 --> Router Class Initialized
INFO - 2018-07-21 21:20:08 --> Output Class Initialized
INFO - 2018-07-21 21:20:08 --> Security Class Initialized
DEBUG - 2018-07-21 21:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:20:08 --> Input Class Initialized
INFO - 2018-07-21 21:20:08 --> Language Class Initialized
INFO - 2018-07-21 21:20:08 --> Loader Class Initialized
INFO - 2018-07-21 21:20:08 --> Controller Class Initialized
INFO - 2018-07-21 21:20:08 --> Database Driver Class Initialized
INFO - 2018-07-21 21:20:08 --> Model Class Initialized
INFO - 2018-07-21 21:20:08 --> Helper loaded: url_helper
INFO - 2018-07-21 21:20:08 --> Model Class Initialized
INFO - 2018-07-21 21:20:08 --> Final output sent to browser
DEBUG - 2018-07-21 21:20:08 --> Total execution time: 0.0444
ERROR - 2018-07-21 21:27:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:27:00 --> Config Class Initialized
INFO - 2018-07-21 21:27:00 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:27:00 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:27:00 --> Utf8 Class Initialized
INFO - 2018-07-21 21:27:00 --> URI Class Initialized
INFO - 2018-07-21 21:27:00 --> Router Class Initialized
INFO - 2018-07-21 21:27:00 --> Output Class Initialized
INFO - 2018-07-21 21:27:00 --> Security Class Initialized
DEBUG - 2018-07-21 21:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:27:00 --> Input Class Initialized
INFO - 2018-07-21 21:27:00 --> Language Class Initialized
INFO - 2018-07-21 21:27:00 --> Loader Class Initialized
INFO - 2018-07-21 21:27:00 --> Controller Class Initialized
INFO - 2018-07-21 21:27:00 --> Database Driver Class Initialized
INFO - 2018-07-21 21:27:00 --> Model Class Initialized
INFO - 2018-07-21 21:27:00 --> Helper loaded: url_helper
INFO - 2018-07-21 21:27:00 --> Model Class Initialized
INFO - 2018-07-21 21:27:00 --> Final output sent to browser
DEBUG - 2018-07-21 21:27:00 --> Total execution time: 0.0421
ERROR - 2018-07-21 21:27:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:27:06 --> Config Class Initialized
INFO - 2018-07-21 21:27:06 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:27:06 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:27:06 --> Utf8 Class Initialized
INFO - 2018-07-21 21:27:06 --> URI Class Initialized
INFO - 2018-07-21 21:27:06 --> Router Class Initialized
INFO - 2018-07-21 21:27:06 --> Output Class Initialized
INFO - 2018-07-21 21:27:06 --> Security Class Initialized
DEBUG - 2018-07-21 21:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:27:06 --> Input Class Initialized
INFO - 2018-07-21 21:27:06 --> Language Class Initialized
INFO - 2018-07-21 21:27:06 --> Loader Class Initialized
INFO - 2018-07-21 21:27:06 --> Controller Class Initialized
INFO - 2018-07-21 21:27:06 --> Database Driver Class Initialized
INFO - 2018-07-21 21:27:06 --> Model Class Initialized
INFO - 2018-07-21 21:27:06 --> Helper loaded: url_helper
INFO - 2018-07-21 21:27:06 --> Model Class Initialized
INFO - 2018-07-21 21:27:06 --> Final output sent to browser
DEBUG - 2018-07-21 21:27:06 --> Total execution time: 0.0396
ERROR - 2018-07-21 21:27:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:27:09 --> Config Class Initialized
INFO - 2018-07-21 21:27:09 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:27:09 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:27:09 --> Utf8 Class Initialized
INFO - 2018-07-21 21:27:09 --> URI Class Initialized
INFO - 2018-07-21 21:27:09 --> Router Class Initialized
INFO - 2018-07-21 21:27:09 --> Output Class Initialized
INFO - 2018-07-21 21:27:09 --> Security Class Initialized
DEBUG - 2018-07-21 21:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:27:09 --> Input Class Initialized
INFO - 2018-07-21 21:27:09 --> Language Class Initialized
INFO - 2018-07-21 21:27:09 --> Loader Class Initialized
INFO - 2018-07-21 21:27:09 --> Controller Class Initialized
INFO - 2018-07-21 21:27:09 --> Database Driver Class Initialized
INFO - 2018-07-21 21:27:09 --> Model Class Initialized
INFO - 2018-07-21 21:27:09 --> Helper loaded: url_helper
INFO - 2018-07-21 21:27:09 --> Model Class Initialized
INFO - 2018-07-21 21:27:09 --> Final output sent to browser
DEBUG - 2018-07-21 21:27:09 --> Total execution time: 0.0473
ERROR - 2018-07-21 21:32:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:32:12 --> Config Class Initialized
INFO - 2018-07-21 21:32:12 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:32:12 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:32:12 --> Utf8 Class Initialized
INFO - 2018-07-21 21:32:12 --> URI Class Initialized
INFO - 2018-07-21 21:32:12 --> Router Class Initialized
INFO - 2018-07-21 21:32:12 --> Output Class Initialized
INFO - 2018-07-21 21:32:12 --> Security Class Initialized
DEBUG - 2018-07-21 21:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:32:12 --> Input Class Initialized
INFO - 2018-07-21 21:32:12 --> Language Class Initialized
INFO - 2018-07-21 21:32:12 --> Loader Class Initialized
INFO - 2018-07-21 21:32:12 --> Controller Class Initialized
INFO - 2018-07-21 21:32:12 --> Database Driver Class Initialized
INFO - 2018-07-21 21:32:13 --> Model Class Initialized
INFO - 2018-07-21 21:32:13 --> Helper loaded: url_helper
INFO - 2018-07-21 21:32:13 --> Model Class Initialized
INFO - 2018-07-21 21:32:13 --> Final output sent to browser
DEBUG - 2018-07-21 21:32:13 --> Total execution time: 0.2209
ERROR - 2018-07-21 21:32:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-21 21:32:34 --> Config Class Initialized
INFO - 2018-07-21 21:32:34 --> Hooks Class Initialized
DEBUG - 2018-07-21 21:32:34 --> UTF-8 Support Enabled
INFO - 2018-07-21 21:32:34 --> Utf8 Class Initialized
INFO - 2018-07-21 21:32:34 --> URI Class Initialized
INFO - 2018-07-21 21:32:34 --> Router Class Initialized
INFO - 2018-07-21 21:32:34 --> Output Class Initialized
INFO - 2018-07-21 21:32:34 --> Security Class Initialized
DEBUG - 2018-07-21 21:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-21 21:32:34 --> Input Class Initialized
INFO - 2018-07-21 21:32:34 --> Language Class Initialized
INFO - 2018-07-21 21:32:34 --> Loader Class Initialized
INFO - 2018-07-21 21:32:34 --> Controller Class Initialized
INFO - 2018-07-21 21:32:34 --> Database Driver Class Initialized
INFO - 2018-07-21 21:32:34 --> Model Class Initialized
INFO - 2018-07-21 21:32:34 --> Helper loaded: url_helper
INFO - 2018-07-21 21:32:34 --> Model Class Initialized
INFO - 2018-07-21 21:32:34 --> Final output sent to browser
DEBUG - 2018-07-21 21:32:34 --> Total execution time: 0.1013
