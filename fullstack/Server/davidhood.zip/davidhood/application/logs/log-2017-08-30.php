<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-30 16:02:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-30 16:02:29 --> Config Class Initialized
INFO - 2017-08-30 16:02:29 --> Hooks Class Initialized
DEBUG - 2017-08-30 16:02:29 --> UTF-8 Support Enabled
INFO - 2017-08-30 16:02:29 --> Utf8 Class Initialized
INFO - 2017-08-30 16:02:29 --> URI Class Initialized
INFO - 2017-08-30 16:02:30 --> Router Class Initialized
INFO - 2017-08-30 16:02:30 --> Output Class Initialized
INFO - 2017-08-30 16:02:30 --> Security Class Initialized
DEBUG - 2017-08-30 16:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-30 16:02:30 --> Input Class Initialized
INFO - 2017-08-30 16:02:30 --> Language Class Initialized
INFO - 2017-08-30 16:02:30 --> Loader Class Initialized
INFO - 2017-08-30 16:02:30 --> Controller Class Initialized
INFO - 2017-08-30 16:02:30 --> Database Driver Class Initialized
INFO - 2017-08-30 16:02:31 --> Model Class Initialized
INFO - 2017-08-30 16:02:31 --> Helper loaded: form_helper
INFO - 2017-08-30 16:02:31 --> Helper loaded: url_helper
INFO - 2017-08-30 16:02:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-30 16:02:31 --> Model Class Initialized
INFO - 2017-08-30 16:02:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-08-30 16:02:31 --> Final output sent to browser
DEBUG - 2017-08-30 16:02:31 --> Total execution time: 1.7411
