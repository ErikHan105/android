<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-31 17:41:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-31 17:41:58 --> Config Class Initialized
INFO - 2017-07-31 17:41:58 --> Hooks Class Initialized
DEBUG - 2017-07-31 17:41:58 --> UTF-8 Support Enabled
INFO - 2017-07-31 17:41:58 --> Utf8 Class Initialized
INFO - 2017-07-31 17:41:58 --> URI Class Initialized
DEBUG - 2017-07-31 17:41:58 --> No URI present. Default controller set.
INFO - 2017-07-31 17:41:58 --> Router Class Initialized
INFO - 2017-07-31 17:41:58 --> Output Class Initialized
INFO - 2017-07-31 17:41:58 --> Security Class Initialized
DEBUG - 2017-07-31 17:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-31 17:41:58 --> Input Class Initialized
INFO - 2017-07-31 17:41:58 --> Language Class Initialized
INFO - 2017-07-31 17:41:58 --> Loader Class Initialized
INFO - 2017-07-31 17:41:58 --> Controller Class Initialized
INFO - 2017-07-31 17:41:58 --> Database Driver Class Initialized
INFO - 2017-07-31 17:41:58 --> Model Class Initialized
INFO - 2017-07-31 17:41:58 --> Helper loaded: form_helper
INFO - 2017-07-31 17:41:58 --> Helper loaded: url_helper
INFO - 2017-07-31 17:41:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-31 17:41:58 --> Final output sent to browser
DEBUG - 2017-07-31 17:41:58 --> Total execution time: 0.0330
ERROR - 2017-07-31 17:42:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-31 17:42:03 --> Config Class Initialized
INFO - 2017-07-31 17:42:03 --> Hooks Class Initialized
DEBUG - 2017-07-31 17:42:03 --> UTF-8 Support Enabled
INFO - 2017-07-31 17:42:03 --> Utf8 Class Initialized
INFO - 2017-07-31 17:42:03 --> URI Class Initialized
INFO - 2017-07-31 17:42:03 --> Router Class Initialized
INFO - 2017-07-31 17:42:03 --> Output Class Initialized
INFO - 2017-07-31 17:42:03 --> Security Class Initialized
DEBUG - 2017-07-31 17:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-31 17:42:03 --> Input Class Initialized
INFO - 2017-07-31 17:42:03 --> Language Class Initialized
INFO - 2017-07-31 17:42:03 --> Loader Class Initialized
INFO - 2017-07-31 17:42:03 --> Controller Class Initialized
INFO - 2017-07-31 17:42:03 --> Database Driver Class Initialized
INFO - 2017-07-31 17:42:03 --> Model Class Initialized
INFO - 2017-07-31 17:42:03 --> Helper loaded: form_helper
INFO - 2017-07-31 17:42:03 --> Helper loaded: url_helper
INFO - 2017-07-31 17:42:03 --> Model Class Initialized
ERROR - 2017-07-31 17:42:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-31 17:42:03 --> Config Class Initialized
INFO - 2017-07-31 17:42:03 --> Hooks Class Initialized
DEBUG - 2017-07-31 17:42:03 --> UTF-8 Support Enabled
INFO - 2017-07-31 17:42:03 --> Utf8 Class Initialized
INFO - 2017-07-31 17:42:03 --> URI Class Initialized
INFO - 2017-07-31 17:42:03 --> Router Class Initialized
INFO - 2017-07-31 17:42:03 --> Output Class Initialized
INFO - 2017-07-31 17:42:03 --> Security Class Initialized
DEBUG - 2017-07-31 17:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-31 17:42:03 --> Input Class Initialized
INFO - 2017-07-31 17:42:03 --> Language Class Initialized
INFO - 2017-07-31 17:42:03 --> Loader Class Initialized
INFO - 2017-07-31 17:42:03 --> Controller Class Initialized
INFO - 2017-07-31 17:42:03 --> Database Driver Class Initialized
INFO - 2017-07-31 17:42:03 --> Model Class Initialized
INFO - 2017-07-31 17:42:03 --> Helper loaded: form_helper
INFO - 2017-07-31 17:42:03 --> Helper loaded: url_helper
INFO - 2017-07-31 17:42:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-31 17:42:03 --> Model Class Initialized
INFO - 2017-07-31 17:42:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-31 17:42:03 --> Final output sent to browser
DEBUG - 2017-07-31 17:42:03 --> Total execution time: 0.0670
ERROR - 2017-07-31 17:42:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-31 17:42:07 --> Config Class Initialized
INFO - 2017-07-31 17:42:07 --> Hooks Class Initialized
DEBUG - 2017-07-31 17:42:07 --> UTF-8 Support Enabled
INFO - 2017-07-31 17:42:07 --> Utf8 Class Initialized
INFO - 2017-07-31 17:42:07 --> URI Class Initialized
INFO - 2017-07-31 17:42:07 --> Router Class Initialized
INFO - 2017-07-31 17:42:07 --> Output Class Initialized
INFO - 2017-07-31 17:42:07 --> Security Class Initialized
DEBUG - 2017-07-31 17:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-31 17:42:07 --> Input Class Initialized
INFO - 2017-07-31 17:42:07 --> Language Class Initialized
INFO - 2017-07-31 17:42:07 --> Loader Class Initialized
INFO - 2017-07-31 17:42:07 --> Controller Class Initialized
INFO - 2017-07-31 17:42:07 --> Database Driver Class Initialized
INFO - 2017-07-31 17:42:07 --> Model Class Initialized
INFO - 2017-07-31 17:42:07 --> Helper loaded: form_helper
INFO - 2017-07-31 17:42:07 --> Helper loaded: url_helper
INFO - 2017-07-31 17:42:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-31 17:42:07 --> Model Class Initialized
INFO - 2017-07-31 17:42:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-31 17:42:07 --> Final output sent to browser
DEBUG - 2017-07-31 17:42:07 --> Total execution time: 0.0720
ERROR - 2017-07-31 17:42:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-31 17:42:08 --> Config Class Initialized
INFO - 2017-07-31 17:42:08 --> Hooks Class Initialized
DEBUG - 2017-07-31 17:42:08 --> UTF-8 Support Enabled
INFO - 2017-07-31 17:42:08 --> Utf8 Class Initialized
INFO - 2017-07-31 17:42:08 --> URI Class Initialized
INFO - 2017-07-31 17:42:08 --> Router Class Initialized
INFO - 2017-07-31 17:42:08 --> Output Class Initialized
INFO - 2017-07-31 17:42:08 --> Security Class Initialized
DEBUG - 2017-07-31 17:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-31 17:42:08 --> Input Class Initialized
INFO - 2017-07-31 17:42:08 --> Language Class Initialized
INFO - 2017-07-31 17:42:08 --> Loader Class Initialized
INFO - 2017-07-31 17:42:08 --> Controller Class Initialized
INFO - 2017-07-31 17:42:08 --> Database Driver Class Initialized
INFO - 2017-07-31 17:42:08 --> Model Class Initialized
INFO - 2017-07-31 17:42:08 --> Helper loaded: form_helper
INFO - 2017-07-31 17:42:08 --> Helper loaded: url_helper
INFO - 2017-07-31 17:42:08 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-31 17:42:08 --> Model Class Initialized
INFO - 2017-07-31 17:42:08 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-31 17:42:08 --> Final output sent to browser
DEBUG - 2017-07-31 17:42:09 --> Total execution time: 0.0610
