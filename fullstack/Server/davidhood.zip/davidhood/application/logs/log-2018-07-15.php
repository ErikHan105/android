<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-15 03:42:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 03:42:08 --> Config Class Initialized
INFO - 2018-07-15 03:42:08 --> Hooks Class Initialized
DEBUG - 2018-07-15 03:42:08 --> UTF-8 Support Enabled
INFO - 2018-07-15 03:42:08 --> Utf8 Class Initialized
INFO - 2018-07-15 03:42:08 --> URI Class Initialized
INFO - 2018-07-15 03:42:08 --> Router Class Initialized
INFO - 2018-07-15 03:42:08 --> Output Class Initialized
INFO - 2018-07-15 03:42:08 --> Security Class Initialized
DEBUG - 2018-07-15 03:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 03:42:08 --> Input Class Initialized
INFO - 2018-07-15 03:42:08 --> Language Class Initialized
INFO - 2018-07-15 03:42:08 --> Loader Class Initialized
INFO - 2018-07-15 03:42:08 --> Controller Class Initialized
INFO - 2018-07-15 03:42:08 --> Database Driver Class Initialized
INFO - 2018-07-15 03:42:08 --> Model Class Initialized
INFO - 2018-07-15 03:42:08 --> Helper loaded: url_helper
DEBUG - 2018-07-15 03:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 03:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 03:42:08 --> Model Class Initialized
INFO - 2018-07-15 03:42:08 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 03:42:08 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-15 03:42:08 --> Final output sent to browser
DEBUG - 2018-07-15 03:42:08 --> Total execution time: 0.1160
ERROR - 2018-07-15 03:42:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 03:42:24 --> Config Class Initialized
INFO - 2018-07-15 03:42:24 --> Hooks Class Initialized
DEBUG - 2018-07-15 03:42:24 --> UTF-8 Support Enabled
INFO - 2018-07-15 03:42:24 --> Utf8 Class Initialized
INFO - 2018-07-15 03:42:24 --> URI Class Initialized
INFO - 2018-07-15 03:42:24 --> Router Class Initialized
INFO - 2018-07-15 03:42:24 --> Output Class Initialized
INFO - 2018-07-15 03:42:24 --> Security Class Initialized
DEBUG - 2018-07-15 03:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 03:42:24 --> Input Class Initialized
INFO - 2018-07-15 03:42:24 --> Language Class Initialized
INFO - 2018-07-15 03:42:24 --> Loader Class Initialized
INFO - 2018-07-15 03:42:24 --> Controller Class Initialized
INFO - 2018-07-15 03:42:24 --> Database Driver Class Initialized
INFO - 2018-07-15 03:42:24 --> Model Class Initialized
INFO - 2018-07-15 03:42:24 --> Helper loaded: url_helper
DEBUG - 2018-07-15 03:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 03:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 03:42:24 --> Model Class Initialized
INFO - 2018-07-15 03:42:24 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 03:42:24 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-15 03:42:24 --> Final output sent to browser
DEBUG - 2018-07-15 03:42:24 --> Total execution time: 0.0622
ERROR - 2018-07-15 05:20:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 05:20:03 --> Config Class Initialized
INFO - 2018-07-15 05:20:03 --> Hooks Class Initialized
DEBUG - 2018-07-15 05:20:03 --> UTF-8 Support Enabled
INFO - 2018-07-15 05:20:03 --> Utf8 Class Initialized
INFO - 2018-07-15 05:20:03 --> URI Class Initialized
INFO - 2018-07-15 05:20:03 --> Router Class Initialized
INFO - 2018-07-15 05:20:03 --> Output Class Initialized
INFO - 2018-07-15 05:20:03 --> Security Class Initialized
DEBUG - 2018-07-15 05:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 05:20:03 --> Input Class Initialized
INFO - 2018-07-15 05:20:03 --> Language Class Initialized
INFO - 2018-07-15 05:20:03 --> Loader Class Initialized
INFO - 2018-07-15 05:20:03 --> Controller Class Initialized
INFO - 2018-07-15 05:20:03 --> Database Driver Class Initialized
INFO - 2018-07-15 05:20:03 --> Model Class Initialized
INFO - 2018-07-15 05:20:03 --> Helper loaded: url_helper
INFO - 2018-07-15 05:20:03 --> Model Class Initialized
INFO - 2018-07-15 05:20:03 --> Final output sent to browser
DEBUG - 2018-07-15 05:20:03 --> Total execution time: 0.0473
ERROR - 2018-07-15 05:20:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 05:20:16 --> Config Class Initialized
INFO - 2018-07-15 05:20:16 --> Hooks Class Initialized
DEBUG - 2018-07-15 05:20:16 --> UTF-8 Support Enabled
INFO - 2018-07-15 05:20:16 --> Utf8 Class Initialized
INFO - 2018-07-15 05:20:16 --> URI Class Initialized
INFO - 2018-07-15 05:20:16 --> Router Class Initialized
INFO - 2018-07-15 05:20:16 --> Output Class Initialized
INFO - 2018-07-15 05:20:16 --> Security Class Initialized
DEBUG - 2018-07-15 05:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 05:20:16 --> Input Class Initialized
INFO - 2018-07-15 05:20:16 --> Language Class Initialized
INFO - 2018-07-15 05:20:16 --> Loader Class Initialized
INFO - 2018-07-15 05:20:16 --> Controller Class Initialized
INFO - 2018-07-15 05:20:16 --> Database Driver Class Initialized
INFO - 2018-07-15 05:20:16 --> Model Class Initialized
INFO - 2018-07-15 05:20:16 --> Helper loaded: url_helper
INFO - 2018-07-15 05:20:16 --> Model Class Initialized
ERROR - 2018-07-15 05:21:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 05:21:15 --> Config Class Initialized
INFO - 2018-07-15 05:21:15 --> Hooks Class Initialized
DEBUG - 2018-07-15 05:21:15 --> UTF-8 Support Enabled
INFO - 2018-07-15 05:21:15 --> Utf8 Class Initialized
INFO - 2018-07-15 05:21:15 --> URI Class Initialized
INFO - 2018-07-15 05:21:15 --> Router Class Initialized
INFO - 2018-07-15 05:21:15 --> Output Class Initialized
INFO - 2018-07-15 05:21:15 --> Security Class Initialized
DEBUG - 2018-07-15 05:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 05:21:15 --> Input Class Initialized
INFO - 2018-07-15 05:21:15 --> Language Class Initialized
INFO - 2018-07-15 05:21:15 --> Loader Class Initialized
INFO - 2018-07-15 05:21:15 --> Controller Class Initialized
INFO - 2018-07-15 05:21:15 --> Database Driver Class Initialized
INFO - 2018-07-15 05:21:15 --> Model Class Initialized
INFO - 2018-07-15 05:21:15 --> Helper loaded: url_helper
INFO - 2018-07-15 05:21:15 --> Model Class Initialized
ERROR - 2018-07-15 05:23:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 05:23:13 --> Config Class Initialized
INFO - 2018-07-15 05:23:13 --> Hooks Class Initialized
DEBUG - 2018-07-15 05:23:13 --> UTF-8 Support Enabled
INFO - 2018-07-15 05:23:13 --> Utf8 Class Initialized
INFO - 2018-07-15 05:23:13 --> URI Class Initialized
INFO - 2018-07-15 05:23:13 --> Router Class Initialized
INFO - 2018-07-15 05:23:13 --> Output Class Initialized
INFO - 2018-07-15 05:23:13 --> Security Class Initialized
DEBUG - 2018-07-15 05:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 05:23:13 --> Input Class Initialized
INFO - 2018-07-15 05:23:13 --> Language Class Initialized
INFO - 2018-07-15 05:23:13 --> Loader Class Initialized
INFO - 2018-07-15 05:23:13 --> Controller Class Initialized
INFO - 2018-07-15 05:23:13 --> Database Driver Class Initialized
INFO - 2018-07-15 05:23:13 --> Model Class Initialized
INFO - 2018-07-15 05:23:13 --> Helper loaded: url_helper
INFO - 2018-07-15 05:23:13 --> Model Class Initialized
INFO - 2018-07-15 05:23:13 --> Final output sent to browser
DEBUG - 2018-07-15 05:23:13 --> Total execution time: 0.0393
ERROR - 2018-07-15 05:23:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 05:23:50 --> Config Class Initialized
INFO - 2018-07-15 05:23:50 --> Hooks Class Initialized
DEBUG - 2018-07-15 05:23:50 --> UTF-8 Support Enabled
INFO - 2018-07-15 05:23:50 --> Utf8 Class Initialized
INFO - 2018-07-15 05:23:50 --> URI Class Initialized
INFO - 2018-07-15 05:23:50 --> Router Class Initialized
INFO - 2018-07-15 05:23:50 --> Output Class Initialized
INFO - 2018-07-15 05:23:50 --> Security Class Initialized
DEBUG - 2018-07-15 05:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 05:23:50 --> Input Class Initialized
INFO - 2018-07-15 05:23:50 --> Language Class Initialized
INFO - 2018-07-15 05:23:50 --> Loader Class Initialized
INFO - 2018-07-15 05:23:50 --> Controller Class Initialized
INFO - 2018-07-15 05:23:50 --> Database Driver Class Initialized
INFO - 2018-07-15 05:23:50 --> Model Class Initialized
INFO - 2018-07-15 05:23:50 --> Helper loaded: url_helper
INFO - 2018-07-15 05:23:50 --> Model Class Initialized
INFO - 2018-07-15 05:23:50 --> Final output sent to browser
DEBUG - 2018-07-15 05:23:50 --> Total execution time: 0.0418
ERROR - 2018-07-15 05:25:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 05:25:29 --> Config Class Initialized
INFO - 2018-07-15 05:25:29 --> Hooks Class Initialized
DEBUG - 2018-07-15 05:25:29 --> UTF-8 Support Enabled
INFO - 2018-07-15 05:25:29 --> Utf8 Class Initialized
INFO - 2018-07-15 05:25:29 --> URI Class Initialized
INFO - 2018-07-15 05:25:29 --> Router Class Initialized
INFO - 2018-07-15 05:25:29 --> Output Class Initialized
INFO - 2018-07-15 05:25:29 --> Security Class Initialized
DEBUG - 2018-07-15 05:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 05:25:29 --> Input Class Initialized
INFO - 2018-07-15 05:25:29 --> Language Class Initialized
INFO - 2018-07-15 05:25:29 --> Loader Class Initialized
INFO - 2018-07-15 05:25:29 --> Controller Class Initialized
INFO - 2018-07-15 05:25:29 --> Database Driver Class Initialized
INFO - 2018-07-15 05:25:29 --> Model Class Initialized
INFO - 2018-07-15 05:25:29 --> Helper loaded: url_helper
INFO - 2018-07-15 05:25:29 --> Model Class Initialized
ERROR - 2018-07-15 05:25:29 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 26
ERROR - 2018-07-15 05:25:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 05:25:48 --> Config Class Initialized
INFO - 2018-07-15 05:25:48 --> Hooks Class Initialized
DEBUG - 2018-07-15 05:25:48 --> UTF-8 Support Enabled
INFO - 2018-07-15 05:25:48 --> Utf8 Class Initialized
INFO - 2018-07-15 05:25:48 --> URI Class Initialized
INFO - 2018-07-15 05:25:48 --> Router Class Initialized
INFO - 2018-07-15 05:25:48 --> Output Class Initialized
INFO - 2018-07-15 05:25:48 --> Security Class Initialized
DEBUG - 2018-07-15 05:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 05:25:48 --> Input Class Initialized
INFO - 2018-07-15 05:25:48 --> Language Class Initialized
INFO - 2018-07-15 05:25:48 --> Loader Class Initialized
INFO - 2018-07-15 05:25:48 --> Controller Class Initialized
INFO - 2018-07-15 05:25:48 --> Database Driver Class Initialized
INFO - 2018-07-15 05:25:48 --> Model Class Initialized
INFO - 2018-07-15 05:25:48 --> Helper loaded: url_helper
INFO - 2018-07-15 05:25:48 --> Model Class Initialized
ERROR - 2018-07-15 05:25:48 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 26
ERROR - 2018-07-15 05:26:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 05:26:11 --> Config Class Initialized
INFO - 2018-07-15 05:26:11 --> Hooks Class Initialized
DEBUG - 2018-07-15 05:26:11 --> UTF-8 Support Enabled
INFO - 2018-07-15 05:26:11 --> Utf8 Class Initialized
INFO - 2018-07-15 05:26:11 --> URI Class Initialized
INFO - 2018-07-15 05:26:11 --> Router Class Initialized
INFO - 2018-07-15 05:26:11 --> Output Class Initialized
INFO - 2018-07-15 05:26:11 --> Security Class Initialized
DEBUG - 2018-07-15 05:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 05:26:11 --> Input Class Initialized
INFO - 2018-07-15 05:26:11 --> Language Class Initialized
INFO - 2018-07-15 05:26:11 --> Loader Class Initialized
INFO - 2018-07-15 05:26:11 --> Controller Class Initialized
INFO - 2018-07-15 05:26:11 --> Database Driver Class Initialized
INFO - 2018-07-15 05:26:11 --> Model Class Initialized
INFO - 2018-07-15 05:26:11 --> Helper loaded: url_helper
INFO - 2018-07-15 05:26:11 --> Model Class Initialized
ERROR - 2018-07-15 05:26:11 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 26
ERROR - 2018-07-15 05:27:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 05:27:47 --> Config Class Initialized
INFO - 2018-07-15 05:27:47 --> Hooks Class Initialized
DEBUG - 2018-07-15 05:27:47 --> UTF-8 Support Enabled
INFO - 2018-07-15 05:27:47 --> Utf8 Class Initialized
INFO - 2018-07-15 05:27:47 --> URI Class Initialized
INFO - 2018-07-15 05:27:47 --> Router Class Initialized
INFO - 2018-07-15 05:27:47 --> Output Class Initialized
INFO - 2018-07-15 05:27:47 --> Security Class Initialized
DEBUG - 2018-07-15 05:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 05:27:47 --> Input Class Initialized
INFO - 2018-07-15 05:27:47 --> Language Class Initialized
INFO - 2018-07-15 05:27:47 --> Loader Class Initialized
INFO - 2018-07-15 05:27:47 --> Controller Class Initialized
INFO - 2018-07-15 05:27:47 --> Database Driver Class Initialized
INFO - 2018-07-15 05:27:47 --> Model Class Initialized
INFO - 2018-07-15 05:27:47 --> Helper loaded: url_helper
INFO - 2018-07-15 05:27:47 --> Model Class Initialized
INFO - 2018-07-15 05:27:47 --> Final output sent to browser
DEBUG - 2018-07-15 05:27:47 --> Total execution time: 0.0424
ERROR - 2018-07-15 05:28:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 05:28:05 --> Config Class Initialized
INFO - 2018-07-15 05:28:05 --> Hooks Class Initialized
DEBUG - 2018-07-15 05:28:05 --> UTF-8 Support Enabled
INFO - 2018-07-15 05:28:05 --> Utf8 Class Initialized
INFO - 2018-07-15 05:28:05 --> URI Class Initialized
INFO - 2018-07-15 05:28:05 --> Router Class Initialized
INFO - 2018-07-15 05:28:05 --> Output Class Initialized
INFO - 2018-07-15 05:28:05 --> Security Class Initialized
DEBUG - 2018-07-15 05:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 05:28:05 --> Input Class Initialized
INFO - 2018-07-15 05:28:05 --> Language Class Initialized
INFO - 2018-07-15 05:28:05 --> Loader Class Initialized
INFO - 2018-07-15 05:28:05 --> Controller Class Initialized
INFO - 2018-07-15 05:28:05 --> Database Driver Class Initialized
INFO - 2018-07-15 05:28:05 --> Model Class Initialized
INFO - 2018-07-15 05:28:05 --> Helper loaded: url_helper
INFO - 2018-07-15 05:28:05 --> Model Class Initialized
ERROR - 2018-07-15 05:28:05 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 26
ERROR - 2018-07-15 05:28:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 05:28:46 --> Config Class Initialized
INFO - 2018-07-15 05:28:46 --> Hooks Class Initialized
DEBUG - 2018-07-15 05:28:46 --> UTF-8 Support Enabled
INFO - 2018-07-15 05:28:46 --> Utf8 Class Initialized
INFO - 2018-07-15 05:28:46 --> URI Class Initialized
INFO - 2018-07-15 05:28:46 --> Router Class Initialized
INFO - 2018-07-15 05:28:46 --> Output Class Initialized
INFO - 2018-07-15 05:28:46 --> Security Class Initialized
DEBUG - 2018-07-15 05:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 05:28:46 --> Input Class Initialized
INFO - 2018-07-15 05:28:46 --> Language Class Initialized
INFO - 2018-07-15 05:28:46 --> Loader Class Initialized
INFO - 2018-07-15 05:28:46 --> Controller Class Initialized
INFO - 2018-07-15 05:28:46 --> Database Driver Class Initialized
INFO - 2018-07-15 05:28:46 --> Model Class Initialized
INFO - 2018-07-15 05:28:46 --> Helper loaded: url_helper
INFO - 2018-07-15 05:28:46 --> Model Class Initialized
INFO - 2018-07-15 05:28:46 --> Final output sent to browser
DEBUG - 2018-07-15 05:28:46 --> Total execution time: 0.0600
ERROR - 2018-07-15 05:59:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 05:59:56 --> Config Class Initialized
INFO - 2018-07-15 05:59:56 --> Hooks Class Initialized
DEBUG - 2018-07-15 05:59:56 --> UTF-8 Support Enabled
INFO - 2018-07-15 05:59:56 --> Utf8 Class Initialized
INFO - 2018-07-15 05:59:56 --> URI Class Initialized
INFO - 2018-07-15 05:59:56 --> Router Class Initialized
INFO - 2018-07-15 05:59:56 --> Output Class Initialized
INFO - 2018-07-15 05:59:56 --> Security Class Initialized
DEBUG - 2018-07-15 05:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 05:59:56 --> Input Class Initialized
INFO - 2018-07-15 05:59:56 --> Language Class Initialized
INFO - 2018-07-15 05:59:56 --> Loader Class Initialized
INFO - 2018-07-15 05:59:56 --> Controller Class Initialized
INFO - 2018-07-15 05:59:56 --> Database Driver Class Initialized
INFO - 2018-07-15 05:59:56 --> Model Class Initialized
INFO - 2018-07-15 05:59:56 --> Helper loaded: url_helper
INFO - 2018-07-15 05:59:56 --> Model Class Initialized
INFO - 2018-07-15 05:59:56 --> Final output sent to browser
DEBUG - 2018-07-15 05:59:56 --> Total execution time: 0.0402
ERROR - 2018-07-15 06:00:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 06:00:07 --> Config Class Initialized
INFO - 2018-07-15 06:00:07 --> Hooks Class Initialized
DEBUG - 2018-07-15 06:00:07 --> UTF-8 Support Enabled
INFO - 2018-07-15 06:00:07 --> Utf8 Class Initialized
INFO - 2018-07-15 06:00:07 --> URI Class Initialized
INFO - 2018-07-15 06:00:07 --> Router Class Initialized
INFO - 2018-07-15 06:00:07 --> Output Class Initialized
INFO - 2018-07-15 06:00:07 --> Security Class Initialized
DEBUG - 2018-07-15 06:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 06:00:07 --> Input Class Initialized
INFO - 2018-07-15 06:00:07 --> Language Class Initialized
INFO - 2018-07-15 06:00:07 --> Loader Class Initialized
INFO - 2018-07-15 06:00:07 --> Controller Class Initialized
INFO - 2018-07-15 06:00:07 --> Database Driver Class Initialized
INFO - 2018-07-15 06:00:07 --> Model Class Initialized
INFO - 2018-07-15 06:00:07 --> Helper loaded: url_helper
INFO - 2018-07-15 06:00:07 --> Model Class Initialized
ERROR - 2018-07-15 06:00:07 --> Severity: Notice --> Undefined property: stdClass::$lang C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 26
ERROR - 2018-07-15 06:00:07 --> Severity: Notice --> Undefined variable: array C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 32
INFO - 2018-07-15 06:00:07 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-15 06:01:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 06:01:08 --> Config Class Initialized
INFO - 2018-07-15 06:01:08 --> Hooks Class Initialized
DEBUG - 2018-07-15 06:01:08 --> UTF-8 Support Enabled
INFO - 2018-07-15 06:01:08 --> Utf8 Class Initialized
INFO - 2018-07-15 06:01:08 --> URI Class Initialized
INFO - 2018-07-15 06:01:08 --> Router Class Initialized
INFO - 2018-07-15 06:01:08 --> Output Class Initialized
INFO - 2018-07-15 06:01:08 --> Security Class Initialized
DEBUG - 2018-07-15 06:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 06:01:08 --> Input Class Initialized
INFO - 2018-07-15 06:01:08 --> Language Class Initialized
INFO - 2018-07-15 06:01:08 --> Loader Class Initialized
INFO - 2018-07-15 06:01:08 --> Controller Class Initialized
INFO - 2018-07-15 06:01:08 --> Database Driver Class Initialized
INFO - 2018-07-15 06:01:08 --> Model Class Initialized
INFO - 2018-07-15 06:01:08 --> Helper loaded: url_helper
INFO - 2018-07-15 06:01:08 --> Model Class Initialized
ERROR - 2018-07-15 06:01:08 --> Severity: Notice --> Trying to get property 'lang' of non-object C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 26
ERROR - 2018-07-15 06:01:08 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 26
ERROR - 2018-07-15 06:01:08 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 26
ERROR - 2018-07-15 06:01:08 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 26
ERROR - 2018-07-15 06:01:08 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 26
ERROR - 2018-07-15 06:01:08 --> Severity: Notice --> Trying to get property 'birth_date' of non-object C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 26
ERROR - 2018-07-15 06:01:08 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 26
ERROR - 2018-07-15 06:01:08 --> Severity: Notice --> Trying to get property 'postal_code' of non-object C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 26
ERROR - 2018-07-15 06:01:08 --> Severity: Notice --> Trying to get property 'iban' of non-object C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 26
ERROR - 2018-07-15 06:01:08 --> Severity: Notice --> Undefined variable: array C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 32
INFO - 2018-07-15 06:01:08 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-15 06:01:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\davidhood\system\core\Exceptions.php:271) C:\xampp\htdocs\davidhood\system\core\Common.php 578
ERROR - 2018-07-15 06:05:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 06:05:41 --> Config Class Initialized
INFO - 2018-07-15 06:05:41 --> Hooks Class Initialized
DEBUG - 2018-07-15 06:05:41 --> UTF-8 Support Enabled
INFO - 2018-07-15 06:05:41 --> Utf8 Class Initialized
INFO - 2018-07-15 06:05:41 --> URI Class Initialized
INFO - 2018-07-15 06:05:41 --> Router Class Initialized
INFO - 2018-07-15 06:05:41 --> Output Class Initialized
INFO - 2018-07-15 06:05:41 --> Security Class Initialized
DEBUG - 2018-07-15 06:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 06:05:41 --> Input Class Initialized
INFO - 2018-07-15 06:05:41 --> Language Class Initialized
INFO - 2018-07-15 06:05:41 --> Loader Class Initialized
INFO - 2018-07-15 06:05:41 --> Controller Class Initialized
INFO - 2018-07-15 06:05:41 --> Database Driver Class Initialized
INFO - 2018-07-15 06:05:41 --> Model Class Initialized
INFO - 2018-07-15 06:05:41 --> Helper loaded: url_helper
INFO - 2018-07-15 06:05:41 --> Model Class Initialized
INFO - 2018-07-15 06:05:41 --> Final output sent to browser
DEBUG - 2018-07-15 06:05:41 --> Total execution time: 0.0534
ERROR - 2018-07-15 06:05:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 06:05:47 --> Config Class Initialized
INFO - 2018-07-15 06:05:47 --> Hooks Class Initialized
DEBUG - 2018-07-15 06:05:47 --> UTF-8 Support Enabled
INFO - 2018-07-15 06:05:47 --> Utf8 Class Initialized
INFO - 2018-07-15 06:05:47 --> URI Class Initialized
INFO - 2018-07-15 06:05:47 --> Router Class Initialized
INFO - 2018-07-15 06:05:47 --> Output Class Initialized
INFO - 2018-07-15 06:05:47 --> Security Class Initialized
DEBUG - 2018-07-15 06:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 06:05:47 --> Input Class Initialized
INFO - 2018-07-15 06:05:47 --> Language Class Initialized
INFO - 2018-07-15 06:05:47 --> Loader Class Initialized
INFO - 2018-07-15 06:05:47 --> Controller Class Initialized
INFO - 2018-07-15 06:05:47 --> Database Driver Class Initialized
INFO - 2018-07-15 06:05:47 --> Model Class Initialized
INFO - 2018-07-15 06:05:47 --> Helper loaded: url_helper
INFO - 2018-07-15 06:05:47 --> Model Class Initialized
ERROR - 2018-07-15 06:05:47 --> Severity: Notice --> Undefined variable: array C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 32
INFO - 2018-07-15 06:05:47 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-07-15 06:06:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 06:06:46 --> Config Class Initialized
INFO - 2018-07-15 06:06:46 --> Hooks Class Initialized
DEBUG - 2018-07-15 06:06:46 --> UTF-8 Support Enabled
INFO - 2018-07-15 06:06:46 --> Utf8 Class Initialized
INFO - 2018-07-15 06:06:46 --> URI Class Initialized
INFO - 2018-07-15 06:06:46 --> Router Class Initialized
INFO - 2018-07-15 06:06:46 --> Output Class Initialized
INFO - 2018-07-15 06:06:46 --> Security Class Initialized
DEBUG - 2018-07-15 06:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 06:06:46 --> Input Class Initialized
INFO - 2018-07-15 06:06:46 --> Language Class Initialized
INFO - 2018-07-15 06:06:46 --> Loader Class Initialized
INFO - 2018-07-15 06:06:46 --> Controller Class Initialized
INFO - 2018-07-15 06:06:46 --> Database Driver Class Initialized
INFO - 2018-07-15 06:06:46 --> Model Class Initialized
INFO - 2018-07-15 06:06:46 --> Helper loaded: url_helper
INFO - 2018-07-15 06:06:46 --> Model Class Initialized
INFO - 2018-07-15 06:06:46 --> Final output sent to browser
DEBUG - 2018-07-15 06:06:46 --> Total execution time: 0.3112
ERROR - 2018-07-15 06:09:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 06:09:16 --> Config Class Initialized
INFO - 2018-07-15 06:09:16 --> Hooks Class Initialized
DEBUG - 2018-07-15 06:09:16 --> UTF-8 Support Enabled
INFO - 2018-07-15 06:09:16 --> Utf8 Class Initialized
INFO - 2018-07-15 06:09:16 --> URI Class Initialized
INFO - 2018-07-15 06:09:16 --> Router Class Initialized
INFO - 2018-07-15 06:09:16 --> Output Class Initialized
INFO - 2018-07-15 06:09:16 --> Security Class Initialized
DEBUG - 2018-07-15 06:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 06:09:16 --> Input Class Initialized
INFO - 2018-07-15 06:09:16 --> Language Class Initialized
INFO - 2018-07-15 06:09:16 --> Loader Class Initialized
INFO - 2018-07-15 06:09:16 --> Controller Class Initialized
INFO - 2018-07-15 06:09:16 --> Database Driver Class Initialized
INFO - 2018-07-15 06:09:16 --> Model Class Initialized
INFO - 2018-07-15 06:09:16 --> Helper loaded: url_helper
INFO - 2018-07-15 06:09:16 --> Model Class Initialized
INFO - 2018-07-15 06:09:16 --> Final output sent to browser
DEBUG - 2018-07-15 06:09:16 --> Total execution time: 0.0469
ERROR - 2018-07-15 06:09:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 06:09:51 --> Config Class Initialized
INFO - 2018-07-15 06:09:51 --> Hooks Class Initialized
DEBUG - 2018-07-15 06:09:51 --> UTF-8 Support Enabled
INFO - 2018-07-15 06:09:51 --> Utf8 Class Initialized
INFO - 2018-07-15 06:09:51 --> URI Class Initialized
INFO - 2018-07-15 06:09:51 --> Router Class Initialized
INFO - 2018-07-15 06:09:51 --> Output Class Initialized
INFO - 2018-07-15 06:09:51 --> Security Class Initialized
DEBUG - 2018-07-15 06:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 06:09:51 --> Input Class Initialized
INFO - 2018-07-15 06:09:51 --> Language Class Initialized
INFO - 2018-07-15 06:09:51 --> Loader Class Initialized
INFO - 2018-07-15 06:09:51 --> Controller Class Initialized
INFO - 2018-07-15 06:09:51 --> Database Driver Class Initialized
INFO - 2018-07-15 06:09:51 --> Model Class Initialized
INFO - 2018-07-15 06:09:51 --> Helper loaded: url_helper
INFO - 2018-07-15 06:09:51 --> Model Class Initialized
INFO - 2018-07-15 06:09:51 --> Final output sent to browser
DEBUG - 2018-07-15 06:09:51 --> Total execution time: 0.0432
ERROR - 2018-07-15 06:10:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 06:10:07 --> Config Class Initialized
INFO - 2018-07-15 06:10:07 --> Hooks Class Initialized
DEBUG - 2018-07-15 06:10:07 --> UTF-8 Support Enabled
INFO - 2018-07-15 06:10:07 --> Utf8 Class Initialized
INFO - 2018-07-15 06:10:07 --> URI Class Initialized
INFO - 2018-07-15 06:10:07 --> Router Class Initialized
INFO - 2018-07-15 06:10:07 --> Output Class Initialized
INFO - 2018-07-15 06:10:07 --> Security Class Initialized
DEBUG - 2018-07-15 06:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 06:10:07 --> Input Class Initialized
INFO - 2018-07-15 06:10:07 --> Language Class Initialized
INFO - 2018-07-15 06:10:07 --> Loader Class Initialized
INFO - 2018-07-15 06:10:07 --> Controller Class Initialized
INFO - 2018-07-15 06:10:07 --> Database Driver Class Initialized
INFO - 2018-07-15 06:10:07 --> Model Class Initialized
INFO - 2018-07-15 06:10:07 --> Helper loaded: url_helper
INFO - 2018-07-15 06:10:07 --> Model Class Initialized
INFO - 2018-07-15 06:10:07 --> Final output sent to browser
DEBUG - 2018-07-15 06:10:07 --> Total execution time: 0.0446
ERROR - 2018-07-15 06:11:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 06:11:29 --> Config Class Initialized
INFO - 2018-07-15 06:11:29 --> Hooks Class Initialized
DEBUG - 2018-07-15 06:11:29 --> UTF-8 Support Enabled
INFO - 2018-07-15 06:11:29 --> Utf8 Class Initialized
INFO - 2018-07-15 06:11:29 --> URI Class Initialized
INFO - 2018-07-15 06:11:29 --> Router Class Initialized
INFO - 2018-07-15 06:11:29 --> Output Class Initialized
INFO - 2018-07-15 06:11:29 --> Security Class Initialized
DEBUG - 2018-07-15 06:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 06:11:29 --> Input Class Initialized
INFO - 2018-07-15 06:11:29 --> Language Class Initialized
INFO - 2018-07-15 06:11:29 --> Loader Class Initialized
INFO - 2018-07-15 06:11:29 --> Controller Class Initialized
INFO - 2018-07-15 06:11:29 --> Database Driver Class Initialized
INFO - 2018-07-15 06:11:29 --> Model Class Initialized
INFO - 2018-07-15 06:11:29 --> Helper loaded: url_helper
INFO - 2018-07-15 06:11:29 --> Model Class Initialized
INFO - 2018-07-15 06:11:29 --> Final output sent to browser
DEBUG - 2018-07-15 06:11:29 --> Total execution time: 0.0384
ERROR - 2018-07-15 06:11:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 06:11:55 --> Config Class Initialized
INFO - 2018-07-15 06:11:55 --> Hooks Class Initialized
DEBUG - 2018-07-15 06:11:55 --> UTF-8 Support Enabled
INFO - 2018-07-15 06:11:55 --> Utf8 Class Initialized
INFO - 2018-07-15 06:11:55 --> URI Class Initialized
INFO - 2018-07-15 06:11:55 --> Router Class Initialized
INFO - 2018-07-15 06:11:55 --> Output Class Initialized
INFO - 2018-07-15 06:11:55 --> Security Class Initialized
DEBUG - 2018-07-15 06:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 06:11:55 --> Input Class Initialized
INFO - 2018-07-15 06:11:55 --> Language Class Initialized
INFO - 2018-07-15 06:11:55 --> Loader Class Initialized
INFO - 2018-07-15 06:11:55 --> Controller Class Initialized
INFO - 2018-07-15 06:11:55 --> Database Driver Class Initialized
INFO - 2018-07-15 06:11:55 --> Model Class Initialized
INFO - 2018-07-15 06:11:55 --> Helper loaded: url_helper
INFO - 2018-07-15 06:11:55 --> Model Class Initialized
INFO - 2018-07-15 06:11:55 --> Final output sent to browser
DEBUG - 2018-07-15 06:11:55 --> Total execution time: 0.0484
ERROR - 2018-07-15 06:12:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 06:12:02 --> Config Class Initialized
INFO - 2018-07-15 06:12:02 --> Hooks Class Initialized
DEBUG - 2018-07-15 06:12:02 --> UTF-8 Support Enabled
INFO - 2018-07-15 06:12:02 --> Utf8 Class Initialized
INFO - 2018-07-15 06:12:02 --> URI Class Initialized
INFO - 2018-07-15 06:12:02 --> Router Class Initialized
INFO - 2018-07-15 06:12:02 --> Output Class Initialized
INFO - 2018-07-15 06:12:02 --> Security Class Initialized
DEBUG - 2018-07-15 06:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 06:12:02 --> Input Class Initialized
INFO - 2018-07-15 06:12:02 --> Language Class Initialized
INFO - 2018-07-15 06:12:02 --> Loader Class Initialized
INFO - 2018-07-15 06:12:02 --> Controller Class Initialized
INFO - 2018-07-15 06:12:02 --> Database Driver Class Initialized
INFO - 2018-07-15 06:12:02 --> Model Class Initialized
INFO - 2018-07-15 06:12:02 --> Helper loaded: url_helper
INFO - 2018-07-15 06:12:02 --> Model Class Initialized
INFO - 2018-07-15 06:12:02 --> Final output sent to browser
DEBUG - 2018-07-15 06:12:02 --> Total execution time: 0.1001
ERROR - 2018-07-15 06:23:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 06:23:32 --> Config Class Initialized
INFO - 2018-07-15 06:23:32 --> Hooks Class Initialized
DEBUG - 2018-07-15 06:23:32 --> UTF-8 Support Enabled
INFO - 2018-07-15 06:23:32 --> Utf8 Class Initialized
INFO - 2018-07-15 06:23:32 --> URI Class Initialized
INFO - 2018-07-15 06:23:32 --> Router Class Initialized
INFO - 2018-07-15 06:23:32 --> Output Class Initialized
INFO - 2018-07-15 06:23:32 --> Security Class Initialized
DEBUG - 2018-07-15 06:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 06:23:32 --> Input Class Initialized
INFO - 2018-07-15 06:23:32 --> Language Class Initialized
INFO - 2018-07-15 06:23:32 --> Loader Class Initialized
INFO - 2018-07-15 06:23:32 --> Controller Class Initialized
INFO - 2018-07-15 06:23:32 --> Database Driver Class Initialized
INFO - 2018-07-15 06:23:32 --> Model Class Initialized
INFO - 2018-07-15 06:23:32 --> Helper loaded: url_helper
INFO - 2018-07-15 06:23:32 --> Model Class Initialized
INFO - 2018-07-15 06:23:32 --> Final output sent to browser
DEBUG - 2018-07-15 06:23:32 --> Total execution time: 0.0433
ERROR - 2018-07-15 06:53:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 06:53:57 --> Config Class Initialized
INFO - 2018-07-15 06:53:57 --> Hooks Class Initialized
DEBUG - 2018-07-15 06:53:57 --> UTF-8 Support Enabled
INFO - 2018-07-15 06:53:57 --> Utf8 Class Initialized
INFO - 2018-07-15 06:53:57 --> URI Class Initialized
INFO - 2018-07-15 06:53:57 --> Router Class Initialized
INFO - 2018-07-15 06:53:57 --> Output Class Initialized
INFO - 2018-07-15 06:53:57 --> Security Class Initialized
DEBUG - 2018-07-15 06:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 06:53:57 --> Input Class Initialized
INFO - 2018-07-15 06:53:57 --> Language Class Initialized
INFO - 2018-07-15 06:53:57 --> Loader Class Initialized
INFO - 2018-07-15 06:53:57 --> Controller Class Initialized
INFO - 2018-07-15 06:53:57 --> Database Driver Class Initialized
INFO - 2018-07-15 06:53:57 --> Model Class Initialized
INFO - 2018-07-15 06:53:57 --> Helper loaded: url_helper
INFO - 2018-07-15 06:53:57 --> Model Class Initialized
ERROR - 2018-07-15 06:53:57 --> Severity: Notice --> Undefined index: user_id C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 29
ERROR - 2018-07-15 06:53:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\davidhood\application\models\Mobile_model.php 37
INFO - 2018-07-15 06:53:57 --> Final output sent to browser
DEBUG - 2018-07-15 06:53:57 --> Total execution time: 0.0446
ERROR - 2018-07-15 06:54:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 06:54:03 --> Config Class Initialized
INFO - 2018-07-15 06:54:03 --> Hooks Class Initialized
DEBUG - 2018-07-15 06:54:03 --> UTF-8 Support Enabled
INFO - 2018-07-15 06:54:03 --> Utf8 Class Initialized
INFO - 2018-07-15 06:54:03 --> URI Class Initialized
INFO - 2018-07-15 06:54:03 --> Router Class Initialized
INFO - 2018-07-15 06:54:03 --> Output Class Initialized
INFO - 2018-07-15 06:54:03 --> Security Class Initialized
DEBUG - 2018-07-15 06:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 06:54:03 --> Input Class Initialized
INFO - 2018-07-15 06:54:03 --> Language Class Initialized
INFO - 2018-07-15 06:54:03 --> Loader Class Initialized
INFO - 2018-07-15 06:54:03 --> Controller Class Initialized
INFO - 2018-07-15 06:54:03 --> Database Driver Class Initialized
INFO - 2018-07-15 06:54:03 --> Model Class Initialized
INFO - 2018-07-15 06:54:03 --> Helper loaded: url_helper
INFO - 2018-07-15 06:54:03 --> Model Class Initialized
INFO - 2018-07-15 06:54:03 --> Final output sent to browser
DEBUG - 2018-07-15 06:54:03 --> Total execution time: 0.5595
ERROR - 2018-07-15 06:54:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 06:54:11 --> Config Class Initialized
INFO - 2018-07-15 06:54:11 --> Hooks Class Initialized
DEBUG - 2018-07-15 06:54:12 --> UTF-8 Support Enabled
INFO - 2018-07-15 06:54:12 --> Utf8 Class Initialized
INFO - 2018-07-15 06:54:12 --> URI Class Initialized
INFO - 2018-07-15 06:54:12 --> Router Class Initialized
INFO - 2018-07-15 06:54:12 --> Output Class Initialized
INFO - 2018-07-15 06:54:12 --> Security Class Initialized
DEBUG - 2018-07-15 06:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 06:54:12 --> Input Class Initialized
INFO - 2018-07-15 06:54:12 --> Language Class Initialized
INFO - 2018-07-15 06:54:12 --> Loader Class Initialized
INFO - 2018-07-15 06:54:12 --> Controller Class Initialized
INFO - 2018-07-15 06:54:12 --> Database Driver Class Initialized
INFO - 2018-07-15 06:54:12 --> Model Class Initialized
INFO - 2018-07-15 06:54:12 --> Helper loaded: url_helper
INFO - 2018-07-15 06:54:12 --> Model Class Initialized
INFO - 2018-07-15 06:54:12 --> Final output sent to browser
DEBUG - 2018-07-15 06:54:12 --> Total execution time: 0.0589
ERROR - 2018-07-15 07:19:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:19:00 --> Config Class Initialized
INFO - 2018-07-15 07:19:00 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:19:00 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:19:00 --> Utf8 Class Initialized
INFO - 2018-07-15 07:19:00 --> URI Class Initialized
INFO - 2018-07-15 07:19:00 --> Router Class Initialized
INFO - 2018-07-15 07:19:00 --> Output Class Initialized
INFO - 2018-07-15 07:19:00 --> Security Class Initialized
DEBUG - 2018-07-15 07:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:19:00 --> Input Class Initialized
INFO - 2018-07-15 07:19:00 --> Language Class Initialized
INFO - 2018-07-15 07:19:00 --> Loader Class Initialized
INFO - 2018-07-15 07:19:00 --> Controller Class Initialized
INFO - 2018-07-15 07:19:00 --> Database Driver Class Initialized
INFO - 2018-07-15 07:19:00 --> Model Class Initialized
INFO - 2018-07-15 07:19:00 --> Helper loaded: url_helper
INFO - 2018-07-15 07:19:00 --> Model Class Initialized
INFO - 2018-07-15 07:19:00 --> Final output sent to browser
DEBUG - 2018-07-15 07:19:00 --> Total execution time: 0.0430
ERROR - 2018-07-15 07:20:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:20:22 --> Config Class Initialized
INFO - 2018-07-15 07:20:22 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:20:22 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:20:22 --> Utf8 Class Initialized
INFO - 2018-07-15 07:20:22 --> URI Class Initialized
INFO - 2018-07-15 07:20:22 --> Router Class Initialized
INFO - 2018-07-15 07:20:22 --> Output Class Initialized
INFO - 2018-07-15 07:20:22 --> Security Class Initialized
DEBUG - 2018-07-15 07:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:20:22 --> Input Class Initialized
INFO - 2018-07-15 07:20:22 --> Language Class Initialized
INFO - 2018-07-15 07:20:22 --> Loader Class Initialized
INFO - 2018-07-15 07:20:22 --> Controller Class Initialized
INFO - 2018-07-15 07:20:22 --> Database Driver Class Initialized
INFO - 2018-07-15 07:20:22 --> Model Class Initialized
INFO - 2018-07-15 07:20:22 --> Helper loaded: url_helper
INFO - 2018-07-15 07:20:22 --> Model Class Initialized
INFO - 2018-07-15 07:20:22 --> Final output sent to browser
DEBUG - 2018-07-15 07:20:22 --> Total execution time: 0.0585
ERROR - 2018-07-15 07:20:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:20:23 --> Config Class Initialized
INFO - 2018-07-15 07:20:23 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:20:23 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:20:23 --> Utf8 Class Initialized
INFO - 2018-07-15 07:20:23 --> URI Class Initialized
INFO - 2018-07-15 07:20:23 --> Router Class Initialized
INFO - 2018-07-15 07:20:23 --> Output Class Initialized
INFO - 2018-07-15 07:20:23 --> Security Class Initialized
DEBUG - 2018-07-15 07:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:20:23 --> Input Class Initialized
INFO - 2018-07-15 07:20:23 --> Language Class Initialized
INFO - 2018-07-15 07:20:23 --> Loader Class Initialized
INFO - 2018-07-15 07:20:23 --> Controller Class Initialized
INFO - 2018-07-15 07:20:23 --> Database Driver Class Initialized
INFO - 2018-07-15 07:20:23 --> Model Class Initialized
INFO - 2018-07-15 07:20:23 --> Helper loaded: url_helper
INFO - 2018-07-15 07:20:23 --> Model Class Initialized
INFO - 2018-07-15 07:20:23 --> Final output sent to browser
DEBUG - 2018-07-15 07:20:23 --> Total execution time: 0.0405
ERROR - 2018-07-15 07:20:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:20:24 --> Config Class Initialized
INFO - 2018-07-15 07:20:24 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:20:24 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:20:24 --> Utf8 Class Initialized
INFO - 2018-07-15 07:20:24 --> URI Class Initialized
INFO - 2018-07-15 07:20:24 --> Router Class Initialized
INFO - 2018-07-15 07:20:24 --> Output Class Initialized
INFO - 2018-07-15 07:20:24 --> Security Class Initialized
DEBUG - 2018-07-15 07:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:20:24 --> Input Class Initialized
INFO - 2018-07-15 07:20:24 --> Language Class Initialized
INFO - 2018-07-15 07:20:24 --> Loader Class Initialized
INFO - 2018-07-15 07:20:24 --> Controller Class Initialized
INFO - 2018-07-15 07:20:24 --> Database Driver Class Initialized
INFO - 2018-07-15 07:20:24 --> Model Class Initialized
INFO - 2018-07-15 07:20:24 --> Helper loaded: url_helper
INFO - 2018-07-15 07:20:24 --> Model Class Initialized
INFO - 2018-07-15 07:20:24 --> Final output sent to browser
DEBUG - 2018-07-15 07:20:24 --> Total execution time: 0.0521
ERROR - 2018-07-15 07:20:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:20:43 --> Config Class Initialized
INFO - 2018-07-15 07:20:43 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:20:43 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:20:43 --> Utf8 Class Initialized
INFO - 2018-07-15 07:20:43 --> URI Class Initialized
INFO - 2018-07-15 07:20:43 --> Router Class Initialized
INFO - 2018-07-15 07:20:43 --> Output Class Initialized
INFO - 2018-07-15 07:20:43 --> Security Class Initialized
DEBUG - 2018-07-15 07:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:20:43 --> Input Class Initialized
INFO - 2018-07-15 07:20:43 --> Language Class Initialized
INFO - 2018-07-15 07:20:43 --> Loader Class Initialized
INFO - 2018-07-15 07:20:43 --> Controller Class Initialized
INFO - 2018-07-15 07:20:43 --> Database Driver Class Initialized
INFO - 2018-07-15 07:20:43 --> Model Class Initialized
INFO - 2018-07-15 07:20:43 --> Helper loaded: url_helper
INFO - 2018-07-15 07:20:43 --> Model Class Initialized
INFO - 2018-07-15 07:20:43 --> Final output sent to browser
DEBUG - 2018-07-15 07:20:43 --> Total execution time: 0.0380
ERROR - 2018-07-15 07:20:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:20:44 --> Config Class Initialized
INFO - 2018-07-15 07:20:44 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:20:44 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:20:44 --> Utf8 Class Initialized
INFO - 2018-07-15 07:20:44 --> URI Class Initialized
INFO - 2018-07-15 07:20:44 --> Router Class Initialized
INFO - 2018-07-15 07:20:44 --> Output Class Initialized
INFO - 2018-07-15 07:20:44 --> Security Class Initialized
DEBUG - 2018-07-15 07:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:20:44 --> Input Class Initialized
INFO - 2018-07-15 07:20:44 --> Language Class Initialized
INFO - 2018-07-15 07:20:44 --> Loader Class Initialized
INFO - 2018-07-15 07:20:44 --> Controller Class Initialized
INFO - 2018-07-15 07:20:44 --> Database Driver Class Initialized
INFO - 2018-07-15 07:20:44 --> Model Class Initialized
INFO - 2018-07-15 07:20:44 --> Helper loaded: url_helper
INFO - 2018-07-15 07:20:44 --> Model Class Initialized
INFO - 2018-07-15 07:20:44 --> Final output sent to browser
DEBUG - 2018-07-15 07:20:44 --> Total execution time: 0.0485
ERROR - 2018-07-15 07:20:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:20:45 --> Config Class Initialized
INFO - 2018-07-15 07:20:45 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:20:45 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:20:45 --> Utf8 Class Initialized
INFO - 2018-07-15 07:20:45 --> URI Class Initialized
INFO - 2018-07-15 07:20:45 --> Router Class Initialized
INFO - 2018-07-15 07:20:45 --> Output Class Initialized
INFO - 2018-07-15 07:20:45 --> Security Class Initialized
DEBUG - 2018-07-15 07:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:20:45 --> Input Class Initialized
INFO - 2018-07-15 07:20:45 --> Language Class Initialized
INFO - 2018-07-15 07:20:45 --> Loader Class Initialized
INFO - 2018-07-15 07:20:45 --> Controller Class Initialized
INFO - 2018-07-15 07:20:45 --> Database Driver Class Initialized
INFO - 2018-07-15 07:20:45 --> Model Class Initialized
INFO - 2018-07-15 07:20:45 --> Helper loaded: url_helper
INFO - 2018-07-15 07:20:45 --> Model Class Initialized
INFO - 2018-07-15 07:20:45 --> Final output sent to browser
DEBUG - 2018-07-15 07:20:45 --> Total execution time: 0.0485
ERROR - 2018-07-15 07:21:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:21:40 --> Config Class Initialized
INFO - 2018-07-15 07:21:40 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:21:40 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:21:40 --> Utf8 Class Initialized
INFO - 2018-07-15 07:21:40 --> URI Class Initialized
INFO - 2018-07-15 07:21:40 --> Router Class Initialized
INFO - 2018-07-15 07:21:40 --> Output Class Initialized
INFO - 2018-07-15 07:21:40 --> Security Class Initialized
DEBUG - 2018-07-15 07:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:21:40 --> Input Class Initialized
INFO - 2018-07-15 07:21:40 --> Language Class Initialized
INFO - 2018-07-15 07:21:40 --> Loader Class Initialized
INFO - 2018-07-15 07:21:40 --> Controller Class Initialized
INFO - 2018-07-15 07:21:40 --> Database Driver Class Initialized
INFO - 2018-07-15 07:21:40 --> Model Class Initialized
INFO - 2018-07-15 07:21:40 --> Helper loaded: url_helper
INFO - 2018-07-15 07:21:40 --> Model Class Initialized
INFO - 2018-07-15 07:21:40 --> Final output sent to browser
DEBUG - 2018-07-15 07:21:40 --> Total execution time: 0.0530
ERROR - 2018-07-15 07:21:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:21:41 --> Config Class Initialized
INFO - 2018-07-15 07:21:41 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:21:41 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:21:41 --> Utf8 Class Initialized
INFO - 2018-07-15 07:21:41 --> URI Class Initialized
INFO - 2018-07-15 07:21:41 --> Router Class Initialized
INFO - 2018-07-15 07:21:41 --> Output Class Initialized
INFO - 2018-07-15 07:21:41 --> Security Class Initialized
DEBUG - 2018-07-15 07:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:21:41 --> Input Class Initialized
INFO - 2018-07-15 07:21:41 --> Language Class Initialized
INFO - 2018-07-15 07:21:41 --> Loader Class Initialized
INFO - 2018-07-15 07:21:41 --> Controller Class Initialized
INFO - 2018-07-15 07:21:41 --> Database Driver Class Initialized
INFO - 2018-07-15 07:21:41 --> Model Class Initialized
INFO - 2018-07-15 07:21:41 --> Helper loaded: url_helper
INFO - 2018-07-15 07:21:41 --> Model Class Initialized
INFO - 2018-07-15 07:21:41 --> Final output sent to browser
DEBUG - 2018-07-15 07:21:41 --> Total execution time: 0.0878
ERROR - 2018-07-15 07:21:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:21:42 --> Config Class Initialized
INFO - 2018-07-15 07:21:42 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:21:42 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:21:42 --> Utf8 Class Initialized
INFO - 2018-07-15 07:21:42 --> URI Class Initialized
INFO - 2018-07-15 07:21:42 --> Router Class Initialized
INFO - 2018-07-15 07:21:42 --> Output Class Initialized
INFO - 2018-07-15 07:21:42 --> Security Class Initialized
DEBUG - 2018-07-15 07:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:21:42 --> Input Class Initialized
INFO - 2018-07-15 07:21:42 --> Language Class Initialized
INFO - 2018-07-15 07:21:42 --> Loader Class Initialized
INFO - 2018-07-15 07:21:42 --> Controller Class Initialized
INFO - 2018-07-15 07:21:42 --> Database Driver Class Initialized
INFO - 2018-07-15 07:21:42 --> Model Class Initialized
INFO - 2018-07-15 07:21:42 --> Helper loaded: url_helper
INFO - 2018-07-15 07:21:42 --> Model Class Initialized
INFO - 2018-07-15 07:21:42 --> Final output sent to browser
DEBUG - 2018-07-15 07:21:42 --> Total execution time: 0.0400
ERROR - 2018-07-15 07:22:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:22:17 --> Config Class Initialized
INFO - 2018-07-15 07:22:17 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:22:17 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:22:17 --> Utf8 Class Initialized
INFO - 2018-07-15 07:22:17 --> URI Class Initialized
INFO - 2018-07-15 07:22:17 --> Router Class Initialized
INFO - 2018-07-15 07:22:17 --> Output Class Initialized
INFO - 2018-07-15 07:22:17 --> Security Class Initialized
DEBUG - 2018-07-15 07:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:22:17 --> Input Class Initialized
INFO - 2018-07-15 07:22:17 --> Language Class Initialized
INFO - 2018-07-15 07:22:17 --> Loader Class Initialized
INFO - 2018-07-15 07:22:17 --> Controller Class Initialized
INFO - 2018-07-15 07:22:17 --> Database Driver Class Initialized
INFO - 2018-07-15 07:22:17 --> Model Class Initialized
INFO - 2018-07-15 07:22:17 --> Helper loaded: url_helper
INFO - 2018-07-15 07:22:17 --> Model Class Initialized
INFO - 2018-07-15 07:22:17 --> Final output sent to browser
DEBUG - 2018-07-15 07:22:17 --> Total execution time: 0.0509
ERROR - 2018-07-15 07:22:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:22:54 --> Config Class Initialized
INFO - 2018-07-15 07:22:54 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:22:54 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:22:54 --> Utf8 Class Initialized
INFO - 2018-07-15 07:22:54 --> URI Class Initialized
INFO - 2018-07-15 07:22:54 --> Router Class Initialized
INFO - 2018-07-15 07:22:54 --> Output Class Initialized
INFO - 2018-07-15 07:22:54 --> Security Class Initialized
DEBUG - 2018-07-15 07:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:22:54 --> Input Class Initialized
INFO - 2018-07-15 07:22:54 --> Language Class Initialized
INFO - 2018-07-15 07:22:54 --> Loader Class Initialized
INFO - 2018-07-15 07:22:54 --> Controller Class Initialized
INFO - 2018-07-15 07:22:54 --> Database Driver Class Initialized
INFO - 2018-07-15 07:22:54 --> Model Class Initialized
INFO - 2018-07-15 07:22:54 --> Helper loaded: url_helper
INFO - 2018-07-15 07:22:54 --> Model Class Initialized
INFO - 2018-07-15 07:22:54 --> Final output sent to browser
DEBUG - 2018-07-15 07:22:54 --> Total execution time: 0.0483
ERROR - 2018-07-15 07:36:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:36:40 --> Config Class Initialized
INFO - 2018-07-15 07:36:40 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:36:40 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:36:40 --> Utf8 Class Initialized
INFO - 2018-07-15 07:36:40 --> URI Class Initialized
INFO - 2018-07-15 07:36:40 --> Router Class Initialized
INFO - 2018-07-15 07:36:40 --> Output Class Initialized
INFO - 2018-07-15 07:36:40 --> Security Class Initialized
DEBUG - 2018-07-15 07:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:36:40 --> Input Class Initialized
INFO - 2018-07-15 07:36:40 --> Language Class Initialized
INFO - 2018-07-15 07:36:40 --> Loader Class Initialized
INFO - 2018-07-15 07:36:40 --> Controller Class Initialized
INFO - 2018-07-15 07:36:40 --> Database Driver Class Initialized
INFO - 2018-07-15 07:36:40 --> Model Class Initialized
INFO - 2018-07-15 07:36:40 --> Helper loaded: url_helper
INFO - 2018-07-15 07:36:40 --> Model Class Initialized
INFO - 2018-07-15 07:36:40 --> Final output sent to browser
DEBUG - 2018-07-15 07:36:40 --> Total execution time: 0.0365
ERROR - 2018-07-15 07:36:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:36:42 --> Config Class Initialized
INFO - 2018-07-15 07:36:42 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:36:42 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:36:42 --> Utf8 Class Initialized
INFO - 2018-07-15 07:36:42 --> URI Class Initialized
INFO - 2018-07-15 07:36:42 --> Router Class Initialized
INFO - 2018-07-15 07:36:42 --> Output Class Initialized
INFO - 2018-07-15 07:36:42 --> Security Class Initialized
DEBUG - 2018-07-15 07:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:36:42 --> Input Class Initialized
INFO - 2018-07-15 07:36:42 --> Language Class Initialized
INFO - 2018-07-15 07:36:42 --> Loader Class Initialized
INFO - 2018-07-15 07:36:42 --> Controller Class Initialized
INFO - 2018-07-15 07:36:42 --> Database Driver Class Initialized
INFO - 2018-07-15 07:36:42 --> Model Class Initialized
INFO - 2018-07-15 07:36:42 --> Helper loaded: url_helper
INFO - 2018-07-15 07:36:42 --> Model Class Initialized
INFO - 2018-07-15 07:36:42 --> Final output sent to browser
DEBUG - 2018-07-15 07:36:42 --> Total execution time: 0.0467
ERROR - 2018-07-15 07:36:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:36:42 --> Config Class Initialized
INFO - 2018-07-15 07:36:42 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:36:42 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:36:42 --> Utf8 Class Initialized
INFO - 2018-07-15 07:36:42 --> URI Class Initialized
INFO - 2018-07-15 07:36:42 --> Router Class Initialized
INFO - 2018-07-15 07:36:42 --> Output Class Initialized
INFO - 2018-07-15 07:36:42 --> Security Class Initialized
DEBUG - 2018-07-15 07:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:36:42 --> Input Class Initialized
INFO - 2018-07-15 07:36:42 --> Language Class Initialized
INFO - 2018-07-15 07:36:42 --> Loader Class Initialized
INFO - 2018-07-15 07:36:42 --> Controller Class Initialized
INFO - 2018-07-15 07:36:42 --> Database Driver Class Initialized
INFO - 2018-07-15 07:36:42 --> Model Class Initialized
INFO - 2018-07-15 07:36:42 --> Helper loaded: url_helper
INFO - 2018-07-15 07:36:42 --> Model Class Initialized
INFO - 2018-07-15 07:36:42 --> Final output sent to browser
DEBUG - 2018-07-15 07:36:42 --> Total execution time: 0.0472
ERROR - 2018-07-15 07:37:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:37:34 --> Config Class Initialized
INFO - 2018-07-15 07:37:34 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:37:34 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:37:34 --> Utf8 Class Initialized
INFO - 2018-07-15 07:37:34 --> URI Class Initialized
INFO - 2018-07-15 07:37:34 --> Router Class Initialized
INFO - 2018-07-15 07:37:34 --> Output Class Initialized
INFO - 2018-07-15 07:37:34 --> Security Class Initialized
DEBUG - 2018-07-15 07:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:37:34 --> Input Class Initialized
INFO - 2018-07-15 07:37:34 --> Language Class Initialized
INFO - 2018-07-15 07:37:34 --> Loader Class Initialized
INFO - 2018-07-15 07:37:34 --> Controller Class Initialized
INFO - 2018-07-15 07:37:34 --> Database Driver Class Initialized
INFO - 2018-07-15 07:37:34 --> Model Class Initialized
INFO - 2018-07-15 07:37:34 --> Helper loaded: url_helper
INFO - 2018-07-15 07:37:34 --> Model Class Initialized
INFO - 2018-07-15 07:37:34 --> Final output sent to browser
DEBUG - 2018-07-15 07:37:34 --> Total execution time: 0.0438
ERROR - 2018-07-15 07:37:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:37:36 --> Config Class Initialized
INFO - 2018-07-15 07:37:36 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:37:36 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:37:36 --> Utf8 Class Initialized
INFO - 2018-07-15 07:37:36 --> URI Class Initialized
INFO - 2018-07-15 07:37:36 --> Router Class Initialized
INFO - 2018-07-15 07:37:36 --> Output Class Initialized
INFO - 2018-07-15 07:37:36 --> Security Class Initialized
DEBUG - 2018-07-15 07:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:37:36 --> Input Class Initialized
INFO - 2018-07-15 07:37:36 --> Language Class Initialized
INFO - 2018-07-15 07:37:36 --> Loader Class Initialized
INFO - 2018-07-15 07:37:36 --> Controller Class Initialized
INFO - 2018-07-15 07:37:36 --> Database Driver Class Initialized
INFO - 2018-07-15 07:37:36 --> Model Class Initialized
INFO - 2018-07-15 07:37:36 --> Helper loaded: url_helper
INFO - 2018-07-15 07:37:36 --> Model Class Initialized
INFO - 2018-07-15 07:37:36 --> Final output sent to browser
DEBUG - 2018-07-15 07:37:36 --> Total execution time: 0.0393
ERROR - 2018-07-15 07:37:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:37:36 --> Config Class Initialized
INFO - 2018-07-15 07:37:36 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:37:36 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:37:36 --> Utf8 Class Initialized
INFO - 2018-07-15 07:37:36 --> URI Class Initialized
INFO - 2018-07-15 07:37:36 --> Router Class Initialized
INFO - 2018-07-15 07:37:36 --> Output Class Initialized
INFO - 2018-07-15 07:37:36 --> Security Class Initialized
DEBUG - 2018-07-15 07:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:37:36 --> Input Class Initialized
INFO - 2018-07-15 07:37:36 --> Language Class Initialized
INFO - 2018-07-15 07:37:36 --> Loader Class Initialized
INFO - 2018-07-15 07:37:36 --> Controller Class Initialized
INFO - 2018-07-15 07:37:36 --> Database Driver Class Initialized
INFO - 2018-07-15 07:37:36 --> Model Class Initialized
INFO - 2018-07-15 07:37:36 --> Helper loaded: url_helper
INFO - 2018-07-15 07:37:36 --> Model Class Initialized
INFO - 2018-07-15 07:37:36 --> Final output sent to browser
DEBUG - 2018-07-15 07:37:36 --> Total execution time: 0.0376
ERROR - 2018-07-15 07:40:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:28 --> Config Class Initialized
INFO - 2018-07-15 07:40:28 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:28 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:28 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:28 --> URI Class Initialized
INFO - 2018-07-15 07:40:28 --> Router Class Initialized
INFO - 2018-07-15 07:40:28 --> Output Class Initialized
INFO - 2018-07-15 07:40:28 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:28 --> Input Class Initialized
INFO - 2018-07-15 07:40:28 --> Language Class Initialized
INFO - 2018-07-15 07:40:28 --> Loader Class Initialized
INFO - 2018-07-15 07:40:28 --> Controller Class Initialized
INFO - 2018-07-15 07:40:28 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:28 --> Model Class Initialized
INFO - 2018-07-15 07:40:28 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:28 --> Model Class Initialized
INFO - 2018-07-15 07:40:28 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:28 --> Total execution time: 0.0348
ERROR - 2018-07-15 07:40:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:30 --> Config Class Initialized
INFO - 2018-07-15 07:40:30 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:30 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:30 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:30 --> URI Class Initialized
INFO - 2018-07-15 07:40:30 --> Router Class Initialized
INFO - 2018-07-15 07:40:30 --> Output Class Initialized
INFO - 2018-07-15 07:40:30 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:30 --> Input Class Initialized
INFO - 2018-07-15 07:40:30 --> Language Class Initialized
INFO - 2018-07-15 07:40:30 --> Loader Class Initialized
INFO - 2018-07-15 07:40:30 --> Controller Class Initialized
INFO - 2018-07-15 07:40:30 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:30 --> Model Class Initialized
INFO - 2018-07-15 07:40:30 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:30 --> Model Class Initialized
INFO - 2018-07-15 07:40:30 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:30 --> Total execution time: 0.0378
ERROR - 2018-07-15 07:40:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:31 --> Config Class Initialized
INFO - 2018-07-15 07:40:31 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:31 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:31 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:31 --> URI Class Initialized
INFO - 2018-07-15 07:40:31 --> Router Class Initialized
INFO - 2018-07-15 07:40:31 --> Output Class Initialized
INFO - 2018-07-15 07:40:31 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:31 --> Input Class Initialized
INFO - 2018-07-15 07:40:31 --> Language Class Initialized
INFO - 2018-07-15 07:40:31 --> Loader Class Initialized
INFO - 2018-07-15 07:40:31 --> Controller Class Initialized
INFO - 2018-07-15 07:40:31 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:31 --> Model Class Initialized
INFO - 2018-07-15 07:40:31 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:31 --> Model Class Initialized
INFO - 2018-07-15 07:40:31 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:31 --> Total execution time: 0.0488
ERROR - 2018-07-15 07:40:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:31 --> Config Class Initialized
INFO - 2018-07-15 07:40:31 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:31 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:31 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:31 --> URI Class Initialized
INFO - 2018-07-15 07:40:31 --> Router Class Initialized
INFO - 2018-07-15 07:40:31 --> Output Class Initialized
INFO - 2018-07-15 07:40:31 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:31 --> Input Class Initialized
INFO - 2018-07-15 07:40:31 --> Language Class Initialized
INFO - 2018-07-15 07:40:31 --> Loader Class Initialized
INFO - 2018-07-15 07:40:31 --> Controller Class Initialized
INFO - 2018-07-15 07:40:31 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:31 --> Model Class Initialized
INFO - 2018-07-15 07:40:31 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:31 --> Model Class Initialized
INFO - 2018-07-15 07:40:31 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:31 --> Total execution time: 0.0509
ERROR - 2018-07-15 07:40:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:32 --> Config Class Initialized
INFO - 2018-07-15 07:40:32 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:32 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:32 --> URI Class Initialized
INFO - 2018-07-15 07:40:32 --> Router Class Initialized
INFO - 2018-07-15 07:40:32 --> Output Class Initialized
INFO - 2018-07-15 07:40:32 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:32 --> Input Class Initialized
INFO - 2018-07-15 07:40:32 --> Language Class Initialized
INFO - 2018-07-15 07:40:32 --> Loader Class Initialized
INFO - 2018-07-15 07:40:32 --> Controller Class Initialized
INFO - 2018-07-15 07:40:32 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:32 --> Model Class Initialized
INFO - 2018-07-15 07:40:32 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:32 --> Model Class Initialized
INFO - 2018-07-15 07:40:32 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:32 --> Total execution time: 0.0541
ERROR - 2018-07-15 07:40:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:32 --> Config Class Initialized
INFO - 2018-07-15 07:40:32 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:32 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:32 --> URI Class Initialized
INFO - 2018-07-15 07:40:32 --> Router Class Initialized
INFO - 2018-07-15 07:40:32 --> Output Class Initialized
INFO - 2018-07-15 07:40:32 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:32 --> Input Class Initialized
INFO - 2018-07-15 07:40:32 --> Language Class Initialized
INFO - 2018-07-15 07:40:32 --> Loader Class Initialized
INFO - 2018-07-15 07:40:32 --> Controller Class Initialized
INFO - 2018-07-15 07:40:32 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:32 --> Model Class Initialized
INFO - 2018-07-15 07:40:32 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:32 --> Model Class Initialized
INFO - 2018-07-15 07:40:32 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:32 --> Total execution time: 0.0507
ERROR - 2018-07-15 07:40:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:32 --> Config Class Initialized
INFO - 2018-07-15 07:40:32 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:32 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:32 --> URI Class Initialized
INFO - 2018-07-15 07:40:32 --> Router Class Initialized
INFO - 2018-07-15 07:40:32 --> Output Class Initialized
INFO - 2018-07-15 07:40:32 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:32 --> Input Class Initialized
INFO - 2018-07-15 07:40:32 --> Language Class Initialized
INFO - 2018-07-15 07:40:32 --> Loader Class Initialized
INFO - 2018-07-15 07:40:32 --> Controller Class Initialized
INFO - 2018-07-15 07:40:32 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:32 --> Model Class Initialized
INFO - 2018-07-15 07:40:32 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:32 --> Model Class Initialized
INFO - 2018-07-15 07:40:32 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:32 --> Total execution time: 0.0461
ERROR - 2018-07-15 07:40:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:32 --> Config Class Initialized
INFO - 2018-07-15 07:40:32 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:32 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:32 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:32 --> URI Class Initialized
INFO - 2018-07-15 07:40:32 --> Router Class Initialized
INFO - 2018-07-15 07:40:32 --> Output Class Initialized
INFO - 2018-07-15 07:40:32 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:32 --> Input Class Initialized
INFO - 2018-07-15 07:40:32 --> Language Class Initialized
INFO - 2018-07-15 07:40:32 --> Loader Class Initialized
INFO - 2018-07-15 07:40:32 --> Controller Class Initialized
INFO - 2018-07-15 07:40:33 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:33 --> Model Class Initialized
INFO - 2018-07-15 07:40:33 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:33 --> Model Class Initialized
INFO - 2018-07-15 07:40:33 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:33 --> Total execution time: 0.0591
ERROR - 2018-07-15 07:40:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:33 --> Config Class Initialized
INFO - 2018-07-15 07:40:33 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:33 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:33 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:33 --> URI Class Initialized
INFO - 2018-07-15 07:40:33 --> Router Class Initialized
INFO - 2018-07-15 07:40:33 --> Output Class Initialized
INFO - 2018-07-15 07:40:33 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:33 --> Input Class Initialized
INFO - 2018-07-15 07:40:33 --> Language Class Initialized
INFO - 2018-07-15 07:40:33 --> Loader Class Initialized
INFO - 2018-07-15 07:40:33 --> Controller Class Initialized
INFO - 2018-07-15 07:40:33 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:33 --> Model Class Initialized
INFO - 2018-07-15 07:40:33 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:33 --> Model Class Initialized
INFO - 2018-07-15 07:40:33 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:33 --> Total execution time: 0.0499
ERROR - 2018-07-15 07:40:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:33 --> Config Class Initialized
INFO - 2018-07-15 07:40:33 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:33 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:33 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:33 --> URI Class Initialized
INFO - 2018-07-15 07:40:33 --> Router Class Initialized
INFO - 2018-07-15 07:40:33 --> Output Class Initialized
INFO - 2018-07-15 07:40:33 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:33 --> Input Class Initialized
INFO - 2018-07-15 07:40:33 --> Language Class Initialized
INFO - 2018-07-15 07:40:33 --> Loader Class Initialized
INFO - 2018-07-15 07:40:33 --> Controller Class Initialized
INFO - 2018-07-15 07:40:33 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:33 --> Model Class Initialized
INFO - 2018-07-15 07:40:33 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:33 --> Model Class Initialized
INFO - 2018-07-15 07:40:33 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:33 --> Total execution time: 0.0509
ERROR - 2018-07-15 07:40:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:33 --> Config Class Initialized
INFO - 2018-07-15 07:40:33 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:33 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:33 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:33 --> URI Class Initialized
INFO - 2018-07-15 07:40:33 --> Router Class Initialized
INFO - 2018-07-15 07:40:33 --> Output Class Initialized
INFO - 2018-07-15 07:40:33 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:33 --> Input Class Initialized
INFO - 2018-07-15 07:40:33 --> Language Class Initialized
INFO - 2018-07-15 07:40:33 --> Loader Class Initialized
INFO - 2018-07-15 07:40:33 --> Controller Class Initialized
INFO - 2018-07-15 07:40:33 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:33 --> Model Class Initialized
INFO - 2018-07-15 07:40:33 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:33 --> Model Class Initialized
INFO - 2018-07-15 07:40:33 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:33 --> Total execution time: 0.0486
ERROR - 2018-07-15 07:40:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:33 --> Config Class Initialized
INFO - 2018-07-15 07:40:33 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:33 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:33 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:33 --> URI Class Initialized
INFO - 2018-07-15 07:40:33 --> Router Class Initialized
INFO - 2018-07-15 07:40:33 --> Output Class Initialized
INFO - 2018-07-15 07:40:33 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:33 --> Input Class Initialized
INFO - 2018-07-15 07:40:33 --> Language Class Initialized
INFO - 2018-07-15 07:40:33 --> Loader Class Initialized
INFO - 2018-07-15 07:40:33 --> Controller Class Initialized
INFO - 2018-07-15 07:40:33 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:33 --> Model Class Initialized
INFO - 2018-07-15 07:40:33 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:33 --> Model Class Initialized
INFO - 2018-07-15 07:40:33 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:33 --> Total execution time: 0.0480
ERROR - 2018-07-15 07:40:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:34 --> Config Class Initialized
INFO - 2018-07-15 07:40:34 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:34 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:34 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:34 --> URI Class Initialized
INFO - 2018-07-15 07:40:34 --> Router Class Initialized
INFO - 2018-07-15 07:40:34 --> Output Class Initialized
INFO - 2018-07-15 07:40:34 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:34 --> Input Class Initialized
INFO - 2018-07-15 07:40:34 --> Language Class Initialized
INFO - 2018-07-15 07:40:34 --> Loader Class Initialized
INFO - 2018-07-15 07:40:34 --> Controller Class Initialized
INFO - 2018-07-15 07:40:34 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:34 --> Model Class Initialized
INFO - 2018-07-15 07:40:34 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:34 --> Model Class Initialized
INFO - 2018-07-15 07:40:34 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:34 --> Total execution time: 0.0481
ERROR - 2018-07-15 07:40:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:34 --> Config Class Initialized
INFO - 2018-07-15 07:40:34 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:34 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:34 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:34 --> URI Class Initialized
INFO - 2018-07-15 07:40:34 --> Router Class Initialized
INFO - 2018-07-15 07:40:34 --> Output Class Initialized
INFO - 2018-07-15 07:40:34 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:34 --> Input Class Initialized
INFO - 2018-07-15 07:40:34 --> Language Class Initialized
INFO - 2018-07-15 07:40:34 --> Loader Class Initialized
INFO - 2018-07-15 07:40:34 --> Controller Class Initialized
INFO - 2018-07-15 07:40:34 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:34 --> Model Class Initialized
INFO - 2018-07-15 07:40:34 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:34 --> Model Class Initialized
INFO - 2018-07-15 07:40:34 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:34 --> Total execution time: 0.0422
ERROR - 2018-07-15 07:40:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:34 --> Config Class Initialized
INFO - 2018-07-15 07:40:34 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:34 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:34 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:34 --> URI Class Initialized
INFO - 2018-07-15 07:40:34 --> Router Class Initialized
INFO - 2018-07-15 07:40:34 --> Output Class Initialized
INFO - 2018-07-15 07:40:34 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:34 --> Input Class Initialized
INFO - 2018-07-15 07:40:34 --> Language Class Initialized
INFO - 2018-07-15 07:40:34 --> Loader Class Initialized
INFO - 2018-07-15 07:40:34 --> Controller Class Initialized
INFO - 2018-07-15 07:40:34 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:34 --> Model Class Initialized
INFO - 2018-07-15 07:40:34 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:34 --> Model Class Initialized
INFO - 2018-07-15 07:40:34 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:34 --> Total execution time: 0.0433
ERROR - 2018-07-15 07:40:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:34 --> Config Class Initialized
INFO - 2018-07-15 07:40:34 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:34 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:34 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:34 --> URI Class Initialized
INFO - 2018-07-15 07:40:34 --> Router Class Initialized
INFO - 2018-07-15 07:40:34 --> Output Class Initialized
INFO - 2018-07-15 07:40:34 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:34 --> Input Class Initialized
INFO - 2018-07-15 07:40:34 --> Language Class Initialized
INFO - 2018-07-15 07:40:34 --> Loader Class Initialized
INFO - 2018-07-15 07:40:34 --> Controller Class Initialized
INFO - 2018-07-15 07:40:34 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:34 --> Model Class Initialized
INFO - 2018-07-15 07:40:34 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:34 --> Model Class Initialized
INFO - 2018-07-15 07:40:34 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:34 --> Total execution time: 0.0477
ERROR - 2018-07-15 07:40:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:34 --> Config Class Initialized
INFO - 2018-07-15 07:40:34 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:34 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:34 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:35 --> URI Class Initialized
INFO - 2018-07-15 07:40:35 --> Router Class Initialized
INFO - 2018-07-15 07:40:35 --> Output Class Initialized
INFO - 2018-07-15 07:40:35 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:35 --> Input Class Initialized
INFO - 2018-07-15 07:40:35 --> Language Class Initialized
INFO - 2018-07-15 07:40:35 --> Loader Class Initialized
INFO - 2018-07-15 07:40:35 --> Controller Class Initialized
INFO - 2018-07-15 07:40:35 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:35 --> Model Class Initialized
INFO - 2018-07-15 07:40:35 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:35 --> Model Class Initialized
INFO - 2018-07-15 07:40:35 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:35 --> Total execution time: 0.0582
ERROR - 2018-07-15 07:40:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:35 --> Config Class Initialized
INFO - 2018-07-15 07:40:35 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:35 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:35 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:35 --> URI Class Initialized
INFO - 2018-07-15 07:40:35 --> Router Class Initialized
INFO - 2018-07-15 07:40:35 --> Output Class Initialized
INFO - 2018-07-15 07:40:35 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:35 --> Input Class Initialized
INFO - 2018-07-15 07:40:35 --> Language Class Initialized
INFO - 2018-07-15 07:40:35 --> Loader Class Initialized
INFO - 2018-07-15 07:40:35 --> Controller Class Initialized
INFO - 2018-07-15 07:40:35 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:35 --> Model Class Initialized
INFO - 2018-07-15 07:40:35 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:35 --> Model Class Initialized
INFO - 2018-07-15 07:40:35 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:35 --> Total execution time: 0.0415
ERROR - 2018-07-15 07:40:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:35 --> Config Class Initialized
INFO - 2018-07-15 07:40:35 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:35 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:35 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:35 --> URI Class Initialized
INFO - 2018-07-15 07:40:35 --> Router Class Initialized
INFO - 2018-07-15 07:40:35 --> Output Class Initialized
INFO - 2018-07-15 07:40:35 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:35 --> Input Class Initialized
INFO - 2018-07-15 07:40:35 --> Language Class Initialized
INFO - 2018-07-15 07:40:35 --> Loader Class Initialized
INFO - 2018-07-15 07:40:35 --> Controller Class Initialized
INFO - 2018-07-15 07:40:35 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:35 --> Model Class Initialized
INFO - 2018-07-15 07:40:35 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:35 --> Model Class Initialized
INFO - 2018-07-15 07:40:35 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:35 --> Total execution time: 0.0601
ERROR - 2018-07-15 07:40:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:35 --> Config Class Initialized
INFO - 2018-07-15 07:40:35 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:35 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:35 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:35 --> URI Class Initialized
INFO - 2018-07-15 07:40:35 --> Router Class Initialized
INFO - 2018-07-15 07:40:35 --> Output Class Initialized
INFO - 2018-07-15 07:40:35 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:35 --> Input Class Initialized
INFO - 2018-07-15 07:40:35 --> Language Class Initialized
INFO - 2018-07-15 07:40:35 --> Loader Class Initialized
INFO - 2018-07-15 07:40:35 --> Controller Class Initialized
INFO - 2018-07-15 07:40:35 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:35 --> Model Class Initialized
INFO - 2018-07-15 07:40:35 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:35 --> Model Class Initialized
INFO - 2018-07-15 07:40:35 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:35 --> Total execution time: 0.0540
ERROR - 2018-07-15 07:40:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:35 --> Config Class Initialized
INFO - 2018-07-15 07:40:35 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:35 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:35 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:35 --> URI Class Initialized
INFO - 2018-07-15 07:40:35 --> Router Class Initialized
INFO - 2018-07-15 07:40:35 --> Output Class Initialized
INFO - 2018-07-15 07:40:35 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:35 --> Input Class Initialized
INFO - 2018-07-15 07:40:35 --> Language Class Initialized
INFO - 2018-07-15 07:40:35 --> Loader Class Initialized
INFO - 2018-07-15 07:40:35 --> Controller Class Initialized
INFO - 2018-07-15 07:40:35 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:35 --> Model Class Initialized
INFO - 2018-07-15 07:40:35 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:35 --> Model Class Initialized
INFO - 2018-07-15 07:40:35 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:35 --> Total execution time: 0.0417
ERROR - 2018-07-15 07:40:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:36 --> Config Class Initialized
INFO - 2018-07-15 07:40:36 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:36 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:36 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:36 --> URI Class Initialized
INFO - 2018-07-15 07:40:36 --> Router Class Initialized
INFO - 2018-07-15 07:40:36 --> Output Class Initialized
INFO - 2018-07-15 07:40:36 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:36 --> Input Class Initialized
INFO - 2018-07-15 07:40:36 --> Language Class Initialized
INFO - 2018-07-15 07:40:36 --> Loader Class Initialized
INFO - 2018-07-15 07:40:36 --> Controller Class Initialized
INFO - 2018-07-15 07:40:36 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:36 --> Model Class Initialized
INFO - 2018-07-15 07:40:36 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:36 --> Model Class Initialized
INFO - 2018-07-15 07:40:36 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:36 --> Total execution time: 0.0432
ERROR - 2018-07-15 07:40:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:36 --> Config Class Initialized
INFO - 2018-07-15 07:40:36 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:36 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:36 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:36 --> URI Class Initialized
INFO - 2018-07-15 07:40:36 --> Router Class Initialized
INFO - 2018-07-15 07:40:36 --> Output Class Initialized
INFO - 2018-07-15 07:40:36 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:36 --> Input Class Initialized
INFO - 2018-07-15 07:40:36 --> Language Class Initialized
INFO - 2018-07-15 07:40:36 --> Loader Class Initialized
INFO - 2018-07-15 07:40:36 --> Controller Class Initialized
INFO - 2018-07-15 07:40:36 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:36 --> Model Class Initialized
INFO - 2018-07-15 07:40:36 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:36 --> Model Class Initialized
INFO - 2018-07-15 07:40:36 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:36 --> Total execution time: 0.0433
ERROR - 2018-07-15 07:40:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:36 --> Config Class Initialized
INFO - 2018-07-15 07:40:36 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:36 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:36 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:36 --> URI Class Initialized
INFO - 2018-07-15 07:40:36 --> Router Class Initialized
INFO - 2018-07-15 07:40:36 --> Output Class Initialized
INFO - 2018-07-15 07:40:36 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:36 --> Input Class Initialized
INFO - 2018-07-15 07:40:36 --> Language Class Initialized
INFO - 2018-07-15 07:40:36 --> Loader Class Initialized
INFO - 2018-07-15 07:40:36 --> Controller Class Initialized
INFO - 2018-07-15 07:40:36 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:36 --> Model Class Initialized
INFO - 2018-07-15 07:40:36 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:36 --> Model Class Initialized
INFO - 2018-07-15 07:40:36 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:36 --> Total execution time: 0.0410
ERROR - 2018-07-15 07:40:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:36 --> Config Class Initialized
INFO - 2018-07-15 07:40:36 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:36 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:36 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:36 --> URI Class Initialized
INFO - 2018-07-15 07:40:36 --> Router Class Initialized
INFO - 2018-07-15 07:40:36 --> Output Class Initialized
INFO - 2018-07-15 07:40:36 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:36 --> Input Class Initialized
INFO - 2018-07-15 07:40:36 --> Language Class Initialized
INFO - 2018-07-15 07:40:36 --> Loader Class Initialized
INFO - 2018-07-15 07:40:36 --> Controller Class Initialized
INFO - 2018-07-15 07:40:36 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:36 --> Model Class Initialized
INFO - 2018-07-15 07:40:36 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:36 --> Model Class Initialized
INFO - 2018-07-15 07:40:36 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:36 --> Total execution time: 0.0423
ERROR - 2018-07-15 07:40:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:36 --> Config Class Initialized
INFO - 2018-07-15 07:40:36 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:36 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:36 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:36 --> URI Class Initialized
INFO - 2018-07-15 07:40:36 --> Router Class Initialized
INFO - 2018-07-15 07:40:36 --> Output Class Initialized
INFO - 2018-07-15 07:40:36 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:36 --> Input Class Initialized
INFO - 2018-07-15 07:40:37 --> Language Class Initialized
INFO - 2018-07-15 07:40:37 --> Loader Class Initialized
INFO - 2018-07-15 07:40:37 --> Controller Class Initialized
INFO - 2018-07-15 07:40:37 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:37 --> Model Class Initialized
INFO - 2018-07-15 07:40:37 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:37 --> Model Class Initialized
INFO - 2018-07-15 07:40:37 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:37 --> Total execution time: 0.0407
ERROR - 2018-07-15 07:40:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:37 --> Config Class Initialized
INFO - 2018-07-15 07:40:37 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:37 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:37 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:37 --> URI Class Initialized
INFO - 2018-07-15 07:40:37 --> Router Class Initialized
INFO - 2018-07-15 07:40:37 --> Output Class Initialized
INFO - 2018-07-15 07:40:37 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:37 --> Input Class Initialized
INFO - 2018-07-15 07:40:37 --> Language Class Initialized
INFO - 2018-07-15 07:40:37 --> Loader Class Initialized
INFO - 2018-07-15 07:40:37 --> Controller Class Initialized
INFO - 2018-07-15 07:40:37 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:37 --> Model Class Initialized
INFO - 2018-07-15 07:40:37 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:37 --> Model Class Initialized
INFO - 2018-07-15 07:40:37 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:37 --> Total execution time: 0.0417
ERROR - 2018-07-15 07:40:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:37 --> Config Class Initialized
INFO - 2018-07-15 07:40:37 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:37 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:37 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:37 --> URI Class Initialized
INFO - 2018-07-15 07:40:37 --> Router Class Initialized
INFO - 2018-07-15 07:40:37 --> Output Class Initialized
INFO - 2018-07-15 07:40:37 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:37 --> Input Class Initialized
INFO - 2018-07-15 07:40:37 --> Language Class Initialized
INFO - 2018-07-15 07:40:37 --> Loader Class Initialized
INFO - 2018-07-15 07:40:37 --> Controller Class Initialized
INFO - 2018-07-15 07:40:37 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:37 --> Model Class Initialized
INFO - 2018-07-15 07:40:37 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:37 --> Model Class Initialized
INFO - 2018-07-15 07:40:37 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:37 --> Total execution time: 0.0415
ERROR - 2018-07-15 07:40:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:37 --> Config Class Initialized
INFO - 2018-07-15 07:40:37 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:37 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:37 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:37 --> URI Class Initialized
INFO - 2018-07-15 07:40:37 --> Router Class Initialized
INFO - 2018-07-15 07:40:37 --> Output Class Initialized
INFO - 2018-07-15 07:40:37 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:37 --> Input Class Initialized
INFO - 2018-07-15 07:40:37 --> Language Class Initialized
INFO - 2018-07-15 07:40:37 --> Loader Class Initialized
INFO - 2018-07-15 07:40:37 --> Controller Class Initialized
INFO - 2018-07-15 07:40:37 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:37 --> Model Class Initialized
INFO - 2018-07-15 07:40:37 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:37 --> Model Class Initialized
INFO - 2018-07-15 07:40:37 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:37 --> Total execution time: 0.0434
ERROR - 2018-07-15 07:40:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:37 --> Config Class Initialized
INFO - 2018-07-15 07:40:37 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:37 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:37 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:37 --> URI Class Initialized
INFO - 2018-07-15 07:40:37 --> Router Class Initialized
INFO - 2018-07-15 07:40:37 --> Output Class Initialized
INFO - 2018-07-15 07:40:37 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:37 --> Input Class Initialized
INFO - 2018-07-15 07:40:37 --> Language Class Initialized
INFO - 2018-07-15 07:40:37 --> Loader Class Initialized
INFO - 2018-07-15 07:40:37 --> Controller Class Initialized
INFO - 2018-07-15 07:40:37 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:37 --> Model Class Initialized
INFO - 2018-07-15 07:40:37 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:37 --> Model Class Initialized
INFO - 2018-07-15 07:40:37 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:37 --> Total execution time: 0.0409
ERROR - 2018-07-15 07:40:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:37 --> Config Class Initialized
INFO - 2018-07-15 07:40:37 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:37 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:37 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:37 --> URI Class Initialized
INFO - 2018-07-15 07:40:37 --> Router Class Initialized
INFO - 2018-07-15 07:40:37 --> Output Class Initialized
INFO - 2018-07-15 07:40:37 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:37 --> Input Class Initialized
INFO - 2018-07-15 07:40:37 --> Language Class Initialized
INFO - 2018-07-15 07:40:37 --> Loader Class Initialized
INFO - 2018-07-15 07:40:37 --> Controller Class Initialized
INFO - 2018-07-15 07:40:37 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:37 --> Model Class Initialized
INFO - 2018-07-15 07:40:38 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:38 --> Model Class Initialized
INFO - 2018-07-15 07:40:38 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:38 --> Total execution time: 0.0431
ERROR - 2018-07-15 07:40:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:38 --> Config Class Initialized
INFO - 2018-07-15 07:40:38 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:38 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:38 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:38 --> URI Class Initialized
INFO - 2018-07-15 07:40:38 --> Router Class Initialized
INFO - 2018-07-15 07:40:38 --> Output Class Initialized
INFO - 2018-07-15 07:40:38 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:38 --> Input Class Initialized
INFO - 2018-07-15 07:40:38 --> Language Class Initialized
INFO - 2018-07-15 07:40:38 --> Loader Class Initialized
INFO - 2018-07-15 07:40:38 --> Controller Class Initialized
INFO - 2018-07-15 07:40:38 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:38 --> Model Class Initialized
INFO - 2018-07-15 07:40:38 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:38 --> Model Class Initialized
INFO - 2018-07-15 07:40:38 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:38 --> Total execution time: 0.0365
ERROR - 2018-07-15 07:40:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:38 --> Config Class Initialized
INFO - 2018-07-15 07:40:38 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:38 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:38 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:38 --> URI Class Initialized
INFO - 2018-07-15 07:40:38 --> Router Class Initialized
INFO - 2018-07-15 07:40:38 --> Output Class Initialized
INFO - 2018-07-15 07:40:38 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:38 --> Input Class Initialized
INFO - 2018-07-15 07:40:38 --> Language Class Initialized
INFO - 2018-07-15 07:40:38 --> Loader Class Initialized
INFO - 2018-07-15 07:40:38 --> Controller Class Initialized
INFO - 2018-07-15 07:40:38 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:38 --> Model Class Initialized
INFO - 2018-07-15 07:40:38 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:38 --> Model Class Initialized
INFO - 2018-07-15 07:40:38 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:38 --> Total execution time: 0.0445
ERROR - 2018-07-15 07:40:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:38 --> Config Class Initialized
INFO - 2018-07-15 07:40:38 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:38 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:38 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:38 --> URI Class Initialized
INFO - 2018-07-15 07:40:38 --> Router Class Initialized
INFO - 2018-07-15 07:40:38 --> Output Class Initialized
INFO - 2018-07-15 07:40:38 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:38 --> Input Class Initialized
INFO - 2018-07-15 07:40:38 --> Language Class Initialized
INFO - 2018-07-15 07:40:38 --> Loader Class Initialized
INFO - 2018-07-15 07:40:38 --> Controller Class Initialized
INFO - 2018-07-15 07:40:38 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:38 --> Model Class Initialized
INFO - 2018-07-15 07:40:38 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:38 --> Model Class Initialized
INFO - 2018-07-15 07:40:38 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:38 --> Total execution time: 0.0548
ERROR - 2018-07-15 07:40:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:38 --> Config Class Initialized
INFO - 2018-07-15 07:40:38 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:38 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:38 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:38 --> URI Class Initialized
INFO - 2018-07-15 07:40:38 --> Router Class Initialized
INFO - 2018-07-15 07:40:38 --> Output Class Initialized
INFO - 2018-07-15 07:40:38 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:38 --> Input Class Initialized
INFO - 2018-07-15 07:40:38 --> Language Class Initialized
INFO - 2018-07-15 07:40:38 --> Loader Class Initialized
INFO - 2018-07-15 07:40:38 --> Controller Class Initialized
INFO - 2018-07-15 07:40:38 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:38 --> Model Class Initialized
INFO - 2018-07-15 07:40:38 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:38 --> Model Class Initialized
INFO - 2018-07-15 07:40:38 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:38 --> Total execution time: 0.0439
ERROR - 2018-07-15 07:40:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:38 --> Config Class Initialized
INFO - 2018-07-15 07:40:38 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:38 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:38 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:38 --> URI Class Initialized
INFO - 2018-07-15 07:40:38 --> Router Class Initialized
INFO - 2018-07-15 07:40:38 --> Output Class Initialized
INFO - 2018-07-15 07:40:38 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:38 --> Input Class Initialized
INFO - 2018-07-15 07:40:38 --> Language Class Initialized
INFO - 2018-07-15 07:40:38 --> Loader Class Initialized
INFO - 2018-07-15 07:40:38 --> Controller Class Initialized
INFO - 2018-07-15 07:40:38 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:38 --> Model Class Initialized
INFO - 2018-07-15 07:40:38 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:38 --> Model Class Initialized
INFO - 2018-07-15 07:40:38 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:38 --> Total execution time: 0.0423
ERROR - 2018-07-15 07:40:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:39 --> Config Class Initialized
INFO - 2018-07-15 07:40:39 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:39 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:39 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:39 --> URI Class Initialized
INFO - 2018-07-15 07:40:39 --> Router Class Initialized
INFO - 2018-07-15 07:40:39 --> Output Class Initialized
INFO - 2018-07-15 07:40:39 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:39 --> Input Class Initialized
INFO - 2018-07-15 07:40:39 --> Language Class Initialized
INFO - 2018-07-15 07:40:39 --> Loader Class Initialized
INFO - 2018-07-15 07:40:39 --> Controller Class Initialized
INFO - 2018-07-15 07:40:39 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:39 --> Model Class Initialized
INFO - 2018-07-15 07:40:39 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:39 --> Model Class Initialized
INFO - 2018-07-15 07:40:39 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:39 --> Total execution time: 0.0519
ERROR - 2018-07-15 07:40:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:39 --> Config Class Initialized
INFO - 2018-07-15 07:40:39 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:39 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:39 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:39 --> URI Class Initialized
INFO - 2018-07-15 07:40:39 --> Router Class Initialized
INFO - 2018-07-15 07:40:39 --> Output Class Initialized
INFO - 2018-07-15 07:40:39 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:39 --> Input Class Initialized
INFO - 2018-07-15 07:40:39 --> Language Class Initialized
INFO - 2018-07-15 07:40:39 --> Loader Class Initialized
INFO - 2018-07-15 07:40:39 --> Controller Class Initialized
INFO - 2018-07-15 07:40:39 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:39 --> Model Class Initialized
INFO - 2018-07-15 07:40:39 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:39 --> Model Class Initialized
INFO - 2018-07-15 07:40:39 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:39 --> Total execution time: 0.0461
ERROR - 2018-07-15 07:40:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:39 --> Config Class Initialized
INFO - 2018-07-15 07:40:39 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:39 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:39 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:39 --> URI Class Initialized
INFO - 2018-07-15 07:40:39 --> Router Class Initialized
INFO - 2018-07-15 07:40:39 --> Output Class Initialized
INFO - 2018-07-15 07:40:39 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:39 --> Input Class Initialized
INFO - 2018-07-15 07:40:39 --> Language Class Initialized
INFO - 2018-07-15 07:40:39 --> Loader Class Initialized
INFO - 2018-07-15 07:40:39 --> Controller Class Initialized
INFO - 2018-07-15 07:40:39 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:39 --> Model Class Initialized
INFO - 2018-07-15 07:40:39 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:39 --> Model Class Initialized
INFO - 2018-07-15 07:40:39 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:39 --> Total execution time: 0.1419
ERROR - 2018-07-15 07:40:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:39 --> Config Class Initialized
INFO - 2018-07-15 07:40:39 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:39 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:39 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:39 --> URI Class Initialized
INFO - 2018-07-15 07:40:39 --> Router Class Initialized
INFO - 2018-07-15 07:40:39 --> Output Class Initialized
INFO - 2018-07-15 07:40:39 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:39 --> Input Class Initialized
INFO - 2018-07-15 07:40:39 --> Language Class Initialized
INFO - 2018-07-15 07:40:39 --> Loader Class Initialized
INFO - 2018-07-15 07:40:39 --> Controller Class Initialized
INFO - 2018-07-15 07:40:39 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:39 --> Model Class Initialized
INFO - 2018-07-15 07:40:39 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:39 --> Model Class Initialized
INFO - 2018-07-15 07:40:39 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:39 --> Total execution time: 0.0463
ERROR - 2018-07-15 07:40:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:39 --> Config Class Initialized
INFO - 2018-07-15 07:40:39 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:39 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:39 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:39 --> URI Class Initialized
INFO - 2018-07-15 07:40:39 --> Router Class Initialized
INFO - 2018-07-15 07:40:39 --> Output Class Initialized
INFO - 2018-07-15 07:40:39 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:39 --> Input Class Initialized
INFO - 2018-07-15 07:40:39 --> Language Class Initialized
INFO - 2018-07-15 07:40:39 --> Loader Class Initialized
INFO - 2018-07-15 07:40:39 --> Controller Class Initialized
INFO - 2018-07-15 07:40:40 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:40 --> Model Class Initialized
INFO - 2018-07-15 07:40:40 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:40 --> Model Class Initialized
INFO - 2018-07-15 07:40:40 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:40 --> Total execution time: 0.0421
ERROR - 2018-07-15 07:40:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:40 --> Config Class Initialized
INFO - 2018-07-15 07:40:40 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:40 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:40 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:40 --> URI Class Initialized
INFO - 2018-07-15 07:40:40 --> Router Class Initialized
INFO - 2018-07-15 07:40:40 --> Output Class Initialized
INFO - 2018-07-15 07:40:40 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:40 --> Input Class Initialized
INFO - 2018-07-15 07:40:40 --> Language Class Initialized
INFO - 2018-07-15 07:40:40 --> Loader Class Initialized
INFO - 2018-07-15 07:40:40 --> Controller Class Initialized
INFO - 2018-07-15 07:40:40 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:40 --> Model Class Initialized
INFO - 2018-07-15 07:40:40 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:40 --> Model Class Initialized
INFO - 2018-07-15 07:40:40 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:40 --> Total execution time: 0.0422
ERROR - 2018-07-15 07:40:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:40 --> Config Class Initialized
INFO - 2018-07-15 07:40:40 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:40 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:40 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:40 --> URI Class Initialized
INFO - 2018-07-15 07:40:40 --> Router Class Initialized
INFO - 2018-07-15 07:40:40 --> Output Class Initialized
INFO - 2018-07-15 07:40:40 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:40 --> Input Class Initialized
INFO - 2018-07-15 07:40:40 --> Language Class Initialized
INFO - 2018-07-15 07:40:40 --> Loader Class Initialized
INFO - 2018-07-15 07:40:40 --> Controller Class Initialized
INFO - 2018-07-15 07:40:40 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:40 --> Model Class Initialized
INFO - 2018-07-15 07:40:40 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:40 --> Model Class Initialized
INFO - 2018-07-15 07:40:40 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:40 --> Total execution time: 0.0487
ERROR - 2018-07-15 07:40:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:40 --> Config Class Initialized
INFO - 2018-07-15 07:40:40 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:40 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:40 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:40 --> URI Class Initialized
INFO - 2018-07-15 07:40:40 --> Router Class Initialized
INFO - 2018-07-15 07:40:40 --> Output Class Initialized
INFO - 2018-07-15 07:40:40 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:40 --> Input Class Initialized
INFO - 2018-07-15 07:40:40 --> Language Class Initialized
INFO - 2018-07-15 07:40:40 --> Loader Class Initialized
INFO - 2018-07-15 07:40:40 --> Controller Class Initialized
INFO - 2018-07-15 07:40:40 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:40 --> Model Class Initialized
INFO - 2018-07-15 07:40:40 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:40 --> Model Class Initialized
INFO - 2018-07-15 07:40:40 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:40 --> Total execution time: 0.0410
ERROR - 2018-07-15 07:40:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:40 --> Config Class Initialized
INFO - 2018-07-15 07:40:40 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:40 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:40 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:40 --> URI Class Initialized
INFO - 2018-07-15 07:40:40 --> Router Class Initialized
INFO - 2018-07-15 07:40:40 --> Output Class Initialized
INFO - 2018-07-15 07:40:40 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:40 --> Input Class Initialized
INFO - 2018-07-15 07:40:40 --> Language Class Initialized
INFO - 2018-07-15 07:40:40 --> Loader Class Initialized
INFO - 2018-07-15 07:40:40 --> Controller Class Initialized
INFO - 2018-07-15 07:40:40 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:40 --> Model Class Initialized
INFO - 2018-07-15 07:40:40 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:40 --> Model Class Initialized
INFO - 2018-07-15 07:40:40 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:40 --> Total execution time: 0.0395
ERROR - 2018-07-15 07:40:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:40 --> Config Class Initialized
INFO - 2018-07-15 07:40:40 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:40 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:40 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:40 --> URI Class Initialized
INFO - 2018-07-15 07:40:40 --> Router Class Initialized
INFO - 2018-07-15 07:40:40 --> Output Class Initialized
INFO - 2018-07-15 07:40:40 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:40 --> Input Class Initialized
INFO - 2018-07-15 07:40:40 --> Language Class Initialized
INFO - 2018-07-15 07:40:40 --> Loader Class Initialized
INFO - 2018-07-15 07:40:40 --> Controller Class Initialized
INFO - 2018-07-15 07:40:40 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:40 --> Model Class Initialized
INFO - 2018-07-15 07:40:40 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:40 --> Model Class Initialized
INFO - 2018-07-15 07:40:40 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:40 --> Total execution time: 0.0414
ERROR - 2018-07-15 07:40:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:41 --> Config Class Initialized
INFO - 2018-07-15 07:40:41 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:41 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:41 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:41 --> URI Class Initialized
INFO - 2018-07-15 07:40:41 --> Router Class Initialized
INFO - 2018-07-15 07:40:41 --> Output Class Initialized
INFO - 2018-07-15 07:40:41 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:41 --> Input Class Initialized
INFO - 2018-07-15 07:40:41 --> Language Class Initialized
INFO - 2018-07-15 07:40:41 --> Loader Class Initialized
INFO - 2018-07-15 07:40:41 --> Controller Class Initialized
INFO - 2018-07-15 07:40:41 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:41 --> Model Class Initialized
INFO - 2018-07-15 07:40:41 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:41 --> Model Class Initialized
INFO - 2018-07-15 07:40:41 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:41 --> Total execution time: 0.0431
ERROR - 2018-07-15 07:40:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:41 --> Config Class Initialized
INFO - 2018-07-15 07:40:41 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:41 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:41 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:41 --> URI Class Initialized
INFO - 2018-07-15 07:40:41 --> Router Class Initialized
INFO - 2018-07-15 07:40:41 --> Output Class Initialized
INFO - 2018-07-15 07:40:41 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:41 --> Input Class Initialized
INFO - 2018-07-15 07:40:41 --> Language Class Initialized
INFO - 2018-07-15 07:40:41 --> Loader Class Initialized
INFO - 2018-07-15 07:40:41 --> Controller Class Initialized
INFO - 2018-07-15 07:40:41 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:41 --> Model Class Initialized
INFO - 2018-07-15 07:40:41 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:41 --> Model Class Initialized
INFO - 2018-07-15 07:40:41 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:41 --> Total execution time: 0.0498
ERROR - 2018-07-15 07:40:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:41 --> Config Class Initialized
INFO - 2018-07-15 07:40:41 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:41 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:41 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:41 --> URI Class Initialized
INFO - 2018-07-15 07:40:41 --> Router Class Initialized
INFO - 2018-07-15 07:40:41 --> Output Class Initialized
INFO - 2018-07-15 07:40:41 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:41 --> Input Class Initialized
INFO - 2018-07-15 07:40:41 --> Language Class Initialized
INFO - 2018-07-15 07:40:41 --> Loader Class Initialized
INFO - 2018-07-15 07:40:41 --> Controller Class Initialized
INFO - 2018-07-15 07:40:41 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:41 --> Model Class Initialized
INFO - 2018-07-15 07:40:41 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:41 --> Model Class Initialized
INFO - 2018-07-15 07:40:41 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:41 --> Total execution time: 0.0637
ERROR - 2018-07-15 07:40:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:41 --> Config Class Initialized
INFO - 2018-07-15 07:40:41 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:41 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:41 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:41 --> URI Class Initialized
INFO - 2018-07-15 07:40:41 --> Router Class Initialized
INFO - 2018-07-15 07:40:41 --> Output Class Initialized
INFO - 2018-07-15 07:40:41 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:41 --> Input Class Initialized
INFO - 2018-07-15 07:40:41 --> Language Class Initialized
INFO - 2018-07-15 07:40:41 --> Loader Class Initialized
INFO - 2018-07-15 07:40:41 --> Controller Class Initialized
INFO - 2018-07-15 07:40:41 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:41 --> Model Class Initialized
INFO - 2018-07-15 07:40:41 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:41 --> Model Class Initialized
INFO - 2018-07-15 07:40:41 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:41 --> Total execution time: 0.0467
ERROR - 2018-07-15 07:40:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:41 --> Config Class Initialized
INFO - 2018-07-15 07:40:41 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:41 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:41 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:41 --> URI Class Initialized
INFO - 2018-07-15 07:40:41 --> Router Class Initialized
INFO - 2018-07-15 07:40:41 --> Output Class Initialized
INFO - 2018-07-15 07:40:41 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:42 --> Input Class Initialized
INFO - 2018-07-15 07:40:42 --> Language Class Initialized
INFO - 2018-07-15 07:40:42 --> Loader Class Initialized
INFO - 2018-07-15 07:40:42 --> Controller Class Initialized
INFO - 2018-07-15 07:40:42 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:42 --> Model Class Initialized
INFO - 2018-07-15 07:40:42 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:42 --> Model Class Initialized
INFO - 2018-07-15 07:40:42 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:42 --> Total execution time: 0.0413
ERROR - 2018-07-15 07:40:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:42 --> Config Class Initialized
INFO - 2018-07-15 07:40:42 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:42 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:42 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:42 --> URI Class Initialized
INFO - 2018-07-15 07:40:42 --> Router Class Initialized
INFO - 2018-07-15 07:40:42 --> Output Class Initialized
INFO - 2018-07-15 07:40:42 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:42 --> Input Class Initialized
INFO - 2018-07-15 07:40:42 --> Language Class Initialized
INFO - 2018-07-15 07:40:42 --> Loader Class Initialized
INFO - 2018-07-15 07:40:42 --> Controller Class Initialized
INFO - 2018-07-15 07:40:42 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:42 --> Model Class Initialized
INFO - 2018-07-15 07:40:42 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:42 --> Model Class Initialized
INFO - 2018-07-15 07:40:42 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:42 --> Total execution time: 0.0406
ERROR - 2018-07-15 07:40:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:42 --> Config Class Initialized
INFO - 2018-07-15 07:40:42 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:42 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:42 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:42 --> URI Class Initialized
INFO - 2018-07-15 07:40:42 --> Router Class Initialized
INFO - 2018-07-15 07:40:42 --> Output Class Initialized
INFO - 2018-07-15 07:40:42 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:42 --> Input Class Initialized
INFO - 2018-07-15 07:40:42 --> Language Class Initialized
INFO - 2018-07-15 07:40:42 --> Loader Class Initialized
INFO - 2018-07-15 07:40:42 --> Controller Class Initialized
INFO - 2018-07-15 07:40:42 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:42 --> Model Class Initialized
INFO - 2018-07-15 07:40:42 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:42 --> Model Class Initialized
INFO - 2018-07-15 07:40:42 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:42 --> Total execution time: 0.0426
ERROR - 2018-07-15 07:40:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:42 --> Config Class Initialized
INFO - 2018-07-15 07:40:42 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:42 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:42 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:42 --> URI Class Initialized
INFO - 2018-07-15 07:40:42 --> Router Class Initialized
INFO - 2018-07-15 07:40:42 --> Output Class Initialized
INFO - 2018-07-15 07:40:42 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:42 --> Input Class Initialized
INFO - 2018-07-15 07:40:42 --> Language Class Initialized
INFO - 2018-07-15 07:40:42 --> Loader Class Initialized
INFO - 2018-07-15 07:40:42 --> Controller Class Initialized
INFO - 2018-07-15 07:40:42 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:42 --> Model Class Initialized
INFO - 2018-07-15 07:40:42 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:42 --> Model Class Initialized
INFO - 2018-07-15 07:40:42 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:42 --> Total execution time: 0.0433
ERROR - 2018-07-15 07:40:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:42 --> Config Class Initialized
INFO - 2018-07-15 07:40:42 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:42 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:42 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:42 --> URI Class Initialized
INFO - 2018-07-15 07:40:42 --> Router Class Initialized
INFO - 2018-07-15 07:40:42 --> Output Class Initialized
INFO - 2018-07-15 07:40:42 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:42 --> Input Class Initialized
INFO - 2018-07-15 07:40:42 --> Language Class Initialized
INFO - 2018-07-15 07:40:42 --> Loader Class Initialized
INFO - 2018-07-15 07:40:42 --> Controller Class Initialized
INFO - 2018-07-15 07:40:42 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:42 --> Model Class Initialized
INFO - 2018-07-15 07:40:42 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:42 --> Model Class Initialized
INFO - 2018-07-15 07:40:42 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:42 --> Total execution time: 0.0520
ERROR - 2018-07-15 07:40:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:43 --> Config Class Initialized
INFO - 2018-07-15 07:40:43 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:43 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:43 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:43 --> URI Class Initialized
INFO - 2018-07-15 07:40:43 --> Router Class Initialized
INFO - 2018-07-15 07:40:43 --> Output Class Initialized
INFO - 2018-07-15 07:40:43 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:43 --> Input Class Initialized
INFO - 2018-07-15 07:40:43 --> Language Class Initialized
INFO - 2018-07-15 07:40:43 --> Loader Class Initialized
INFO - 2018-07-15 07:40:43 --> Controller Class Initialized
INFO - 2018-07-15 07:40:43 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:43 --> Model Class Initialized
INFO - 2018-07-15 07:40:43 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:43 --> Model Class Initialized
INFO - 2018-07-15 07:40:43 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:43 --> Total execution time: 0.0539
ERROR - 2018-07-15 07:40:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:43 --> Config Class Initialized
INFO - 2018-07-15 07:40:43 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:43 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:43 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:43 --> URI Class Initialized
INFO - 2018-07-15 07:40:43 --> Router Class Initialized
INFO - 2018-07-15 07:40:43 --> Output Class Initialized
INFO - 2018-07-15 07:40:43 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:43 --> Input Class Initialized
INFO - 2018-07-15 07:40:43 --> Language Class Initialized
INFO - 2018-07-15 07:40:43 --> Loader Class Initialized
INFO - 2018-07-15 07:40:43 --> Controller Class Initialized
INFO - 2018-07-15 07:40:43 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:43 --> Model Class Initialized
INFO - 2018-07-15 07:40:43 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:43 --> Model Class Initialized
INFO - 2018-07-15 07:40:43 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:43 --> Total execution time: 0.0396
ERROR - 2018-07-15 07:40:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:43 --> Config Class Initialized
INFO - 2018-07-15 07:40:43 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:43 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:43 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:43 --> URI Class Initialized
INFO - 2018-07-15 07:40:43 --> Router Class Initialized
INFO - 2018-07-15 07:40:43 --> Output Class Initialized
INFO - 2018-07-15 07:40:43 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:43 --> Input Class Initialized
INFO - 2018-07-15 07:40:43 --> Language Class Initialized
INFO - 2018-07-15 07:40:43 --> Loader Class Initialized
INFO - 2018-07-15 07:40:43 --> Controller Class Initialized
INFO - 2018-07-15 07:40:43 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:43 --> Model Class Initialized
INFO - 2018-07-15 07:40:43 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:43 --> Model Class Initialized
INFO - 2018-07-15 07:40:43 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:43 --> Total execution time: 0.0410
ERROR - 2018-07-15 07:40:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:43 --> Config Class Initialized
INFO - 2018-07-15 07:40:43 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:43 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:43 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:43 --> URI Class Initialized
INFO - 2018-07-15 07:40:43 --> Router Class Initialized
INFO - 2018-07-15 07:40:43 --> Output Class Initialized
INFO - 2018-07-15 07:40:43 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:43 --> Input Class Initialized
INFO - 2018-07-15 07:40:43 --> Language Class Initialized
INFO - 2018-07-15 07:40:43 --> Loader Class Initialized
INFO - 2018-07-15 07:40:43 --> Controller Class Initialized
INFO - 2018-07-15 07:40:43 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:43 --> Model Class Initialized
INFO - 2018-07-15 07:40:43 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:43 --> Model Class Initialized
INFO - 2018-07-15 07:40:43 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:43 --> Total execution time: 0.0437
ERROR - 2018-07-15 07:40:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:43 --> Config Class Initialized
INFO - 2018-07-15 07:40:43 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:43 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:43 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:43 --> URI Class Initialized
INFO - 2018-07-15 07:40:43 --> Router Class Initialized
INFO - 2018-07-15 07:40:43 --> Output Class Initialized
INFO - 2018-07-15 07:40:43 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:43 --> Input Class Initialized
INFO - 2018-07-15 07:40:43 --> Language Class Initialized
INFO - 2018-07-15 07:40:43 --> Loader Class Initialized
INFO - 2018-07-15 07:40:43 --> Controller Class Initialized
INFO - 2018-07-15 07:40:43 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:43 --> Model Class Initialized
INFO - 2018-07-15 07:40:43 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:43 --> Model Class Initialized
INFO - 2018-07-15 07:40:43 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:43 --> Total execution time: 0.0457
ERROR - 2018-07-15 07:40:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:43 --> Config Class Initialized
INFO - 2018-07-15 07:40:43 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:43 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:43 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:43 --> URI Class Initialized
INFO - 2018-07-15 07:40:43 --> Router Class Initialized
INFO - 2018-07-15 07:40:43 --> Output Class Initialized
INFO - 2018-07-15 07:40:43 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:43 --> Input Class Initialized
INFO - 2018-07-15 07:40:43 --> Language Class Initialized
INFO - 2018-07-15 07:40:43 --> Loader Class Initialized
INFO - 2018-07-15 07:40:43 --> Controller Class Initialized
INFO - 2018-07-15 07:40:43 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:43 --> Model Class Initialized
INFO - 2018-07-15 07:40:43 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:43 --> Model Class Initialized
INFO - 2018-07-15 07:40:43 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:43 --> Total execution time: 0.0435
ERROR - 2018-07-15 07:40:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:40:44 --> Config Class Initialized
INFO - 2018-07-15 07:40:44 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:40:44 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:40:44 --> Utf8 Class Initialized
INFO - 2018-07-15 07:40:44 --> URI Class Initialized
INFO - 2018-07-15 07:40:44 --> Router Class Initialized
INFO - 2018-07-15 07:40:44 --> Output Class Initialized
INFO - 2018-07-15 07:40:44 --> Security Class Initialized
DEBUG - 2018-07-15 07:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:40:44 --> Input Class Initialized
INFO - 2018-07-15 07:40:44 --> Language Class Initialized
INFO - 2018-07-15 07:40:44 --> Loader Class Initialized
INFO - 2018-07-15 07:40:44 --> Controller Class Initialized
INFO - 2018-07-15 07:40:44 --> Database Driver Class Initialized
INFO - 2018-07-15 07:40:44 --> Model Class Initialized
INFO - 2018-07-15 07:40:44 --> Helper loaded: url_helper
INFO - 2018-07-15 07:40:44 --> Model Class Initialized
INFO - 2018-07-15 07:40:44 --> Final output sent to browser
DEBUG - 2018-07-15 07:40:44 --> Total execution time: 0.0495
ERROR - 2018-07-15 07:43:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:43:15 --> Config Class Initialized
INFO - 2018-07-15 07:43:15 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:43:15 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:43:15 --> Utf8 Class Initialized
INFO - 2018-07-15 07:43:15 --> URI Class Initialized
INFO - 2018-07-15 07:43:15 --> Router Class Initialized
INFO - 2018-07-15 07:43:15 --> Output Class Initialized
INFO - 2018-07-15 07:43:15 --> Security Class Initialized
DEBUG - 2018-07-15 07:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:43:15 --> Input Class Initialized
INFO - 2018-07-15 07:43:15 --> Language Class Initialized
INFO - 2018-07-15 07:43:15 --> Loader Class Initialized
INFO - 2018-07-15 07:43:15 --> Controller Class Initialized
INFO - 2018-07-15 07:43:15 --> Database Driver Class Initialized
INFO - 2018-07-15 07:43:15 --> Model Class Initialized
INFO - 2018-07-15 07:43:15 --> Helper loaded: url_helper
INFO - 2018-07-15 07:43:15 --> Model Class Initialized
INFO - 2018-07-15 07:43:15 --> Final output sent to browser
DEBUG - 2018-07-15 07:43:15 --> Total execution time: 0.0563
ERROR - 2018-07-15 07:43:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:43:17 --> Config Class Initialized
INFO - 2018-07-15 07:43:17 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:43:17 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:43:17 --> Utf8 Class Initialized
INFO - 2018-07-15 07:43:17 --> URI Class Initialized
INFO - 2018-07-15 07:43:17 --> Router Class Initialized
INFO - 2018-07-15 07:43:17 --> Output Class Initialized
INFO - 2018-07-15 07:43:17 --> Security Class Initialized
DEBUG - 2018-07-15 07:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:43:17 --> Input Class Initialized
INFO - 2018-07-15 07:43:17 --> Language Class Initialized
INFO - 2018-07-15 07:43:17 --> Loader Class Initialized
INFO - 2018-07-15 07:43:17 --> Controller Class Initialized
INFO - 2018-07-15 07:43:17 --> Database Driver Class Initialized
INFO - 2018-07-15 07:43:17 --> Model Class Initialized
INFO - 2018-07-15 07:43:17 --> Helper loaded: url_helper
INFO - 2018-07-15 07:43:17 --> Model Class Initialized
INFO - 2018-07-15 07:43:17 --> Final output sent to browser
DEBUG - 2018-07-15 07:43:17 --> Total execution time: 0.0455
ERROR - 2018-07-15 07:44:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:44:09 --> Config Class Initialized
INFO - 2018-07-15 07:44:09 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:44:09 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:44:09 --> Utf8 Class Initialized
INFO - 2018-07-15 07:44:09 --> URI Class Initialized
INFO - 2018-07-15 07:44:09 --> Router Class Initialized
INFO - 2018-07-15 07:44:09 --> Output Class Initialized
INFO - 2018-07-15 07:44:09 --> Security Class Initialized
DEBUG - 2018-07-15 07:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:44:09 --> Input Class Initialized
INFO - 2018-07-15 07:44:09 --> Language Class Initialized
INFO - 2018-07-15 07:44:09 --> Loader Class Initialized
INFO - 2018-07-15 07:44:09 --> Controller Class Initialized
INFO - 2018-07-15 07:44:09 --> Database Driver Class Initialized
INFO - 2018-07-15 07:44:09 --> Model Class Initialized
INFO - 2018-07-15 07:44:09 --> Helper loaded: url_helper
INFO - 2018-07-15 07:44:09 --> Model Class Initialized
INFO - 2018-07-15 07:44:09 --> Final output sent to browser
DEBUG - 2018-07-15 07:44:09 --> Total execution time: 0.0439
ERROR - 2018-07-15 07:44:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:44:38 --> Config Class Initialized
INFO - 2018-07-15 07:44:38 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:44:38 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:44:38 --> Utf8 Class Initialized
INFO - 2018-07-15 07:44:38 --> URI Class Initialized
INFO - 2018-07-15 07:44:38 --> Router Class Initialized
INFO - 2018-07-15 07:44:38 --> Output Class Initialized
INFO - 2018-07-15 07:44:38 --> Security Class Initialized
DEBUG - 2018-07-15 07:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:44:38 --> Input Class Initialized
INFO - 2018-07-15 07:44:38 --> Language Class Initialized
INFO - 2018-07-15 07:44:38 --> Loader Class Initialized
INFO - 2018-07-15 07:44:38 --> Controller Class Initialized
INFO - 2018-07-15 07:44:38 --> Database Driver Class Initialized
INFO - 2018-07-15 07:44:38 --> Model Class Initialized
INFO - 2018-07-15 07:44:38 --> Helper loaded: url_helper
INFO - 2018-07-15 07:44:38 --> Model Class Initialized
INFO - 2018-07-15 07:44:38 --> Final output sent to browser
DEBUG - 2018-07-15 07:44:38 --> Total execution time: 0.0413
ERROR - 2018-07-15 07:45:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:45:45 --> Config Class Initialized
INFO - 2018-07-15 07:45:45 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:45:45 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:45:45 --> Utf8 Class Initialized
INFO - 2018-07-15 07:45:45 --> URI Class Initialized
INFO - 2018-07-15 07:45:45 --> Router Class Initialized
INFO - 2018-07-15 07:45:45 --> Output Class Initialized
INFO - 2018-07-15 07:45:45 --> Security Class Initialized
DEBUG - 2018-07-15 07:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:45:45 --> Input Class Initialized
INFO - 2018-07-15 07:45:45 --> Language Class Initialized
INFO - 2018-07-15 07:45:45 --> Loader Class Initialized
INFO - 2018-07-15 07:45:45 --> Controller Class Initialized
INFO - 2018-07-15 07:45:45 --> Database Driver Class Initialized
INFO - 2018-07-15 07:45:45 --> Model Class Initialized
INFO - 2018-07-15 07:45:45 --> Helper loaded: url_helper
INFO - 2018-07-15 07:45:45 --> Model Class Initialized
INFO - 2018-07-15 07:45:45 --> Final output sent to browser
DEBUG - 2018-07-15 07:45:45 --> Total execution time: 0.0439
ERROR - 2018-07-15 07:45:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:45:47 --> Config Class Initialized
INFO - 2018-07-15 07:45:47 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:45:47 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:45:47 --> Utf8 Class Initialized
INFO - 2018-07-15 07:45:47 --> URI Class Initialized
INFO - 2018-07-15 07:45:47 --> Router Class Initialized
INFO - 2018-07-15 07:45:47 --> Output Class Initialized
INFO - 2018-07-15 07:45:47 --> Security Class Initialized
DEBUG - 2018-07-15 07:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:45:47 --> Input Class Initialized
INFO - 2018-07-15 07:45:47 --> Language Class Initialized
INFO - 2018-07-15 07:45:47 --> Loader Class Initialized
INFO - 2018-07-15 07:45:47 --> Controller Class Initialized
INFO - 2018-07-15 07:45:47 --> Database Driver Class Initialized
INFO - 2018-07-15 07:45:47 --> Model Class Initialized
INFO - 2018-07-15 07:45:47 --> Helper loaded: url_helper
INFO - 2018-07-15 07:45:47 --> Model Class Initialized
INFO - 2018-07-15 07:45:47 --> Final output sent to browser
DEBUG - 2018-07-15 07:45:47 --> Total execution time: 0.0387
ERROR - 2018-07-15 07:45:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:45:58 --> Config Class Initialized
INFO - 2018-07-15 07:45:58 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:45:58 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:45:58 --> Utf8 Class Initialized
INFO - 2018-07-15 07:45:58 --> URI Class Initialized
INFO - 2018-07-15 07:45:58 --> Router Class Initialized
INFO - 2018-07-15 07:45:58 --> Output Class Initialized
INFO - 2018-07-15 07:45:58 --> Security Class Initialized
DEBUG - 2018-07-15 07:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:45:58 --> Input Class Initialized
INFO - 2018-07-15 07:45:58 --> Language Class Initialized
INFO - 2018-07-15 07:45:58 --> Loader Class Initialized
INFO - 2018-07-15 07:45:58 --> Controller Class Initialized
INFO - 2018-07-15 07:45:58 --> Database Driver Class Initialized
INFO - 2018-07-15 07:45:58 --> Model Class Initialized
INFO - 2018-07-15 07:45:58 --> Helper loaded: url_helper
INFO - 2018-07-15 07:45:58 --> Model Class Initialized
INFO - 2018-07-15 07:45:58 --> Final output sent to browser
DEBUG - 2018-07-15 07:45:58 --> Total execution time: 0.0431
ERROR - 2018-07-15 07:46:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:46:01 --> Config Class Initialized
INFO - 2018-07-15 07:46:01 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:46:01 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:46:01 --> Utf8 Class Initialized
INFO - 2018-07-15 07:46:01 --> URI Class Initialized
INFO - 2018-07-15 07:46:01 --> Router Class Initialized
INFO - 2018-07-15 07:46:01 --> Output Class Initialized
INFO - 2018-07-15 07:46:01 --> Security Class Initialized
DEBUG - 2018-07-15 07:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:46:01 --> Input Class Initialized
INFO - 2018-07-15 07:46:01 --> Language Class Initialized
INFO - 2018-07-15 07:46:01 --> Loader Class Initialized
INFO - 2018-07-15 07:46:01 --> Controller Class Initialized
INFO - 2018-07-15 07:46:01 --> Database Driver Class Initialized
INFO - 2018-07-15 07:46:01 --> Model Class Initialized
INFO - 2018-07-15 07:46:01 --> Helper loaded: url_helper
INFO - 2018-07-15 07:46:01 --> Model Class Initialized
INFO - 2018-07-15 07:46:01 --> Final output sent to browser
DEBUG - 2018-07-15 07:46:01 --> Total execution time: 0.0462
ERROR - 2018-07-15 07:46:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:46:51 --> Config Class Initialized
INFO - 2018-07-15 07:46:51 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:46:51 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:46:51 --> Utf8 Class Initialized
INFO - 2018-07-15 07:46:51 --> URI Class Initialized
INFO - 2018-07-15 07:46:51 --> Router Class Initialized
INFO - 2018-07-15 07:46:51 --> Output Class Initialized
INFO - 2018-07-15 07:46:51 --> Security Class Initialized
DEBUG - 2018-07-15 07:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:46:51 --> Input Class Initialized
INFO - 2018-07-15 07:46:51 --> Language Class Initialized
INFO - 2018-07-15 07:46:51 --> Loader Class Initialized
INFO - 2018-07-15 07:46:51 --> Controller Class Initialized
INFO - 2018-07-15 07:46:51 --> Database Driver Class Initialized
INFO - 2018-07-15 07:46:51 --> Model Class Initialized
INFO - 2018-07-15 07:46:51 --> Helper loaded: url_helper
INFO - 2018-07-15 07:46:51 --> Model Class Initialized
INFO - 2018-07-15 07:46:51 --> Final output sent to browser
DEBUG - 2018-07-15 07:46:51 --> Total execution time: 0.0489
ERROR - 2018-07-15 07:46:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:46:52 --> Config Class Initialized
INFO - 2018-07-15 07:46:52 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:46:52 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:46:52 --> Utf8 Class Initialized
INFO - 2018-07-15 07:46:52 --> URI Class Initialized
INFO - 2018-07-15 07:46:52 --> Router Class Initialized
INFO - 2018-07-15 07:46:52 --> Output Class Initialized
INFO - 2018-07-15 07:46:52 --> Security Class Initialized
DEBUG - 2018-07-15 07:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:46:52 --> Input Class Initialized
INFO - 2018-07-15 07:46:52 --> Language Class Initialized
INFO - 2018-07-15 07:46:52 --> Loader Class Initialized
INFO - 2018-07-15 07:46:52 --> Controller Class Initialized
INFO - 2018-07-15 07:46:52 --> Database Driver Class Initialized
INFO - 2018-07-15 07:46:52 --> Model Class Initialized
INFO - 2018-07-15 07:46:52 --> Helper loaded: url_helper
INFO - 2018-07-15 07:46:52 --> Model Class Initialized
INFO - 2018-07-15 07:46:52 --> Final output sent to browser
DEBUG - 2018-07-15 07:46:52 --> Total execution time: 0.0415
ERROR - 2018-07-15 07:47:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:47:14 --> Config Class Initialized
INFO - 2018-07-15 07:47:14 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:47:14 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:47:14 --> Utf8 Class Initialized
INFO - 2018-07-15 07:47:14 --> URI Class Initialized
INFO - 2018-07-15 07:47:14 --> Router Class Initialized
INFO - 2018-07-15 07:47:14 --> Output Class Initialized
INFO - 2018-07-15 07:47:14 --> Security Class Initialized
DEBUG - 2018-07-15 07:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:47:14 --> Input Class Initialized
INFO - 2018-07-15 07:47:14 --> Language Class Initialized
INFO - 2018-07-15 07:47:14 --> Loader Class Initialized
INFO - 2018-07-15 07:47:14 --> Controller Class Initialized
INFO - 2018-07-15 07:47:14 --> Database Driver Class Initialized
INFO - 2018-07-15 07:47:14 --> Model Class Initialized
INFO - 2018-07-15 07:47:14 --> Helper loaded: url_helper
INFO - 2018-07-15 07:47:14 --> Model Class Initialized
INFO - 2018-07-15 07:47:14 --> Final output sent to browser
DEBUG - 2018-07-15 07:47:14 --> Total execution time: 0.0414
ERROR - 2018-07-15 07:47:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:47:18 --> Config Class Initialized
INFO - 2018-07-15 07:47:18 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:47:18 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:47:18 --> Utf8 Class Initialized
INFO - 2018-07-15 07:47:18 --> URI Class Initialized
INFO - 2018-07-15 07:47:18 --> Router Class Initialized
INFO - 2018-07-15 07:47:18 --> Output Class Initialized
INFO - 2018-07-15 07:47:18 --> Security Class Initialized
DEBUG - 2018-07-15 07:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:47:18 --> Input Class Initialized
INFO - 2018-07-15 07:47:18 --> Language Class Initialized
INFO - 2018-07-15 07:47:18 --> Loader Class Initialized
INFO - 2018-07-15 07:47:18 --> Controller Class Initialized
INFO - 2018-07-15 07:47:18 --> Database Driver Class Initialized
INFO - 2018-07-15 07:47:18 --> Model Class Initialized
INFO - 2018-07-15 07:47:18 --> Helper loaded: url_helper
INFO - 2018-07-15 07:47:18 --> Model Class Initialized
INFO - 2018-07-15 07:47:18 --> Final output sent to browser
DEBUG - 2018-07-15 07:47:18 --> Total execution time: 0.0467
ERROR - 2018-07-15 07:47:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:47:21 --> Config Class Initialized
INFO - 2018-07-15 07:47:21 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:47:21 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:47:21 --> Utf8 Class Initialized
INFO - 2018-07-15 07:47:21 --> URI Class Initialized
INFO - 2018-07-15 07:47:21 --> Router Class Initialized
INFO - 2018-07-15 07:47:21 --> Output Class Initialized
INFO - 2018-07-15 07:47:21 --> Security Class Initialized
DEBUG - 2018-07-15 07:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:47:21 --> Input Class Initialized
INFO - 2018-07-15 07:47:21 --> Language Class Initialized
INFO - 2018-07-15 07:47:21 --> Loader Class Initialized
INFO - 2018-07-15 07:47:21 --> Controller Class Initialized
INFO - 2018-07-15 07:47:21 --> Database Driver Class Initialized
INFO - 2018-07-15 07:47:21 --> Model Class Initialized
INFO - 2018-07-15 07:47:21 --> Helper loaded: url_helper
INFO - 2018-07-15 07:47:21 --> Model Class Initialized
INFO - 2018-07-15 07:47:21 --> Final output sent to browser
DEBUG - 2018-07-15 07:47:21 --> Total execution time: 0.0442
ERROR - 2018-07-15 07:47:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:47:23 --> Config Class Initialized
INFO - 2018-07-15 07:47:23 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:47:23 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:47:23 --> Utf8 Class Initialized
INFO - 2018-07-15 07:47:23 --> URI Class Initialized
INFO - 2018-07-15 07:47:23 --> Router Class Initialized
INFO - 2018-07-15 07:47:23 --> Output Class Initialized
INFO - 2018-07-15 07:47:23 --> Security Class Initialized
DEBUG - 2018-07-15 07:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:47:23 --> Input Class Initialized
INFO - 2018-07-15 07:47:23 --> Language Class Initialized
INFO - 2018-07-15 07:47:23 --> Loader Class Initialized
INFO - 2018-07-15 07:47:23 --> Controller Class Initialized
INFO - 2018-07-15 07:47:23 --> Database Driver Class Initialized
INFO - 2018-07-15 07:47:23 --> Model Class Initialized
INFO - 2018-07-15 07:47:23 --> Helper loaded: url_helper
INFO - 2018-07-15 07:47:23 --> Model Class Initialized
INFO - 2018-07-15 07:47:23 --> Final output sent to browser
DEBUG - 2018-07-15 07:47:23 --> Total execution time: 0.0424
ERROR - 2018-07-15 07:48:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:48:58 --> Config Class Initialized
INFO - 2018-07-15 07:48:58 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:48:58 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:48:58 --> Utf8 Class Initialized
INFO - 2018-07-15 07:48:58 --> URI Class Initialized
INFO - 2018-07-15 07:48:58 --> Router Class Initialized
INFO - 2018-07-15 07:48:58 --> Output Class Initialized
INFO - 2018-07-15 07:48:58 --> Security Class Initialized
DEBUG - 2018-07-15 07:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:48:58 --> Input Class Initialized
INFO - 2018-07-15 07:48:58 --> Language Class Initialized
INFO - 2018-07-15 07:48:58 --> Loader Class Initialized
INFO - 2018-07-15 07:48:58 --> Controller Class Initialized
INFO - 2018-07-15 07:48:58 --> Database Driver Class Initialized
INFO - 2018-07-15 07:48:58 --> Model Class Initialized
INFO - 2018-07-15 07:48:58 --> Helper loaded: url_helper
INFO - 2018-07-15 07:48:58 --> Model Class Initialized
INFO - 2018-07-15 07:48:58 --> Final output sent to browser
DEBUG - 2018-07-15 07:48:58 --> Total execution time: 0.0553
ERROR - 2018-07-15 07:48:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:48:59 --> Config Class Initialized
INFO - 2018-07-15 07:48:59 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:48:59 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:48:59 --> Utf8 Class Initialized
INFO - 2018-07-15 07:48:59 --> URI Class Initialized
INFO - 2018-07-15 07:48:59 --> Router Class Initialized
INFO - 2018-07-15 07:48:59 --> Output Class Initialized
INFO - 2018-07-15 07:48:59 --> Security Class Initialized
DEBUG - 2018-07-15 07:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:48:59 --> Input Class Initialized
INFO - 2018-07-15 07:48:59 --> Language Class Initialized
INFO - 2018-07-15 07:48:59 --> Loader Class Initialized
INFO - 2018-07-15 07:48:59 --> Controller Class Initialized
INFO - 2018-07-15 07:48:59 --> Database Driver Class Initialized
INFO - 2018-07-15 07:48:59 --> Model Class Initialized
INFO - 2018-07-15 07:48:59 --> Helper loaded: url_helper
INFO - 2018-07-15 07:48:59 --> Model Class Initialized
INFO - 2018-07-15 07:48:59 --> Final output sent to browser
DEBUG - 2018-07-15 07:48:59 --> Total execution time: 0.0722
ERROR - 2018-07-15 07:50:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:50:56 --> Config Class Initialized
INFO - 2018-07-15 07:50:56 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:50:56 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:50:56 --> Utf8 Class Initialized
INFO - 2018-07-15 07:50:56 --> URI Class Initialized
INFO - 2018-07-15 07:50:56 --> Router Class Initialized
INFO - 2018-07-15 07:50:56 --> Output Class Initialized
INFO - 2018-07-15 07:50:56 --> Security Class Initialized
DEBUG - 2018-07-15 07:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:50:56 --> Input Class Initialized
INFO - 2018-07-15 07:50:56 --> Language Class Initialized
INFO - 2018-07-15 07:50:56 --> Loader Class Initialized
INFO - 2018-07-15 07:50:56 --> Controller Class Initialized
INFO - 2018-07-15 07:50:56 --> Database Driver Class Initialized
INFO - 2018-07-15 07:50:56 --> Model Class Initialized
INFO - 2018-07-15 07:50:56 --> Helper loaded: url_helper
INFO - 2018-07-15 07:50:56 --> Model Class Initialized
INFO - 2018-07-15 07:50:56 --> Final output sent to browser
DEBUG - 2018-07-15 07:50:56 --> Total execution time: 0.0515
ERROR - 2018-07-15 07:51:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:51:54 --> Config Class Initialized
INFO - 2018-07-15 07:51:54 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:51:54 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:51:54 --> Utf8 Class Initialized
INFO - 2018-07-15 07:51:54 --> URI Class Initialized
INFO - 2018-07-15 07:51:54 --> Router Class Initialized
INFO - 2018-07-15 07:51:54 --> Output Class Initialized
INFO - 2018-07-15 07:51:54 --> Security Class Initialized
DEBUG - 2018-07-15 07:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:51:54 --> Input Class Initialized
INFO - 2018-07-15 07:51:54 --> Language Class Initialized
INFO - 2018-07-15 07:51:54 --> Loader Class Initialized
INFO - 2018-07-15 07:51:54 --> Controller Class Initialized
INFO - 2018-07-15 07:51:54 --> Database Driver Class Initialized
INFO - 2018-07-15 07:51:54 --> Model Class Initialized
INFO - 2018-07-15 07:51:54 --> Helper loaded: url_helper
INFO - 2018-07-15 07:51:54 --> Model Class Initialized
INFO - 2018-07-15 07:51:54 --> Final output sent to browser
DEBUG - 2018-07-15 07:51:54 --> Total execution time: 0.0400
ERROR - 2018-07-15 07:52:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:52:00 --> Config Class Initialized
INFO - 2018-07-15 07:52:00 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:52:00 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:52:00 --> Utf8 Class Initialized
INFO - 2018-07-15 07:52:00 --> URI Class Initialized
INFO - 2018-07-15 07:52:00 --> Router Class Initialized
INFO - 2018-07-15 07:52:00 --> Output Class Initialized
INFO - 2018-07-15 07:52:00 --> Security Class Initialized
DEBUG - 2018-07-15 07:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:52:00 --> Input Class Initialized
INFO - 2018-07-15 07:52:00 --> Language Class Initialized
INFO - 2018-07-15 07:52:00 --> Loader Class Initialized
INFO - 2018-07-15 07:52:00 --> Controller Class Initialized
INFO - 2018-07-15 07:52:00 --> Database Driver Class Initialized
INFO - 2018-07-15 07:52:00 --> Model Class Initialized
INFO - 2018-07-15 07:52:00 --> Helper loaded: url_helper
INFO - 2018-07-15 07:52:00 --> Model Class Initialized
INFO - 2018-07-15 07:52:00 --> Final output sent to browser
DEBUG - 2018-07-15 07:52:00 --> Total execution time: 0.0475
ERROR - 2018-07-15 07:53:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:53:52 --> Config Class Initialized
INFO - 2018-07-15 07:53:52 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:53:52 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:53:52 --> Utf8 Class Initialized
INFO - 2018-07-15 07:53:52 --> URI Class Initialized
INFO - 2018-07-15 07:53:52 --> Router Class Initialized
INFO - 2018-07-15 07:53:52 --> Output Class Initialized
INFO - 2018-07-15 07:53:52 --> Security Class Initialized
DEBUG - 2018-07-15 07:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:53:52 --> Input Class Initialized
INFO - 2018-07-15 07:53:52 --> Language Class Initialized
INFO - 2018-07-15 07:53:52 --> Loader Class Initialized
INFO - 2018-07-15 07:53:52 --> Controller Class Initialized
INFO - 2018-07-15 07:53:52 --> Database Driver Class Initialized
INFO - 2018-07-15 07:53:52 --> Model Class Initialized
INFO - 2018-07-15 07:53:52 --> Helper loaded: url_helper
INFO - 2018-07-15 07:53:52 --> Model Class Initialized
INFO - 2018-07-15 07:53:52 --> Final output sent to browser
DEBUG - 2018-07-15 07:53:52 --> Total execution time: 0.0397
ERROR - 2018-07-15 07:53:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:53:52 --> Config Class Initialized
INFO - 2018-07-15 07:53:52 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:53:52 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:53:52 --> Utf8 Class Initialized
INFO - 2018-07-15 07:53:52 --> URI Class Initialized
INFO - 2018-07-15 07:53:52 --> Router Class Initialized
INFO - 2018-07-15 07:53:52 --> Output Class Initialized
INFO - 2018-07-15 07:53:52 --> Security Class Initialized
DEBUG - 2018-07-15 07:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:53:52 --> Input Class Initialized
INFO - 2018-07-15 07:53:52 --> Language Class Initialized
INFO - 2018-07-15 07:53:52 --> Loader Class Initialized
INFO - 2018-07-15 07:53:52 --> Controller Class Initialized
INFO - 2018-07-15 07:53:52 --> Database Driver Class Initialized
INFO - 2018-07-15 07:53:52 --> Model Class Initialized
INFO - 2018-07-15 07:53:52 --> Helper loaded: url_helper
INFO - 2018-07-15 07:53:52 --> Model Class Initialized
INFO - 2018-07-15 07:53:52 --> Final output sent to browser
DEBUG - 2018-07-15 07:53:52 --> Total execution time: 0.0526
ERROR - 2018-07-15 07:54:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:54:09 --> Config Class Initialized
INFO - 2018-07-15 07:54:09 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:54:09 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:54:09 --> Utf8 Class Initialized
INFO - 2018-07-15 07:54:09 --> URI Class Initialized
INFO - 2018-07-15 07:54:09 --> Router Class Initialized
INFO - 2018-07-15 07:54:09 --> Output Class Initialized
INFO - 2018-07-15 07:54:09 --> Security Class Initialized
DEBUG - 2018-07-15 07:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:54:09 --> Input Class Initialized
INFO - 2018-07-15 07:54:09 --> Language Class Initialized
INFO - 2018-07-15 07:54:09 --> Loader Class Initialized
INFO - 2018-07-15 07:54:09 --> Controller Class Initialized
INFO - 2018-07-15 07:54:09 --> Database Driver Class Initialized
INFO - 2018-07-15 07:54:09 --> Model Class Initialized
INFO - 2018-07-15 07:54:09 --> Helper loaded: url_helper
INFO - 2018-07-15 07:54:09 --> Model Class Initialized
INFO - 2018-07-15 07:54:09 --> Final output sent to browser
DEBUG - 2018-07-15 07:54:09 --> Total execution time: 0.0633
ERROR - 2018-07-15 07:54:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:54:11 --> Config Class Initialized
INFO - 2018-07-15 07:54:11 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:54:11 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:54:11 --> Utf8 Class Initialized
INFO - 2018-07-15 07:54:11 --> URI Class Initialized
INFO - 2018-07-15 07:54:11 --> Router Class Initialized
INFO - 2018-07-15 07:54:11 --> Output Class Initialized
INFO - 2018-07-15 07:54:11 --> Security Class Initialized
DEBUG - 2018-07-15 07:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:54:11 --> Input Class Initialized
INFO - 2018-07-15 07:54:11 --> Language Class Initialized
INFO - 2018-07-15 07:54:11 --> Loader Class Initialized
INFO - 2018-07-15 07:54:11 --> Controller Class Initialized
INFO - 2018-07-15 07:54:11 --> Database Driver Class Initialized
INFO - 2018-07-15 07:54:11 --> Model Class Initialized
INFO - 2018-07-15 07:54:11 --> Helper loaded: url_helper
INFO - 2018-07-15 07:54:11 --> Model Class Initialized
INFO - 2018-07-15 07:54:11 --> Final output sent to browser
DEBUG - 2018-07-15 07:54:11 --> Total execution time: 0.0380
ERROR - 2018-07-15 07:54:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:54:13 --> Config Class Initialized
INFO - 2018-07-15 07:54:13 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:54:13 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:54:13 --> Utf8 Class Initialized
INFO - 2018-07-15 07:54:13 --> URI Class Initialized
INFO - 2018-07-15 07:54:13 --> Router Class Initialized
INFO - 2018-07-15 07:54:13 --> Output Class Initialized
INFO - 2018-07-15 07:54:13 --> Security Class Initialized
DEBUG - 2018-07-15 07:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:54:13 --> Input Class Initialized
INFO - 2018-07-15 07:54:13 --> Language Class Initialized
INFO - 2018-07-15 07:54:13 --> Loader Class Initialized
INFO - 2018-07-15 07:54:13 --> Controller Class Initialized
INFO - 2018-07-15 07:54:13 --> Database Driver Class Initialized
INFO - 2018-07-15 07:54:13 --> Model Class Initialized
INFO - 2018-07-15 07:54:14 --> Helper loaded: url_helper
INFO - 2018-07-15 07:54:14 --> Model Class Initialized
INFO - 2018-07-15 07:54:14 --> Final output sent to browser
DEBUG - 2018-07-15 07:54:14 --> Total execution time: 0.0628
ERROR - 2018-07-15 07:54:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:54:15 --> Config Class Initialized
INFO - 2018-07-15 07:54:15 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:54:15 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:54:15 --> Utf8 Class Initialized
INFO - 2018-07-15 07:54:15 --> URI Class Initialized
INFO - 2018-07-15 07:54:15 --> Router Class Initialized
INFO - 2018-07-15 07:54:15 --> Output Class Initialized
INFO - 2018-07-15 07:54:15 --> Security Class Initialized
DEBUG - 2018-07-15 07:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:54:15 --> Input Class Initialized
INFO - 2018-07-15 07:54:15 --> Language Class Initialized
INFO - 2018-07-15 07:54:15 --> Loader Class Initialized
INFO - 2018-07-15 07:54:15 --> Controller Class Initialized
INFO - 2018-07-15 07:54:15 --> Database Driver Class Initialized
INFO - 2018-07-15 07:54:15 --> Model Class Initialized
INFO - 2018-07-15 07:54:15 --> Helper loaded: url_helper
INFO - 2018-07-15 07:54:15 --> Model Class Initialized
INFO - 2018-07-15 07:54:15 --> Final output sent to browser
DEBUG - 2018-07-15 07:54:15 --> Total execution time: 0.0392
ERROR - 2018-07-15 07:54:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:54:54 --> Config Class Initialized
INFO - 2018-07-15 07:54:54 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:54:54 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:54:54 --> Utf8 Class Initialized
INFO - 2018-07-15 07:54:54 --> URI Class Initialized
INFO - 2018-07-15 07:54:54 --> Router Class Initialized
INFO - 2018-07-15 07:54:54 --> Output Class Initialized
INFO - 2018-07-15 07:54:54 --> Security Class Initialized
DEBUG - 2018-07-15 07:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:54:54 --> Input Class Initialized
INFO - 2018-07-15 07:54:54 --> Language Class Initialized
INFO - 2018-07-15 07:54:54 --> Loader Class Initialized
INFO - 2018-07-15 07:54:54 --> Controller Class Initialized
INFO - 2018-07-15 07:54:54 --> Database Driver Class Initialized
INFO - 2018-07-15 07:54:54 --> Model Class Initialized
INFO - 2018-07-15 07:54:54 --> Helper loaded: url_helper
INFO - 2018-07-15 07:54:54 --> Model Class Initialized
INFO - 2018-07-15 07:54:54 --> Final output sent to browser
DEBUG - 2018-07-15 07:54:54 --> Total execution time: 0.0579
ERROR - 2018-07-15 07:55:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:55:27 --> Config Class Initialized
INFO - 2018-07-15 07:55:27 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:55:27 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:55:27 --> Utf8 Class Initialized
INFO - 2018-07-15 07:55:27 --> URI Class Initialized
INFO - 2018-07-15 07:55:27 --> Router Class Initialized
INFO - 2018-07-15 07:55:27 --> Output Class Initialized
INFO - 2018-07-15 07:55:27 --> Security Class Initialized
DEBUG - 2018-07-15 07:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:55:27 --> Input Class Initialized
INFO - 2018-07-15 07:55:27 --> Language Class Initialized
INFO - 2018-07-15 07:55:27 --> Loader Class Initialized
INFO - 2018-07-15 07:55:27 --> Controller Class Initialized
INFO - 2018-07-15 07:55:27 --> Database Driver Class Initialized
INFO - 2018-07-15 07:55:27 --> Model Class Initialized
INFO - 2018-07-15 07:55:27 --> Helper loaded: url_helper
INFO - 2018-07-15 07:55:27 --> Model Class Initialized
INFO - 2018-07-15 07:55:27 --> Final output sent to browser
DEBUG - 2018-07-15 07:55:27 --> Total execution time: 0.0660
ERROR - 2018-07-15 07:55:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:55:47 --> Config Class Initialized
INFO - 2018-07-15 07:55:47 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:55:47 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:55:47 --> Utf8 Class Initialized
INFO - 2018-07-15 07:55:47 --> URI Class Initialized
INFO - 2018-07-15 07:55:47 --> Router Class Initialized
INFO - 2018-07-15 07:55:47 --> Output Class Initialized
INFO - 2018-07-15 07:55:47 --> Security Class Initialized
DEBUG - 2018-07-15 07:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:55:47 --> Input Class Initialized
INFO - 2018-07-15 07:55:47 --> Language Class Initialized
INFO - 2018-07-15 07:55:47 --> Loader Class Initialized
INFO - 2018-07-15 07:55:47 --> Controller Class Initialized
INFO - 2018-07-15 07:55:47 --> Database Driver Class Initialized
INFO - 2018-07-15 07:55:47 --> Model Class Initialized
INFO - 2018-07-15 07:55:47 --> Helper loaded: url_helper
INFO - 2018-07-15 07:55:47 --> Model Class Initialized
INFO - 2018-07-15 07:55:47 --> Final output sent to browser
DEBUG - 2018-07-15 07:55:47 --> Total execution time: 0.0565
ERROR - 2018-07-15 07:55:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:55:47 --> Config Class Initialized
INFO - 2018-07-15 07:55:47 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:55:47 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:55:47 --> Utf8 Class Initialized
INFO - 2018-07-15 07:55:47 --> URI Class Initialized
INFO - 2018-07-15 07:55:47 --> Router Class Initialized
INFO - 2018-07-15 07:55:47 --> Output Class Initialized
INFO - 2018-07-15 07:55:47 --> Security Class Initialized
DEBUG - 2018-07-15 07:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:55:47 --> Input Class Initialized
INFO - 2018-07-15 07:55:47 --> Language Class Initialized
INFO - 2018-07-15 07:55:47 --> Loader Class Initialized
INFO - 2018-07-15 07:55:47 --> Controller Class Initialized
INFO - 2018-07-15 07:55:47 --> Database Driver Class Initialized
INFO - 2018-07-15 07:55:47 --> Model Class Initialized
INFO - 2018-07-15 07:55:47 --> Helper loaded: url_helper
INFO - 2018-07-15 07:55:47 --> Model Class Initialized
INFO - 2018-07-15 07:55:47 --> Final output sent to browser
DEBUG - 2018-07-15 07:55:47 --> Total execution time: 0.0368
ERROR - 2018-07-15 07:56:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:56:22 --> Config Class Initialized
INFO - 2018-07-15 07:56:22 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:56:22 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:56:22 --> Utf8 Class Initialized
INFO - 2018-07-15 07:56:22 --> URI Class Initialized
INFO - 2018-07-15 07:56:22 --> Router Class Initialized
INFO - 2018-07-15 07:56:22 --> Output Class Initialized
INFO - 2018-07-15 07:56:22 --> Security Class Initialized
DEBUG - 2018-07-15 07:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:56:22 --> Input Class Initialized
INFO - 2018-07-15 07:56:22 --> Language Class Initialized
INFO - 2018-07-15 07:56:22 --> Loader Class Initialized
INFO - 2018-07-15 07:56:22 --> Controller Class Initialized
INFO - 2018-07-15 07:56:22 --> Database Driver Class Initialized
INFO - 2018-07-15 07:56:22 --> Model Class Initialized
INFO - 2018-07-15 07:56:22 --> Helper loaded: url_helper
INFO - 2018-07-15 07:56:22 --> Model Class Initialized
INFO - 2018-07-15 07:56:22 --> Final output sent to browser
DEBUG - 2018-07-15 07:56:22 --> Total execution time: 0.0757
ERROR - 2018-07-15 07:56:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:56:26 --> Config Class Initialized
INFO - 2018-07-15 07:56:26 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:56:26 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:56:26 --> Utf8 Class Initialized
INFO - 2018-07-15 07:56:26 --> URI Class Initialized
INFO - 2018-07-15 07:56:26 --> Router Class Initialized
INFO - 2018-07-15 07:56:26 --> Output Class Initialized
INFO - 2018-07-15 07:56:26 --> Security Class Initialized
DEBUG - 2018-07-15 07:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:56:26 --> Input Class Initialized
INFO - 2018-07-15 07:56:26 --> Language Class Initialized
INFO - 2018-07-15 07:56:26 --> Loader Class Initialized
INFO - 2018-07-15 07:56:26 --> Controller Class Initialized
INFO - 2018-07-15 07:56:26 --> Database Driver Class Initialized
INFO - 2018-07-15 07:56:26 --> Model Class Initialized
INFO - 2018-07-15 07:56:26 --> Helper loaded: url_helper
INFO - 2018-07-15 07:56:26 --> Model Class Initialized
INFO - 2018-07-15 07:56:26 --> Final output sent to browser
DEBUG - 2018-07-15 07:56:26 --> Total execution time: 0.0552
ERROR - 2018-07-15 07:56:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:56:29 --> Config Class Initialized
INFO - 2018-07-15 07:56:29 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:56:29 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:56:29 --> Utf8 Class Initialized
INFO - 2018-07-15 07:56:29 --> URI Class Initialized
INFO - 2018-07-15 07:56:29 --> Router Class Initialized
INFO - 2018-07-15 07:56:29 --> Output Class Initialized
INFO - 2018-07-15 07:56:29 --> Security Class Initialized
DEBUG - 2018-07-15 07:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:56:29 --> Input Class Initialized
INFO - 2018-07-15 07:56:29 --> Language Class Initialized
INFO - 2018-07-15 07:56:29 --> Loader Class Initialized
INFO - 2018-07-15 07:56:29 --> Controller Class Initialized
INFO - 2018-07-15 07:56:29 --> Database Driver Class Initialized
INFO - 2018-07-15 07:56:29 --> Model Class Initialized
INFO - 2018-07-15 07:56:29 --> Helper loaded: url_helper
INFO - 2018-07-15 07:56:29 --> Model Class Initialized
INFO - 2018-07-15 07:56:29 --> Final output sent to browser
DEBUG - 2018-07-15 07:56:29 --> Total execution time: 0.0446
ERROR - 2018-07-15 07:56:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:56:38 --> Config Class Initialized
INFO - 2018-07-15 07:56:38 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:56:38 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:56:38 --> Utf8 Class Initialized
INFO - 2018-07-15 07:56:38 --> URI Class Initialized
INFO - 2018-07-15 07:56:38 --> Router Class Initialized
INFO - 2018-07-15 07:56:38 --> Output Class Initialized
INFO - 2018-07-15 07:56:38 --> Security Class Initialized
DEBUG - 2018-07-15 07:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:56:38 --> Input Class Initialized
INFO - 2018-07-15 07:56:38 --> Language Class Initialized
INFO - 2018-07-15 07:56:38 --> Loader Class Initialized
INFO - 2018-07-15 07:56:38 --> Controller Class Initialized
INFO - 2018-07-15 07:56:38 --> Database Driver Class Initialized
INFO - 2018-07-15 07:56:38 --> Model Class Initialized
INFO - 2018-07-15 07:56:38 --> Helper loaded: url_helper
INFO - 2018-07-15 07:56:38 --> Model Class Initialized
INFO - 2018-07-15 07:56:38 --> Final output sent to browser
DEBUG - 2018-07-15 07:56:38 --> Total execution time: 0.0643
ERROR - 2018-07-15 07:56:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:56:40 --> Config Class Initialized
INFO - 2018-07-15 07:56:40 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:56:40 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:56:40 --> Utf8 Class Initialized
INFO - 2018-07-15 07:56:40 --> URI Class Initialized
INFO - 2018-07-15 07:56:40 --> Router Class Initialized
INFO - 2018-07-15 07:56:40 --> Output Class Initialized
INFO - 2018-07-15 07:56:40 --> Security Class Initialized
DEBUG - 2018-07-15 07:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:56:40 --> Input Class Initialized
INFO - 2018-07-15 07:56:40 --> Language Class Initialized
INFO - 2018-07-15 07:56:40 --> Loader Class Initialized
INFO - 2018-07-15 07:56:40 --> Controller Class Initialized
INFO - 2018-07-15 07:56:40 --> Database Driver Class Initialized
INFO - 2018-07-15 07:56:40 --> Model Class Initialized
INFO - 2018-07-15 07:56:40 --> Helper loaded: url_helper
INFO - 2018-07-15 07:56:40 --> Model Class Initialized
INFO - 2018-07-15 07:56:40 --> Final output sent to browser
DEBUG - 2018-07-15 07:56:40 --> Total execution time: 0.0367
ERROR - 2018-07-15 07:57:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:57:12 --> Config Class Initialized
INFO - 2018-07-15 07:57:12 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:57:12 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:57:12 --> Utf8 Class Initialized
INFO - 2018-07-15 07:57:12 --> URI Class Initialized
INFO - 2018-07-15 07:57:12 --> Router Class Initialized
INFO - 2018-07-15 07:57:12 --> Output Class Initialized
INFO - 2018-07-15 07:57:12 --> Security Class Initialized
DEBUG - 2018-07-15 07:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:57:12 --> Input Class Initialized
INFO - 2018-07-15 07:57:12 --> Language Class Initialized
INFO - 2018-07-15 07:57:12 --> Loader Class Initialized
INFO - 2018-07-15 07:57:12 --> Controller Class Initialized
INFO - 2018-07-15 07:57:12 --> Database Driver Class Initialized
INFO - 2018-07-15 07:57:12 --> Model Class Initialized
INFO - 2018-07-15 07:57:12 --> Helper loaded: url_helper
INFO - 2018-07-15 07:57:12 --> Model Class Initialized
INFO - 2018-07-15 07:57:12 --> Final output sent to browser
DEBUG - 2018-07-15 07:57:12 --> Total execution time: 0.0594
ERROR - 2018-07-15 07:57:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:57:29 --> Config Class Initialized
INFO - 2018-07-15 07:57:29 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:57:29 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:57:29 --> Utf8 Class Initialized
INFO - 2018-07-15 07:57:29 --> URI Class Initialized
INFO - 2018-07-15 07:57:29 --> Router Class Initialized
INFO - 2018-07-15 07:57:29 --> Output Class Initialized
INFO - 2018-07-15 07:57:29 --> Security Class Initialized
DEBUG - 2018-07-15 07:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:57:29 --> Input Class Initialized
INFO - 2018-07-15 07:57:29 --> Language Class Initialized
INFO - 2018-07-15 07:57:29 --> Loader Class Initialized
INFO - 2018-07-15 07:57:29 --> Controller Class Initialized
INFO - 2018-07-15 07:57:29 --> Database Driver Class Initialized
INFO - 2018-07-15 07:57:29 --> Model Class Initialized
INFO - 2018-07-15 07:57:29 --> Helper loaded: url_helper
INFO - 2018-07-15 07:57:29 --> Model Class Initialized
INFO - 2018-07-15 07:57:29 --> Final output sent to browser
DEBUG - 2018-07-15 07:57:29 --> Total execution time: 0.0502
ERROR - 2018-07-15 07:57:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:57:41 --> Config Class Initialized
INFO - 2018-07-15 07:57:41 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:57:41 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:57:41 --> Utf8 Class Initialized
INFO - 2018-07-15 07:57:41 --> URI Class Initialized
INFO - 2018-07-15 07:57:41 --> Router Class Initialized
INFO - 2018-07-15 07:57:41 --> Output Class Initialized
INFO - 2018-07-15 07:57:41 --> Security Class Initialized
DEBUG - 2018-07-15 07:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:57:41 --> Input Class Initialized
INFO - 2018-07-15 07:57:41 --> Language Class Initialized
INFO - 2018-07-15 07:57:41 --> Loader Class Initialized
INFO - 2018-07-15 07:57:41 --> Controller Class Initialized
INFO - 2018-07-15 07:57:41 --> Database Driver Class Initialized
INFO - 2018-07-15 07:57:41 --> Model Class Initialized
INFO - 2018-07-15 07:57:41 --> Helper loaded: url_helper
INFO - 2018-07-15 07:57:41 --> Model Class Initialized
INFO - 2018-07-15 07:57:41 --> Final output sent to browser
DEBUG - 2018-07-15 07:57:41 --> Total execution time: 0.0366
ERROR - 2018-07-15 07:58:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:58:41 --> Config Class Initialized
INFO - 2018-07-15 07:58:41 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:58:41 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:58:41 --> Utf8 Class Initialized
INFO - 2018-07-15 07:58:41 --> URI Class Initialized
INFO - 2018-07-15 07:58:41 --> Router Class Initialized
INFO - 2018-07-15 07:58:41 --> Output Class Initialized
INFO - 2018-07-15 07:58:41 --> Security Class Initialized
DEBUG - 2018-07-15 07:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:58:41 --> Input Class Initialized
INFO - 2018-07-15 07:58:41 --> Language Class Initialized
INFO - 2018-07-15 07:58:41 --> Loader Class Initialized
INFO - 2018-07-15 07:58:41 --> Controller Class Initialized
INFO - 2018-07-15 07:58:41 --> Database Driver Class Initialized
INFO - 2018-07-15 07:58:41 --> Model Class Initialized
INFO - 2018-07-15 07:58:41 --> Helper loaded: url_helper
INFO - 2018-07-15 07:58:41 --> Model Class Initialized
INFO - 2018-07-15 07:58:41 --> Final output sent to browser
DEBUG - 2018-07-15 07:58:41 --> Total execution time: 0.0417
ERROR - 2018-07-15 07:58:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:58:42 --> Config Class Initialized
INFO - 2018-07-15 07:58:42 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:58:42 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:58:42 --> Utf8 Class Initialized
INFO - 2018-07-15 07:58:42 --> URI Class Initialized
INFO - 2018-07-15 07:58:42 --> Router Class Initialized
INFO - 2018-07-15 07:58:42 --> Output Class Initialized
INFO - 2018-07-15 07:58:42 --> Security Class Initialized
DEBUG - 2018-07-15 07:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:58:42 --> Input Class Initialized
INFO - 2018-07-15 07:58:42 --> Language Class Initialized
INFO - 2018-07-15 07:58:42 --> Loader Class Initialized
INFO - 2018-07-15 07:58:42 --> Controller Class Initialized
INFO - 2018-07-15 07:58:42 --> Database Driver Class Initialized
INFO - 2018-07-15 07:58:42 --> Model Class Initialized
INFO - 2018-07-15 07:58:42 --> Helper loaded: url_helper
INFO - 2018-07-15 07:58:42 --> Model Class Initialized
INFO - 2018-07-15 07:58:42 --> Final output sent to browser
DEBUG - 2018-07-15 07:58:42 --> Total execution time: 0.0396
ERROR - 2018-07-15 07:59:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:59:45 --> Config Class Initialized
INFO - 2018-07-15 07:59:45 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:59:45 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:59:45 --> Utf8 Class Initialized
INFO - 2018-07-15 07:59:45 --> URI Class Initialized
INFO - 2018-07-15 07:59:45 --> Router Class Initialized
INFO - 2018-07-15 07:59:45 --> Output Class Initialized
INFO - 2018-07-15 07:59:45 --> Security Class Initialized
DEBUG - 2018-07-15 07:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:59:45 --> Input Class Initialized
INFO - 2018-07-15 07:59:45 --> Language Class Initialized
INFO - 2018-07-15 07:59:45 --> Loader Class Initialized
INFO - 2018-07-15 07:59:45 --> Controller Class Initialized
INFO - 2018-07-15 07:59:45 --> Database Driver Class Initialized
INFO - 2018-07-15 07:59:45 --> Model Class Initialized
INFO - 2018-07-15 07:59:45 --> Helper loaded: url_helper
INFO - 2018-07-15 07:59:45 --> Model Class Initialized
INFO - 2018-07-15 07:59:45 --> Final output sent to browser
DEBUG - 2018-07-15 07:59:45 --> Total execution time: 0.0567
ERROR - 2018-07-15 07:59:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 07:59:47 --> Config Class Initialized
INFO - 2018-07-15 07:59:47 --> Hooks Class Initialized
DEBUG - 2018-07-15 07:59:47 --> UTF-8 Support Enabled
INFO - 2018-07-15 07:59:47 --> Utf8 Class Initialized
INFO - 2018-07-15 07:59:47 --> URI Class Initialized
INFO - 2018-07-15 07:59:47 --> Router Class Initialized
INFO - 2018-07-15 07:59:47 --> Output Class Initialized
INFO - 2018-07-15 07:59:47 --> Security Class Initialized
DEBUG - 2018-07-15 07:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 07:59:47 --> Input Class Initialized
INFO - 2018-07-15 07:59:47 --> Language Class Initialized
INFO - 2018-07-15 07:59:47 --> Loader Class Initialized
INFO - 2018-07-15 07:59:47 --> Controller Class Initialized
INFO - 2018-07-15 07:59:47 --> Database Driver Class Initialized
INFO - 2018-07-15 07:59:47 --> Model Class Initialized
INFO - 2018-07-15 07:59:47 --> Helper loaded: url_helper
INFO - 2018-07-15 07:59:47 --> Model Class Initialized
INFO - 2018-07-15 07:59:47 --> Final output sent to browser
DEBUG - 2018-07-15 07:59:47 --> Total execution time: 0.0380
ERROR - 2018-07-15 08:00:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:00:13 --> Config Class Initialized
INFO - 2018-07-15 08:00:13 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:00:13 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:00:13 --> Utf8 Class Initialized
INFO - 2018-07-15 08:00:13 --> URI Class Initialized
INFO - 2018-07-15 08:00:13 --> Router Class Initialized
INFO - 2018-07-15 08:00:13 --> Output Class Initialized
INFO - 2018-07-15 08:00:13 --> Security Class Initialized
DEBUG - 2018-07-15 08:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:00:13 --> Input Class Initialized
INFO - 2018-07-15 08:00:13 --> Language Class Initialized
INFO - 2018-07-15 08:00:13 --> Loader Class Initialized
INFO - 2018-07-15 08:00:13 --> Controller Class Initialized
INFO - 2018-07-15 08:00:13 --> Database Driver Class Initialized
INFO - 2018-07-15 08:00:13 --> Model Class Initialized
INFO - 2018-07-15 08:00:13 --> Helper loaded: url_helper
INFO - 2018-07-15 08:00:13 --> Model Class Initialized
INFO - 2018-07-15 08:00:13 --> Final output sent to browser
DEBUG - 2018-07-15 08:00:13 --> Total execution time: 0.0494
ERROR - 2018-07-15 08:10:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:10:42 --> Config Class Initialized
INFO - 2018-07-15 08:10:42 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:10:42 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:10:42 --> Utf8 Class Initialized
INFO - 2018-07-15 08:10:42 --> URI Class Initialized
INFO - 2018-07-15 08:10:42 --> Router Class Initialized
INFO - 2018-07-15 08:10:42 --> Output Class Initialized
INFO - 2018-07-15 08:10:42 --> Security Class Initialized
DEBUG - 2018-07-15 08:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:10:42 --> Input Class Initialized
INFO - 2018-07-15 08:10:42 --> Language Class Initialized
INFO - 2018-07-15 08:10:42 --> Loader Class Initialized
INFO - 2018-07-15 08:10:42 --> Controller Class Initialized
INFO - 2018-07-15 08:10:42 --> Database Driver Class Initialized
INFO - 2018-07-15 08:10:42 --> Model Class Initialized
INFO - 2018-07-15 08:10:42 --> Helper loaded: url_helper
INFO - 2018-07-15 08:10:42 --> Model Class Initialized
INFO - 2018-07-15 08:10:42 --> Final output sent to browser
DEBUG - 2018-07-15 08:10:42 --> Total execution time: 0.0469
ERROR - 2018-07-15 08:10:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:10:42 --> Config Class Initialized
INFO - 2018-07-15 08:10:42 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:10:42 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:10:42 --> Utf8 Class Initialized
INFO - 2018-07-15 08:10:42 --> URI Class Initialized
INFO - 2018-07-15 08:10:42 --> Router Class Initialized
INFO - 2018-07-15 08:10:42 --> Output Class Initialized
INFO - 2018-07-15 08:10:42 --> Security Class Initialized
DEBUG - 2018-07-15 08:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:10:42 --> Input Class Initialized
INFO - 2018-07-15 08:10:42 --> Language Class Initialized
INFO - 2018-07-15 08:10:42 --> Loader Class Initialized
INFO - 2018-07-15 08:10:42 --> Controller Class Initialized
INFO - 2018-07-15 08:10:42 --> Database Driver Class Initialized
INFO - 2018-07-15 08:10:42 --> Model Class Initialized
INFO - 2018-07-15 08:10:42 --> Helper loaded: url_helper
INFO - 2018-07-15 08:10:42 --> Model Class Initialized
INFO - 2018-07-15 08:10:42 --> Final output sent to browser
DEBUG - 2018-07-15 08:10:42 --> Total execution time: 0.0672
ERROR - 2018-07-15 08:12:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:12:42 --> Config Class Initialized
INFO - 2018-07-15 08:12:42 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:12:42 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:12:42 --> Utf8 Class Initialized
INFO - 2018-07-15 08:12:42 --> URI Class Initialized
INFO - 2018-07-15 08:12:42 --> Router Class Initialized
INFO - 2018-07-15 08:12:42 --> Output Class Initialized
INFO - 2018-07-15 08:12:42 --> Security Class Initialized
DEBUG - 2018-07-15 08:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:12:42 --> Input Class Initialized
INFO - 2018-07-15 08:12:42 --> Language Class Initialized
INFO - 2018-07-15 08:12:42 --> Loader Class Initialized
INFO - 2018-07-15 08:12:42 --> Controller Class Initialized
INFO - 2018-07-15 08:12:42 --> Database Driver Class Initialized
INFO - 2018-07-15 08:12:42 --> Model Class Initialized
INFO - 2018-07-15 08:12:42 --> Helper loaded: url_helper
INFO - 2018-07-15 08:12:42 --> Model Class Initialized
INFO - 2018-07-15 08:12:42 --> Final output sent to browser
DEBUG - 2018-07-15 08:12:42 --> Total execution time: 0.0627
ERROR - 2018-07-15 08:12:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:12:42 --> Config Class Initialized
INFO - 2018-07-15 08:12:42 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:12:42 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:12:42 --> Utf8 Class Initialized
INFO - 2018-07-15 08:12:42 --> URI Class Initialized
INFO - 2018-07-15 08:12:42 --> Router Class Initialized
INFO - 2018-07-15 08:12:42 --> Output Class Initialized
INFO - 2018-07-15 08:12:42 --> Security Class Initialized
DEBUG - 2018-07-15 08:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:12:42 --> Input Class Initialized
INFO - 2018-07-15 08:12:42 --> Language Class Initialized
INFO - 2018-07-15 08:12:42 --> Loader Class Initialized
INFO - 2018-07-15 08:12:42 --> Controller Class Initialized
INFO - 2018-07-15 08:12:42 --> Database Driver Class Initialized
INFO - 2018-07-15 08:12:42 --> Model Class Initialized
INFO - 2018-07-15 08:12:42 --> Helper loaded: url_helper
INFO - 2018-07-15 08:12:42 --> Model Class Initialized
INFO - 2018-07-15 08:12:42 --> Final output sent to browser
DEBUG - 2018-07-15 08:12:42 --> Total execution time: 0.0514
ERROR - 2018-07-15 08:14:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:14:59 --> Config Class Initialized
INFO - 2018-07-15 08:14:59 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:14:59 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:14:59 --> Utf8 Class Initialized
INFO - 2018-07-15 08:14:59 --> URI Class Initialized
INFO - 2018-07-15 08:14:59 --> Router Class Initialized
INFO - 2018-07-15 08:14:59 --> Output Class Initialized
INFO - 2018-07-15 08:14:59 --> Security Class Initialized
DEBUG - 2018-07-15 08:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:14:59 --> Input Class Initialized
INFO - 2018-07-15 08:14:59 --> Language Class Initialized
INFO - 2018-07-15 08:14:59 --> Loader Class Initialized
INFO - 2018-07-15 08:14:59 --> Controller Class Initialized
INFO - 2018-07-15 08:14:59 --> Database Driver Class Initialized
INFO - 2018-07-15 08:14:59 --> Model Class Initialized
INFO - 2018-07-15 08:14:59 --> Helper loaded: url_helper
INFO - 2018-07-15 08:14:59 --> Model Class Initialized
INFO - 2018-07-15 08:14:59 --> Final output sent to browser
DEBUG - 2018-07-15 08:14:59 --> Total execution time: 0.0361
ERROR - 2018-07-15 08:15:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:15:00 --> Config Class Initialized
INFO - 2018-07-15 08:15:00 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:15:00 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:15:00 --> Utf8 Class Initialized
INFO - 2018-07-15 08:15:00 --> URI Class Initialized
INFO - 2018-07-15 08:15:00 --> Router Class Initialized
INFO - 2018-07-15 08:15:00 --> Output Class Initialized
INFO - 2018-07-15 08:15:00 --> Security Class Initialized
DEBUG - 2018-07-15 08:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:15:00 --> Input Class Initialized
INFO - 2018-07-15 08:15:00 --> Language Class Initialized
INFO - 2018-07-15 08:15:00 --> Loader Class Initialized
INFO - 2018-07-15 08:15:00 --> Controller Class Initialized
INFO - 2018-07-15 08:15:00 --> Database Driver Class Initialized
INFO - 2018-07-15 08:15:00 --> Model Class Initialized
INFO - 2018-07-15 08:15:00 --> Helper loaded: url_helper
INFO - 2018-07-15 08:15:00 --> Model Class Initialized
INFO - 2018-07-15 08:15:00 --> Final output sent to browser
DEBUG - 2018-07-15 08:15:00 --> Total execution time: 0.0458
ERROR - 2018-07-15 08:20:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:20:10 --> Config Class Initialized
INFO - 2018-07-15 08:20:10 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:20:10 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:20:10 --> Utf8 Class Initialized
INFO - 2018-07-15 08:20:10 --> URI Class Initialized
INFO - 2018-07-15 08:20:10 --> Router Class Initialized
INFO - 2018-07-15 08:20:10 --> Output Class Initialized
INFO - 2018-07-15 08:20:10 --> Security Class Initialized
DEBUG - 2018-07-15 08:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:20:10 --> Input Class Initialized
INFO - 2018-07-15 08:20:10 --> Language Class Initialized
INFO - 2018-07-15 08:20:10 --> Loader Class Initialized
INFO - 2018-07-15 08:20:10 --> Controller Class Initialized
INFO - 2018-07-15 08:20:10 --> Database Driver Class Initialized
INFO - 2018-07-15 08:20:10 --> Model Class Initialized
INFO - 2018-07-15 08:20:10 --> Helper loaded: url_helper
INFO - 2018-07-15 08:20:10 --> Model Class Initialized
INFO - 2018-07-15 08:20:10 --> Final output sent to browser
DEBUG - 2018-07-15 08:20:10 --> Total execution time: 0.0611
ERROR - 2018-07-15 08:20:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:20:11 --> Config Class Initialized
INFO - 2018-07-15 08:20:11 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:20:11 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:20:11 --> Utf8 Class Initialized
INFO - 2018-07-15 08:20:11 --> URI Class Initialized
INFO - 2018-07-15 08:20:11 --> Router Class Initialized
INFO - 2018-07-15 08:20:11 --> Output Class Initialized
INFO - 2018-07-15 08:20:11 --> Security Class Initialized
DEBUG - 2018-07-15 08:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:20:11 --> Input Class Initialized
INFO - 2018-07-15 08:20:11 --> Language Class Initialized
INFO - 2018-07-15 08:20:11 --> Loader Class Initialized
INFO - 2018-07-15 08:20:11 --> Controller Class Initialized
INFO - 2018-07-15 08:20:11 --> Database Driver Class Initialized
INFO - 2018-07-15 08:20:11 --> Model Class Initialized
INFO - 2018-07-15 08:20:11 --> Helper loaded: url_helper
INFO - 2018-07-15 08:20:11 --> Model Class Initialized
INFO - 2018-07-15 08:20:11 --> Final output sent to browser
DEBUG - 2018-07-15 08:20:11 --> Total execution time: 0.0606
ERROR - 2018-07-15 08:21:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:21:35 --> Config Class Initialized
INFO - 2018-07-15 08:21:35 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:21:35 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:21:35 --> Utf8 Class Initialized
INFO - 2018-07-15 08:21:35 --> URI Class Initialized
INFO - 2018-07-15 08:21:35 --> Router Class Initialized
INFO - 2018-07-15 08:21:35 --> Output Class Initialized
INFO - 2018-07-15 08:21:35 --> Security Class Initialized
DEBUG - 2018-07-15 08:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:21:35 --> Input Class Initialized
INFO - 2018-07-15 08:21:35 --> Language Class Initialized
INFO - 2018-07-15 08:21:35 --> Loader Class Initialized
INFO - 2018-07-15 08:21:35 --> Controller Class Initialized
INFO - 2018-07-15 08:21:35 --> Database Driver Class Initialized
INFO - 2018-07-15 08:21:35 --> Model Class Initialized
INFO - 2018-07-15 08:21:35 --> Helper loaded: url_helper
INFO - 2018-07-15 08:21:35 --> Model Class Initialized
INFO - 2018-07-15 08:21:35 --> Final output sent to browser
DEBUG - 2018-07-15 08:21:35 --> Total execution time: 0.0622
ERROR - 2018-07-15 08:21:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:21:35 --> Config Class Initialized
INFO - 2018-07-15 08:21:35 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:21:35 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:21:35 --> Utf8 Class Initialized
INFO - 2018-07-15 08:21:35 --> URI Class Initialized
INFO - 2018-07-15 08:21:35 --> Router Class Initialized
INFO - 2018-07-15 08:21:35 --> Output Class Initialized
INFO - 2018-07-15 08:21:35 --> Security Class Initialized
DEBUG - 2018-07-15 08:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:21:35 --> Input Class Initialized
INFO - 2018-07-15 08:21:35 --> Language Class Initialized
INFO - 2018-07-15 08:21:35 --> Loader Class Initialized
INFO - 2018-07-15 08:21:35 --> Controller Class Initialized
INFO - 2018-07-15 08:21:35 --> Database Driver Class Initialized
INFO - 2018-07-15 08:21:35 --> Model Class Initialized
INFO - 2018-07-15 08:21:35 --> Helper loaded: url_helper
INFO - 2018-07-15 08:21:35 --> Model Class Initialized
INFO - 2018-07-15 08:21:35 --> Final output sent to browser
DEBUG - 2018-07-15 08:21:35 --> Total execution time: 0.0378
ERROR - 2018-07-15 08:24:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:24:39 --> Config Class Initialized
INFO - 2018-07-15 08:24:39 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:24:39 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:24:39 --> Utf8 Class Initialized
INFO - 2018-07-15 08:24:39 --> URI Class Initialized
INFO - 2018-07-15 08:24:39 --> Router Class Initialized
INFO - 2018-07-15 08:24:39 --> Output Class Initialized
INFO - 2018-07-15 08:24:39 --> Security Class Initialized
DEBUG - 2018-07-15 08:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:24:39 --> Input Class Initialized
INFO - 2018-07-15 08:24:39 --> Language Class Initialized
INFO - 2018-07-15 08:24:39 --> Loader Class Initialized
INFO - 2018-07-15 08:24:39 --> Controller Class Initialized
INFO - 2018-07-15 08:24:39 --> Database Driver Class Initialized
INFO - 2018-07-15 08:24:39 --> Model Class Initialized
INFO - 2018-07-15 08:24:39 --> Helper loaded: url_helper
INFO - 2018-07-15 08:24:39 --> Model Class Initialized
INFO - 2018-07-15 08:24:39 --> Final output sent to browser
DEBUG - 2018-07-15 08:24:39 --> Total execution time: 0.0570
ERROR - 2018-07-15 08:24:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:24:40 --> Config Class Initialized
INFO - 2018-07-15 08:24:40 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:24:40 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:24:40 --> Utf8 Class Initialized
INFO - 2018-07-15 08:24:40 --> URI Class Initialized
INFO - 2018-07-15 08:24:40 --> Router Class Initialized
INFO - 2018-07-15 08:24:40 --> Output Class Initialized
INFO - 2018-07-15 08:24:40 --> Security Class Initialized
DEBUG - 2018-07-15 08:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:24:40 --> Input Class Initialized
INFO - 2018-07-15 08:24:40 --> Language Class Initialized
INFO - 2018-07-15 08:24:40 --> Loader Class Initialized
INFO - 2018-07-15 08:24:40 --> Controller Class Initialized
INFO - 2018-07-15 08:24:40 --> Database Driver Class Initialized
INFO - 2018-07-15 08:24:40 --> Model Class Initialized
INFO - 2018-07-15 08:24:40 --> Helper loaded: url_helper
INFO - 2018-07-15 08:24:40 --> Model Class Initialized
INFO - 2018-07-15 08:24:40 --> Final output sent to browser
DEBUG - 2018-07-15 08:24:40 --> Total execution time: 0.0532
ERROR - 2018-07-15 08:25:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:25:16 --> Config Class Initialized
INFO - 2018-07-15 08:25:16 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:25:16 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:25:16 --> Utf8 Class Initialized
INFO - 2018-07-15 08:25:16 --> URI Class Initialized
INFO - 2018-07-15 08:25:16 --> Router Class Initialized
INFO - 2018-07-15 08:25:16 --> Output Class Initialized
INFO - 2018-07-15 08:25:16 --> Security Class Initialized
DEBUG - 2018-07-15 08:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:25:16 --> Input Class Initialized
INFO - 2018-07-15 08:25:16 --> Language Class Initialized
INFO - 2018-07-15 08:25:16 --> Loader Class Initialized
INFO - 2018-07-15 08:25:16 --> Controller Class Initialized
INFO - 2018-07-15 08:25:16 --> Database Driver Class Initialized
INFO - 2018-07-15 08:25:16 --> Model Class Initialized
INFO - 2018-07-15 08:25:16 --> Helper loaded: url_helper
INFO - 2018-07-15 08:25:16 --> Model Class Initialized
INFO - 2018-07-15 08:25:16 --> Final output sent to browser
DEBUG - 2018-07-15 08:25:16 --> Total execution time: 0.0394
ERROR - 2018-07-15 08:25:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:25:17 --> Config Class Initialized
INFO - 2018-07-15 08:25:17 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:25:17 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:25:17 --> Utf8 Class Initialized
INFO - 2018-07-15 08:25:17 --> URI Class Initialized
INFO - 2018-07-15 08:25:17 --> Router Class Initialized
INFO - 2018-07-15 08:25:17 --> Output Class Initialized
INFO - 2018-07-15 08:25:17 --> Security Class Initialized
DEBUG - 2018-07-15 08:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:25:17 --> Input Class Initialized
INFO - 2018-07-15 08:25:17 --> Language Class Initialized
INFO - 2018-07-15 08:25:17 --> Loader Class Initialized
INFO - 2018-07-15 08:25:17 --> Controller Class Initialized
INFO - 2018-07-15 08:25:17 --> Database Driver Class Initialized
INFO - 2018-07-15 08:25:17 --> Model Class Initialized
INFO - 2018-07-15 08:25:17 --> Helper loaded: url_helper
INFO - 2018-07-15 08:25:17 --> Model Class Initialized
INFO - 2018-07-15 08:25:17 --> Final output sent to browser
DEBUG - 2018-07-15 08:25:17 --> Total execution time: 0.0394
ERROR - 2018-07-15 08:25:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:25:19 --> Config Class Initialized
INFO - 2018-07-15 08:25:19 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:25:19 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:25:19 --> Utf8 Class Initialized
INFO - 2018-07-15 08:25:19 --> URI Class Initialized
INFO - 2018-07-15 08:25:19 --> Router Class Initialized
INFO - 2018-07-15 08:25:19 --> Output Class Initialized
INFO - 2018-07-15 08:25:19 --> Security Class Initialized
DEBUG - 2018-07-15 08:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:25:19 --> Input Class Initialized
INFO - 2018-07-15 08:25:19 --> Language Class Initialized
INFO - 2018-07-15 08:25:19 --> Loader Class Initialized
INFO - 2018-07-15 08:25:19 --> Controller Class Initialized
INFO - 2018-07-15 08:25:19 --> Database Driver Class Initialized
INFO - 2018-07-15 08:25:19 --> Model Class Initialized
INFO - 2018-07-15 08:25:19 --> Helper loaded: url_helper
INFO - 2018-07-15 08:25:19 --> Model Class Initialized
INFO - 2018-07-15 08:25:19 --> Final output sent to browser
DEBUG - 2018-07-15 08:25:19 --> Total execution time: 0.0525
ERROR - 2018-07-15 08:25:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:25:22 --> Config Class Initialized
INFO - 2018-07-15 08:25:22 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:25:22 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:25:22 --> Utf8 Class Initialized
INFO - 2018-07-15 08:25:22 --> URI Class Initialized
INFO - 2018-07-15 08:25:22 --> Router Class Initialized
INFO - 2018-07-15 08:25:22 --> Output Class Initialized
INFO - 2018-07-15 08:25:22 --> Security Class Initialized
DEBUG - 2018-07-15 08:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:25:22 --> Input Class Initialized
INFO - 2018-07-15 08:25:22 --> Language Class Initialized
INFO - 2018-07-15 08:25:22 --> Loader Class Initialized
INFO - 2018-07-15 08:25:22 --> Controller Class Initialized
INFO - 2018-07-15 08:25:22 --> Database Driver Class Initialized
INFO - 2018-07-15 08:25:22 --> Model Class Initialized
INFO - 2018-07-15 08:25:22 --> Helper loaded: url_helper
INFO - 2018-07-15 08:25:22 --> Model Class Initialized
INFO - 2018-07-15 08:25:22 --> Final output sent to browser
DEBUG - 2018-07-15 08:25:22 --> Total execution time: 0.0374
ERROR - 2018-07-15 08:26:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:26:21 --> Config Class Initialized
INFO - 2018-07-15 08:26:21 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:26:21 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:26:21 --> Utf8 Class Initialized
INFO - 2018-07-15 08:26:21 --> URI Class Initialized
INFO - 2018-07-15 08:26:21 --> Router Class Initialized
INFO - 2018-07-15 08:26:21 --> Output Class Initialized
INFO - 2018-07-15 08:26:21 --> Security Class Initialized
DEBUG - 2018-07-15 08:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:26:21 --> Input Class Initialized
INFO - 2018-07-15 08:26:21 --> Language Class Initialized
INFO - 2018-07-15 08:26:21 --> Loader Class Initialized
INFO - 2018-07-15 08:26:21 --> Controller Class Initialized
INFO - 2018-07-15 08:26:21 --> Database Driver Class Initialized
INFO - 2018-07-15 08:26:21 --> Model Class Initialized
INFO - 2018-07-15 08:26:21 --> Helper loaded: url_helper
INFO - 2018-07-15 08:26:21 --> Model Class Initialized
INFO - 2018-07-15 08:26:21 --> Final output sent to browser
DEBUG - 2018-07-15 08:26:21 --> Total execution time: 0.0826
ERROR - 2018-07-15 08:26:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:26:26 --> Config Class Initialized
INFO - 2018-07-15 08:26:26 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:26:26 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:26:26 --> Utf8 Class Initialized
INFO - 2018-07-15 08:26:26 --> URI Class Initialized
INFO - 2018-07-15 08:26:26 --> Router Class Initialized
INFO - 2018-07-15 08:26:26 --> Output Class Initialized
INFO - 2018-07-15 08:26:26 --> Security Class Initialized
DEBUG - 2018-07-15 08:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:26:26 --> Input Class Initialized
INFO - 2018-07-15 08:26:26 --> Language Class Initialized
INFO - 2018-07-15 08:26:26 --> Loader Class Initialized
INFO - 2018-07-15 08:26:26 --> Controller Class Initialized
INFO - 2018-07-15 08:26:26 --> Database Driver Class Initialized
INFO - 2018-07-15 08:26:26 --> Model Class Initialized
INFO - 2018-07-15 08:26:26 --> Helper loaded: url_helper
INFO - 2018-07-15 08:26:26 --> Model Class Initialized
INFO - 2018-07-15 08:26:26 --> Final output sent to browser
DEBUG - 2018-07-15 08:26:26 --> Total execution time: 0.0417
ERROR - 2018-07-15 08:26:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 08:26:27 --> Config Class Initialized
INFO - 2018-07-15 08:26:27 --> Hooks Class Initialized
DEBUG - 2018-07-15 08:26:27 --> UTF-8 Support Enabled
INFO - 2018-07-15 08:26:27 --> Utf8 Class Initialized
INFO - 2018-07-15 08:26:27 --> URI Class Initialized
INFO - 2018-07-15 08:26:27 --> Router Class Initialized
INFO - 2018-07-15 08:26:27 --> Output Class Initialized
INFO - 2018-07-15 08:26:27 --> Security Class Initialized
DEBUG - 2018-07-15 08:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 08:26:27 --> Input Class Initialized
INFO - 2018-07-15 08:26:27 --> Language Class Initialized
INFO - 2018-07-15 08:26:27 --> Loader Class Initialized
INFO - 2018-07-15 08:26:27 --> Controller Class Initialized
INFO - 2018-07-15 08:26:27 --> Database Driver Class Initialized
INFO - 2018-07-15 08:26:27 --> Model Class Initialized
INFO - 2018-07-15 08:26:27 --> Helper loaded: url_helper
INFO - 2018-07-15 08:26:27 --> Model Class Initialized
INFO - 2018-07-15 08:26:27 --> Final output sent to browser
DEBUG - 2018-07-15 08:26:27 --> Total execution time: 0.0435
ERROR - 2018-07-15 12:47:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 12:47:57 --> Config Class Initialized
INFO - 2018-07-15 12:47:57 --> Hooks Class Initialized
DEBUG - 2018-07-15 12:47:57 --> UTF-8 Support Enabled
INFO - 2018-07-15 12:47:57 --> Utf8 Class Initialized
INFO - 2018-07-15 12:47:57 --> URI Class Initialized
INFO - 2018-07-15 12:47:57 --> Router Class Initialized
INFO - 2018-07-15 12:47:57 --> Output Class Initialized
INFO - 2018-07-15 12:47:57 --> Security Class Initialized
DEBUG - 2018-07-15 12:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 12:47:57 --> Input Class Initialized
INFO - 2018-07-15 12:47:57 --> Language Class Initialized
INFO - 2018-07-15 12:47:57 --> Loader Class Initialized
INFO - 2018-07-15 12:47:57 --> Controller Class Initialized
INFO - 2018-07-15 12:47:57 --> Database Driver Class Initialized
INFO - 2018-07-15 12:47:57 --> Model Class Initialized
INFO - 2018-07-15 12:47:57 --> Helper loaded: url_helper
INFO - 2018-07-15 12:47:57 --> Model Class Initialized
INFO - 2018-07-15 12:47:57 --> Final output sent to browser
DEBUG - 2018-07-15 12:47:57 --> Total execution time: 0.0419
ERROR - 2018-07-15 12:47:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 12:47:58 --> Config Class Initialized
INFO - 2018-07-15 12:47:58 --> Hooks Class Initialized
DEBUG - 2018-07-15 12:47:58 --> UTF-8 Support Enabled
INFO - 2018-07-15 12:47:58 --> Utf8 Class Initialized
INFO - 2018-07-15 12:47:58 --> URI Class Initialized
INFO - 2018-07-15 12:47:58 --> Router Class Initialized
INFO - 2018-07-15 12:47:58 --> Output Class Initialized
INFO - 2018-07-15 12:47:58 --> Security Class Initialized
DEBUG - 2018-07-15 12:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 12:47:58 --> Input Class Initialized
INFO - 2018-07-15 12:47:58 --> Language Class Initialized
INFO - 2018-07-15 12:47:58 --> Loader Class Initialized
INFO - 2018-07-15 12:47:58 --> Controller Class Initialized
INFO - 2018-07-15 12:47:58 --> Database Driver Class Initialized
INFO - 2018-07-15 12:47:58 --> Model Class Initialized
INFO - 2018-07-15 12:47:58 --> Helper loaded: url_helper
INFO - 2018-07-15 12:47:58 --> Model Class Initialized
INFO - 2018-07-15 12:47:58 --> Final output sent to browser
DEBUG - 2018-07-15 12:47:58 --> Total execution time: 0.0345
ERROR - 2018-07-15 12:48:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 12:48:28 --> Config Class Initialized
INFO - 2018-07-15 12:48:28 --> Hooks Class Initialized
DEBUG - 2018-07-15 12:48:28 --> UTF-8 Support Enabled
INFO - 2018-07-15 12:48:28 --> Utf8 Class Initialized
INFO - 2018-07-15 12:48:28 --> URI Class Initialized
INFO - 2018-07-15 12:48:28 --> Router Class Initialized
INFO - 2018-07-15 12:48:28 --> Output Class Initialized
INFO - 2018-07-15 12:48:28 --> Security Class Initialized
DEBUG - 2018-07-15 12:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 12:48:28 --> Input Class Initialized
INFO - 2018-07-15 12:48:28 --> Language Class Initialized
INFO - 2018-07-15 12:48:28 --> Loader Class Initialized
INFO - 2018-07-15 12:48:28 --> Controller Class Initialized
INFO - 2018-07-15 12:48:28 --> Database Driver Class Initialized
INFO - 2018-07-15 12:48:28 --> Model Class Initialized
INFO - 2018-07-15 12:48:28 --> Helper loaded: url_helper
INFO - 2018-07-15 12:48:28 --> Model Class Initialized
INFO - 2018-07-15 12:48:28 --> Final output sent to browser
DEBUG - 2018-07-15 12:48:28 --> Total execution time: 0.0401
ERROR - 2018-07-15 12:48:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 12:48:30 --> Config Class Initialized
INFO - 2018-07-15 12:48:30 --> Hooks Class Initialized
DEBUG - 2018-07-15 12:48:30 --> UTF-8 Support Enabled
INFO - 2018-07-15 12:48:30 --> Utf8 Class Initialized
INFO - 2018-07-15 12:48:30 --> URI Class Initialized
INFO - 2018-07-15 12:48:30 --> Router Class Initialized
INFO - 2018-07-15 12:48:30 --> Output Class Initialized
INFO - 2018-07-15 12:48:30 --> Security Class Initialized
DEBUG - 2018-07-15 12:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 12:48:30 --> Input Class Initialized
INFO - 2018-07-15 12:48:30 --> Language Class Initialized
INFO - 2018-07-15 12:48:30 --> Loader Class Initialized
INFO - 2018-07-15 12:48:30 --> Controller Class Initialized
INFO - 2018-07-15 12:48:30 --> Database Driver Class Initialized
INFO - 2018-07-15 12:48:30 --> Model Class Initialized
INFO - 2018-07-15 12:48:30 --> Helper loaded: url_helper
INFO - 2018-07-15 12:48:30 --> Model Class Initialized
INFO - 2018-07-15 12:48:30 --> Final output sent to browser
DEBUG - 2018-07-15 12:48:30 --> Total execution time: 0.0439
ERROR - 2018-07-15 12:50:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 12:50:33 --> Config Class Initialized
INFO - 2018-07-15 12:50:33 --> Hooks Class Initialized
DEBUG - 2018-07-15 12:50:33 --> UTF-8 Support Enabled
INFO - 2018-07-15 12:50:33 --> Utf8 Class Initialized
INFO - 2018-07-15 12:50:33 --> URI Class Initialized
INFO - 2018-07-15 12:50:33 --> Router Class Initialized
INFO - 2018-07-15 12:50:33 --> Output Class Initialized
INFO - 2018-07-15 12:50:33 --> Security Class Initialized
DEBUG - 2018-07-15 12:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 12:50:33 --> Input Class Initialized
INFO - 2018-07-15 12:50:33 --> Language Class Initialized
INFO - 2018-07-15 12:50:33 --> Loader Class Initialized
INFO - 2018-07-15 12:50:33 --> Controller Class Initialized
INFO - 2018-07-15 12:50:33 --> Database Driver Class Initialized
INFO - 2018-07-15 12:50:33 --> Model Class Initialized
INFO - 2018-07-15 12:50:33 --> Helper loaded: url_helper
INFO - 2018-07-15 12:50:33 --> Model Class Initialized
INFO - 2018-07-15 12:50:33 --> Final output sent to browser
DEBUG - 2018-07-15 12:50:33 --> Total execution time: 0.0380
ERROR - 2018-07-15 12:50:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 12:50:43 --> Config Class Initialized
INFO - 2018-07-15 12:50:43 --> Hooks Class Initialized
DEBUG - 2018-07-15 12:50:43 --> UTF-8 Support Enabled
INFO - 2018-07-15 12:50:43 --> Utf8 Class Initialized
INFO - 2018-07-15 12:50:43 --> URI Class Initialized
INFO - 2018-07-15 12:50:43 --> Router Class Initialized
INFO - 2018-07-15 12:50:43 --> Output Class Initialized
INFO - 2018-07-15 12:50:43 --> Security Class Initialized
DEBUG - 2018-07-15 12:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 12:50:43 --> Input Class Initialized
INFO - 2018-07-15 12:50:43 --> Language Class Initialized
INFO - 2018-07-15 12:50:43 --> Loader Class Initialized
INFO - 2018-07-15 12:50:43 --> Controller Class Initialized
INFO - 2018-07-15 12:50:43 --> Database Driver Class Initialized
INFO - 2018-07-15 12:50:43 --> Model Class Initialized
INFO - 2018-07-15 12:50:43 --> Helper loaded: url_helper
INFO - 2018-07-15 12:50:43 --> Model Class Initialized
INFO - 2018-07-15 12:50:43 --> Final output sent to browser
DEBUG - 2018-07-15 12:50:43 --> Total execution time: 0.0366
ERROR - 2018-07-15 12:50:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 12:50:51 --> Config Class Initialized
INFO - 2018-07-15 12:50:51 --> Hooks Class Initialized
DEBUG - 2018-07-15 12:50:51 --> UTF-8 Support Enabled
INFO - 2018-07-15 12:50:51 --> Utf8 Class Initialized
INFO - 2018-07-15 12:50:51 --> URI Class Initialized
INFO - 2018-07-15 12:50:51 --> Router Class Initialized
INFO - 2018-07-15 12:50:51 --> Output Class Initialized
INFO - 2018-07-15 12:50:51 --> Security Class Initialized
DEBUG - 2018-07-15 12:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 12:50:51 --> Input Class Initialized
INFO - 2018-07-15 12:50:51 --> Language Class Initialized
INFO - 2018-07-15 12:50:51 --> Loader Class Initialized
INFO - 2018-07-15 12:50:51 --> Controller Class Initialized
INFO - 2018-07-15 12:50:51 --> Database Driver Class Initialized
INFO - 2018-07-15 12:50:51 --> Model Class Initialized
INFO - 2018-07-15 12:50:51 --> Helper loaded: url_helper
INFO - 2018-07-15 12:50:51 --> Model Class Initialized
INFO - 2018-07-15 12:50:51 --> Final output sent to browser
DEBUG - 2018-07-15 12:50:51 --> Total execution time: 0.0422
ERROR - 2018-07-15 12:50:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 12:50:52 --> Config Class Initialized
INFO - 2018-07-15 12:50:52 --> Hooks Class Initialized
DEBUG - 2018-07-15 12:50:52 --> UTF-8 Support Enabled
INFO - 2018-07-15 12:50:52 --> Utf8 Class Initialized
INFO - 2018-07-15 12:50:52 --> URI Class Initialized
INFO - 2018-07-15 12:50:52 --> Router Class Initialized
INFO - 2018-07-15 12:50:52 --> Output Class Initialized
INFO - 2018-07-15 12:50:52 --> Security Class Initialized
DEBUG - 2018-07-15 12:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 12:50:52 --> Input Class Initialized
INFO - 2018-07-15 12:50:52 --> Language Class Initialized
INFO - 2018-07-15 12:50:52 --> Loader Class Initialized
INFO - 2018-07-15 12:50:52 --> Controller Class Initialized
INFO - 2018-07-15 12:50:52 --> Database Driver Class Initialized
INFO - 2018-07-15 12:50:52 --> Model Class Initialized
INFO - 2018-07-15 12:50:52 --> Helper loaded: url_helper
INFO - 2018-07-15 12:50:52 --> Model Class Initialized
INFO - 2018-07-15 12:50:52 --> Final output sent to browser
DEBUG - 2018-07-15 12:50:52 --> Total execution time: 0.0352
ERROR - 2018-07-15 12:53:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 12:53:32 --> Config Class Initialized
INFO - 2018-07-15 12:53:32 --> Hooks Class Initialized
DEBUG - 2018-07-15 12:53:32 --> UTF-8 Support Enabled
INFO - 2018-07-15 12:53:32 --> Utf8 Class Initialized
INFO - 2018-07-15 12:53:32 --> URI Class Initialized
INFO - 2018-07-15 12:53:32 --> Router Class Initialized
INFO - 2018-07-15 12:53:32 --> Output Class Initialized
INFO - 2018-07-15 12:53:32 --> Security Class Initialized
DEBUG - 2018-07-15 12:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 12:53:32 --> Input Class Initialized
INFO - 2018-07-15 12:53:32 --> Language Class Initialized
INFO - 2018-07-15 12:53:32 --> Loader Class Initialized
INFO - 2018-07-15 12:53:32 --> Controller Class Initialized
INFO - 2018-07-15 12:53:32 --> Database Driver Class Initialized
INFO - 2018-07-15 12:53:32 --> Model Class Initialized
INFO - 2018-07-15 12:53:32 --> Helper loaded: url_helper
INFO - 2018-07-15 12:53:32 --> Model Class Initialized
INFO - 2018-07-15 12:53:32 --> Final output sent to browser
DEBUG - 2018-07-15 12:53:32 --> Total execution time: 0.0535
ERROR - 2018-07-15 12:53:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 12:53:33 --> Config Class Initialized
INFO - 2018-07-15 12:53:33 --> Hooks Class Initialized
DEBUG - 2018-07-15 12:53:33 --> UTF-8 Support Enabled
INFO - 2018-07-15 12:53:33 --> Utf8 Class Initialized
INFO - 2018-07-15 12:53:33 --> URI Class Initialized
INFO - 2018-07-15 12:53:33 --> Router Class Initialized
INFO - 2018-07-15 12:53:33 --> Output Class Initialized
INFO - 2018-07-15 12:53:33 --> Security Class Initialized
DEBUG - 2018-07-15 12:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 12:53:33 --> Input Class Initialized
INFO - 2018-07-15 12:53:33 --> Language Class Initialized
INFO - 2018-07-15 12:53:33 --> Loader Class Initialized
INFO - 2018-07-15 12:53:33 --> Controller Class Initialized
INFO - 2018-07-15 12:53:33 --> Database Driver Class Initialized
INFO - 2018-07-15 12:53:33 --> Model Class Initialized
INFO - 2018-07-15 12:53:33 --> Helper loaded: url_helper
INFO - 2018-07-15 12:53:33 --> Model Class Initialized
INFO - 2018-07-15 12:53:33 --> Final output sent to browser
DEBUG - 2018-07-15 12:53:33 --> Total execution time: 0.0774
ERROR - 2018-07-15 12:57:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 12:57:17 --> Config Class Initialized
INFO - 2018-07-15 12:57:17 --> Hooks Class Initialized
DEBUG - 2018-07-15 12:57:17 --> UTF-8 Support Enabled
INFO - 2018-07-15 12:57:17 --> Utf8 Class Initialized
INFO - 2018-07-15 12:57:17 --> URI Class Initialized
INFO - 2018-07-15 12:57:17 --> Router Class Initialized
INFO - 2018-07-15 12:57:17 --> Output Class Initialized
INFO - 2018-07-15 12:57:17 --> Security Class Initialized
DEBUG - 2018-07-15 12:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 12:57:17 --> Input Class Initialized
INFO - 2018-07-15 12:57:17 --> Language Class Initialized
INFO - 2018-07-15 12:57:17 --> Loader Class Initialized
INFO - 2018-07-15 12:57:17 --> Controller Class Initialized
INFO - 2018-07-15 12:57:17 --> Database Driver Class Initialized
INFO - 2018-07-15 12:57:17 --> Model Class Initialized
INFO - 2018-07-15 12:57:17 --> Helper loaded: url_helper
INFO - 2018-07-15 12:57:17 --> Model Class Initialized
INFO - 2018-07-15 12:57:17 --> Final output sent to browser
DEBUG - 2018-07-15 12:57:17 --> Total execution time: 0.0458
ERROR - 2018-07-15 12:57:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 12:57:18 --> Config Class Initialized
INFO - 2018-07-15 12:57:18 --> Hooks Class Initialized
DEBUG - 2018-07-15 12:57:18 --> UTF-8 Support Enabled
INFO - 2018-07-15 12:57:18 --> Utf8 Class Initialized
INFO - 2018-07-15 12:57:18 --> URI Class Initialized
INFO - 2018-07-15 12:57:18 --> Router Class Initialized
INFO - 2018-07-15 12:57:18 --> Output Class Initialized
INFO - 2018-07-15 12:57:18 --> Security Class Initialized
DEBUG - 2018-07-15 12:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 12:57:18 --> Input Class Initialized
INFO - 2018-07-15 12:57:18 --> Language Class Initialized
INFO - 2018-07-15 12:57:18 --> Loader Class Initialized
INFO - 2018-07-15 12:57:18 --> Controller Class Initialized
INFO - 2018-07-15 12:57:18 --> Database Driver Class Initialized
INFO - 2018-07-15 12:57:18 --> Model Class Initialized
INFO - 2018-07-15 12:57:18 --> Helper loaded: url_helper
INFO - 2018-07-15 12:57:18 --> Model Class Initialized
INFO - 2018-07-15 12:57:18 --> Final output sent to browser
DEBUG - 2018-07-15 12:57:18 --> Total execution time: 0.0415
ERROR - 2018-07-15 13:02:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 13:02:35 --> Config Class Initialized
INFO - 2018-07-15 13:02:35 --> Hooks Class Initialized
DEBUG - 2018-07-15 13:02:35 --> UTF-8 Support Enabled
INFO - 2018-07-15 13:02:35 --> Utf8 Class Initialized
INFO - 2018-07-15 13:02:35 --> URI Class Initialized
INFO - 2018-07-15 13:02:35 --> Router Class Initialized
INFO - 2018-07-15 13:02:35 --> Output Class Initialized
INFO - 2018-07-15 13:02:35 --> Security Class Initialized
DEBUG - 2018-07-15 13:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 13:02:35 --> Input Class Initialized
INFO - 2018-07-15 13:02:35 --> Language Class Initialized
INFO - 2018-07-15 13:02:35 --> Loader Class Initialized
INFO - 2018-07-15 13:02:35 --> Controller Class Initialized
INFO - 2018-07-15 13:02:35 --> Database Driver Class Initialized
INFO - 2018-07-15 13:02:35 --> Model Class Initialized
INFO - 2018-07-15 13:02:35 --> Helper loaded: url_helper
INFO - 2018-07-15 13:02:35 --> Model Class Initialized
INFO - 2018-07-15 13:02:35 --> Final output sent to browser
DEBUG - 2018-07-15 13:02:35 --> Total execution time: 0.0404
ERROR - 2018-07-15 13:02:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 13:02:36 --> Config Class Initialized
INFO - 2018-07-15 13:02:36 --> Hooks Class Initialized
DEBUG - 2018-07-15 13:02:36 --> UTF-8 Support Enabled
INFO - 2018-07-15 13:02:36 --> Utf8 Class Initialized
INFO - 2018-07-15 13:02:36 --> URI Class Initialized
INFO - 2018-07-15 13:02:36 --> Router Class Initialized
INFO - 2018-07-15 13:02:36 --> Output Class Initialized
INFO - 2018-07-15 13:02:36 --> Security Class Initialized
DEBUG - 2018-07-15 13:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 13:02:36 --> Input Class Initialized
INFO - 2018-07-15 13:02:36 --> Language Class Initialized
INFO - 2018-07-15 13:02:36 --> Loader Class Initialized
INFO - 2018-07-15 13:02:36 --> Controller Class Initialized
INFO - 2018-07-15 13:02:36 --> Database Driver Class Initialized
INFO - 2018-07-15 13:02:36 --> Model Class Initialized
INFO - 2018-07-15 13:02:36 --> Helper loaded: url_helper
INFO - 2018-07-15 13:02:36 --> Model Class Initialized
INFO - 2018-07-15 13:02:36 --> Final output sent to browser
DEBUG - 2018-07-15 13:02:36 --> Total execution time: 0.0413
ERROR - 2018-07-15 13:05:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 13:05:47 --> Config Class Initialized
INFO - 2018-07-15 13:05:47 --> Hooks Class Initialized
DEBUG - 2018-07-15 13:05:47 --> UTF-8 Support Enabled
INFO - 2018-07-15 13:05:47 --> Utf8 Class Initialized
INFO - 2018-07-15 13:05:47 --> URI Class Initialized
INFO - 2018-07-15 13:05:47 --> Router Class Initialized
INFO - 2018-07-15 13:05:47 --> Output Class Initialized
INFO - 2018-07-15 13:05:47 --> Security Class Initialized
DEBUG - 2018-07-15 13:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 13:05:48 --> Input Class Initialized
INFO - 2018-07-15 13:05:48 --> Language Class Initialized
INFO - 2018-07-15 13:05:48 --> Loader Class Initialized
INFO - 2018-07-15 13:05:48 --> Controller Class Initialized
INFO - 2018-07-15 13:05:48 --> Database Driver Class Initialized
INFO - 2018-07-15 13:05:48 --> Model Class Initialized
INFO - 2018-07-15 13:05:48 --> Helper loaded: url_helper
INFO - 2018-07-15 13:05:48 --> Model Class Initialized
INFO - 2018-07-15 13:05:48 --> Final output sent to browser
DEBUG - 2018-07-15 13:05:48 --> Total execution time: 0.0485
ERROR - 2018-07-15 13:05:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 13:05:49 --> Config Class Initialized
INFO - 2018-07-15 13:05:49 --> Hooks Class Initialized
DEBUG - 2018-07-15 13:05:49 --> UTF-8 Support Enabled
INFO - 2018-07-15 13:05:49 --> Utf8 Class Initialized
INFO - 2018-07-15 13:05:49 --> URI Class Initialized
INFO - 2018-07-15 13:05:49 --> Router Class Initialized
INFO - 2018-07-15 13:05:49 --> Output Class Initialized
INFO - 2018-07-15 13:05:49 --> Security Class Initialized
DEBUG - 2018-07-15 13:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 13:05:49 --> Input Class Initialized
INFO - 2018-07-15 13:05:49 --> Language Class Initialized
INFO - 2018-07-15 13:05:49 --> Loader Class Initialized
INFO - 2018-07-15 13:05:49 --> Controller Class Initialized
INFO - 2018-07-15 13:05:49 --> Database Driver Class Initialized
INFO - 2018-07-15 13:05:49 --> Model Class Initialized
INFO - 2018-07-15 13:05:49 --> Helper loaded: url_helper
INFO - 2018-07-15 13:05:49 --> Model Class Initialized
INFO - 2018-07-15 13:05:49 --> Final output sent to browser
DEBUG - 2018-07-15 13:05:49 --> Total execution time: 0.0665
ERROR - 2018-07-15 13:07:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 13:07:15 --> Config Class Initialized
INFO - 2018-07-15 13:07:15 --> Hooks Class Initialized
DEBUG - 2018-07-15 13:07:15 --> UTF-8 Support Enabled
INFO - 2018-07-15 13:07:15 --> Utf8 Class Initialized
INFO - 2018-07-15 13:07:15 --> URI Class Initialized
INFO - 2018-07-15 13:07:15 --> Router Class Initialized
INFO - 2018-07-15 13:07:15 --> Output Class Initialized
INFO - 2018-07-15 13:07:15 --> Security Class Initialized
DEBUG - 2018-07-15 13:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 13:07:15 --> Input Class Initialized
INFO - 2018-07-15 13:07:15 --> Language Class Initialized
INFO - 2018-07-15 13:07:15 --> Loader Class Initialized
INFO - 2018-07-15 13:07:15 --> Controller Class Initialized
INFO - 2018-07-15 13:07:15 --> Database Driver Class Initialized
INFO - 2018-07-15 13:07:15 --> Model Class Initialized
INFO - 2018-07-15 13:07:15 --> Helper loaded: url_helper
INFO - 2018-07-15 13:07:15 --> Model Class Initialized
INFO - 2018-07-15 13:07:15 --> Final output sent to browser
DEBUG - 2018-07-15 13:07:15 --> Total execution time: 0.0578
ERROR - 2018-07-15 13:07:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 13:07:15 --> Config Class Initialized
INFO - 2018-07-15 13:07:15 --> Hooks Class Initialized
DEBUG - 2018-07-15 13:07:15 --> UTF-8 Support Enabled
INFO - 2018-07-15 13:07:15 --> Utf8 Class Initialized
INFO - 2018-07-15 13:07:15 --> URI Class Initialized
INFO - 2018-07-15 13:07:15 --> Router Class Initialized
INFO - 2018-07-15 13:07:15 --> Output Class Initialized
INFO - 2018-07-15 13:07:15 --> Security Class Initialized
DEBUG - 2018-07-15 13:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 13:07:15 --> Input Class Initialized
INFO - 2018-07-15 13:07:15 --> Language Class Initialized
INFO - 2018-07-15 13:07:15 --> Loader Class Initialized
INFO - 2018-07-15 13:07:15 --> Controller Class Initialized
INFO - 2018-07-15 13:07:15 --> Database Driver Class Initialized
INFO - 2018-07-15 13:07:15 --> Model Class Initialized
INFO - 2018-07-15 13:07:15 --> Helper loaded: url_helper
INFO - 2018-07-15 13:07:15 --> Model Class Initialized
INFO - 2018-07-15 13:07:15 --> Final output sent to browser
DEBUG - 2018-07-15 13:07:15 --> Total execution time: 0.0643
ERROR - 2018-07-15 13:07:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 13:07:23 --> Config Class Initialized
INFO - 2018-07-15 13:07:23 --> Hooks Class Initialized
DEBUG - 2018-07-15 13:07:23 --> UTF-8 Support Enabled
INFO - 2018-07-15 13:07:23 --> Utf8 Class Initialized
INFO - 2018-07-15 13:07:23 --> URI Class Initialized
INFO - 2018-07-15 13:07:23 --> Router Class Initialized
INFO - 2018-07-15 13:07:23 --> Output Class Initialized
INFO - 2018-07-15 13:07:23 --> Security Class Initialized
DEBUG - 2018-07-15 13:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 13:07:23 --> Input Class Initialized
INFO - 2018-07-15 13:07:23 --> Language Class Initialized
INFO - 2018-07-15 13:07:23 --> Loader Class Initialized
INFO - 2018-07-15 13:07:23 --> Controller Class Initialized
INFO - 2018-07-15 13:07:23 --> Database Driver Class Initialized
INFO - 2018-07-15 13:07:23 --> Model Class Initialized
INFO - 2018-07-15 13:07:23 --> Helper loaded: url_helper
INFO - 2018-07-15 13:07:23 --> Model Class Initialized
INFO - 2018-07-15 13:07:23 --> Final output sent to browser
DEBUG - 2018-07-15 13:07:23 --> Total execution time: 0.0542
ERROR - 2018-07-15 13:07:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 13:07:24 --> Config Class Initialized
INFO - 2018-07-15 13:07:24 --> Hooks Class Initialized
DEBUG - 2018-07-15 13:07:24 --> UTF-8 Support Enabled
INFO - 2018-07-15 13:07:24 --> Utf8 Class Initialized
INFO - 2018-07-15 13:07:24 --> URI Class Initialized
INFO - 2018-07-15 13:07:24 --> Router Class Initialized
INFO - 2018-07-15 13:07:24 --> Output Class Initialized
INFO - 2018-07-15 13:07:24 --> Security Class Initialized
DEBUG - 2018-07-15 13:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 13:07:24 --> Input Class Initialized
INFO - 2018-07-15 13:07:24 --> Language Class Initialized
INFO - 2018-07-15 13:07:24 --> Loader Class Initialized
INFO - 2018-07-15 13:07:24 --> Controller Class Initialized
INFO - 2018-07-15 13:07:24 --> Database Driver Class Initialized
INFO - 2018-07-15 13:07:24 --> Model Class Initialized
INFO - 2018-07-15 13:07:24 --> Helper loaded: url_helper
INFO - 2018-07-15 13:07:24 --> Model Class Initialized
INFO - 2018-07-15 13:07:24 --> Final output sent to browser
DEBUG - 2018-07-15 13:07:24 --> Total execution time: 0.0569
ERROR - 2018-07-15 13:09:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 13:09:47 --> Config Class Initialized
INFO - 2018-07-15 13:09:47 --> Hooks Class Initialized
DEBUG - 2018-07-15 13:09:47 --> UTF-8 Support Enabled
INFO - 2018-07-15 13:09:47 --> Utf8 Class Initialized
INFO - 2018-07-15 13:09:47 --> URI Class Initialized
INFO - 2018-07-15 13:09:47 --> Router Class Initialized
INFO - 2018-07-15 13:09:47 --> Output Class Initialized
INFO - 2018-07-15 13:09:47 --> Security Class Initialized
DEBUG - 2018-07-15 13:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 13:09:47 --> Input Class Initialized
INFO - 2018-07-15 13:09:47 --> Language Class Initialized
INFO - 2018-07-15 13:09:47 --> Loader Class Initialized
INFO - 2018-07-15 13:09:47 --> Controller Class Initialized
INFO - 2018-07-15 13:09:47 --> Database Driver Class Initialized
INFO - 2018-07-15 13:09:47 --> Model Class Initialized
INFO - 2018-07-15 13:09:47 --> Helper loaded: url_helper
INFO - 2018-07-15 13:09:47 --> Model Class Initialized
INFO - 2018-07-15 13:09:47 --> Final output sent to browser
DEBUG - 2018-07-15 13:09:47 --> Total execution time: 0.0607
ERROR - 2018-07-15 13:12:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 13:12:43 --> Config Class Initialized
INFO - 2018-07-15 13:12:43 --> Hooks Class Initialized
DEBUG - 2018-07-15 13:12:43 --> UTF-8 Support Enabled
INFO - 2018-07-15 13:12:43 --> Utf8 Class Initialized
INFO - 2018-07-15 13:12:43 --> URI Class Initialized
INFO - 2018-07-15 13:12:43 --> Router Class Initialized
INFO - 2018-07-15 13:12:43 --> Output Class Initialized
INFO - 2018-07-15 13:12:43 --> Security Class Initialized
DEBUG - 2018-07-15 13:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 13:12:43 --> Input Class Initialized
INFO - 2018-07-15 13:12:43 --> Language Class Initialized
INFO - 2018-07-15 13:12:43 --> Loader Class Initialized
INFO - 2018-07-15 13:12:43 --> Controller Class Initialized
INFO - 2018-07-15 13:12:43 --> Database Driver Class Initialized
INFO - 2018-07-15 13:12:43 --> Model Class Initialized
INFO - 2018-07-15 13:12:43 --> Helper loaded: url_helper
INFO - 2018-07-15 13:12:43 --> Model Class Initialized
INFO - 2018-07-15 13:12:43 --> Final output sent to browser
DEBUG - 2018-07-15 13:12:43 --> Total execution time: 0.0577
ERROR - 2018-07-15 13:14:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 13:14:22 --> Config Class Initialized
INFO - 2018-07-15 13:14:22 --> Hooks Class Initialized
DEBUG - 2018-07-15 13:14:22 --> UTF-8 Support Enabled
INFO - 2018-07-15 13:14:22 --> Utf8 Class Initialized
INFO - 2018-07-15 13:14:22 --> URI Class Initialized
INFO - 2018-07-15 13:14:22 --> Router Class Initialized
INFO - 2018-07-15 13:14:22 --> Output Class Initialized
INFO - 2018-07-15 13:14:22 --> Security Class Initialized
DEBUG - 2018-07-15 13:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 13:14:22 --> Input Class Initialized
INFO - 2018-07-15 13:14:22 --> Language Class Initialized
INFO - 2018-07-15 13:14:22 --> Loader Class Initialized
INFO - 2018-07-15 13:14:22 --> Controller Class Initialized
INFO - 2018-07-15 13:14:22 --> Database Driver Class Initialized
INFO - 2018-07-15 13:14:22 --> Model Class Initialized
INFO - 2018-07-15 13:14:22 --> Helper loaded: url_helper
INFO - 2018-07-15 13:14:22 --> Model Class Initialized
INFO - 2018-07-15 13:14:22 --> Final output sent to browser
DEBUG - 2018-07-15 13:14:22 --> Total execution time: 0.0575
ERROR - 2018-07-15 13:14:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 13:14:22 --> Config Class Initialized
INFO - 2018-07-15 13:14:22 --> Hooks Class Initialized
DEBUG - 2018-07-15 13:14:22 --> UTF-8 Support Enabled
INFO - 2018-07-15 13:14:22 --> Utf8 Class Initialized
INFO - 2018-07-15 13:14:22 --> URI Class Initialized
INFO - 2018-07-15 13:14:22 --> Router Class Initialized
INFO - 2018-07-15 13:14:22 --> Output Class Initialized
INFO - 2018-07-15 13:14:22 --> Security Class Initialized
DEBUG - 2018-07-15 13:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 13:14:22 --> Input Class Initialized
INFO - 2018-07-15 13:14:22 --> Language Class Initialized
INFO - 2018-07-15 13:14:22 --> Loader Class Initialized
INFO - 2018-07-15 13:14:22 --> Controller Class Initialized
INFO - 2018-07-15 13:14:22 --> Database Driver Class Initialized
INFO - 2018-07-15 13:14:22 --> Model Class Initialized
INFO - 2018-07-15 13:14:22 --> Helper loaded: url_helper
INFO - 2018-07-15 13:14:22 --> Model Class Initialized
INFO - 2018-07-15 13:14:22 --> Final output sent to browser
DEBUG - 2018-07-15 13:14:22 --> Total execution time: 0.0619
ERROR - 2018-07-15 13:52:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 13:52:06 --> Config Class Initialized
INFO - 2018-07-15 13:52:06 --> Hooks Class Initialized
DEBUG - 2018-07-15 13:52:06 --> UTF-8 Support Enabled
INFO - 2018-07-15 13:52:06 --> Utf8 Class Initialized
INFO - 2018-07-15 13:52:06 --> URI Class Initialized
INFO - 2018-07-15 13:52:06 --> Router Class Initialized
INFO - 2018-07-15 13:52:06 --> Output Class Initialized
INFO - 2018-07-15 13:52:06 --> Security Class Initialized
DEBUG - 2018-07-15 13:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 13:52:06 --> Input Class Initialized
INFO - 2018-07-15 13:52:06 --> Language Class Initialized
INFO - 2018-07-15 13:52:06 --> Loader Class Initialized
INFO - 2018-07-15 13:52:06 --> Controller Class Initialized
INFO - 2018-07-15 13:52:06 --> Database Driver Class Initialized
INFO - 2018-07-15 13:52:06 --> Model Class Initialized
INFO - 2018-07-15 13:52:06 --> Helper loaded: url_helper
INFO - 2018-07-15 13:52:06 --> Model Class Initialized
INFO - 2018-07-15 13:52:06 --> Final output sent to browser
DEBUG - 2018-07-15 13:52:06 --> Total execution time: 0.0466
ERROR - 2018-07-15 13:52:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 13:52:06 --> Config Class Initialized
INFO - 2018-07-15 13:52:06 --> Hooks Class Initialized
DEBUG - 2018-07-15 13:52:06 --> UTF-8 Support Enabled
INFO - 2018-07-15 13:52:06 --> Utf8 Class Initialized
INFO - 2018-07-15 13:52:06 --> URI Class Initialized
INFO - 2018-07-15 13:52:06 --> Router Class Initialized
INFO - 2018-07-15 13:52:06 --> Output Class Initialized
INFO - 2018-07-15 13:52:06 --> Security Class Initialized
DEBUG - 2018-07-15 13:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 13:52:06 --> Input Class Initialized
INFO - 2018-07-15 13:52:06 --> Language Class Initialized
INFO - 2018-07-15 13:52:06 --> Loader Class Initialized
INFO - 2018-07-15 13:52:06 --> Controller Class Initialized
INFO - 2018-07-15 13:52:06 --> Database Driver Class Initialized
INFO - 2018-07-15 13:52:06 --> Model Class Initialized
INFO - 2018-07-15 13:52:06 --> Helper loaded: url_helper
INFO - 2018-07-15 13:52:06 --> Model Class Initialized
INFO - 2018-07-15 13:52:06 --> Final output sent to browser
DEBUG - 2018-07-15 13:52:06 --> Total execution time: 0.1574
ERROR - 2018-07-15 13:53:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 13:53:07 --> Config Class Initialized
INFO - 2018-07-15 13:53:07 --> Hooks Class Initialized
DEBUG - 2018-07-15 13:53:07 --> UTF-8 Support Enabled
INFO - 2018-07-15 13:53:07 --> Utf8 Class Initialized
INFO - 2018-07-15 13:53:07 --> URI Class Initialized
INFO - 2018-07-15 13:53:07 --> Router Class Initialized
INFO - 2018-07-15 13:53:07 --> Output Class Initialized
INFO - 2018-07-15 13:53:07 --> Security Class Initialized
DEBUG - 2018-07-15 13:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 13:53:07 --> Input Class Initialized
INFO - 2018-07-15 13:53:07 --> Language Class Initialized
INFO - 2018-07-15 13:53:07 --> Loader Class Initialized
INFO - 2018-07-15 13:53:07 --> Controller Class Initialized
INFO - 2018-07-15 13:53:07 --> Database Driver Class Initialized
INFO - 2018-07-15 13:53:07 --> Model Class Initialized
INFO - 2018-07-15 13:53:07 --> Helper loaded: url_helper
INFO - 2018-07-15 13:53:07 --> Model Class Initialized
INFO - 2018-07-15 13:53:07 --> Final output sent to browser
DEBUG - 2018-07-15 13:53:07 --> Total execution time: 0.0468
ERROR - 2018-07-15 14:35:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 14:35:00 --> Config Class Initialized
INFO - 2018-07-15 14:35:00 --> Hooks Class Initialized
DEBUG - 2018-07-15 14:35:00 --> UTF-8 Support Enabled
INFO - 2018-07-15 14:35:00 --> Utf8 Class Initialized
INFO - 2018-07-15 14:35:00 --> URI Class Initialized
INFO - 2018-07-15 14:35:00 --> Router Class Initialized
INFO - 2018-07-15 14:35:00 --> Output Class Initialized
INFO - 2018-07-15 14:35:00 --> Security Class Initialized
DEBUG - 2018-07-15 14:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 14:35:00 --> Input Class Initialized
INFO - 2018-07-15 14:35:00 --> Language Class Initialized
INFO - 2018-07-15 14:35:00 --> Loader Class Initialized
INFO - 2018-07-15 14:35:00 --> Controller Class Initialized
INFO - 2018-07-15 14:35:00 --> Database Driver Class Initialized
INFO - 2018-07-15 14:35:00 --> Model Class Initialized
INFO - 2018-07-15 14:35:00 --> Helper loaded: url_helper
INFO - 2018-07-15 14:35:00 --> Model Class Initialized
INFO - 2018-07-15 14:35:00 --> Final output sent to browser
DEBUG - 2018-07-15 14:35:00 --> Total execution time: 0.7026
ERROR - 2018-07-15 14:35:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 14:35:17 --> Config Class Initialized
INFO - 2018-07-15 14:35:17 --> Hooks Class Initialized
DEBUG - 2018-07-15 14:35:17 --> UTF-8 Support Enabled
INFO - 2018-07-15 14:35:17 --> Utf8 Class Initialized
INFO - 2018-07-15 14:35:17 --> URI Class Initialized
INFO - 2018-07-15 14:35:17 --> Router Class Initialized
INFO - 2018-07-15 14:35:17 --> Output Class Initialized
INFO - 2018-07-15 14:35:17 --> Security Class Initialized
DEBUG - 2018-07-15 14:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 14:35:17 --> Input Class Initialized
INFO - 2018-07-15 14:35:17 --> Language Class Initialized
INFO - 2018-07-15 14:35:17 --> Loader Class Initialized
INFO - 2018-07-15 14:35:17 --> Controller Class Initialized
INFO - 2018-07-15 14:35:17 --> Database Driver Class Initialized
INFO - 2018-07-15 14:35:17 --> Model Class Initialized
INFO - 2018-07-15 14:35:17 --> Helper loaded: url_helper
DEBUG - 2018-07-15 14:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 14:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 14:35:17 --> Model Class Initialized
ERROR - 2018-07-15 14:35:17 --> Severity: Notice --> Undefined index: Davidhood C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-07-15 14:35:17 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 14:35:17 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 14:35:17 --> Final output sent to browser
DEBUG - 2018-07-15 14:35:17 --> Total execution time: 0.3107
ERROR - 2018-07-15 14:35:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 14:35:18 --> Config Class Initialized
INFO - 2018-07-15 14:35:18 --> Hooks Class Initialized
DEBUG - 2018-07-15 14:35:18 --> UTF-8 Support Enabled
INFO - 2018-07-15 14:35:18 --> Utf8 Class Initialized
INFO - 2018-07-15 14:35:18 --> URI Class Initialized
DEBUG - 2018-07-15 14:35:18 --> No URI present. Default controller set.
INFO - 2018-07-15 14:35:18 --> Router Class Initialized
INFO - 2018-07-15 14:35:18 --> Output Class Initialized
INFO - 2018-07-15 14:35:18 --> Security Class Initialized
DEBUG - 2018-07-15 14:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 14:35:18 --> Input Class Initialized
INFO - 2018-07-15 14:35:18 --> Language Class Initialized
INFO - 2018-07-15 14:35:18 --> Loader Class Initialized
INFO - 2018-07-15 14:35:18 --> Controller Class Initialized
INFO - 2018-07-15 14:35:18 --> Database Driver Class Initialized
INFO - 2018-07-15 14:35:18 --> Model Class Initialized
INFO - 2018-07-15 14:35:18 --> Helper loaded: url_helper
DEBUG - 2018-07-15 14:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 14:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 14:35:18 --> Model Class Initialized
INFO - 2018-07-15 14:35:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-15 14:35:18 --> Final output sent to browser
DEBUG - 2018-07-15 14:35:18 --> Total execution time: 0.0666
ERROR - 2018-07-15 14:35:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 14:35:19 --> Config Class Initialized
INFO - 2018-07-15 14:35:19 --> Hooks Class Initialized
DEBUG - 2018-07-15 14:35:19 --> UTF-8 Support Enabled
INFO - 2018-07-15 14:35:19 --> Utf8 Class Initialized
INFO - 2018-07-15 14:35:19 --> URI Class Initialized
INFO - 2018-07-15 14:35:19 --> Router Class Initialized
INFO - 2018-07-15 14:35:19 --> Output Class Initialized
INFO - 2018-07-15 14:35:19 --> Security Class Initialized
DEBUG - 2018-07-15 14:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 14:35:19 --> Input Class Initialized
INFO - 2018-07-15 14:35:19 --> Language Class Initialized
INFO - 2018-07-15 14:35:19 --> Loader Class Initialized
INFO - 2018-07-15 14:35:19 --> Controller Class Initialized
INFO - 2018-07-15 14:35:19 --> Database Driver Class Initialized
INFO - 2018-07-15 14:35:19 --> Model Class Initialized
INFO - 2018-07-15 14:35:19 --> Helper loaded: url_helper
DEBUG - 2018-07-15 14:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 14:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 14:35:19 --> Model Class Initialized
ERROR - 2018-07-15 14:35:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 14:35:19 --> Config Class Initialized
INFO - 2018-07-15 14:35:19 --> Hooks Class Initialized
DEBUG - 2018-07-15 14:35:19 --> UTF-8 Support Enabled
INFO - 2018-07-15 14:35:19 --> Utf8 Class Initialized
INFO - 2018-07-15 14:35:19 --> URI Class Initialized
INFO - 2018-07-15 14:35:19 --> Router Class Initialized
INFO - 2018-07-15 14:35:19 --> Output Class Initialized
INFO - 2018-07-15 14:35:19 --> Security Class Initialized
DEBUG - 2018-07-15 14:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 14:35:19 --> Input Class Initialized
INFO - 2018-07-15 14:35:19 --> Language Class Initialized
INFO - 2018-07-15 14:35:19 --> Loader Class Initialized
INFO - 2018-07-15 14:35:19 --> Controller Class Initialized
INFO - 2018-07-15 14:35:19 --> Database Driver Class Initialized
INFO - 2018-07-15 14:35:19 --> Model Class Initialized
INFO - 2018-07-15 14:35:19 --> Helper loaded: url_helper
DEBUG - 2018-07-15 14:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 14:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 14:35:19 --> Model Class Initialized
INFO - 2018-07-15 14:35:19 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 14:35:19 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-15 14:35:19 --> Final output sent to browser
DEBUG - 2018-07-15 14:35:19 --> Total execution time: 0.0659
ERROR - 2018-07-15 14:35:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 14:35:20 --> Config Class Initialized
INFO - 2018-07-15 14:35:20 --> Hooks Class Initialized
DEBUG - 2018-07-15 14:35:20 --> UTF-8 Support Enabled
INFO - 2018-07-15 14:35:20 --> Utf8 Class Initialized
INFO - 2018-07-15 14:35:20 --> URI Class Initialized
INFO - 2018-07-15 14:35:20 --> Router Class Initialized
INFO - 2018-07-15 14:35:20 --> Output Class Initialized
INFO - 2018-07-15 14:35:20 --> Security Class Initialized
DEBUG - 2018-07-15 14:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 14:35:20 --> Input Class Initialized
INFO - 2018-07-15 14:35:20 --> Language Class Initialized
INFO - 2018-07-15 14:35:20 --> Loader Class Initialized
INFO - 2018-07-15 14:35:20 --> Controller Class Initialized
INFO - 2018-07-15 14:35:20 --> Database Driver Class Initialized
INFO - 2018-07-15 14:35:20 --> Model Class Initialized
INFO - 2018-07-15 14:35:20 --> Helper loaded: url_helper
DEBUG - 2018-07-15 14:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 14:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 14:35:20 --> Model Class Initialized
INFO - 2018-07-15 14:35:20 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 14:35:20 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 14:35:20 --> Final output sent to browser
DEBUG - 2018-07-15 14:35:20 --> Total execution time: 0.0776
ERROR - 2018-07-15 14:35:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 14:35:30 --> Config Class Initialized
INFO - 2018-07-15 14:35:30 --> Hooks Class Initialized
DEBUG - 2018-07-15 14:35:30 --> UTF-8 Support Enabled
INFO - 2018-07-15 14:35:30 --> Utf8 Class Initialized
INFO - 2018-07-15 14:35:30 --> URI Class Initialized
INFO - 2018-07-15 14:35:30 --> Router Class Initialized
INFO - 2018-07-15 14:35:30 --> Output Class Initialized
INFO - 2018-07-15 14:35:30 --> Security Class Initialized
DEBUG - 2018-07-15 14:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 14:35:30 --> Input Class Initialized
INFO - 2018-07-15 14:35:30 --> Language Class Initialized
INFO - 2018-07-15 14:35:30 --> Loader Class Initialized
INFO - 2018-07-15 14:35:30 --> Controller Class Initialized
INFO - 2018-07-15 14:35:30 --> Database Driver Class Initialized
INFO - 2018-07-15 14:35:30 --> Model Class Initialized
INFO - 2018-07-15 14:35:30 --> Helper loaded: url_helper
DEBUG - 2018-07-15 14:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 14:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 14:35:30 --> Model Class Initialized
ERROR - 2018-07-15 14:35:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 14:35:31 --> Config Class Initialized
INFO - 2018-07-15 14:35:31 --> Hooks Class Initialized
DEBUG - 2018-07-15 14:35:31 --> UTF-8 Support Enabled
INFO - 2018-07-15 14:35:31 --> Utf8 Class Initialized
INFO - 2018-07-15 14:35:31 --> URI Class Initialized
INFO - 2018-07-15 14:35:31 --> Router Class Initialized
INFO - 2018-07-15 14:35:31 --> Output Class Initialized
INFO - 2018-07-15 14:35:31 --> Security Class Initialized
DEBUG - 2018-07-15 14:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 14:35:31 --> Input Class Initialized
INFO - 2018-07-15 14:35:31 --> Language Class Initialized
INFO - 2018-07-15 14:35:31 --> Loader Class Initialized
INFO - 2018-07-15 14:35:31 --> Controller Class Initialized
INFO - 2018-07-15 14:35:31 --> Database Driver Class Initialized
INFO - 2018-07-15 14:35:31 --> Model Class Initialized
INFO - 2018-07-15 14:35:31 --> Helper loaded: url_helper
DEBUG - 2018-07-15 14:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 14:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 14:35:31 --> Model Class Initialized
INFO - 2018-07-15 14:35:31 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 14:35:31 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 14:35:31 --> Final output sent to browser
DEBUG - 2018-07-15 14:35:31 --> Total execution time: 0.0966
ERROR - 2018-07-15 14:35:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 14:35:34 --> Config Class Initialized
INFO - 2018-07-15 14:35:34 --> Hooks Class Initialized
DEBUG - 2018-07-15 14:35:34 --> UTF-8 Support Enabled
INFO - 2018-07-15 14:35:34 --> Utf8 Class Initialized
INFO - 2018-07-15 14:35:34 --> URI Class Initialized
INFO - 2018-07-15 14:35:34 --> Router Class Initialized
INFO - 2018-07-15 14:35:34 --> Output Class Initialized
INFO - 2018-07-15 14:35:34 --> Security Class Initialized
DEBUG - 2018-07-15 14:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 14:35:34 --> Input Class Initialized
INFO - 2018-07-15 14:35:34 --> Language Class Initialized
INFO - 2018-07-15 14:35:34 --> Loader Class Initialized
INFO - 2018-07-15 14:35:34 --> Controller Class Initialized
INFO - 2018-07-15 14:35:34 --> Database Driver Class Initialized
INFO - 2018-07-15 14:35:34 --> Model Class Initialized
INFO - 2018-07-15 14:35:34 --> Helper loaded: url_helper
DEBUG - 2018-07-15 14:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 14:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 14:35:34 --> Model Class Initialized
ERROR - 2018-07-15 14:35:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 14:35:34 --> Config Class Initialized
INFO - 2018-07-15 14:35:34 --> Hooks Class Initialized
DEBUG - 2018-07-15 14:35:34 --> UTF-8 Support Enabled
INFO - 2018-07-15 14:35:34 --> Utf8 Class Initialized
INFO - 2018-07-15 14:35:34 --> URI Class Initialized
INFO - 2018-07-15 14:35:34 --> Router Class Initialized
INFO - 2018-07-15 14:35:34 --> Output Class Initialized
INFO - 2018-07-15 14:35:34 --> Security Class Initialized
DEBUG - 2018-07-15 14:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 14:35:34 --> Input Class Initialized
INFO - 2018-07-15 14:35:34 --> Language Class Initialized
INFO - 2018-07-15 14:35:34 --> Loader Class Initialized
INFO - 2018-07-15 14:35:34 --> Controller Class Initialized
INFO - 2018-07-15 14:35:34 --> Database Driver Class Initialized
INFO - 2018-07-15 14:35:34 --> Model Class Initialized
INFO - 2018-07-15 14:35:34 --> Helper loaded: url_helper
DEBUG - 2018-07-15 14:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 14:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 14:35:34 --> Model Class Initialized
INFO - 2018-07-15 14:35:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 14:35:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 14:35:34 --> Final output sent to browser
DEBUG - 2018-07-15 14:35:34 --> Total execution time: 0.0529
ERROR - 2018-07-15 14:35:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 14:35:38 --> Config Class Initialized
INFO - 2018-07-15 14:35:38 --> Hooks Class Initialized
DEBUG - 2018-07-15 14:35:38 --> UTF-8 Support Enabled
INFO - 2018-07-15 14:35:38 --> Utf8 Class Initialized
INFO - 2018-07-15 14:35:38 --> URI Class Initialized
INFO - 2018-07-15 14:35:38 --> Router Class Initialized
INFO - 2018-07-15 14:35:38 --> Output Class Initialized
INFO - 2018-07-15 14:35:38 --> Security Class Initialized
DEBUG - 2018-07-15 14:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 14:35:38 --> Input Class Initialized
INFO - 2018-07-15 14:35:38 --> Language Class Initialized
INFO - 2018-07-15 14:35:38 --> Loader Class Initialized
INFO - 2018-07-15 14:35:38 --> Controller Class Initialized
INFO - 2018-07-15 14:35:38 --> Database Driver Class Initialized
INFO - 2018-07-15 14:35:38 --> Model Class Initialized
INFO - 2018-07-15 14:35:38 --> Helper loaded: url_helper
DEBUG - 2018-07-15 14:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 14:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 14:35:38 --> Model Class Initialized
INFO - 2018-07-15 14:35:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 14:35:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-15 14:35:38 --> Final output sent to browser
DEBUG - 2018-07-15 14:35:38 --> Total execution time: 0.0731
ERROR - 2018-07-15 14:37:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 14:37:53 --> Config Class Initialized
INFO - 2018-07-15 14:37:53 --> Hooks Class Initialized
DEBUG - 2018-07-15 14:37:53 --> UTF-8 Support Enabled
INFO - 2018-07-15 14:37:53 --> Utf8 Class Initialized
INFO - 2018-07-15 14:37:53 --> URI Class Initialized
INFO - 2018-07-15 14:37:53 --> Router Class Initialized
INFO - 2018-07-15 14:37:53 --> Output Class Initialized
INFO - 2018-07-15 14:37:53 --> Security Class Initialized
DEBUG - 2018-07-15 14:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 14:37:53 --> Input Class Initialized
INFO - 2018-07-15 14:37:53 --> Language Class Initialized
INFO - 2018-07-15 14:37:53 --> Loader Class Initialized
INFO - 2018-07-15 14:37:53 --> Controller Class Initialized
INFO - 2018-07-15 14:37:53 --> Database Driver Class Initialized
INFO - 2018-07-15 14:37:53 --> Model Class Initialized
INFO - 2018-07-15 14:37:53 --> Helper loaded: url_helper
INFO - 2018-07-15 14:37:53 --> Model Class Initialized
INFO - 2018-07-15 14:37:54 --> Final output sent to browser
DEBUG - 2018-07-15 14:37:54 --> Total execution time: 0.4004
ERROR - 2018-07-15 15:03:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:03:05 --> Config Class Initialized
INFO - 2018-07-15 15:03:05 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:03:05 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:03:05 --> Utf8 Class Initialized
INFO - 2018-07-15 15:03:05 --> URI Class Initialized
INFO - 2018-07-15 15:03:05 --> Router Class Initialized
INFO - 2018-07-15 15:03:05 --> Output Class Initialized
INFO - 2018-07-15 15:03:05 --> Security Class Initialized
DEBUG - 2018-07-15 15:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:03:05 --> Input Class Initialized
INFO - 2018-07-15 15:03:05 --> Language Class Initialized
INFO - 2018-07-15 15:03:05 --> Loader Class Initialized
INFO - 2018-07-15 15:03:05 --> Controller Class Initialized
INFO - 2018-07-15 15:03:05 --> Database Driver Class Initialized
INFO - 2018-07-15 15:03:05 --> Model Class Initialized
INFO - 2018-07-15 15:03:05 --> Helper loaded: url_helper
INFO - 2018-07-15 15:03:05 --> Model Class Initialized
INFO - 2018-07-15 15:03:05 --> Final output sent to browser
DEBUG - 2018-07-15 15:03:05 --> Total execution time: 0.0573
ERROR - 2018-07-15 15:08:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:08:30 --> Config Class Initialized
INFO - 2018-07-15 15:08:30 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:08:30 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:08:30 --> Utf8 Class Initialized
INFO - 2018-07-15 15:08:30 --> URI Class Initialized
INFO - 2018-07-15 15:08:30 --> Router Class Initialized
INFO - 2018-07-15 15:08:30 --> Output Class Initialized
INFO - 2018-07-15 15:08:30 --> Security Class Initialized
DEBUG - 2018-07-15 15:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:08:30 --> Input Class Initialized
INFO - 2018-07-15 15:08:30 --> Language Class Initialized
INFO - 2018-07-15 15:08:30 --> Loader Class Initialized
INFO - 2018-07-15 15:08:30 --> Controller Class Initialized
INFO - 2018-07-15 15:08:30 --> Database Driver Class Initialized
INFO - 2018-07-15 15:08:30 --> Model Class Initialized
INFO - 2018-07-15 15:08:30 --> Helper loaded: url_helper
INFO - 2018-07-15 15:08:30 --> Model Class Initialized
INFO - 2018-07-15 15:08:30 --> Final output sent to browser
DEBUG - 2018-07-15 15:08:30 --> Total execution time: 0.0512
ERROR - 2018-07-15 15:08:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:08:30 --> Config Class Initialized
INFO - 2018-07-15 15:08:30 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:08:30 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:08:30 --> Utf8 Class Initialized
INFO - 2018-07-15 15:08:30 --> URI Class Initialized
INFO - 2018-07-15 15:08:30 --> Router Class Initialized
INFO - 2018-07-15 15:08:30 --> Output Class Initialized
INFO - 2018-07-15 15:08:30 --> Security Class Initialized
DEBUG - 2018-07-15 15:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:08:30 --> Input Class Initialized
INFO - 2018-07-15 15:08:30 --> Language Class Initialized
INFO - 2018-07-15 15:08:30 --> Loader Class Initialized
INFO - 2018-07-15 15:08:30 --> Controller Class Initialized
INFO - 2018-07-15 15:08:30 --> Database Driver Class Initialized
INFO - 2018-07-15 15:08:30 --> Model Class Initialized
INFO - 2018-07-15 15:08:30 --> Helper loaded: url_helper
INFO - 2018-07-15 15:08:30 --> Model Class Initialized
INFO - 2018-07-15 15:08:30 --> Final output sent to browser
DEBUG - 2018-07-15 15:08:30 --> Total execution time: 0.0594
ERROR - 2018-07-15 15:09:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:09:41 --> Config Class Initialized
INFO - 2018-07-15 15:09:41 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:09:42 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:09:42 --> Utf8 Class Initialized
INFO - 2018-07-15 15:09:42 --> URI Class Initialized
INFO - 2018-07-15 15:09:42 --> Router Class Initialized
INFO - 2018-07-15 15:09:42 --> Output Class Initialized
INFO - 2018-07-15 15:09:42 --> Security Class Initialized
DEBUG - 2018-07-15 15:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:09:42 --> Input Class Initialized
INFO - 2018-07-15 15:09:42 --> Language Class Initialized
INFO - 2018-07-15 15:09:42 --> Loader Class Initialized
INFO - 2018-07-15 15:09:42 --> Controller Class Initialized
INFO - 2018-07-15 15:09:42 --> Database Driver Class Initialized
INFO - 2018-07-15 15:09:42 --> Model Class Initialized
INFO - 2018-07-15 15:09:42 --> Helper loaded: url_helper
INFO - 2018-07-15 15:09:42 --> Model Class Initialized
INFO - 2018-07-15 15:09:42 --> Final output sent to browser
DEBUG - 2018-07-15 15:09:42 --> Total execution time: 0.0596
ERROR - 2018-07-15 15:09:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:09:42 --> Config Class Initialized
INFO - 2018-07-15 15:09:42 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:09:42 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:09:42 --> Utf8 Class Initialized
INFO - 2018-07-15 15:09:42 --> URI Class Initialized
INFO - 2018-07-15 15:09:42 --> Router Class Initialized
INFO - 2018-07-15 15:09:42 --> Output Class Initialized
INFO - 2018-07-15 15:09:42 --> Security Class Initialized
DEBUG - 2018-07-15 15:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:09:42 --> Input Class Initialized
INFO - 2018-07-15 15:09:42 --> Language Class Initialized
INFO - 2018-07-15 15:09:42 --> Loader Class Initialized
INFO - 2018-07-15 15:09:42 --> Controller Class Initialized
INFO - 2018-07-15 15:09:42 --> Database Driver Class Initialized
INFO - 2018-07-15 15:09:42 --> Model Class Initialized
INFO - 2018-07-15 15:09:42 --> Helper loaded: url_helper
INFO - 2018-07-15 15:09:42 --> Model Class Initialized
INFO - 2018-07-15 15:09:42 --> Final output sent to browser
DEBUG - 2018-07-15 15:09:42 --> Total execution time: 0.0568
ERROR - 2018-07-15 15:09:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:09:42 --> Config Class Initialized
INFO - 2018-07-15 15:09:42 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:09:42 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:09:42 --> Utf8 Class Initialized
INFO - 2018-07-15 15:09:42 --> URI Class Initialized
INFO - 2018-07-15 15:09:42 --> Router Class Initialized
INFO - 2018-07-15 15:09:42 --> Output Class Initialized
INFO - 2018-07-15 15:09:42 --> Security Class Initialized
DEBUG - 2018-07-15 15:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:09:42 --> Input Class Initialized
INFO - 2018-07-15 15:09:42 --> Language Class Initialized
INFO - 2018-07-15 15:09:42 --> Loader Class Initialized
INFO - 2018-07-15 15:09:42 --> Controller Class Initialized
INFO - 2018-07-15 15:09:42 --> Database Driver Class Initialized
INFO - 2018-07-15 15:09:42 --> Model Class Initialized
INFO - 2018-07-15 15:09:42 --> Helper loaded: url_helper
INFO - 2018-07-15 15:09:42 --> Model Class Initialized
INFO - 2018-07-15 15:09:42 --> Final output sent to browser
DEBUG - 2018-07-15 15:09:42 --> Total execution time: 0.0351
ERROR - 2018-07-15 15:10:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:10:46 --> Config Class Initialized
INFO - 2018-07-15 15:10:46 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:10:46 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:10:46 --> Utf8 Class Initialized
INFO - 2018-07-15 15:10:46 --> URI Class Initialized
INFO - 2018-07-15 15:10:46 --> Router Class Initialized
INFO - 2018-07-15 15:10:46 --> Output Class Initialized
INFO - 2018-07-15 15:10:46 --> Security Class Initialized
DEBUG - 2018-07-15 15:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:10:46 --> Input Class Initialized
INFO - 2018-07-15 15:10:46 --> Language Class Initialized
INFO - 2018-07-15 15:10:46 --> Loader Class Initialized
INFO - 2018-07-15 15:10:46 --> Controller Class Initialized
INFO - 2018-07-15 15:10:46 --> Database Driver Class Initialized
INFO - 2018-07-15 15:10:46 --> Model Class Initialized
INFO - 2018-07-15 15:10:46 --> Helper loaded: url_helper
INFO - 2018-07-15 15:10:46 --> Model Class Initialized
INFO - 2018-07-15 15:10:46 --> Final output sent to browser
DEBUG - 2018-07-15 15:10:46 --> Total execution time: 0.0725
ERROR - 2018-07-15 15:10:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:10:47 --> Config Class Initialized
INFO - 2018-07-15 15:10:47 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:10:47 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:10:47 --> Utf8 Class Initialized
INFO - 2018-07-15 15:10:47 --> URI Class Initialized
INFO - 2018-07-15 15:10:47 --> Router Class Initialized
INFO - 2018-07-15 15:10:47 --> Output Class Initialized
INFO - 2018-07-15 15:10:47 --> Security Class Initialized
DEBUG - 2018-07-15 15:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:10:47 --> Input Class Initialized
INFO - 2018-07-15 15:10:47 --> Language Class Initialized
INFO - 2018-07-15 15:10:47 --> Loader Class Initialized
INFO - 2018-07-15 15:10:47 --> Controller Class Initialized
INFO - 2018-07-15 15:10:47 --> Database Driver Class Initialized
INFO - 2018-07-15 15:10:47 --> Model Class Initialized
INFO - 2018-07-15 15:10:47 --> Helper loaded: url_helper
INFO - 2018-07-15 15:10:47 --> Model Class Initialized
INFO - 2018-07-15 15:10:47 --> Final output sent to browser
DEBUG - 2018-07-15 15:10:47 --> Total execution time: 0.0567
ERROR - 2018-07-15 15:10:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:10:47 --> Config Class Initialized
INFO - 2018-07-15 15:10:47 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:10:47 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:10:47 --> Utf8 Class Initialized
INFO - 2018-07-15 15:10:47 --> URI Class Initialized
INFO - 2018-07-15 15:10:47 --> Router Class Initialized
INFO - 2018-07-15 15:10:47 --> Output Class Initialized
INFO - 2018-07-15 15:10:47 --> Security Class Initialized
DEBUG - 2018-07-15 15:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:10:47 --> Input Class Initialized
INFO - 2018-07-15 15:10:47 --> Language Class Initialized
INFO - 2018-07-15 15:10:47 --> Loader Class Initialized
INFO - 2018-07-15 15:10:47 --> Controller Class Initialized
INFO - 2018-07-15 15:10:47 --> Database Driver Class Initialized
INFO - 2018-07-15 15:10:47 --> Model Class Initialized
INFO - 2018-07-15 15:10:47 --> Helper loaded: url_helper
INFO - 2018-07-15 15:10:47 --> Model Class Initialized
INFO - 2018-07-15 15:10:47 --> Final output sent to browser
DEBUG - 2018-07-15 15:10:47 --> Total execution time: 0.0360
ERROR - 2018-07-15 15:11:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:11:05 --> Config Class Initialized
INFO - 2018-07-15 15:11:05 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:11:05 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:11:05 --> Utf8 Class Initialized
INFO - 2018-07-15 15:11:05 --> URI Class Initialized
INFO - 2018-07-15 15:11:05 --> Router Class Initialized
INFO - 2018-07-15 15:11:05 --> Output Class Initialized
INFO - 2018-07-15 15:11:05 --> Security Class Initialized
DEBUG - 2018-07-15 15:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:11:05 --> Input Class Initialized
INFO - 2018-07-15 15:11:05 --> Language Class Initialized
INFO - 2018-07-15 15:11:05 --> Loader Class Initialized
INFO - 2018-07-15 15:11:05 --> Controller Class Initialized
INFO - 2018-07-15 15:11:05 --> Database Driver Class Initialized
INFO - 2018-07-15 15:11:05 --> Model Class Initialized
INFO - 2018-07-15 15:11:05 --> Helper loaded: url_helper
INFO - 2018-07-15 15:11:05 --> Model Class Initialized
INFO - 2018-07-15 15:11:05 --> Final output sent to browser
DEBUG - 2018-07-15 15:11:05 --> Total execution time: 0.1276
ERROR - 2018-07-15 15:12:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:12:10 --> Config Class Initialized
INFO - 2018-07-15 15:12:10 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:12:10 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:12:10 --> Utf8 Class Initialized
INFO - 2018-07-15 15:12:10 --> URI Class Initialized
INFO - 2018-07-15 15:12:10 --> Router Class Initialized
INFO - 2018-07-15 15:12:10 --> Output Class Initialized
INFO - 2018-07-15 15:12:10 --> Security Class Initialized
DEBUG - 2018-07-15 15:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:12:10 --> Input Class Initialized
INFO - 2018-07-15 15:12:10 --> Language Class Initialized
INFO - 2018-07-15 15:12:10 --> Loader Class Initialized
INFO - 2018-07-15 15:12:10 --> Controller Class Initialized
INFO - 2018-07-15 15:12:10 --> Database Driver Class Initialized
INFO - 2018-07-15 15:12:10 --> Model Class Initialized
INFO - 2018-07-15 15:12:10 --> Helper loaded: url_helper
INFO - 2018-07-15 15:12:10 --> Model Class Initialized
INFO - 2018-07-15 15:12:10 --> Final output sent to browser
DEBUG - 2018-07-15 15:12:10 --> Total execution time: 0.0580
ERROR - 2018-07-15 15:12:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:12:10 --> Config Class Initialized
INFO - 2018-07-15 15:12:10 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:12:10 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:12:10 --> Utf8 Class Initialized
INFO - 2018-07-15 15:12:10 --> URI Class Initialized
INFO - 2018-07-15 15:12:10 --> Router Class Initialized
INFO - 2018-07-15 15:12:10 --> Output Class Initialized
INFO - 2018-07-15 15:12:10 --> Security Class Initialized
DEBUG - 2018-07-15 15:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:12:10 --> Input Class Initialized
INFO - 2018-07-15 15:12:10 --> Language Class Initialized
INFO - 2018-07-15 15:12:10 --> Loader Class Initialized
INFO - 2018-07-15 15:12:10 --> Controller Class Initialized
INFO - 2018-07-15 15:12:10 --> Database Driver Class Initialized
INFO - 2018-07-15 15:12:10 --> Model Class Initialized
INFO - 2018-07-15 15:12:10 --> Helper loaded: url_helper
INFO - 2018-07-15 15:12:10 --> Model Class Initialized
INFO - 2018-07-15 15:12:10 --> Final output sent to browser
DEBUG - 2018-07-15 15:12:10 --> Total execution time: 0.0632
ERROR - 2018-07-15 15:12:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:12:10 --> Config Class Initialized
INFO - 2018-07-15 15:12:10 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:12:10 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:12:10 --> Utf8 Class Initialized
INFO - 2018-07-15 15:12:10 --> URI Class Initialized
INFO - 2018-07-15 15:12:10 --> Router Class Initialized
INFO - 2018-07-15 15:12:10 --> Output Class Initialized
INFO - 2018-07-15 15:12:10 --> Security Class Initialized
DEBUG - 2018-07-15 15:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:12:10 --> Input Class Initialized
INFO - 2018-07-15 15:12:10 --> Language Class Initialized
INFO - 2018-07-15 15:12:10 --> Loader Class Initialized
INFO - 2018-07-15 15:12:10 --> Controller Class Initialized
INFO - 2018-07-15 15:12:10 --> Database Driver Class Initialized
INFO - 2018-07-15 15:12:10 --> Model Class Initialized
INFO - 2018-07-15 15:12:10 --> Helper loaded: url_helper
INFO - 2018-07-15 15:12:10 --> Model Class Initialized
INFO - 2018-07-15 15:12:10 --> Final output sent to browser
DEBUG - 2018-07-15 15:12:10 --> Total execution time: 0.0704
ERROR - 2018-07-15 15:12:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:12:24 --> Config Class Initialized
INFO - 2018-07-15 15:12:24 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:12:24 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:12:24 --> Utf8 Class Initialized
INFO - 2018-07-15 15:12:24 --> URI Class Initialized
INFO - 2018-07-15 15:12:24 --> Router Class Initialized
INFO - 2018-07-15 15:12:24 --> Output Class Initialized
INFO - 2018-07-15 15:12:24 --> Security Class Initialized
DEBUG - 2018-07-15 15:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:12:24 --> Input Class Initialized
INFO - 2018-07-15 15:12:24 --> Language Class Initialized
INFO - 2018-07-15 15:12:24 --> Loader Class Initialized
INFO - 2018-07-15 15:12:24 --> Controller Class Initialized
INFO - 2018-07-15 15:12:24 --> Database Driver Class Initialized
INFO - 2018-07-15 15:12:24 --> Model Class Initialized
INFO - 2018-07-15 15:12:24 --> Helper loaded: url_helper
INFO - 2018-07-15 15:12:24 --> Model Class Initialized
INFO - 2018-07-15 15:12:24 --> Final output sent to browser
DEBUG - 2018-07-15 15:12:24 --> Total execution time: 0.0719
ERROR - 2018-07-15 15:12:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:12:31 --> Config Class Initialized
INFO - 2018-07-15 15:12:31 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:12:31 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:12:31 --> Utf8 Class Initialized
INFO - 2018-07-15 15:12:31 --> URI Class Initialized
INFO - 2018-07-15 15:12:31 --> Router Class Initialized
INFO - 2018-07-15 15:12:31 --> Output Class Initialized
INFO - 2018-07-15 15:12:31 --> Security Class Initialized
DEBUG - 2018-07-15 15:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:12:31 --> Input Class Initialized
INFO - 2018-07-15 15:12:31 --> Language Class Initialized
INFO - 2018-07-15 15:12:31 --> Loader Class Initialized
INFO - 2018-07-15 15:12:31 --> Controller Class Initialized
INFO - 2018-07-15 15:12:31 --> Database Driver Class Initialized
INFO - 2018-07-15 15:12:31 --> Model Class Initialized
INFO - 2018-07-15 15:12:31 --> Helper loaded: url_helper
INFO - 2018-07-15 15:12:31 --> Model Class Initialized
INFO - 2018-07-15 15:12:31 --> Final output sent to browser
DEBUG - 2018-07-15 15:12:31 --> Total execution time: 0.0625
ERROR - 2018-07-15 15:12:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:12:39 --> Config Class Initialized
INFO - 2018-07-15 15:12:39 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:12:39 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:12:39 --> Utf8 Class Initialized
INFO - 2018-07-15 15:12:39 --> URI Class Initialized
INFO - 2018-07-15 15:12:39 --> Router Class Initialized
INFO - 2018-07-15 15:12:39 --> Output Class Initialized
INFO - 2018-07-15 15:12:39 --> Security Class Initialized
DEBUG - 2018-07-15 15:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:12:39 --> Input Class Initialized
INFO - 2018-07-15 15:12:39 --> Language Class Initialized
INFO - 2018-07-15 15:12:39 --> Loader Class Initialized
INFO - 2018-07-15 15:12:39 --> Controller Class Initialized
INFO - 2018-07-15 15:12:39 --> Database Driver Class Initialized
INFO - 2018-07-15 15:12:39 --> Model Class Initialized
INFO - 2018-07-15 15:12:39 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:12:39 --> Model Class Initialized
INFO - 2018-07-15 15:12:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:12:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-15 15:12:39 --> Final output sent to browser
DEBUG - 2018-07-15 15:12:39 --> Total execution time: 0.0556
ERROR - 2018-07-15 15:12:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:12:41 --> Config Class Initialized
INFO - 2018-07-15 15:12:41 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:12:41 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:12:41 --> Utf8 Class Initialized
INFO - 2018-07-15 15:12:41 --> URI Class Initialized
INFO - 2018-07-15 15:12:41 --> Router Class Initialized
INFO - 2018-07-15 15:12:41 --> Output Class Initialized
INFO - 2018-07-15 15:12:41 --> Security Class Initialized
DEBUG - 2018-07-15 15:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:12:41 --> Input Class Initialized
INFO - 2018-07-15 15:12:41 --> Language Class Initialized
INFO - 2018-07-15 15:12:41 --> Loader Class Initialized
INFO - 2018-07-15 15:12:41 --> Controller Class Initialized
INFO - 2018-07-15 15:12:41 --> Database Driver Class Initialized
INFO - 2018-07-15 15:12:41 --> Model Class Initialized
INFO - 2018-07-15 15:12:41 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:12:41 --> Model Class Initialized
INFO - 2018-07-15 15:12:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:12:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:12:41 --> Final output sent to browser
DEBUG - 2018-07-15 15:12:41 --> Total execution time: 0.0501
ERROR - 2018-07-15 15:12:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:12:42 --> Config Class Initialized
INFO - 2018-07-15 15:12:42 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:12:42 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:12:42 --> Utf8 Class Initialized
INFO - 2018-07-15 15:12:42 --> URI Class Initialized
INFO - 2018-07-15 15:12:42 --> Router Class Initialized
INFO - 2018-07-15 15:12:42 --> Output Class Initialized
INFO - 2018-07-15 15:12:42 --> Security Class Initialized
DEBUG - 2018-07-15 15:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:12:42 --> Input Class Initialized
INFO - 2018-07-15 15:12:42 --> Language Class Initialized
INFO - 2018-07-15 15:12:42 --> Loader Class Initialized
INFO - 2018-07-15 15:12:42 --> Controller Class Initialized
INFO - 2018-07-15 15:12:42 --> Database Driver Class Initialized
INFO - 2018-07-15 15:12:42 --> Model Class Initialized
INFO - 2018-07-15 15:12:42 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:12:42 --> Model Class Initialized
ERROR - 2018-07-15 15:12:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:12:43 --> Config Class Initialized
INFO - 2018-07-15 15:12:43 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:12:43 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:12:43 --> Utf8 Class Initialized
INFO - 2018-07-15 15:12:43 --> URI Class Initialized
INFO - 2018-07-15 15:12:43 --> Router Class Initialized
INFO - 2018-07-15 15:12:43 --> Output Class Initialized
INFO - 2018-07-15 15:12:43 --> Security Class Initialized
DEBUG - 2018-07-15 15:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:12:43 --> Input Class Initialized
INFO - 2018-07-15 15:12:43 --> Language Class Initialized
INFO - 2018-07-15 15:12:43 --> Loader Class Initialized
INFO - 2018-07-15 15:12:43 --> Controller Class Initialized
INFO - 2018-07-15 15:12:43 --> Database Driver Class Initialized
INFO - 2018-07-15 15:12:43 --> Model Class Initialized
INFO - 2018-07-15 15:12:43 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:12:43 --> Model Class Initialized
INFO - 2018-07-15 15:12:43 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:12:43 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:12:43 --> Final output sent to browser
DEBUG - 2018-07-15 15:12:43 --> Total execution time: 0.0593
ERROR - 2018-07-15 15:12:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:12:47 --> Config Class Initialized
INFO - 2018-07-15 15:12:47 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:12:47 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:12:47 --> Utf8 Class Initialized
INFO - 2018-07-15 15:12:47 --> URI Class Initialized
INFO - 2018-07-15 15:12:47 --> Router Class Initialized
INFO - 2018-07-15 15:12:47 --> Output Class Initialized
INFO - 2018-07-15 15:12:47 --> Security Class Initialized
DEBUG - 2018-07-15 15:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:12:47 --> Input Class Initialized
INFO - 2018-07-15 15:12:47 --> Language Class Initialized
INFO - 2018-07-15 15:12:47 --> Loader Class Initialized
INFO - 2018-07-15 15:12:47 --> Controller Class Initialized
INFO - 2018-07-15 15:12:47 --> Database Driver Class Initialized
INFO - 2018-07-15 15:12:47 --> Model Class Initialized
INFO - 2018-07-15 15:12:47 --> Helper loaded: url_helper
INFO - 2018-07-15 15:12:47 --> Model Class Initialized
INFO - 2018-07-15 15:12:47 --> Final output sent to browser
DEBUG - 2018-07-15 15:12:47 --> Total execution time: 0.0559
ERROR - 2018-07-15 15:19:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:19:30 --> Config Class Initialized
INFO - 2018-07-15 15:19:30 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:19:30 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:19:30 --> Utf8 Class Initialized
INFO - 2018-07-15 15:19:30 --> URI Class Initialized
INFO - 2018-07-15 15:19:30 --> Router Class Initialized
INFO - 2018-07-15 15:19:30 --> Output Class Initialized
INFO - 2018-07-15 15:19:30 --> Security Class Initialized
DEBUG - 2018-07-15 15:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:19:30 --> Input Class Initialized
INFO - 2018-07-15 15:19:30 --> Language Class Initialized
INFO - 2018-07-15 15:19:30 --> Loader Class Initialized
INFO - 2018-07-15 15:19:30 --> Controller Class Initialized
INFO - 2018-07-15 15:19:30 --> Database Driver Class Initialized
INFO - 2018-07-15 15:19:30 --> Model Class Initialized
INFO - 2018-07-15 15:19:30 --> Helper loaded: url_helper
INFO - 2018-07-15 15:19:30 --> Model Class Initialized
INFO - 2018-07-15 15:19:30 --> Final output sent to browser
DEBUG - 2018-07-15 15:19:30 --> Total execution time: 0.0384
ERROR - 2018-07-15 15:19:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:19:30 --> Config Class Initialized
INFO - 2018-07-15 15:19:30 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:19:30 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:19:30 --> Utf8 Class Initialized
INFO - 2018-07-15 15:19:30 --> URI Class Initialized
INFO - 2018-07-15 15:19:30 --> Router Class Initialized
INFO - 2018-07-15 15:19:30 --> Output Class Initialized
INFO - 2018-07-15 15:19:30 --> Security Class Initialized
DEBUG - 2018-07-15 15:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:19:30 --> Input Class Initialized
INFO - 2018-07-15 15:19:30 --> Language Class Initialized
INFO - 2018-07-15 15:19:30 --> Loader Class Initialized
INFO - 2018-07-15 15:19:30 --> Controller Class Initialized
INFO - 2018-07-15 15:19:30 --> Database Driver Class Initialized
INFO - 2018-07-15 15:19:30 --> Model Class Initialized
INFO - 2018-07-15 15:19:30 --> Helper loaded: url_helper
INFO - 2018-07-15 15:19:30 --> Model Class Initialized
INFO - 2018-07-15 15:19:30 --> Final output sent to browser
DEBUG - 2018-07-15 15:19:30 --> Total execution time: 0.0583
ERROR - 2018-07-15 15:19:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:19:30 --> Config Class Initialized
INFO - 2018-07-15 15:19:30 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:19:30 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:19:30 --> Utf8 Class Initialized
INFO - 2018-07-15 15:19:30 --> URI Class Initialized
INFO - 2018-07-15 15:19:30 --> Router Class Initialized
INFO - 2018-07-15 15:19:30 --> Output Class Initialized
INFO - 2018-07-15 15:19:30 --> Security Class Initialized
DEBUG - 2018-07-15 15:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:19:30 --> Input Class Initialized
INFO - 2018-07-15 15:19:30 --> Language Class Initialized
INFO - 2018-07-15 15:19:30 --> Loader Class Initialized
INFO - 2018-07-15 15:19:30 --> Controller Class Initialized
INFO - 2018-07-15 15:19:30 --> Database Driver Class Initialized
INFO - 2018-07-15 15:19:30 --> Model Class Initialized
INFO - 2018-07-15 15:19:30 --> Helper loaded: url_helper
INFO - 2018-07-15 15:19:30 --> Model Class Initialized
INFO - 2018-07-15 15:19:30 --> Final output sent to browser
DEBUG - 2018-07-15 15:19:30 --> Total execution time: 0.0452
ERROR - 2018-07-15 15:22:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:22:52 --> Config Class Initialized
INFO - 2018-07-15 15:22:52 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:22:52 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:22:52 --> Utf8 Class Initialized
INFO - 2018-07-15 15:22:52 --> URI Class Initialized
INFO - 2018-07-15 15:22:52 --> Router Class Initialized
INFO - 2018-07-15 15:22:52 --> Output Class Initialized
INFO - 2018-07-15 15:22:52 --> Security Class Initialized
DEBUG - 2018-07-15 15:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:22:52 --> Input Class Initialized
INFO - 2018-07-15 15:22:52 --> Language Class Initialized
INFO - 2018-07-15 15:22:52 --> Loader Class Initialized
INFO - 2018-07-15 15:22:52 --> Controller Class Initialized
INFO - 2018-07-15 15:22:52 --> Database Driver Class Initialized
INFO - 2018-07-15 15:22:52 --> Model Class Initialized
INFO - 2018-07-15 15:22:52 --> Helper loaded: url_helper
INFO - 2018-07-15 15:22:52 --> Model Class Initialized
INFO - 2018-07-15 15:22:52 --> Final output sent to browser
DEBUG - 2018-07-15 15:22:52 --> Total execution time: 0.0460
ERROR - 2018-07-15 15:22:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:22:52 --> Config Class Initialized
INFO - 2018-07-15 15:22:52 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:22:52 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:22:52 --> Utf8 Class Initialized
INFO - 2018-07-15 15:22:52 --> URI Class Initialized
INFO - 2018-07-15 15:22:52 --> Router Class Initialized
INFO - 2018-07-15 15:22:52 --> Output Class Initialized
INFO - 2018-07-15 15:22:52 --> Security Class Initialized
DEBUG - 2018-07-15 15:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:22:52 --> Input Class Initialized
INFO - 2018-07-15 15:22:52 --> Language Class Initialized
INFO - 2018-07-15 15:22:52 --> Loader Class Initialized
INFO - 2018-07-15 15:22:52 --> Controller Class Initialized
INFO - 2018-07-15 15:22:52 --> Database Driver Class Initialized
INFO - 2018-07-15 15:22:52 --> Model Class Initialized
INFO - 2018-07-15 15:22:52 --> Helper loaded: url_helper
INFO - 2018-07-15 15:22:52 --> Model Class Initialized
INFO - 2018-07-15 15:22:52 --> Final output sent to browser
DEBUG - 2018-07-15 15:22:52 --> Total execution time: 0.0441
ERROR - 2018-07-15 15:22:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:22:52 --> Config Class Initialized
INFO - 2018-07-15 15:22:52 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:22:52 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:22:52 --> Utf8 Class Initialized
INFO - 2018-07-15 15:22:52 --> URI Class Initialized
INFO - 2018-07-15 15:22:52 --> Router Class Initialized
INFO - 2018-07-15 15:22:52 --> Output Class Initialized
INFO - 2018-07-15 15:22:52 --> Security Class Initialized
DEBUG - 2018-07-15 15:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:22:52 --> Input Class Initialized
INFO - 2018-07-15 15:22:52 --> Language Class Initialized
INFO - 2018-07-15 15:22:52 --> Loader Class Initialized
INFO - 2018-07-15 15:22:52 --> Controller Class Initialized
INFO - 2018-07-15 15:22:52 --> Database Driver Class Initialized
INFO - 2018-07-15 15:22:52 --> Model Class Initialized
INFO - 2018-07-15 15:22:52 --> Helper loaded: url_helper
INFO - 2018-07-15 15:22:52 --> Model Class Initialized
INFO - 2018-07-15 15:22:52 --> Final output sent to browser
DEBUG - 2018-07-15 15:22:52 --> Total execution time: 0.0389
ERROR - 2018-07-15 15:23:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:23:13 --> Config Class Initialized
INFO - 2018-07-15 15:23:13 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:23:13 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:23:13 --> Utf8 Class Initialized
INFO - 2018-07-15 15:23:13 --> URI Class Initialized
INFO - 2018-07-15 15:23:13 --> Router Class Initialized
INFO - 2018-07-15 15:23:13 --> Output Class Initialized
INFO - 2018-07-15 15:23:13 --> Security Class Initialized
DEBUG - 2018-07-15 15:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:23:13 --> Input Class Initialized
INFO - 2018-07-15 15:23:13 --> Language Class Initialized
INFO - 2018-07-15 15:23:13 --> Loader Class Initialized
INFO - 2018-07-15 15:23:13 --> Controller Class Initialized
INFO - 2018-07-15 15:23:13 --> Database Driver Class Initialized
INFO - 2018-07-15 15:23:13 --> Model Class Initialized
INFO - 2018-07-15 15:23:13 --> Helper loaded: url_helper
INFO - 2018-07-15 15:23:13 --> Model Class Initialized
INFO - 2018-07-15 15:23:13 --> Final output sent to browser
DEBUG - 2018-07-15 15:23:13 --> Total execution time: 0.0669
ERROR - 2018-07-15 15:23:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:23:13 --> Config Class Initialized
INFO - 2018-07-15 15:23:13 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:23:13 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:23:13 --> Utf8 Class Initialized
INFO - 2018-07-15 15:23:13 --> URI Class Initialized
INFO - 2018-07-15 15:23:13 --> Router Class Initialized
INFO - 2018-07-15 15:23:13 --> Output Class Initialized
INFO - 2018-07-15 15:23:13 --> Security Class Initialized
DEBUG - 2018-07-15 15:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:23:13 --> Input Class Initialized
INFO - 2018-07-15 15:23:13 --> Language Class Initialized
INFO - 2018-07-15 15:23:13 --> Loader Class Initialized
INFO - 2018-07-15 15:23:13 --> Controller Class Initialized
INFO - 2018-07-15 15:23:13 --> Database Driver Class Initialized
INFO - 2018-07-15 15:23:13 --> Model Class Initialized
INFO - 2018-07-15 15:23:13 --> Helper loaded: url_helper
INFO - 2018-07-15 15:23:13 --> Model Class Initialized
INFO - 2018-07-15 15:23:13 --> Final output sent to browser
DEBUG - 2018-07-15 15:23:13 --> Total execution time: 0.0458
ERROR - 2018-07-15 15:23:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:23:13 --> Config Class Initialized
INFO - 2018-07-15 15:23:13 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:23:13 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:23:13 --> Utf8 Class Initialized
INFO - 2018-07-15 15:23:13 --> URI Class Initialized
INFO - 2018-07-15 15:23:13 --> Router Class Initialized
INFO - 2018-07-15 15:23:13 --> Output Class Initialized
INFO - 2018-07-15 15:23:13 --> Security Class Initialized
DEBUG - 2018-07-15 15:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:23:13 --> Input Class Initialized
INFO - 2018-07-15 15:23:13 --> Language Class Initialized
INFO - 2018-07-15 15:23:13 --> Loader Class Initialized
INFO - 2018-07-15 15:23:13 --> Controller Class Initialized
INFO - 2018-07-15 15:23:13 --> Database Driver Class Initialized
INFO - 2018-07-15 15:23:13 --> Model Class Initialized
INFO - 2018-07-15 15:23:13 --> Helper loaded: url_helper
INFO - 2018-07-15 15:23:13 --> Model Class Initialized
INFO - 2018-07-15 15:23:13 --> Final output sent to browser
DEBUG - 2018-07-15 15:23:13 --> Total execution time: 0.0454
ERROR - 2018-07-15 15:23:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:23:53 --> Config Class Initialized
INFO - 2018-07-15 15:23:53 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:23:53 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:23:53 --> Utf8 Class Initialized
INFO - 2018-07-15 15:23:53 --> URI Class Initialized
INFO - 2018-07-15 15:23:53 --> Router Class Initialized
INFO - 2018-07-15 15:23:53 --> Output Class Initialized
INFO - 2018-07-15 15:23:53 --> Security Class Initialized
DEBUG - 2018-07-15 15:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:23:53 --> Input Class Initialized
INFO - 2018-07-15 15:23:53 --> Language Class Initialized
INFO - 2018-07-15 15:23:53 --> Loader Class Initialized
INFO - 2018-07-15 15:23:53 --> Controller Class Initialized
INFO - 2018-07-15 15:23:53 --> Database Driver Class Initialized
INFO - 2018-07-15 15:23:53 --> Model Class Initialized
INFO - 2018-07-15 15:23:53 --> Helper loaded: url_helper
INFO - 2018-07-15 15:23:53 --> Model Class Initialized
INFO - 2018-07-15 15:23:53 --> Final output sent to browser
DEBUG - 2018-07-15 15:23:53 --> Total execution time: 0.0552
ERROR - 2018-07-15 15:24:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:24:42 --> Config Class Initialized
INFO - 2018-07-15 15:24:42 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:24:42 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:24:42 --> Utf8 Class Initialized
INFO - 2018-07-15 15:24:42 --> URI Class Initialized
INFO - 2018-07-15 15:24:42 --> Router Class Initialized
INFO - 2018-07-15 15:24:42 --> Output Class Initialized
INFO - 2018-07-15 15:24:42 --> Security Class Initialized
DEBUG - 2018-07-15 15:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:24:42 --> Input Class Initialized
INFO - 2018-07-15 15:24:42 --> Language Class Initialized
INFO - 2018-07-15 15:24:42 --> Loader Class Initialized
INFO - 2018-07-15 15:24:42 --> Controller Class Initialized
INFO - 2018-07-15 15:24:42 --> Database Driver Class Initialized
INFO - 2018-07-15 15:24:42 --> Model Class Initialized
INFO - 2018-07-15 15:24:42 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:24:42 --> Model Class Initialized
INFO - 2018-07-15 15:24:42 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:24:42 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:24:42 --> Final output sent to browser
DEBUG - 2018-07-15 15:24:42 --> Total execution time: 0.0621
ERROR - 2018-07-15 15:24:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:24:44 --> Config Class Initialized
INFO - 2018-07-15 15:24:44 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:24:44 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:24:44 --> Utf8 Class Initialized
INFO - 2018-07-15 15:24:44 --> URI Class Initialized
INFO - 2018-07-15 15:24:44 --> Router Class Initialized
INFO - 2018-07-15 15:24:44 --> Output Class Initialized
INFO - 2018-07-15 15:24:44 --> Security Class Initialized
DEBUG - 2018-07-15 15:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:24:44 --> Input Class Initialized
INFO - 2018-07-15 15:24:44 --> Language Class Initialized
INFO - 2018-07-15 15:24:44 --> Loader Class Initialized
INFO - 2018-07-15 15:24:44 --> Controller Class Initialized
INFO - 2018-07-15 15:24:44 --> Database Driver Class Initialized
INFO - 2018-07-15 15:24:44 --> Model Class Initialized
INFO - 2018-07-15 15:24:44 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:24:44 --> Model Class Initialized
INFO - 2018-07-15 15:24:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:24:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:24:44 --> Final output sent to browser
DEBUG - 2018-07-15 15:24:44 --> Total execution time: 0.0513
ERROR - 2018-07-15 15:25:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:25:10 --> Config Class Initialized
INFO - 2018-07-15 15:25:10 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:25:10 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:25:10 --> Utf8 Class Initialized
INFO - 2018-07-15 15:25:10 --> URI Class Initialized
INFO - 2018-07-15 15:25:10 --> Router Class Initialized
INFO - 2018-07-15 15:25:10 --> Output Class Initialized
INFO - 2018-07-15 15:25:10 --> Security Class Initialized
DEBUG - 2018-07-15 15:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:25:10 --> Input Class Initialized
INFO - 2018-07-15 15:25:10 --> Language Class Initialized
INFO - 2018-07-15 15:25:10 --> Loader Class Initialized
INFO - 2018-07-15 15:25:10 --> Controller Class Initialized
INFO - 2018-07-15 15:25:10 --> Database Driver Class Initialized
INFO - 2018-07-15 15:25:10 --> Model Class Initialized
INFO - 2018-07-15 15:25:10 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:25:10 --> Model Class Initialized
INFO - 2018-07-15 15:25:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:25:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-15 15:25:10 --> Final output sent to browser
DEBUG - 2018-07-15 15:25:10 --> Total execution time: 0.0607
ERROR - 2018-07-15 15:25:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:25:17 --> Config Class Initialized
INFO - 2018-07-15 15:25:17 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:25:17 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:25:17 --> Utf8 Class Initialized
INFO - 2018-07-15 15:25:17 --> URI Class Initialized
INFO - 2018-07-15 15:25:17 --> Router Class Initialized
INFO - 2018-07-15 15:25:17 --> Output Class Initialized
INFO - 2018-07-15 15:25:17 --> Security Class Initialized
DEBUG - 2018-07-15 15:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:25:17 --> Input Class Initialized
INFO - 2018-07-15 15:25:17 --> Language Class Initialized
INFO - 2018-07-15 15:25:17 --> Loader Class Initialized
INFO - 2018-07-15 15:25:17 --> Controller Class Initialized
INFO - 2018-07-15 15:25:17 --> Database Driver Class Initialized
INFO - 2018-07-15 15:25:17 --> Model Class Initialized
INFO - 2018-07-15 15:25:17 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:25:17 --> Model Class Initialized
INFO - 2018-07-15 15:25:17 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:25:17 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:25:17 --> Final output sent to browser
DEBUG - 2018-07-15 15:25:17 --> Total execution time: 0.0517
ERROR - 2018-07-15 15:34:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:34:31 --> Config Class Initialized
INFO - 2018-07-15 15:34:31 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:34:31 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:34:31 --> Utf8 Class Initialized
INFO - 2018-07-15 15:34:31 --> URI Class Initialized
INFO - 2018-07-15 15:34:31 --> Router Class Initialized
INFO - 2018-07-15 15:34:31 --> Output Class Initialized
INFO - 2018-07-15 15:34:31 --> Security Class Initialized
DEBUG - 2018-07-15 15:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:34:31 --> Input Class Initialized
INFO - 2018-07-15 15:34:31 --> Language Class Initialized
INFO - 2018-07-15 15:34:31 --> Loader Class Initialized
INFO - 2018-07-15 15:34:31 --> Controller Class Initialized
INFO - 2018-07-15 15:34:31 --> Database Driver Class Initialized
INFO - 2018-07-15 15:34:32 --> Model Class Initialized
INFO - 2018-07-15 15:34:32 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:34:32 --> Model Class Initialized
INFO - 2018-07-15 15:34:32 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:34:32 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:34:32 --> Final output sent to browser
DEBUG - 2018-07-15 15:34:32 --> Total execution time: 0.0613
ERROR - 2018-07-15 15:34:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:34:34 --> Config Class Initialized
INFO - 2018-07-15 15:34:34 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:34:34 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:34:34 --> Utf8 Class Initialized
INFO - 2018-07-15 15:34:34 --> URI Class Initialized
INFO - 2018-07-15 15:34:34 --> Router Class Initialized
INFO - 2018-07-15 15:34:34 --> Output Class Initialized
INFO - 2018-07-15 15:34:34 --> Security Class Initialized
DEBUG - 2018-07-15 15:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:34:34 --> Input Class Initialized
INFO - 2018-07-15 15:34:34 --> Language Class Initialized
INFO - 2018-07-15 15:34:34 --> Loader Class Initialized
INFO - 2018-07-15 15:34:34 --> Controller Class Initialized
INFO - 2018-07-15 15:34:34 --> Database Driver Class Initialized
INFO - 2018-07-15 15:34:34 --> Model Class Initialized
INFO - 2018-07-15 15:34:34 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:34:34 --> Model Class Initialized
INFO - 2018-07-15 15:34:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:34:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-15 15:34:34 --> Final output sent to browser
DEBUG - 2018-07-15 15:34:34 --> Total execution time: 0.0571
ERROR - 2018-07-15 15:34:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:34:37 --> Config Class Initialized
INFO - 2018-07-15 15:34:37 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:34:37 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:34:37 --> Utf8 Class Initialized
INFO - 2018-07-15 15:34:37 --> URI Class Initialized
INFO - 2018-07-15 15:34:37 --> Router Class Initialized
INFO - 2018-07-15 15:34:37 --> Output Class Initialized
INFO - 2018-07-15 15:34:37 --> Security Class Initialized
DEBUG - 2018-07-15 15:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:34:37 --> Input Class Initialized
INFO - 2018-07-15 15:34:37 --> Language Class Initialized
INFO - 2018-07-15 15:34:37 --> Loader Class Initialized
INFO - 2018-07-15 15:34:37 --> Controller Class Initialized
INFO - 2018-07-15 15:34:37 --> Database Driver Class Initialized
INFO - 2018-07-15 15:34:37 --> Model Class Initialized
INFO - 2018-07-15 15:34:37 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:34:37 --> Model Class Initialized
INFO - 2018-07-15 15:34:37 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:34:37 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:34:37 --> Final output sent to browser
DEBUG - 2018-07-15 15:34:37 --> Total execution time: 0.0544
ERROR - 2018-07-15 15:34:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:34:38 --> Config Class Initialized
INFO - 2018-07-15 15:34:38 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:34:38 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:34:38 --> Utf8 Class Initialized
INFO - 2018-07-15 15:34:38 --> URI Class Initialized
INFO - 2018-07-15 15:34:38 --> Router Class Initialized
INFO - 2018-07-15 15:34:38 --> Output Class Initialized
INFO - 2018-07-15 15:34:38 --> Security Class Initialized
DEBUG - 2018-07-15 15:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:34:38 --> Input Class Initialized
INFO - 2018-07-15 15:34:38 --> Language Class Initialized
INFO - 2018-07-15 15:34:38 --> Loader Class Initialized
INFO - 2018-07-15 15:34:38 --> Controller Class Initialized
INFO - 2018-07-15 15:34:38 --> Database Driver Class Initialized
INFO - 2018-07-15 15:34:38 --> Model Class Initialized
INFO - 2018-07-15 15:34:38 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:34:38 --> Model Class Initialized
ERROR - 2018-07-15 15:34:39 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\davidhood\application\models\Model.php 70
ERROR - 2018-07-15 15:34:39 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\davidhood\application\models\Model.php 70
ERROR - 2018-07-15 15:34:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:34:39 --> Config Class Initialized
INFO - 2018-07-15 15:34:39 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:34:39 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:34:39 --> Utf8 Class Initialized
INFO - 2018-07-15 15:34:39 --> URI Class Initialized
INFO - 2018-07-15 15:34:39 --> Router Class Initialized
INFO - 2018-07-15 15:34:39 --> Output Class Initialized
INFO - 2018-07-15 15:34:39 --> Security Class Initialized
DEBUG - 2018-07-15 15:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:34:39 --> Input Class Initialized
INFO - 2018-07-15 15:34:39 --> Language Class Initialized
INFO - 2018-07-15 15:34:39 --> Loader Class Initialized
INFO - 2018-07-15 15:34:39 --> Controller Class Initialized
INFO - 2018-07-15 15:34:39 --> Database Driver Class Initialized
INFO - 2018-07-15 15:34:39 --> Model Class Initialized
INFO - 2018-07-15 15:34:39 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:34:39 --> Model Class Initialized
INFO - 2018-07-15 15:34:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:34:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:34:39 --> Final output sent to browser
DEBUG - 2018-07-15 15:34:39 --> Total execution time: 0.0459
ERROR - 2018-07-15 15:34:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:34:40 --> Config Class Initialized
INFO - 2018-07-15 15:34:40 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:34:40 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:34:40 --> Utf8 Class Initialized
INFO - 2018-07-15 15:34:40 --> URI Class Initialized
INFO - 2018-07-15 15:34:40 --> Router Class Initialized
INFO - 2018-07-15 15:34:40 --> Output Class Initialized
INFO - 2018-07-15 15:34:40 --> Security Class Initialized
DEBUG - 2018-07-15 15:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:34:40 --> Input Class Initialized
INFO - 2018-07-15 15:34:40 --> Language Class Initialized
INFO - 2018-07-15 15:34:40 --> Loader Class Initialized
INFO - 2018-07-15 15:34:40 --> Controller Class Initialized
INFO - 2018-07-15 15:34:40 --> Database Driver Class Initialized
INFO - 2018-07-15 15:34:40 --> Model Class Initialized
INFO - 2018-07-15 15:34:41 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:34:41 --> Model Class Initialized
INFO - 2018-07-15 15:34:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:34:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-15 15:34:41 --> Final output sent to browser
DEBUG - 2018-07-15 15:34:41 --> Total execution time: 0.3066
ERROR - 2018-07-15 15:34:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:34:45 --> Config Class Initialized
INFO - 2018-07-15 15:34:45 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:34:45 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:34:45 --> Utf8 Class Initialized
INFO - 2018-07-15 15:34:45 --> URI Class Initialized
INFO - 2018-07-15 15:34:45 --> Router Class Initialized
INFO - 2018-07-15 15:34:45 --> Output Class Initialized
INFO - 2018-07-15 15:34:45 --> Security Class Initialized
DEBUG - 2018-07-15 15:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:34:45 --> Input Class Initialized
INFO - 2018-07-15 15:34:45 --> Language Class Initialized
INFO - 2018-07-15 15:34:45 --> Loader Class Initialized
INFO - 2018-07-15 15:34:45 --> Controller Class Initialized
INFO - 2018-07-15 15:34:45 --> Database Driver Class Initialized
INFO - 2018-07-15 15:34:45 --> Model Class Initialized
INFO - 2018-07-15 15:34:45 --> Helper loaded: url_helper
INFO - 2018-07-15 15:34:45 --> Model Class Initialized
INFO - 2018-07-15 15:34:45 --> Final output sent to browser
DEBUG - 2018-07-15 15:34:45 --> Total execution time: 0.0432
ERROR - 2018-07-15 15:34:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:34:46 --> Config Class Initialized
INFO - 2018-07-15 15:34:46 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:34:46 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:34:46 --> Utf8 Class Initialized
INFO - 2018-07-15 15:34:46 --> URI Class Initialized
INFO - 2018-07-15 15:34:46 --> Router Class Initialized
INFO - 2018-07-15 15:34:46 --> Output Class Initialized
INFO - 2018-07-15 15:34:46 --> Security Class Initialized
DEBUG - 2018-07-15 15:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:34:46 --> Input Class Initialized
INFO - 2018-07-15 15:34:46 --> Language Class Initialized
INFO - 2018-07-15 15:34:46 --> Loader Class Initialized
INFO - 2018-07-15 15:34:46 --> Controller Class Initialized
INFO - 2018-07-15 15:34:46 --> Database Driver Class Initialized
INFO - 2018-07-15 15:34:46 --> Model Class Initialized
INFO - 2018-07-15 15:34:46 --> Helper loaded: url_helper
INFO - 2018-07-15 15:34:46 --> Model Class Initialized
INFO - 2018-07-15 15:34:46 --> Final output sent to browser
DEBUG - 2018-07-15 15:34:46 --> Total execution time: 0.0575
ERROR - 2018-07-15 15:34:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:34:46 --> Config Class Initialized
INFO - 2018-07-15 15:34:46 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:34:46 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:34:46 --> Utf8 Class Initialized
INFO - 2018-07-15 15:34:46 --> URI Class Initialized
INFO - 2018-07-15 15:34:46 --> Router Class Initialized
INFO - 2018-07-15 15:34:46 --> Output Class Initialized
INFO - 2018-07-15 15:34:46 --> Security Class Initialized
DEBUG - 2018-07-15 15:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:34:46 --> Input Class Initialized
INFO - 2018-07-15 15:34:46 --> Language Class Initialized
INFO - 2018-07-15 15:34:46 --> Loader Class Initialized
INFO - 2018-07-15 15:34:46 --> Controller Class Initialized
INFO - 2018-07-15 15:34:46 --> Database Driver Class Initialized
INFO - 2018-07-15 15:34:46 --> Model Class Initialized
INFO - 2018-07-15 15:34:46 --> Helper loaded: url_helper
INFO - 2018-07-15 15:34:46 --> Model Class Initialized
INFO - 2018-07-15 15:34:46 --> Final output sent to browser
DEBUG - 2018-07-15 15:34:46 --> Total execution time: 0.1275
ERROR - 2018-07-15 15:35:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:35:44 --> Config Class Initialized
INFO - 2018-07-15 15:35:44 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:35:44 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:35:44 --> Utf8 Class Initialized
INFO - 2018-07-15 15:35:44 --> URI Class Initialized
INFO - 2018-07-15 15:35:44 --> Router Class Initialized
INFO - 2018-07-15 15:35:44 --> Output Class Initialized
INFO - 2018-07-15 15:35:44 --> Security Class Initialized
DEBUG - 2018-07-15 15:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:35:44 --> Input Class Initialized
INFO - 2018-07-15 15:35:44 --> Language Class Initialized
INFO - 2018-07-15 15:35:44 --> Loader Class Initialized
INFO - 2018-07-15 15:35:44 --> Controller Class Initialized
INFO - 2018-07-15 15:35:44 --> Database Driver Class Initialized
INFO - 2018-07-15 15:35:44 --> Model Class Initialized
INFO - 2018-07-15 15:35:44 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:35:44 --> Model Class Initialized
INFO - 2018-07-15 15:35:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:35:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-15 15:35:44 --> Final output sent to browser
DEBUG - 2018-07-15 15:35:44 --> Total execution time: 0.0512
ERROR - 2018-07-15 15:36:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:36:09 --> Config Class Initialized
INFO - 2018-07-15 15:36:09 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:36:09 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:36:09 --> Utf8 Class Initialized
INFO - 2018-07-15 15:36:09 --> URI Class Initialized
INFO - 2018-07-15 15:36:09 --> Router Class Initialized
INFO - 2018-07-15 15:36:09 --> Output Class Initialized
INFO - 2018-07-15 15:36:09 --> Security Class Initialized
DEBUG - 2018-07-15 15:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:36:09 --> Input Class Initialized
INFO - 2018-07-15 15:36:09 --> Language Class Initialized
INFO - 2018-07-15 15:36:09 --> Loader Class Initialized
INFO - 2018-07-15 15:36:09 --> Controller Class Initialized
INFO - 2018-07-15 15:36:09 --> Database Driver Class Initialized
INFO - 2018-07-15 15:36:09 --> Model Class Initialized
INFO - 2018-07-15 15:36:09 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:36:09 --> Model Class Initialized
INFO - 2018-07-15 15:36:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:36:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:36:09 --> Final output sent to browser
DEBUG - 2018-07-15 15:36:09 --> Total execution time: 0.0595
ERROR - 2018-07-15 15:36:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:36:11 --> Config Class Initialized
INFO - 2018-07-15 15:36:11 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:36:11 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:36:11 --> Utf8 Class Initialized
INFO - 2018-07-15 15:36:11 --> URI Class Initialized
INFO - 2018-07-15 15:36:11 --> Router Class Initialized
INFO - 2018-07-15 15:36:11 --> Output Class Initialized
INFO - 2018-07-15 15:36:11 --> Security Class Initialized
DEBUG - 2018-07-15 15:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:36:11 --> Input Class Initialized
INFO - 2018-07-15 15:36:11 --> Language Class Initialized
INFO - 2018-07-15 15:36:11 --> Loader Class Initialized
INFO - 2018-07-15 15:36:11 --> Controller Class Initialized
INFO - 2018-07-15 15:36:11 --> Database Driver Class Initialized
INFO - 2018-07-15 15:36:11 --> Model Class Initialized
INFO - 2018-07-15 15:36:11 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:36:11 --> Model Class Initialized
INFO - 2018-07-15 15:36:11 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:36:11 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-15 15:36:11 --> Final output sent to browser
DEBUG - 2018-07-15 15:36:11 --> Total execution time: 0.0572
ERROR - 2018-07-15 15:36:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:36:12 --> Config Class Initialized
INFO - 2018-07-15 15:36:12 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:36:12 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:36:12 --> Utf8 Class Initialized
INFO - 2018-07-15 15:36:12 --> URI Class Initialized
INFO - 2018-07-15 15:36:12 --> Router Class Initialized
INFO - 2018-07-15 15:36:12 --> Output Class Initialized
INFO - 2018-07-15 15:36:12 --> Security Class Initialized
DEBUG - 2018-07-15 15:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:36:12 --> Input Class Initialized
INFO - 2018-07-15 15:36:12 --> Language Class Initialized
INFO - 2018-07-15 15:36:12 --> Loader Class Initialized
INFO - 2018-07-15 15:36:12 --> Controller Class Initialized
INFO - 2018-07-15 15:36:12 --> Database Driver Class Initialized
INFO - 2018-07-15 15:36:12 --> Model Class Initialized
INFO - 2018-07-15 15:36:12 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:36:12 --> Model Class Initialized
INFO - 2018-07-15 15:36:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:36:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:36:12 --> Final output sent to browser
DEBUG - 2018-07-15 15:36:12 --> Total execution time: 0.0560
ERROR - 2018-07-15 15:36:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:36:14 --> Config Class Initialized
INFO - 2018-07-15 15:36:14 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:36:14 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:36:14 --> Utf8 Class Initialized
INFO - 2018-07-15 15:36:14 --> URI Class Initialized
INFO - 2018-07-15 15:36:14 --> Router Class Initialized
INFO - 2018-07-15 15:36:14 --> Output Class Initialized
INFO - 2018-07-15 15:36:14 --> Security Class Initialized
DEBUG - 2018-07-15 15:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:36:14 --> Input Class Initialized
INFO - 2018-07-15 15:36:14 --> Language Class Initialized
INFO - 2018-07-15 15:36:14 --> Loader Class Initialized
INFO - 2018-07-15 15:36:14 --> Controller Class Initialized
INFO - 2018-07-15 15:36:14 --> Database Driver Class Initialized
INFO - 2018-07-15 15:36:14 --> Model Class Initialized
INFO - 2018-07-15 15:36:14 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:36:14 --> Model Class Initialized
ERROR - 2018-07-15 15:36:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:36:14 --> Config Class Initialized
INFO - 2018-07-15 15:36:14 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:36:14 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:36:14 --> Utf8 Class Initialized
INFO - 2018-07-15 15:36:14 --> URI Class Initialized
INFO - 2018-07-15 15:36:14 --> Router Class Initialized
INFO - 2018-07-15 15:36:14 --> Output Class Initialized
INFO - 2018-07-15 15:36:14 --> Security Class Initialized
DEBUG - 2018-07-15 15:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:36:14 --> Input Class Initialized
INFO - 2018-07-15 15:36:14 --> Language Class Initialized
INFO - 2018-07-15 15:36:14 --> Loader Class Initialized
INFO - 2018-07-15 15:36:14 --> Controller Class Initialized
INFO - 2018-07-15 15:36:14 --> Database Driver Class Initialized
INFO - 2018-07-15 15:36:14 --> Model Class Initialized
INFO - 2018-07-15 15:36:14 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:36:14 --> Model Class Initialized
INFO - 2018-07-15 15:36:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:36:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:36:14 --> Final output sent to browser
DEBUG - 2018-07-15 15:36:14 --> Total execution time: 0.0490
ERROR - 2018-07-15 15:36:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:36:15 --> Config Class Initialized
INFO - 2018-07-15 15:36:15 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:36:15 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:36:15 --> Utf8 Class Initialized
INFO - 2018-07-15 15:36:15 --> URI Class Initialized
INFO - 2018-07-15 15:36:15 --> Router Class Initialized
INFO - 2018-07-15 15:36:15 --> Output Class Initialized
INFO - 2018-07-15 15:36:15 --> Security Class Initialized
DEBUG - 2018-07-15 15:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:36:15 --> Input Class Initialized
INFO - 2018-07-15 15:36:15 --> Language Class Initialized
INFO - 2018-07-15 15:36:15 --> Loader Class Initialized
INFO - 2018-07-15 15:36:15 --> Controller Class Initialized
INFO - 2018-07-15 15:36:15 --> Database Driver Class Initialized
INFO - 2018-07-15 15:36:15 --> Model Class Initialized
INFO - 2018-07-15 15:36:15 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:36:15 --> Model Class Initialized
INFO - 2018-07-15 15:36:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:36:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-15 15:36:15 --> Final output sent to browser
DEBUG - 2018-07-15 15:36:15 --> Total execution time: 0.0464
ERROR - 2018-07-15 15:39:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:39:20 --> Config Class Initialized
INFO - 2018-07-15 15:39:20 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:39:20 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:39:20 --> Utf8 Class Initialized
INFO - 2018-07-15 15:39:20 --> URI Class Initialized
INFO - 2018-07-15 15:39:20 --> Router Class Initialized
INFO - 2018-07-15 15:39:20 --> Output Class Initialized
INFO - 2018-07-15 15:39:20 --> Security Class Initialized
DEBUG - 2018-07-15 15:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:39:20 --> Input Class Initialized
INFO - 2018-07-15 15:39:20 --> Language Class Initialized
INFO - 2018-07-15 15:39:20 --> Loader Class Initialized
INFO - 2018-07-15 15:39:20 --> Controller Class Initialized
INFO - 2018-07-15 15:39:20 --> Database Driver Class Initialized
INFO - 2018-07-15 15:39:20 --> Model Class Initialized
INFO - 2018-07-15 15:39:20 --> Helper loaded: url_helper
INFO - 2018-07-15 15:39:20 --> Model Class Initialized
INFO - 2018-07-15 15:39:20 --> Final output sent to browser
DEBUG - 2018-07-15 15:39:20 --> Total execution time: 0.0628
ERROR - 2018-07-15 15:39:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:39:20 --> Config Class Initialized
INFO - 2018-07-15 15:39:20 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:39:20 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:39:20 --> Utf8 Class Initialized
INFO - 2018-07-15 15:39:20 --> URI Class Initialized
INFO - 2018-07-15 15:39:20 --> Router Class Initialized
INFO - 2018-07-15 15:39:20 --> Output Class Initialized
INFO - 2018-07-15 15:39:20 --> Security Class Initialized
DEBUG - 2018-07-15 15:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:39:20 --> Input Class Initialized
INFO - 2018-07-15 15:39:20 --> Language Class Initialized
INFO - 2018-07-15 15:39:20 --> Loader Class Initialized
INFO - 2018-07-15 15:39:20 --> Controller Class Initialized
INFO - 2018-07-15 15:39:20 --> Database Driver Class Initialized
INFO - 2018-07-15 15:39:20 --> Model Class Initialized
INFO - 2018-07-15 15:39:20 --> Helper loaded: url_helper
INFO - 2018-07-15 15:39:20 --> Model Class Initialized
INFO - 2018-07-15 15:39:20 --> Final output sent to browser
DEBUG - 2018-07-15 15:39:20 --> Total execution time: 0.0466
ERROR - 2018-07-15 15:39:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:39:20 --> Config Class Initialized
INFO - 2018-07-15 15:39:20 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:39:20 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:39:20 --> Utf8 Class Initialized
INFO - 2018-07-15 15:39:20 --> URI Class Initialized
INFO - 2018-07-15 15:39:20 --> Router Class Initialized
INFO - 2018-07-15 15:39:20 --> Output Class Initialized
INFO - 2018-07-15 15:39:20 --> Security Class Initialized
DEBUG - 2018-07-15 15:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:39:20 --> Input Class Initialized
INFO - 2018-07-15 15:39:20 --> Language Class Initialized
INFO - 2018-07-15 15:39:20 --> Loader Class Initialized
INFO - 2018-07-15 15:39:20 --> Controller Class Initialized
INFO - 2018-07-15 15:39:20 --> Database Driver Class Initialized
INFO - 2018-07-15 15:39:20 --> Model Class Initialized
INFO - 2018-07-15 15:39:20 --> Helper loaded: url_helper
INFO - 2018-07-15 15:39:20 --> Model Class Initialized
INFO - 2018-07-15 15:39:20 --> Final output sent to browser
DEBUG - 2018-07-15 15:39:20 --> Total execution time: 0.0467
ERROR - 2018-07-15 15:39:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:39:36 --> Config Class Initialized
INFO - 2018-07-15 15:39:36 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:39:37 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:39:37 --> Utf8 Class Initialized
INFO - 2018-07-15 15:39:37 --> URI Class Initialized
INFO - 2018-07-15 15:39:37 --> Router Class Initialized
INFO - 2018-07-15 15:39:37 --> Output Class Initialized
INFO - 2018-07-15 15:39:37 --> Security Class Initialized
DEBUG - 2018-07-15 15:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:39:37 --> Input Class Initialized
INFO - 2018-07-15 15:39:37 --> Language Class Initialized
INFO - 2018-07-15 15:39:37 --> Loader Class Initialized
INFO - 2018-07-15 15:39:37 --> Controller Class Initialized
INFO - 2018-07-15 15:39:37 --> Database Driver Class Initialized
INFO - 2018-07-15 15:39:37 --> Model Class Initialized
INFO - 2018-07-15 15:39:37 --> Helper loaded: url_helper
INFO - 2018-07-15 15:39:37 --> Model Class Initialized
INFO - 2018-07-15 15:39:37 --> Final output sent to browser
DEBUG - 2018-07-15 15:39:37 --> Total execution time: 0.0443
ERROR - 2018-07-15 15:40:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:40:07 --> Config Class Initialized
INFO - 2018-07-15 15:40:07 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:40:07 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:40:07 --> Utf8 Class Initialized
INFO - 2018-07-15 15:40:07 --> URI Class Initialized
INFO - 2018-07-15 15:40:07 --> Router Class Initialized
INFO - 2018-07-15 15:40:07 --> Output Class Initialized
INFO - 2018-07-15 15:40:07 --> Security Class Initialized
DEBUG - 2018-07-15 15:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:40:07 --> Input Class Initialized
INFO - 2018-07-15 15:40:07 --> Language Class Initialized
INFO - 2018-07-15 15:40:07 --> Loader Class Initialized
INFO - 2018-07-15 15:40:07 --> Controller Class Initialized
INFO - 2018-07-15 15:40:07 --> Database Driver Class Initialized
INFO - 2018-07-15 15:40:07 --> Model Class Initialized
INFO - 2018-07-15 15:40:07 --> Helper loaded: url_helper
INFO - 2018-07-15 15:40:07 --> Model Class Initialized
INFO - 2018-07-15 15:40:07 --> Final output sent to browser
DEBUG - 2018-07-15 15:40:07 --> Total execution time: 0.0546
ERROR - 2018-07-15 15:40:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:40:17 --> Config Class Initialized
INFO - 2018-07-15 15:40:17 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:40:17 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:40:17 --> Utf8 Class Initialized
INFO - 2018-07-15 15:40:17 --> URI Class Initialized
INFO - 2018-07-15 15:40:17 --> Router Class Initialized
INFO - 2018-07-15 15:40:17 --> Output Class Initialized
INFO - 2018-07-15 15:40:17 --> Security Class Initialized
DEBUG - 2018-07-15 15:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:40:17 --> Input Class Initialized
INFO - 2018-07-15 15:40:17 --> Language Class Initialized
INFO - 2018-07-15 15:40:17 --> Loader Class Initialized
INFO - 2018-07-15 15:40:17 --> Controller Class Initialized
INFO - 2018-07-15 15:40:17 --> Database Driver Class Initialized
INFO - 2018-07-15 15:40:17 --> Model Class Initialized
INFO - 2018-07-15 15:40:17 --> Helper loaded: url_helper
INFO - 2018-07-15 15:40:17 --> Model Class Initialized
INFO - 2018-07-15 15:40:17 --> Final output sent to browser
DEBUG - 2018-07-15 15:40:17 --> Total execution time: 0.0418
ERROR - 2018-07-15 15:40:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:40:17 --> Config Class Initialized
INFO - 2018-07-15 15:40:17 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:40:17 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:40:17 --> Utf8 Class Initialized
INFO - 2018-07-15 15:40:17 --> URI Class Initialized
INFO - 2018-07-15 15:40:17 --> Router Class Initialized
INFO - 2018-07-15 15:40:17 --> Output Class Initialized
INFO - 2018-07-15 15:40:17 --> Security Class Initialized
DEBUG - 2018-07-15 15:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:40:17 --> Input Class Initialized
INFO - 2018-07-15 15:40:17 --> Language Class Initialized
INFO - 2018-07-15 15:40:17 --> Loader Class Initialized
INFO - 2018-07-15 15:40:17 --> Controller Class Initialized
INFO - 2018-07-15 15:40:17 --> Database Driver Class Initialized
INFO - 2018-07-15 15:40:17 --> Model Class Initialized
INFO - 2018-07-15 15:40:17 --> Helper loaded: url_helper
INFO - 2018-07-15 15:40:17 --> Model Class Initialized
INFO - 2018-07-15 15:40:17 --> Final output sent to browser
DEBUG - 2018-07-15 15:40:17 --> Total execution time: 0.0660
ERROR - 2018-07-15 15:40:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:40:18 --> Config Class Initialized
INFO - 2018-07-15 15:40:18 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:40:18 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:40:18 --> Utf8 Class Initialized
INFO - 2018-07-15 15:40:18 --> URI Class Initialized
INFO - 2018-07-15 15:40:18 --> Router Class Initialized
INFO - 2018-07-15 15:40:18 --> Output Class Initialized
INFO - 2018-07-15 15:40:18 --> Security Class Initialized
DEBUG - 2018-07-15 15:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:40:18 --> Input Class Initialized
INFO - 2018-07-15 15:40:18 --> Language Class Initialized
INFO - 2018-07-15 15:40:18 --> Loader Class Initialized
INFO - 2018-07-15 15:40:18 --> Controller Class Initialized
INFO - 2018-07-15 15:40:18 --> Database Driver Class Initialized
INFO - 2018-07-15 15:40:18 --> Model Class Initialized
INFO - 2018-07-15 15:40:18 --> Helper loaded: url_helper
INFO - 2018-07-15 15:40:18 --> Model Class Initialized
INFO - 2018-07-15 15:40:18 --> Final output sent to browser
DEBUG - 2018-07-15 15:40:18 --> Total execution time: 0.0508
ERROR - 2018-07-15 15:40:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:40:23 --> Config Class Initialized
INFO - 2018-07-15 15:40:23 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:40:23 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:40:23 --> Utf8 Class Initialized
INFO - 2018-07-15 15:40:23 --> URI Class Initialized
INFO - 2018-07-15 15:40:23 --> Router Class Initialized
INFO - 2018-07-15 15:40:23 --> Output Class Initialized
INFO - 2018-07-15 15:40:23 --> Security Class Initialized
DEBUG - 2018-07-15 15:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:40:23 --> Input Class Initialized
INFO - 2018-07-15 15:40:23 --> Language Class Initialized
INFO - 2018-07-15 15:40:23 --> Loader Class Initialized
INFO - 2018-07-15 15:40:23 --> Controller Class Initialized
INFO - 2018-07-15 15:40:23 --> Database Driver Class Initialized
INFO - 2018-07-15 15:40:23 --> Model Class Initialized
INFO - 2018-07-15 15:40:23 --> Helper loaded: url_helper
INFO - 2018-07-15 15:40:23 --> Model Class Initialized
INFO - 2018-07-15 15:40:23 --> Final output sent to browser
DEBUG - 2018-07-15 15:40:23 --> Total execution time: 0.0560
ERROR - 2018-07-15 15:40:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:40:33 --> Config Class Initialized
INFO - 2018-07-15 15:40:33 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:40:33 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:40:33 --> Utf8 Class Initialized
INFO - 2018-07-15 15:40:33 --> URI Class Initialized
INFO - 2018-07-15 15:40:33 --> Router Class Initialized
INFO - 2018-07-15 15:40:33 --> Output Class Initialized
INFO - 2018-07-15 15:40:33 --> Security Class Initialized
DEBUG - 2018-07-15 15:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:40:33 --> Input Class Initialized
INFO - 2018-07-15 15:40:33 --> Language Class Initialized
INFO - 2018-07-15 15:40:33 --> Loader Class Initialized
INFO - 2018-07-15 15:40:33 --> Controller Class Initialized
INFO - 2018-07-15 15:40:33 --> Database Driver Class Initialized
INFO - 2018-07-15 15:40:33 --> Model Class Initialized
INFO - 2018-07-15 15:40:33 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:40:33 --> Model Class Initialized
INFO - 2018-07-15 15:40:33 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:40:33 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:40:33 --> Final output sent to browser
DEBUG - 2018-07-15 15:40:33 --> Total execution time: 0.0583
ERROR - 2018-07-15 15:40:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:40:34 --> Config Class Initialized
INFO - 2018-07-15 15:40:34 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:40:34 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:40:34 --> Utf8 Class Initialized
INFO - 2018-07-15 15:40:34 --> URI Class Initialized
INFO - 2018-07-15 15:40:34 --> Router Class Initialized
INFO - 2018-07-15 15:40:34 --> Output Class Initialized
INFO - 2018-07-15 15:40:34 --> Security Class Initialized
DEBUG - 2018-07-15 15:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:40:34 --> Input Class Initialized
INFO - 2018-07-15 15:40:34 --> Language Class Initialized
INFO - 2018-07-15 15:40:34 --> Loader Class Initialized
INFO - 2018-07-15 15:40:34 --> Controller Class Initialized
INFO - 2018-07-15 15:40:34 --> Database Driver Class Initialized
INFO - 2018-07-15 15:40:34 --> Model Class Initialized
INFO - 2018-07-15 15:40:34 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:40:34 --> Model Class Initialized
INFO - 2018-07-15 15:40:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:40:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:40:34 --> Final output sent to browser
DEBUG - 2018-07-15 15:40:34 --> Total execution time: 0.0566
ERROR - 2018-07-15 15:41:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:41:07 --> Config Class Initialized
INFO - 2018-07-15 15:41:07 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:41:07 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:41:07 --> Utf8 Class Initialized
INFO - 2018-07-15 15:41:07 --> URI Class Initialized
INFO - 2018-07-15 15:41:07 --> Router Class Initialized
INFO - 2018-07-15 15:41:07 --> Output Class Initialized
INFO - 2018-07-15 15:41:07 --> Security Class Initialized
DEBUG - 2018-07-15 15:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:41:07 --> Input Class Initialized
INFO - 2018-07-15 15:41:07 --> Language Class Initialized
INFO - 2018-07-15 15:41:07 --> Loader Class Initialized
INFO - 2018-07-15 15:41:07 --> Controller Class Initialized
INFO - 2018-07-15 15:41:07 --> Database Driver Class Initialized
INFO - 2018-07-15 15:41:07 --> Model Class Initialized
INFO - 2018-07-15 15:41:07 --> Helper loaded: url_helper
INFO - 2018-07-15 15:41:07 --> Model Class Initialized
INFO - 2018-07-15 15:41:07 --> Final output sent to browser
DEBUG - 2018-07-15 15:41:07 --> Total execution time: 0.0395
ERROR - 2018-07-15 15:41:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:41:08 --> Config Class Initialized
INFO - 2018-07-15 15:41:08 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:41:08 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:41:08 --> Utf8 Class Initialized
INFO - 2018-07-15 15:41:08 --> URI Class Initialized
INFO - 2018-07-15 15:41:08 --> Router Class Initialized
INFO - 2018-07-15 15:41:08 --> Output Class Initialized
INFO - 2018-07-15 15:41:08 --> Security Class Initialized
DEBUG - 2018-07-15 15:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:41:08 --> Input Class Initialized
INFO - 2018-07-15 15:41:08 --> Language Class Initialized
INFO - 2018-07-15 15:41:08 --> Loader Class Initialized
INFO - 2018-07-15 15:41:08 --> Controller Class Initialized
INFO - 2018-07-15 15:41:08 --> Database Driver Class Initialized
INFO - 2018-07-15 15:41:08 --> Model Class Initialized
INFO - 2018-07-15 15:41:08 --> Helper loaded: url_helper
INFO - 2018-07-15 15:41:08 --> Model Class Initialized
INFO - 2018-07-15 15:41:08 --> Final output sent to browser
DEBUG - 2018-07-15 15:41:08 --> Total execution time: 0.0606
ERROR - 2018-07-15 15:41:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:41:08 --> Config Class Initialized
INFO - 2018-07-15 15:41:08 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:41:08 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:41:08 --> Utf8 Class Initialized
INFO - 2018-07-15 15:41:08 --> URI Class Initialized
INFO - 2018-07-15 15:41:08 --> Router Class Initialized
INFO - 2018-07-15 15:41:08 --> Output Class Initialized
INFO - 2018-07-15 15:41:08 --> Security Class Initialized
DEBUG - 2018-07-15 15:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:41:08 --> Input Class Initialized
INFO - 2018-07-15 15:41:08 --> Language Class Initialized
INFO - 2018-07-15 15:41:08 --> Loader Class Initialized
INFO - 2018-07-15 15:41:08 --> Controller Class Initialized
INFO - 2018-07-15 15:41:08 --> Database Driver Class Initialized
INFO - 2018-07-15 15:41:08 --> Model Class Initialized
INFO - 2018-07-15 15:41:08 --> Helper loaded: url_helper
INFO - 2018-07-15 15:41:08 --> Model Class Initialized
INFO - 2018-07-15 15:41:08 --> Final output sent to browser
DEBUG - 2018-07-15 15:41:08 --> Total execution time: 0.0526
ERROR - 2018-07-15 15:41:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:41:45 --> Config Class Initialized
INFO - 2018-07-15 15:41:45 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:41:45 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:41:45 --> Utf8 Class Initialized
INFO - 2018-07-15 15:41:45 --> URI Class Initialized
INFO - 2018-07-15 15:41:45 --> Router Class Initialized
INFO - 2018-07-15 15:41:45 --> Output Class Initialized
INFO - 2018-07-15 15:41:45 --> Security Class Initialized
DEBUG - 2018-07-15 15:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:41:45 --> Input Class Initialized
INFO - 2018-07-15 15:41:45 --> Language Class Initialized
INFO - 2018-07-15 15:41:45 --> Loader Class Initialized
INFO - 2018-07-15 15:41:45 --> Controller Class Initialized
INFO - 2018-07-15 15:41:45 --> Database Driver Class Initialized
INFO - 2018-07-15 15:41:45 --> Model Class Initialized
INFO - 2018-07-15 15:41:45 --> Helper loaded: url_helper
INFO - 2018-07-15 15:41:45 --> Model Class Initialized
INFO - 2018-07-15 15:41:45 --> Final output sent to browser
DEBUG - 2018-07-15 15:41:45 --> Total execution time: 0.0525
ERROR - 2018-07-15 15:42:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:42:26 --> Config Class Initialized
INFO - 2018-07-15 15:42:26 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:42:26 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:42:26 --> Utf8 Class Initialized
INFO - 2018-07-15 15:42:26 --> URI Class Initialized
INFO - 2018-07-15 15:42:26 --> Router Class Initialized
INFO - 2018-07-15 15:42:26 --> Output Class Initialized
INFO - 2018-07-15 15:42:26 --> Security Class Initialized
DEBUG - 2018-07-15 15:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:42:26 --> Input Class Initialized
INFO - 2018-07-15 15:42:26 --> Language Class Initialized
INFO - 2018-07-15 15:42:26 --> Loader Class Initialized
INFO - 2018-07-15 15:42:26 --> Controller Class Initialized
INFO - 2018-07-15 15:42:26 --> Database Driver Class Initialized
INFO - 2018-07-15 15:42:26 --> Model Class Initialized
INFO - 2018-07-15 15:42:26 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:42:26 --> Model Class Initialized
INFO - 2018-07-15 15:42:26 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:42:26 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:42:26 --> Final output sent to browser
DEBUG - 2018-07-15 15:42:26 --> Total execution time: 0.0642
ERROR - 2018-07-15 15:42:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:42:37 --> Config Class Initialized
INFO - 2018-07-15 15:42:37 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:42:37 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:42:37 --> Utf8 Class Initialized
INFO - 2018-07-15 15:42:37 --> URI Class Initialized
INFO - 2018-07-15 15:42:37 --> Router Class Initialized
INFO - 2018-07-15 15:42:37 --> Output Class Initialized
INFO - 2018-07-15 15:42:37 --> Security Class Initialized
DEBUG - 2018-07-15 15:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:42:37 --> Input Class Initialized
INFO - 2018-07-15 15:42:37 --> Language Class Initialized
INFO - 2018-07-15 15:42:37 --> Loader Class Initialized
INFO - 2018-07-15 15:42:37 --> Controller Class Initialized
INFO - 2018-07-15 15:42:37 --> Database Driver Class Initialized
INFO - 2018-07-15 15:42:37 --> Model Class Initialized
INFO - 2018-07-15 15:42:37 --> Helper loaded: url_helper
INFO - 2018-07-15 15:42:37 --> Model Class Initialized
INFO - 2018-07-15 15:42:37 --> Final output sent to browser
DEBUG - 2018-07-15 15:42:37 --> Total execution time: 0.0697
ERROR - 2018-07-15 15:42:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:42:38 --> Config Class Initialized
INFO - 2018-07-15 15:42:38 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:42:38 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:42:38 --> Utf8 Class Initialized
INFO - 2018-07-15 15:42:38 --> URI Class Initialized
INFO - 2018-07-15 15:42:38 --> Router Class Initialized
INFO - 2018-07-15 15:42:38 --> Output Class Initialized
INFO - 2018-07-15 15:42:38 --> Security Class Initialized
DEBUG - 2018-07-15 15:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:42:38 --> Input Class Initialized
INFO - 2018-07-15 15:42:38 --> Language Class Initialized
INFO - 2018-07-15 15:42:38 --> Loader Class Initialized
INFO - 2018-07-15 15:42:38 --> Controller Class Initialized
INFO - 2018-07-15 15:42:38 --> Database Driver Class Initialized
INFO - 2018-07-15 15:42:38 --> Model Class Initialized
INFO - 2018-07-15 15:42:38 --> Helper loaded: url_helper
INFO - 2018-07-15 15:42:38 --> Model Class Initialized
INFO - 2018-07-15 15:42:38 --> Final output sent to browser
DEBUG - 2018-07-15 15:42:38 --> Total execution time: 0.0463
ERROR - 2018-07-15 15:42:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:42:38 --> Config Class Initialized
INFO - 2018-07-15 15:42:38 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:42:38 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:42:38 --> Utf8 Class Initialized
INFO - 2018-07-15 15:42:38 --> URI Class Initialized
INFO - 2018-07-15 15:42:38 --> Router Class Initialized
INFO - 2018-07-15 15:42:38 --> Output Class Initialized
INFO - 2018-07-15 15:42:38 --> Security Class Initialized
DEBUG - 2018-07-15 15:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:42:38 --> Input Class Initialized
INFO - 2018-07-15 15:42:38 --> Language Class Initialized
INFO - 2018-07-15 15:42:38 --> Loader Class Initialized
INFO - 2018-07-15 15:42:38 --> Controller Class Initialized
INFO - 2018-07-15 15:42:38 --> Database Driver Class Initialized
INFO - 2018-07-15 15:42:38 --> Model Class Initialized
INFO - 2018-07-15 15:42:38 --> Helper loaded: url_helper
INFO - 2018-07-15 15:42:38 --> Model Class Initialized
INFO - 2018-07-15 15:42:38 --> Final output sent to browser
DEBUG - 2018-07-15 15:42:38 --> Total execution time: 0.0698
ERROR - 2018-07-15 15:43:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:43:19 --> Config Class Initialized
INFO - 2018-07-15 15:43:19 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:43:19 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:43:19 --> Utf8 Class Initialized
INFO - 2018-07-15 15:43:19 --> URI Class Initialized
INFO - 2018-07-15 15:43:19 --> Router Class Initialized
INFO - 2018-07-15 15:43:19 --> Output Class Initialized
INFO - 2018-07-15 15:43:19 --> Security Class Initialized
DEBUG - 2018-07-15 15:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:43:19 --> Input Class Initialized
INFO - 2018-07-15 15:43:19 --> Language Class Initialized
INFO - 2018-07-15 15:43:19 --> Loader Class Initialized
INFO - 2018-07-15 15:43:19 --> Controller Class Initialized
INFO - 2018-07-15 15:43:19 --> Database Driver Class Initialized
INFO - 2018-07-15 15:43:19 --> Model Class Initialized
INFO - 2018-07-15 15:43:19 --> Helper loaded: url_helper
INFO - 2018-07-15 15:43:19 --> Model Class Initialized
INFO - 2018-07-15 15:43:19 --> Final output sent to browser
DEBUG - 2018-07-15 15:43:19 --> Total execution time: 0.0601
ERROR - 2018-07-15 15:43:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:43:19 --> Config Class Initialized
INFO - 2018-07-15 15:43:19 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:43:19 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:43:19 --> Utf8 Class Initialized
INFO - 2018-07-15 15:43:19 --> URI Class Initialized
INFO - 2018-07-15 15:43:19 --> Router Class Initialized
INFO - 2018-07-15 15:43:19 --> Output Class Initialized
INFO - 2018-07-15 15:43:19 --> Security Class Initialized
DEBUG - 2018-07-15 15:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:43:19 --> Input Class Initialized
INFO - 2018-07-15 15:43:19 --> Language Class Initialized
INFO - 2018-07-15 15:43:19 --> Loader Class Initialized
INFO - 2018-07-15 15:43:19 --> Controller Class Initialized
INFO - 2018-07-15 15:43:19 --> Database Driver Class Initialized
INFO - 2018-07-15 15:43:19 --> Model Class Initialized
INFO - 2018-07-15 15:43:19 --> Helper loaded: url_helper
INFO - 2018-07-15 15:43:19 --> Model Class Initialized
INFO - 2018-07-15 15:43:19 --> Final output sent to browser
DEBUG - 2018-07-15 15:43:19 --> Total execution time: 0.0706
ERROR - 2018-07-15 15:43:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:43:19 --> Config Class Initialized
INFO - 2018-07-15 15:43:19 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:43:19 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:43:19 --> Utf8 Class Initialized
INFO - 2018-07-15 15:43:19 --> URI Class Initialized
INFO - 2018-07-15 15:43:19 --> Router Class Initialized
INFO - 2018-07-15 15:43:19 --> Output Class Initialized
INFO - 2018-07-15 15:43:19 --> Security Class Initialized
DEBUG - 2018-07-15 15:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:43:19 --> Input Class Initialized
INFO - 2018-07-15 15:43:19 --> Language Class Initialized
INFO - 2018-07-15 15:43:19 --> Loader Class Initialized
INFO - 2018-07-15 15:43:19 --> Controller Class Initialized
INFO - 2018-07-15 15:43:19 --> Database Driver Class Initialized
INFO - 2018-07-15 15:43:19 --> Model Class Initialized
INFO - 2018-07-15 15:43:19 --> Helper loaded: url_helper
INFO - 2018-07-15 15:43:19 --> Model Class Initialized
INFO - 2018-07-15 15:43:19 --> Final output sent to browser
DEBUG - 2018-07-15 15:43:19 --> Total execution time: 0.0550
ERROR - 2018-07-15 15:43:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:43:32 --> Config Class Initialized
INFO - 2018-07-15 15:43:32 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:43:32 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:43:32 --> Utf8 Class Initialized
INFO - 2018-07-15 15:43:32 --> URI Class Initialized
INFO - 2018-07-15 15:43:32 --> Router Class Initialized
INFO - 2018-07-15 15:43:32 --> Output Class Initialized
INFO - 2018-07-15 15:43:32 --> Security Class Initialized
DEBUG - 2018-07-15 15:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:43:32 --> Input Class Initialized
INFO - 2018-07-15 15:43:32 --> Language Class Initialized
INFO - 2018-07-15 15:43:32 --> Loader Class Initialized
INFO - 2018-07-15 15:43:32 --> Controller Class Initialized
INFO - 2018-07-15 15:43:32 --> Database Driver Class Initialized
INFO - 2018-07-15 15:43:32 --> Model Class Initialized
INFO - 2018-07-15 15:43:32 --> Helper loaded: url_helper
INFO - 2018-07-15 15:43:32 --> Model Class Initialized
INFO - 2018-07-15 15:43:32 --> Final output sent to browser
DEBUG - 2018-07-15 15:43:32 --> Total execution time: 0.1208
ERROR - 2018-07-15 15:43:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:43:43 --> Config Class Initialized
INFO - 2018-07-15 15:43:43 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:43:43 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:43:43 --> Utf8 Class Initialized
INFO - 2018-07-15 15:43:43 --> URI Class Initialized
INFO - 2018-07-15 15:43:43 --> Router Class Initialized
INFO - 2018-07-15 15:43:43 --> Output Class Initialized
INFO - 2018-07-15 15:43:43 --> Security Class Initialized
DEBUG - 2018-07-15 15:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:43:43 --> Input Class Initialized
INFO - 2018-07-15 15:43:43 --> Language Class Initialized
INFO - 2018-07-15 15:43:43 --> Loader Class Initialized
INFO - 2018-07-15 15:43:43 --> Controller Class Initialized
INFO - 2018-07-15 15:43:43 --> Database Driver Class Initialized
INFO - 2018-07-15 15:43:43 --> Model Class Initialized
INFO - 2018-07-15 15:43:43 --> Helper loaded: url_helper
INFO - 2018-07-15 15:43:43 --> Model Class Initialized
INFO - 2018-07-15 15:43:43 --> Final output sent to browser
DEBUG - 2018-07-15 15:43:43 --> Total execution time: 0.0435
ERROR - 2018-07-15 15:43:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:43:44 --> Config Class Initialized
INFO - 2018-07-15 15:43:44 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:43:44 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:43:44 --> Utf8 Class Initialized
INFO - 2018-07-15 15:43:44 --> URI Class Initialized
INFO - 2018-07-15 15:43:44 --> Router Class Initialized
INFO - 2018-07-15 15:43:44 --> Output Class Initialized
INFO - 2018-07-15 15:43:44 --> Security Class Initialized
DEBUG - 2018-07-15 15:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:43:44 --> Input Class Initialized
INFO - 2018-07-15 15:43:44 --> Language Class Initialized
INFO - 2018-07-15 15:43:44 --> Loader Class Initialized
INFO - 2018-07-15 15:43:44 --> Controller Class Initialized
INFO - 2018-07-15 15:43:44 --> Database Driver Class Initialized
INFO - 2018-07-15 15:43:44 --> Model Class Initialized
INFO - 2018-07-15 15:43:44 --> Helper loaded: url_helper
INFO - 2018-07-15 15:43:44 --> Model Class Initialized
INFO - 2018-07-15 15:43:44 --> Final output sent to browser
DEBUG - 2018-07-15 15:43:44 --> Total execution time: 0.0434
ERROR - 2018-07-15 15:43:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:43:46 --> Config Class Initialized
INFO - 2018-07-15 15:43:46 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:43:46 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:43:46 --> Utf8 Class Initialized
INFO - 2018-07-15 15:43:46 --> URI Class Initialized
INFO - 2018-07-15 15:43:46 --> Router Class Initialized
INFO - 2018-07-15 15:43:46 --> Output Class Initialized
INFO - 2018-07-15 15:43:46 --> Security Class Initialized
DEBUG - 2018-07-15 15:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:43:46 --> Input Class Initialized
INFO - 2018-07-15 15:43:46 --> Language Class Initialized
INFO - 2018-07-15 15:43:46 --> Loader Class Initialized
INFO - 2018-07-15 15:43:46 --> Controller Class Initialized
INFO - 2018-07-15 15:43:46 --> Database Driver Class Initialized
INFO - 2018-07-15 15:43:46 --> Model Class Initialized
INFO - 2018-07-15 15:43:46 --> Helper loaded: url_helper
INFO - 2018-07-15 15:43:46 --> Model Class Initialized
INFO - 2018-07-15 15:43:46 --> Final output sent to browser
DEBUG - 2018-07-15 15:43:46 --> Total execution time: 0.0396
ERROR - 2018-07-15 15:43:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:43:49 --> Config Class Initialized
INFO - 2018-07-15 15:43:49 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:43:49 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:43:49 --> Utf8 Class Initialized
INFO - 2018-07-15 15:43:49 --> URI Class Initialized
INFO - 2018-07-15 15:43:49 --> Router Class Initialized
INFO - 2018-07-15 15:43:49 --> Output Class Initialized
INFO - 2018-07-15 15:43:49 --> Security Class Initialized
DEBUG - 2018-07-15 15:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:43:49 --> Input Class Initialized
INFO - 2018-07-15 15:43:49 --> Language Class Initialized
INFO - 2018-07-15 15:43:49 --> Loader Class Initialized
INFO - 2018-07-15 15:43:49 --> Controller Class Initialized
INFO - 2018-07-15 15:43:49 --> Database Driver Class Initialized
INFO - 2018-07-15 15:43:49 --> Model Class Initialized
INFO - 2018-07-15 15:43:49 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:43:49 --> Model Class Initialized
INFO - 2018-07-15 15:43:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:43:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:43:49 --> Final output sent to browser
DEBUG - 2018-07-15 15:43:49 --> Total execution time: 0.0571
ERROR - 2018-07-15 15:43:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:43:52 --> Config Class Initialized
INFO - 2018-07-15 15:43:52 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:43:52 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:43:52 --> Utf8 Class Initialized
INFO - 2018-07-15 15:43:52 --> URI Class Initialized
INFO - 2018-07-15 15:43:52 --> Router Class Initialized
INFO - 2018-07-15 15:43:52 --> Output Class Initialized
INFO - 2018-07-15 15:43:52 --> Security Class Initialized
DEBUG - 2018-07-15 15:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:43:52 --> Input Class Initialized
INFO - 2018-07-15 15:43:52 --> Language Class Initialized
INFO - 2018-07-15 15:43:52 --> Loader Class Initialized
INFO - 2018-07-15 15:43:52 --> Controller Class Initialized
INFO - 2018-07-15 15:43:52 --> Database Driver Class Initialized
INFO - 2018-07-15 15:43:52 --> Model Class Initialized
INFO - 2018-07-15 15:43:52 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:43:52 --> Model Class Initialized
INFO - 2018-07-15 15:43:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:43:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-15 15:43:52 --> Final output sent to browser
DEBUG - 2018-07-15 15:43:52 --> Total execution time: 0.0565
ERROR - 2018-07-15 15:44:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:44:00 --> Config Class Initialized
INFO - 2018-07-15 15:44:00 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:44:00 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:44:00 --> Utf8 Class Initialized
INFO - 2018-07-15 15:44:00 --> URI Class Initialized
INFO - 2018-07-15 15:44:00 --> Router Class Initialized
INFO - 2018-07-15 15:44:00 --> Output Class Initialized
INFO - 2018-07-15 15:44:00 --> Security Class Initialized
DEBUG - 2018-07-15 15:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:44:00 --> Input Class Initialized
INFO - 2018-07-15 15:44:00 --> Language Class Initialized
INFO - 2018-07-15 15:44:00 --> Loader Class Initialized
INFO - 2018-07-15 15:44:00 --> Controller Class Initialized
INFO - 2018-07-15 15:44:00 --> Database Driver Class Initialized
INFO - 2018-07-15 15:44:00 --> Model Class Initialized
INFO - 2018-07-15 15:44:00 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:44:00 --> Model Class Initialized
INFO - 2018-07-15 15:44:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:44:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:44:00 --> Final output sent to browser
DEBUG - 2018-07-15 15:44:00 --> Total execution time: 0.0709
ERROR - 2018-07-15 15:44:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:44:01 --> Config Class Initialized
INFO - 2018-07-15 15:44:01 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:44:01 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:44:01 --> Utf8 Class Initialized
INFO - 2018-07-15 15:44:01 --> URI Class Initialized
INFO - 2018-07-15 15:44:01 --> Router Class Initialized
INFO - 2018-07-15 15:44:01 --> Output Class Initialized
INFO - 2018-07-15 15:44:01 --> Security Class Initialized
DEBUG - 2018-07-15 15:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:44:01 --> Input Class Initialized
INFO - 2018-07-15 15:44:01 --> Language Class Initialized
INFO - 2018-07-15 15:44:01 --> Loader Class Initialized
INFO - 2018-07-15 15:44:01 --> Controller Class Initialized
INFO - 2018-07-15 15:44:01 --> Database Driver Class Initialized
INFO - 2018-07-15 15:44:01 --> Model Class Initialized
INFO - 2018-07-15 15:44:01 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:44:01 --> Model Class Initialized
ERROR - 2018-07-15 15:44:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:44:01 --> Config Class Initialized
INFO - 2018-07-15 15:44:01 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:44:01 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:44:01 --> Utf8 Class Initialized
INFO - 2018-07-15 15:44:01 --> URI Class Initialized
INFO - 2018-07-15 15:44:01 --> Router Class Initialized
INFO - 2018-07-15 15:44:01 --> Output Class Initialized
INFO - 2018-07-15 15:44:01 --> Security Class Initialized
DEBUG - 2018-07-15 15:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:44:01 --> Input Class Initialized
INFO - 2018-07-15 15:44:01 --> Language Class Initialized
INFO - 2018-07-15 15:44:01 --> Loader Class Initialized
INFO - 2018-07-15 15:44:01 --> Controller Class Initialized
INFO - 2018-07-15 15:44:01 --> Database Driver Class Initialized
INFO - 2018-07-15 15:44:01 --> Model Class Initialized
INFO - 2018-07-15 15:44:01 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:44:01 --> Model Class Initialized
INFO - 2018-07-15 15:44:01 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:44:01 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:44:01 --> Final output sent to browser
DEBUG - 2018-07-15 15:44:01 --> Total execution time: 0.0461
ERROR - 2018-07-15 15:44:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:44:03 --> Config Class Initialized
INFO - 2018-07-15 15:44:03 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:44:03 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:44:03 --> Utf8 Class Initialized
INFO - 2018-07-15 15:44:03 --> URI Class Initialized
INFO - 2018-07-15 15:44:03 --> Router Class Initialized
INFO - 2018-07-15 15:44:03 --> Output Class Initialized
INFO - 2018-07-15 15:44:03 --> Security Class Initialized
DEBUG - 2018-07-15 15:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:44:03 --> Input Class Initialized
INFO - 2018-07-15 15:44:03 --> Language Class Initialized
INFO - 2018-07-15 15:44:03 --> Loader Class Initialized
INFO - 2018-07-15 15:44:03 --> Controller Class Initialized
INFO - 2018-07-15 15:44:03 --> Database Driver Class Initialized
INFO - 2018-07-15 15:44:03 --> Model Class Initialized
INFO - 2018-07-15 15:44:03 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:44:03 --> Model Class Initialized
INFO - 2018-07-15 15:44:03 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:44:03 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-15 15:44:03 --> Final output sent to browser
DEBUG - 2018-07-15 15:44:03 --> Total execution time: 0.0928
ERROR - 2018-07-15 15:44:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:44:08 --> Config Class Initialized
INFO - 2018-07-15 15:44:08 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:44:08 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:44:08 --> Utf8 Class Initialized
INFO - 2018-07-15 15:44:08 --> URI Class Initialized
INFO - 2018-07-15 15:44:08 --> Router Class Initialized
INFO - 2018-07-15 15:44:08 --> Output Class Initialized
INFO - 2018-07-15 15:44:08 --> Security Class Initialized
DEBUG - 2018-07-15 15:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:44:08 --> Input Class Initialized
INFO - 2018-07-15 15:44:08 --> Language Class Initialized
INFO - 2018-07-15 15:44:08 --> Loader Class Initialized
INFO - 2018-07-15 15:44:08 --> Controller Class Initialized
INFO - 2018-07-15 15:44:08 --> Database Driver Class Initialized
INFO - 2018-07-15 15:44:08 --> Model Class Initialized
INFO - 2018-07-15 15:44:08 --> Helper loaded: url_helper
INFO - 2018-07-15 15:44:08 --> Model Class Initialized
INFO - 2018-07-15 15:44:08 --> Final output sent to browser
DEBUG - 2018-07-15 15:44:08 --> Total execution time: 0.0903
ERROR - 2018-07-15 15:45:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:45:49 --> Config Class Initialized
INFO - 2018-07-15 15:45:49 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:45:49 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:45:49 --> Utf8 Class Initialized
INFO - 2018-07-15 15:45:49 --> URI Class Initialized
INFO - 2018-07-15 15:45:49 --> Router Class Initialized
INFO - 2018-07-15 15:45:49 --> Output Class Initialized
INFO - 2018-07-15 15:45:49 --> Security Class Initialized
DEBUG - 2018-07-15 15:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:45:49 --> Input Class Initialized
INFO - 2018-07-15 15:45:49 --> Language Class Initialized
INFO - 2018-07-15 15:45:49 --> Loader Class Initialized
INFO - 2018-07-15 15:45:49 --> Controller Class Initialized
INFO - 2018-07-15 15:45:49 --> Database Driver Class Initialized
INFO - 2018-07-15 15:45:49 --> Model Class Initialized
INFO - 2018-07-15 15:45:49 --> Helper loaded: url_helper
INFO - 2018-07-15 15:45:49 --> Model Class Initialized
INFO - 2018-07-15 15:45:49 --> Final output sent to browser
DEBUG - 2018-07-15 15:45:49 --> Total execution time: 0.0542
ERROR - 2018-07-15 15:45:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:45:49 --> Config Class Initialized
INFO - 2018-07-15 15:45:49 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:45:49 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:45:49 --> Utf8 Class Initialized
INFO - 2018-07-15 15:45:49 --> URI Class Initialized
INFO - 2018-07-15 15:45:49 --> Router Class Initialized
INFO - 2018-07-15 15:45:49 --> Output Class Initialized
INFO - 2018-07-15 15:45:49 --> Security Class Initialized
DEBUG - 2018-07-15 15:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:45:49 --> Input Class Initialized
INFO - 2018-07-15 15:45:49 --> Language Class Initialized
INFO - 2018-07-15 15:45:49 --> Loader Class Initialized
INFO - 2018-07-15 15:45:49 --> Controller Class Initialized
INFO - 2018-07-15 15:45:49 --> Database Driver Class Initialized
INFO - 2018-07-15 15:45:49 --> Model Class Initialized
INFO - 2018-07-15 15:45:49 --> Helper loaded: url_helper
INFO - 2018-07-15 15:45:49 --> Model Class Initialized
INFO - 2018-07-15 15:45:49 --> Final output sent to browser
DEBUG - 2018-07-15 15:45:49 --> Total execution time: 0.0824
ERROR - 2018-07-15 15:45:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:45:49 --> Config Class Initialized
INFO - 2018-07-15 15:45:49 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:45:49 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:45:49 --> Utf8 Class Initialized
INFO - 2018-07-15 15:45:49 --> URI Class Initialized
INFO - 2018-07-15 15:45:49 --> Router Class Initialized
INFO - 2018-07-15 15:45:49 --> Output Class Initialized
INFO - 2018-07-15 15:45:49 --> Security Class Initialized
DEBUG - 2018-07-15 15:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:45:49 --> Input Class Initialized
INFO - 2018-07-15 15:45:49 --> Language Class Initialized
INFO - 2018-07-15 15:45:49 --> Loader Class Initialized
INFO - 2018-07-15 15:45:49 --> Controller Class Initialized
INFO - 2018-07-15 15:45:49 --> Database Driver Class Initialized
INFO - 2018-07-15 15:45:49 --> Model Class Initialized
INFO - 2018-07-15 15:45:49 --> Helper loaded: url_helper
INFO - 2018-07-15 15:45:49 --> Model Class Initialized
INFO - 2018-07-15 15:45:49 --> Final output sent to browser
DEBUG - 2018-07-15 15:45:49 --> Total execution time: 0.0398
ERROR - 2018-07-15 15:46:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:46:36 --> Config Class Initialized
INFO - 2018-07-15 15:46:36 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:46:36 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:46:36 --> Utf8 Class Initialized
INFO - 2018-07-15 15:46:36 --> URI Class Initialized
INFO - 2018-07-15 15:46:36 --> Router Class Initialized
INFO - 2018-07-15 15:46:36 --> Output Class Initialized
INFO - 2018-07-15 15:46:36 --> Security Class Initialized
DEBUG - 2018-07-15 15:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:46:36 --> Input Class Initialized
INFO - 2018-07-15 15:46:36 --> Language Class Initialized
INFO - 2018-07-15 15:46:36 --> Loader Class Initialized
INFO - 2018-07-15 15:46:36 --> Controller Class Initialized
INFO - 2018-07-15 15:46:36 --> Database Driver Class Initialized
INFO - 2018-07-15 15:46:36 --> Model Class Initialized
INFO - 2018-07-15 15:46:36 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:46:36 --> Model Class Initialized
INFO - 2018-07-15 15:46:36 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:46:36 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:46:36 --> Final output sent to browser
DEBUG - 2018-07-15 15:46:36 --> Total execution time: 0.0553
ERROR - 2018-07-15 15:46:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:46:50 --> Config Class Initialized
INFO - 2018-07-15 15:46:50 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:46:50 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:46:50 --> Utf8 Class Initialized
INFO - 2018-07-15 15:46:50 --> URI Class Initialized
INFO - 2018-07-15 15:46:50 --> Router Class Initialized
INFO - 2018-07-15 15:46:50 --> Output Class Initialized
INFO - 2018-07-15 15:46:50 --> Security Class Initialized
DEBUG - 2018-07-15 15:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:46:50 --> Input Class Initialized
INFO - 2018-07-15 15:46:50 --> Language Class Initialized
INFO - 2018-07-15 15:46:50 --> Loader Class Initialized
INFO - 2018-07-15 15:46:50 --> Controller Class Initialized
INFO - 2018-07-15 15:46:50 --> Database Driver Class Initialized
INFO - 2018-07-15 15:46:50 --> Model Class Initialized
INFO - 2018-07-15 15:46:50 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:46:50 --> Model Class Initialized
INFO - 2018-07-15 15:46:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:46:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:46:50 --> Final output sent to browser
DEBUG - 2018-07-15 15:46:50 --> Total execution time: 0.0567
ERROR - 2018-07-15 15:46:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:46:56 --> Config Class Initialized
INFO - 2018-07-15 15:46:56 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:46:56 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:46:56 --> Utf8 Class Initialized
INFO - 2018-07-15 15:46:56 --> URI Class Initialized
INFO - 2018-07-15 15:46:56 --> Router Class Initialized
INFO - 2018-07-15 15:46:56 --> Output Class Initialized
INFO - 2018-07-15 15:46:56 --> Security Class Initialized
DEBUG - 2018-07-15 15:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:46:56 --> Input Class Initialized
INFO - 2018-07-15 15:46:56 --> Language Class Initialized
INFO - 2018-07-15 15:46:56 --> Loader Class Initialized
INFO - 2018-07-15 15:46:56 --> Controller Class Initialized
INFO - 2018-07-15 15:46:56 --> Database Driver Class Initialized
INFO - 2018-07-15 15:46:56 --> Model Class Initialized
INFO - 2018-07-15 15:46:56 --> Helper loaded: url_helper
INFO - 2018-07-15 15:46:56 --> Model Class Initialized
INFO - 2018-07-15 15:46:56 --> Final output sent to browser
DEBUG - 2018-07-15 15:46:56 --> Total execution time: 0.0448
ERROR - 2018-07-15 15:46:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:46:56 --> Config Class Initialized
INFO - 2018-07-15 15:46:56 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:46:56 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:46:56 --> Utf8 Class Initialized
INFO - 2018-07-15 15:46:56 --> URI Class Initialized
INFO - 2018-07-15 15:46:56 --> Router Class Initialized
INFO - 2018-07-15 15:46:56 --> Output Class Initialized
INFO - 2018-07-15 15:46:56 --> Security Class Initialized
DEBUG - 2018-07-15 15:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:46:56 --> Input Class Initialized
INFO - 2018-07-15 15:46:56 --> Language Class Initialized
INFO - 2018-07-15 15:46:56 --> Loader Class Initialized
INFO - 2018-07-15 15:46:56 --> Controller Class Initialized
INFO - 2018-07-15 15:46:56 --> Database Driver Class Initialized
INFO - 2018-07-15 15:46:56 --> Model Class Initialized
INFO - 2018-07-15 15:46:56 --> Helper loaded: url_helper
INFO - 2018-07-15 15:46:56 --> Model Class Initialized
INFO - 2018-07-15 15:46:56 --> Final output sent to browser
DEBUG - 2018-07-15 15:46:56 --> Total execution time: 0.0474
ERROR - 2018-07-15 15:46:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:46:56 --> Config Class Initialized
INFO - 2018-07-15 15:46:56 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:46:56 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:46:56 --> Utf8 Class Initialized
INFO - 2018-07-15 15:46:56 --> URI Class Initialized
INFO - 2018-07-15 15:46:56 --> Router Class Initialized
INFO - 2018-07-15 15:46:56 --> Output Class Initialized
INFO - 2018-07-15 15:46:56 --> Security Class Initialized
DEBUG - 2018-07-15 15:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:46:56 --> Input Class Initialized
INFO - 2018-07-15 15:46:56 --> Language Class Initialized
INFO - 2018-07-15 15:46:56 --> Loader Class Initialized
INFO - 2018-07-15 15:46:56 --> Controller Class Initialized
INFO - 2018-07-15 15:46:56 --> Database Driver Class Initialized
INFO - 2018-07-15 15:46:56 --> Model Class Initialized
INFO - 2018-07-15 15:46:56 --> Helper loaded: url_helper
INFO - 2018-07-15 15:46:56 --> Model Class Initialized
INFO - 2018-07-15 15:46:56 --> Final output sent to browser
DEBUG - 2018-07-15 15:46:56 --> Total execution time: 0.0354
ERROR - 2018-07-15 15:47:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:47:02 --> Config Class Initialized
INFO - 2018-07-15 15:47:02 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:47:02 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:47:02 --> Utf8 Class Initialized
INFO - 2018-07-15 15:47:02 --> URI Class Initialized
INFO - 2018-07-15 15:47:02 --> Router Class Initialized
INFO - 2018-07-15 15:47:02 --> Output Class Initialized
INFO - 2018-07-15 15:47:02 --> Security Class Initialized
DEBUG - 2018-07-15 15:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:47:02 --> Input Class Initialized
INFO - 2018-07-15 15:47:02 --> Language Class Initialized
INFO - 2018-07-15 15:47:02 --> Loader Class Initialized
INFO - 2018-07-15 15:47:02 --> Controller Class Initialized
INFO - 2018-07-15 15:47:02 --> Database Driver Class Initialized
INFO - 2018-07-15 15:47:02 --> Model Class Initialized
INFO - 2018-07-15 15:47:02 --> Helper loaded: url_helper
INFO - 2018-07-15 15:47:02 --> Model Class Initialized
INFO - 2018-07-15 15:47:02 --> Final output sent to browser
DEBUG - 2018-07-15 15:47:02 --> Total execution time: 0.1584
ERROR - 2018-07-15 15:47:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:47:03 --> Config Class Initialized
INFO - 2018-07-15 15:47:03 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:47:03 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:47:03 --> Utf8 Class Initialized
INFO - 2018-07-15 15:47:03 --> URI Class Initialized
INFO - 2018-07-15 15:47:03 --> Router Class Initialized
INFO - 2018-07-15 15:47:03 --> Output Class Initialized
INFO - 2018-07-15 15:47:03 --> Security Class Initialized
DEBUG - 2018-07-15 15:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:47:03 --> Input Class Initialized
INFO - 2018-07-15 15:47:03 --> Language Class Initialized
INFO - 2018-07-15 15:47:03 --> Loader Class Initialized
INFO - 2018-07-15 15:47:03 --> Controller Class Initialized
INFO - 2018-07-15 15:47:03 --> Database Driver Class Initialized
INFO - 2018-07-15 15:47:03 --> Model Class Initialized
INFO - 2018-07-15 15:47:03 --> Helper loaded: url_helper
INFO - 2018-07-15 15:47:03 --> Model Class Initialized
INFO - 2018-07-15 15:47:03 --> Final output sent to browser
DEBUG - 2018-07-15 15:47:03 --> Total execution time: 0.1733
ERROR - 2018-07-15 15:47:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:47:13 --> Config Class Initialized
INFO - 2018-07-15 15:47:13 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:47:13 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:47:13 --> Utf8 Class Initialized
INFO - 2018-07-15 15:47:13 --> URI Class Initialized
INFO - 2018-07-15 15:47:13 --> Router Class Initialized
INFO - 2018-07-15 15:47:13 --> Output Class Initialized
INFO - 2018-07-15 15:47:13 --> Security Class Initialized
DEBUG - 2018-07-15 15:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:47:13 --> Input Class Initialized
INFO - 2018-07-15 15:47:13 --> Language Class Initialized
INFO - 2018-07-15 15:47:13 --> Loader Class Initialized
INFO - 2018-07-15 15:47:13 --> Controller Class Initialized
INFO - 2018-07-15 15:47:13 --> Database Driver Class Initialized
INFO - 2018-07-15 15:47:13 --> Model Class Initialized
INFO - 2018-07-15 15:47:13 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:47:13 --> Model Class Initialized
INFO - 2018-07-15 15:47:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:47:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:47:13 --> Final output sent to browser
DEBUG - 2018-07-15 15:47:13 --> Total execution time: 0.0562
ERROR - 2018-07-15 15:47:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:47:16 --> Config Class Initialized
INFO - 2018-07-15 15:47:16 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:47:16 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:47:16 --> Utf8 Class Initialized
INFO - 2018-07-15 15:47:16 --> URI Class Initialized
INFO - 2018-07-15 15:47:16 --> Router Class Initialized
INFO - 2018-07-15 15:47:16 --> Output Class Initialized
INFO - 2018-07-15 15:47:16 --> Security Class Initialized
DEBUG - 2018-07-15 15:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:47:16 --> Input Class Initialized
INFO - 2018-07-15 15:47:16 --> Language Class Initialized
INFO - 2018-07-15 15:47:16 --> Loader Class Initialized
INFO - 2018-07-15 15:47:16 --> Controller Class Initialized
INFO - 2018-07-15 15:47:16 --> Database Driver Class Initialized
INFO - 2018-07-15 15:47:16 --> Model Class Initialized
INFO - 2018-07-15 15:47:16 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:47:16 --> Model Class Initialized
INFO - 2018-07-15 15:47:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:47:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-15 15:47:16 --> Final output sent to browser
DEBUG - 2018-07-15 15:47:16 --> Total execution time: 0.0492
ERROR - 2018-07-15 15:47:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:47:19 --> Config Class Initialized
INFO - 2018-07-15 15:47:19 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:47:19 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:47:19 --> Utf8 Class Initialized
INFO - 2018-07-15 15:47:19 --> URI Class Initialized
INFO - 2018-07-15 15:47:19 --> Router Class Initialized
INFO - 2018-07-15 15:47:19 --> Output Class Initialized
INFO - 2018-07-15 15:47:19 --> Security Class Initialized
DEBUG - 2018-07-15 15:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:47:19 --> Input Class Initialized
INFO - 2018-07-15 15:47:19 --> Language Class Initialized
INFO - 2018-07-15 15:47:19 --> Loader Class Initialized
INFO - 2018-07-15 15:47:19 --> Controller Class Initialized
INFO - 2018-07-15 15:47:19 --> Database Driver Class Initialized
INFO - 2018-07-15 15:47:19 --> Model Class Initialized
INFO - 2018-07-15 15:47:19 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:47:19 --> Model Class Initialized
INFO - 2018-07-15 15:47:19 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:47:19 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:47:19 --> Final output sent to browser
DEBUG - 2018-07-15 15:47:19 --> Total execution time: 0.0517
ERROR - 2018-07-15 15:47:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:47:21 --> Config Class Initialized
INFO - 2018-07-15 15:47:21 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:47:21 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:47:21 --> Utf8 Class Initialized
INFO - 2018-07-15 15:47:21 --> URI Class Initialized
INFO - 2018-07-15 15:47:21 --> Router Class Initialized
INFO - 2018-07-15 15:47:21 --> Output Class Initialized
INFO - 2018-07-15 15:47:21 --> Security Class Initialized
DEBUG - 2018-07-15 15:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:47:21 --> Input Class Initialized
INFO - 2018-07-15 15:47:21 --> Language Class Initialized
INFO - 2018-07-15 15:47:21 --> Loader Class Initialized
INFO - 2018-07-15 15:47:21 --> Controller Class Initialized
INFO - 2018-07-15 15:47:21 --> Database Driver Class Initialized
INFO - 2018-07-15 15:47:21 --> Model Class Initialized
INFO - 2018-07-15 15:47:21 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:47:21 --> Model Class Initialized
ERROR - 2018-07-15 15:47:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:47:21 --> Config Class Initialized
INFO - 2018-07-15 15:47:21 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:47:21 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:47:21 --> Utf8 Class Initialized
INFO - 2018-07-15 15:47:21 --> URI Class Initialized
INFO - 2018-07-15 15:47:22 --> Router Class Initialized
INFO - 2018-07-15 15:47:22 --> Output Class Initialized
INFO - 2018-07-15 15:47:22 --> Security Class Initialized
DEBUG - 2018-07-15 15:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:47:22 --> Input Class Initialized
INFO - 2018-07-15 15:47:22 --> Language Class Initialized
INFO - 2018-07-15 15:47:22 --> Loader Class Initialized
INFO - 2018-07-15 15:47:22 --> Controller Class Initialized
INFO - 2018-07-15 15:47:22 --> Database Driver Class Initialized
INFO - 2018-07-15 15:47:22 --> Model Class Initialized
INFO - 2018-07-15 15:47:22 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:47:22 --> Model Class Initialized
INFO - 2018-07-15 15:47:22 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:47:22 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 15:47:22 --> Final output sent to browser
DEBUG - 2018-07-15 15:47:22 --> Total execution time: 0.0453
ERROR - 2018-07-15 15:47:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:47:24 --> Config Class Initialized
INFO - 2018-07-15 15:47:24 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:47:24 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:47:24 --> Utf8 Class Initialized
INFO - 2018-07-15 15:47:24 --> URI Class Initialized
INFO - 2018-07-15 15:47:24 --> Router Class Initialized
INFO - 2018-07-15 15:47:24 --> Output Class Initialized
INFO - 2018-07-15 15:47:24 --> Security Class Initialized
DEBUG - 2018-07-15 15:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:47:24 --> Input Class Initialized
INFO - 2018-07-15 15:47:24 --> Language Class Initialized
INFO - 2018-07-15 15:47:24 --> Loader Class Initialized
INFO - 2018-07-15 15:47:24 --> Controller Class Initialized
INFO - 2018-07-15 15:47:24 --> Database Driver Class Initialized
INFO - 2018-07-15 15:47:24 --> Model Class Initialized
INFO - 2018-07-15 15:47:24 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:47:24 --> Model Class Initialized
INFO - 2018-07-15 15:47:24 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:47:24 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-15 15:47:24 --> Final output sent to browser
DEBUG - 2018-07-15 15:47:24 --> Total execution time: 0.0508
ERROR - 2018-07-15 15:47:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:47:28 --> Config Class Initialized
INFO - 2018-07-15 15:47:28 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:47:28 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:47:28 --> Utf8 Class Initialized
INFO - 2018-07-15 15:47:28 --> URI Class Initialized
INFO - 2018-07-15 15:47:28 --> Router Class Initialized
INFO - 2018-07-15 15:47:28 --> Output Class Initialized
INFO - 2018-07-15 15:47:28 --> Security Class Initialized
DEBUG - 2018-07-15 15:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:47:28 --> Input Class Initialized
INFO - 2018-07-15 15:47:28 --> Language Class Initialized
INFO - 2018-07-15 15:47:28 --> Loader Class Initialized
INFO - 2018-07-15 15:47:28 --> Controller Class Initialized
INFO - 2018-07-15 15:47:28 --> Database Driver Class Initialized
INFO - 2018-07-15 15:47:28 --> Model Class Initialized
INFO - 2018-07-15 15:47:28 --> Helper loaded: url_helper
INFO - 2018-07-15 15:47:28 --> Model Class Initialized
INFO - 2018-07-15 15:47:28 --> Final output sent to browser
DEBUG - 2018-07-15 15:47:28 --> Total execution time: 0.0385
ERROR - 2018-07-15 15:48:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:48:48 --> Config Class Initialized
INFO - 2018-07-15 15:48:48 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:48:48 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:48:48 --> Utf8 Class Initialized
INFO - 2018-07-15 15:48:48 --> URI Class Initialized
INFO - 2018-07-15 15:48:48 --> Router Class Initialized
INFO - 2018-07-15 15:48:48 --> Output Class Initialized
INFO - 2018-07-15 15:48:48 --> Security Class Initialized
DEBUG - 2018-07-15 15:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:48:48 --> Input Class Initialized
INFO - 2018-07-15 15:48:48 --> Language Class Initialized
INFO - 2018-07-15 15:48:48 --> Loader Class Initialized
INFO - 2018-07-15 15:48:48 --> Controller Class Initialized
INFO - 2018-07-15 15:48:48 --> Database Driver Class Initialized
INFO - 2018-07-15 15:48:48 --> Model Class Initialized
INFO - 2018-07-15 15:48:48 --> Helper loaded: url_helper
DEBUG - 2018-07-15 15:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 15:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 15:48:48 --> Model Class Initialized
INFO - 2018-07-15 15:48:48 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 15:48:48 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-15 15:48:48 --> Final output sent to browser
DEBUG - 2018-07-15 15:48:48 --> Total execution time: 0.0746
ERROR - 2018-07-15 15:48:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:48:56 --> Config Class Initialized
INFO - 2018-07-15 15:48:56 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:48:56 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:48:56 --> Utf8 Class Initialized
INFO - 2018-07-15 15:48:57 --> URI Class Initialized
INFO - 2018-07-15 15:48:57 --> Router Class Initialized
INFO - 2018-07-15 15:48:57 --> Output Class Initialized
INFO - 2018-07-15 15:48:57 --> Security Class Initialized
DEBUG - 2018-07-15 15:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:48:57 --> Input Class Initialized
INFO - 2018-07-15 15:48:57 --> Language Class Initialized
INFO - 2018-07-15 15:48:57 --> Loader Class Initialized
INFO - 2018-07-15 15:48:57 --> Controller Class Initialized
INFO - 2018-07-15 15:48:57 --> Database Driver Class Initialized
INFO - 2018-07-15 15:48:57 --> Model Class Initialized
INFO - 2018-07-15 15:48:57 --> Helper loaded: url_helper
INFO - 2018-07-15 15:48:57 --> Model Class Initialized
INFO - 2018-07-15 15:48:57 --> Final output sent to browser
DEBUG - 2018-07-15 15:48:57 --> Total execution time: 0.0413
ERROR - 2018-07-15 15:48:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:48:57 --> Config Class Initialized
INFO - 2018-07-15 15:48:57 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:48:57 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:48:57 --> Utf8 Class Initialized
INFO - 2018-07-15 15:48:57 --> URI Class Initialized
INFO - 2018-07-15 15:48:57 --> Router Class Initialized
INFO - 2018-07-15 15:48:57 --> Output Class Initialized
INFO - 2018-07-15 15:48:57 --> Security Class Initialized
DEBUG - 2018-07-15 15:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:48:57 --> Input Class Initialized
INFO - 2018-07-15 15:48:57 --> Language Class Initialized
INFO - 2018-07-15 15:48:57 --> Loader Class Initialized
INFO - 2018-07-15 15:48:57 --> Controller Class Initialized
INFO - 2018-07-15 15:48:57 --> Database Driver Class Initialized
INFO - 2018-07-15 15:48:57 --> Model Class Initialized
INFO - 2018-07-15 15:48:57 --> Helper loaded: url_helper
INFO - 2018-07-15 15:48:57 --> Model Class Initialized
INFO - 2018-07-15 15:48:57 --> Final output sent to browser
DEBUG - 2018-07-15 15:48:57 --> Total execution time: 0.0414
ERROR - 2018-07-15 15:48:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:48:57 --> Config Class Initialized
INFO - 2018-07-15 15:48:57 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:48:57 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:48:57 --> Utf8 Class Initialized
INFO - 2018-07-15 15:48:57 --> URI Class Initialized
INFO - 2018-07-15 15:48:57 --> Router Class Initialized
INFO - 2018-07-15 15:48:57 --> Output Class Initialized
INFO - 2018-07-15 15:48:57 --> Security Class Initialized
DEBUG - 2018-07-15 15:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:48:57 --> Input Class Initialized
INFO - 2018-07-15 15:48:57 --> Language Class Initialized
INFO - 2018-07-15 15:48:57 --> Loader Class Initialized
INFO - 2018-07-15 15:48:57 --> Controller Class Initialized
INFO - 2018-07-15 15:48:57 --> Database Driver Class Initialized
INFO - 2018-07-15 15:48:57 --> Model Class Initialized
INFO - 2018-07-15 15:48:57 --> Helper loaded: url_helper
INFO - 2018-07-15 15:48:57 --> Model Class Initialized
INFO - 2018-07-15 15:48:57 --> Final output sent to browser
DEBUG - 2018-07-15 15:48:57 --> Total execution time: 0.0430
ERROR - 2018-07-15 15:50:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:50:15 --> Config Class Initialized
INFO - 2018-07-15 15:50:15 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:50:15 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:50:15 --> Utf8 Class Initialized
INFO - 2018-07-15 15:50:15 --> URI Class Initialized
INFO - 2018-07-15 15:50:15 --> Router Class Initialized
INFO - 2018-07-15 15:50:15 --> Output Class Initialized
INFO - 2018-07-15 15:50:15 --> Security Class Initialized
DEBUG - 2018-07-15 15:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:50:15 --> Input Class Initialized
INFO - 2018-07-15 15:50:15 --> Language Class Initialized
INFO - 2018-07-15 15:50:15 --> Loader Class Initialized
INFO - 2018-07-15 15:50:15 --> Controller Class Initialized
INFO - 2018-07-15 15:50:15 --> Database Driver Class Initialized
INFO - 2018-07-15 15:50:15 --> Model Class Initialized
INFO - 2018-07-15 15:50:15 --> Helper loaded: url_helper
INFO - 2018-07-15 15:50:15 --> Model Class Initialized
INFO - 2018-07-15 15:50:15 --> Final output sent to browser
DEBUG - 2018-07-15 15:50:15 --> Total execution time: 0.0439
ERROR - 2018-07-15 15:50:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:50:15 --> Config Class Initialized
INFO - 2018-07-15 15:50:15 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:50:15 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:50:15 --> Utf8 Class Initialized
INFO - 2018-07-15 15:50:15 --> URI Class Initialized
INFO - 2018-07-15 15:50:15 --> Router Class Initialized
INFO - 2018-07-15 15:50:15 --> Output Class Initialized
INFO - 2018-07-15 15:50:15 --> Security Class Initialized
DEBUG - 2018-07-15 15:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:50:15 --> Input Class Initialized
INFO - 2018-07-15 15:50:15 --> Language Class Initialized
INFO - 2018-07-15 15:50:15 --> Loader Class Initialized
INFO - 2018-07-15 15:50:15 --> Controller Class Initialized
INFO - 2018-07-15 15:50:15 --> Database Driver Class Initialized
INFO - 2018-07-15 15:50:15 --> Model Class Initialized
INFO - 2018-07-15 15:50:15 --> Helper loaded: url_helper
INFO - 2018-07-15 15:50:15 --> Model Class Initialized
INFO - 2018-07-15 15:50:15 --> Final output sent to browser
DEBUG - 2018-07-15 15:50:15 --> Total execution time: 0.0743
ERROR - 2018-07-15 15:50:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:50:15 --> Config Class Initialized
INFO - 2018-07-15 15:50:15 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:50:15 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:50:15 --> Utf8 Class Initialized
INFO - 2018-07-15 15:50:15 --> URI Class Initialized
INFO - 2018-07-15 15:50:15 --> Router Class Initialized
INFO - 2018-07-15 15:50:15 --> Output Class Initialized
INFO - 2018-07-15 15:50:15 --> Security Class Initialized
DEBUG - 2018-07-15 15:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:50:15 --> Input Class Initialized
INFO - 2018-07-15 15:50:15 --> Language Class Initialized
INFO - 2018-07-15 15:50:15 --> Loader Class Initialized
INFO - 2018-07-15 15:50:15 --> Controller Class Initialized
INFO - 2018-07-15 15:50:15 --> Database Driver Class Initialized
INFO - 2018-07-15 15:50:15 --> Model Class Initialized
INFO - 2018-07-15 15:50:15 --> Helper loaded: url_helper
INFO - 2018-07-15 15:50:15 --> Model Class Initialized
INFO - 2018-07-15 15:50:15 --> Final output sent to browser
DEBUG - 2018-07-15 15:50:15 --> Total execution time: 0.0466
ERROR - 2018-07-15 15:51:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:51:44 --> Config Class Initialized
INFO - 2018-07-15 15:51:44 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:51:44 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:51:44 --> Utf8 Class Initialized
INFO - 2018-07-15 15:51:44 --> URI Class Initialized
INFO - 2018-07-15 15:51:44 --> Router Class Initialized
INFO - 2018-07-15 15:51:44 --> Output Class Initialized
INFO - 2018-07-15 15:51:44 --> Security Class Initialized
DEBUG - 2018-07-15 15:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:51:44 --> Input Class Initialized
INFO - 2018-07-15 15:51:44 --> Language Class Initialized
INFO - 2018-07-15 15:51:44 --> Loader Class Initialized
INFO - 2018-07-15 15:51:44 --> Controller Class Initialized
INFO - 2018-07-15 15:51:44 --> Database Driver Class Initialized
INFO - 2018-07-15 15:51:44 --> Model Class Initialized
INFO - 2018-07-15 15:51:44 --> Helper loaded: url_helper
INFO - 2018-07-15 15:51:44 --> Model Class Initialized
INFO - 2018-07-15 15:51:44 --> Final output sent to browser
DEBUG - 2018-07-15 15:51:44 --> Total execution time: 0.0451
ERROR - 2018-07-15 15:51:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:51:50 --> Config Class Initialized
INFO - 2018-07-15 15:51:50 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:51:50 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:51:50 --> Utf8 Class Initialized
INFO - 2018-07-15 15:51:50 --> URI Class Initialized
INFO - 2018-07-15 15:51:50 --> Router Class Initialized
INFO - 2018-07-15 15:51:50 --> Output Class Initialized
INFO - 2018-07-15 15:51:50 --> Security Class Initialized
DEBUG - 2018-07-15 15:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:51:50 --> Input Class Initialized
INFO - 2018-07-15 15:51:50 --> Language Class Initialized
INFO - 2018-07-15 15:51:50 --> Loader Class Initialized
INFO - 2018-07-15 15:51:50 --> Controller Class Initialized
INFO - 2018-07-15 15:51:50 --> Database Driver Class Initialized
INFO - 2018-07-15 15:51:50 --> Model Class Initialized
INFO - 2018-07-15 15:51:50 --> Helper loaded: url_helper
INFO - 2018-07-15 15:51:50 --> Model Class Initialized
INFO - 2018-07-15 15:51:50 --> Final output sent to browser
DEBUG - 2018-07-15 15:51:50 --> Total execution time: 0.0529
ERROR - 2018-07-15 15:51:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:51:51 --> Config Class Initialized
INFO - 2018-07-15 15:51:51 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:51:51 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:51:51 --> Utf8 Class Initialized
INFO - 2018-07-15 15:51:51 --> URI Class Initialized
INFO - 2018-07-15 15:51:51 --> Router Class Initialized
INFO - 2018-07-15 15:51:51 --> Output Class Initialized
INFO - 2018-07-15 15:51:51 --> Security Class Initialized
DEBUG - 2018-07-15 15:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:51:51 --> Input Class Initialized
INFO - 2018-07-15 15:51:51 --> Language Class Initialized
INFO - 2018-07-15 15:51:51 --> Loader Class Initialized
INFO - 2018-07-15 15:51:51 --> Controller Class Initialized
INFO - 2018-07-15 15:51:51 --> Database Driver Class Initialized
INFO - 2018-07-15 15:51:51 --> Model Class Initialized
INFO - 2018-07-15 15:51:51 --> Helper loaded: url_helper
INFO - 2018-07-15 15:51:51 --> Model Class Initialized
INFO - 2018-07-15 15:51:51 --> Final output sent to browser
DEBUG - 2018-07-15 15:51:51 --> Total execution time: 0.0616
ERROR - 2018-07-15 15:51:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:51:51 --> Config Class Initialized
INFO - 2018-07-15 15:51:51 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:51:51 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:51:51 --> Utf8 Class Initialized
INFO - 2018-07-15 15:51:51 --> URI Class Initialized
INFO - 2018-07-15 15:51:51 --> Router Class Initialized
INFO - 2018-07-15 15:51:51 --> Output Class Initialized
INFO - 2018-07-15 15:51:51 --> Security Class Initialized
DEBUG - 2018-07-15 15:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:51:51 --> Input Class Initialized
INFO - 2018-07-15 15:51:51 --> Language Class Initialized
INFO - 2018-07-15 15:51:51 --> Loader Class Initialized
INFO - 2018-07-15 15:51:51 --> Controller Class Initialized
INFO - 2018-07-15 15:51:51 --> Database Driver Class Initialized
INFO - 2018-07-15 15:51:51 --> Model Class Initialized
INFO - 2018-07-15 15:51:51 --> Helper loaded: url_helper
INFO - 2018-07-15 15:51:51 --> Model Class Initialized
INFO - 2018-07-15 15:51:51 --> Final output sent to browser
DEBUG - 2018-07-15 15:51:51 --> Total execution time: 0.0465
ERROR - 2018-07-15 15:51:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 15:51:57 --> Config Class Initialized
INFO - 2018-07-15 15:51:57 --> Hooks Class Initialized
DEBUG - 2018-07-15 15:51:57 --> UTF-8 Support Enabled
INFO - 2018-07-15 15:51:57 --> Utf8 Class Initialized
INFO - 2018-07-15 15:51:57 --> URI Class Initialized
INFO - 2018-07-15 15:51:57 --> Router Class Initialized
INFO - 2018-07-15 15:51:57 --> Output Class Initialized
INFO - 2018-07-15 15:51:57 --> Security Class Initialized
DEBUG - 2018-07-15 15:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 15:51:57 --> Input Class Initialized
INFO - 2018-07-15 15:51:57 --> Language Class Initialized
INFO - 2018-07-15 15:51:57 --> Loader Class Initialized
INFO - 2018-07-15 15:51:57 --> Controller Class Initialized
INFO - 2018-07-15 15:51:57 --> Database Driver Class Initialized
INFO - 2018-07-15 15:51:57 --> Model Class Initialized
INFO - 2018-07-15 15:51:57 --> Helper loaded: url_helper
INFO - 2018-07-15 15:51:57 --> Model Class Initialized
INFO - 2018-07-15 15:51:57 --> Final output sent to browser
DEBUG - 2018-07-15 15:51:57 --> Total execution time: 0.0591
ERROR - 2018-07-15 16:36:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 16:36:50 --> Config Class Initialized
INFO - 2018-07-15 16:36:50 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:36:50 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:36:50 --> Utf8 Class Initialized
INFO - 2018-07-15 16:36:50 --> URI Class Initialized
INFO - 2018-07-15 16:36:50 --> Router Class Initialized
INFO - 2018-07-15 16:36:50 --> Output Class Initialized
INFO - 2018-07-15 16:36:50 --> Security Class Initialized
DEBUG - 2018-07-15 16:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:36:50 --> Input Class Initialized
INFO - 2018-07-15 16:36:50 --> Language Class Initialized
INFO - 2018-07-15 16:36:50 --> Loader Class Initialized
INFO - 2018-07-15 16:36:50 --> Controller Class Initialized
INFO - 2018-07-15 16:36:50 --> Database Driver Class Initialized
INFO - 2018-07-15 16:36:50 --> Model Class Initialized
INFO - 2018-07-15 16:36:50 --> Helper loaded: url_helper
INFO - 2018-07-15 16:36:50 --> Model Class Initialized
INFO - 2018-07-15 16:36:50 --> Final output sent to browser
DEBUG - 2018-07-15 16:36:50 --> Total execution time: 0.0402
ERROR - 2018-07-15 16:36:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 16:36:52 --> Config Class Initialized
INFO - 2018-07-15 16:36:52 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:36:52 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:36:52 --> Utf8 Class Initialized
INFO - 2018-07-15 16:36:52 --> URI Class Initialized
INFO - 2018-07-15 16:36:52 --> Router Class Initialized
INFO - 2018-07-15 16:36:52 --> Output Class Initialized
INFO - 2018-07-15 16:36:52 --> Security Class Initialized
DEBUG - 2018-07-15 16:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:36:52 --> Input Class Initialized
INFO - 2018-07-15 16:36:52 --> Language Class Initialized
INFO - 2018-07-15 16:36:52 --> Loader Class Initialized
INFO - 2018-07-15 16:36:52 --> Controller Class Initialized
INFO - 2018-07-15 16:36:52 --> Database Driver Class Initialized
INFO - 2018-07-15 16:36:52 --> Model Class Initialized
INFO - 2018-07-15 16:36:52 --> Helper loaded: url_helper
INFO - 2018-07-15 16:36:52 --> Model Class Initialized
INFO - 2018-07-15 16:36:52 --> Final output sent to browser
DEBUG - 2018-07-15 16:36:52 --> Total execution time: 0.0434
ERROR - 2018-07-15 16:38:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 16:38:02 --> Config Class Initialized
INFO - 2018-07-15 16:38:02 --> Hooks Class Initialized
DEBUG - 2018-07-15 16:38:02 --> UTF-8 Support Enabled
INFO - 2018-07-15 16:38:02 --> Utf8 Class Initialized
INFO - 2018-07-15 16:38:02 --> URI Class Initialized
INFO - 2018-07-15 16:38:02 --> Router Class Initialized
INFO - 2018-07-15 16:38:02 --> Output Class Initialized
INFO - 2018-07-15 16:38:02 --> Security Class Initialized
DEBUG - 2018-07-15 16:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 16:38:02 --> Input Class Initialized
INFO - 2018-07-15 16:38:02 --> Language Class Initialized
INFO - 2018-07-15 16:38:02 --> Loader Class Initialized
INFO - 2018-07-15 16:38:02 --> Controller Class Initialized
INFO - 2018-07-15 16:38:02 --> Database Driver Class Initialized
INFO - 2018-07-15 16:38:02 --> Model Class Initialized
INFO - 2018-07-15 16:38:02 --> Helper loaded: url_helper
INFO - 2018-07-15 16:38:02 --> Model Class Initialized
INFO - 2018-07-15 16:38:02 --> Final output sent to browser
DEBUG - 2018-07-15 16:38:02 --> Total execution time: 0.0460
ERROR - 2018-07-15 19:15:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 19:15:23 --> Config Class Initialized
INFO - 2018-07-15 19:15:23 --> Hooks Class Initialized
DEBUG - 2018-07-15 19:15:23 --> UTF-8 Support Enabled
INFO - 2018-07-15 19:15:23 --> Utf8 Class Initialized
INFO - 2018-07-15 19:15:23 --> URI Class Initialized
INFO - 2018-07-15 19:15:23 --> Router Class Initialized
INFO - 2018-07-15 19:15:23 --> Output Class Initialized
INFO - 2018-07-15 19:15:23 --> Security Class Initialized
DEBUG - 2018-07-15 19:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 19:15:23 --> Input Class Initialized
INFO - 2018-07-15 19:15:23 --> Language Class Initialized
INFO - 2018-07-15 19:15:23 --> Loader Class Initialized
INFO - 2018-07-15 19:15:23 --> Controller Class Initialized
INFO - 2018-07-15 19:15:23 --> Database Driver Class Initialized
INFO - 2018-07-15 19:15:23 --> Model Class Initialized
INFO - 2018-07-15 19:15:23 --> Helper loaded: url_helper
INFO - 2018-07-15 19:15:23 --> Model Class Initialized
INFO - 2018-07-15 19:15:23 --> Final output sent to browser
DEBUG - 2018-07-15 19:15:23 --> Total execution time: 0.0477
ERROR - 2018-07-15 19:46:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 19:46:17 --> Config Class Initialized
INFO - 2018-07-15 19:46:17 --> Hooks Class Initialized
DEBUG - 2018-07-15 19:46:17 --> UTF-8 Support Enabled
INFO - 2018-07-15 19:46:17 --> Utf8 Class Initialized
INFO - 2018-07-15 19:46:17 --> URI Class Initialized
INFO - 2018-07-15 19:46:17 --> Router Class Initialized
INFO - 2018-07-15 19:46:17 --> Output Class Initialized
INFO - 2018-07-15 19:46:17 --> Security Class Initialized
DEBUG - 2018-07-15 19:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 19:46:17 --> Input Class Initialized
INFO - 2018-07-15 19:46:17 --> Language Class Initialized
INFO - 2018-07-15 19:46:17 --> Loader Class Initialized
INFO - 2018-07-15 19:46:17 --> Controller Class Initialized
INFO - 2018-07-15 19:46:17 --> Database Driver Class Initialized
INFO - 2018-07-15 19:46:17 --> Model Class Initialized
INFO - 2018-07-15 19:46:17 --> Helper loaded: url_helper
INFO - 2018-07-15 19:46:17 --> Model Class Initialized
INFO - 2018-07-15 19:46:17 --> Final output sent to browser
DEBUG - 2018-07-15 19:46:17 --> Total execution time: 0.0388
ERROR - 2018-07-15 19:46:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 19:46:19 --> Config Class Initialized
INFO - 2018-07-15 19:46:19 --> Hooks Class Initialized
DEBUG - 2018-07-15 19:46:19 --> UTF-8 Support Enabled
INFO - 2018-07-15 19:46:19 --> Utf8 Class Initialized
INFO - 2018-07-15 19:46:19 --> URI Class Initialized
INFO - 2018-07-15 19:46:19 --> Router Class Initialized
INFO - 2018-07-15 19:46:19 --> Output Class Initialized
INFO - 2018-07-15 19:46:19 --> Security Class Initialized
DEBUG - 2018-07-15 19:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 19:46:19 --> Input Class Initialized
INFO - 2018-07-15 19:46:19 --> Language Class Initialized
INFO - 2018-07-15 19:46:19 --> Loader Class Initialized
INFO - 2018-07-15 19:46:19 --> Controller Class Initialized
INFO - 2018-07-15 19:46:19 --> Database Driver Class Initialized
INFO - 2018-07-15 19:46:19 --> Model Class Initialized
INFO - 2018-07-15 19:46:19 --> Helper loaded: url_helper
INFO - 2018-07-15 19:46:19 --> Model Class Initialized
INFO - 2018-07-15 19:46:19 --> Final output sent to browser
DEBUG - 2018-07-15 19:46:19 --> Total execution time: 0.0375
ERROR - 2018-07-15 19:46:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 19:46:19 --> Config Class Initialized
INFO - 2018-07-15 19:46:19 --> Hooks Class Initialized
DEBUG - 2018-07-15 19:46:19 --> UTF-8 Support Enabled
INFO - 2018-07-15 19:46:19 --> Utf8 Class Initialized
INFO - 2018-07-15 19:46:19 --> URI Class Initialized
INFO - 2018-07-15 19:46:19 --> Router Class Initialized
INFO - 2018-07-15 19:46:19 --> Output Class Initialized
INFO - 2018-07-15 19:46:19 --> Security Class Initialized
DEBUG - 2018-07-15 19:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 19:46:19 --> Input Class Initialized
INFO - 2018-07-15 19:46:19 --> Language Class Initialized
INFO - 2018-07-15 19:46:19 --> Loader Class Initialized
INFO - 2018-07-15 19:46:19 --> Controller Class Initialized
INFO - 2018-07-15 19:46:19 --> Database Driver Class Initialized
INFO - 2018-07-15 19:46:19 --> Model Class Initialized
INFO - 2018-07-15 19:46:19 --> Helper loaded: url_helper
INFO - 2018-07-15 19:46:19 --> Model Class Initialized
INFO - 2018-07-15 19:46:20 --> Final output sent to browser
DEBUG - 2018-07-15 19:46:20 --> Total execution time: 0.0406
ERROR - 2018-07-15 20:05:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:05:42 --> Config Class Initialized
INFO - 2018-07-15 20:05:42 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:05:42 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:05:42 --> Utf8 Class Initialized
INFO - 2018-07-15 20:05:42 --> URI Class Initialized
INFO - 2018-07-15 20:05:42 --> Router Class Initialized
INFO - 2018-07-15 20:05:42 --> Output Class Initialized
INFO - 2018-07-15 20:05:42 --> Security Class Initialized
DEBUG - 2018-07-15 20:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:05:42 --> Input Class Initialized
INFO - 2018-07-15 20:05:42 --> Language Class Initialized
INFO - 2018-07-15 20:05:42 --> Loader Class Initialized
INFO - 2018-07-15 20:05:42 --> Controller Class Initialized
INFO - 2018-07-15 20:05:42 --> Database Driver Class Initialized
INFO - 2018-07-15 20:05:42 --> Model Class Initialized
INFO - 2018-07-15 20:05:42 --> Helper loaded: url_helper
INFO - 2018-07-15 20:05:42 --> Model Class Initialized
INFO - 2018-07-15 20:05:42 --> Final output sent to browser
DEBUG - 2018-07-15 20:05:42 --> Total execution time: 0.0351
ERROR - 2018-07-15 20:05:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:05:44 --> Config Class Initialized
INFO - 2018-07-15 20:05:44 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:05:44 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:05:44 --> Utf8 Class Initialized
INFO - 2018-07-15 20:05:44 --> URI Class Initialized
INFO - 2018-07-15 20:05:44 --> Router Class Initialized
INFO - 2018-07-15 20:05:44 --> Output Class Initialized
INFO - 2018-07-15 20:05:44 --> Security Class Initialized
DEBUG - 2018-07-15 20:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:05:44 --> Input Class Initialized
INFO - 2018-07-15 20:05:44 --> Language Class Initialized
INFO - 2018-07-15 20:05:44 --> Loader Class Initialized
INFO - 2018-07-15 20:05:44 --> Controller Class Initialized
INFO - 2018-07-15 20:05:44 --> Database Driver Class Initialized
INFO - 2018-07-15 20:05:44 --> Model Class Initialized
INFO - 2018-07-15 20:05:44 --> Helper loaded: url_helper
INFO - 2018-07-15 20:05:44 --> Model Class Initialized
INFO - 2018-07-15 20:05:44 --> Final output sent to browser
DEBUG - 2018-07-15 20:05:44 --> Total execution time: 0.0379
ERROR - 2018-07-15 20:05:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:05:44 --> Config Class Initialized
INFO - 2018-07-15 20:05:44 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:05:44 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:05:44 --> Utf8 Class Initialized
INFO - 2018-07-15 20:05:44 --> URI Class Initialized
INFO - 2018-07-15 20:05:44 --> Router Class Initialized
INFO - 2018-07-15 20:05:44 --> Output Class Initialized
INFO - 2018-07-15 20:05:44 --> Security Class Initialized
DEBUG - 2018-07-15 20:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:05:44 --> Input Class Initialized
INFO - 2018-07-15 20:05:44 --> Language Class Initialized
INFO - 2018-07-15 20:05:44 --> Loader Class Initialized
INFO - 2018-07-15 20:05:44 --> Controller Class Initialized
INFO - 2018-07-15 20:05:44 --> Database Driver Class Initialized
INFO - 2018-07-15 20:05:44 --> Model Class Initialized
INFO - 2018-07-15 20:05:44 --> Helper loaded: url_helper
INFO - 2018-07-15 20:05:44 --> Model Class Initialized
INFO - 2018-07-15 20:05:44 --> Final output sent to browser
DEBUG - 2018-07-15 20:05:44 --> Total execution time: 0.2464
ERROR - 2018-07-15 20:07:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:07:55 --> Config Class Initialized
INFO - 2018-07-15 20:07:55 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:07:55 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:07:55 --> Utf8 Class Initialized
INFO - 2018-07-15 20:07:55 --> URI Class Initialized
INFO - 2018-07-15 20:07:55 --> Router Class Initialized
INFO - 2018-07-15 20:07:55 --> Output Class Initialized
INFO - 2018-07-15 20:07:55 --> Security Class Initialized
DEBUG - 2018-07-15 20:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:07:55 --> Input Class Initialized
INFO - 2018-07-15 20:07:55 --> Language Class Initialized
INFO - 2018-07-15 20:07:55 --> Loader Class Initialized
INFO - 2018-07-15 20:07:55 --> Controller Class Initialized
INFO - 2018-07-15 20:07:55 --> Database Driver Class Initialized
INFO - 2018-07-15 20:07:55 --> Model Class Initialized
INFO - 2018-07-15 20:07:55 --> Helper loaded: url_helper
INFO - 2018-07-15 20:07:55 --> Model Class Initialized
INFO - 2018-07-15 20:07:55 --> Final output sent to browser
DEBUG - 2018-07-15 20:07:55 --> Total execution time: 0.0925
ERROR - 2018-07-15 20:09:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:09:24 --> Config Class Initialized
INFO - 2018-07-15 20:09:24 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:09:24 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:09:24 --> Utf8 Class Initialized
INFO - 2018-07-15 20:09:24 --> URI Class Initialized
INFO - 2018-07-15 20:09:24 --> Router Class Initialized
INFO - 2018-07-15 20:09:24 --> Output Class Initialized
INFO - 2018-07-15 20:09:24 --> Security Class Initialized
DEBUG - 2018-07-15 20:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:09:24 --> Input Class Initialized
INFO - 2018-07-15 20:09:24 --> Language Class Initialized
INFO - 2018-07-15 20:09:24 --> Loader Class Initialized
INFO - 2018-07-15 20:09:24 --> Controller Class Initialized
INFO - 2018-07-15 20:09:24 --> Database Driver Class Initialized
INFO - 2018-07-15 20:09:24 --> Model Class Initialized
INFO - 2018-07-15 20:09:24 --> Helper loaded: url_helper
INFO - 2018-07-15 20:09:24 --> Model Class Initialized
INFO - 2018-07-15 20:09:24 --> Final output sent to browser
DEBUG - 2018-07-15 20:09:24 --> Total execution time: 0.0440
ERROR - 2018-07-15 20:37:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:37:05 --> Config Class Initialized
INFO - 2018-07-15 20:37:05 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:37:05 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:37:05 --> Utf8 Class Initialized
INFO - 2018-07-15 20:37:05 --> URI Class Initialized
INFO - 2018-07-15 20:37:05 --> Router Class Initialized
INFO - 2018-07-15 20:37:05 --> Output Class Initialized
INFO - 2018-07-15 20:37:05 --> Security Class Initialized
DEBUG - 2018-07-15 20:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:37:05 --> Input Class Initialized
INFO - 2018-07-15 20:37:05 --> Language Class Initialized
INFO - 2018-07-15 20:37:05 --> Loader Class Initialized
INFO - 2018-07-15 20:37:05 --> Controller Class Initialized
INFO - 2018-07-15 20:37:05 --> Database Driver Class Initialized
INFO - 2018-07-15 20:37:05 --> Model Class Initialized
INFO - 2018-07-15 20:37:05 --> Helper loaded: url_helper
INFO - 2018-07-15 20:37:05 --> Model Class Initialized
INFO - 2018-07-15 20:37:05 --> Final output sent to browser
DEBUG - 2018-07-15 20:37:05 --> Total execution time: 0.0391
ERROR - 2018-07-15 20:37:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:37:05 --> Config Class Initialized
INFO - 2018-07-15 20:37:05 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:37:05 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:37:05 --> Utf8 Class Initialized
INFO - 2018-07-15 20:37:05 --> URI Class Initialized
INFO - 2018-07-15 20:37:05 --> Router Class Initialized
INFO - 2018-07-15 20:37:05 --> Output Class Initialized
INFO - 2018-07-15 20:37:05 --> Security Class Initialized
DEBUG - 2018-07-15 20:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:37:05 --> Input Class Initialized
INFO - 2018-07-15 20:37:05 --> Language Class Initialized
INFO - 2018-07-15 20:37:05 --> Loader Class Initialized
INFO - 2018-07-15 20:37:05 --> Controller Class Initialized
INFO - 2018-07-15 20:37:05 --> Database Driver Class Initialized
INFO - 2018-07-15 20:37:05 --> Model Class Initialized
INFO - 2018-07-15 20:37:05 --> Helper loaded: url_helper
INFO - 2018-07-15 20:37:05 --> Model Class Initialized
INFO - 2018-07-15 20:37:05 --> Final output sent to browser
DEBUG - 2018-07-15 20:37:05 --> Total execution time: 0.0375
ERROR - 2018-07-15 20:37:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:37:24 --> Config Class Initialized
INFO - 2018-07-15 20:37:24 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:37:24 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:37:24 --> Utf8 Class Initialized
INFO - 2018-07-15 20:37:24 --> URI Class Initialized
INFO - 2018-07-15 20:37:24 --> Router Class Initialized
INFO - 2018-07-15 20:37:24 --> Output Class Initialized
INFO - 2018-07-15 20:37:24 --> Security Class Initialized
DEBUG - 2018-07-15 20:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:37:24 --> Input Class Initialized
INFO - 2018-07-15 20:37:24 --> Language Class Initialized
INFO - 2018-07-15 20:37:24 --> Loader Class Initialized
INFO - 2018-07-15 20:37:24 --> Controller Class Initialized
INFO - 2018-07-15 20:37:24 --> Database Driver Class Initialized
INFO - 2018-07-15 20:37:24 --> Model Class Initialized
INFO - 2018-07-15 20:37:24 --> Helper loaded: url_helper
INFO - 2018-07-15 20:37:24 --> Model Class Initialized
INFO - 2018-07-15 20:37:24 --> Final output sent to browser
DEBUG - 2018-07-15 20:37:24 --> Total execution time: 0.1706
ERROR - 2018-07-15 20:40:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:40:26 --> Config Class Initialized
INFO - 2018-07-15 20:40:26 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:40:26 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:40:26 --> Utf8 Class Initialized
INFO - 2018-07-15 20:40:26 --> URI Class Initialized
INFO - 2018-07-15 20:40:26 --> Router Class Initialized
INFO - 2018-07-15 20:40:26 --> Output Class Initialized
INFO - 2018-07-15 20:40:26 --> Security Class Initialized
DEBUG - 2018-07-15 20:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:40:26 --> Input Class Initialized
INFO - 2018-07-15 20:40:26 --> Language Class Initialized
INFO - 2018-07-15 20:40:26 --> Loader Class Initialized
INFO - 2018-07-15 20:40:26 --> Controller Class Initialized
INFO - 2018-07-15 20:40:26 --> Database Driver Class Initialized
INFO - 2018-07-15 20:40:26 --> Model Class Initialized
INFO - 2018-07-15 20:40:26 --> Helper loaded: url_helper
INFO - 2018-07-15 20:40:26 --> Model Class Initialized
INFO - 2018-07-15 20:40:26 --> Final output sent to browser
DEBUG - 2018-07-15 20:40:26 --> Total execution time: 0.0536
ERROR - 2018-07-15 20:40:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:40:27 --> Config Class Initialized
INFO - 2018-07-15 20:40:27 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:40:27 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:40:27 --> Utf8 Class Initialized
INFO - 2018-07-15 20:40:27 --> URI Class Initialized
INFO - 2018-07-15 20:40:27 --> Router Class Initialized
INFO - 2018-07-15 20:40:27 --> Output Class Initialized
INFO - 2018-07-15 20:40:27 --> Security Class Initialized
DEBUG - 2018-07-15 20:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:40:27 --> Input Class Initialized
INFO - 2018-07-15 20:40:27 --> Language Class Initialized
INFO - 2018-07-15 20:40:27 --> Loader Class Initialized
INFO - 2018-07-15 20:40:27 --> Controller Class Initialized
INFO - 2018-07-15 20:40:27 --> Database Driver Class Initialized
INFO - 2018-07-15 20:40:27 --> Model Class Initialized
INFO - 2018-07-15 20:40:27 --> Helper loaded: url_helper
INFO - 2018-07-15 20:40:27 --> Model Class Initialized
INFO - 2018-07-15 20:40:27 --> Final output sent to browser
DEBUG - 2018-07-15 20:40:27 --> Total execution time: 0.0635
ERROR - 2018-07-15 20:40:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:40:27 --> Config Class Initialized
INFO - 2018-07-15 20:40:27 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:40:27 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:40:27 --> Utf8 Class Initialized
INFO - 2018-07-15 20:40:27 --> URI Class Initialized
INFO - 2018-07-15 20:40:27 --> Router Class Initialized
INFO - 2018-07-15 20:40:27 --> Output Class Initialized
INFO - 2018-07-15 20:40:27 --> Security Class Initialized
DEBUG - 2018-07-15 20:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:40:27 --> Input Class Initialized
INFO - 2018-07-15 20:40:27 --> Language Class Initialized
INFO - 2018-07-15 20:40:27 --> Loader Class Initialized
INFO - 2018-07-15 20:40:27 --> Controller Class Initialized
INFO - 2018-07-15 20:40:27 --> Database Driver Class Initialized
INFO - 2018-07-15 20:40:27 --> Model Class Initialized
INFO - 2018-07-15 20:40:27 --> Helper loaded: url_helper
INFO - 2018-07-15 20:40:27 --> Model Class Initialized
INFO - 2018-07-15 20:40:27 --> Final output sent to browser
DEBUG - 2018-07-15 20:40:27 --> Total execution time: 0.0607
ERROR - 2018-07-15 20:42:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:42:09 --> Config Class Initialized
INFO - 2018-07-15 20:42:09 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:42:09 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:42:09 --> Utf8 Class Initialized
INFO - 2018-07-15 20:42:09 --> URI Class Initialized
INFO - 2018-07-15 20:42:09 --> Router Class Initialized
INFO - 2018-07-15 20:42:09 --> Output Class Initialized
INFO - 2018-07-15 20:42:09 --> Security Class Initialized
DEBUG - 2018-07-15 20:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:42:09 --> Input Class Initialized
INFO - 2018-07-15 20:42:09 --> Language Class Initialized
INFO - 2018-07-15 20:42:09 --> Loader Class Initialized
INFO - 2018-07-15 20:42:09 --> Controller Class Initialized
INFO - 2018-07-15 20:42:09 --> Database Driver Class Initialized
INFO - 2018-07-15 20:42:09 --> Model Class Initialized
INFO - 2018-07-15 20:42:09 --> Helper loaded: url_helper
INFO - 2018-07-15 20:42:09 --> Model Class Initialized
INFO - 2018-07-15 20:42:09 --> Final output sent to browser
DEBUG - 2018-07-15 20:42:09 --> Total execution time: 0.0767
ERROR - 2018-07-15 20:42:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:42:09 --> Config Class Initialized
INFO - 2018-07-15 20:42:09 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:42:09 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:42:09 --> Utf8 Class Initialized
INFO - 2018-07-15 20:42:09 --> URI Class Initialized
INFO - 2018-07-15 20:42:09 --> Router Class Initialized
INFO - 2018-07-15 20:42:09 --> Output Class Initialized
INFO - 2018-07-15 20:42:09 --> Security Class Initialized
DEBUG - 2018-07-15 20:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:42:09 --> Input Class Initialized
INFO - 2018-07-15 20:42:09 --> Language Class Initialized
INFO - 2018-07-15 20:42:09 --> Loader Class Initialized
INFO - 2018-07-15 20:42:09 --> Controller Class Initialized
INFO - 2018-07-15 20:42:09 --> Database Driver Class Initialized
INFO - 2018-07-15 20:42:09 --> Model Class Initialized
INFO - 2018-07-15 20:42:09 --> Helper loaded: url_helper
INFO - 2018-07-15 20:42:09 --> Model Class Initialized
INFO - 2018-07-15 20:42:09 --> Final output sent to browser
DEBUG - 2018-07-15 20:42:09 --> Total execution time: 0.0561
ERROR - 2018-07-15 20:42:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:42:09 --> Config Class Initialized
INFO - 2018-07-15 20:42:09 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:42:09 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:42:09 --> Utf8 Class Initialized
INFO - 2018-07-15 20:42:09 --> URI Class Initialized
INFO - 2018-07-15 20:42:09 --> Router Class Initialized
INFO - 2018-07-15 20:42:09 --> Output Class Initialized
INFO - 2018-07-15 20:42:09 --> Security Class Initialized
DEBUG - 2018-07-15 20:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:42:09 --> Input Class Initialized
INFO - 2018-07-15 20:42:09 --> Language Class Initialized
INFO - 2018-07-15 20:42:09 --> Loader Class Initialized
INFO - 2018-07-15 20:42:09 --> Controller Class Initialized
INFO - 2018-07-15 20:42:09 --> Database Driver Class Initialized
INFO - 2018-07-15 20:42:09 --> Model Class Initialized
INFO - 2018-07-15 20:42:09 --> Helper loaded: url_helper
INFO - 2018-07-15 20:42:09 --> Model Class Initialized
INFO - 2018-07-15 20:42:09 --> Final output sent to browser
DEBUG - 2018-07-15 20:42:09 --> Total execution time: 0.0537
ERROR - 2018-07-15 20:43:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:43:20 --> Config Class Initialized
INFO - 2018-07-15 20:43:20 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:43:20 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:43:20 --> Utf8 Class Initialized
INFO - 2018-07-15 20:43:20 --> URI Class Initialized
INFO - 2018-07-15 20:43:20 --> Router Class Initialized
INFO - 2018-07-15 20:43:20 --> Output Class Initialized
INFO - 2018-07-15 20:43:20 --> Security Class Initialized
DEBUG - 2018-07-15 20:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:43:20 --> Input Class Initialized
INFO - 2018-07-15 20:43:20 --> Language Class Initialized
INFO - 2018-07-15 20:43:20 --> Loader Class Initialized
INFO - 2018-07-15 20:43:20 --> Controller Class Initialized
INFO - 2018-07-15 20:43:20 --> Database Driver Class Initialized
INFO - 2018-07-15 20:43:20 --> Model Class Initialized
INFO - 2018-07-15 20:43:20 --> Helper loaded: url_helper
INFO - 2018-07-15 20:43:20 --> Model Class Initialized
INFO - 2018-07-15 20:43:20 --> Final output sent to browser
DEBUG - 2018-07-15 20:43:20 --> Total execution time: 0.1763
ERROR - 2018-07-15 20:46:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:46:03 --> Config Class Initialized
INFO - 2018-07-15 20:46:03 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:46:03 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:46:03 --> Utf8 Class Initialized
INFO - 2018-07-15 20:46:03 --> URI Class Initialized
INFO - 2018-07-15 20:46:03 --> Router Class Initialized
INFO - 2018-07-15 20:46:03 --> Output Class Initialized
INFO - 2018-07-15 20:46:03 --> Security Class Initialized
DEBUG - 2018-07-15 20:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:46:03 --> Input Class Initialized
INFO - 2018-07-15 20:46:03 --> Language Class Initialized
INFO - 2018-07-15 20:46:03 --> Loader Class Initialized
INFO - 2018-07-15 20:46:03 --> Controller Class Initialized
INFO - 2018-07-15 20:46:03 --> Database Driver Class Initialized
INFO - 2018-07-15 20:46:03 --> Model Class Initialized
INFO - 2018-07-15 20:46:03 --> Helper loaded: url_helper
INFO - 2018-07-15 20:46:03 --> Model Class Initialized
INFO - 2018-07-15 20:46:03 --> Final output sent to browser
DEBUG - 2018-07-15 20:46:03 --> Total execution time: 0.0558
ERROR - 2018-07-15 20:46:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:46:28 --> Config Class Initialized
INFO - 2018-07-15 20:46:28 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:46:28 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:46:28 --> Utf8 Class Initialized
INFO - 2018-07-15 20:46:28 --> URI Class Initialized
INFO - 2018-07-15 20:46:28 --> Router Class Initialized
INFO - 2018-07-15 20:46:28 --> Output Class Initialized
INFO - 2018-07-15 20:46:28 --> Security Class Initialized
DEBUG - 2018-07-15 20:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:46:28 --> Input Class Initialized
INFO - 2018-07-15 20:46:28 --> Language Class Initialized
INFO - 2018-07-15 20:46:28 --> Loader Class Initialized
INFO - 2018-07-15 20:46:28 --> Controller Class Initialized
INFO - 2018-07-15 20:46:28 --> Database Driver Class Initialized
INFO - 2018-07-15 20:46:28 --> Model Class Initialized
INFO - 2018-07-15 20:46:28 --> Helper loaded: url_helper
INFO - 2018-07-15 20:46:28 --> Model Class Initialized
INFO - 2018-07-15 20:46:28 --> Final output sent to browser
DEBUG - 2018-07-15 20:46:28 --> Total execution time: 0.0581
ERROR - 2018-07-15 20:46:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:46:28 --> Config Class Initialized
INFO - 2018-07-15 20:46:28 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:46:28 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:46:28 --> Utf8 Class Initialized
INFO - 2018-07-15 20:46:28 --> URI Class Initialized
INFO - 2018-07-15 20:46:28 --> Router Class Initialized
INFO - 2018-07-15 20:46:28 --> Output Class Initialized
INFO - 2018-07-15 20:46:28 --> Security Class Initialized
DEBUG - 2018-07-15 20:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:46:28 --> Input Class Initialized
INFO - 2018-07-15 20:46:28 --> Language Class Initialized
INFO - 2018-07-15 20:46:28 --> Loader Class Initialized
INFO - 2018-07-15 20:46:28 --> Controller Class Initialized
INFO - 2018-07-15 20:46:28 --> Database Driver Class Initialized
INFO - 2018-07-15 20:46:28 --> Model Class Initialized
INFO - 2018-07-15 20:46:28 --> Helper loaded: url_helper
INFO - 2018-07-15 20:46:28 --> Model Class Initialized
INFO - 2018-07-15 20:46:28 --> Final output sent to browser
DEBUG - 2018-07-15 20:46:28 --> Total execution time: 0.0657
ERROR - 2018-07-15 20:46:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:46:29 --> Config Class Initialized
INFO - 2018-07-15 20:46:29 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:46:29 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:46:29 --> Utf8 Class Initialized
INFO - 2018-07-15 20:46:29 --> URI Class Initialized
INFO - 2018-07-15 20:46:29 --> Router Class Initialized
INFO - 2018-07-15 20:46:29 --> Output Class Initialized
INFO - 2018-07-15 20:46:29 --> Security Class Initialized
DEBUG - 2018-07-15 20:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:46:29 --> Input Class Initialized
INFO - 2018-07-15 20:46:29 --> Language Class Initialized
INFO - 2018-07-15 20:46:29 --> Loader Class Initialized
INFO - 2018-07-15 20:46:29 --> Controller Class Initialized
INFO - 2018-07-15 20:46:29 --> Database Driver Class Initialized
INFO - 2018-07-15 20:46:29 --> Model Class Initialized
INFO - 2018-07-15 20:46:29 --> Helper loaded: url_helper
INFO - 2018-07-15 20:46:29 --> Model Class Initialized
INFO - 2018-07-15 20:46:29 --> Final output sent to browser
DEBUG - 2018-07-15 20:46:29 --> Total execution time: 0.0544
ERROR - 2018-07-15 20:46:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:46:58 --> Config Class Initialized
INFO - 2018-07-15 20:46:58 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:46:58 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:46:58 --> Utf8 Class Initialized
INFO - 2018-07-15 20:46:58 --> URI Class Initialized
INFO - 2018-07-15 20:46:58 --> Router Class Initialized
INFO - 2018-07-15 20:46:58 --> Output Class Initialized
INFO - 2018-07-15 20:46:58 --> Security Class Initialized
DEBUG - 2018-07-15 20:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:46:58 --> Input Class Initialized
INFO - 2018-07-15 20:46:58 --> Language Class Initialized
INFO - 2018-07-15 20:46:58 --> Loader Class Initialized
INFO - 2018-07-15 20:46:58 --> Controller Class Initialized
INFO - 2018-07-15 20:46:58 --> Database Driver Class Initialized
INFO - 2018-07-15 20:46:58 --> Model Class Initialized
INFO - 2018-07-15 20:46:58 --> Helper loaded: url_helper
INFO - 2018-07-15 20:46:58 --> Model Class Initialized
INFO - 2018-07-15 20:46:58 --> Final output sent to browser
DEBUG - 2018-07-15 20:46:58 --> Total execution time: 0.3975
ERROR - 2018-07-15 20:49:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:49:46 --> Config Class Initialized
INFO - 2018-07-15 20:49:46 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:49:46 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:49:46 --> Utf8 Class Initialized
INFO - 2018-07-15 20:49:46 --> URI Class Initialized
INFO - 2018-07-15 20:49:46 --> Router Class Initialized
INFO - 2018-07-15 20:49:46 --> Output Class Initialized
INFO - 2018-07-15 20:49:46 --> Security Class Initialized
DEBUG - 2018-07-15 20:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:49:46 --> Input Class Initialized
INFO - 2018-07-15 20:49:46 --> Language Class Initialized
INFO - 2018-07-15 20:49:46 --> Loader Class Initialized
INFO - 2018-07-15 20:49:46 --> Controller Class Initialized
INFO - 2018-07-15 20:49:46 --> Database Driver Class Initialized
INFO - 2018-07-15 20:49:46 --> Model Class Initialized
INFO - 2018-07-15 20:49:46 --> Helper loaded: url_helper
INFO - 2018-07-15 20:49:46 --> Model Class Initialized
INFO - 2018-07-15 20:49:46 --> Final output sent to browser
DEBUG - 2018-07-15 20:49:46 --> Total execution time: 0.0517
ERROR - 2018-07-15 20:50:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:50:48 --> Config Class Initialized
INFO - 2018-07-15 20:50:48 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:50:48 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:50:48 --> Utf8 Class Initialized
INFO - 2018-07-15 20:50:48 --> URI Class Initialized
INFO - 2018-07-15 20:50:48 --> Router Class Initialized
INFO - 2018-07-15 20:50:48 --> Output Class Initialized
INFO - 2018-07-15 20:50:48 --> Security Class Initialized
DEBUG - 2018-07-15 20:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:50:48 --> Input Class Initialized
INFO - 2018-07-15 20:50:48 --> Language Class Initialized
INFO - 2018-07-15 20:50:48 --> Loader Class Initialized
INFO - 2018-07-15 20:50:48 --> Controller Class Initialized
INFO - 2018-07-15 20:50:48 --> Database Driver Class Initialized
INFO - 2018-07-15 20:50:48 --> Model Class Initialized
INFO - 2018-07-15 20:50:48 --> Helper loaded: url_helper
INFO - 2018-07-15 20:50:48 --> Model Class Initialized
INFO - 2018-07-15 20:50:48 --> Final output sent to browser
DEBUG - 2018-07-15 20:50:48 --> Total execution time: 0.0780
ERROR - 2018-07-15 20:50:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:50:58 --> Config Class Initialized
INFO - 2018-07-15 20:50:58 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:50:58 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:50:58 --> Utf8 Class Initialized
INFO - 2018-07-15 20:50:58 --> URI Class Initialized
INFO - 2018-07-15 20:50:58 --> Router Class Initialized
INFO - 2018-07-15 20:50:58 --> Output Class Initialized
INFO - 2018-07-15 20:50:58 --> Security Class Initialized
DEBUG - 2018-07-15 20:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:50:58 --> Input Class Initialized
INFO - 2018-07-15 20:50:58 --> Language Class Initialized
INFO - 2018-07-15 20:50:58 --> Loader Class Initialized
INFO - 2018-07-15 20:50:58 --> Controller Class Initialized
INFO - 2018-07-15 20:50:58 --> Database Driver Class Initialized
INFO - 2018-07-15 20:50:58 --> Model Class Initialized
INFO - 2018-07-15 20:50:58 --> Helper loaded: url_helper
INFO - 2018-07-15 20:50:58 --> Model Class Initialized
INFO - 2018-07-15 20:50:58 --> Final output sent to browser
DEBUG - 2018-07-15 20:50:58 --> Total execution time: 0.0589
ERROR - 2018-07-15 20:51:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:51:35 --> Config Class Initialized
INFO - 2018-07-15 20:51:35 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:51:35 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:51:35 --> Utf8 Class Initialized
INFO - 2018-07-15 20:51:35 --> URI Class Initialized
INFO - 2018-07-15 20:51:35 --> Router Class Initialized
INFO - 2018-07-15 20:51:35 --> Output Class Initialized
INFO - 2018-07-15 20:51:35 --> Security Class Initialized
DEBUG - 2018-07-15 20:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:51:35 --> Input Class Initialized
INFO - 2018-07-15 20:51:35 --> Language Class Initialized
INFO - 2018-07-15 20:51:35 --> Loader Class Initialized
INFO - 2018-07-15 20:51:35 --> Controller Class Initialized
INFO - 2018-07-15 20:51:35 --> Database Driver Class Initialized
INFO - 2018-07-15 20:51:35 --> Model Class Initialized
INFO - 2018-07-15 20:51:35 --> Helper loaded: url_helper
INFO - 2018-07-15 20:51:35 --> Model Class Initialized
INFO - 2018-07-15 20:51:35 --> Final output sent to browser
DEBUG - 2018-07-15 20:51:35 --> Total execution time: 0.2513
ERROR - 2018-07-15 20:52:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:52:40 --> Config Class Initialized
INFO - 2018-07-15 20:52:40 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:52:40 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:52:40 --> Utf8 Class Initialized
INFO - 2018-07-15 20:52:40 --> URI Class Initialized
INFO - 2018-07-15 20:52:40 --> Router Class Initialized
INFO - 2018-07-15 20:52:40 --> Output Class Initialized
INFO - 2018-07-15 20:52:40 --> Security Class Initialized
DEBUG - 2018-07-15 20:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:52:40 --> Input Class Initialized
INFO - 2018-07-15 20:52:40 --> Language Class Initialized
INFO - 2018-07-15 20:52:40 --> Loader Class Initialized
INFO - 2018-07-15 20:52:40 --> Controller Class Initialized
INFO - 2018-07-15 20:52:40 --> Database Driver Class Initialized
INFO - 2018-07-15 20:52:40 --> Model Class Initialized
INFO - 2018-07-15 20:52:40 --> Helper loaded: url_helper
INFO - 2018-07-15 20:52:40 --> Model Class Initialized
ERROR - 2018-07-15 20:52:40 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 38
INFO - 2018-07-15 20:52:40 --> Final output sent to browser
DEBUG - 2018-07-15 20:52:40 --> Total execution time: 0.0547
ERROR - 2018-07-15 20:53:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:53:05 --> Config Class Initialized
INFO - 2018-07-15 20:53:05 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:53:05 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:53:05 --> Utf8 Class Initialized
INFO - 2018-07-15 20:53:05 --> URI Class Initialized
INFO - 2018-07-15 20:53:05 --> Router Class Initialized
INFO - 2018-07-15 20:53:05 --> Output Class Initialized
INFO - 2018-07-15 20:53:05 --> Security Class Initialized
DEBUG - 2018-07-15 20:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:53:05 --> Input Class Initialized
INFO - 2018-07-15 20:53:05 --> Language Class Initialized
INFO - 2018-07-15 20:53:05 --> Loader Class Initialized
INFO - 2018-07-15 20:53:05 --> Controller Class Initialized
INFO - 2018-07-15 20:53:05 --> Database Driver Class Initialized
INFO - 2018-07-15 20:53:05 --> Model Class Initialized
INFO - 2018-07-15 20:53:05 --> Helper loaded: url_helper
INFO - 2018-07-15 20:53:05 --> Model Class Initialized
INFO - 2018-07-15 20:53:06 --> Final output sent to browser
DEBUG - 2018-07-15 20:53:06 --> Total execution time: 0.1951
ERROR - 2018-07-15 20:54:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:54:29 --> Config Class Initialized
INFO - 2018-07-15 20:54:29 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:54:29 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:54:29 --> Utf8 Class Initialized
INFO - 2018-07-15 20:54:29 --> URI Class Initialized
INFO - 2018-07-15 20:54:29 --> Router Class Initialized
INFO - 2018-07-15 20:54:29 --> Output Class Initialized
INFO - 2018-07-15 20:54:29 --> Security Class Initialized
DEBUG - 2018-07-15 20:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:54:29 --> Input Class Initialized
INFO - 2018-07-15 20:54:29 --> Language Class Initialized
INFO - 2018-07-15 20:54:29 --> Loader Class Initialized
INFO - 2018-07-15 20:54:29 --> Controller Class Initialized
INFO - 2018-07-15 20:54:29 --> Database Driver Class Initialized
INFO - 2018-07-15 20:54:29 --> Model Class Initialized
INFO - 2018-07-15 20:54:29 --> Helper loaded: url_helper
INFO - 2018-07-15 20:54:29 --> Model Class Initialized
INFO - 2018-07-15 20:54:29 --> Final output sent to browser
DEBUG - 2018-07-15 20:54:29 --> Total execution time: 0.1512
ERROR - 2018-07-15 20:54:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:54:44 --> Config Class Initialized
INFO - 2018-07-15 20:54:44 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:54:44 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:54:44 --> Utf8 Class Initialized
INFO - 2018-07-15 20:54:44 --> URI Class Initialized
INFO - 2018-07-15 20:54:44 --> Router Class Initialized
INFO - 2018-07-15 20:54:44 --> Output Class Initialized
INFO - 2018-07-15 20:54:44 --> Security Class Initialized
DEBUG - 2018-07-15 20:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:54:44 --> Input Class Initialized
INFO - 2018-07-15 20:54:44 --> Language Class Initialized
INFO - 2018-07-15 20:54:44 --> Loader Class Initialized
INFO - 2018-07-15 20:54:44 --> Controller Class Initialized
INFO - 2018-07-15 20:54:44 --> Database Driver Class Initialized
INFO - 2018-07-15 20:54:44 --> Model Class Initialized
INFO - 2018-07-15 20:54:44 --> Helper loaded: url_helper
INFO - 2018-07-15 20:54:44 --> Model Class Initialized
INFO - 2018-07-15 20:54:44 --> Final output sent to browser
DEBUG - 2018-07-15 20:54:44 --> Total execution time: 0.0821
ERROR - 2018-07-15 20:54:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:54:44 --> Config Class Initialized
INFO - 2018-07-15 20:54:44 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:54:44 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:54:44 --> Utf8 Class Initialized
INFO - 2018-07-15 20:54:44 --> URI Class Initialized
INFO - 2018-07-15 20:54:44 --> Router Class Initialized
INFO - 2018-07-15 20:54:44 --> Output Class Initialized
INFO - 2018-07-15 20:54:44 --> Security Class Initialized
DEBUG - 2018-07-15 20:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:54:44 --> Input Class Initialized
INFO - 2018-07-15 20:54:44 --> Language Class Initialized
INFO - 2018-07-15 20:54:44 --> Loader Class Initialized
INFO - 2018-07-15 20:54:44 --> Controller Class Initialized
INFO - 2018-07-15 20:54:44 --> Database Driver Class Initialized
INFO - 2018-07-15 20:54:44 --> Model Class Initialized
INFO - 2018-07-15 20:54:44 --> Helper loaded: url_helper
INFO - 2018-07-15 20:54:44 --> Model Class Initialized
INFO - 2018-07-15 20:54:44 --> Final output sent to browser
DEBUG - 2018-07-15 20:54:44 --> Total execution time: 0.0571
ERROR - 2018-07-15 20:54:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:54:44 --> Config Class Initialized
INFO - 2018-07-15 20:54:44 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:54:44 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:54:44 --> Utf8 Class Initialized
INFO - 2018-07-15 20:54:44 --> URI Class Initialized
INFO - 2018-07-15 20:54:44 --> Router Class Initialized
INFO - 2018-07-15 20:54:44 --> Output Class Initialized
INFO - 2018-07-15 20:54:44 --> Security Class Initialized
DEBUG - 2018-07-15 20:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:54:44 --> Input Class Initialized
INFO - 2018-07-15 20:54:44 --> Language Class Initialized
INFO - 2018-07-15 20:54:44 --> Loader Class Initialized
INFO - 2018-07-15 20:54:44 --> Controller Class Initialized
INFO - 2018-07-15 20:54:44 --> Database Driver Class Initialized
INFO - 2018-07-15 20:54:44 --> Model Class Initialized
INFO - 2018-07-15 20:54:44 --> Helper loaded: url_helper
INFO - 2018-07-15 20:54:44 --> Model Class Initialized
INFO - 2018-07-15 20:54:44 --> Final output sent to browser
DEBUG - 2018-07-15 20:54:44 --> Total execution time: 0.0341
ERROR - 2018-07-15 20:55:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:55:46 --> Config Class Initialized
INFO - 2018-07-15 20:55:46 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:55:46 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:55:46 --> Utf8 Class Initialized
INFO - 2018-07-15 20:55:46 --> URI Class Initialized
INFO - 2018-07-15 20:55:46 --> Router Class Initialized
INFO - 2018-07-15 20:55:46 --> Output Class Initialized
INFO - 2018-07-15 20:55:46 --> Security Class Initialized
DEBUG - 2018-07-15 20:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:55:46 --> Input Class Initialized
INFO - 2018-07-15 20:55:46 --> Language Class Initialized
INFO - 2018-07-15 20:55:46 --> Loader Class Initialized
INFO - 2018-07-15 20:55:46 --> Controller Class Initialized
INFO - 2018-07-15 20:55:46 --> Database Driver Class Initialized
INFO - 2018-07-15 20:55:46 --> Model Class Initialized
INFO - 2018-07-15 20:55:46 --> Helper loaded: url_helper
INFO - 2018-07-15 20:55:46 --> Model Class Initialized
INFO - 2018-07-15 20:55:46 --> Final output sent to browser
DEBUG - 2018-07-15 20:55:46 --> Total execution time: 0.1786
ERROR - 2018-07-15 20:56:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:56:25 --> Config Class Initialized
INFO - 2018-07-15 20:56:25 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:56:25 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:56:25 --> Utf8 Class Initialized
INFO - 2018-07-15 20:56:25 --> URI Class Initialized
INFO - 2018-07-15 20:56:25 --> Router Class Initialized
INFO - 2018-07-15 20:56:25 --> Output Class Initialized
INFO - 2018-07-15 20:56:25 --> Security Class Initialized
DEBUG - 2018-07-15 20:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:56:25 --> Input Class Initialized
INFO - 2018-07-15 20:56:25 --> Language Class Initialized
INFO - 2018-07-15 20:56:25 --> Loader Class Initialized
INFO - 2018-07-15 20:56:25 --> Controller Class Initialized
INFO - 2018-07-15 20:56:25 --> Database Driver Class Initialized
INFO - 2018-07-15 20:56:25 --> Model Class Initialized
INFO - 2018-07-15 20:56:25 --> Helper loaded: url_helper
INFO - 2018-07-15 20:56:25 --> Model Class Initialized
INFO - 2018-07-15 20:56:25 --> Final output sent to browser
DEBUG - 2018-07-15 20:56:25 --> Total execution time: 0.1703
ERROR - 2018-07-15 20:56:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:56:42 --> Config Class Initialized
INFO - 2018-07-15 20:56:42 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:56:42 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:56:42 --> Utf8 Class Initialized
INFO - 2018-07-15 20:56:42 --> URI Class Initialized
INFO - 2018-07-15 20:56:42 --> Router Class Initialized
INFO - 2018-07-15 20:56:42 --> Output Class Initialized
INFO - 2018-07-15 20:56:42 --> Security Class Initialized
DEBUG - 2018-07-15 20:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:56:42 --> Input Class Initialized
INFO - 2018-07-15 20:56:42 --> Language Class Initialized
INFO - 2018-07-15 20:56:42 --> Loader Class Initialized
INFO - 2018-07-15 20:56:42 --> Controller Class Initialized
INFO - 2018-07-15 20:56:42 --> Database Driver Class Initialized
INFO - 2018-07-15 20:56:42 --> Model Class Initialized
INFO - 2018-07-15 20:56:42 --> Helper loaded: url_helper
INFO - 2018-07-15 20:56:42 --> Model Class Initialized
INFO - 2018-07-15 20:56:42 --> Final output sent to browser
DEBUG - 2018-07-15 20:56:42 --> Total execution time: 0.1655
ERROR - 2018-07-15 20:59:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:59:43 --> Config Class Initialized
INFO - 2018-07-15 20:59:43 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:59:43 --> Utf8 Class Initialized
INFO - 2018-07-15 20:59:43 --> URI Class Initialized
INFO - 2018-07-15 20:59:43 --> Router Class Initialized
INFO - 2018-07-15 20:59:43 --> Output Class Initialized
INFO - 2018-07-15 20:59:43 --> Security Class Initialized
DEBUG - 2018-07-15 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:59:43 --> Input Class Initialized
INFO - 2018-07-15 20:59:43 --> Language Class Initialized
INFO - 2018-07-15 20:59:43 --> Loader Class Initialized
INFO - 2018-07-15 20:59:43 --> Controller Class Initialized
INFO - 2018-07-15 20:59:43 --> Database Driver Class Initialized
INFO - 2018-07-15 20:59:43 --> Model Class Initialized
INFO - 2018-07-15 20:59:43 --> Helper loaded: url_helper
INFO - 2018-07-15 20:59:43 --> Model Class Initialized
INFO - 2018-07-15 20:59:43 --> Final output sent to browser
DEBUG - 2018-07-15 20:59:43 --> Total execution time: 0.0576
ERROR - 2018-07-15 20:59:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:59:43 --> Config Class Initialized
INFO - 2018-07-15 20:59:43 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:59:43 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:59:43 --> Utf8 Class Initialized
INFO - 2018-07-15 20:59:43 --> URI Class Initialized
INFO - 2018-07-15 20:59:43 --> Router Class Initialized
INFO - 2018-07-15 20:59:43 --> Output Class Initialized
INFO - 2018-07-15 20:59:43 --> Security Class Initialized
DEBUG - 2018-07-15 20:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:59:43 --> Input Class Initialized
INFO - 2018-07-15 20:59:44 --> Language Class Initialized
INFO - 2018-07-15 20:59:44 --> Loader Class Initialized
INFO - 2018-07-15 20:59:44 --> Controller Class Initialized
INFO - 2018-07-15 20:59:44 --> Database Driver Class Initialized
INFO - 2018-07-15 20:59:44 --> Model Class Initialized
INFO - 2018-07-15 20:59:44 --> Helper loaded: url_helper
INFO - 2018-07-15 20:59:44 --> Model Class Initialized
INFO - 2018-07-15 20:59:44 --> Final output sent to browser
DEBUG - 2018-07-15 20:59:44 --> Total execution time: 0.0487
ERROR - 2018-07-15 20:59:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 20:59:44 --> Config Class Initialized
INFO - 2018-07-15 20:59:44 --> Hooks Class Initialized
DEBUG - 2018-07-15 20:59:44 --> UTF-8 Support Enabled
INFO - 2018-07-15 20:59:44 --> Utf8 Class Initialized
INFO - 2018-07-15 20:59:44 --> URI Class Initialized
INFO - 2018-07-15 20:59:44 --> Router Class Initialized
INFO - 2018-07-15 20:59:44 --> Output Class Initialized
INFO - 2018-07-15 20:59:44 --> Security Class Initialized
DEBUG - 2018-07-15 20:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 20:59:44 --> Input Class Initialized
INFO - 2018-07-15 20:59:44 --> Language Class Initialized
INFO - 2018-07-15 20:59:44 --> Loader Class Initialized
INFO - 2018-07-15 20:59:44 --> Controller Class Initialized
INFO - 2018-07-15 20:59:44 --> Database Driver Class Initialized
INFO - 2018-07-15 20:59:44 --> Model Class Initialized
INFO - 2018-07-15 20:59:44 --> Helper loaded: url_helper
INFO - 2018-07-15 20:59:44 --> Model Class Initialized
INFO - 2018-07-15 20:59:44 --> Final output sent to browser
DEBUG - 2018-07-15 20:59:44 --> Total execution time: 0.0387
ERROR - 2018-07-15 21:12:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:12:52 --> Config Class Initialized
INFO - 2018-07-15 21:12:52 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:12:52 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:12:52 --> Utf8 Class Initialized
INFO - 2018-07-15 21:12:52 --> URI Class Initialized
INFO - 2018-07-15 21:12:52 --> Router Class Initialized
INFO - 2018-07-15 21:12:52 --> Output Class Initialized
INFO - 2018-07-15 21:12:52 --> Security Class Initialized
DEBUG - 2018-07-15 21:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:12:52 --> Input Class Initialized
INFO - 2018-07-15 21:12:52 --> Language Class Initialized
INFO - 2018-07-15 21:12:52 --> Loader Class Initialized
INFO - 2018-07-15 21:12:52 --> Controller Class Initialized
INFO - 2018-07-15 21:12:52 --> Database Driver Class Initialized
INFO - 2018-07-15 21:12:52 --> Model Class Initialized
INFO - 2018-07-15 21:12:52 --> Helper loaded: url_helper
INFO - 2018-07-15 21:12:52 --> Model Class Initialized
INFO - 2018-07-15 21:12:52 --> Final output sent to browser
DEBUG - 2018-07-15 21:12:52 --> Total execution time: 0.0588
ERROR - 2018-07-15 21:12:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:12:52 --> Config Class Initialized
INFO - 2018-07-15 21:12:52 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:12:52 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:12:52 --> Utf8 Class Initialized
INFO - 2018-07-15 21:12:52 --> URI Class Initialized
INFO - 2018-07-15 21:12:52 --> Router Class Initialized
INFO - 2018-07-15 21:12:52 --> Output Class Initialized
INFO - 2018-07-15 21:12:52 --> Security Class Initialized
DEBUG - 2018-07-15 21:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:12:52 --> Input Class Initialized
INFO - 2018-07-15 21:12:52 --> Language Class Initialized
INFO - 2018-07-15 21:12:52 --> Loader Class Initialized
INFO - 2018-07-15 21:12:52 --> Controller Class Initialized
INFO - 2018-07-15 21:12:52 --> Database Driver Class Initialized
INFO - 2018-07-15 21:12:52 --> Model Class Initialized
INFO - 2018-07-15 21:12:52 --> Helper loaded: url_helper
INFO - 2018-07-15 21:12:52 --> Model Class Initialized
INFO - 2018-07-15 21:12:52 --> Final output sent to browser
DEBUG - 2018-07-15 21:12:52 --> Total execution time: 0.0361
ERROR - 2018-07-15 21:12:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:12:52 --> Config Class Initialized
INFO - 2018-07-15 21:12:52 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:12:52 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:12:52 --> Utf8 Class Initialized
INFO - 2018-07-15 21:12:52 --> URI Class Initialized
INFO - 2018-07-15 21:12:52 --> Router Class Initialized
INFO - 2018-07-15 21:12:52 --> Output Class Initialized
INFO - 2018-07-15 21:12:52 --> Security Class Initialized
DEBUG - 2018-07-15 21:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:12:52 --> Input Class Initialized
INFO - 2018-07-15 21:12:52 --> Language Class Initialized
INFO - 2018-07-15 21:12:52 --> Loader Class Initialized
INFO - 2018-07-15 21:12:52 --> Controller Class Initialized
INFO - 2018-07-15 21:12:52 --> Database Driver Class Initialized
INFO - 2018-07-15 21:12:52 --> Model Class Initialized
INFO - 2018-07-15 21:12:52 --> Helper loaded: url_helper
INFO - 2018-07-15 21:12:52 --> Model Class Initialized
INFO - 2018-07-15 21:12:52 --> Final output sent to browser
DEBUG - 2018-07-15 21:12:52 --> Total execution time: 0.0485
ERROR - 2018-07-15 21:14:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:14:53 --> Config Class Initialized
INFO - 2018-07-15 21:14:53 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:14:53 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:14:53 --> Utf8 Class Initialized
INFO - 2018-07-15 21:14:53 --> URI Class Initialized
INFO - 2018-07-15 21:14:53 --> Router Class Initialized
INFO - 2018-07-15 21:14:53 --> Output Class Initialized
INFO - 2018-07-15 21:14:53 --> Security Class Initialized
DEBUG - 2018-07-15 21:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:14:53 --> Input Class Initialized
INFO - 2018-07-15 21:14:53 --> Language Class Initialized
INFO - 2018-07-15 21:14:53 --> Loader Class Initialized
INFO - 2018-07-15 21:14:53 --> Controller Class Initialized
INFO - 2018-07-15 21:14:53 --> Database Driver Class Initialized
INFO - 2018-07-15 21:14:53 --> Model Class Initialized
INFO - 2018-07-15 21:14:53 --> Helper loaded: url_helper
INFO - 2018-07-15 21:14:53 --> Model Class Initialized
INFO - 2018-07-15 21:14:53 --> Final output sent to browser
DEBUG - 2018-07-15 21:14:53 --> Total execution time: 0.0590
ERROR - 2018-07-15 21:14:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:14:55 --> Config Class Initialized
INFO - 2018-07-15 21:14:55 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:14:55 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:14:55 --> Utf8 Class Initialized
INFO - 2018-07-15 21:14:55 --> URI Class Initialized
INFO - 2018-07-15 21:14:55 --> Router Class Initialized
INFO - 2018-07-15 21:14:55 --> Output Class Initialized
INFO - 2018-07-15 21:14:55 --> Security Class Initialized
DEBUG - 2018-07-15 21:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:14:55 --> Input Class Initialized
INFO - 2018-07-15 21:14:55 --> Language Class Initialized
INFO - 2018-07-15 21:14:55 --> Loader Class Initialized
INFO - 2018-07-15 21:14:55 --> Controller Class Initialized
INFO - 2018-07-15 21:14:55 --> Database Driver Class Initialized
INFO - 2018-07-15 21:14:55 --> Model Class Initialized
INFO - 2018-07-15 21:14:55 --> Helper loaded: url_helper
INFO - 2018-07-15 21:14:55 --> Model Class Initialized
INFO - 2018-07-15 21:14:55 --> Final output sent to browser
DEBUG - 2018-07-15 21:14:55 --> Total execution time: 0.0444
ERROR - 2018-07-15 21:14:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:14:55 --> Config Class Initialized
INFO - 2018-07-15 21:14:55 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:14:55 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:14:55 --> Utf8 Class Initialized
INFO - 2018-07-15 21:14:55 --> URI Class Initialized
INFO - 2018-07-15 21:14:55 --> Router Class Initialized
INFO - 2018-07-15 21:14:55 --> Output Class Initialized
INFO - 2018-07-15 21:14:55 --> Security Class Initialized
DEBUG - 2018-07-15 21:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:14:55 --> Input Class Initialized
INFO - 2018-07-15 21:14:55 --> Language Class Initialized
INFO - 2018-07-15 21:14:55 --> Loader Class Initialized
INFO - 2018-07-15 21:14:55 --> Controller Class Initialized
INFO - 2018-07-15 21:14:55 --> Database Driver Class Initialized
INFO - 2018-07-15 21:14:55 --> Model Class Initialized
INFO - 2018-07-15 21:14:55 --> Helper loaded: url_helper
INFO - 2018-07-15 21:14:55 --> Model Class Initialized
INFO - 2018-07-15 21:14:55 --> Final output sent to browser
DEBUG - 2018-07-15 21:14:55 --> Total execution time: 0.0470
ERROR - 2018-07-15 21:21:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:21:53 --> Config Class Initialized
INFO - 2018-07-15 21:21:53 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:21:53 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:21:53 --> Utf8 Class Initialized
INFO - 2018-07-15 21:21:53 --> URI Class Initialized
INFO - 2018-07-15 21:21:53 --> Router Class Initialized
INFO - 2018-07-15 21:21:53 --> Output Class Initialized
INFO - 2018-07-15 21:21:53 --> Security Class Initialized
DEBUG - 2018-07-15 21:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:21:53 --> Input Class Initialized
INFO - 2018-07-15 21:21:53 --> Language Class Initialized
INFO - 2018-07-15 21:21:53 --> Loader Class Initialized
INFO - 2018-07-15 21:21:53 --> Controller Class Initialized
INFO - 2018-07-15 21:21:53 --> Database Driver Class Initialized
INFO - 2018-07-15 21:21:53 --> Model Class Initialized
INFO - 2018-07-15 21:21:53 --> Helper loaded: url_helper
INFO - 2018-07-15 21:21:53 --> Model Class Initialized
INFO - 2018-07-15 21:21:53 --> Final output sent to browser
DEBUG - 2018-07-15 21:21:53 --> Total execution time: 0.0511
ERROR - 2018-07-15 21:22:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:22:36 --> Config Class Initialized
INFO - 2018-07-15 21:22:36 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:22:36 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:22:36 --> Utf8 Class Initialized
INFO - 2018-07-15 21:22:36 --> URI Class Initialized
INFO - 2018-07-15 21:22:36 --> Router Class Initialized
INFO - 2018-07-15 21:22:36 --> Output Class Initialized
INFO - 2018-07-15 21:22:36 --> Security Class Initialized
DEBUG - 2018-07-15 21:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:22:36 --> Input Class Initialized
INFO - 2018-07-15 21:22:36 --> Language Class Initialized
INFO - 2018-07-15 21:22:36 --> Loader Class Initialized
INFO - 2018-07-15 21:22:36 --> Controller Class Initialized
INFO - 2018-07-15 21:22:36 --> Database Driver Class Initialized
INFO - 2018-07-15 21:22:36 --> Model Class Initialized
INFO - 2018-07-15 21:22:36 --> Helper loaded: url_helper
INFO - 2018-07-15 21:22:36 --> Model Class Initialized
INFO - 2018-07-15 21:22:36 --> Final output sent to browser
DEBUG - 2018-07-15 21:22:36 --> Total execution time: 0.0399
ERROR - 2018-07-15 21:22:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:22:37 --> Config Class Initialized
INFO - 2018-07-15 21:22:37 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:22:37 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:22:37 --> Utf8 Class Initialized
INFO - 2018-07-15 21:22:37 --> URI Class Initialized
INFO - 2018-07-15 21:22:37 --> Router Class Initialized
INFO - 2018-07-15 21:22:37 --> Output Class Initialized
INFO - 2018-07-15 21:22:37 --> Security Class Initialized
DEBUG - 2018-07-15 21:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:22:37 --> Input Class Initialized
INFO - 2018-07-15 21:22:37 --> Language Class Initialized
INFO - 2018-07-15 21:22:37 --> Loader Class Initialized
INFO - 2018-07-15 21:22:37 --> Controller Class Initialized
INFO - 2018-07-15 21:22:37 --> Database Driver Class Initialized
INFO - 2018-07-15 21:22:38 --> Model Class Initialized
INFO - 2018-07-15 21:22:38 --> Helper loaded: url_helper
INFO - 2018-07-15 21:22:38 --> Model Class Initialized
INFO - 2018-07-15 21:22:38 --> Final output sent to browser
DEBUG - 2018-07-15 21:22:38 --> Total execution time: 0.0391
ERROR - 2018-07-15 21:22:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:22:38 --> Config Class Initialized
INFO - 2018-07-15 21:22:38 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:22:38 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:22:38 --> Utf8 Class Initialized
INFO - 2018-07-15 21:22:38 --> URI Class Initialized
INFO - 2018-07-15 21:22:38 --> Router Class Initialized
INFO - 2018-07-15 21:22:38 --> Output Class Initialized
INFO - 2018-07-15 21:22:38 --> Security Class Initialized
DEBUG - 2018-07-15 21:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:22:38 --> Input Class Initialized
INFO - 2018-07-15 21:22:38 --> Language Class Initialized
INFO - 2018-07-15 21:22:38 --> Loader Class Initialized
INFO - 2018-07-15 21:22:38 --> Controller Class Initialized
INFO - 2018-07-15 21:22:38 --> Database Driver Class Initialized
INFO - 2018-07-15 21:22:38 --> Model Class Initialized
INFO - 2018-07-15 21:22:38 --> Helper loaded: url_helper
INFO - 2018-07-15 21:22:38 --> Model Class Initialized
INFO - 2018-07-15 21:22:38 --> Final output sent to browser
DEBUG - 2018-07-15 21:22:38 --> Total execution time: 0.0450
ERROR - 2018-07-15 21:23:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:23:16 --> Config Class Initialized
INFO - 2018-07-15 21:23:16 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:23:16 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:23:16 --> Utf8 Class Initialized
INFO - 2018-07-15 21:23:16 --> URI Class Initialized
INFO - 2018-07-15 21:23:16 --> Router Class Initialized
INFO - 2018-07-15 21:23:16 --> Output Class Initialized
INFO - 2018-07-15 21:23:16 --> Security Class Initialized
DEBUG - 2018-07-15 21:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:23:16 --> Input Class Initialized
INFO - 2018-07-15 21:23:16 --> Language Class Initialized
INFO - 2018-07-15 21:23:16 --> Loader Class Initialized
INFO - 2018-07-15 21:23:16 --> Controller Class Initialized
INFO - 2018-07-15 21:23:16 --> Database Driver Class Initialized
INFO - 2018-07-15 21:23:16 --> Model Class Initialized
INFO - 2018-07-15 21:23:16 --> Helper loaded: url_helper
INFO - 2018-07-15 21:23:16 --> Model Class Initialized
INFO - 2018-07-15 21:23:16 --> Final output sent to browser
DEBUG - 2018-07-15 21:23:16 --> Total execution time: 0.0418
ERROR - 2018-07-15 21:23:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:23:17 --> Config Class Initialized
INFO - 2018-07-15 21:23:17 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:23:17 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:23:17 --> Utf8 Class Initialized
INFO - 2018-07-15 21:23:17 --> URI Class Initialized
INFO - 2018-07-15 21:23:17 --> Router Class Initialized
INFO - 2018-07-15 21:23:17 --> Output Class Initialized
INFO - 2018-07-15 21:23:17 --> Security Class Initialized
DEBUG - 2018-07-15 21:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:23:17 --> Input Class Initialized
INFO - 2018-07-15 21:23:17 --> Language Class Initialized
INFO - 2018-07-15 21:23:17 --> Loader Class Initialized
INFO - 2018-07-15 21:23:17 --> Controller Class Initialized
INFO - 2018-07-15 21:23:17 --> Database Driver Class Initialized
INFO - 2018-07-15 21:23:17 --> Model Class Initialized
INFO - 2018-07-15 21:23:17 --> Helper loaded: url_helper
INFO - 2018-07-15 21:23:17 --> Model Class Initialized
INFO - 2018-07-15 21:23:17 --> Final output sent to browser
DEBUG - 2018-07-15 21:23:17 --> Total execution time: 0.0416
ERROR - 2018-07-15 21:23:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:23:17 --> Config Class Initialized
INFO - 2018-07-15 21:23:17 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:23:17 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:23:17 --> Utf8 Class Initialized
INFO - 2018-07-15 21:23:17 --> URI Class Initialized
INFO - 2018-07-15 21:23:17 --> Router Class Initialized
INFO - 2018-07-15 21:23:17 --> Output Class Initialized
INFO - 2018-07-15 21:23:17 --> Security Class Initialized
DEBUG - 2018-07-15 21:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:23:17 --> Input Class Initialized
INFO - 2018-07-15 21:23:17 --> Language Class Initialized
INFO - 2018-07-15 21:23:17 --> Loader Class Initialized
INFO - 2018-07-15 21:23:17 --> Controller Class Initialized
INFO - 2018-07-15 21:23:17 --> Database Driver Class Initialized
INFO - 2018-07-15 21:23:17 --> Model Class Initialized
INFO - 2018-07-15 21:23:17 --> Helper loaded: url_helper
INFO - 2018-07-15 21:23:17 --> Model Class Initialized
INFO - 2018-07-15 21:23:17 --> Final output sent to browser
DEBUG - 2018-07-15 21:23:17 --> Total execution time: 0.0435
ERROR - 2018-07-15 21:24:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:24:34 --> Config Class Initialized
INFO - 2018-07-15 21:24:34 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:24:34 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:24:34 --> Utf8 Class Initialized
INFO - 2018-07-15 21:24:34 --> URI Class Initialized
INFO - 2018-07-15 21:24:34 --> Router Class Initialized
INFO - 2018-07-15 21:24:34 --> Output Class Initialized
INFO - 2018-07-15 21:24:34 --> Security Class Initialized
DEBUG - 2018-07-15 21:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:24:34 --> Input Class Initialized
INFO - 2018-07-15 21:24:34 --> Language Class Initialized
INFO - 2018-07-15 21:24:34 --> Loader Class Initialized
INFO - 2018-07-15 21:24:34 --> Controller Class Initialized
INFO - 2018-07-15 21:24:34 --> Database Driver Class Initialized
INFO - 2018-07-15 21:24:34 --> Model Class Initialized
INFO - 2018-07-15 21:24:34 --> Helper loaded: url_helper
INFO - 2018-07-15 21:24:34 --> Model Class Initialized
INFO - 2018-07-15 21:24:34 --> Final output sent to browser
DEBUG - 2018-07-15 21:24:34 --> Total execution time: 0.1440
ERROR - 2018-07-15 21:26:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:26:00 --> Config Class Initialized
INFO - 2018-07-15 21:26:00 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:26:00 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:26:00 --> Utf8 Class Initialized
INFO - 2018-07-15 21:26:00 --> URI Class Initialized
INFO - 2018-07-15 21:26:00 --> Router Class Initialized
INFO - 2018-07-15 21:26:00 --> Output Class Initialized
INFO - 2018-07-15 21:26:00 --> Security Class Initialized
DEBUG - 2018-07-15 21:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:26:00 --> Input Class Initialized
INFO - 2018-07-15 21:26:00 --> Language Class Initialized
INFO - 2018-07-15 21:26:00 --> Loader Class Initialized
INFO - 2018-07-15 21:26:00 --> Controller Class Initialized
INFO - 2018-07-15 21:26:00 --> Database Driver Class Initialized
INFO - 2018-07-15 21:26:00 --> Model Class Initialized
INFO - 2018-07-15 21:26:00 --> Helper loaded: url_helper
INFO - 2018-07-15 21:26:00 --> Model Class Initialized
INFO - 2018-07-15 21:26:00 --> Final output sent to browser
DEBUG - 2018-07-15 21:26:00 --> Total execution time: 0.0468
ERROR - 2018-07-15 21:26:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:26:08 --> Config Class Initialized
INFO - 2018-07-15 21:26:08 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:26:08 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:26:08 --> Utf8 Class Initialized
INFO - 2018-07-15 21:26:08 --> URI Class Initialized
INFO - 2018-07-15 21:26:08 --> Router Class Initialized
INFO - 2018-07-15 21:26:08 --> Output Class Initialized
INFO - 2018-07-15 21:26:08 --> Security Class Initialized
DEBUG - 2018-07-15 21:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:26:08 --> Input Class Initialized
INFO - 2018-07-15 21:26:08 --> Language Class Initialized
INFO - 2018-07-15 21:26:08 --> Loader Class Initialized
INFO - 2018-07-15 21:26:08 --> Controller Class Initialized
INFO - 2018-07-15 21:26:08 --> Database Driver Class Initialized
INFO - 2018-07-15 21:26:08 --> Model Class Initialized
INFO - 2018-07-15 21:26:08 --> Helper loaded: url_helper
INFO - 2018-07-15 21:26:08 --> Model Class Initialized
INFO - 2018-07-15 21:26:08 --> Final output sent to browser
DEBUG - 2018-07-15 21:26:08 --> Total execution time: 0.0528
ERROR - 2018-07-15 21:26:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:26:12 --> Config Class Initialized
INFO - 2018-07-15 21:26:12 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:26:12 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:26:12 --> Utf8 Class Initialized
INFO - 2018-07-15 21:26:12 --> URI Class Initialized
INFO - 2018-07-15 21:26:12 --> Router Class Initialized
INFO - 2018-07-15 21:26:12 --> Output Class Initialized
INFO - 2018-07-15 21:26:12 --> Security Class Initialized
DEBUG - 2018-07-15 21:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:26:12 --> Input Class Initialized
INFO - 2018-07-15 21:26:12 --> Language Class Initialized
INFO - 2018-07-15 21:26:12 --> Loader Class Initialized
INFO - 2018-07-15 21:26:12 --> Controller Class Initialized
INFO - 2018-07-15 21:26:12 --> Database Driver Class Initialized
INFO - 2018-07-15 21:26:12 --> Model Class Initialized
INFO - 2018-07-15 21:26:12 --> Helper loaded: url_helper
INFO - 2018-07-15 21:26:12 --> Model Class Initialized
INFO - 2018-07-15 21:26:12 --> Final output sent to browser
DEBUG - 2018-07-15 21:26:12 --> Total execution time: 0.0406
ERROR - 2018-07-15 21:28:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:28:20 --> Config Class Initialized
INFO - 2018-07-15 21:28:20 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:28:20 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:28:20 --> Utf8 Class Initialized
INFO - 2018-07-15 21:28:20 --> URI Class Initialized
INFO - 2018-07-15 21:28:20 --> Router Class Initialized
INFO - 2018-07-15 21:28:20 --> Output Class Initialized
INFO - 2018-07-15 21:28:20 --> Security Class Initialized
DEBUG - 2018-07-15 21:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:28:20 --> Input Class Initialized
INFO - 2018-07-15 21:28:20 --> Language Class Initialized
INFO - 2018-07-15 21:28:20 --> Loader Class Initialized
INFO - 2018-07-15 21:28:20 --> Controller Class Initialized
INFO - 2018-07-15 21:28:20 --> Database Driver Class Initialized
INFO - 2018-07-15 21:28:20 --> Model Class Initialized
INFO - 2018-07-15 21:28:20 --> Helper loaded: url_helper
INFO - 2018-07-15 21:28:20 --> Model Class Initialized
INFO - 2018-07-15 21:28:20 --> Final output sent to browser
DEBUG - 2018-07-15 21:28:20 --> Total execution time: 0.0388
ERROR - 2018-07-15 21:32:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:32:06 --> Config Class Initialized
INFO - 2018-07-15 21:32:06 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:32:06 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:32:06 --> Utf8 Class Initialized
INFO - 2018-07-15 21:32:06 --> URI Class Initialized
INFO - 2018-07-15 21:32:06 --> Router Class Initialized
INFO - 2018-07-15 21:32:06 --> Output Class Initialized
INFO - 2018-07-15 21:32:06 --> Security Class Initialized
DEBUG - 2018-07-15 21:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:32:06 --> Input Class Initialized
INFO - 2018-07-15 21:32:06 --> Language Class Initialized
INFO - 2018-07-15 21:32:06 --> Loader Class Initialized
INFO - 2018-07-15 21:32:06 --> Controller Class Initialized
INFO - 2018-07-15 21:32:06 --> Database Driver Class Initialized
INFO - 2018-07-15 21:32:06 --> Model Class Initialized
INFO - 2018-07-15 21:32:06 --> Helper loaded: url_helper
INFO - 2018-07-15 21:32:06 --> Model Class Initialized
INFO - 2018-07-15 21:32:06 --> Final output sent to browser
DEBUG - 2018-07-15 21:32:06 --> Total execution time: 0.0402
ERROR - 2018-07-15 21:32:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:32:08 --> Config Class Initialized
INFO - 2018-07-15 21:32:08 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:32:08 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:32:08 --> Utf8 Class Initialized
INFO - 2018-07-15 21:32:08 --> URI Class Initialized
INFO - 2018-07-15 21:32:08 --> Router Class Initialized
INFO - 2018-07-15 21:32:08 --> Output Class Initialized
INFO - 2018-07-15 21:32:08 --> Security Class Initialized
DEBUG - 2018-07-15 21:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:32:08 --> Input Class Initialized
INFO - 2018-07-15 21:32:08 --> Language Class Initialized
INFO - 2018-07-15 21:32:08 --> Loader Class Initialized
INFO - 2018-07-15 21:32:08 --> Controller Class Initialized
INFO - 2018-07-15 21:32:08 --> Database Driver Class Initialized
INFO - 2018-07-15 21:32:08 --> Model Class Initialized
INFO - 2018-07-15 21:32:08 --> Helper loaded: url_helper
INFO - 2018-07-15 21:32:08 --> Model Class Initialized
INFO - 2018-07-15 21:32:08 --> Final output sent to browser
DEBUG - 2018-07-15 21:32:08 --> Total execution time: 0.0386
ERROR - 2018-07-15 21:32:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:32:08 --> Config Class Initialized
INFO - 2018-07-15 21:32:08 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:32:08 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:32:08 --> Utf8 Class Initialized
INFO - 2018-07-15 21:32:08 --> URI Class Initialized
INFO - 2018-07-15 21:32:08 --> Router Class Initialized
INFO - 2018-07-15 21:32:08 --> Output Class Initialized
INFO - 2018-07-15 21:32:08 --> Security Class Initialized
DEBUG - 2018-07-15 21:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:32:08 --> Input Class Initialized
INFO - 2018-07-15 21:32:08 --> Language Class Initialized
INFO - 2018-07-15 21:32:08 --> Loader Class Initialized
INFO - 2018-07-15 21:32:08 --> Controller Class Initialized
INFO - 2018-07-15 21:32:08 --> Database Driver Class Initialized
INFO - 2018-07-15 21:32:08 --> Model Class Initialized
INFO - 2018-07-15 21:32:08 --> Helper loaded: url_helper
INFO - 2018-07-15 21:32:08 --> Model Class Initialized
INFO - 2018-07-15 21:32:08 --> Final output sent to browser
DEBUG - 2018-07-15 21:32:08 --> Total execution time: 0.0493
ERROR - 2018-07-15 21:32:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:32:34 --> Config Class Initialized
INFO - 2018-07-15 21:32:34 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:32:34 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:32:34 --> Utf8 Class Initialized
INFO - 2018-07-15 21:32:34 --> URI Class Initialized
INFO - 2018-07-15 21:32:34 --> Router Class Initialized
INFO - 2018-07-15 21:32:34 --> Output Class Initialized
INFO - 2018-07-15 21:32:34 --> Security Class Initialized
DEBUG - 2018-07-15 21:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:32:34 --> Input Class Initialized
INFO - 2018-07-15 21:32:34 --> Language Class Initialized
INFO - 2018-07-15 21:32:34 --> Loader Class Initialized
INFO - 2018-07-15 21:32:34 --> Controller Class Initialized
INFO - 2018-07-15 21:32:34 --> Database Driver Class Initialized
INFO - 2018-07-15 21:32:34 --> Model Class Initialized
INFO - 2018-07-15 21:32:34 --> Helper loaded: url_helper
INFO - 2018-07-15 21:32:34 --> Model Class Initialized
INFO - 2018-07-15 21:32:34 --> Final output sent to browser
DEBUG - 2018-07-15 21:32:34 --> Total execution time: 0.1578
ERROR - 2018-07-15 21:32:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:32:43 --> Config Class Initialized
INFO - 2018-07-15 21:32:43 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:32:43 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:32:43 --> Utf8 Class Initialized
INFO - 2018-07-15 21:32:43 --> URI Class Initialized
INFO - 2018-07-15 21:32:43 --> Router Class Initialized
INFO - 2018-07-15 21:32:43 --> Output Class Initialized
INFO - 2018-07-15 21:32:43 --> Security Class Initialized
DEBUG - 2018-07-15 21:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:32:43 --> Input Class Initialized
INFO - 2018-07-15 21:32:43 --> Language Class Initialized
INFO - 2018-07-15 21:32:43 --> Loader Class Initialized
INFO - 2018-07-15 21:32:43 --> Controller Class Initialized
INFO - 2018-07-15 21:32:43 --> Database Driver Class Initialized
INFO - 2018-07-15 21:32:43 --> Model Class Initialized
INFO - 2018-07-15 21:32:43 --> Helper loaded: url_helper
INFO - 2018-07-15 21:32:43 --> Model Class Initialized
INFO - 2018-07-15 21:32:43 --> Final output sent to browser
DEBUG - 2018-07-15 21:32:43 --> Total execution time: 0.0457
ERROR - 2018-07-15 21:33:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 21:33:17 --> Config Class Initialized
INFO - 2018-07-15 21:33:17 --> Hooks Class Initialized
DEBUG - 2018-07-15 21:33:17 --> UTF-8 Support Enabled
INFO - 2018-07-15 21:33:17 --> Utf8 Class Initialized
INFO - 2018-07-15 21:33:17 --> URI Class Initialized
INFO - 2018-07-15 21:33:17 --> Router Class Initialized
INFO - 2018-07-15 21:33:17 --> Output Class Initialized
INFO - 2018-07-15 21:33:17 --> Security Class Initialized
DEBUG - 2018-07-15 21:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 21:33:17 --> Input Class Initialized
INFO - 2018-07-15 21:33:17 --> Language Class Initialized
INFO - 2018-07-15 21:33:17 --> Loader Class Initialized
INFO - 2018-07-15 21:33:17 --> Controller Class Initialized
INFO - 2018-07-15 21:33:17 --> Database Driver Class Initialized
INFO - 2018-07-15 21:33:17 --> Model Class Initialized
INFO - 2018-07-15 21:33:17 --> Helper loaded: url_helper
INFO - 2018-07-15 21:33:17 --> Model Class Initialized
INFO - 2018-07-15 21:33:17 --> Final output sent to browser
DEBUG - 2018-07-15 21:33:17 --> Total execution time: 0.0625
ERROR - 2018-07-15 22:12:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 22:12:12 --> Config Class Initialized
INFO - 2018-07-15 22:12:12 --> Hooks Class Initialized
DEBUG - 2018-07-15 22:12:12 --> UTF-8 Support Enabled
INFO - 2018-07-15 22:12:12 --> Utf8 Class Initialized
INFO - 2018-07-15 22:12:12 --> URI Class Initialized
DEBUG - 2018-07-15 22:12:12 --> No URI present. Default controller set.
INFO - 2018-07-15 22:12:12 --> Router Class Initialized
INFO - 2018-07-15 22:12:12 --> Output Class Initialized
INFO - 2018-07-15 22:12:12 --> Security Class Initialized
DEBUG - 2018-07-15 22:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 22:12:12 --> Input Class Initialized
INFO - 2018-07-15 22:12:12 --> Language Class Initialized
INFO - 2018-07-15 22:12:12 --> Loader Class Initialized
INFO - 2018-07-15 22:12:12 --> Controller Class Initialized
INFO - 2018-07-15 22:12:12 --> Database Driver Class Initialized
INFO - 2018-07-15 22:12:12 --> Model Class Initialized
INFO - 2018-07-15 22:12:12 --> Helper loaded: url_helper
DEBUG - 2018-07-15 22:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 22:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 22:12:12 --> Model Class Initialized
INFO - 2018-07-15 22:12:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-15 22:12:12 --> Final output sent to browser
DEBUG - 2018-07-15 22:12:12 --> Total execution time: 0.0994
ERROR - 2018-07-15 22:12:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 22:12:18 --> Config Class Initialized
INFO - 2018-07-15 22:12:18 --> Hooks Class Initialized
DEBUG - 2018-07-15 22:12:18 --> UTF-8 Support Enabled
INFO - 2018-07-15 22:12:18 --> Utf8 Class Initialized
INFO - 2018-07-15 22:12:18 --> URI Class Initialized
INFO - 2018-07-15 22:12:18 --> Router Class Initialized
INFO - 2018-07-15 22:12:18 --> Output Class Initialized
INFO - 2018-07-15 22:12:18 --> Security Class Initialized
DEBUG - 2018-07-15 22:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 22:12:18 --> Input Class Initialized
INFO - 2018-07-15 22:12:18 --> Language Class Initialized
INFO - 2018-07-15 22:12:18 --> Loader Class Initialized
INFO - 2018-07-15 22:12:18 --> Controller Class Initialized
INFO - 2018-07-15 22:12:18 --> Database Driver Class Initialized
INFO - 2018-07-15 22:12:18 --> Model Class Initialized
INFO - 2018-07-15 22:12:18 --> Helper loaded: url_helper
DEBUG - 2018-07-15 22:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 22:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 22:12:18 --> Model Class Initialized
ERROR - 2018-07-15 22:12:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 22:12:18 --> Config Class Initialized
INFO - 2018-07-15 22:12:18 --> Hooks Class Initialized
DEBUG - 2018-07-15 22:12:18 --> UTF-8 Support Enabled
INFO - 2018-07-15 22:12:18 --> Utf8 Class Initialized
INFO - 2018-07-15 22:12:18 --> URI Class Initialized
INFO - 2018-07-15 22:12:18 --> Router Class Initialized
INFO - 2018-07-15 22:12:18 --> Output Class Initialized
INFO - 2018-07-15 22:12:18 --> Security Class Initialized
DEBUG - 2018-07-15 22:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 22:12:18 --> Input Class Initialized
INFO - 2018-07-15 22:12:18 --> Language Class Initialized
INFO - 2018-07-15 22:12:18 --> Loader Class Initialized
INFO - 2018-07-15 22:12:18 --> Controller Class Initialized
INFO - 2018-07-15 22:12:18 --> Database Driver Class Initialized
INFO - 2018-07-15 22:12:18 --> Model Class Initialized
INFO - 2018-07-15 22:12:18 --> Helper loaded: url_helper
DEBUG - 2018-07-15 22:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 22:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 22:12:18 --> Model Class Initialized
INFO - 2018-07-15 22:12:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 22:12:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-15 22:12:18 --> Final output sent to browser
DEBUG - 2018-07-15 22:12:18 --> Total execution time: 0.0964
ERROR - 2018-07-15 22:13:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 22:13:35 --> Config Class Initialized
INFO - 2018-07-15 22:13:35 --> Hooks Class Initialized
DEBUG - 2018-07-15 22:13:35 --> UTF-8 Support Enabled
INFO - 2018-07-15 22:13:35 --> Utf8 Class Initialized
INFO - 2018-07-15 22:13:35 --> URI Class Initialized
INFO - 2018-07-15 22:13:35 --> Router Class Initialized
INFO - 2018-07-15 22:13:35 --> Output Class Initialized
INFO - 2018-07-15 22:13:35 --> Security Class Initialized
DEBUG - 2018-07-15 22:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 22:13:35 --> Input Class Initialized
INFO - 2018-07-15 22:13:35 --> Language Class Initialized
INFO - 2018-07-15 22:13:35 --> Loader Class Initialized
INFO - 2018-07-15 22:13:35 --> Controller Class Initialized
INFO - 2018-07-15 22:13:35 --> Database Driver Class Initialized
INFO - 2018-07-15 22:13:35 --> Model Class Initialized
INFO - 2018-07-15 22:13:35 --> Helper loaded: url_helper
DEBUG - 2018-07-15 22:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 22:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 22:13:35 --> Model Class Initialized
INFO - 2018-07-15 22:13:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 22:13:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 22:13:35 --> Final output sent to browser
DEBUG - 2018-07-15 22:13:35 --> Total execution time: 0.0735
ERROR - 2018-07-15 22:14:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 22:14:05 --> Config Class Initialized
INFO - 2018-07-15 22:14:05 --> Hooks Class Initialized
DEBUG - 2018-07-15 22:14:05 --> UTF-8 Support Enabled
INFO - 2018-07-15 22:14:05 --> Utf8 Class Initialized
INFO - 2018-07-15 22:14:05 --> URI Class Initialized
INFO - 2018-07-15 22:14:05 --> Router Class Initialized
INFO - 2018-07-15 22:14:05 --> Output Class Initialized
INFO - 2018-07-15 22:14:05 --> Security Class Initialized
DEBUG - 2018-07-15 22:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 22:14:05 --> Input Class Initialized
INFO - 2018-07-15 22:14:05 --> Language Class Initialized
INFO - 2018-07-15 22:14:05 --> Loader Class Initialized
INFO - 2018-07-15 22:14:05 --> Controller Class Initialized
INFO - 2018-07-15 22:14:05 --> Database Driver Class Initialized
INFO - 2018-07-15 22:14:05 --> Model Class Initialized
INFO - 2018-07-15 22:14:05 --> Helper loaded: url_helper
DEBUG - 2018-07-15 22:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 22:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 22:14:05 --> Model Class Initialized
INFO - 2018-07-15 22:14:05 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 22:14:05 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 22:14:05 --> Final output sent to browser
DEBUG - 2018-07-15 22:14:05 --> Total execution time: 0.0449
ERROR - 2018-07-15 22:14:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 22:14:16 --> Config Class Initialized
INFO - 2018-07-15 22:14:16 --> Hooks Class Initialized
DEBUG - 2018-07-15 22:14:16 --> UTF-8 Support Enabled
INFO - 2018-07-15 22:14:16 --> Utf8 Class Initialized
INFO - 2018-07-15 22:14:16 --> URI Class Initialized
INFO - 2018-07-15 22:14:16 --> Router Class Initialized
INFO - 2018-07-15 22:14:16 --> Output Class Initialized
INFO - 2018-07-15 22:14:16 --> Security Class Initialized
DEBUG - 2018-07-15 22:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 22:14:16 --> Input Class Initialized
INFO - 2018-07-15 22:14:16 --> Language Class Initialized
INFO - 2018-07-15 22:14:16 --> Loader Class Initialized
INFO - 2018-07-15 22:14:16 --> Controller Class Initialized
INFO - 2018-07-15 22:14:16 --> Database Driver Class Initialized
INFO - 2018-07-15 22:14:16 --> Model Class Initialized
INFO - 2018-07-15 22:14:16 --> Helper loaded: url_helper
DEBUG - 2018-07-15 22:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 22:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 22:14:16 --> Model Class Initialized
INFO - 2018-07-15 22:14:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 22:14:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 22:14:16 --> Final output sent to browser
DEBUG - 2018-07-15 22:14:16 --> Total execution time: 0.0370
ERROR - 2018-07-15 22:14:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 22:14:49 --> Config Class Initialized
INFO - 2018-07-15 22:14:49 --> Hooks Class Initialized
DEBUG - 2018-07-15 22:14:49 --> UTF-8 Support Enabled
INFO - 2018-07-15 22:14:49 --> Utf8 Class Initialized
INFO - 2018-07-15 22:14:49 --> URI Class Initialized
INFO - 2018-07-15 22:14:49 --> Router Class Initialized
INFO - 2018-07-15 22:14:49 --> Output Class Initialized
INFO - 2018-07-15 22:14:49 --> Security Class Initialized
DEBUG - 2018-07-15 22:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 22:14:49 --> Input Class Initialized
INFO - 2018-07-15 22:14:49 --> Language Class Initialized
INFO - 2018-07-15 22:14:49 --> Loader Class Initialized
INFO - 2018-07-15 22:14:49 --> Controller Class Initialized
INFO - 2018-07-15 22:14:49 --> Database Driver Class Initialized
INFO - 2018-07-15 22:14:49 --> Model Class Initialized
INFO - 2018-07-15 22:14:49 --> Helper loaded: url_helper
DEBUG - 2018-07-15 22:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 22:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 22:14:49 --> Model Class Initialized
INFO - 2018-07-15 22:14:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 22:14:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-15 22:14:49 --> Final output sent to browser
DEBUG - 2018-07-15 22:14:49 --> Total execution time: 0.0341
ERROR - 2018-07-15 22:14:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 22:14:54 --> Config Class Initialized
INFO - 2018-07-15 22:14:54 --> Hooks Class Initialized
DEBUG - 2018-07-15 22:14:54 --> UTF-8 Support Enabled
INFO - 2018-07-15 22:14:54 --> Utf8 Class Initialized
INFO - 2018-07-15 22:14:54 --> URI Class Initialized
INFO - 2018-07-15 22:14:54 --> Router Class Initialized
INFO - 2018-07-15 22:14:54 --> Output Class Initialized
INFO - 2018-07-15 22:14:54 --> Security Class Initialized
DEBUG - 2018-07-15 22:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 22:14:54 --> Input Class Initialized
INFO - 2018-07-15 22:14:54 --> Language Class Initialized
INFO - 2018-07-15 22:14:54 --> Loader Class Initialized
INFO - 2018-07-15 22:14:54 --> Controller Class Initialized
INFO - 2018-07-15 22:14:54 --> Database Driver Class Initialized
INFO - 2018-07-15 22:14:54 --> Model Class Initialized
INFO - 2018-07-15 22:14:54 --> Helper loaded: url_helper
DEBUG - 2018-07-15 22:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 22:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 22:14:54 --> Model Class Initialized
INFO - 2018-07-15 22:14:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 22:14:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 22:14:54 --> Final output sent to browser
DEBUG - 2018-07-15 22:14:54 --> Total execution time: 0.0454
ERROR - 2018-07-15 22:14:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 22:14:59 --> Config Class Initialized
INFO - 2018-07-15 22:14:59 --> Hooks Class Initialized
DEBUG - 2018-07-15 22:14:59 --> UTF-8 Support Enabled
INFO - 2018-07-15 22:14:59 --> Utf8 Class Initialized
INFO - 2018-07-15 22:14:59 --> URI Class Initialized
INFO - 2018-07-15 22:14:59 --> Router Class Initialized
INFO - 2018-07-15 22:14:59 --> Output Class Initialized
INFO - 2018-07-15 22:14:59 --> Security Class Initialized
DEBUG - 2018-07-15 22:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 22:14:59 --> Input Class Initialized
INFO - 2018-07-15 22:14:59 --> Language Class Initialized
INFO - 2018-07-15 22:14:59 --> Loader Class Initialized
INFO - 2018-07-15 22:14:59 --> Controller Class Initialized
INFO - 2018-07-15 22:14:59 --> Database Driver Class Initialized
INFO - 2018-07-15 22:14:59 --> Model Class Initialized
INFO - 2018-07-15 22:14:59 --> Helper loaded: url_helper
DEBUG - 2018-07-15 22:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 22:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 22:14:59 --> Model Class Initialized
ERROR - 2018-07-15 22:14:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 22:14:59 --> Config Class Initialized
INFO - 2018-07-15 22:14:59 --> Hooks Class Initialized
DEBUG - 2018-07-15 22:14:59 --> UTF-8 Support Enabled
INFO - 2018-07-15 22:14:59 --> Utf8 Class Initialized
INFO - 2018-07-15 22:14:59 --> URI Class Initialized
INFO - 2018-07-15 22:14:59 --> Router Class Initialized
INFO - 2018-07-15 22:14:59 --> Output Class Initialized
INFO - 2018-07-15 22:14:59 --> Security Class Initialized
DEBUG - 2018-07-15 22:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 22:14:59 --> Input Class Initialized
INFO - 2018-07-15 22:14:59 --> Language Class Initialized
INFO - 2018-07-15 22:14:59 --> Loader Class Initialized
INFO - 2018-07-15 22:14:59 --> Controller Class Initialized
INFO - 2018-07-15 22:14:59 --> Database Driver Class Initialized
INFO - 2018-07-15 22:14:59 --> Model Class Initialized
INFO - 2018-07-15 22:14:59 --> Helper loaded: url_helper
DEBUG - 2018-07-15 22:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 22:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 22:14:59 --> Model Class Initialized
INFO - 2018-07-15 22:14:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 22:14:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 22:14:59 --> Final output sent to browser
DEBUG - 2018-07-15 22:14:59 --> Total execution time: 0.0334
ERROR - 2018-07-15 22:15:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 22:15:03 --> Config Class Initialized
INFO - 2018-07-15 22:15:03 --> Hooks Class Initialized
DEBUG - 2018-07-15 22:15:03 --> UTF-8 Support Enabled
INFO - 2018-07-15 22:15:03 --> Utf8 Class Initialized
INFO - 2018-07-15 22:15:03 --> URI Class Initialized
INFO - 2018-07-15 22:15:03 --> Router Class Initialized
INFO - 2018-07-15 22:15:03 --> Output Class Initialized
INFO - 2018-07-15 22:15:03 --> Security Class Initialized
DEBUG - 2018-07-15 22:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 22:15:03 --> Input Class Initialized
INFO - 2018-07-15 22:15:03 --> Language Class Initialized
INFO - 2018-07-15 22:15:03 --> Loader Class Initialized
INFO - 2018-07-15 22:15:03 --> Controller Class Initialized
INFO - 2018-07-15 22:15:03 --> Database Driver Class Initialized
INFO - 2018-07-15 22:15:03 --> Model Class Initialized
INFO - 2018-07-15 22:15:03 --> Helper loaded: url_helper
DEBUG - 2018-07-15 22:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 22:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 22:15:03 --> Model Class Initialized
INFO - 2018-07-15 22:15:03 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 22:15:03 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-15 22:15:03 --> Final output sent to browser
DEBUG - 2018-07-15 22:15:03 --> Total execution time: 0.0329
ERROR - 2018-07-15 22:15:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 22:15:31 --> Config Class Initialized
INFO - 2018-07-15 22:15:31 --> Hooks Class Initialized
DEBUG - 2018-07-15 22:15:31 --> UTF-8 Support Enabled
INFO - 2018-07-15 22:15:31 --> Utf8 Class Initialized
INFO - 2018-07-15 22:15:31 --> URI Class Initialized
INFO - 2018-07-15 22:15:31 --> Router Class Initialized
INFO - 2018-07-15 22:15:31 --> Output Class Initialized
INFO - 2018-07-15 22:15:31 --> Security Class Initialized
DEBUG - 2018-07-15 22:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 22:15:31 --> Input Class Initialized
INFO - 2018-07-15 22:15:31 --> Language Class Initialized
INFO - 2018-07-15 22:15:31 --> Loader Class Initialized
INFO - 2018-07-15 22:15:31 --> Controller Class Initialized
INFO - 2018-07-15 22:15:31 --> Database Driver Class Initialized
INFO - 2018-07-15 22:15:31 --> Model Class Initialized
INFO - 2018-07-15 22:15:31 --> Helper loaded: url_helper
DEBUG - 2018-07-15 22:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 22:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 22:15:31 --> Model Class Initialized
INFO - 2018-07-15 22:15:31 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 22:15:31 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-15 22:15:31 --> Final output sent to browser
DEBUG - 2018-07-15 22:15:31 --> Total execution time: 0.0436
ERROR - 2018-07-15 22:15:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 22:15:34 --> Config Class Initialized
INFO - 2018-07-15 22:15:34 --> Hooks Class Initialized
DEBUG - 2018-07-15 22:15:34 --> UTF-8 Support Enabled
INFO - 2018-07-15 22:15:34 --> Utf8 Class Initialized
INFO - 2018-07-15 22:15:34 --> URI Class Initialized
INFO - 2018-07-15 22:15:34 --> Router Class Initialized
INFO - 2018-07-15 22:15:34 --> Output Class Initialized
INFO - 2018-07-15 22:15:34 --> Security Class Initialized
DEBUG - 2018-07-15 22:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 22:15:34 --> Input Class Initialized
INFO - 2018-07-15 22:15:34 --> Language Class Initialized
INFO - 2018-07-15 22:15:34 --> Loader Class Initialized
INFO - 2018-07-15 22:15:34 --> Controller Class Initialized
INFO - 2018-07-15 22:15:34 --> Database Driver Class Initialized
INFO - 2018-07-15 22:15:34 --> Model Class Initialized
INFO - 2018-07-15 22:15:34 --> Helper loaded: url_helper
DEBUG - 2018-07-15 22:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 22:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 22:15:34 --> Model Class Initialized
INFO - 2018-07-15 22:15:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 22:15:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-15 22:15:34 --> Final output sent to browser
DEBUG - 2018-07-15 22:15:34 --> Total execution time: 0.0441
ERROR - 2018-07-15 22:15:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 22:15:34 --> Config Class Initialized
INFO - 2018-07-15 22:15:34 --> Hooks Class Initialized
DEBUG - 2018-07-15 22:15:34 --> UTF-8 Support Enabled
INFO - 2018-07-15 22:15:34 --> Utf8 Class Initialized
INFO - 2018-07-15 22:15:34 --> URI Class Initialized
INFO - 2018-07-15 22:15:34 --> Router Class Initialized
INFO - 2018-07-15 22:15:34 --> Output Class Initialized
INFO - 2018-07-15 22:15:34 --> Security Class Initialized
DEBUG - 2018-07-15 22:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 22:15:34 --> Input Class Initialized
INFO - 2018-07-15 22:15:34 --> Language Class Initialized
INFO - 2018-07-15 22:15:34 --> Loader Class Initialized
INFO - 2018-07-15 22:15:34 --> Controller Class Initialized
INFO - 2018-07-15 22:15:34 --> Database Driver Class Initialized
INFO - 2018-07-15 22:15:34 --> Model Class Initialized
INFO - 2018-07-15 22:15:34 --> Helper loaded: url_helper
DEBUG - 2018-07-15 22:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 22:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 22:15:34 --> Model Class Initialized
INFO - 2018-07-15 22:15:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 22:15:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-15 22:15:34 --> Final output sent to browser
DEBUG - 2018-07-15 22:15:34 --> Total execution time: 0.0353
ERROR - 2018-07-15 22:16:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 22:16:11 --> Config Class Initialized
INFO - 2018-07-15 22:16:11 --> Hooks Class Initialized
DEBUG - 2018-07-15 22:16:11 --> UTF-8 Support Enabled
INFO - 2018-07-15 22:16:11 --> Utf8 Class Initialized
INFO - 2018-07-15 22:16:11 --> URI Class Initialized
INFO - 2018-07-15 22:16:11 --> Router Class Initialized
INFO - 2018-07-15 22:16:11 --> Output Class Initialized
INFO - 2018-07-15 22:16:11 --> Security Class Initialized
DEBUG - 2018-07-15 22:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 22:16:11 --> Input Class Initialized
INFO - 2018-07-15 22:16:11 --> Language Class Initialized
INFO - 2018-07-15 22:16:11 --> Loader Class Initialized
INFO - 2018-07-15 22:16:11 --> Controller Class Initialized
INFO - 2018-07-15 22:16:11 --> Database Driver Class Initialized
INFO - 2018-07-15 22:16:11 --> Model Class Initialized
INFO - 2018-07-15 22:16:11 --> Helper loaded: url_helper
DEBUG - 2018-07-15 22:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 22:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 22:16:11 --> Model Class Initialized
INFO - 2018-07-15 22:16:11 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 22:16:11 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-15 22:16:11 --> Final output sent to browser
DEBUG - 2018-07-15 22:16:11 --> Total execution time: 0.0526
ERROR - 2018-07-15 22:18:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 22:18:04 --> Config Class Initialized
INFO - 2018-07-15 22:18:04 --> Hooks Class Initialized
DEBUG - 2018-07-15 22:18:04 --> UTF-8 Support Enabled
INFO - 2018-07-15 22:18:04 --> Utf8 Class Initialized
INFO - 2018-07-15 22:18:04 --> URI Class Initialized
INFO - 2018-07-15 22:18:04 --> Router Class Initialized
INFO - 2018-07-15 22:18:04 --> Output Class Initialized
INFO - 2018-07-15 22:18:04 --> Security Class Initialized
DEBUG - 2018-07-15 22:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 22:18:04 --> Input Class Initialized
INFO - 2018-07-15 22:18:04 --> Language Class Initialized
INFO - 2018-07-15 22:18:04 --> Loader Class Initialized
INFO - 2018-07-15 22:18:04 --> Controller Class Initialized
INFO - 2018-07-15 22:18:04 --> Database Driver Class Initialized
INFO - 2018-07-15 22:18:04 --> Model Class Initialized
INFO - 2018-07-15 22:18:04 --> Helper loaded: url_helper
DEBUG - 2018-07-15 22:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 22:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 22:18:04 --> Model Class Initialized
INFO - 2018-07-15 22:18:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 22:18:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-07-15 22:18:04 --> Final output sent to browser
DEBUG - 2018-07-15 22:18:04 --> Total execution time: 0.0645
ERROR - 2018-07-15 22:18:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-15 22:18:07 --> Config Class Initialized
INFO - 2018-07-15 22:18:07 --> Hooks Class Initialized
DEBUG - 2018-07-15 22:18:07 --> UTF-8 Support Enabled
INFO - 2018-07-15 22:18:07 --> Utf8 Class Initialized
INFO - 2018-07-15 22:18:07 --> URI Class Initialized
INFO - 2018-07-15 22:18:07 --> Router Class Initialized
INFO - 2018-07-15 22:18:07 --> Output Class Initialized
INFO - 2018-07-15 22:18:07 --> Security Class Initialized
DEBUG - 2018-07-15 22:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-15 22:18:07 --> Input Class Initialized
INFO - 2018-07-15 22:18:07 --> Language Class Initialized
INFO - 2018-07-15 22:18:07 --> Loader Class Initialized
INFO - 2018-07-15 22:18:07 --> Controller Class Initialized
INFO - 2018-07-15 22:18:07 --> Database Driver Class Initialized
INFO - 2018-07-15 22:18:07 --> Model Class Initialized
INFO - 2018-07-15 22:18:07 --> Helper loaded: url_helper
DEBUG - 2018-07-15 22:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-15 22:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-15 22:18:07 --> Model Class Initialized
INFO - 2018-07-15 22:18:07 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-15 22:18:07 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-15 22:18:07 --> Final output sent to browser
DEBUG - 2018-07-15 22:18:07 --> Total execution time: 0.0527
