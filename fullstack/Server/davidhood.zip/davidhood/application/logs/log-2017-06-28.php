<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-28 09:00:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 09:00:54 --> Config Class Initialized
INFO - 2017-06-28 09:00:54 --> Hooks Class Initialized
DEBUG - 2017-06-28 09:00:54 --> UTF-8 Support Enabled
INFO - 2017-06-28 09:00:54 --> Utf8 Class Initialized
INFO - 2017-06-28 09:00:54 --> URI Class Initialized
INFO - 2017-06-28 09:00:54 --> Router Class Initialized
INFO - 2017-06-28 09:00:54 --> Output Class Initialized
INFO - 2017-06-28 09:00:54 --> Security Class Initialized
DEBUG - 2017-06-28 09:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 09:00:54 --> Input Class Initialized
INFO - 2017-06-28 09:00:54 --> Language Class Initialized
INFO - 2017-06-28 09:00:54 --> Loader Class Initialized
INFO - 2017-06-28 09:00:54 --> Controller Class Initialized
INFO - 2017-06-28 09:00:54 --> Database Driver Class Initialized
INFO - 2017-06-28 09:00:54 --> Model Class Initialized
INFO - 2017-06-28 09:00:54 --> Helper loaded: form_helper
INFO - 2017-06-28 09:00:54 --> Helper loaded: url_helper
INFO - 2017-06-28 09:00:54 --> Model Class Initialized
INFO - 2017-06-28 09:00:54 --> Final output sent to browser
DEBUG - 2017-06-28 09:00:54 --> Total execution time: 0.0760
ERROR - 2017-06-28 09:01:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 09:01:13 --> Config Class Initialized
INFO - 2017-06-28 09:01:13 --> Hooks Class Initialized
DEBUG - 2017-06-28 09:01:13 --> UTF-8 Support Enabled
INFO - 2017-06-28 09:01:13 --> Utf8 Class Initialized
INFO - 2017-06-28 09:01:13 --> URI Class Initialized
INFO - 2017-06-28 09:01:13 --> Router Class Initialized
INFO - 2017-06-28 09:01:13 --> Output Class Initialized
INFO - 2017-06-28 09:01:13 --> Security Class Initialized
DEBUG - 2017-06-28 09:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 09:01:13 --> Input Class Initialized
INFO - 2017-06-28 09:01:13 --> Language Class Initialized
INFO - 2017-06-28 09:01:13 --> Loader Class Initialized
INFO - 2017-06-28 09:01:13 --> Controller Class Initialized
INFO - 2017-06-28 09:01:13 --> Database Driver Class Initialized
INFO - 2017-06-28 09:01:13 --> Model Class Initialized
INFO - 2017-06-28 09:01:13 --> Helper loaded: form_helper
INFO - 2017-06-28 09:01:13 --> Helper loaded: url_helper
INFO - 2017-06-28 09:01:13 --> Model Class Initialized
INFO - 2017-06-28 09:01:13 --> Final output sent to browser
DEBUG - 2017-06-28 09:01:13 --> Total execution time: 0.1420
ERROR - 2017-06-28 09:01:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 09:01:17 --> Config Class Initialized
INFO - 2017-06-28 09:01:17 --> Hooks Class Initialized
DEBUG - 2017-06-28 09:01:17 --> UTF-8 Support Enabled
INFO - 2017-06-28 09:01:17 --> Utf8 Class Initialized
INFO - 2017-06-28 09:01:17 --> URI Class Initialized
INFO - 2017-06-28 09:01:17 --> Router Class Initialized
INFO - 2017-06-28 09:01:17 --> Output Class Initialized
INFO - 2017-06-28 09:01:17 --> Security Class Initialized
DEBUG - 2017-06-28 09:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 09:01:17 --> Input Class Initialized
INFO - 2017-06-28 09:01:17 --> Language Class Initialized
INFO - 2017-06-28 09:01:17 --> Loader Class Initialized
INFO - 2017-06-28 09:01:17 --> Controller Class Initialized
INFO - 2017-06-28 09:01:17 --> Database Driver Class Initialized
INFO - 2017-06-28 09:01:17 --> Model Class Initialized
INFO - 2017-06-28 09:01:17 --> Helper loaded: form_helper
INFO - 2017-06-28 09:01:17 --> Helper loaded: url_helper
INFO - 2017-06-28 09:01:17 --> Model Class Initialized
INFO - 2017-06-28 09:01:17 --> Final output sent to browser
DEBUG - 2017-06-28 09:01:17 --> Total execution time: 0.1890
ERROR - 2017-06-28 09:07:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 09:07:37 --> Config Class Initialized
INFO - 2017-06-28 09:07:37 --> Hooks Class Initialized
DEBUG - 2017-06-28 09:07:37 --> UTF-8 Support Enabled
INFO - 2017-06-28 09:07:37 --> Utf8 Class Initialized
INFO - 2017-06-28 09:07:37 --> URI Class Initialized
INFO - 2017-06-28 09:07:37 --> Router Class Initialized
INFO - 2017-06-28 09:07:37 --> Output Class Initialized
INFO - 2017-06-28 09:07:37 --> Security Class Initialized
DEBUG - 2017-06-28 09:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 09:07:37 --> Input Class Initialized
INFO - 2017-06-28 09:07:37 --> Language Class Initialized
INFO - 2017-06-28 09:07:37 --> Loader Class Initialized
INFO - 2017-06-28 09:07:37 --> Controller Class Initialized
INFO - 2017-06-28 09:07:37 --> Database Driver Class Initialized
INFO - 2017-06-28 09:07:37 --> Model Class Initialized
INFO - 2017-06-28 09:07:37 --> Helper loaded: form_helper
INFO - 2017-06-28 09:07:37 --> Helper loaded: url_helper
INFO - 2017-06-28 09:07:37 --> Model Class Initialized
INFO - 2017-06-28 09:07:37 --> Final output sent to browser
DEBUG - 2017-06-28 09:07:37 --> Total execution time: 0.0810
ERROR - 2017-06-28 09:08:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 09:08:12 --> Config Class Initialized
INFO - 2017-06-28 09:08:12 --> Hooks Class Initialized
DEBUG - 2017-06-28 09:08:12 --> UTF-8 Support Enabled
INFO - 2017-06-28 09:08:12 --> Utf8 Class Initialized
INFO - 2017-06-28 09:08:12 --> URI Class Initialized
INFO - 2017-06-28 09:08:12 --> Router Class Initialized
INFO - 2017-06-28 09:08:12 --> Output Class Initialized
INFO - 2017-06-28 09:08:12 --> Security Class Initialized
DEBUG - 2017-06-28 09:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 09:08:12 --> Input Class Initialized
INFO - 2017-06-28 09:08:12 --> Language Class Initialized
INFO - 2017-06-28 09:08:12 --> Loader Class Initialized
INFO - 2017-06-28 09:08:12 --> Controller Class Initialized
INFO - 2017-06-28 09:08:12 --> Database Driver Class Initialized
INFO - 2017-06-28 09:08:12 --> Model Class Initialized
INFO - 2017-06-28 09:08:12 --> Helper loaded: form_helper
INFO - 2017-06-28 09:08:12 --> Helper loaded: url_helper
INFO - 2017-06-28 09:08:12 --> Model Class Initialized
INFO - 2017-06-28 09:08:12 --> Final output sent to browser
DEBUG - 2017-06-28 09:08:12 --> Total execution time: 0.1150
ERROR - 2017-06-28 09:08:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 09:08:39 --> Config Class Initialized
INFO - 2017-06-28 09:08:39 --> Hooks Class Initialized
DEBUG - 2017-06-28 09:08:39 --> UTF-8 Support Enabled
INFO - 2017-06-28 09:08:39 --> Utf8 Class Initialized
INFO - 2017-06-28 09:08:39 --> URI Class Initialized
INFO - 2017-06-28 09:08:39 --> Router Class Initialized
INFO - 2017-06-28 09:08:39 --> Output Class Initialized
INFO - 2017-06-28 09:08:39 --> Security Class Initialized
DEBUG - 2017-06-28 09:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 09:08:39 --> Input Class Initialized
INFO - 2017-06-28 09:08:39 --> Language Class Initialized
INFO - 2017-06-28 09:08:39 --> Loader Class Initialized
INFO - 2017-06-28 09:08:39 --> Controller Class Initialized
INFO - 2017-06-28 09:08:39 --> Database Driver Class Initialized
INFO - 2017-06-28 09:08:39 --> Model Class Initialized
INFO - 2017-06-28 09:08:39 --> Helper loaded: form_helper
INFO - 2017-06-28 09:08:39 --> Helper loaded: url_helper
INFO - 2017-06-28 09:08:39 --> Model Class Initialized
INFO - 2017-06-28 09:08:39 --> Final output sent to browser
DEBUG - 2017-06-28 09:08:39 --> Total execution time: 0.0730
ERROR - 2017-06-28 09:08:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 09:08:41 --> Config Class Initialized
INFO - 2017-06-28 09:08:41 --> Hooks Class Initialized
DEBUG - 2017-06-28 09:08:41 --> UTF-8 Support Enabled
INFO - 2017-06-28 09:08:41 --> Utf8 Class Initialized
INFO - 2017-06-28 09:08:41 --> URI Class Initialized
INFO - 2017-06-28 09:08:41 --> Router Class Initialized
INFO - 2017-06-28 09:08:41 --> Output Class Initialized
INFO - 2017-06-28 09:08:41 --> Security Class Initialized
DEBUG - 2017-06-28 09:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 09:08:41 --> Input Class Initialized
INFO - 2017-06-28 09:08:41 --> Language Class Initialized
INFO - 2017-06-28 09:08:41 --> Loader Class Initialized
INFO - 2017-06-28 09:08:41 --> Controller Class Initialized
INFO - 2017-06-28 09:08:41 --> Database Driver Class Initialized
INFO - 2017-06-28 09:08:41 --> Model Class Initialized
INFO - 2017-06-28 09:08:41 --> Helper loaded: form_helper
INFO - 2017-06-28 09:08:41 --> Helper loaded: url_helper
INFO - 2017-06-28 09:08:41 --> Model Class Initialized
INFO - 2017-06-28 09:08:41 --> Final output sent to browser
DEBUG - 2017-06-28 09:08:41 --> Total execution time: 0.1240
ERROR - 2017-06-28 09:09:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 09:09:07 --> Config Class Initialized
INFO - 2017-06-28 09:09:07 --> Hooks Class Initialized
DEBUG - 2017-06-28 09:09:07 --> UTF-8 Support Enabled
INFO - 2017-06-28 09:09:07 --> Utf8 Class Initialized
INFO - 2017-06-28 09:09:07 --> URI Class Initialized
INFO - 2017-06-28 09:09:07 --> Router Class Initialized
INFO - 2017-06-28 09:09:07 --> Output Class Initialized
INFO - 2017-06-28 09:09:07 --> Security Class Initialized
DEBUG - 2017-06-28 09:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 09:09:07 --> Input Class Initialized
INFO - 2017-06-28 09:09:07 --> Language Class Initialized
INFO - 2017-06-28 09:09:07 --> Loader Class Initialized
INFO - 2017-06-28 09:09:07 --> Controller Class Initialized
INFO - 2017-06-28 09:09:07 --> Database Driver Class Initialized
INFO - 2017-06-28 09:09:07 --> Model Class Initialized
INFO - 2017-06-28 09:09:07 --> Helper loaded: form_helper
INFO - 2017-06-28 09:09:07 --> Helper loaded: url_helper
INFO - 2017-06-28 09:09:07 --> Model Class Initialized
INFO - 2017-06-28 09:09:07 --> Final output sent to browser
DEBUG - 2017-06-28 09:09:07 --> Total execution time: 0.1130
ERROR - 2017-06-28 09:09:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 09:09:34 --> Config Class Initialized
INFO - 2017-06-28 09:09:34 --> Hooks Class Initialized
DEBUG - 2017-06-28 09:09:34 --> UTF-8 Support Enabled
INFO - 2017-06-28 09:09:34 --> Utf8 Class Initialized
INFO - 2017-06-28 09:09:34 --> URI Class Initialized
INFO - 2017-06-28 09:09:34 --> Router Class Initialized
INFO - 2017-06-28 09:09:34 --> Output Class Initialized
INFO - 2017-06-28 09:09:34 --> Security Class Initialized
DEBUG - 2017-06-28 09:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 09:09:34 --> Input Class Initialized
INFO - 2017-06-28 09:09:34 --> Language Class Initialized
INFO - 2017-06-28 09:09:34 --> Loader Class Initialized
INFO - 2017-06-28 09:09:34 --> Controller Class Initialized
INFO - 2017-06-28 09:09:34 --> Database Driver Class Initialized
INFO - 2017-06-28 09:09:34 --> Model Class Initialized
INFO - 2017-06-28 09:09:34 --> Helper loaded: form_helper
INFO - 2017-06-28 09:09:34 --> Helper loaded: url_helper
INFO - 2017-06-28 09:09:34 --> Model Class Initialized
INFO - 2017-06-28 09:09:34 --> Final output sent to browser
DEBUG - 2017-06-28 09:09:34 --> Total execution time: 0.0860
ERROR - 2017-06-28 09:09:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 09:09:38 --> Config Class Initialized
INFO - 2017-06-28 09:09:38 --> Hooks Class Initialized
DEBUG - 2017-06-28 09:09:38 --> UTF-8 Support Enabled
INFO - 2017-06-28 09:09:38 --> Utf8 Class Initialized
INFO - 2017-06-28 09:09:38 --> URI Class Initialized
INFO - 2017-06-28 09:09:38 --> Router Class Initialized
INFO - 2017-06-28 09:09:38 --> Output Class Initialized
INFO - 2017-06-28 09:09:38 --> Security Class Initialized
DEBUG - 2017-06-28 09:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 09:09:38 --> Input Class Initialized
INFO - 2017-06-28 09:09:38 --> Language Class Initialized
INFO - 2017-06-28 09:09:38 --> Loader Class Initialized
INFO - 2017-06-28 09:09:38 --> Controller Class Initialized
INFO - 2017-06-28 09:09:38 --> Database Driver Class Initialized
INFO - 2017-06-28 09:09:38 --> Model Class Initialized
INFO - 2017-06-28 09:09:38 --> Helper loaded: form_helper
INFO - 2017-06-28 09:09:38 --> Helper loaded: url_helper
INFO - 2017-06-28 09:09:38 --> Model Class Initialized
INFO - 2017-06-28 09:09:38 --> Final output sent to browser
DEBUG - 2017-06-28 09:09:38 --> Total execution time: 0.2130
ERROR - 2017-06-28 09:09:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 09:09:41 --> Config Class Initialized
INFO - 2017-06-28 09:09:41 --> Hooks Class Initialized
DEBUG - 2017-06-28 09:09:41 --> UTF-8 Support Enabled
INFO - 2017-06-28 09:09:41 --> Utf8 Class Initialized
INFO - 2017-06-28 09:09:41 --> URI Class Initialized
INFO - 2017-06-28 09:09:41 --> Router Class Initialized
INFO - 2017-06-28 09:09:41 --> Output Class Initialized
INFO - 2017-06-28 09:09:41 --> Security Class Initialized
DEBUG - 2017-06-28 09:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 09:09:41 --> Input Class Initialized
INFO - 2017-06-28 09:09:41 --> Language Class Initialized
INFO - 2017-06-28 09:09:41 --> Loader Class Initialized
INFO - 2017-06-28 09:09:41 --> Controller Class Initialized
INFO - 2017-06-28 09:09:41 --> Database Driver Class Initialized
INFO - 2017-06-28 09:09:41 --> Model Class Initialized
INFO - 2017-06-28 09:09:41 --> Helper loaded: form_helper
INFO - 2017-06-28 09:09:41 --> Helper loaded: url_helper
INFO - 2017-06-28 09:09:41 --> Model Class Initialized
INFO - 2017-06-28 09:09:41 --> Final output sent to browser
DEBUG - 2017-06-28 09:09:41 --> Total execution time: 0.1990
ERROR - 2017-06-28 09:09:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 09:09:52 --> Config Class Initialized
INFO - 2017-06-28 09:09:52 --> Hooks Class Initialized
DEBUG - 2017-06-28 09:09:52 --> UTF-8 Support Enabled
INFO - 2017-06-28 09:09:52 --> Utf8 Class Initialized
INFO - 2017-06-28 09:09:52 --> URI Class Initialized
INFO - 2017-06-28 09:09:52 --> Router Class Initialized
INFO - 2017-06-28 09:09:52 --> Output Class Initialized
INFO - 2017-06-28 09:09:52 --> Security Class Initialized
DEBUG - 2017-06-28 09:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 09:09:52 --> Input Class Initialized
INFO - 2017-06-28 09:09:52 --> Language Class Initialized
INFO - 2017-06-28 09:09:52 --> Loader Class Initialized
INFO - 2017-06-28 09:09:52 --> Controller Class Initialized
INFO - 2017-06-28 09:09:52 --> Database Driver Class Initialized
INFO - 2017-06-28 09:09:52 --> Model Class Initialized
INFO - 2017-06-28 09:09:52 --> Helper loaded: form_helper
INFO - 2017-06-28 09:09:52 --> Helper loaded: url_helper
INFO - 2017-06-28 09:09:52 --> Model Class Initialized
INFO - 2017-06-28 09:09:52 --> Final output sent to browser
DEBUG - 2017-06-28 09:09:52 --> Total execution time: 0.1220
ERROR - 2017-06-28 11:26:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 11:26:35 --> Config Class Initialized
INFO - 2017-06-28 11:26:35 --> Hooks Class Initialized
DEBUG - 2017-06-28 11:26:35 --> UTF-8 Support Enabled
INFO - 2017-06-28 11:26:35 --> Utf8 Class Initialized
INFO - 2017-06-28 11:26:35 --> URI Class Initialized
INFO - 2017-06-28 11:26:35 --> Router Class Initialized
INFO - 2017-06-28 11:26:35 --> Output Class Initialized
INFO - 2017-06-28 11:26:35 --> Security Class Initialized
DEBUG - 2017-06-28 11:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 11:26:35 --> Input Class Initialized
INFO - 2017-06-28 11:26:35 --> Language Class Initialized
INFO - 2017-06-28 11:26:35 --> Loader Class Initialized
INFO - 2017-06-28 11:26:35 --> Controller Class Initialized
INFO - 2017-06-28 11:26:36 --> Database Driver Class Initialized
INFO - 2017-06-28 11:26:36 --> Model Class Initialized
INFO - 2017-06-28 11:26:36 --> Helper loaded: form_helper
INFO - 2017-06-28 11:26:36 --> Helper loaded: url_helper
INFO - 2017-06-28 11:26:36 --> Model Class Initialized
ERROR - 2017-06-28 11:26:36 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\mystage\application\controllers\Mobile.php 61
INFO - 2017-06-28 11:26:36 --> Final output sent to browser
DEBUG - 2017-06-28 11:26:36 --> Total execution time: 0.0740
ERROR - 2017-06-28 11:26:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 11:26:41 --> Config Class Initialized
INFO - 2017-06-28 11:26:41 --> Hooks Class Initialized
DEBUG - 2017-06-28 11:26:41 --> UTF-8 Support Enabled
INFO - 2017-06-28 11:26:41 --> Utf8 Class Initialized
INFO - 2017-06-28 11:26:41 --> URI Class Initialized
INFO - 2017-06-28 11:26:41 --> Router Class Initialized
INFO - 2017-06-28 11:26:41 --> Output Class Initialized
INFO - 2017-06-28 11:26:41 --> Security Class Initialized
DEBUG - 2017-06-28 11:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 11:26:41 --> Input Class Initialized
INFO - 2017-06-28 11:26:41 --> Language Class Initialized
INFO - 2017-06-28 11:26:41 --> Loader Class Initialized
INFO - 2017-06-28 11:26:41 --> Controller Class Initialized
INFO - 2017-06-28 11:26:41 --> Database Driver Class Initialized
INFO - 2017-06-28 11:26:41 --> Model Class Initialized
INFO - 2017-06-28 11:26:41 --> Helper loaded: form_helper
INFO - 2017-06-28 11:26:41 --> Helper loaded: url_helper
INFO - 2017-06-28 11:26:41 --> Model Class Initialized
ERROR - 2017-06-28 11:26:41 --> Severity: Notice --> Undefined variable: array C:\xampp\htdocs\mystage\application\models\Mobile_model.php 132
INFO - 2017-06-28 11:26:41 --> Final output sent to browser
DEBUG - 2017-06-28 11:26:41 --> Total execution time: 0.0720
ERROR - 2017-06-28 11:26:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 11:26:57 --> Config Class Initialized
INFO - 2017-06-28 11:26:57 --> Hooks Class Initialized
DEBUG - 2017-06-28 11:26:57 --> UTF-8 Support Enabled
INFO - 2017-06-28 11:26:57 --> Utf8 Class Initialized
INFO - 2017-06-28 11:26:57 --> URI Class Initialized
INFO - 2017-06-28 11:26:57 --> Router Class Initialized
INFO - 2017-06-28 11:26:57 --> Output Class Initialized
INFO - 2017-06-28 11:26:57 --> Security Class Initialized
DEBUG - 2017-06-28 11:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 11:26:57 --> Input Class Initialized
INFO - 2017-06-28 11:26:57 --> Language Class Initialized
INFO - 2017-06-28 11:26:57 --> Loader Class Initialized
INFO - 2017-06-28 11:26:57 --> Controller Class Initialized
INFO - 2017-06-28 11:26:57 --> Database Driver Class Initialized
INFO - 2017-06-28 11:26:57 --> Model Class Initialized
INFO - 2017-06-28 11:26:57 --> Helper loaded: form_helper
INFO - 2017-06-28 11:26:57 --> Helper loaded: url_helper
INFO - 2017-06-28 11:26:57 --> Model Class Initialized
ERROR - 2017-06-28 11:26:57 --> Severity: Notice --> Undefined index: guests C:\xampp\htdocs\mystage\application\models\Mobile_model.php 132
INFO - 2017-06-28 11:26:57 --> Final output sent to browser
DEBUG - 2017-06-28 11:26:57 --> Total execution time: 0.0460
ERROR - 2017-06-28 11:27:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 11:27:27 --> Config Class Initialized
INFO - 2017-06-28 11:27:27 --> Hooks Class Initialized
DEBUG - 2017-06-28 11:27:27 --> UTF-8 Support Enabled
INFO - 2017-06-28 11:27:27 --> Utf8 Class Initialized
INFO - 2017-06-28 11:27:27 --> URI Class Initialized
INFO - 2017-06-28 11:27:27 --> Router Class Initialized
INFO - 2017-06-28 11:27:27 --> Output Class Initialized
INFO - 2017-06-28 11:27:27 --> Security Class Initialized
DEBUG - 2017-06-28 11:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 11:27:27 --> Input Class Initialized
INFO - 2017-06-28 11:27:27 --> Language Class Initialized
INFO - 2017-06-28 11:27:27 --> Loader Class Initialized
INFO - 2017-06-28 11:27:27 --> Controller Class Initialized
INFO - 2017-06-28 11:27:27 --> Database Driver Class Initialized
INFO - 2017-06-28 11:27:27 --> Model Class Initialized
INFO - 2017-06-28 11:27:27 --> Helper loaded: form_helper
INFO - 2017-06-28 11:27:27 --> Helper loaded: url_helper
INFO - 2017-06-28 11:27:27 --> Model Class Initialized
INFO - 2017-06-28 11:27:27 --> Final output sent to browser
DEBUG - 2017-06-28 11:27:27 --> Total execution time: 0.0740
ERROR - 2017-06-28 11:27:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 11:27:43 --> Config Class Initialized
INFO - 2017-06-28 11:27:43 --> Hooks Class Initialized
DEBUG - 2017-06-28 11:27:43 --> UTF-8 Support Enabled
INFO - 2017-06-28 11:27:43 --> Utf8 Class Initialized
INFO - 2017-06-28 11:27:44 --> URI Class Initialized
INFO - 2017-06-28 11:27:44 --> Router Class Initialized
INFO - 2017-06-28 11:27:44 --> Output Class Initialized
INFO - 2017-06-28 11:27:44 --> Security Class Initialized
DEBUG - 2017-06-28 11:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 11:27:44 --> Input Class Initialized
INFO - 2017-06-28 11:27:44 --> Language Class Initialized
INFO - 2017-06-28 11:27:44 --> Loader Class Initialized
INFO - 2017-06-28 11:27:44 --> Controller Class Initialized
INFO - 2017-06-28 11:27:44 --> Database Driver Class Initialized
INFO - 2017-06-28 11:27:44 --> Model Class Initialized
INFO - 2017-06-28 11:27:44 --> Helper loaded: form_helper
INFO - 2017-06-28 11:27:44 --> Helper loaded: url_helper
INFO - 2017-06-28 11:27:44 --> Model Class Initialized
INFO - 2017-06-28 11:27:44 --> Final output sent to browser
DEBUG - 2017-06-28 11:27:44 --> Total execution time: 0.0590
ERROR - 2017-06-28 11:27:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 11:27:48 --> Config Class Initialized
INFO - 2017-06-28 11:27:48 --> Hooks Class Initialized
DEBUG - 2017-06-28 11:27:48 --> UTF-8 Support Enabled
INFO - 2017-06-28 11:27:48 --> Utf8 Class Initialized
INFO - 2017-06-28 11:27:48 --> URI Class Initialized
INFO - 2017-06-28 11:27:48 --> Router Class Initialized
INFO - 2017-06-28 11:27:48 --> Output Class Initialized
INFO - 2017-06-28 11:27:48 --> Security Class Initialized
DEBUG - 2017-06-28 11:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 11:27:48 --> Input Class Initialized
INFO - 2017-06-28 11:27:48 --> Language Class Initialized
INFO - 2017-06-28 11:27:48 --> Loader Class Initialized
INFO - 2017-06-28 11:27:48 --> Controller Class Initialized
INFO - 2017-06-28 11:27:48 --> Database Driver Class Initialized
INFO - 2017-06-28 11:27:48 --> Model Class Initialized
INFO - 2017-06-28 11:27:48 --> Helper loaded: form_helper
INFO - 2017-06-28 11:27:48 --> Helper loaded: url_helper
INFO - 2017-06-28 11:27:48 --> Model Class Initialized
INFO - 2017-06-28 11:27:48 --> Final output sent to browser
DEBUG - 2017-06-28 11:27:48 --> Total execution time: 0.0900
ERROR - 2017-06-28 11:27:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 11:27:55 --> Config Class Initialized
INFO - 2017-06-28 11:27:55 --> Hooks Class Initialized
DEBUG - 2017-06-28 11:27:55 --> UTF-8 Support Enabled
INFO - 2017-06-28 11:27:55 --> Utf8 Class Initialized
INFO - 2017-06-28 11:27:55 --> URI Class Initialized
INFO - 2017-06-28 11:27:55 --> Router Class Initialized
INFO - 2017-06-28 11:27:55 --> Output Class Initialized
INFO - 2017-06-28 11:27:55 --> Security Class Initialized
DEBUG - 2017-06-28 11:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 11:27:55 --> Input Class Initialized
INFO - 2017-06-28 11:27:55 --> Language Class Initialized
INFO - 2017-06-28 11:27:55 --> Loader Class Initialized
INFO - 2017-06-28 11:27:55 --> Controller Class Initialized
INFO - 2017-06-28 11:27:55 --> Database Driver Class Initialized
INFO - 2017-06-28 11:27:55 --> Model Class Initialized
INFO - 2017-06-28 11:27:55 --> Helper loaded: form_helper
INFO - 2017-06-28 11:27:55 --> Helper loaded: url_helper
INFO - 2017-06-28 11:27:55 --> Model Class Initialized
INFO - 2017-06-28 11:27:55 --> Final output sent to browser
DEBUG - 2017-06-28 11:27:55 --> Total execution time: 0.0590
ERROR - 2017-06-28 11:28:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 11:28:00 --> Config Class Initialized
INFO - 2017-06-28 11:28:00 --> Hooks Class Initialized
DEBUG - 2017-06-28 11:28:00 --> UTF-8 Support Enabled
INFO - 2017-06-28 11:28:00 --> Utf8 Class Initialized
INFO - 2017-06-28 11:28:00 --> URI Class Initialized
INFO - 2017-06-28 11:28:00 --> Router Class Initialized
INFO - 2017-06-28 11:28:00 --> Output Class Initialized
INFO - 2017-06-28 11:28:00 --> Security Class Initialized
DEBUG - 2017-06-28 11:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 11:28:00 --> Input Class Initialized
INFO - 2017-06-28 11:28:00 --> Language Class Initialized
INFO - 2017-06-28 11:28:00 --> Loader Class Initialized
INFO - 2017-06-28 11:28:00 --> Controller Class Initialized
INFO - 2017-06-28 11:28:00 --> Database Driver Class Initialized
INFO - 2017-06-28 11:28:00 --> Model Class Initialized
INFO - 2017-06-28 11:28:00 --> Helper loaded: form_helper
INFO - 2017-06-28 11:28:00 --> Helper loaded: url_helper
INFO - 2017-06-28 11:28:00 --> Model Class Initialized
INFO - 2017-06-28 11:28:00 --> Final output sent to browser
DEBUG - 2017-06-28 11:28:00 --> Total execution time: 0.0490
ERROR - 2017-06-28 11:32:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 11:32:42 --> Config Class Initialized
INFO - 2017-06-28 11:32:42 --> Hooks Class Initialized
DEBUG - 2017-06-28 11:32:42 --> UTF-8 Support Enabled
INFO - 2017-06-28 11:32:42 --> Utf8 Class Initialized
INFO - 2017-06-28 11:32:42 --> URI Class Initialized
INFO - 2017-06-28 11:32:42 --> Router Class Initialized
INFO - 2017-06-28 11:32:42 --> Output Class Initialized
INFO - 2017-06-28 11:32:42 --> Security Class Initialized
DEBUG - 2017-06-28 11:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 11:32:42 --> Input Class Initialized
INFO - 2017-06-28 11:32:42 --> Language Class Initialized
INFO - 2017-06-28 11:32:42 --> Loader Class Initialized
INFO - 2017-06-28 11:32:42 --> Controller Class Initialized
INFO - 2017-06-28 11:32:42 --> Database Driver Class Initialized
INFO - 2017-06-28 11:32:42 --> Model Class Initialized
INFO - 2017-06-28 11:32:42 --> Helper loaded: form_helper
INFO - 2017-06-28 11:32:42 --> Helper loaded: url_helper
INFO - 2017-06-28 11:32:42 --> Model Class Initialized
INFO - 2017-06-28 11:32:42 --> Final output sent to browser
DEBUG - 2017-06-28 11:32:42 --> Total execution time: 0.0620
ERROR - 2017-06-28 11:32:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 11:32:57 --> Config Class Initialized
INFO - 2017-06-28 11:32:57 --> Hooks Class Initialized
DEBUG - 2017-06-28 11:32:57 --> UTF-8 Support Enabled
INFO - 2017-06-28 11:32:57 --> Utf8 Class Initialized
INFO - 2017-06-28 11:32:57 --> URI Class Initialized
INFO - 2017-06-28 11:32:57 --> Router Class Initialized
INFO - 2017-06-28 11:32:57 --> Output Class Initialized
INFO - 2017-06-28 11:32:57 --> Security Class Initialized
DEBUG - 2017-06-28 11:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 11:32:57 --> Input Class Initialized
INFO - 2017-06-28 11:32:57 --> Language Class Initialized
INFO - 2017-06-28 11:32:57 --> Loader Class Initialized
INFO - 2017-06-28 11:32:57 --> Controller Class Initialized
INFO - 2017-06-28 11:32:58 --> Database Driver Class Initialized
INFO - 2017-06-28 11:32:58 --> Model Class Initialized
INFO - 2017-06-28 11:32:58 --> Helper loaded: form_helper
INFO - 2017-06-28 11:32:58 --> Helper loaded: url_helper
INFO - 2017-06-28 11:32:58 --> Model Class Initialized
INFO - 2017-06-28 11:32:58 --> Final output sent to browser
DEBUG - 2017-06-28 11:32:58 --> Total execution time: 0.0460
ERROR - 2017-06-28 11:33:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 11:33:15 --> Config Class Initialized
INFO - 2017-06-28 11:33:15 --> Hooks Class Initialized
DEBUG - 2017-06-28 11:33:15 --> UTF-8 Support Enabled
INFO - 2017-06-28 11:33:15 --> Utf8 Class Initialized
INFO - 2017-06-28 11:33:15 --> URI Class Initialized
INFO - 2017-06-28 11:33:15 --> Router Class Initialized
INFO - 2017-06-28 11:33:15 --> Output Class Initialized
INFO - 2017-06-28 11:33:15 --> Security Class Initialized
DEBUG - 2017-06-28 11:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 11:33:15 --> Input Class Initialized
INFO - 2017-06-28 11:33:15 --> Language Class Initialized
INFO - 2017-06-28 11:33:15 --> Loader Class Initialized
INFO - 2017-06-28 11:33:15 --> Controller Class Initialized
INFO - 2017-06-28 11:33:15 --> Database Driver Class Initialized
INFO - 2017-06-28 11:33:15 --> Model Class Initialized
INFO - 2017-06-28 11:33:15 --> Helper loaded: form_helper
INFO - 2017-06-28 11:33:15 --> Helper loaded: url_helper
INFO - 2017-06-28 11:33:15 --> Model Class Initialized
INFO - 2017-06-28 11:33:15 --> Final output sent to browser
DEBUG - 2017-06-28 11:33:15 --> Total execution time: 0.0590
ERROR - 2017-06-28 11:33:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 11:33:23 --> Config Class Initialized
INFO - 2017-06-28 11:33:23 --> Hooks Class Initialized
DEBUG - 2017-06-28 11:33:23 --> UTF-8 Support Enabled
INFO - 2017-06-28 11:33:23 --> Utf8 Class Initialized
INFO - 2017-06-28 11:33:23 --> URI Class Initialized
INFO - 2017-06-28 11:33:23 --> Router Class Initialized
INFO - 2017-06-28 11:33:23 --> Output Class Initialized
INFO - 2017-06-28 11:33:23 --> Security Class Initialized
DEBUG - 2017-06-28 11:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 11:33:23 --> Input Class Initialized
INFO - 2017-06-28 11:33:23 --> Language Class Initialized
INFO - 2017-06-28 11:33:23 --> Loader Class Initialized
INFO - 2017-06-28 11:33:23 --> Controller Class Initialized
INFO - 2017-06-28 11:33:23 --> Database Driver Class Initialized
INFO - 2017-06-28 11:33:23 --> Model Class Initialized
INFO - 2017-06-28 11:33:23 --> Helper loaded: form_helper
INFO - 2017-06-28 11:33:23 --> Helper loaded: url_helper
INFO - 2017-06-28 11:33:23 --> Model Class Initialized
INFO - 2017-06-28 11:33:23 --> Final output sent to browser
DEBUG - 2017-06-28 11:33:23 --> Total execution time: 0.0450
ERROR - 2017-06-28 11:33:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 11:33:43 --> Config Class Initialized
INFO - 2017-06-28 11:33:43 --> Hooks Class Initialized
DEBUG - 2017-06-28 11:33:43 --> UTF-8 Support Enabled
INFO - 2017-06-28 11:33:43 --> Utf8 Class Initialized
INFO - 2017-06-28 11:33:43 --> URI Class Initialized
INFO - 2017-06-28 11:33:43 --> Router Class Initialized
INFO - 2017-06-28 11:33:43 --> Output Class Initialized
INFO - 2017-06-28 11:33:43 --> Security Class Initialized
DEBUG - 2017-06-28 11:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 11:33:43 --> Input Class Initialized
INFO - 2017-06-28 11:33:43 --> Language Class Initialized
INFO - 2017-06-28 11:33:43 --> Loader Class Initialized
INFO - 2017-06-28 11:33:43 --> Controller Class Initialized
INFO - 2017-06-28 11:33:43 --> Database Driver Class Initialized
INFO - 2017-06-28 11:33:43 --> Model Class Initialized
INFO - 2017-06-28 11:33:43 --> Helper loaded: form_helper
INFO - 2017-06-28 11:33:43 --> Helper loaded: url_helper
INFO - 2017-06-28 11:33:43 --> Model Class Initialized
INFO - 2017-06-28 11:33:43 --> Final output sent to browser
DEBUG - 2017-06-28 11:33:43 --> Total execution time: 0.0430
ERROR - 2017-06-28 12:13:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 12:13:35 --> Config Class Initialized
INFO - 2017-06-28 12:13:35 --> Hooks Class Initialized
DEBUG - 2017-06-28 12:13:35 --> UTF-8 Support Enabled
INFO - 2017-06-28 12:13:35 --> Utf8 Class Initialized
INFO - 2017-06-28 12:13:35 --> URI Class Initialized
INFO - 2017-06-28 12:13:35 --> Router Class Initialized
INFO - 2017-06-28 12:13:35 --> Output Class Initialized
INFO - 2017-06-28 12:13:35 --> Security Class Initialized
DEBUG - 2017-06-28 12:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 12:13:35 --> Input Class Initialized
INFO - 2017-06-28 12:13:35 --> Language Class Initialized
INFO - 2017-06-28 12:13:35 --> Loader Class Initialized
INFO - 2017-06-28 12:13:35 --> Controller Class Initialized
INFO - 2017-06-28 12:13:35 --> Database Driver Class Initialized
INFO - 2017-06-28 12:13:35 --> Model Class Initialized
INFO - 2017-06-28 12:13:35 --> Helper loaded: form_helper
INFO - 2017-06-28 12:13:35 --> Helper loaded: url_helper
INFO - 2017-06-28 12:13:35 --> Model Class Initialized
INFO - 2017-06-28 12:13:35 --> Final output sent to browser
DEBUG - 2017-06-28 12:13:35 --> Total execution time: 0.1190
ERROR - 2017-06-28 12:20:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 12:20:16 --> Config Class Initialized
INFO - 2017-06-28 12:20:16 --> Hooks Class Initialized
DEBUG - 2017-06-28 12:20:16 --> UTF-8 Support Enabled
INFO - 2017-06-28 12:20:16 --> Utf8 Class Initialized
INFO - 2017-06-28 12:20:16 --> URI Class Initialized
INFO - 2017-06-28 12:20:16 --> Router Class Initialized
INFO - 2017-06-28 12:20:16 --> Output Class Initialized
INFO - 2017-06-28 12:20:16 --> Security Class Initialized
DEBUG - 2017-06-28 12:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 12:20:16 --> Input Class Initialized
INFO - 2017-06-28 12:20:16 --> Language Class Initialized
INFO - 2017-06-28 12:20:16 --> Loader Class Initialized
INFO - 2017-06-28 12:20:16 --> Controller Class Initialized
INFO - 2017-06-28 12:20:16 --> Database Driver Class Initialized
INFO - 2017-06-28 12:20:16 --> Model Class Initialized
INFO - 2017-06-28 12:20:16 --> Helper loaded: form_helper
INFO - 2017-06-28 12:20:16 --> Helper loaded: url_helper
INFO - 2017-06-28 12:20:16 --> Model Class Initialized
INFO - 2017-06-28 12:20:16 --> Final output sent to browser
DEBUG - 2017-06-28 12:20:16 --> Total execution time: 0.0490
ERROR - 2017-06-28 12:20:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 12:20:28 --> Config Class Initialized
INFO - 2017-06-28 12:20:28 --> Hooks Class Initialized
DEBUG - 2017-06-28 12:20:28 --> UTF-8 Support Enabled
INFO - 2017-06-28 12:20:28 --> Utf8 Class Initialized
INFO - 2017-06-28 12:20:28 --> URI Class Initialized
INFO - 2017-06-28 12:20:28 --> Router Class Initialized
INFO - 2017-06-28 12:20:28 --> Output Class Initialized
INFO - 2017-06-28 12:20:28 --> Security Class Initialized
DEBUG - 2017-06-28 12:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 12:20:28 --> Input Class Initialized
INFO - 2017-06-28 12:20:28 --> Language Class Initialized
INFO - 2017-06-28 12:20:28 --> Loader Class Initialized
INFO - 2017-06-28 12:20:28 --> Controller Class Initialized
INFO - 2017-06-28 12:20:28 --> Database Driver Class Initialized
INFO - 2017-06-28 12:20:28 --> Model Class Initialized
INFO - 2017-06-28 12:20:28 --> Helper loaded: form_helper
INFO - 2017-06-28 12:20:28 --> Helper loaded: url_helper
INFO - 2017-06-28 12:20:28 --> Model Class Initialized
INFO - 2017-06-28 12:20:28 --> Final output sent to browser
DEBUG - 2017-06-28 12:20:28 --> Total execution time: 0.0460
ERROR - 2017-06-28 12:26:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 12:26:29 --> Config Class Initialized
INFO - 2017-06-28 12:26:29 --> Hooks Class Initialized
DEBUG - 2017-06-28 12:26:29 --> UTF-8 Support Enabled
INFO - 2017-06-28 12:26:29 --> Utf8 Class Initialized
INFO - 2017-06-28 12:26:29 --> URI Class Initialized
INFO - 2017-06-28 12:26:29 --> Router Class Initialized
INFO - 2017-06-28 12:26:29 --> Output Class Initialized
INFO - 2017-06-28 12:26:29 --> Security Class Initialized
DEBUG - 2017-06-28 12:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 12:26:29 --> Input Class Initialized
INFO - 2017-06-28 12:26:29 --> Language Class Initialized
INFO - 2017-06-28 12:26:29 --> Loader Class Initialized
INFO - 2017-06-28 12:26:29 --> Controller Class Initialized
INFO - 2017-06-28 12:26:29 --> Database Driver Class Initialized
INFO - 2017-06-28 12:26:29 --> Model Class Initialized
INFO - 2017-06-28 12:26:29 --> Helper loaded: form_helper
INFO - 2017-06-28 12:26:29 --> Helper loaded: url_helper
INFO - 2017-06-28 12:26:29 --> Model Class Initialized
INFO - 2017-06-28 12:26:29 --> Final output sent to browser
DEBUG - 2017-06-28 12:26:29 --> Total execution time: 0.0490
ERROR - 2017-06-28 12:26:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 12:26:31 --> Config Class Initialized
INFO - 2017-06-28 12:26:31 --> Hooks Class Initialized
DEBUG - 2017-06-28 12:26:31 --> UTF-8 Support Enabled
INFO - 2017-06-28 12:26:31 --> Utf8 Class Initialized
INFO - 2017-06-28 12:26:31 --> URI Class Initialized
INFO - 2017-06-28 12:26:31 --> Router Class Initialized
INFO - 2017-06-28 12:26:31 --> Output Class Initialized
INFO - 2017-06-28 12:26:31 --> Security Class Initialized
DEBUG - 2017-06-28 12:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 12:26:31 --> Input Class Initialized
INFO - 2017-06-28 12:26:31 --> Language Class Initialized
INFO - 2017-06-28 12:26:31 --> Loader Class Initialized
INFO - 2017-06-28 12:26:31 --> Controller Class Initialized
INFO - 2017-06-28 12:26:31 --> Database Driver Class Initialized
INFO - 2017-06-28 12:26:31 --> Model Class Initialized
INFO - 2017-06-28 12:26:31 --> Helper loaded: form_helper
INFO - 2017-06-28 12:26:31 --> Helper loaded: url_helper
INFO - 2017-06-28 12:26:31 --> Model Class Initialized
INFO - 2017-06-28 12:26:31 --> Final output sent to browser
DEBUG - 2017-06-28 12:26:31 --> Total execution time: 0.0520
ERROR - 2017-06-28 13:17:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 13:17:26 --> Config Class Initialized
INFO - 2017-06-28 13:17:26 --> Hooks Class Initialized
DEBUG - 2017-06-28 13:17:26 --> UTF-8 Support Enabled
INFO - 2017-06-28 13:17:26 --> Utf8 Class Initialized
INFO - 2017-06-28 13:17:26 --> URI Class Initialized
INFO - 2017-06-28 13:17:26 --> Router Class Initialized
INFO - 2017-06-28 13:17:26 --> Output Class Initialized
INFO - 2017-06-28 13:17:26 --> Security Class Initialized
DEBUG - 2017-06-28 13:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 13:17:26 --> Input Class Initialized
INFO - 2017-06-28 13:17:26 --> Language Class Initialized
INFO - 2017-06-28 13:17:26 --> Loader Class Initialized
INFO - 2017-06-28 13:17:26 --> Controller Class Initialized
INFO - 2017-06-28 13:17:26 --> Database Driver Class Initialized
INFO - 2017-06-28 13:17:26 --> Model Class Initialized
INFO - 2017-06-28 13:17:26 --> Helper loaded: form_helper
INFO - 2017-06-28 13:17:26 --> Helper loaded: url_helper
INFO - 2017-06-28 13:17:26 --> Model Class Initialized
INFO - 2017-06-28 13:17:26 --> Final output sent to browser
DEBUG - 2017-06-28 13:17:26 --> Total execution time: 0.0800
ERROR - 2017-06-28 14:18:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 14:18:40 --> Config Class Initialized
INFO - 2017-06-28 14:18:40 --> Hooks Class Initialized
DEBUG - 2017-06-28 14:18:40 --> UTF-8 Support Enabled
INFO - 2017-06-28 14:18:40 --> Utf8 Class Initialized
INFO - 2017-06-28 14:18:40 --> URI Class Initialized
INFO - 2017-06-28 14:18:40 --> Router Class Initialized
INFO - 2017-06-28 14:18:40 --> Output Class Initialized
INFO - 2017-06-28 14:18:40 --> Security Class Initialized
DEBUG - 2017-06-28 14:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 14:18:40 --> Input Class Initialized
INFO - 2017-06-28 14:18:40 --> Language Class Initialized
INFO - 2017-06-28 14:18:40 --> Loader Class Initialized
INFO - 2017-06-28 14:18:40 --> Controller Class Initialized
INFO - 2017-06-28 14:18:40 --> Database Driver Class Initialized
INFO - 2017-06-28 14:18:40 --> Model Class Initialized
INFO - 2017-06-28 14:18:40 --> Helper loaded: form_helper
INFO - 2017-06-28 14:18:40 --> Helper loaded: url_helper
INFO - 2017-06-28 14:18:40 --> Model Class Initialized
INFO - 2017-06-28 14:18:40 --> Final output sent to browser
DEBUG - 2017-06-28 14:18:40 --> Total execution time: 0.0500
ERROR - 2017-06-28 14:18:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 14:18:43 --> Config Class Initialized
INFO - 2017-06-28 14:18:43 --> Hooks Class Initialized
DEBUG - 2017-06-28 14:18:43 --> UTF-8 Support Enabled
INFO - 2017-06-28 14:18:43 --> Utf8 Class Initialized
INFO - 2017-06-28 14:18:43 --> URI Class Initialized
INFO - 2017-06-28 14:18:43 --> Router Class Initialized
INFO - 2017-06-28 14:18:43 --> Output Class Initialized
INFO - 2017-06-28 14:18:43 --> Security Class Initialized
DEBUG - 2017-06-28 14:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 14:18:43 --> Input Class Initialized
INFO - 2017-06-28 14:18:43 --> Language Class Initialized
INFO - 2017-06-28 14:18:43 --> Loader Class Initialized
INFO - 2017-06-28 14:18:43 --> Controller Class Initialized
INFO - 2017-06-28 14:18:43 --> Database Driver Class Initialized
INFO - 2017-06-28 14:18:43 --> Model Class Initialized
INFO - 2017-06-28 14:18:43 --> Helper loaded: form_helper
INFO - 2017-06-28 14:18:43 --> Helper loaded: url_helper
INFO - 2017-06-28 14:18:43 --> Model Class Initialized
INFO - 2017-06-28 14:18:43 --> Final output sent to browser
DEBUG - 2017-06-28 14:18:43 --> Total execution time: 0.0575
ERROR - 2017-06-28 14:19:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 14:19:55 --> Config Class Initialized
INFO - 2017-06-28 14:19:55 --> Hooks Class Initialized
DEBUG - 2017-06-28 14:19:55 --> UTF-8 Support Enabled
INFO - 2017-06-28 14:19:55 --> Utf8 Class Initialized
INFO - 2017-06-28 14:19:55 --> URI Class Initialized
INFO - 2017-06-28 14:19:55 --> Router Class Initialized
INFO - 2017-06-28 14:19:55 --> Output Class Initialized
INFO - 2017-06-28 14:19:55 --> Security Class Initialized
DEBUG - 2017-06-28 14:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 14:19:55 --> Input Class Initialized
INFO - 2017-06-28 14:19:55 --> Language Class Initialized
INFO - 2017-06-28 14:19:55 --> Loader Class Initialized
INFO - 2017-06-28 14:19:55 --> Controller Class Initialized
INFO - 2017-06-28 14:19:55 --> Database Driver Class Initialized
INFO - 2017-06-28 14:19:55 --> Model Class Initialized
INFO - 2017-06-28 14:19:55 --> Helper loaded: form_helper
INFO - 2017-06-28 14:19:55 --> Helper loaded: url_helper
INFO - 2017-06-28 14:19:55 --> Model Class Initialized
INFO - 2017-06-28 14:19:55 --> Final output sent to browser
DEBUG - 2017-06-28 14:19:55 --> Total execution time: 0.0550
ERROR - 2017-06-28 14:19:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 14:19:56 --> Config Class Initialized
INFO - 2017-06-28 14:19:56 --> Hooks Class Initialized
DEBUG - 2017-06-28 14:19:56 --> UTF-8 Support Enabled
INFO - 2017-06-28 14:19:56 --> Utf8 Class Initialized
INFO - 2017-06-28 14:19:56 --> URI Class Initialized
INFO - 2017-06-28 14:19:56 --> Router Class Initialized
INFO - 2017-06-28 14:19:56 --> Output Class Initialized
INFO - 2017-06-28 14:19:56 --> Security Class Initialized
DEBUG - 2017-06-28 14:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 14:19:56 --> Input Class Initialized
INFO - 2017-06-28 14:19:56 --> Language Class Initialized
INFO - 2017-06-28 14:19:56 --> Loader Class Initialized
INFO - 2017-06-28 14:19:56 --> Controller Class Initialized
INFO - 2017-06-28 14:19:56 --> Database Driver Class Initialized
INFO - 2017-06-28 14:19:56 --> Model Class Initialized
INFO - 2017-06-28 14:19:56 --> Helper loaded: form_helper
INFO - 2017-06-28 14:19:56 --> Helper loaded: url_helper
INFO - 2017-06-28 14:19:56 --> Model Class Initialized
INFO - 2017-06-28 14:19:56 --> Final output sent to browser
DEBUG - 2017-06-28 14:19:56 --> Total execution time: 0.0500
ERROR - 2017-06-28 14:20:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 14:20:40 --> Config Class Initialized
INFO - 2017-06-28 14:20:40 --> Hooks Class Initialized
DEBUG - 2017-06-28 14:20:40 --> UTF-8 Support Enabled
INFO - 2017-06-28 14:20:40 --> Utf8 Class Initialized
INFO - 2017-06-28 14:20:40 --> URI Class Initialized
INFO - 2017-06-28 14:20:40 --> Router Class Initialized
INFO - 2017-06-28 14:20:40 --> Output Class Initialized
INFO - 2017-06-28 14:20:40 --> Security Class Initialized
DEBUG - 2017-06-28 14:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 14:20:40 --> Input Class Initialized
INFO - 2017-06-28 14:20:40 --> Language Class Initialized
INFO - 2017-06-28 14:20:40 --> Loader Class Initialized
INFO - 2017-06-28 14:20:40 --> Controller Class Initialized
INFO - 2017-06-28 14:20:40 --> Database Driver Class Initialized
INFO - 2017-06-28 14:20:40 --> Model Class Initialized
INFO - 2017-06-28 14:20:40 --> Helper loaded: form_helper
INFO - 2017-06-28 14:20:40 --> Helper loaded: url_helper
INFO - 2017-06-28 14:20:40 --> Model Class Initialized
INFO - 2017-06-28 14:20:40 --> Final output sent to browser
DEBUG - 2017-06-28 14:20:40 --> Total execution time: 0.0600
ERROR - 2017-06-28 14:21:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 14:21:43 --> Config Class Initialized
INFO - 2017-06-28 14:21:43 --> Hooks Class Initialized
DEBUG - 2017-06-28 14:21:43 --> UTF-8 Support Enabled
INFO - 2017-06-28 14:21:43 --> Utf8 Class Initialized
INFO - 2017-06-28 14:21:43 --> URI Class Initialized
INFO - 2017-06-28 14:21:43 --> Router Class Initialized
INFO - 2017-06-28 14:21:43 --> Output Class Initialized
INFO - 2017-06-28 14:21:43 --> Security Class Initialized
DEBUG - 2017-06-28 14:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 14:21:43 --> Input Class Initialized
INFO - 2017-06-28 14:21:43 --> Language Class Initialized
INFO - 2017-06-28 14:21:43 --> Loader Class Initialized
INFO - 2017-06-28 14:21:43 --> Controller Class Initialized
INFO - 2017-06-28 14:21:43 --> Database Driver Class Initialized
INFO - 2017-06-28 14:21:43 --> Model Class Initialized
INFO - 2017-06-28 14:21:43 --> Helper loaded: form_helper
INFO - 2017-06-28 14:21:43 --> Helper loaded: url_helper
INFO - 2017-06-28 14:21:43 --> Model Class Initialized
INFO - 2017-06-28 14:21:43 --> Final output sent to browser
DEBUG - 2017-06-28 14:21:43 --> Total execution time: 0.0450
ERROR - 2017-06-28 14:21:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 14:21:58 --> Config Class Initialized
INFO - 2017-06-28 14:21:58 --> Hooks Class Initialized
DEBUG - 2017-06-28 14:21:58 --> UTF-8 Support Enabled
INFO - 2017-06-28 14:21:58 --> Utf8 Class Initialized
INFO - 2017-06-28 14:21:58 --> URI Class Initialized
INFO - 2017-06-28 14:21:58 --> Router Class Initialized
INFO - 2017-06-28 14:21:58 --> Output Class Initialized
INFO - 2017-06-28 14:21:58 --> Security Class Initialized
DEBUG - 2017-06-28 14:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 14:21:58 --> Input Class Initialized
INFO - 2017-06-28 14:21:58 --> Language Class Initialized
INFO - 2017-06-28 14:21:58 --> Loader Class Initialized
INFO - 2017-06-28 14:21:58 --> Controller Class Initialized
INFO - 2017-06-28 14:21:58 --> Database Driver Class Initialized
INFO - 2017-06-28 14:21:58 --> Model Class Initialized
INFO - 2017-06-28 14:21:58 --> Helper loaded: form_helper
INFO - 2017-06-28 14:21:58 --> Helper loaded: url_helper
INFO - 2017-06-28 14:21:58 --> Model Class Initialized
INFO - 2017-06-28 14:21:58 --> Final output sent to browser
DEBUG - 2017-06-28 14:21:58 --> Total execution time: 0.0450
ERROR - 2017-06-28 14:23:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 14:23:28 --> Config Class Initialized
INFO - 2017-06-28 14:23:28 --> Hooks Class Initialized
DEBUG - 2017-06-28 14:23:28 --> UTF-8 Support Enabled
INFO - 2017-06-28 14:23:28 --> Utf8 Class Initialized
INFO - 2017-06-28 14:23:28 --> URI Class Initialized
INFO - 2017-06-28 14:23:28 --> Router Class Initialized
INFO - 2017-06-28 14:23:28 --> Output Class Initialized
INFO - 2017-06-28 14:23:28 --> Security Class Initialized
DEBUG - 2017-06-28 14:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 14:23:28 --> Input Class Initialized
INFO - 2017-06-28 14:23:28 --> Language Class Initialized
INFO - 2017-06-28 14:23:28 --> Loader Class Initialized
INFO - 2017-06-28 14:23:28 --> Controller Class Initialized
INFO - 2017-06-28 14:23:28 --> Database Driver Class Initialized
INFO - 2017-06-28 14:23:28 --> Model Class Initialized
INFO - 2017-06-28 14:23:28 --> Helper loaded: form_helper
INFO - 2017-06-28 14:23:28 --> Helper loaded: url_helper
INFO - 2017-06-28 14:23:28 --> Model Class Initialized
INFO - 2017-06-28 14:23:28 --> Final output sent to browser
DEBUG - 2017-06-28 14:23:28 --> Total execution time: 0.0750
ERROR - 2017-06-28 14:23:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 14:23:31 --> Config Class Initialized
INFO - 2017-06-28 14:23:31 --> Hooks Class Initialized
DEBUG - 2017-06-28 14:23:31 --> UTF-8 Support Enabled
INFO - 2017-06-28 14:23:31 --> Utf8 Class Initialized
INFO - 2017-06-28 14:23:31 --> URI Class Initialized
INFO - 2017-06-28 14:23:31 --> Router Class Initialized
INFO - 2017-06-28 14:23:31 --> Output Class Initialized
INFO - 2017-06-28 14:23:31 --> Security Class Initialized
DEBUG - 2017-06-28 14:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 14:23:31 --> Input Class Initialized
INFO - 2017-06-28 14:23:31 --> Language Class Initialized
INFO - 2017-06-28 14:23:31 --> Loader Class Initialized
INFO - 2017-06-28 14:23:31 --> Controller Class Initialized
INFO - 2017-06-28 14:23:31 --> Database Driver Class Initialized
INFO - 2017-06-28 14:23:31 --> Model Class Initialized
INFO - 2017-06-28 14:23:31 --> Helper loaded: form_helper
INFO - 2017-06-28 14:23:31 --> Helper loaded: url_helper
INFO - 2017-06-28 14:23:31 --> Model Class Initialized
INFO - 2017-06-28 14:23:31 --> Final output sent to browser
DEBUG - 2017-06-28 14:23:31 --> Total execution time: 0.0700
ERROR - 2017-06-28 14:23:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 14:23:33 --> Config Class Initialized
INFO - 2017-06-28 14:23:33 --> Hooks Class Initialized
DEBUG - 2017-06-28 14:23:33 --> UTF-8 Support Enabled
INFO - 2017-06-28 14:23:33 --> Utf8 Class Initialized
INFO - 2017-06-28 14:23:33 --> URI Class Initialized
INFO - 2017-06-28 14:23:33 --> Router Class Initialized
INFO - 2017-06-28 14:23:33 --> Output Class Initialized
INFO - 2017-06-28 14:23:33 --> Security Class Initialized
DEBUG - 2017-06-28 14:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 14:23:33 --> Input Class Initialized
INFO - 2017-06-28 14:23:33 --> Language Class Initialized
INFO - 2017-06-28 14:23:33 --> Loader Class Initialized
INFO - 2017-06-28 14:23:33 --> Controller Class Initialized
INFO - 2017-06-28 14:23:33 --> Database Driver Class Initialized
INFO - 2017-06-28 14:23:33 --> Model Class Initialized
INFO - 2017-06-28 14:23:33 --> Helper loaded: form_helper
INFO - 2017-06-28 14:23:33 --> Helper loaded: url_helper
INFO - 2017-06-28 14:23:33 --> Model Class Initialized
INFO - 2017-06-28 14:23:33 --> Final output sent to browser
DEBUG - 2017-06-28 14:23:33 --> Total execution time: 0.0650
ERROR - 2017-06-28 16:37:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 16:37:47 --> Config Class Initialized
INFO - 2017-06-28 16:37:47 --> Hooks Class Initialized
DEBUG - 2017-06-28 16:37:47 --> UTF-8 Support Enabled
INFO - 2017-06-28 16:37:47 --> Utf8 Class Initialized
INFO - 2017-06-28 16:37:47 --> URI Class Initialized
INFO - 2017-06-28 16:37:47 --> Router Class Initialized
INFO - 2017-06-28 16:37:47 --> Output Class Initialized
INFO - 2017-06-28 16:37:47 --> Security Class Initialized
DEBUG - 2017-06-28 16:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 16:37:47 --> Input Class Initialized
INFO - 2017-06-28 16:37:47 --> Language Class Initialized
INFO - 2017-06-28 16:37:47 --> Loader Class Initialized
INFO - 2017-06-28 16:37:47 --> Controller Class Initialized
INFO - 2017-06-28 16:37:47 --> Database Driver Class Initialized
INFO - 2017-06-28 16:37:47 --> Model Class Initialized
INFO - 2017-06-28 16:37:47 --> Helper loaded: form_helper
INFO - 2017-06-28 16:37:47 --> Helper loaded: url_helper
INFO - 2017-06-28 16:37:47 --> Model Class Initialized
INFO - 2017-06-28 16:37:47 --> Final output sent to browser
DEBUG - 2017-06-28 16:37:47 --> Total execution time: 0.0550
ERROR - 2017-06-28 16:37:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 16:37:57 --> Config Class Initialized
INFO - 2017-06-28 16:37:57 --> Hooks Class Initialized
DEBUG - 2017-06-28 16:37:57 --> UTF-8 Support Enabled
INFO - 2017-06-28 16:37:57 --> Utf8 Class Initialized
INFO - 2017-06-28 16:37:57 --> URI Class Initialized
INFO - 2017-06-28 16:37:57 --> Router Class Initialized
INFO - 2017-06-28 16:37:57 --> Output Class Initialized
INFO - 2017-06-28 16:37:57 --> Security Class Initialized
DEBUG - 2017-06-28 16:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 16:37:57 --> Input Class Initialized
INFO - 2017-06-28 16:37:57 --> Language Class Initialized
INFO - 2017-06-28 16:37:57 --> Loader Class Initialized
INFO - 2017-06-28 16:37:57 --> Controller Class Initialized
INFO - 2017-06-28 16:37:57 --> Database Driver Class Initialized
INFO - 2017-06-28 16:37:57 --> Model Class Initialized
INFO - 2017-06-28 16:37:57 --> Helper loaded: form_helper
INFO - 2017-06-28 16:37:57 --> Helper loaded: url_helper
INFO - 2017-06-28 16:37:57 --> Model Class Initialized
INFO - 2017-06-28 16:37:57 --> Final output sent to browser
DEBUG - 2017-06-28 16:37:57 --> Total execution time: 0.0625
ERROR - 2017-06-28 16:38:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 16:38:01 --> Config Class Initialized
INFO - 2017-06-28 16:38:01 --> Hooks Class Initialized
DEBUG - 2017-06-28 16:38:01 --> UTF-8 Support Enabled
INFO - 2017-06-28 16:38:01 --> Utf8 Class Initialized
INFO - 2017-06-28 16:38:01 --> URI Class Initialized
INFO - 2017-06-28 16:38:01 --> Router Class Initialized
INFO - 2017-06-28 16:38:01 --> Output Class Initialized
INFO - 2017-06-28 16:38:01 --> Security Class Initialized
DEBUG - 2017-06-28 16:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 16:38:01 --> Input Class Initialized
INFO - 2017-06-28 16:38:01 --> Language Class Initialized
INFO - 2017-06-28 16:38:01 --> Loader Class Initialized
INFO - 2017-06-28 16:38:01 --> Controller Class Initialized
INFO - 2017-06-28 16:38:01 --> Database Driver Class Initialized
INFO - 2017-06-28 16:38:01 --> Model Class Initialized
INFO - 2017-06-28 16:38:01 --> Helper loaded: form_helper
INFO - 2017-06-28 16:38:01 --> Helper loaded: url_helper
INFO - 2017-06-28 16:38:01 --> Model Class Initialized
INFO - 2017-06-28 16:38:01 --> Final output sent to browser
DEBUG - 2017-06-28 16:38:01 --> Total execution time: 0.0675
ERROR - 2017-06-28 16:38:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 16:38:38 --> Config Class Initialized
INFO - 2017-06-28 16:38:38 --> Hooks Class Initialized
DEBUG - 2017-06-28 16:38:38 --> UTF-8 Support Enabled
INFO - 2017-06-28 16:38:38 --> Utf8 Class Initialized
INFO - 2017-06-28 16:38:38 --> URI Class Initialized
INFO - 2017-06-28 16:38:38 --> Router Class Initialized
INFO - 2017-06-28 16:38:38 --> Output Class Initialized
INFO - 2017-06-28 16:38:38 --> Security Class Initialized
DEBUG - 2017-06-28 16:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 16:38:38 --> Input Class Initialized
INFO - 2017-06-28 16:38:38 --> Language Class Initialized
INFO - 2017-06-28 16:38:38 --> Loader Class Initialized
INFO - 2017-06-28 16:38:38 --> Controller Class Initialized
INFO - 2017-06-28 16:38:38 --> Database Driver Class Initialized
INFO - 2017-06-28 16:38:38 --> Model Class Initialized
INFO - 2017-06-28 16:38:38 --> Helper loaded: form_helper
INFO - 2017-06-28 16:38:38 --> Helper loaded: url_helper
INFO - 2017-06-28 16:38:38 --> Model Class Initialized
INFO - 2017-06-28 16:38:38 --> Final output sent to browser
DEBUG - 2017-06-28 16:38:38 --> Total execution time: 0.0600
ERROR - 2017-06-28 16:38:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 16:38:40 --> Config Class Initialized
INFO - 2017-06-28 16:38:40 --> Hooks Class Initialized
DEBUG - 2017-06-28 16:38:40 --> UTF-8 Support Enabled
INFO - 2017-06-28 16:38:40 --> Utf8 Class Initialized
INFO - 2017-06-28 16:38:40 --> URI Class Initialized
INFO - 2017-06-28 16:38:40 --> Router Class Initialized
INFO - 2017-06-28 16:38:40 --> Output Class Initialized
INFO - 2017-06-28 16:38:40 --> Security Class Initialized
DEBUG - 2017-06-28 16:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 16:38:40 --> Input Class Initialized
INFO - 2017-06-28 16:38:40 --> Language Class Initialized
INFO - 2017-06-28 16:38:40 --> Loader Class Initialized
INFO - 2017-06-28 16:38:40 --> Controller Class Initialized
INFO - 2017-06-28 16:38:40 --> Database Driver Class Initialized
INFO - 2017-06-28 16:38:40 --> Model Class Initialized
INFO - 2017-06-28 16:38:40 --> Helper loaded: form_helper
INFO - 2017-06-28 16:38:40 --> Helper loaded: url_helper
INFO - 2017-06-28 16:38:40 --> Model Class Initialized
INFO - 2017-06-28 16:38:40 --> Final output sent to browser
DEBUG - 2017-06-28 16:38:40 --> Total execution time: 0.0590
ERROR - 2017-06-28 16:38:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 16:38:41 --> Config Class Initialized
INFO - 2017-06-28 16:38:41 --> Hooks Class Initialized
DEBUG - 2017-06-28 16:38:41 --> UTF-8 Support Enabled
INFO - 2017-06-28 16:38:41 --> Utf8 Class Initialized
INFO - 2017-06-28 16:38:41 --> URI Class Initialized
INFO - 2017-06-28 16:38:41 --> Router Class Initialized
INFO - 2017-06-28 16:38:41 --> Output Class Initialized
INFO - 2017-06-28 16:38:41 --> Security Class Initialized
DEBUG - 2017-06-28 16:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 16:38:41 --> Input Class Initialized
INFO - 2017-06-28 16:38:41 --> Language Class Initialized
INFO - 2017-06-28 16:38:41 --> Loader Class Initialized
INFO - 2017-06-28 16:38:41 --> Controller Class Initialized
INFO - 2017-06-28 16:38:41 --> Database Driver Class Initialized
INFO - 2017-06-28 16:38:41 --> Model Class Initialized
INFO - 2017-06-28 16:38:41 --> Helper loaded: form_helper
INFO - 2017-06-28 16:38:41 --> Helper loaded: url_helper
INFO - 2017-06-28 16:38:41 --> Model Class Initialized
INFO - 2017-06-28 16:38:41 --> Final output sent to browser
DEBUG - 2017-06-28 16:38:41 --> Total execution time: 0.0600
ERROR - 2017-06-28 16:41:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 16:41:41 --> Config Class Initialized
INFO - 2017-06-28 16:41:41 --> Hooks Class Initialized
DEBUG - 2017-06-28 16:41:41 --> UTF-8 Support Enabled
INFO - 2017-06-28 16:41:41 --> Utf8 Class Initialized
INFO - 2017-06-28 16:41:41 --> URI Class Initialized
INFO - 2017-06-28 16:41:41 --> Router Class Initialized
INFO - 2017-06-28 16:41:41 --> Output Class Initialized
INFO - 2017-06-28 16:41:41 --> Security Class Initialized
DEBUG - 2017-06-28 16:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 16:41:41 --> Input Class Initialized
INFO - 2017-06-28 16:41:41 --> Language Class Initialized
INFO - 2017-06-28 16:41:41 --> Loader Class Initialized
INFO - 2017-06-28 16:41:41 --> Controller Class Initialized
INFO - 2017-06-28 16:41:41 --> Database Driver Class Initialized
INFO - 2017-06-28 16:41:41 --> Model Class Initialized
INFO - 2017-06-28 16:41:41 --> Helper loaded: form_helper
INFO - 2017-06-28 16:41:41 --> Helper loaded: url_helper
INFO - 2017-06-28 16:41:41 --> Model Class Initialized
INFO - 2017-06-28 16:41:41 --> Final output sent to browser
DEBUG - 2017-06-28 16:41:41 --> Total execution time: 0.0525
ERROR - 2017-06-28 16:46:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 16:46:00 --> Config Class Initialized
INFO - 2017-06-28 16:46:00 --> Hooks Class Initialized
DEBUG - 2017-06-28 16:46:00 --> UTF-8 Support Enabled
INFO - 2017-06-28 16:46:00 --> Utf8 Class Initialized
INFO - 2017-06-28 16:46:00 --> URI Class Initialized
INFO - 2017-06-28 16:46:00 --> Router Class Initialized
INFO - 2017-06-28 16:46:00 --> Output Class Initialized
INFO - 2017-06-28 16:46:00 --> Security Class Initialized
DEBUG - 2017-06-28 16:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 16:46:00 --> Input Class Initialized
INFO - 2017-06-28 16:46:00 --> Language Class Initialized
INFO - 2017-06-28 16:46:00 --> Loader Class Initialized
INFO - 2017-06-28 16:46:00 --> Controller Class Initialized
INFO - 2017-06-28 16:46:00 --> Database Driver Class Initialized
INFO - 2017-06-28 16:46:01 --> Model Class Initialized
INFO - 2017-06-28 16:46:01 --> Helper loaded: form_helper
INFO - 2017-06-28 16:46:01 --> Helper loaded: url_helper
INFO - 2017-06-28 16:46:01 --> Model Class Initialized
INFO - 2017-06-28 16:46:01 --> Final output sent to browser
DEBUG - 2017-06-28 16:46:01 --> Total execution time: 0.0550
ERROR - 2017-06-28 16:46:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 16:46:03 --> Config Class Initialized
INFO - 2017-06-28 16:46:03 --> Hooks Class Initialized
DEBUG - 2017-06-28 16:46:03 --> UTF-8 Support Enabled
INFO - 2017-06-28 16:46:03 --> Utf8 Class Initialized
INFO - 2017-06-28 16:46:04 --> URI Class Initialized
INFO - 2017-06-28 16:46:04 --> Router Class Initialized
INFO - 2017-06-28 16:46:04 --> Output Class Initialized
INFO - 2017-06-28 16:46:04 --> Security Class Initialized
DEBUG - 2017-06-28 16:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 16:46:04 --> Input Class Initialized
INFO - 2017-06-28 16:46:04 --> Language Class Initialized
INFO - 2017-06-28 16:46:04 --> Loader Class Initialized
INFO - 2017-06-28 16:46:04 --> Controller Class Initialized
INFO - 2017-06-28 16:46:04 --> Database Driver Class Initialized
INFO - 2017-06-28 16:46:04 --> Model Class Initialized
INFO - 2017-06-28 16:46:04 --> Helper loaded: form_helper
INFO - 2017-06-28 16:46:04 --> Helper loaded: url_helper
INFO - 2017-06-28 16:46:04 --> Model Class Initialized
INFO - 2017-06-28 16:46:04 --> Final output sent to browser
DEBUG - 2017-06-28 16:46:04 --> Total execution time: 0.0475
ERROR - 2017-06-28 16:47:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 16:47:17 --> Config Class Initialized
INFO - 2017-06-28 16:47:17 --> Hooks Class Initialized
DEBUG - 2017-06-28 16:47:17 --> UTF-8 Support Enabled
INFO - 2017-06-28 16:47:17 --> Utf8 Class Initialized
INFO - 2017-06-28 16:47:17 --> URI Class Initialized
INFO - 2017-06-28 16:47:17 --> Router Class Initialized
INFO - 2017-06-28 16:47:17 --> Output Class Initialized
INFO - 2017-06-28 16:47:17 --> Security Class Initialized
DEBUG - 2017-06-28 16:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 16:47:17 --> Input Class Initialized
INFO - 2017-06-28 16:47:17 --> Language Class Initialized
INFO - 2017-06-28 16:47:17 --> Loader Class Initialized
INFO - 2017-06-28 16:47:17 --> Controller Class Initialized
INFO - 2017-06-28 16:47:17 --> Database Driver Class Initialized
INFO - 2017-06-28 16:47:17 --> Model Class Initialized
INFO - 2017-06-28 16:47:17 --> Helper loaded: form_helper
INFO - 2017-06-28 16:47:17 --> Helper loaded: url_helper
INFO - 2017-06-28 16:47:17 --> Model Class Initialized
INFO - 2017-06-28 16:47:17 --> Final output sent to browser
DEBUG - 2017-06-28 16:47:17 --> Total execution time: 0.0575
ERROR - 2017-06-28 16:47:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 16:47:18 --> Config Class Initialized
INFO - 2017-06-28 16:47:18 --> Hooks Class Initialized
DEBUG - 2017-06-28 16:47:18 --> UTF-8 Support Enabled
INFO - 2017-06-28 16:47:18 --> Utf8 Class Initialized
INFO - 2017-06-28 16:47:18 --> URI Class Initialized
INFO - 2017-06-28 16:47:18 --> Router Class Initialized
INFO - 2017-06-28 16:47:18 --> Output Class Initialized
INFO - 2017-06-28 16:47:18 --> Security Class Initialized
DEBUG - 2017-06-28 16:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 16:47:18 --> Input Class Initialized
INFO - 2017-06-28 16:47:18 --> Language Class Initialized
INFO - 2017-06-28 16:47:18 --> Loader Class Initialized
INFO - 2017-06-28 16:47:18 --> Controller Class Initialized
INFO - 2017-06-28 16:47:18 --> Database Driver Class Initialized
INFO - 2017-06-28 16:47:18 --> Model Class Initialized
INFO - 2017-06-28 16:47:18 --> Helper loaded: form_helper
INFO - 2017-06-28 16:47:18 --> Helper loaded: url_helper
INFO - 2017-06-28 16:47:18 --> Model Class Initialized
INFO - 2017-06-28 16:47:18 --> Final output sent to browser
DEBUG - 2017-06-28 16:47:18 --> Total execution time: 0.0465
ERROR - 2017-06-28 16:54:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 16:54:40 --> Config Class Initialized
INFO - 2017-06-28 16:54:40 --> Hooks Class Initialized
DEBUG - 2017-06-28 16:54:40 --> UTF-8 Support Enabled
INFO - 2017-06-28 16:54:40 --> Utf8 Class Initialized
INFO - 2017-06-28 16:54:40 --> URI Class Initialized
INFO - 2017-06-28 16:54:40 --> Router Class Initialized
INFO - 2017-06-28 16:54:40 --> Output Class Initialized
INFO - 2017-06-28 16:54:40 --> Security Class Initialized
DEBUG - 2017-06-28 16:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 16:54:40 --> Input Class Initialized
INFO - 2017-06-28 16:54:40 --> Language Class Initialized
INFO - 2017-06-28 16:54:40 --> Loader Class Initialized
INFO - 2017-06-28 16:54:40 --> Controller Class Initialized
INFO - 2017-06-28 16:54:40 --> Database Driver Class Initialized
INFO - 2017-06-28 16:54:40 --> Model Class Initialized
INFO - 2017-06-28 16:54:40 --> Helper loaded: form_helper
INFO - 2017-06-28 16:54:40 --> Helper loaded: url_helper
INFO - 2017-06-28 16:54:40 --> Model Class Initialized
INFO - 2017-06-28 16:54:40 --> Final output sent to browser
DEBUG - 2017-06-28 16:54:40 --> Total execution time: 0.0650
ERROR - 2017-06-28 16:54:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 16:54:42 --> Config Class Initialized
INFO - 2017-06-28 16:54:42 --> Hooks Class Initialized
DEBUG - 2017-06-28 16:54:42 --> UTF-8 Support Enabled
INFO - 2017-06-28 16:54:42 --> Utf8 Class Initialized
INFO - 2017-06-28 16:54:42 --> URI Class Initialized
INFO - 2017-06-28 16:54:42 --> Router Class Initialized
INFO - 2017-06-28 16:54:42 --> Output Class Initialized
INFO - 2017-06-28 16:54:42 --> Security Class Initialized
DEBUG - 2017-06-28 16:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 16:54:42 --> Input Class Initialized
INFO - 2017-06-28 16:54:42 --> Language Class Initialized
INFO - 2017-06-28 16:54:42 --> Loader Class Initialized
INFO - 2017-06-28 16:54:42 --> Controller Class Initialized
INFO - 2017-06-28 16:54:42 --> Database Driver Class Initialized
INFO - 2017-06-28 16:54:42 --> Model Class Initialized
INFO - 2017-06-28 16:54:42 --> Helper loaded: form_helper
INFO - 2017-06-28 16:54:42 --> Helper loaded: url_helper
INFO - 2017-06-28 16:54:42 --> Model Class Initialized
INFO - 2017-06-28 16:54:42 --> Final output sent to browser
DEBUG - 2017-06-28 16:54:42 --> Total execution time: 0.0600
ERROR - 2017-06-28 16:57:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 16:57:21 --> Config Class Initialized
INFO - 2017-06-28 16:57:21 --> Hooks Class Initialized
DEBUG - 2017-06-28 16:57:21 --> UTF-8 Support Enabled
INFO - 2017-06-28 16:57:21 --> Utf8 Class Initialized
INFO - 2017-06-28 16:57:21 --> URI Class Initialized
INFO - 2017-06-28 16:57:21 --> Router Class Initialized
INFO - 2017-06-28 16:57:21 --> Output Class Initialized
INFO - 2017-06-28 16:57:21 --> Security Class Initialized
DEBUG - 2017-06-28 16:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 16:57:21 --> Input Class Initialized
INFO - 2017-06-28 16:57:21 --> Language Class Initialized
INFO - 2017-06-28 16:57:21 --> Loader Class Initialized
INFO - 2017-06-28 16:57:21 --> Controller Class Initialized
INFO - 2017-06-28 16:57:21 --> Database Driver Class Initialized
INFO - 2017-06-28 16:57:21 --> Model Class Initialized
INFO - 2017-06-28 16:57:21 --> Helper loaded: form_helper
INFO - 2017-06-28 16:57:21 --> Helper loaded: url_helper
INFO - 2017-06-28 16:57:21 --> Model Class Initialized
INFO - 2017-06-28 16:57:21 --> Final output sent to browser
DEBUG - 2017-06-28 16:57:21 --> Total execution time: 0.0645
ERROR - 2017-06-28 16:57:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 16:57:23 --> Config Class Initialized
INFO - 2017-06-28 16:57:23 --> Hooks Class Initialized
DEBUG - 2017-06-28 16:57:23 --> UTF-8 Support Enabled
INFO - 2017-06-28 16:57:23 --> Utf8 Class Initialized
INFO - 2017-06-28 16:57:23 --> URI Class Initialized
INFO - 2017-06-28 16:57:23 --> Router Class Initialized
INFO - 2017-06-28 16:57:23 --> Output Class Initialized
INFO - 2017-06-28 16:57:23 --> Security Class Initialized
DEBUG - 2017-06-28 16:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 16:57:23 --> Input Class Initialized
INFO - 2017-06-28 16:57:23 --> Language Class Initialized
INFO - 2017-06-28 16:57:23 --> Loader Class Initialized
INFO - 2017-06-28 16:57:23 --> Controller Class Initialized
INFO - 2017-06-28 16:57:23 --> Database Driver Class Initialized
INFO - 2017-06-28 16:57:23 --> Model Class Initialized
INFO - 2017-06-28 16:57:23 --> Helper loaded: form_helper
INFO - 2017-06-28 16:57:23 --> Helper loaded: url_helper
INFO - 2017-06-28 16:57:23 --> Model Class Initialized
INFO - 2017-06-28 16:57:23 --> Final output sent to browser
DEBUG - 2017-06-28 16:57:23 --> Total execution time: 0.0550
ERROR - 2017-06-28 17:03:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:03:54 --> Config Class Initialized
INFO - 2017-06-28 17:03:54 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:03:54 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:03:54 --> Utf8 Class Initialized
INFO - 2017-06-28 17:03:54 --> URI Class Initialized
INFO - 2017-06-28 17:03:54 --> Router Class Initialized
INFO - 2017-06-28 17:03:54 --> Output Class Initialized
INFO - 2017-06-28 17:03:54 --> Security Class Initialized
DEBUG - 2017-06-28 17:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:03:54 --> Input Class Initialized
INFO - 2017-06-28 17:03:54 --> Language Class Initialized
INFO - 2017-06-28 17:03:54 --> Loader Class Initialized
INFO - 2017-06-28 17:03:54 --> Controller Class Initialized
INFO - 2017-06-28 17:03:54 --> Database Driver Class Initialized
INFO - 2017-06-28 17:03:54 --> Model Class Initialized
INFO - 2017-06-28 17:03:54 --> Helper loaded: form_helper
INFO - 2017-06-28 17:03:54 --> Helper loaded: url_helper
INFO - 2017-06-28 17:03:54 --> Model Class Initialized
INFO - 2017-06-28 17:03:54 --> Final output sent to browser
DEBUG - 2017-06-28 17:03:54 --> Total execution time: 0.0500
ERROR - 2017-06-28 17:03:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:03:57 --> Config Class Initialized
INFO - 2017-06-28 17:03:57 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:03:57 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:03:57 --> Utf8 Class Initialized
INFO - 2017-06-28 17:03:57 --> URI Class Initialized
INFO - 2017-06-28 17:03:57 --> Router Class Initialized
INFO - 2017-06-28 17:03:57 --> Output Class Initialized
INFO - 2017-06-28 17:03:57 --> Security Class Initialized
DEBUG - 2017-06-28 17:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:03:57 --> Input Class Initialized
INFO - 2017-06-28 17:03:57 --> Language Class Initialized
INFO - 2017-06-28 17:03:57 --> Loader Class Initialized
INFO - 2017-06-28 17:03:57 --> Controller Class Initialized
INFO - 2017-06-28 17:03:57 --> Database Driver Class Initialized
INFO - 2017-06-28 17:03:57 --> Model Class Initialized
INFO - 2017-06-28 17:03:57 --> Helper loaded: form_helper
INFO - 2017-06-28 17:03:57 --> Helper loaded: url_helper
INFO - 2017-06-28 17:03:57 --> Model Class Initialized
INFO - 2017-06-28 17:03:57 --> Final output sent to browser
DEBUG - 2017-06-28 17:03:57 --> Total execution time: 0.0600
ERROR - 2017-06-28 17:03:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:03:59 --> Config Class Initialized
INFO - 2017-06-28 17:03:59 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:03:59 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:03:59 --> Utf8 Class Initialized
INFO - 2017-06-28 17:03:59 --> URI Class Initialized
INFO - 2017-06-28 17:03:59 --> Router Class Initialized
INFO - 2017-06-28 17:03:59 --> Output Class Initialized
INFO - 2017-06-28 17:03:59 --> Security Class Initialized
DEBUG - 2017-06-28 17:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:03:59 --> Input Class Initialized
INFO - 2017-06-28 17:03:59 --> Language Class Initialized
INFO - 2017-06-28 17:03:59 --> Loader Class Initialized
INFO - 2017-06-28 17:03:59 --> Controller Class Initialized
INFO - 2017-06-28 17:03:59 --> Database Driver Class Initialized
INFO - 2017-06-28 17:03:59 --> Model Class Initialized
INFO - 2017-06-28 17:03:59 --> Helper loaded: form_helper
INFO - 2017-06-28 17:03:59 --> Helper loaded: url_helper
INFO - 2017-06-28 17:03:59 --> Model Class Initialized
INFO - 2017-06-28 17:03:59 --> Final output sent to browser
DEBUG - 2017-06-28 17:03:59 --> Total execution time: 0.0475
ERROR - 2017-06-28 17:10:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:10:02 --> Config Class Initialized
INFO - 2017-06-28 17:10:02 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:10:02 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:10:02 --> Utf8 Class Initialized
INFO - 2017-06-28 17:10:02 --> URI Class Initialized
INFO - 2017-06-28 17:10:02 --> Router Class Initialized
INFO - 2017-06-28 17:10:02 --> Output Class Initialized
INFO - 2017-06-28 17:10:02 --> Security Class Initialized
DEBUG - 2017-06-28 17:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:10:02 --> Input Class Initialized
INFO - 2017-06-28 17:10:02 --> Language Class Initialized
INFO - 2017-06-28 17:10:02 --> Loader Class Initialized
INFO - 2017-06-28 17:10:02 --> Controller Class Initialized
INFO - 2017-06-28 17:10:02 --> Database Driver Class Initialized
INFO - 2017-06-28 17:10:02 --> Model Class Initialized
INFO - 2017-06-28 17:10:02 --> Helper loaded: form_helper
INFO - 2017-06-28 17:10:02 --> Helper loaded: url_helper
INFO - 2017-06-28 17:10:02 --> Model Class Initialized
INFO - 2017-06-28 17:10:02 --> Final output sent to browser
DEBUG - 2017-06-28 17:10:02 --> Total execution time: 0.0575
ERROR - 2017-06-28 17:10:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:10:07 --> Config Class Initialized
INFO - 2017-06-28 17:10:07 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:10:07 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:10:07 --> Utf8 Class Initialized
INFO - 2017-06-28 17:10:07 --> URI Class Initialized
INFO - 2017-06-28 17:10:07 --> Router Class Initialized
INFO - 2017-06-28 17:10:07 --> Output Class Initialized
INFO - 2017-06-28 17:10:07 --> Security Class Initialized
DEBUG - 2017-06-28 17:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:10:07 --> Input Class Initialized
INFO - 2017-06-28 17:10:07 --> Language Class Initialized
INFO - 2017-06-28 17:10:07 --> Loader Class Initialized
INFO - 2017-06-28 17:10:07 --> Controller Class Initialized
INFO - 2017-06-28 17:10:07 --> Database Driver Class Initialized
INFO - 2017-06-28 17:10:07 --> Model Class Initialized
INFO - 2017-06-28 17:10:07 --> Helper loaded: form_helper
INFO - 2017-06-28 17:10:07 --> Helper loaded: url_helper
INFO - 2017-06-28 17:10:07 --> Model Class Initialized
INFO - 2017-06-28 17:10:07 --> Final output sent to browser
DEBUG - 2017-06-28 17:10:07 --> Total execution time: 0.0600
ERROR - 2017-06-28 17:13:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:13:49 --> Config Class Initialized
INFO - 2017-06-28 17:13:49 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:13:49 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:13:49 --> Utf8 Class Initialized
INFO - 2017-06-28 17:13:49 --> URI Class Initialized
INFO - 2017-06-28 17:13:49 --> Router Class Initialized
INFO - 2017-06-28 17:13:49 --> Output Class Initialized
INFO - 2017-06-28 17:13:49 --> Security Class Initialized
DEBUG - 2017-06-28 17:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:13:49 --> Input Class Initialized
INFO - 2017-06-28 17:13:49 --> Language Class Initialized
INFO - 2017-06-28 17:13:49 --> Loader Class Initialized
INFO - 2017-06-28 17:13:49 --> Controller Class Initialized
INFO - 2017-06-28 17:13:49 --> Database Driver Class Initialized
INFO - 2017-06-28 17:13:49 --> Model Class Initialized
INFO - 2017-06-28 17:13:49 --> Helper loaded: form_helper
INFO - 2017-06-28 17:13:49 --> Helper loaded: url_helper
INFO - 2017-06-28 17:13:49 --> Model Class Initialized
INFO - 2017-06-28 17:13:49 --> Final output sent to browser
DEBUG - 2017-06-28 17:13:49 --> Total execution time: 0.0675
ERROR - 2017-06-28 17:13:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:13:52 --> Config Class Initialized
INFO - 2017-06-28 17:13:52 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:13:52 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:13:52 --> Utf8 Class Initialized
INFO - 2017-06-28 17:13:52 --> URI Class Initialized
INFO - 2017-06-28 17:13:52 --> Router Class Initialized
INFO - 2017-06-28 17:13:52 --> Output Class Initialized
INFO - 2017-06-28 17:13:52 --> Security Class Initialized
DEBUG - 2017-06-28 17:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:13:52 --> Input Class Initialized
INFO - 2017-06-28 17:13:52 --> Language Class Initialized
INFO - 2017-06-28 17:13:52 --> Loader Class Initialized
INFO - 2017-06-28 17:13:52 --> Controller Class Initialized
INFO - 2017-06-28 17:13:52 --> Database Driver Class Initialized
INFO - 2017-06-28 17:13:52 --> Model Class Initialized
INFO - 2017-06-28 17:13:52 --> Helper loaded: form_helper
INFO - 2017-06-28 17:13:52 --> Helper loaded: url_helper
INFO - 2017-06-28 17:13:52 --> Model Class Initialized
INFO - 2017-06-28 17:13:52 --> Final output sent to browser
DEBUG - 2017-06-28 17:13:52 --> Total execution time: 0.0650
ERROR - 2017-06-28 17:18:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:18:36 --> Config Class Initialized
INFO - 2017-06-28 17:18:36 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:18:36 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:18:36 --> Utf8 Class Initialized
INFO - 2017-06-28 17:18:36 --> URI Class Initialized
INFO - 2017-06-28 17:18:36 --> Router Class Initialized
INFO - 2017-06-28 17:18:36 --> Output Class Initialized
INFO - 2017-06-28 17:18:36 --> Security Class Initialized
DEBUG - 2017-06-28 17:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:18:36 --> Input Class Initialized
INFO - 2017-06-28 17:18:36 --> Language Class Initialized
INFO - 2017-06-28 17:18:36 --> Loader Class Initialized
INFO - 2017-06-28 17:18:36 --> Controller Class Initialized
INFO - 2017-06-28 17:18:36 --> Database Driver Class Initialized
INFO - 2017-06-28 17:18:36 --> Model Class Initialized
INFO - 2017-06-28 17:18:36 --> Helper loaded: form_helper
INFO - 2017-06-28 17:18:36 --> Helper loaded: url_helper
INFO - 2017-06-28 17:18:36 --> Model Class Initialized
INFO - 2017-06-28 17:18:36 --> Final output sent to browser
DEBUG - 2017-06-28 17:18:36 --> Total execution time: 0.0755
ERROR - 2017-06-28 17:18:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:18:37 --> Config Class Initialized
INFO - 2017-06-28 17:18:37 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:18:38 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:18:38 --> Utf8 Class Initialized
INFO - 2017-06-28 17:18:38 --> URI Class Initialized
INFO - 2017-06-28 17:18:38 --> Router Class Initialized
INFO - 2017-06-28 17:18:38 --> Output Class Initialized
INFO - 2017-06-28 17:18:38 --> Security Class Initialized
DEBUG - 2017-06-28 17:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:18:38 --> Input Class Initialized
INFO - 2017-06-28 17:18:38 --> Language Class Initialized
INFO - 2017-06-28 17:18:38 --> Loader Class Initialized
INFO - 2017-06-28 17:18:38 --> Controller Class Initialized
INFO - 2017-06-28 17:18:38 --> Database Driver Class Initialized
INFO - 2017-06-28 17:18:38 --> Model Class Initialized
INFO - 2017-06-28 17:18:38 --> Helper loaded: form_helper
INFO - 2017-06-28 17:18:38 --> Helper loaded: url_helper
INFO - 2017-06-28 17:18:38 --> Model Class Initialized
INFO - 2017-06-28 17:18:38 --> Final output sent to browser
DEBUG - 2017-06-28 17:18:38 --> Total execution time: 0.0575
ERROR - 2017-06-28 17:21:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:21:08 --> Config Class Initialized
INFO - 2017-06-28 17:21:08 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:21:08 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:21:08 --> Utf8 Class Initialized
INFO - 2017-06-28 17:21:08 --> URI Class Initialized
INFO - 2017-06-28 17:21:08 --> Router Class Initialized
INFO - 2017-06-28 17:21:08 --> Output Class Initialized
INFO - 2017-06-28 17:21:08 --> Security Class Initialized
DEBUG - 2017-06-28 17:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:21:08 --> Input Class Initialized
INFO - 2017-06-28 17:21:08 --> Language Class Initialized
INFO - 2017-06-28 17:21:08 --> Loader Class Initialized
INFO - 2017-06-28 17:21:08 --> Controller Class Initialized
INFO - 2017-06-28 17:21:08 --> Database Driver Class Initialized
INFO - 2017-06-28 17:21:08 --> Model Class Initialized
INFO - 2017-06-28 17:21:08 --> Helper loaded: form_helper
INFO - 2017-06-28 17:21:08 --> Helper loaded: url_helper
INFO - 2017-06-28 17:21:08 --> Model Class Initialized
INFO - 2017-06-28 17:21:08 --> Final output sent to browser
DEBUG - 2017-06-28 17:21:08 --> Total execution time: 0.0645
ERROR - 2017-06-28 17:21:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:21:09 --> Config Class Initialized
INFO - 2017-06-28 17:21:09 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:21:09 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:21:09 --> Utf8 Class Initialized
INFO - 2017-06-28 17:21:09 --> URI Class Initialized
INFO - 2017-06-28 17:21:09 --> Router Class Initialized
INFO - 2017-06-28 17:21:09 --> Output Class Initialized
INFO - 2017-06-28 17:21:09 --> Security Class Initialized
DEBUG - 2017-06-28 17:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:21:09 --> Input Class Initialized
INFO - 2017-06-28 17:21:09 --> Language Class Initialized
INFO - 2017-06-28 17:21:09 --> Loader Class Initialized
INFO - 2017-06-28 17:21:09 --> Controller Class Initialized
INFO - 2017-06-28 17:21:09 --> Database Driver Class Initialized
INFO - 2017-06-28 17:21:09 --> Model Class Initialized
INFO - 2017-06-28 17:21:09 --> Helper loaded: form_helper
INFO - 2017-06-28 17:21:09 --> Helper loaded: url_helper
INFO - 2017-06-28 17:21:09 --> Model Class Initialized
INFO - 2017-06-28 17:21:09 --> Final output sent to browser
DEBUG - 2017-06-28 17:21:09 --> Total execution time: 0.1200
ERROR - 2017-06-28 17:21:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:21:18 --> Config Class Initialized
INFO - 2017-06-28 17:21:18 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:21:18 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:21:18 --> Utf8 Class Initialized
INFO - 2017-06-28 17:21:18 --> URI Class Initialized
INFO - 2017-06-28 17:21:18 --> Router Class Initialized
INFO - 2017-06-28 17:21:18 --> Output Class Initialized
INFO - 2017-06-28 17:21:18 --> Security Class Initialized
DEBUG - 2017-06-28 17:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:21:18 --> Input Class Initialized
INFO - 2017-06-28 17:21:18 --> Language Class Initialized
INFO - 2017-06-28 17:21:18 --> Loader Class Initialized
INFO - 2017-06-28 17:21:18 --> Controller Class Initialized
INFO - 2017-06-28 17:21:18 --> Database Driver Class Initialized
INFO - 2017-06-28 17:21:18 --> Model Class Initialized
INFO - 2017-06-28 17:21:18 --> Helper loaded: form_helper
INFO - 2017-06-28 17:21:18 --> Helper loaded: url_helper
INFO - 2017-06-28 17:21:18 --> Model Class Initialized
INFO - 2017-06-28 17:21:18 --> Final output sent to browser
DEBUG - 2017-06-28 17:21:18 --> Total execution time: 0.0910
ERROR - 2017-06-28 17:21:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:21:18 --> Config Class Initialized
INFO - 2017-06-28 17:21:18 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:21:18 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:21:18 --> Utf8 Class Initialized
INFO - 2017-06-28 17:21:18 --> URI Class Initialized
INFO - 2017-06-28 17:21:18 --> Router Class Initialized
INFO - 2017-06-28 17:21:18 --> Output Class Initialized
INFO - 2017-06-28 17:21:18 --> Security Class Initialized
DEBUG - 2017-06-28 17:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:21:18 --> Input Class Initialized
INFO - 2017-06-28 17:21:18 --> Language Class Initialized
INFO - 2017-06-28 17:21:18 --> Loader Class Initialized
INFO - 2017-06-28 17:21:18 --> Controller Class Initialized
INFO - 2017-06-28 17:21:18 --> Database Driver Class Initialized
INFO - 2017-06-28 17:21:18 --> Model Class Initialized
INFO - 2017-06-28 17:21:18 --> Helper loaded: form_helper
INFO - 2017-06-28 17:21:18 --> Helper loaded: url_helper
INFO - 2017-06-28 17:21:18 --> Model Class Initialized
INFO - 2017-06-28 17:21:19 --> Final output sent to browser
DEBUG - 2017-06-28 17:21:19 --> Total execution time: 0.0800
ERROR - 2017-06-28 17:21:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:21:21 --> Config Class Initialized
INFO - 2017-06-28 17:21:21 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:21:21 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:21:21 --> Utf8 Class Initialized
INFO - 2017-06-28 17:21:21 --> URI Class Initialized
INFO - 2017-06-28 17:21:21 --> Router Class Initialized
INFO - 2017-06-28 17:21:21 --> Output Class Initialized
INFO - 2017-06-28 17:21:21 --> Security Class Initialized
DEBUG - 2017-06-28 17:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:21:21 --> Input Class Initialized
INFO - 2017-06-28 17:21:21 --> Language Class Initialized
INFO - 2017-06-28 17:21:21 --> Loader Class Initialized
INFO - 2017-06-28 17:21:21 --> Controller Class Initialized
INFO - 2017-06-28 17:21:21 --> Database Driver Class Initialized
INFO - 2017-06-28 17:21:21 --> Model Class Initialized
INFO - 2017-06-28 17:21:21 --> Helper loaded: form_helper
INFO - 2017-06-28 17:21:21 --> Helper loaded: url_helper
INFO - 2017-06-28 17:21:21 --> Model Class Initialized
INFO - 2017-06-28 17:21:21 --> Final output sent to browser
DEBUG - 2017-06-28 17:21:21 --> Total execution time: 0.0500
ERROR - 2017-06-28 17:21:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:21:29 --> Config Class Initialized
INFO - 2017-06-28 17:21:29 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:21:29 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:21:29 --> Utf8 Class Initialized
INFO - 2017-06-28 17:21:29 --> URI Class Initialized
INFO - 2017-06-28 17:21:29 --> Router Class Initialized
INFO - 2017-06-28 17:21:29 --> Output Class Initialized
INFO - 2017-06-28 17:21:29 --> Security Class Initialized
DEBUG - 2017-06-28 17:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:21:29 --> Input Class Initialized
INFO - 2017-06-28 17:21:29 --> Language Class Initialized
INFO - 2017-06-28 17:21:29 --> Loader Class Initialized
INFO - 2017-06-28 17:21:29 --> Controller Class Initialized
INFO - 2017-06-28 17:21:29 --> Database Driver Class Initialized
INFO - 2017-06-28 17:21:29 --> Model Class Initialized
INFO - 2017-06-28 17:21:29 --> Helper loaded: form_helper
INFO - 2017-06-28 17:21:29 --> Helper loaded: url_helper
INFO - 2017-06-28 17:21:29 --> Model Class Initialized
INFO - 2017-06-28 17:21:29 --> Final output sent to browser
DEBUG - 2017-06-28 17:21:29 --> Total execution time: 0.0600
ERROR - 2017-06-28 17:22:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:22:14 --> Config Class Initialized
INFO - 2017-06-28 17:22:14 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:22:14 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:22:14 --> Utf8 Class Initialized
INFO - 2017-06-28 17:22:14 --> URI Class Initialized
INFO - 2017-06-28 17:22:14 --> Router Class Initialized
INFO - 2017-06-28 17:22:14 --> Output Class Initialized
INFO - 2017-06-28 17:22:14 --> Security Class Initialized
DEBUG - 2017-06-28 17:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:22:14 --> Input Class Initialized
INFO - 2017-06-28 17:22:14 --> Language Class Initialized
INFO - 2017-06-28 17:22:14 --> Loader Class Initialized
INFO - 2017-06-28 17:22:14 --> Controller Class Initialized
INFO - 2017-06-28 17:22:14 --> Database Driver Class Initialized
INFO - 2017-06-28 17:22:14 --> Model Class Initialized
INFO - 2017-06-28 17:22:14 --> Helper loaded: form_helper
INFO - 2017-06-28 17:22:14 --> Helper loaded: url_helper
INFO - 2017-06-28 17:22:14 --> Model Class Initialized
INFO - 2017-06-28 17:22:14 --> Final output sent to browser
DEBUG - 2017-06-28 17:22:14 --> Total execution time: 0.0600
ERROR - 2017-06-28 17:22:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:22:17 --> Config Class Initialized
INFO - 2017-06-28 17:22:17 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:22:17 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:22:17 --> Utf8 Class Initialized
INFO - 2017-06-28 17:22:17 --> URI Class Initialized
INFO - 2017-06-28 17:22:17 --> Router Class Initialized
INFO - 2017-06-28 17:22:17 --> Output Class Initialized
INFO - 2017-06-28 17:22:17 --> Security Class Initialized
DEBUG - 2017-06-28 17:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:22:17 --> Input Class Initialized
INFO - 2017-06-28 17:22:17 --> Language Class Initialized
INFO - 2017-06-28 17:22:17 --> Loader Class Initialized
INFO - 2017-06-28 17:22:17 --> Controller Class Initialized
INFO - 2017-06-28 17:22:17 --> Database Driver Class Initialized
INFO - 2017-06-28 17:22:17 --> Model Class Initialized
INFO - 2017-06-28 17:22:17 --> Helper loaded: form_helper
INFO - 2017-06-28 17:22:17 --> Helper loaded: url_helper
INFO - 2017-06-28 17:22:17 --> Model Class Initialized
INFO - 2017-06-28 17:22:17 --> Final output sent to browser
DEBUG - 2017-06-28 17:22:17 --> Total execution time: 0.0675
ERROR - 2017-06-28 17:22:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:22:23 --> Config Class Initialized
INFO - 2017-06-28 17:22:23 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:22:23 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:22:23 --> Utf8 Class Initialized
INFO - 2017-06-28 17:22:23 --> URI Class Initialized
INFO - 2017-06-28 17:22:23 --> Router Class Initialized
INFO - 2017-06-28 17:22:23 --> Output Class Initialized
INFO - 2017-06-28 17:22:23 --> Security Class Initialized
DEBUG - 2017-06-28 17:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:22:23 --> Input Class Initialized
INFO - 2017-06-28 17:22:23 --> Language Class Initialized
INFO - 2017-06-28 17:22:23 --> Loader Class Initialized
INFO - 2017-06-28 17:22:23 --> Controller Class Initialized
INFO - 2017-06-28 17:22:23 --> Database Driver Class Initialized
INFO - 2017-06-28 17:22:23 --> Model Class Initialized
INFO - 2017-06-28 17:22:23 --> Helper loaded: form_helper
INFO - 2017-06-28 17:22:23 --> Helper loaded: url_helper
INFO - 2017-06-28 17:22:23 --> Model Class Initialized
INFO - 2017-06-28 17:22:23 --> Final output sent to browser
DEBUG - 2017-06-28 17:22:23 --> Total execution time: 0.0475
ERROR - 2017-06-28 17:22:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:22:43 --> Config Class Initialized
INFO - 2017-06-28 17:22:43 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:22:43 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:22:43 --> Utf8 Class Initialized
INFO - 2017-06-28 17:22:43 --> URI Class Initialized
INFO - 2017-06-28 17:22:43 --> Router Class Initialized
INFO - 2017-06-28 17:22:43 --> Output Class Initialized
INFO - 2017-06-28 17:22:43 --> Security Class Initialized
DEBUG - 2017-06-28 17:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:22:43 --> Input Class Initialized
INFO - 2017-06-28 17:22:43 --> Language Class Initialized
INFO - 2017-06-28 17:22:43 --> Loader Class Initialized
INFO - 2017-06-28 17:22:43 --> Controller Class Initialized
INFO - 2017-06-28 17:22:43 --> Database Driver Class Initialized
INFO - 2017-06-28 17:22:43 --> Model Class Initialized
INFO - 2017-06-28 17:22:43 --> Helper loaded: form_helper
INFO - 2017-06-28 17:22:43 --> Helper loaded: url_helper
INFO - 2017-06-28 17:22:43 --> Model Class Initialized
INFO - 2017-06-28 17:22:43 --> Final output sent to browser
DEBUG - 2017-06-28 17:22:43 --> Total execution time: 0.0595
ERROR - 2017-06-28 17:23:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:23:17 --> Config Class Initialized
INFO - 2017-06-28 17:23:17 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:23:17 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:23:17 --> Utf8 Class Initialized
INFO - 2017-06-28 17:23:17 --> URI Class Initialized
INFO - 2017-06-28 17:23:17 --> Router Class Initialized
INFO - 2017-06-28 17:23:17 --> Output Class Initialized
INFO - 2017-06-28 17:23:17 --> Security Class Initialized
DEBUG - 2017-06-28 17:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:23:17 --> Input Class Initialized
INFO - 2017-06-28 17:23:17 --> Language Class Initialized
INFO - 2017-06-28 17:23:17 --> Loader Class Initialized
INFO - 2017-06-28 17:23:17 --> Controller Class Initialized
INFO - 2017-06-28 17:23:17 --> Database Driver Class Initialized
INFO - 2017-06-28 17:23:17 --> Model Class Initialized
INFO - 2017-06-28 17:23:17 --> Helper loaded: form_helper
INFO - 2017-06-28 17:23:17 --> Helper loaded: url_helper
INFO - 2017-06-28 17:23:17 --> Model Class Initialized
INFO - 2017-06-28 17:23:17 --> Final output sent to browser
DEBUG - 2017-06-28 17:23:17 --> Total execution time: 0.0690
ERROR - 2017-06-28 17:23:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:23:44 --> Config Class Initialized
INFO - 2017-06-28 17:23:44 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:23:44 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:23:44 --> Utf8 Class Initialized
INFO - 2017-06-28 17:23:44 --> URI Class Initialized
INFO - 2017-06-28 17:23:44 --> Router Class Initialized
INFO - 2017-06-28 17:23:44 --> Output Class Initialized
INFO - 2017-06-28 17:23:44 --> Security Class Initialized
DEBUG - 2017-06-28 17:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:23:44 --> Input Class Initialized
INFO - 2017-06-28 17:23:44 --> Language Class Initialized
INFO - 2017-06-28 17:23:44 --> Loader Class Initialized
INFO - 2017-06-28 17:23:44 --> Controller Class Initialized
INFO - 2017-06-28 17:23:44 --> Database Driver Class Initialized
INFO - 2017-06-28 17:23:44 --> Model Class Initialized
INFO - 2017-06-28 17:23:44 --> Helper loaded: form_helper
INFO - 2017-06-28 17:23:44 --> Helper loaded: url_helper
INFO - 2017-06-28 17:23:44 --> Model Class Initialized
INFO - 2017-06-28 17:23:44 --> Final output sent to browser
DEBUG - 2017-06-28 17:23:44 --> Total execution time: 0.0575
ERROR - 2017-06-28 17:23:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:23:45 --> Config Class Initialized
INFO - 2017-06-28 17:23:45 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:23:45 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:23:45 --> Utf8 Class Initialized
INFO - 2017-06-28 17:23:45 --> URI Class Initialized
INFO - 2017-06-28 17:23:45 --> Router Class Initialized
INFO - 2017-06-28 17:23:45 --> Output Class Initialized
INFO - 2017-06-28 17:23:45 --> Security Class Initialized
DEBUG - 2017-06-28 17:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:23:45 --> Input Class Initialized
INFO - 2017-06-28 17:23:45 --> Language Class Initialized
INFO - 2017-06-28 17:23:45 --> Loader Class Initialized
INFO - 2017-06-28 17:23:45 --> Controller Class Initialized
INFO - 2017-06-28 17:23:45 --> Database Driver Class Initialized
INFO - 2017-06-28 17:23:45 --> Model Class Initialized
INFO - 2017-06-28 17:23:45 --> Helper loaded: form_helper
INFO - 2017-06-28 17:23:45 --> Helper loaded: url_helper
INFO - 2017-06-28 17:23:45 --> Model Class Initialized
INFO - 2017-06-28 17:23:45 --> Final output sent to browser
DEBUG - 2017-06-28 17:23:45 --> Total execution time: 0.0900
ERROR - 2017-06-28 17:24:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:24:00 --> Config Class Initialized
INFO - 2017-06-28 17:24:00 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:24:00 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:24:00 --> Utf8 Class Initialized
INFO - 2017-06-28 17:24:00 --> URI Class Initialized
INFO - 2017-06-28 17:24:00 --> Router Class Initialized
INFO - 2017-06-28 17:24:00 --> Output Class Initialized
INFO - 2017-06-28 17:24:00 --> Security Class Initialized
DEBUG - 2017-06-28 17:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:24:00 --> Input Class Initialized
INFO - 2017-06-28 17:24:00 --> Language Class Initialized
INFO - 2017-06-28 17:24:00 --> Loader Class Initialized
INFO - 2017-06-28 17:24:00 --> Controller Class Initialized
INFO - 2017-06-28 17:24:00 --> Database Driver Class Initialized
INFO - 2017-06-28 17:24:00 --> Model Class Initialized
INFO - 2017-06-28 17:24:00 --> Helper loaded: form_helper
INFO - 2017-06-28 17:24:00 --> Helper loaded: url_helper
INFO - 2017-06-28 17:24:00 --> Model Class Initialized
INFO - 2017-06-28 17:24:01 --> Final output sent to browser
DEBUG - 2017-06-28 17:24:01 --> Total execution time: 0.5000
ERROR - 2017-06-28 17:24:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:24:03 --> Config Class Initialized
INFO - 2017-06-28 17:24:03 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:24:03 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:24:03 --> Utf8 Class Initialized
INFO - 2017-06-28 17:24:03 --> URI Class Initialized
INFO - 2017-06-28 17:24:03 --> Router Class Initialized
INFO - 2017-06-28 17:24:03 --> Output Class Initialized
INFO - 2017-06-28 17:24:03 --> Security Class Initialized
DEBUG - 2017-06-28 17:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:24:03 --> Input Class Initialized
INFO - 2017-06-28 17:24:03 --> Language Class Initialized
INFO - 2017-06-28 17:24:03 --> Loader Class Initialized
INFO - 2017-06-28 17:24:03 --> Controller Class Initialized
INFO - 2017-06-28 17:24:03 --> Database Driver Class Initialized
INFO - 2017-06-28 17:24:03 --> Model Class Initialized
INFO - 2017-06-28 17:24:03 --> Helper loaded: form_helper
INFO - 2017-06-28 17:24:03 --> Helper loaded: url_helper
INFO - 2017-06-28 17:24:03 --> Model Class Initialized
INFO - 2017-06-28 17:24:03 --> Final output sent to browser
DEBUG - 2017-06-28 17:24:03 --> Total execution time: 0.0470
ERROR - 2017-06-28 17:26:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:26:37 --> Config Class Initialized
INFO - 2017-06-28 17:26:37 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:26:37 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:26:37 --> Utf8 Class Initialized
INFO - 2017-06-28 17:26:37 --> URI Class Initialized
INFO - 2017-06-28 17:26:37 --> Router Class Initialized
INFO - 2017-06-28 17:26:37 --> Output Class Initialized
INFO - 2017-06-28 17:26:37 --> Security Class Initialized
DEBUG - 2017-06-28 17:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:26:37 --> Input Class Initialized
INFO - 2017-06-28 17:26:37 --> Language Class Initialized
INFO - 2017-06-28 17:26:37 --> Loader Class Initialized
INFO - 2017-06-28 17:26:37 --> Controller Class Initialized
INFO - 2017-06-28 17:26:37 --> Database Driver Class Initialized
INFO - 2017-06-28 17:26:37 --> Model Class Initialized
INFO - 2017-06-28 17:26:37 --> Helper loaded: form_helper
INFO - 2017-06-28 17:26:37 --> Helper loaded: url_helper
INFO - 2017-06-28 17:26:37 --> Model Class Initialized
INFO - 2017-06-28 17:26:37 --> Final output sent to browser
DEBUG - 2017-06-28 17:26:37 --> Total execution time: 0.0575
ERROR - 2017-06-28 17:26:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:26:38 --> Config Class Initialized
INFO - 2017-06-28 17:26:38 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:26:38 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:26:38 --> Utf8 Class Initialized
INFO - 2017-06-28 17:26:38 --> URI Class Initialized
INFO - 2017-06-28 17:26:38 --> Router Class Initialized
INFO - 2017-06-28 17:26:38 --> Output Class Initialized
INFO - 2017-06-28 17:26:38 --> Security Class Initialized
DEBUG - 2017-06-28 17:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:26:38 --> Input Class Initialized
INFO - 2017-06-28 17:26:38 --> Language Class Initialized
INFO - 2017-06-28 17:26:38 --> Loader Class Initialized
INFO - 2017-06-28 17:26:38 --> Controller Class Initialized
INFO - 2017-06-28 17:26:38 --> Database Driver Class Initialized
INFO - 2017-06-28 17:26:38 --> Model Class Initialized
INFO - 2017-06-28 17:26:38 --> Helper loaded: form_helper
INFO - 2017-06-28 17:26:38 --> Helper loaded: url_helper
INFO - 2017-06-28 17:26:38 --> Model Class Initialized
INFO - 2017-06-28 17:26:38 --> Final output sent to browser
DEBUG - 2017-06-28 17:26:38 --> Total execution time: 0.0600
ERROR - 2017-06-28 17:26:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:26:40 --> Config Class Initialized
INFO - 2017-06-28 17:26:40 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:26:40 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:26:40 --> Utf8 Class Initialized
INFO - 2017-06-28 17:26:40 --> URI Class Initialized
INFO - 2017-06-28 17:26:40 --> Router Class Initialized
INFO - 2017-06-28 17:26:40 --> Output Class Initialized
INFO - 2017-06-28 17:26:40 --> Security Class Initialized
DEBUG - 2017-06-28 17:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:26:40 --> Input Class Initialized
INFO - 2017-06-28 17:26:40 --> Language Class Initialized
INFO - 2017-06-28 17:26:40 --> Loader Class Initialized
INFO - 2017-06-28 17:26:40 --> Controller Class Initialized
INFO - 2017-06-28 17:26:40 --> Database Driver Class Initialized
INFO - 2017-06-28 17:26:40 --> Model Class Initialized
INFO - 2017-06-28 17:26:40 --> Helper loaded: form_helper
INFO - 2017-06-28 17:26:40 --> Helper loaded: url_helper
INFO - 2017-06-28 17:26:40 --> Model Class Initialized
INFO - 2017-06-28 17:26:40 --> Final output sent to browser
DEBUG - 2017-06-28 17:26:40 --> Total execution time: 0.0675
ERROR - 2017-06-28 17:31:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:31:22 --> Config Class Initialized
INFO - 2017-06-28 17:31:22 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:31:22 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:31:22 --> Utf8 Class Initialized
INFO - 2017-06-28 17:31:22 --> URI Class Initialized
INFO - 2017-06-28 17:31:22 --> Router Class Initialized
INFO - 2017-06-28 17:31:22 --> Output Class Initialized
INFO - 2017-06-28 17:31:22 --> Security Class Initialized
DEBUG - 2017-06-28 17:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:31:22 --> Input Class Initialized
INFO - 2017-06-28 17:31:22 --> Language Class Initialized
INFO - 2017-06-28 17:31:22 --> Loader Class Initialized
INFO - 2017-06-28 17:31:22 --> Controller Class Initialized
INFO - 2017-06-28 17:31:22 --> Database Driver Class Initialized
INFO - 2017-06-28 17:31:22 --> Model Class Initialized
INFO - 2017-06-28 17:31:22 --> Helper loaded: form_helper
INFO - 2017-06-28 17:31:22 --> Helper loaded: url_helper
INFO - 2017-06-28 17:31:22 --> Model Class Initialized
INFO - 2017-06-28 17:31:22 --> Final output sent to browser
DEBUG - 2017-06-28 17:31:22 --> Total execution time: 0.0500
ERROR - 2017-06-28 17:31:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:31:24 --> Config Class Initialized
INFO - 2017-06-28 17:31:24 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:31:24 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:31:24 --> Utf8 Class Initialized
INFO - 2017-06-28 17:31:24 --> URI Class Initialized
INFO - 2017-06-28 17:31:24 --> Router Class Initialized
INFO - 2017-06-28 17:31:24 --> Output Class Initialized
INFO - 2017-06-28 17:31:24 --> Security Class Initialized
DEBUG - 2017-06-28 17:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:31:24 --> Input Class Initialized
INFO - 2017-06-28 17:31:24 --> Language Class Initialized
INFO - 2017-06-28 17:31:24 --> Loader Class Initialized
INFO - 2017-06-28 17:31:24 --> Controller Class Initialized
INFO - 2017-06-28 17:31:24 --> Database Driver Class Initialized
INFO - 2017-06-28 17:31:24 --> Model Class Initialized
INFO - 2017-06-28 17:31:24 --> Helper loaded: form_helper
INFO - 2017-06-28 17:31:24 --> Helper loaded: url_helper
INFO - 2017-06-28 17:31:24 --> Model Class Initialized
INFO - 2017-06-28 17:31:24 --> Final output sent to browser
DEBUG - 2017-06-28 17:31:24 --> Total execution time: 0.0560
ERROR - 2017-06-28 17:31:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:31:26 --> Config Class Initialized
INFO - 2017-06-28 17:31:26 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:31:26 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:31:26 --> Utf8 Class Initialized
INFO - 2017-06-28 17:31:26 --> URI Class Initialized
INFO - 2017-06-28 17:31:26 --> Router Class Initialized
INFO - 2017-06-28 17:31:26 --> Output Class Initialized
INFO - 2017-06-28 17:31:26 --> Security Class Initialized
DEBUG - 2017-06-28 17:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:31:26 --> Input Class Initialized
INFO - 2017-06-28 17:31:26 --> Language Class Initialized
INFO - 2017-06-28 17:31:26 --> Loader Class Initialized
INFO - 2017-06-28 17:31:26 --> Controller Class Initialized
INFO - 2017-06-28 17:31:26 --> Database Driver Class Initialized
INFO - 2017-06-28 17:31:26 --> Model Class Initialized
INFO - 2017-06-28 17:31:26 --> Helper loaded: form_helper
INFO - 2017-06-28 17:31:26 --> Helper loaded: url_helper
INFO - 2017-06-28 17:31:26 --> Model Class Initialized
INFO - 2017-06-28 17:31:26 --> Final output sent to browser
DEBUG - 2017-06-28 17:31:26 --> Total execution time: 0.0520
ERROR - 2017-06-28 17:36:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:36:43 --> Config Class Initialized
INFO - 2017-06-28 17:36:43 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:36:43 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:36:43 --> Utf8 Class Initialized
INFO - 2017-06-28 17:36:43 --> URI Class Initialized
INFO - 2017-06-28 17:36:43 --> Router Class Initialized
INFO - 2017-06-28 17:36:43 --> Output Class Initialized
INFO - 2017-06-28 17:36:43 --> Security Class Initialized
DEBUG - 2017-06-28 17:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:36:43 --> Input Class Initialized
INFO - 2017-06-28 17:36:43 --> Language Class Initialized
INFO - 2017-06-28 17:36:43 --> Loader Class Initialized
INFO - 2017-06-28 17:36:43 --> Controller Class Initialized
INFO - 2017-06-28 17:36:43 --> Database Driver Class Initialized
INFO - 2017-06-28 17:36:43 --> Model Class Initialized
INFO - 2017-06-28 17:36:43 --> Helper loaded: form_helper
INFO - 2017-06-28 17:36:43 --> Helper loaded: url_helper
INFO - 2017-06-28 17:36:43 --> Model Class Initialized
INFO - 2017-06-28 17:36:43 --> Final output sent to browser
DEBUG - 2017-06-28 17:36:43 --> Total execution time: 0.0505
ERROR - 2017-06-28 17:36:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:36:45 --> Config Class Initialized
INFO - 2017-06-28 17:36:45 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:36:45 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:36:45 --> Utf8 Class Initialized
INFO - 2017-06-28 17:36:45 --> URI Class Initialized
INFO - 2017-06-28 17:36:45 --> Router Class Initialized
INFO - 2017-06-28 17:36:45 --> Output Class Initialized
INFO - 2017-06-28 17:36:45 --> Security Class Initialized
DEBUG - 2017-06-28 17:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:36:45 --> Input Class Initialized
INFO - 2017-06-28 17:36:45 --> Language Class Initialized
INFO - 2017-06-28 17:36:45 --> Loader Class Initialized
INFO - 2017-06-28 17:36:45 --> Controller Class Initialized
INFO - 2017-06-28 17:36:45 --> Database Driver Class Initialized
INFO - 2017-06-28 17:36:45 --> Model Class Initialized
INFO - 2017-06-28 17:36:45 --> Helper loaded: form_helper
INFO - 2017-06-28 17:36:45 --> Helper loaded: url_helper
INFO - 2017-06-28 17:36:45 --> Model Class Initialized
INFO - 2017-06-28 17:36:45 --> Final output sent to browser
DEBUG - 2017-06-28 17:36:45 --> Total execution time: 0.0565
ERROR - 2017-06-28 17:36:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:36:47 --> Config Class Initialized
INFO - 2017-06-28 17:36:47 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:36:47 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:36:47 --> Utf8 Class Initialized
INFO - 2017-06-28 17:36:47 --> URI Class Initialized
INFO - 2017-06-28 17:36:47 --> Router Class Initialized
INFO - 2017-06-28 17:36:47 --> Output Class Initialized
INFO - 2017-06-28 17:36:47 --> Security Class Initialized
DEBUG - 2017-06-28 17:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:36:47 --> Input Class Initialized
INFO - 2017-06-28 17:36:47 --> Language Class Initialized
INFO - 2017-06-28 17:36:47 --> Loader Class Initialized
INFO - 2017-06-28 17:36:47 --> Controller Class Initialized
INFO - 2017-06-28 17:36:47 --> Database Driver Class Initialized
INFO - 2017-06-28 17:36:47 --> Model Class Initialized
INFO - 2017-06-28 17:36:47 --> Helper loaded: form_helper
INFO - 2017-06-28 17:36:47 --> Helper loaded: url_helper
INFO - 2017-06-28 17:36:47 --> Model Class Initialized
INFO - 2017-06-28 17:36:47 --> Final output sent to browser
DEBUG - 2017-06-28 17:36:47 --> Total execution time: 0.0600
ERROR - 2017-06-28 17:41:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:41:35 --> Config Class Initialized
INFO - 2017-06-28 17:41:35 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:41:35 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:41:35 --> Utf8 Class Initialized
INFO - 2017-06-28 17:41:35 --> URI Class Initialized
INFO - 2017-06-28 17:41:35 --> Router Class Initialized
INFO - 2017-06-28 17:41:35 --> Output Class Initialized
INFO - 2017-06-28 17:41:35 --> Security Class Initialized
DEBUG - 2017-06-28 17:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:41:35 --> Input Class Initialized
INFO - 2017-06-28 17:41:35 --> Language Class Initialized
INFO - 2017-06-28 17:41:35 --> Loader Class Initialized
INFO - 2017-06-28 17:41:35 --> Controller Class Initialized
INFO - 2017-06-28 17:41:35 --> Database Driver Class Initialized
INFO - 2017-06-28 17:41:35 --> Model Class Initialized
INFO - 2017-06-28 17:41:35 --> Helper loaded: form_helper
INFO - 2017-06-28 17:41:35 --> Helper loaded: url_helper
INFO - 2017-06-28 17:41:35 --> Model Class Initialized
INFO - 2017-06-28 17:41:35 --> Final output sent to browser
DEBUG - 2017-06-28 17:41:35 --> Total execution time: 0.0600
ERROR - 2017-06-28 17:57:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:57:07 --> Config Class Initialized
INFO - 2017-06-28 17:57:07 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:57:07 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:57:07 --> Utf8 Class Initialized
INFO - 2017-06-28 17:57:07 --> URI Class Initialized
INFO - 2017-06-28 17:57:07 --> Router Class Initialized
INFO - 2017-06-28 17:57:07 --> Output Class Initialized
INFO - 2017-06-28 17:57:07 --> Security Class Initialized
DEBUG - 2017-06-28 17:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:57:07 --> Input Class Initialized
INFO - 2017-06-28 17:57:07 --> Language Class Initialized
INFO - 2017-06-28 17:57:07 --> Loader Class Initialized
INFO - 2017-06-28 17:57:07 --> Controller Class Initialized
INFO - 2017-06-28 17:57:07 --> Database Driver Class Initialized
INFO - 2017-06-28 17:57:07 --> Model Class Initialized
INFO - 2017-06-28 17:57:07 --> Helper loaded: form_helper
INFO - 2017-06-28 17:57:07 --> Helper loaded: url_helper
INFO - 2017-06-28 17:57:07 --> Model Class Initialized
INFO - 2017-06-28 17:57:07 --> Final output sent to browser
DEBUG - 2017-06-28 17:57:07 --> Total execution time: 0.0650
ERROR - 2017-06-28 17:57:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:57:10 --> Config Class Initialized
INFO - 2017-06-28 17:57:10 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:57:10 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:57:10 --> Utf8 Class Initialized
INFO - 2017-06-28 17:57:10 --> URI Class Initialized
INFO - 2017-06-28 17:57:10 --> Router Class Initialized
INFO - 2017-06-28 17:57:10 --> Output Class Initialized
INFO - 2017-06-28 17:57:10 --> Security Class Initialized
DEBUG - 2017-06-28 17:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:57:10 --> Input Class Initialized
INFO - 2017-06-28 17:57:10 --> Language Class Initialized
INFO - 2017-06-28 17:57:10 --> Loader Class Initialized
INFO - 2017-06-28 17:57:10 --> Controller Class Initialized
INFO - 2017-06-28 17:57:10 --> Database Driver Class Initialized
INFO - 2017-06-28 17:57:10 --> Model Class Initialized
INFO - 2017-06-28 17:57:10 --> Helper loaded: form_helper
INFO - 2017-06-28 17:57:10 --> Helper loaded: url_helper
INFO - 2017-06-28 17:57:10 --> Model Class Initialized
INFO - 2017-06-28 17:57:10 --> Final output sent to browser
DEBUG - 2017-06-28 17:57:10 --> Total execution time: 0.0820
ERROR - 2017-06-28 17:57:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:57:12 --> Config Class Initialized
INFO - 2017-06-28 17:57:12 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:57:12 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:57:12 --> Utf8 Class Initialized
INFO - 2017-06-28 17:57:12 --> URI Class Initialized
INFO - 2017-06-28 17:57:12 --> Router Class Initialized
INFO - 2017-06-28 17:57:12 --> Output Class Initialized
INFO - 2017-06-28 17:57:12 --> Security Class Initialized
DEBUG - 2017-06-28 17:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:57:12 --> Input Class Initialized
INFO - 2017-06-28 17:57:12 --> Language Class Initialized
INFO - 2017-06-28 17:57:12 --> Loader Class Initialized
INFO - 2017-06-28 17:57:12 --> Controller Class Initialized
INFO - 2017-06-28 17:57:12 --> Database Driver Class Initialized
INFO - 2017-06-28 17:57:12 --> Model Class Initialized
INFO - 2017-06-28 17:57:12 --> Helper loaded: form_helper
INFO - 2017-06-28 17:57:12 --> Helper loaded: url_helper
INFO - 2017-06-28 17:57:12 --> Model Class Initialized
INFO - 2017-06-28 17:57:12 --> Final output sent to browser
DEBUG - 2017-06-28 17:57:12 --> Total execution time: 0.0640
ERROR - 2017-06-28 17:59:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 17:59:08 --> Config Class Initialized
INFO - 2017-06-28 17:59:08 --> Hooks Class Initialized
DEBUG - 2017-06-28 17:59:08 --> UTF-8 Support Enabled
INFO - 2017-06-28 17:59:08 --> Utf8 Class Initialized
INFO - 2017-06-28 17:59:08 --> URI Class Initialized
INFO - 2017-06-28 17:59:08 --> Router Class Initialized
INFO - 2017-06-28 17:59:08 --> Output Class Initialized
INFO - 2017-06-28 17:59:08 --> Security Class Initialized
DEBUG - 2017-06-28 17:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 17:59:08 --> Input Class Initialized
INFO - 2017-06-28 17:59:08 --> Language Class Initialized
INFO - 2017-06-28 17:59:08 --> Loader Class Initialized
INFO - 2017-06-28 17:59:08 --> Controller Class Initialized
INFO - 2017-06-28 17:59:08 --> Database Driver Class Initialized
INFO - 2017-06-28 17:59:08 --> Model Class Initialized
INFO - 2017-06-28 17:59:08 --> Helper loaded: form_helper
INFO - 2017-06-28 17:59:08 --> Helper loaded: url_helper
INFO - 2017-06-28 17:59:08 --> Model Class Initialized
INFO - 2017-06-28 17:59:08 --> Final output sent to browser
DEBUG - 2017-06-28 17:59:08 --> Total execution time: 0.0775
ERROR - 2017-06-28 18:03:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:03:24 --> Config Class Initialized
INFO - 2017-06-28 18:03:24 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:03:24 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:03:24 --> Utf8 Class Initialized
INFO - 2017-06-28 18:03:24 --> URI Class Initialized
INFO - 2017-06-28 18:03:24 --> Router Class Initialized
INFO - 2017-06-28 18:03:24 --> Output Class Initialized
INFO - 2017-06-28 18:03:24 --> Security Class Initialized
DEBUG - 2017-06-28 18:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:03:24 --> Input Class Initialized
INFO - 2017-06-28 18:03:24 --> Language Class Initialized
INFO - 2017-06-28 18:03:24 --> Loader Class Initialized
INFO - 2017-06-28 18:03:24 --> Controller Class Initialized
INFO - 2017-06-28 18:03:24 --> Database Driver Class Initialized
INFO - 2017-06-28 18:03:24 --> Model Class Initialized
INFO - 2017-06-28 18:03:24 --> Helper loaded: form_helper
INFO - 2017-06-28 18:03:24 --> Helper loaded: url_helper
INFO - 2017-06-28 18:03:24 --> Model Class Initialized
INFO - 2017-06-28 18:03:24 --> Final output sent to browser
DEBUG - 2017-06-28 18:03:24 --> Total execution time: 0.0500
ERROR - 2017-06-28 18:03:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:03:28 --> Config Class Initialized
INFO - 2017-06-28 18:03:28 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:03:28 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:03:28 --> Utf8 Class Initialized
INFO - 2017-06-28 18:03:28 --> URI Class Initialized
INFO - 2017-06-28 18:03:28 --> Router Class Initialized
INFO - 2017-06-28 18:03:28 --> Output Class Initialized
INFO - 2017-06-28 18:03:28 --> Security Class Initialized
DEBUG - 2017-06-28 18:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:03:28 --> Input Class Initialized
INFO - 2017-06-28 18:03:28 --> Language Class Initialized
INFO - 2017-06-28 18:03:28 --> Loader Class Initialized
INFO - 2017-06-28 18:03:28 --> Controller Class Initialized
INFO - 2017-06-28 18:03:28 --> Database Driver Class Initialized
INFO - 2017-06-28 18:03:28 --> Model Class Initialized
INFO - 2017-06-28 18:03:28 --> Helper loaded: form_helper
INFO - 2017-06-28 18:03:28 --> Helper loaded: url_helper
INFO - 2017-06-28 18:03:28 --> Model Class Initialized
INFO - 2017-06-28 18:03:28 --> Final output sent to browser
DEBUG - 2017-06-28 18:03:28 --> Total execution time: 0.0500
ERROR - 2017-06-28 18:03:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:03:39 --> Config Class Initialized
INFO - 2017-06-28 18:03:39 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:03:39 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:03:39 --> Utf8 Class Initialized
INFO - 2017-06-28 18:03:39 --> URI Class Initialized
INFO - 2017-06-28 18:03:39 --> Router Class Initialized
INFO - 2017-06-28 18:03:39 --> Output Class Initialized
INFO - 2017-06-28 18:03:39 --> Security Class Initialized
DEBUG - 2017-06-28 18:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:03:39 --> Input Class Initialized
INFO - 2017-06-28 18:03:39 --> Language Class Initialized
INFO - 2017-06-28 18:03:39 --> Loader Class Initialized
INFO - 2017-06-28 18:03:39 --> Controller Class Initialized
INFO - 2017-06-28 18:03:39 --> Database Driver Class Initialized
INFO - 2017-06-28 18:03:39 --> Model Class Initialized
INFO - 2017-06-28 18:03:39 --> Helper loaded: form_helper
INFO - 2017-06-28 18:03:39 --> Helper loaded: url_helper
INFO - 2017-06-28 18:03:39 --> Model Class Initialized
INFO - 2017-06-28 18:03:39 --> Final output sent to browser
DEBUG - 2017-06-28 18:03:39 --> Total execution time: 0.0610
ERROR - 2017-06-28 18:08:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:08:19 --> Config Class Initialized
INFO - 2017-06-28 18:08:19 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:08:19 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:08:19 --> Utf8 Class Initialized
INFO - 2017-06-28 18:08:19 --> URI Class Initialized
INFO - 2017-06-28 18:08:19 --> Router Class Initialized
INFO - 2017-06-28 18:08:19 --> Output Class Initialized
INFO - 2017-06-28 18:08:19 --> Security Class Initialized
DEBUG - 2017-06-28 18:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:08:19 --> Input Class Initialized
INFO - 2017-06-28 18:08:19 --> Language Class Initialized
INFO - 2017-06-28 18:08:19 --> Loader Class Initialized
INFO - 2017-06-28 18:08:19 --> Controller Class Initialized
INFO - 2017-06-28 18:08:19 --> Database Driver Class Initialized
INFO - 2017-06-28 18:08:19 --> Model Class Initialized
INFO - 2017-06-28 18:08:19 --> Helper loaded: form_helper
INFO - 2017-06-28 18:08:19 --> Helper loaded: url_helper
INFO - 2017-06-28 18:08:19 --> Model Class Initialized
INFO - 2017-06-28 18:08:19 --> Final output sent to browser
DEBUG - 2017-06-28 18:08:19 --> Total execution time: 0.0775
ERROR - 2017-06-28 18:08:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:08:21 --> Config Class Initialized
INFO - 2017-06-28 18:08:21 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:08:21 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:08:21 --> Utf8 Class Initialized
INFO - 2017-06-28 18:08:21 --> URI Class Initialized
INFO - 2017-06-28 18:08:21 --> Router Class Initialized
INFO - 2017-06-28 18:08:21 --> Output Class Initialized
INFO - 2017-06-28 18:08:21 --> Security Class Initialized
DEBUG - 2017-06-28 18:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:08:21 --> Input Class Initialized
INFO - 2017-06-28 18:08:21 --> Language Class Initialized
INFO - 2017-06-28 18:08:21 --> Loader Class Initialized
INFO - 2017-06-28 18:08:21 --> Controller Class Initialized
INFO - 2017-06-28 18:08:21 --> Database Driver Class Initialized
INFO - 2017-06-28 18:08:21 --> Model Class Initialized
INFO - 2017-06-28 18:08:21 --> Helper loaded: form_helper
INFO - 2017-06-28 18:08:21 --> Helper loaded: url_helper
INFO - 2017-06-28 18:08:21 --> Model Class Initialized
INFO - 2017-06-28 18:08:21 --> Final output sent to browser
DEBUG - 2017-06-28 18:08:21 --> Total execution time: 0.0580
ERROR - 2017-06-28 18:08:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:08:22 --> Config Class Initialized
INFO - 2017-06-28 18:08:22 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:08:22 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:08:22 --> Utf8 Class Initialized
INFO - 2017-06-28 18:08:22 --> URI Class Initialized
INFO - 2017-06-28 18:08:22 --> Router Class Initialized
INFO - 2017-06-28 18:08:22 --> Output Class Initialized
INFO - 2017-06-28 18:08:22 --> Security Class Initialized
DEBUG - 2017-06-28 18:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:08:22 --> Input Class Initialized
INFO - 2017-06-28 18:08:22 --> Language Class Initialized
INFO - 2017-06-28 18:08:22 --> Loader Class Initialized
INFO - 2017-06-28 18:08:22 --> Controller Class Initialized
INFO - 2017-06-28 18:08:22 --> Database Driver Class Initialized
INFO - 2017-06-28 18:08:22 --> Model Class Initialized
INFO - 2017-06-28 18:08:22 --> Helper loaded: form_helper
INFO - 2017-06-28 18:08:22 --> Helper loaded: url_helper
INFO - 2017-06-28 18:08:22 --> Model Class Initialized
INFO - 2017-06-28 18:08:22 --> Final output sent to browser
DEBUG - 2017-06-28 18:08:22 --> Total execution time: 0.0745
ERROR - 2017-06-28 18:20:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:20:50 --> Config Class Initialized
INFO - 2017-06-28 18:20:50 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:20:50 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:20:50 --> Utf8 Class Initialized
INFO - 2017-06-28 18:20:50 --> URI Class Initialized
INFO - 2017-06-28 18:20:50 --> Router Class Initialized
INFO - 2017-06-28 18:20:50 --> Output Class Initialized
INFO - 2017-06-28 18:20:50 --> Security Class Initialized
DEBUG - 2017-06-28 18:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:20:50 --> Input Class Initialized
INFO - 2017-06-28 18:20:50 --> Language Class Initialized
INFO - 2017-06-28 18:20:50 --> Loader Class Initialized
INFO - 2017-06-28 18:20:50 --> Controller Class Initialized
INFO - 2017-06-28 18:20:50 --> Database Driver Class Initialized
INFO - 2017-06-28 18:20:50 --> Model Class Initialized
INFO - 2017-06-28 18:20:50 --> Helper loaded: form_helper
INFO - 2017-06-28 18:20:50 --> Helper loaded: url_helper
INFO - 2017-06-28 18:20:50 --> Model Class Initialized
INFO - 2017-06-28 18:20:50 --> Final output sent to browser
DEBUG - 2017-06-28 18:20:50 --> Total execution time: 0.0625
ERROR - 2017-06-28 18:20:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:20:52 --> Config Class Initialized
INFO - 2017-06-28 18:20:52 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:20:52 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:20:52 --> Utf8 Class Initialized
INFO - 2017-06-28 18:20:52 --> URI Class Initialized
INFO - 2017-06-28 18:20:52 --> Router Class Initialized
INFO - 2017-06-28 18:20:52 --> Output Class Initialized
INFO - 2017-06-28 18:20:52 --> Security Class Initialized
DEBUG - 2017-06-28 18:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:20:52 --> Input Class Initialized
INFO - 2017-06-28 18:20:52 --> Language Class Initialized
INFO - 2017-06-28 18:20:52 --> Loader Class Initialized
INFO - 2017-06-28 18:20:52 --> Controller Class Initialized
INFO - 2017-06-28 18:20:52 --> Database Driver Class Initialized
INFO - 2017-06-28 18:20:52 --> Model Class Initialized
INFO - 2017-06-28 18:20:52 --> Helper loaded: form_helper
INFO - 2017-06-28 18:20:52 --> Helper loaded: url_helper
INFO - 2017-06-28 18:20:52 --> Model Class Initialized
INFO - 2017-06-28 18:20:52 --> Final output sent to browser
DEBUG - 2017-06-28 18:20:52 --> Total execution time: 0.0455
ERROR - 2017-06-28 18:20:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:20:54 --> Config Class Initialized
INFO - 2017-06-28 18:20:54 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:20:54 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:20:54 --> Utf8 Class Initialized
INFO - 2017-06-28 18:20:54 --> URI Class Initialized
INFO - 2017-06-28 18:20:54 --> Router Class Initialized
INFO - 2017-06-28 18:20:54 --> Output Class Initialized
INFO - 2017-06-28 18:20:54 --> Security Class Initialized
DEBUG - 2017-06-28 18:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:20:54 --> Input Class Initialized
INFO - 2017-06-28 18:20:54 --> Language Class Initialized
INFO - 2017-06-28 18:20:54 --> Loader Class Initialized
INFO - 2017-06-28 18:20:54 --> Controller Class Initialized
INFO - 2017-06-28 18:20:54 --> Database Driver Class Initialized
INFO - 2017-06-28 18:20:54 --> Model Class Initialized
INFO - 2017-06-28 18:20:54 --> Helper loaded: form_helper
INFO - 2017-06-28 18:20:54 --> Helper loaded: url_helper
INFO - 2017-06-28 18:20:54 --> Model Class Initialized
INFO - 2017-06-28 18:20:54 --> Final output sent to browser
DEBUG - 2017-06-28 18:20:54 --> Total execution time: 0.0700
ERROR - 2017-06-28 18:42:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:42:02 --> Config Class Initialized
INFO - 2017-06-28 18:42:02 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:42:02 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:42:02 --> Utf8 Class Initialized
INFO - 2017-06-28 18:42:02 --> URI Class Initialized
INFO - 2017-06-28 18:42:02 --> Router Class Initialized
INFO - 2017-06-28 18:42:02 --> Output Class Initialized
INFO - 2017-06-28 18:42:02 --> Security Class Initialized
DEBUG - 2017-06-28 18:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:42:02 --> Input Class Initialized
INFO - 2017-06-28 18:42:02 --> Language Class Initialized
INFO - 2017-06-28 18:42:02 --> Loader Class Initialized
INFO - 2017-06-28 18:42:02 --> Controller Class Initialized
INFO - 2017-06-28 18:42:02 --> Database Driver Class Initialized
INFO - 2017-06-28 18:42:02 --> Model Class Initialized
INFO - 2017-06-28 18:42:02 --> Helper loaded: form_helper
INFO - 2017-06-28 18:42:02 --> Helper loaded: url_helper
INFO - 2017-06-28 18:42:02 --> Model Class Initialized
INFO - 2017-06-28 18:42:02 --> Final output sent to browser
DEBUG - 2017-06-28 18:42:02 --> Total execution time: 0.0600
ERROR - 2017-06-28 18:42:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:42:29 --> Config Class Initialized
INFO - 2017-06-28 18:42:29 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:42:29 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:42:29 --> Utf8 Class Initialized
INFO - 2017-06-28 18:42:29 --> URI Class Initialized
INFO - 2017-06-28 18:42:29 --> Router Class Initialized
INFO - 2017-06-28 18:42:29 --> Output Class Initialized
INFO - 2017-06-28 18:42:29 --> Security Class Initialized
DEBUG - 2017-06-28 18:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:42:29 --> Input Class Initialized
INFO - 2017-06-28 18:42:29 --> Language Class Initialized
INFO - 2017-06-28 18:42:29 --> Loader Class Initialized
INFO - 2017-06-28 18:42:29 --> Controller Class Initialized
INFO - 2017-06-28 18:42:29 --> Database Driver Class Initialized
INFO - 2017-06-28 18:42:29 --> Model Class Initialized
INFO - 2017-06-28 18:42:29 --> Helper loaded: form_helper
INFO - 2017-06-28 18:42:29 --> Helper loaded: url_helper
INFO - 2017-06-28 18:42:29 --> Model Class Initialized
INFO - 2017-06-28 18:42:29 --> Final output sent to browser
DEBUG - 2017-06-28 18:42:29 --> Total execution time: 0.0475
ERROR - 2017-06-28 18:42:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:42:31 --> Config Class Initialized
INFO - 2017-06-28 18:42:31 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:42:31 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:42:31 --> Utf8 Class Initialized
INFO - 2017-06-28 18:42:31 --> URI Class Initialized
INFO - 2017-06-28 18:42:31 --> Router Class Initialized
INFO - 2017-06-28 18:42:31 --> Output Class Initialized
INFO - 2017-06-28 18:42:31 --> Security Class Initialized
DEBUG - 2017-06-28 18:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:42:31 --> Input Class Initialized
INFO - 2017-06-28 18:42:31 --> Language Class Initialized
INFO - 2017-06-28 18:42:31 --> Loader Class Initialized
INFO - 2017-06-28 18:42:31 --> Controller Class Initialized
INFO - 2017-06-28 18:42:31 --> Database Driver Class Initialized
INFO - 2017-06-28 18:42:31 --> Model Class Initialized
INFO - 2017-06-28 18:42:31 --> Helper loaded: form_helper
INFO - 2017-06-28 18:42:31 --> Helper loaded: url_helper
INFO - 2017-06-28 18:42:31 --> Model Class Initialized
INFO - 2017-06-28 18:42:31 --> Final output sent to browser
DEBUG - 2017-06-28 18:42:31 --> Total execution time: 0.0500
ERROR - 2017-06-28 18:45:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:45:02 --> Config Class Initialized
INFO - 2017-06-28 18:45:02 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:45:02 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:45:02 --> Utf8 Class Initialized
INFO - 2017-06-28 18:45:02 --> URI Class Initialized
INFO - 2017-06-28 18:45:02 --> Router Class Initialized
INFO - 2017-06-28 18:45:02 --> Output Class Initialized
INFO - 2017-06-28 18:45:02 --> Security Class Initialized
DEBUG - 2017-06-28 18:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:45:02 --> Input Class Initialized
INFO - 2017-06-28 18:45:02 --> Language Class Initialized
INFO - 2017-06-28 18:45:02 --> Loader Class Initialized
INFO - 2017-06-28 18:45:03 --> Controller Class Initialized
INFO - 2017-06-28 18:45:03 --> Database Driver Class Initialized
INFO - 2017-06-28 18:45:03 --> Model Class Initialized
INFO - 2017-06-28 18:45:03 --> Helper loaded: form_helper
INFO - 2017-06-28 18:45:03 --> Helper loaded: url_helper
INFO - 2017-06-28 18:45:03 --> Model Class Initialized
INFO - 2017-06-28 18:45:03 --> Final output sent to browser
DEBUG - 2017-06-28 18:45:03 --> Total execution time: 0.0775
ERROR - 2017-06-28 18:45:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:45:04 --> Config Class Initialized
INFO - 2017-06-28 18:45:04 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:45:04 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:45:04 --> Utf8 Class Initialized
INFO - 2017-06-28 18:45:04 --> URI Class Initialized
INFO - 2017-06-28 18:45:04 --> Router Class Initialized
INFO - 2017-06-28 18:45:04 --> Output Class Initialized
INFO - 2017-06-28 18:45:04 --> Security Class Initialized
DEBUG - 2017-06-28 18:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:45:04 --> Input Class Initialized
INFO - 2017-06-28 18:45:04 --> Language Class Initialized
INFO - 2017-06-28 18:45:04 --> Loader Class Initialized
INFO - 2017-06-28 18:45:04 --> Controller Class Initialized
INFO - 2017-06-28 18:45:04 --> Database Driver Class Initialized
INFO - 2017-06-28 18:45:04 --> Model Class Initialized
INFO - 2017-06-28 18:45:04 --> Helper loaded: form_helper
INFO - 2017-06-28 18:45:04 --> Helper loaded: url_helper
INFO - 2017-06-28 18:45:04 --> Model Class Initialized
INFO - 2017-06-28 18:45:04 --> Final output sent to browser
DEBUG - 2017-06-28 18:45:04 --> Total execution time: 0.0500
ERROR - 2017-06-28 18:45:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:45:08 --> Config Class Initialized
INFO - 2017-06-28 18:45:08 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:45:08 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:45:08 --> Utf8 Class Initialized
INFO - 2017-06-28 18:45:08 --> URI Class Initialized
INFO - 2017-06-28 18:45:08 --> Router Class Initialized
INFO - 2017-06-28 18:45:08 --> Output Class Initialized
INFO - 2017-06-28 18:45:08 --> Security Class Initialized
DEBUG - 2017-06-28 18:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:45:08 --> Input Class Initialized
INFO - 2017-06-28 18:45:08 --> Language Class Initialized
INFO - 2017-06-28 18:45:09 --> Loader Class Initialized
INFO - 2017-06-28 18:45:09 --> Controller Class Initialized
INFO - 2017-06-28 18:45:09 --> Database Driver Class Initialized
INFO - 2017-06-28 18:45:09 --> Model Class Initialized
INFO - 2017-06-28 18:45:09 --> Helper loaded: form_helper
INFO - 2017-06-28 18:45:09 --> Helper loaded: url_helper
INFO - 2017-06-28 18:45:09 --> Model Class Initialized
INFO - 2017-06-28 18:45:09 --> Final output sent to browser
DEBUG - 2017-06-28 18:45:09 --> Total execution time: 0.0525
ERROR - 2017-06-28 18:45:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:45:21 --> Config Class Initialized
INFO - 2017-06-28 18:45:21 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:45:21 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:45:21 --> Utf8 Class Initialized
INFO - 2017-06-28 18:45:21 --> URI Class Initialized
INFO - 2017-06-28 18:45:21 --> Router Class Initialized
INFO - 2017-06-28 18:45:21 --> Output Class Initialized
INFO - 2017-06-28 18:45:21 --> Security Class Initialized
DEBUG - 2017-06-28 18:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:45:21 --> Input Class Initialized
INFO - 2017-06-28 18:45:21 --> Language Class Initialized
INFO - 2017-06-28 18:45:21 --> Loader Class Initialized
INFO - 2017-06-28 18:45:21 --> Controller Class Initialized
INFO - 2017-06-28 18:45:21 --> Database Driver Class Initialized
INFO - 2017-06-28 18:45:21 --> Model Class Initialized
INFO - 2017-06-28 18:45:21 --> Helper loaded: form_helper
INFO - 2017-06-28 18:45:21 --> Helper loaded: url_helper
INFO - 2017-06-28 18:45:21 --> Model Class Initialized
INFO - 2017-06-28 18:45:21 --> Final output sent to browser
DEBUG - 2017-06-28 18:45:21 --> Total execution time: 0.0600
ERROR - 2017-06-28 18:49:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:49:49 --> Config Class Initialized
INFO - 2017-06-28 18:49:49 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:49:49 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:49:49 --> Utf8 Class Initialized
INFO - 2017-06-28 18:49:49 --> URI Class Initialized
INFO - 2017-06-28 18:49:49 --> Router Class Initialized
INFO - 2017-06-28 18:49:49 --> Output Class Initialized
INFO - 2017-06-28 18:49:49 --> Security Class Initialized
DEBUG - 2017-06-28 18:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:49:49 --> Input Class Initialized
INFO - 2017-06-28 18:49:49 --> Language Class Initialized
INFO - 2017-06-28 18:49:49 --> Loader Class Initialized
INFO - 2017-06-28 18:49:49 --> Controller Class Initialized
INFO - 2017-06-28 18:49:49 --> Database Driver Class Initialized
INFO - 2017-06-28 18:49:49 --> Model Class Initialized
INFO - 2017-06-28 18:49:49 --> Helper loaded: form_helper
INFO - 2017-06-28 18:49:49 --> Helper loaded: url_helper
INFO - 2017-06-28 18:49:49 --> Model Class Initialized
INFO - 2017-06-28 18:49:49 --> Final output sent to browser
DEBUG - 2017-06-28 18:49:49 --> Total execution time: 0.0600
ERROR - 2017-06-28 18:49:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:49:50 --> Config Class Initialized
INFO - 2017-06-28 18:49:50 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:49:50 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:49:50 --> Utf8 Class Initialized
INFO - 2017-06-28 18:49:50 --> URI Class Initialized
INFO - 2017-06-28 18:49:50 --> Router Class Initialized
INFO - 2017-06-28 18:49:50 --> Output Class Initialized
INFO - 2017-06-28 18:49:50 --> Security Class Initialized
DEBUG - 2017-06-28 18:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:49:50 --> Input Class Initialized
INFO - 2017-06-28 18:49:50 --> Language Class Initialized
INFO - 2017-06-28 18:49:50 --> Loader Class Initialized
INFO - 2017-06-28 18:49:50 --> Controller Class Initialized
INFO - 2017-06-28 18:49:50 --> Database Driver Class Initialized
INFO - 2017-06-28 18:49:50 --> Model Class Initialized
INFO - 2017-06-28 18:49:50 --> Helper loaded: form_helper
INFO - 2017-06-28 18:49:50 --> Helper loaded: url_helper
INFO - 2017-06-28 18:49:50 --> Model Class Initialized
INFO - 2017-06-28 18:49:50 --> Final output sent to browser
DEBUG - 2017-06-28 18:49:50 --> Total execution time: 0.0600
ERROR - 2017-06-28 18:49:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:49:52 --> Config Class Initialized
INFO - 2017-06-28 18:49:52 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:49:52 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:49:52 --> Utf8 Class Initialized
INFO - 2017-06-28 18:49:52 --> URI Class Initialized
INFO - 2017-06-28 18:49:52 --> Router Class Initialized
INFO - 2017-06-28 18:49:52 --> Output Class Initialized
INFO - 2017-06-28 18:49:52 --> Security Class Initialized
DEBUG - 2017-06-28 18:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:49:52 --> Input Class Initialized
INFO - 2017-06-28 18:49:52 --> Language Class Initialized
INFO - 2017-06-28 18:49:52 --> Loader Class Initialized
INFO - 2017-06-28 18:49:52 --> Controller Class Initialized
INFO - 2017-06-28 18:49:52 --> Database Driver Class Initialized
INFO - 2017-06-28 18:49:52 --> Model Class Initialized
INFO - 2017-06-28 18:49:52 --> Helper loaded: form_helper
INFO - 2017-06-28 18:49:52 --> Helper loaded: url_helper
INFO - 2017-06-28 18:49:52 --> Model Class Initialized
INFO - 2017-06-28 18:49:52 --> Final output sent to browser
DEBUG - 2017-06-28 18:49:52 --> Total execution time: 0.0600
ERROR - 2017-06-28 18:50:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:50:57 --> Config Class Initialized
INFO - 2017-06-28 18:50:57 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:50:57 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:50:57 --> Utf8 Class Initialized
INFO - 2017-06-28 18:50:57 --> URI Class Initialized
INFO - 2017-06-28 18:50:57 --> Router Class Initialized
INFO - 2017-06-28 18:50:57 --> Output Class Initialized
INFO - 2017-06-28 18:50:57 --> Security Class Initialized
DEBUG - 2017-06-28 18:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:50:57 --> Input Class Initialized
INFO - 2017-06-28 18:50:57 --> Language Class Initialized
INFO - 2017-06-28 18:50:57 --> Loader Class Initialized
INFO - 2017-06-28 18:50:57 --> Controller Class Initialized
INFO - 2017-06-28 18:50:57 --> Database Driver Class Initialized
INFO - 2017-06-28 18:50:57 --> Model Class Initialized
INFO - 2017-06-28 18:50:57 --> Helper loaded: form_helper
INFO - 2017-06-28 18:50:57 --> Helper loaded: url_helper
INFO - 2017-06-28 18:50:58 --> Model Class Initialized
INFO - 2017-06-28 18:50:58 --> Final output sent to browser
DEBUG - 2017-06-28 18:50:58 --> Total execution time: 0.0525
ERROR - 2017-06-28 18:53:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:53:11 --> Config Class Initialized
INFO - 2017-06-28 18:53:11 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:53:11 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:53:11 --> Utf8 Class Initialized
INFO - 2017-06-28 18:53:11 --> URI Class Initialized
INFO - 2017-06-28 18:53:11 --> Router Class Initialized
INFO - 2017-06-28 18:53:11 --> Output Class Initialized
INFO - 2017-06-28 18:53:11 --> Security Class Initialized
DEBUG - 2017-06-28 18:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:53:11 --> Input Class Initialized
INFO - 2017-06-28 18:53:11 --> Language Class Initialized
INFO - 2017-06-28 18:53:11 --> Loader Class Initialized
INFO - 2017-06-28 18:53:11 --> Controller Class Initialized
INFO - 2017-06-28 18:53:11 --> Database Driver Class Initialized
INFO - 2017-06-28 18:53:11 --> Model Class Initialized
INFO - 2017-06-28 18:53:11 --> Helper loaded: form_helper
INFO - 2017-06-28 18:53:11 --> Helper loaded: url_helper
INFO - 2017-06-28 18:53:11 --> Model Class Initialized
INFO - 2017-06-28 18:53:11 --> Final output sent to browser
DEBUG - 2017-06-28 18:53:11 --> Total execution time: 0.0525
ERROR - 2017-06-28 18:53:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:53:12 --> Config Class Initialized
INFO - 2017-06-28 18:53:12 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:53:12 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:53:12 --> Utf8 Class Initialized
INFO - 2017-06-28 18:53:12 --> URI Class Initialized
INFO - 2017-06-28 18:53:12 --> Router Class Initialized
INFO - 2017-06-28 18:53:12 --> Output Class Initialized
INFO - 2017-06-28 18:53:12 --> Security Class Initialized
DEBUG - 2017-06-28 18:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:53:12 --> Input Class Initialized
INFO - 2017-06-28 18:53:12 --> Language Class Initialized
INFO - 2017-06-28 18:53:12 --> Loader Class Initialized
INFO - 2017-06-28 18:53:12 --> Controller Class Initialized
INFO - 2017-06-28 18:53:12 --> Database Driver Class Initialized
INFO - 2017-06-28 18:53:12 --> Model Class Initialized
INFO - 2017-06-28 18:53:12 --> Helper loaded: form_helper
INFO - 2017-06-28 18:53:12 --> Helper loaded: url_helper
INFO - 2017-06-28 18:53:12 --> Model Class Initialized
INFO - 2017-06-28 18:53:12 --> Final output sent to browser
DEBUG - 2017-06-28 18:53:12 --> Total execution time: 0.0600
ERROR - 2017-06-28 18:53:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:53:14 --> Config Class Initialized
INFO - 2017-06-28 18:53:14 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:53:14 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:53:14 --> Utf8 Class Initialized
INFO - 2017-06-28 18:53:14 --> URI Class Initialized
INFO - 2017-06-28 18:53:14 --> Router Class Initialized
INFO - 2017-06-28 18:53:14 --> Output Class Initialized
INFO - 2017-06-28 18:53:14 --> Security Class Initialized
DEBUG - 2017-06-28 18:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:53:14 --> Input Class Initialized
INFO - 2017-06-28 18:53:14 --> Language Class Initialized
INFO - 2017-06-28 18:53:14 --> Loader Class Initialized
INFO - 2017-06-28 18:53:14 --> Controller Class Initialized
INFO - 2017-06-28 18:53:14 --> Database Driver Class Initialized
INFO - 2017-06-28 18:53:14 --> Model Class Initialized
INFO - 2017-06-28 18:53:14 --> Helper loaded: form_helper
INFO - 2017-06-28 18:53:14 --> Helper loaded: url_helper
INFO - 2017-06-28 18:53:14 --> Model Class Initialized
INFO - 2017-06-28 18:53:14 --> Final output sent to browser
DEBUG - 2017-06-28 18:53:14 --> Total execution time: 0.0475
ERROR - 2017-06-28 18:53:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:53:20 --> Config Class Initialized
INFO - 2017-06-28 18:53:20 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:53:20 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:53:20 --> Utf8 Class Initialized
INFO - 2017-06-28 18:53:20 --> URI Class Initialized
INFO - 2017-06-28 18:53:20 --> Router Class Initialized
INFO - 2017-06-28 18:53:20 --> Output Class Initialized
INFO - 2017-06-28 18:53:20 --> Security Class Initialized
DEBUG - 2017-06-28 18:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:53:20 --> Input Class Initialized
INFO - 2017-06-28 18:53:20 --> Language Class Initialized
INFO - 2017-06-28 18:53:20 --> Loader Class Initialized
INFO - 2017-06-28 18:53:20 --> Controller Class Initialized
INFO - 2017-06-28 18:53:20 --> Database Driver Class Initialized
INFO - 2017-06-28 18:53:20 --> Model Class Initialized
INFO - 2017-06-28 18:53:20 --> Helper loaded: form_helper
INFO - 2017-06-28 18:53:20 --> Helper loaded: url_helper
INFO - 2017-06-28 18:53:20 --> Model Class Initialized
INFO - 2017-06-28 18:53:20 --> Final output sent to browser
DEBUG - 2017-06-28 18:53:20 --> Total execution time: 0.0550
ERROR - 2017-06-28 18:55:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:55:54 --> Config Class Initialized
INFO - 2017-06-28 18:55:54 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:55:54 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:55:54 --> Utf8 Class Initialized
INFO - 2017-06-28 18:55:54 --> URI Class Initialized
INFO - 2017-06-28 18:55:54 --> Router Class Initialized
INFO - 2017-06-28 18:55:54 --> Output Class Initialized
INFO - 2017-06-28 18:55:54 --> Security Class Initialized
DEBUG - 2017-06-28 18:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:55:54 --> Input Class Initialized
INFO - 2017-06-28 18:55:54 --> Language Class Initialized
INFO - 2017-06-28 18:55:54 --> Loader Class Initialized
INFO - 2017-06-28 18:55:54 --> Controller Class Initialized
INFO - 2017-06-28 18:55:54 --> Database Driver Class Initialized
INFO - 2017-06-28 18:55:54 --> Model Class Initialized
INFO - 2017-06-28 18:55:54 --> Helper loaded: form_helper
INFO - 2017-06-28 18:55:54 --> Helper loaded: url_helper
INFO - 2017-06-28 18:55:54 --> Model Class Initialized
INFO - 2017-06-28 18:55:54 --> Final output sent to browser
DEBUG - 2017-06-28 18:55:54 --> Total execution time: 0.0600
ERROR - 2017-06-28 18:57:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:57:24 --> Config Class Initialized
INFO - 2017-06-28 18:57:24 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:57:24 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:57:24 --> Utf8 Class Initialized
INFO - 2017-06-28 18:57:24 --> URI Class Initialized
INFO - 2017-06-28 18:57:24 --> Router Class Initialized
INFO - 2017-06-28 18:57:24 --> Output Class Initialized
INFO - 2017-06-28 18:57:24 --> Security Class Initialized
DEBUG - 2017-06-28 18:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:57:24 --> Input Class Initialized
INFO - 2017-06-28 18:57:24 --> Language Class Initialized
INFO - 2017-06-28 18:57:24 --> Loader Class Initialized
INFO - 2017-06-28 18:57:24 --> Controller Class Initialized
INFO - 2017-06-28 18:57:24 --> Database Driver Class Initialized
INFO - 2017-06-28 18:57:24 --> Model Class Initialized
INFO - 2017-06-28 18:57:24 --> Helper loaded: form_helper
INFO - 2017-06-28 18:57:24 --> Helper loaded: url_helper
INFO - 2017-06-28 18:57:24 --> Model Class Initialized
INFO - 2017-06-28 18:57:24 --> Final output sent to browser
DEBUG - 2017-06-28 18:57:24 --> Total execution time: 0.0600
ERROR - 2017-06-28 18:57:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:57:26 --> Config Class Initialized
INFO - 2017-06-28 18:57:26 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:57:26 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:57:26 --> Utf8 Class Initialized
INFO - 2017-06-28 18:57:26 --> URI Class Initialized
INFO - 2017-06-28 18:57:26 --> Router Class Initialized
INFO - 2017-06-28 18:57:26 --> Output Class Initialized
INFO - 2017-06-28 18:57:26 --> Security Class Initialized
DEBUG - 2017-06-28 18:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:57:26 --> Input Class Initialized
INFO - 2017-06-28 18:57:26 --> Language Class Initialized
INFO - 2017-06-28 18:57:26 --> Loader Class Initialized
INFO - 2017-06-28 18:57:26 --> Controller Class Initialized
INFO - 2017-06-28 18:57:26 --> Database Driver Class Initialized
INFO - 2017-06-28 18:57:26 --> Model Class Initialized
INFO - 2017-06-28 18:57:26 --> Helper loaded: form_helper
INFO - 2017-06-28 18:57:26 --> Helper loaded: url_helper
INFO - 2017-06-28 18:57:26 --> Model Class Initialized
INFO - 2017-06-28 18:57:26 --> Final output sent to browser
DEBUG - 2017-06-28 18:57:26 --> Total execution time: 0.0500
ERROR - 2017-06-28 18:57:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:57:27 --> Config Class Initialized
INFO - 2017-06-28 18:57:27 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:57:27 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:57:27 --> Utf8 Class Initialized
INFO - 2017-06-28 18:57:27 --> URI Class Initialized
INFO - 2017-06-28 18:57:27 --> Router Class Initialized
INFO - 2017-06-28 18:57:27 --> Output Class Initialized
INFO - 2017-06-28 18:57:27 --> Security Class Initialized
DEBUG - 2017-06-28 18:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:57:27 --> Input Class Initialized
INFO - 2017-06-28 18:57:27 --> Language Class Initialized
INFO - 2017-06-28 18:57:27 --> Loader Class Initialized
INFO - 2017-06-28 18:57:27 --> Controller Class Initialized
INFO - 2017-06-28 18:57:27 --> Database Driver Class Initialized
INFO - 2017-06-28 18:57:27 --> Model Class Initialized
INFO - 2017-06-28 18:57:27 --> Helper loaded: form_helper
INFO - 2017-06-28 18:57:27 --> Helper loaded: url_helper
INFO - 2017-06-28 18:57:27 --> Model Class Initialized
INFO - 2017-06-28 18:57:27 --> Final output sent to browser
DEBUG - 2017-06-28 18:57:27 --> Total execution time: 0.0600
ERROR - 2017-06-28 18:57:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:57:36 --> Config Class Initialized
INFO - 2017-06-28 18:57:36 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:57:36 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:57:36 --> Utf8 Class Initialized
INFO - 2017-06-28 18:57:36 --> URI Class Initialized
INFO - 2017-06-28 18:57:36 --> Router Class Initialized
INFO - 2017-06-28 18:57:36 --> Output Class Initialized
INFO - 2017-06-28 18:57:36 --> Security Class Initialized
DEBUG - 2017-06-28 18:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:57:36 --> Input Class Initialized
INFO - 2017-06-28 18:57:36 --> Language Class Initialized
INFO - 2017-06-28 18:57:36 --> Loader Class Initialized
INFO - 2017-06-28 18:57:36 --> Controller Class Initialized
INFO - 2017-06-28 18:57:36 --> Database Driver Class Initialized
INFO - 2017-06-28 18:57:36 --> Model Class Initialized
INFO - 2017-06-28 18:57:36 --> Helper loaded: form_helper
INFO - 2017-06-28 18:57:36 --> Helper loaded: url_helper
INFO - 2017-06-28 18:57:36 --> Model Class Initialized
INFO - 2017-06-28 18:57:36 --> Final output sent to browser
DEBUG - 2017-06-28 18:57:36 --> Total execution time: 0.0550
ERROR - 2017-06-28 18:57:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:57:38 --> Config Class Initialized
INFO - 2017-06-28 18:57:38 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:57:38 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:57:38 --> Utf8 Class Initialized
INFO - 2017-06-28 18:57:38 --> URI Class Initialized
INFO - 2017-06-28 18:57:38 --> Router Class Initialized
INFO - 2017-06-28 18:57:38 --> Output Class Initialized
INFO - 2017-06-28 18:57:38 --> Security Class Initialized
DEBUG - 2017-06-28 18:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:57:38 --> Input Class Initialized
INFO - 2017-06-28 18:57:38 --> Language Class Initialized
INFO - 2017-06-28 18:57:38 --> Loader Class Initialized
INFO - 2017-06-28 18:57:38 --> Controller Class Initialized
INFO - 2017-06-28 18:57:38 --> Database Driver Class Initialized
INFO - 2017-06-28 18:57:38 --> Model Class Initialized
INFO - 2017-06-28 18:57:38 --> Helper loaded: form_helper
INFO - 2017-06-28 18:57:38 --> Helper loaded: url_helper
INFO - 2017-06-28 18:57:38 --> Model Class Initialized
INFO - 2017-06-28 18:57:38 --> Final output sent to browser
DEBUG - 2017-06-28 18:57:38 --> Total execution time: 0.0450
ERROR - 2017-06-28 18:57:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:57:49 --> Config Class Initialized
INFO - 2017-06-28 18:57:49 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:57:49 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:57:49 --> Utf8 Class Initialized
INFO - 2017-06-28 18:57:49 --> URI Class Initialized
INFO - 2017-06-28 18:57:49 --> Router Class Initialized
INFO - 2017-06-28 18:57:49 --> Output Class Initialized
INFO - 2017-06-28 18:57:49 --> Security Class Initialized
DEBUG - 2017-06-28 18:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:57:49 --> Input Class Initialized
INFO - 2017-06-28 18:57:49 --> Language Class Initialized
INFO - 2017-06-28 18:57:49 --> Loader Class Initialized
INFO - 2017-06-28 18:57:49 --> Controller Class Initialized
INFO - 2017-06-28 18:57:49 --> Database Driver Class Initialized
INFO - 2017-06-28 18:57:49 --> Model Class Initialized
INFO - 2017-06-28 18:57:49 --> Helper loaded: form_helper
INFO - 2017-06-28 18:57:49 --> Helper loaded: url_helper
INFO - 2017-06-28 18:57:49 --> Model Class Initialized
INFO - 2017-06-28 18:57:49 --> Final output sent to browser
DEBUG - 2017-06-28 18:57:49 --> Total execution time: 0.0475
ERROR - 2017-06-28 18:58:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:58:14 --> Config Class Initialized
INFO - 2017-06-28 18:58:14 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:58:14 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:58:14 --> Utf8 Class Initialized
INFO - 2017-06-28 18:58:14 --> URI Class Initialized
INFO - 2017-06-28 18:58:14 --> Router Class Initialized
INFO - 2017-06-28 18:58:14 --> Output Class Initialized
INFO - 2017-06-28 18:58:14 --> Security Class Initialized
DEBUG - 2017-06-28 18:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:58:14 --> Input Class Initialized
INFO - 2017-06-28 18:58:14 --> Language Class Initialized
INFO - 2017-06-28 18:58:14 --> Loader Class Initialized
INFO - 2017-06-28 18:58:14 --> Controller Class Initialized
INFO - 2017-06-28 18:58:14 --> Database Driver Class Initialized
INFO - 2017-06-28 18:58:14 --> Model Class Initialized
INFO - 2017-06-28 18:58:14 --> Helper loaded: form_helper
INFO - 2017-06-28 18:58:14 --> Helper loaded: url_helper
INFO - 2017-06-28 18:58:14 --> Model Class Initialized
INFO - 2017-06-28 18:58:14 --> Final output sent to browser
DEBUG - 2017-06-28 18:58:14 --> Total execution time: 0.0520
ERROR - 2017-06-28 18:59:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:59:08 --> Config Class Initialized
INFO - 2017-06-28 18:59:08 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:59:08 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:59:08 --> Utf8 Class Initialized
INFO - 2017-06-28 18:59:08 --> URI Class Initialized
INFO - 2017-06-28 18:59:08 --> Router Class Initialized
INFO - 2017-06-28 18:59:08 --> Output Class Initialized
INFO - 2017-06-28 18:59:08 --> Security Class Initialized
DEBUG - 2017-06-28 18:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:59:08 --> Input Class Initialized
INFO - 2017-06-28 18:59:08 --> Language Class Initialized
INFO - 2017-06-28 18:59:08 --> Loader Class Initialized
INFO - 2017-06-28 18:59:08 --> Controller Class Initialized
INFO - 2017-06-28 18:59:08 --> Database Driver Class Initialized
INFO - 2017-06-28 18:59:08 --> Model Class Initialized
INFO - 2017-06-28 18:59:08 --> Helper loaded: form_helper
INFO - 2017-06-28 18:59:08 --> Helper loaded: url_helper
INFO - 2017-06-28 18:59:08 --> Model Class Initialized
INFO - 2017-06-28 18:59:08 --> Final output sent to browser
DEBUG - 2017-06-28 18:59:08 --> Total execution time: 0.0825
ERROR - 2017-06-28 18:59:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:59:17 --> Config Class Initialized
INFO - 2017-06-28 18:59:17 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:59:17 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:59:17 --> Utf8 Class Initialized
INFO - 2017-06-28 18:59:17 --> URI Class Initialized
INFO - 2017-06-28 18:59:17 --> Router Class Initialized
INFO - 2017-06-28 18:59:17 --> Output Class Initialized
INFO - 2017-06-28 18:59:17 --> Security Class Initialized
DEBUG - 2017-06-28 18:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:59:17 --> Input Class Initialized
INFO - 2017-06-28 18:59:17 --> Language Class Initialized
INFO - 2017-06-28 18:59:17 --> Loader Class Initialized
INFO - 2017-06-28 18:59:17 --> Controller Class Initialized
INFO - 2017-06-28 18:59:17 --> Database Driver Class Initialized
INFO - 2017-06-28 18:59:17 --> Model Class Initialized
INFO - 2017-06-28 18:59:17 --> Helper loaded: form_helper
INFO - 2017-06-28 18:59:17 --> Helper loaded: url_helper
INFO - 2017-06-28 18:59:17 --> Model Class Initialized
INFO - 2017-06-28 18:59:17 --> Final output sent to browser
DEBUG - 2017-06-28 18:59:17 --> Total execution time: 0.1050
ERROR - 2017-06-28 18:59:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 18:59:17 --> Config Class Initialized
INFO - 2017-06-28 18:59:17 --> Hooks Class Initialized
DEBUG - 2017-06-28 18:59:17 --> UTF-8 Support Enabled
INFO - 2017-06-28 18:59:17 --> Utf8 Class Initialized
INFO - 2017-06-28 18:59:17 --> URI Class Initialized
INFO - 2017-06-28 18:59:17 --> Router Class Initialized
INFO - 2017-06-28 18:59:17 --> Output Class Initialized
INFO - 2017-06-28 18:59:17 --> Security Class Initialized
DEBUG - 2017-06-28 18:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 18:59:17 --> Input Class Initialized
INFO - 2017-06-28 18:59:17 --> Language Class Initialized
INFO - 2017-06-28 18:59:17 --> Loader Class Initialized
INFO - 2017-06-28 18:59:17 --> Controller Class Initialized
INFO - 2017-06-28 18:59:17 --> Database Driver Class Initialized
INFO - 2017-06-28 18:59:17 --> Model Class Initialized
INFO - 2017-06-28 18:59:17 --> Helper loaded: form_helper
INFO - 2017-06-28 18:59:17 --> Helper loaded: url_helper
INFO - 2017-06-28 18:59:17 --> Model Class Initialized
INFO - 2017-06-28 18:59:17 --> Final output sent to browser
DEBUG - 2017-06-28 18:59:17 --> Total execution time: 0.0450
ERROR - 2017-06-28 19:00:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 19:00:15 --> Config Class Initialized
INFO - 2017-06-28 19:00:15 --> Hooks Class Initialized
DEBUG - 2017-06-28 19:00:15 --> UTF-8 Support Enabled
INFO - 2017-06-28 19:00:15 --> Utf8 Class Initialized
INFO - 2017-06-28 19:00:15 --> URI Class Initialized
INFO - 2017-06-28 19:00:15 --> Router Class Initialized
INFO - 2017-06-28 19:00:15 --> Output Class Initialized
INFO - 2017-06-28 19:00:15 --> Security Class Initialized
DEBUG - 2017-06-28 19:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 19:00:15 --> Input Class Initialized
INFO - 2017-06-28 19:00:15 --> Language Class Initialized
INFO - 2017-06-28 19:00:15 --> Loader Class Initialized
INFO - 2017-06-28 19:00:15 --> Controller Class Initialized
INFO - 2017-06-28 19:00:15 --> Database Driver Class Initialized
INFO - 2017-06-28 19:00:15 --> Model Class Initialized
INFO - 2017-06-28 19:00:15 --> Helper loaded: form_helper
INFO - 2017-06-28 19:00:15 --> Helper loaded: url_helper
INFO - 2017-06-28 19:00:15 --> Model Class Initialized
INFO - 2017-06-28 19:00:15 --> Final output sent to browser
DEBUG - 2017-06-28 19:00:15 --> Total execution time: 0.0675
ERROR - 2017-06-28 19:00:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 19:00:18 --> Config Class Initialized
INFO - 2017-06-28 19:00:18 --> Hooks Class Initialized
DEBUG - 2017-06-28 19:00:18 --> UTF-8 Support Enabled
INFO - 2017-06-28 19:00:18 --> Utf8 Class Initialized
INFO - 2017-06-28 19:00:18 --> URI Class Initialized
INFO - 2017-06-28 19:00:18 --> Router Class Initialized
INFO - 2017-06-28 19:00:18 --> Output Class Initialized
INFO - 2017-06-28 19:00:18 --> Security Class Initialized
DEBUG - 2017-06-28 19:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 19:00:18 --> Input Class Initialized
INFO - 2017-06-28 19:00:18 --> Language Class Initialized
INFO - 2017-06-28 19:00:18 --> Loader Class Initialized
INFO - 2017-06-28 19:00:18 --> Controller Class Initialized
INFO - 2017-06-28 19:00:18 --> Database Driver Class Initialized
INFO - 2017-06-28 19:00:18 --> Model Class Initialized
INFO - 2017-06-28 19:00:18 --> Helper loaded: form_helper
INFO - 2017-06-28 19:00:18 --> Helper loaded: url_helper
INFO - 2017-06-28 19:00:18 --> Model Class Initialized
INFO - 2017-06-28 19:00:18 --> Final output sent to browser
DEBUG - 2017-06-28 19:00:18 --> Total execution time: 0.0488
ERROR - 2017-06-28 19:00:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 19:00:48 --> Config Class Initialized
INFO - 2017-06-28 19:00:48 --> Hooks Class Initialized
DEBUG - 2017-06-28 19:00:48 --> UTF-8 Support Enabled
INFO - 2017-06-28 19:00:48 --> Utf8 Class Initialized
INFO - 2017-06-28 19:00:48 --> URI Class Initialized
INFO - 2017-06-28 19:00:48 --> Router Class Initialized
INFO - 2017-06-28 19:00:48 --> Output Class Initialized
INFO - 2017-06-28 19:00:48 --> Security Class Initialized
DEBUG - 2017-06-28 19:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 19:00:48 --> Input Class Initialized
INFO - 2017-06-28 19:00:48 --> Language Class Initialized
INFO - 2017-06-28 19:00:48 --> Loader Class Initialized
INFO - 2017-06-28 19:00:48 --> Controller Class Initialized
INFO - 2017-06-28 19:00:48 --> Database Driver Class Initialized
INFO - 2017-06-28 19:00:48 --> Model Class Initialized
INFO - 2017-06-28 19:00:48 --> Helper loaded: form_helper
INFO - 2017-06-28 19:00:48 --> Helper loaded: url_helper
INFO - 2017-06-28 19:00:48 --> Model Class Initialized
INFO - 2017-06-28 19:00:48 --> Final output sent to browser
DEBUG - 2017-06-28 19:00:48 --> Total execution time: 0.0550
ERROR - 2017-06-28 19:00:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 19:00:50 --> Config Class Initialized
INFO - 2017-06-28 19:00:50 --> Hooks Class Initialized
DEBUG - 2017-06-28 19:00:50 --> UTF-8 Support Enabled
INFO - 2017-06-28 19:00:50 --> Utf8 Class Initialized
INFO - 2017-06-28 19:00:50 --> URI Class Initialized
INFO - 2017-06-28 19:00:50 --> Router Class Initialized
INFO - 2017-06-28 19:00:50 --> Output Class Initialized
INFO - 2017-06-28 19:00:50 --> Security Class Initialized
DEBUG - 2017-06-28 19:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 19:00:50 --> Input Class Initialized
INFO - 2017-06-28 19:00:50 --> Language Class Initialized
INFO - 2017-06-28 19:00:50 --> Loader Class Initialized
INFO - 2017-06-28 19:00:50 --> Controller Class Initialized
INFO - 2017-06-28 19:00:50 --> Database Driver Class Initialized
INFO - 2017-06-28 19:00:50 --> Model Class Initialized
INFO - 2017-06-28 19:00:50 --> Helper loaded: form_helper
INFO - 2017-06-28 19:00:50 --> Helper loaded: url_helper
INFO - 2017-06-28 19:00:50 --> Model Class Initialized
INFO - 2017-06-28 19:00:50 --> Final output sent to browser
DEBUG - 2017-06-28 19:00:50 --> Total execution time: 0.0750
ERROR - 2017-06-28 19:01:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 19:01:01 --> Config Class Initialized
INFO - 2017-06-28 19:01:01 --> Hooks Class Initialized
DEBUG - 2017-06-28 19:01:01 --> UTF-8 Support Enabled
INFO - 2017-06-28 19:01:01 --> Utf8 Class Initialized
INFO - 2017-06-28 19:01:01 --> URI Class Initialized
INFO - 2017-06-28 19:01:01 --> Router Class Initialized
INFO - 2017-06-28 19:01:01 --> Output Class Initialized
INFO - 2017-06-28 19:01:01 --> Security Class Initialized
DEBUG - 2017-06-28 19:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 19:01:01 --> Input Class Initialized
INFO - 2017-06-28 19:01:01 --> Language Class Initialized
INFO - 2017-06-28 19:01:01 --> Loader Class Initialized
INFO - 2017-06-28 19:01:01 --> Controller Class Initialized
INFO - 2017-06-28 19:01:01 --> Database Driver Class Initialized
INFO - 2017-06-28 19:01:01 --> Model Class Initialized
INFO - 2017-06-28 19:01:01 --> Helper loaded: form_helper
INFO - 2017-06-28 19:01:01 --> Helper loaded: url_helper
INFO - 2017-06-28 19:01:01 --> Model Class Initialized
INFO - 2017-06-28 19:01:01 --> Final output sent to browser
DEBUG - 2017-06-28 19:01:01 --> Total execution time: 0.0975
ERROR - 2017-06-28 19:01:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 19:01:06 --> Config Class Initialized
INFO - 2017-06-28 19:01:06 --> Hooks Class Initialized
DEBUG - 2017-06-28 19:01:06 --> UTF-8 Support Enabled
INFO - 2017-06-28 19:01:06 --> Utf8 Class Initialized
INFO - 2017-06-28 19:01:06 --> URI Class Initialized
INFO - 2017-06-28 19:01:06 --> Router Class Initialized
INFO - 2017-06-28 19:01:06 --> Output Class Initialized
INFO - 2017-06-28 19:01:06 --> Security Class Initialized
DEBUG - 2017-06-28 19:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 19:01:06 --> Input Class Initialized
INFO - 2017-06-28 19:01:06 --> Language Class Initialized
INFO - 2017-06-28 19:01:06 --> Loader Class Initialized
INFO - 2017-06-28 19:01:06 --> Controller Class Initialized
INFO - 2017-06-28 19:01:06 --> Database Driver Class Initialized
INFO - 2017-06-28 19:01:06 --> Model Class Initialized
INFO - 2017-06-28 19:01:06 --> Helper loaded: form_helper
INFO - 2017-06-28 19:01:06 --> Helper loaded: url_helper
INFO - 2017-06-28 19:01:06 --> Model Class Initialized
INFO - 2017-06-28 19:01:06 --> Final output sent to browser
DEBUG - 2017-06-28 19:01:06 --> Total execution time: 0.0475
ERROR - 2017-06-28 19:01:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 19:01:59 --> Config Class Initialized
INFO - 2017-06-28 19:01:59 --> Hooks Class Initialized
DEBUG - 2017-06-28 19:01:59 --> UTF-8 Support Enabled
INFO - 2017-06-28 19:01:59 --> Utf8 Class Initialized
INFO - 2017-06-28 19:01:59 --> URI Class Initialized
INFO - 2017-06-28 19:01:59 --> Router Class Initialized
INFO - 2017-06-28 19:01:59 --> Output Class Initialized
INFO - 2017-06-28 19:01:59 --> Security Class Initialized
DEBUG - 2017-06-28 19:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 19:01:59 --> Input Class Initialized
INFO - 2017-06-28 19:01:59 --> Language Class Initialized
INFO - 2017-06-28 19:01:59 --> Loader Class Initialized
INFO - 2017-06-28 19:01:59 --> Controller Class Initialized
INFO - 2017-06-28 19:01:59 --> Database Driver Class Initialized
INFO - 2017-06-28 19:01:59 --> Model Class Initialized
INFO - 2017-06-28 19:01:59 --> Helper loaded: form_helper
INFO - 2017-06-28 19:01:59 --> Helper loaded: url_helper
INFO - 2017-06-28 19:01:59 --> Model Class Initialized
INFO - 2017-06-28 19:01:59 --> Final output sent to browser
DEBUG - 2017-06-28 19:01:59 --> Total execution time: 0.0670
ERROR - 2017-06-28 19:02:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 19:02:36 --> Config Class Initialized
INFO - 2017-06-28 19:02:36 --> Hooks Class Initialized
DEBUG - 2017-06-28 19:02:36 --> UTF-8 Support Enabled
INFO - 2017-06-28 19:02:36 --> Utf8 Class Initialized
INFO - 2017-06-28 19:02:36 --> URI Class Initialized
INFO - 2017-06-28 19:02:36 --> Router Class Initialized
INFO - 2017-06-28 19:02:36 --> Output Class Initialized
INFO - 2017-06-28 19:02:36 --> Security Class Initialized
DEBUG - 2017-06-28 19:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 19:02:36 --> Input Class Initialized
INFO - 2017-06-28 19:02:36 --> Language Class Initialized
INFO - 2017-06-28 19:02:36 --> Loader Class Initialized
INFO - 2017-06-28 19:02:36 --> Controller Class Initialized
INFO - 2017-06-28 19:02:36 --> Database Driver Class Initialized
INFO - 2017-06-28 19:02:36 --> Model Class Initialized
INFO - 2017-06-28 19:02:36 --> Helper loaded: form_helper
INFO - 2017-06-28 19:02:36 --> Helper loaded: url_helper
INFO - 2017-06-28 19:02:36 --> Model Class Initialized
INFO - 2017-06-28 19:02:36 --> Final output sent to browser
DEBUG - 2017-06-28 19:02:36 --> Total execution time: 0.0600
ERROR - 2017-06-28 19:03:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 19:03:08 --> Config Class Initialized
INFO - 2017-06-28 19:03:08 --> Hooks Class Initialized
DEBUG - 2017-06-28 19:03:08 --> UTF-8 Support Enabled
INFO - 2017-06-28 19:03:08 --> Utf8 Class Initialized
INFO - 2017-06-28 19:03:08 --> URI Class Initialized
INFO - 2017-06-28 19:03:08 --> Router Class Initialized
INFO - 2017-06-28 19:03:08 --> Output Class Initialized
INFO - 2017-06-28 19:03:08 --> Security Class Initialized
DEBUG - 2017-06-28 19:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 19:03:08 --> Input Class Initialized
INFO - 2017-06-28 19:03:08 --> Language Class Initialized
INFO - 2017-06-28 19:03:08 --> Loader Class Initialized
INFO - 2017-06-28 19:03:08 --> Controller Class Initialized
INFO - 2017-06-28 19:03:08 --> Database Driver Class Initialized
INFO - 2017-06-28 19:03:08 --> Model Class Initialized
INFO - 2017-06-28 19:03:08 --> Helper loaded: form_helper
INFO - 2017-06-28 19:03:08 --> Helper loaded: url_helper
INFO - 2017-06-28 19:03:08 --> Model Class Initialized
INFO - 2017-06-28 19:03:08 --> Final output sent to browser
DEBUG - 2017-06-28 19:03:08 --> Total execution time: 0.0675
ERROR - 2017-06-28 19:04:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-28 19:04:21 --> Config Class Initialized
INFO - 2017-06-28 19:04:21 --> Hooks Class Initialized
DEBUG - 2017-06-28 19:04:21 --> UTF-8 Support Enabled
INFO - 2017-06-28 19:04:21 --> Utf8 Class Initialized
INFO - 2017-06-28 19:04:21 --> URI Class Initialized
INFO - 2017-06-28 19:04:21 --> Router Class Initialized
INFO - 2017-06-28 19:04:21 --> Output Class Initialized
INFO - 2017-06-28 19:04:21 --> Security Class Initialized
DEBUG - 2017-06-28 19:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-28 19:04:21 --> Input Class Initialized
INFO - 2017-06-28 19:04:21 --> Language Class Initialized
INFO - 2017-06-28 19:04:21 --> Loader Class Initialized
INFO - 2017-06-28 19:04:21 --> Controller Class Initialized
INFO - 2017-06-28 19:04:21 --> Database Driver Class Initialized
INFO - 2017-06-28 19:04:21 --> Model Class Initialized
INFO - 2017-06-28 19:04:21 --> Helper loaded: form_helper
INFO - 2017-06-28 19:04:21 --> Helper loaded: url_helper
INFO - 2017-06-28 19:04:21 --> Model Class Initialized
INFO - 2017-06-28 19:04:21 --> Final output sent to browser
DEBUG - 2017-06-28 19:04:21 --> Total execution time: 0.0525
