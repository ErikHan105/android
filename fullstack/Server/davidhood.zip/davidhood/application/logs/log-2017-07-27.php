<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-27 07:39:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 07:39:17 --> Config Class Initialized
INFO - 2017-07-27 07:39:17 --> Hooks Class Initialized
DEBUG - 2017-07-27 07:39:17 --> UTF-8 Support Enabled
INFO - 2017-07-27 07:39:17 --> Utf8 Class Initialized
INFO - 2017-07-27 07:39:17 --> URI Class Initialized
DEBUG - 2017-07-27 07:39:17 --> No URI present. Default controller set.
INFO - 2017-07-27 07:39:17 --> Router Class Initialized
INFO - 2017-07-27 07:39:17 --> Output Class Initialized
INFO - 2017-07-27 07:39:17 --> Security Class Initialized
DEBUG - 2017-07-27 07:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 07:39:17 --> Input Class Initialized
INFO - 2017-07-27 07:39:17 --> Language Class Initialized
INFO - 2017-07-27 07:39:17 --> Loader Class Initialized
INFO - 2017-07-27 07:39:17 --> Controller Class Initialized
INFO - 2017-07-27 07:39:17 --> Database Driver Class Initialized
INFO - 2017-07-27 07:39:17 --> Model Class Initialized
INFO - 2017-07-27 07:39:17 --> Helper loaded: form_helper
INFO - 2017-07-27 07:39:17 --> Helper loaded: url_helper
INFO - 2017-07-27 07:39:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-27 07:39:17 --> Final output sent to browser
DEBUG - 2017-07-27 07:39:17 --> Total execution time: 0.0410
ERROR - 2017-07-27 07:39:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 07:39:19 --> Config Class Initialized
INFO - 2017-07-27 07:39:19 --> Hooks Class Initialized
DEBUG - 2017-07-27 07:39:19 --> UTF-8 Support Enabled
INFO - 2017-07-27 07:39:19 --> Utf8 Class Initialized
INFO - 2017-07-27 07:39:19 --> URI Class Initialized
INFO - 2017-07-27 07:39:19 --> Router Class Initialized
INFO - 2017-07-27 07:39:19 --> Output Class Initialized
INFO - 2017-07-27 07:39:19 --> Security Class Initialized
DEBUG - 2017-07-27 07:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 07:39:19 --> Input Class Initialized
INFO - 2017-07-27 07:39:19 --> Language Class Initialized
INFO - 2017-07-27 07:39:19 --> Loader Class Initialized
INFO - 2017-07-27 07:39:19 --> Controller Class Initialized
INFO - 2017-07-27 07:39:19 --> Database Driver Class Initialized
INFO - 2017-07-27 07:39:19 --> Model Class Initialized
INFO - 2017-07-27 07:39:19 --> Helper loaded: form_helper
INFO - 2017-07-27 07:39:19 --> Helper loaded: url_helper
INFO - 2017-07-27 07:39:19 --> Model Class Initialized
ERROR - 2017-07-27 07:39:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 07:39:19 --> Config Class Initialized
INFO - 2017-07-27 07:39:19 --> Hooks Class Initialized
DEBUG - 2017-07-27 07:39:19 --> UTF-8 Support Enabled
INFO - 2017-07-27 07:39:19 --> Utf8 Class Initialized
INFO - 2017-07-27 07:39:19 --> URI Class Initialized
INFO - 2017-07-27 07:39:19 --> Router Class Initialized
INFO - 2017-07-27 07:39:19 --> Output Class Initialized
INFO - 2017-07-27 07:39:19 --> Security Class Initialized
DEBUG - 2017-07-27 07:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 07:39:19 --> Input Class Initialized
INFO - 2017-07-27 07:39:19 --> Language Class Initialized
INFO - 2017-07-27 07:39:19 --> Loader Class Initialized
INFO - 2017-07-27 07:39:19 --> Controller Class Initialized
INFO - 2017-07-27 07:39:19 --> Database Driver Class Initialized
INFO - 2017-07-27 07:39:19 --> Model Class Initialized
INFO - 2017-07-27 07:39:19 --> Helper loaded: form_helper
INFO - 2017-07-27 07:39:19 --> Helper loaded: url_helper
INFO - 2017-07-27 07:39:19 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-27 07:39:19 --> Model Class Initialized
INFO - 2017-07-27 07:39:19 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-27 07:39:19 --> Final output sent to browser
DEBUG - 2017-07-27 07:39:19 --> Total execution time: 0.0530
ERROR - 2017-07-27 07:39:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 07:39:23 --> Config Class Initialized
INFO - 2017-07-27 07:39:23 --> Hooks Class Initialized
DEBUG - 2017-07-27 07:39:23 --> UTF-8 Support Enabled
INFO - 2017-07-27 07:39:23 --> Utf8 Class Initialized
INFO - 2017-07-27 07:39:23 --> URI Class Initialized
INFO - 2017-07-27 07:39:23 --> Router Class Initialized
INFO - 2017-07-27 07:39:23 --> Output Class Initialized
INFO - 2017-07-27 07:39:23 --> Security Class Initialized
DEBUG - 2017-07-27 07:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 07:39:23 --> Input Class Initialized
INFO - 2017-07-27 07:39:23 --> Language Class Initialized
INFO - 2017-07-27 07:39:23 --> Loader Class Initialized
INFO - 2017-07-27 07:39:23 --> Controller Class Initialized
INFO - 2017-07-27 07:39:23 --> Database Driver Class Initialized
INFO - 2017-07-27 07:39:23 --> Model Class Initialized
INFO - 2017-07-27 07:39:23 --> Helper loaded: form_helper
INFO - 2017-07-27 07:39:23 --> Helper loaded: url_helper
INFO - 2017-07-27 07:39:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-27 07:39:23 --> Model Class Initialized
INFO - 2017-07-27 07:39:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-27 07:39:23 --> Final output sent to browser
DEBUG - 2017-07-27 07:39:23 --> Total execution time: 0.0570
ERROR - 2017-07-27 07:39:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 07:39:26 --> Config Class Initialized
INFO - 2017-07-27 07:39:26 --> Hooks Class Initialized
DEBUG - 2017-07-27 07:39:26 --> UTF-8 Support Enabled
INFO - 2017-07-27 07:39:26 --> Utf8 Class Initialized
INFO - 2017-07-27 07:39:26 --> URI Class Initialized
INFO - 2017-07-27 07:39:26 --> Router Class Initialized
INFO - 2017-07-27 07:39:26 --> Output Class Initialized
INFO - 2017-07-27 07:39:26 --> Security Class Initialized
DEBUG - 2017-07-27 07:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 07:39:26 --> Input Class Initialized
INFO - 2017-07-27 07:39:26 --> Language Class Initialized
INFO - 2017-07-27 07:39:26 --> Loader Class Initialized
INFO - 2017-07-27 07:39:26 --> Controller Class Initialized
INFO - 2017-07-27 07:39:26 --> Database Driver Class Initialized
INFO - 2017-07-27 07:39:26 --> Model Class Initialized
INFO - 2017-07-27 07:39:26 --> Helper loaded: form_helper
INFO - 2017-07-27 07:39:26 --> Helper loaded: url_helper
INFO - 2017-07-27 07:39:26 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-27 07:39:26 --> Model Class Initialized
INFO - 2017-07-27 07:39:26 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-27 07:39:26 --> Final output sent to browser
DEBUG - 2017-07-27 07:39:26 --> Total execution time: 0.0630
ERROR - 2017-07-27 07:39:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 07:39:49 --> Config Class Initialized
INFO - 2017-07-27 07:39:49 --> Hooks Class Initialized
DEBUG - 2017-07-27 07:39:49 --> UTF-8 Support Enabled
INFO - 2017-07-27 07:39:49 --> Utf8 Class Initialized
INFO - 2017-07-27 07:39:49 --> URI Class Initialized
INFO - 2017-07-27 07:39:49 --> Router Class Initialized
INFO - 2017-07-27 07:39:49 --> Output Class Initialized
INFO - 2017-07-27 07:39:49 --> Security Class Initialized
DEBUG - 2017-07-27 07:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 07:39:49 --> Input Class Initialized
INFO - 2017-07-27 07:39:49 --> Language Class Initialized
INFO - 2017-07-27 07:39:49 --> Loader Class Initialized
INFO - 2017-07-27 07:39:49 --> Controller Class Initialized
INFO - 2017-07-27 07:39:49 --> Database Driver Class Initialized
INFO - 2017-07-27 07:39:49 --> Model Class Initialized
INFO - 2017-07-27 07:39:49 --> Helper loaded: form_helper
INFO - 2017-07-27 07:39:49 --> Helper loaded: url_helper
INFO - 2017-07-27 07:39:49 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-27 07:39:49 --> Model Class Initialized
INFO - 2017-07-27 07:39:49 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-27 07:39:49 --> Final output sent to browser
DEBUG - 2017-07-27 07:39:49 --> Total execution time: 0.0650
ERROR - 2017-07-27 07:39:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 07:39:56 --> Config Class Initialized
INFO - 2017-07-27 07:39:56 --> Hooks Class Initialized
DEBUG - 2017-07-27 07:39:56 --> UTF-8 Support Enabled
INFO - 2017-07-27 07:39:56 --> Utf8 Class Initialized
INFO - 2017-07-27 07:39:56 --> URI Class Initialized
INFO - 2017-07-27 07:39:56 --> Router Class Initialized
INFO - 2017-07-27 07:39:56 --> Output Class Initialized
INFO - 2017-07-27 07:39:56 --> Security Class Initialized
DEBUG - 2017-07-27 07:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 07:39:56 --> Input Class Initialized
INFO - 2017-07-27 07:39:56 --> Language Class Initialized
INFO - 2017-07-27 07:39:56 --> Loader Class Initialized
INFO - 2017-07-27 07:39:56 --> Controller Class Initialized
INFO - 2017-07-27 07:39:56 --> Database Driver Class Initialized
INFO - 2017-07-27 07:39:56 --> Model Class Initialized
INFO - 2017-07-27 07:39:56 --> Helper loaded: form_helper
INFO - 2017-07-27 07:39:56 --> Helper loaded: url_helper
INFO - 2017-07-27 07:39:56 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-27 07:39:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempo_detail.php
INFO - 2017-07-27 07:39:57 --> Final output sent to browser
DEBUG - 2017-07-27 07:39:57 --> Total execution time: 0.0800
ERROR - 2017-07-27 07:40:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 07:40:07 --> Config Class Initialized
INFO - 2017-07-27 07:40:07 --> Hooks Class Initialized
DEBUG - 2017-07-27 07:40:07 --> UTF-8 Support Enabled
INFO - 2017-07-27 07:40:07 --> Utf8 Class Initialized
INFO - 2017-07-27 07:40:07 --> URI Class Initialized
INFO - 2017-07-27 07:40:07 --> Router Class Initialized
INFO - 2017-07-27 07:40:07 --> Output Class Initialized
INFO - 2017-07-27 07:40:07 --> Security Class Initialized
DEBUG - 2017-07-27 07:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 07:40:07 --> Input Class Initialized
INFO - 2017-07-27 07:40:07 --> Language Class Initialized
INFO - 2017-07-27 07:40:07 --> Loader Class Initialized
INFO - 2017-07-27 07:40:07 --> Controller Class Initialized
INFO - 2017-07-27 07:40:07 --> Database Driver Class Initialized
INFO - 2017-07-27 07:40:07 --> Model Class Initialized
INFO - 2017-07-27 07:40:07 --> Helper loaded: form_helper
INFO - 2017-07-27 07:40:07 --> Helper loaded: url_helper
INFO - 2017-07-27 07:40:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-27 07:40:07 --> Model Class Initialized
INFO - 2017-07-27 07:40:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\users.php
INFO - 2017-07-27 07:40:07 --> Final output sent to browser
DEBUG - 2017-07-27 07:40:07 --> Total execution time: 0.0820
ERROR - 2017-07-27 07:40:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 07:40:17 --> Config Class Initialized
INFO - 2017-07-27 07:40:17 --> Hooks Class Initialized
DEBUG - 2017-07-27 07:40:17 --> UTF-8 Support Enabled
INFO - 2017-07-27 07:40:17 --> Utf8 Class Initialized
INFO - 2017-07-27 07:40:17 --> URI Class Initialized
INFO - 2017-07-27 07:40:17 --> Router Class Initialized
INFO - 2017-07-27 07:40:17 --> Output Class Initialized
INFO - 2017-07-27 07:40:17 --> Security Class Initialized
DEBUG - 2017-07-27 07:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 07:40:17 --> Input Class Initialized
INFO - 2017-07-27 07:40:17 --> Language Class Initialized
INFO - 2017-07-27 07:40:17 --> Loader Class Initialized
INFO - 2017-07-27 07:40:17 --> Controller Class Initialized
INFO - 2017-07-27 07:40:17 --> Database Driver Class Initialized
INFO - 2017-07-27 07:40:17 --> Model Class Initialized
INFO - 2017-07-27 07:40:17 --> Helper loaded: form_helper
INFO - 2017-07-27 07:40:17 --> Helper loaded: url_helper
INFO - 2017-07-27 07:40:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-27 07:40:17 --> Model Class Initialized
INFO - 2017-07-27 07:40:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-27 07:40:17 --> Final output sent to browser
DEBUG - 2017-07-27 07:40:17 --> Total execution time: 0.0600
ERROR - 2017-07-27 07:40:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 07:40:24 --> Config Class Initialized
INFO - 2017-07-27 07:40:24 --> Hooks Class Initialized
DEBUG - 2017-07-27 07:40:24 --> UTF-8 Support Enabled
INFO - 2017-07-27 07:40:24 --> Utf8 Class Initialized
INFO - 2017-07-27 07:40:24 --> URI Class Initialized
INFO - 2017-07-27 07:40:24 --> Router Class Initialized
INFO - 2017-07-27 07:40:24 --> Output Class Initialized
INFO - 2017-07-27 07:40:24 --> Security Class Initialized
DEBUG - 2017-07-27 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 07:40:24 --> Input Class Initialized
INFO - 2017-07-27 07:40:24 --> Language Class Initialized
INFO - 2017-07-27 07:40:24 --> Loader Class Initialized
INFO - 2017-07-27 07:40:24 --> Controller Class Initialized
INFO - 2017-07-27 07:40:24 --> Database Driver Class Initialized
INFO - 2017-07-27 07:40:24 --> Model Class Initialized
INFO - 2017-07-27 07:40:24 --> Helper loaded: form_helper
INFO - 2017-07-27 07:40:24 --> Helper loaded: url_helper
INFO - 2017-07-27 07:40:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-27 07:40:24 --> Model Class Initialized
INFO - 2017-07-27 07:40:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\purchase.php
INFO - 2017-07-27 07:40:24 --> Final output sent to browser
DEBUG - 2017-07-27 07:40:24 --> Total execution time: 0.0610
ERROR - 2017-07-27 07:40:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 07:40:25 --> Config Class Initialized
INFO - 2017-07-27 07:40:25 --> Hooks Class Initialized
DEBUG - 2017-07-27 07:40:25 --> UTF-8 Support Enabled
INFO - 2017-07-27 07:40:25 --> Utf8 Class Initialized
INFO - 2017-07-27 07:40:25 --> URI Class Initialized
INFO - 2017-07-27 07:40:25 --> Router Class Initialized
INFO - 2017-07-27 07:40:25 --> Output Class Initialized
INFO - 2017-07-27 07:40:25 --> Security Class Initialized
DEBUG - 2017-07-27 07:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 07:40:25 --> Input Class Initialized
INFO - 2017-07-27 07:40:25 --> Language Class Initialized
INFO - 2017-07-27 07:40:25 --> Loader Class Initialized
INFO - 2017-07-27 07:40:25 --> Controller Class Initialized
INFO - 2017-07-27 07:40:25 --> Database Driver Class Initialized
INFO - 2017-07-27 07:40:25 --> Model Class Initialized
INFO - 2017-07-27 07:40:25 --> Helper loaded: form_helper
INFO - 2017-07-27 07:40:25 --> Helper loaded: url_helper
INFO - 2017-07-27 07:40:25 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-27 07:40:25 --> Model Class Initialized
INFO - 2017-07-27 07:40:25 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-27 07:40:25 --> Final output sent to browser
DEBUG - 2017-07-27 07:40:25 --> Total execution time: 0.0740
ERROR - 2017-07-27 07:41:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 07:41:47 --> Config Class Initialized
INFO - 2017-07-27 07:41:47 --> Hooks Class Initialized
DEBUG - 2017-07-27 07:41:47 --> UTF-8 Support Enabled
INFO - 2017-07-27 07:41:47 --> Utf8 Class Initialized
INFO - 2017-07-27 07:41:47 --> URI Class Initialized
INFO - 2017-07-27 07:41:47 --> Router Class Initialized
INFO - 2017-07-27 07:41:47 --> Output Class Initialized
INFO - 2017-07-27 07:41:47 --> Security Class Initialized
DEBUG - 2017-07-27 07:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 07:41:47 --> Input Class Initialized
INFO - 2017-07-27 07:41:47 --> Language Class Initialized
INFO - 2017-07-27 07:41:47 --> Loader Class Initialized
INFO - 2017-07-27 07:41:47 --> Controller Class Initialized
INFO - 2017-07-27 07:41:47 --> Database Driver Class Initialized
INFO - 2017-07-27 07:41:47 --> Model Class Initialized
INFO - 2017-07-27 07:41:47 --> Helper loaded: form_helper
INFO - 2017-07-27 07:41:47 --> Helper loaded: url_helper
INFO - 2017-07-27 07:41:47 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-27 07:41:47 --> Model Class Initialized
INFO - 2017-07-27 07:41:47 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-27 07:41:47 --> Final output sent to browser
DEBUG - 2017-07-27 07:41:47 --> Total execution time: 0.0620
ERROR - 2017-07-27 07:41:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 07:41:48 --> Config Class Initialized
INFO - 2017-07-27 07:41:48 --> Hooks Class Initialized
DEBUG - 2017-07-27 07:41:48 --> UTF-8 Support Enabled
INFO - 2017-07-27 07:41:48 --> Utf8 Class Initialized
INFO - 2017-07-27 07:41:48 --> URI Class Initialized
INFO - 2017-07-27 07:41:48 --> Router Class Initialized
INFO - 2017-07-27 07:41:48 --> Output Class Initialized
INFO - 2017-07-27 07:41:48 --> Security Class Initialized
DEBUG - 2017-07-27 07:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 07:41:48 --> Input Class Initialized
INFO - 2017-07-27 07:41:48 --> Language Class Initialized
INFO - 2017-07-27 07:41:48 --> Loader Class Initialized
INFO - 2017-07-27 07:41:48 --> Controller Class Initialized
INFO - 2017-07-27 07:41:48 --> Database Driver Class Initialized
INFO - 2017-07-27 07:41:48 --> Model Class Initialized
INFO - 2017-07-27 07:41:48 --> Helper loaded: form_helper
INFO - 2017-07-27 07:41:48 --> Helper loaded: url_helper
INFO - 2017-07-27 07:41:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-27 07:41:48 --> Model Class Initialized
INFO - 2017-07-27 07:41:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-27 07:41:48 --> Final output sent to browser
DEBUG - 2017-07-27 07:41:48 --> Total execution time: 0.0670
ERROR - 2017-07-27 21:06:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 21:06:37 --> Config Class Initialized
INFO - 2017-07-27 21:06:37 --> Hooks Class Initialized
DEBUG - 2017-07-27 21:06:37 --> UTF-8 Support Enabled
INFO - 2017-07-27 21:06:37 --> Utf8 Class Initialized
INFO - 2017-07-27 21:06:37 --> URI Class Initialized
DEBUG - 2017-07-27 21:06:37 --> No URI present. Default controller set.
INFO - 2017-07-27 21:06:37 --> Router Class Initialized
INFO - 2017-07-27 21:06:37 --> Output Class Initialized
INFO - 2017-07-27 21:06:37 --> Security Class Initialized
DEBUG - 2017-07-27 21:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 21:06:37 --> Input Class Initialized
INFO - 2017-07-27 21:06:37 --> Language Class Initialized
INFO - 2017-07-27 21:06:37 --> Loader Class Initialized
INFO - 2017-07-27 21:06:37 --> Controller Class Initialized
INFO - 2017-07-27 21:06:37 --> Database Driver Class Initialized
INFO - 2017-07-27 21:06:37 --> Model Class Initialized
INFO - 2017-07-27 21:06:37 --> Helper loaded: form_helper
INFO - 2017-07-27 21:06:37 --> Helper loaded: url_helper
INFO - 2017-07-27 21:06:37 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-27 21:06:37 --> Final output sent to browser
DEBUG - 2017-07-27 21:06:37 --> Total execution time: 0.0430
ERROR - 2017-07-27 21:06:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 21:06:41 --> Config Class Initialized
INFO - 2017-07-27 21:06:41 --> Hooks Class Initialized
DEBUG - 2017-07-27 21:06:41 --> UTF-8 Support Enabled
INFO - 2017-07-27 21:06:41 --> Utf8 Class Initialized
INFO - 2017-07-27 21:06:41 --> URI Class Initialized
INFO - 2017-07-27 21:06:41 --> Router Class Initialized
INFO - 2017-07-27 21:06:41 --> Output Class Initialized
INFO - 2017-07-27 21:06:41 --> Security Class Initialized
DEBUG - 2017-07-27 21:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 21:06:41 --> Input Class Initialized
INFO - 2017-07-27 21:06:41 --> Language Class Initialized
INFO - 2017-07-27 21:06:41 --> Loader Class Initialized
INFO - 2017-07-27 21:06:41 --> Controller Class Initialized
INFO - 2017-07-27 21:06:41 --> Database Driver Class Initialized
INFO - 2017-07-27 21:06:41 --> Model Class Initialized
INFO - 2017-07-27 21:06:41 --> Helper loaded: form_helper
INFO - 2017-07-27 21:06:41 --> Helper loaded: url_helper
INFO - 2017-07-27 21:06:41 --> Model Class Initialized
ERROR - 2017-07-27 21:06:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 21:06:41 --> Config Class Initialized
INFO - 2017-07-27 21:06:41 --> Hooks Class Initialized
DEBUG - 2017-07-27 21:06:41 --> UTF-8 Support Enabled
INFO - 2017-07-27 21:06:41 --> Utf8 Class Initialized
INFO - 2017-07-27 21:06:41 --> URI Class Initialized
INFO - 2017-07-27 21:06:41 --> Router Class Initialized
INFO - 2017-07-27 21:06:41 --> Output Class Initialized
INFO - 2017-07-27 21:06:41 --> Security Class Initialized
DEBUG - 2017-07-27 21:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 21:06:41 --> Input Class Initialized
INFO - 2017-07-27 21:06:41 --> Language Class Initialized
INFO - 2017-07-27 21:06:41 --> Loader Class Initialized
INFO - 2017-07-27 21:06:41 --> Controller Class Initialized
INFO - 2017-07-27 21:06:41 --> Database Driver Class Initialized
INFO - 2017-07-27 21:06:41 --> Model Class Initialized
INFO - 2017-07-27 21:06:41 --> Helper loaded: form_helper
INFO - 2017-07-27 21:06:41 --> Helper loaded: url_helper
INFO - 2017-07-27 21:06:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-27 21:06:41 --> Model Class Initialized
INFO - 2017-07-27 21:06:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-27 21:06:41 --> Final output sent to browser
DEBUG - 2017-07-27 21:06:41 --> Total execution time: 0.0630
ERROR - 2017-07-27 21:08:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 21:08:09 --> Config Class Initialized
INFO - 2017-07-27 21:08:09 --> Hooks Class Initialized
DEBUG - 2017-07-27 21:08:09 --> UTF-8 Support Enabled
INFO - 2017-07-27 21:08:09 --> Utf8 Class Initialized
INFO - 2017-07-27 21:08:09 --> URI Class Initialized
INFO - 2017-07-27 21:08:09 --> Router Class Initialized
INFO - 2017-07-27 21:08:09 --> Output Class Initialized
INFO - 2017-07-27 21:08:09 --> Security Class Initialized
DEBUG - 2017-07-27 21:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 21:08:09 --> Input Class Initialized
INFO - 2017-07-27 21:08:09 --> Language Class Initialized
INFO - 2017-07-27 21:08:09 --> Loader Class Initialized
INFO - 2017-07-27 21:08:09 --> Controller Class Initialized
INFO - 2017-07-27 21:08:09 --> Database Driver Class Initialized
INFO - 2017-07-27 21:08:09 --> Model Class Initialized
INFO - 2017-07-27 21:08:09 --> Helper loaded: form_helper
INFO - 2017-07-27 21:08:09 --> Helper loaded: url_helper
INFO - 2017-07-27 21:08:09 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-27 21:08:09 --> Model Class Initialized
INFO - 2017-07-27 21:08:09 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-27 21:08:09 --> Final output sent to browser
DEBUG - 2017-07-27 21:08:09 --> Total execution time: 0.0460
ERROR - 2017-07-27 21:08:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 21:08:23 --> Config Class Initialized
INFO - 2017-07-27 21:08:23 --> Hooks Class Initialized
DEBUG - 2017-07-27 21:08:23 --> UTF-8 Support Enabled
INFO - 2017-07-27 21:08:23 --> Utf8 Class Initialized
INFO - 2017-07-27 21:08:23 --> URI Class Initialized
INFO - 2017-07-27 21:08:23 --> Router Class Initialized
INFO - 2017-07-27 21:08:23 --> Output Class Initialized
INFO - 2017-07-27 21:08:23 --> Security Class Initialized
DEBUG - 2017-07-27 21:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 21:08:23 --> Input Class Initialized
INFO - 2017-07-27 21:08:23 --> Language Class Initialized
INFO - 2017-07-27 21:08:23 --> Loader Class Initialized
INFO - 2017-07-27 21:08:23 --> Controller Class Initialized
INFO - 2017-07-27 21:08:23 --> Database Driver Class Initialized
INFO - 2017-07-27 21:08:23 --> Model Class Initialized
INFO - 2017-07-27 21:08:23 --> Helper loaded: form_helper
INFO - 2017-07-27 21:08:23 --> Helper loaded: url_helper
INFO - 2017-07-27 21:08:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-27 21:08:23 --> Model Class Initialized
INFO - 2017-07-27 21:08:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\users.php
INFO - 2017-07-27 21:08:23 --> Final output sent to browser
DEBUG - 2017-07-27 21:08:23 --> Total execution time: 0.0900
ERROR - 2017-07-27 21:09:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 21:09:01 --> Config Class Initialized
INFO - 2017-07-27 21:09:01 --> Hooks Class Initialized
DEBUG - 2017-07-27 21:09:01 --> UTF-8 Support Enabled
INFO - 2017-07-27 21:09:01 --> Utf8 Class Initialized
INFO - 2017-07-27 21:09:01 --> URI Class Initialized
INFO - 2017-07-27 21:09:01 --> Router Class Initialized
INFO - 2017-07-27 21:09:01 --> Output Class Initialized
INFO - 2017-07-27 21:09:01 --> Security Class Initialized
DEBUG - 2017-07-27 21:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 21:09:01 --> Input Class Initialized
INFO - 2017-07-27 21:09:01 --> Language Class Initialized
INFO - 2017-07-27 21:09:01 --> Loader Class Initialized
INFO - 2017-07-27 21:09:01 --> Controller Class Initialized
INFO - 2017-07-27 21:09:01 --> Database Driver Class Initialized
INFO - 2017-07-27 21:09:01 --> Model Class Initialized
INFO - 2017-07-27 21:09:01 --> Helper loaded: form_helper
INFO - 2017-07-27 21:09:01 --> Helper loaded: url_helper
INFO - 2017-07-27 21:09:01 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-27 21:09:01 --> Final output sent to browser
DEBUG - 2017-07-27 21:09:01 --> Total execution time: 0.0750
ERROR - 2017-07-27 21:09:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 21:09:16 --> Config Class Initialized
INFO - 2017-07-27 21:09:16 --> Hooks Class Initialized
DEBUG - 2017-07-27 21:09:16 --> UTF-8 Support Enabled
INFO - 2017-07-27 21:09:16 --> Utf8 Class Initialized
INFO - 2017-07-27 21:09:16 --> URI Class Initialized
INFO - 2017-07-27 21:09:16 --> Router Class Initialized
INFO - 2017-07-27 21:09:16 --> Output Class Initialized
INFO - 2017-07-27 21:09:16 --> Security Class Initialized
DEBUG - 2017-07-27 21:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 21:09:16 --> Input Class Initialized
INFO - 2017-07-27 21:09:16 --> Language Class Initialized
INFO - 2017-07-27 21:09:16 --> Loader Class Initialized
INFO - 2017-07-27 21:09:16 --> Controller Class Initialized
INFO - 2017-07-27 21:09:16 --> Database Driver Class Initialized
INFO - 2017-07-27 21:09:16 --> Model Class Initialized
INFO - 2017-07-27 21:09:16 --> Helper loaded: form_helper
INFO - 2017-07-27 21:09:16 --> Helper loaded: url_helper
INFO - 2017-07-27 21:09:16 --> Model Class Initialized
ERROR - 2017-07-27 21:09:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 21:09:16 --> Config Class Initialized
INFO - 2017-07-27 21:09:16 --> Hooks Class Initialized
DEBUG - 2017-07-27 21:09:16 --> UTF-8 Support Enabled
INFO - 2017-07-27 21:09:16 --> Utf8 Class Initialized
INFO - 2017-07-27 21:09:16 --> URI Class Initialized
INFO - 2017-07-27 21:09:16 --> Router Class Initialized
INFO - 2017-07-27 21:09:16 --> Output Class Initialized
INFO - 2017-07-27 21:09:16 --> Security Class Initialized
DEBUG - 2017-07-27 21:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 21:09:16 --> Input Class Initialized
INFO - 2017-07-27 21:09:16 --> Language Class Initialized
INFO - 2017-07-27 21:09:16 --> Loader Class Initialized
INFO - 2017-07-27 21:09:16 --> Controller Class Initialized
INFO - 2017-07-27 21:09:16 --> Database Driver Class Initialized
INFO - 2017-07-27 21:09:16 --> Model Class Initialized
INFO - 2017-07-27 21:09:16 --> Helper loaded: form_helper
INFO - 2017-07-27 21:09:16 --> Helper loaded: url_helper
INFO - 2017-07-27 21:09:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-27 21:09:16 --> Model Class Initialized
INFO - 2017-07-27 21:09:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-27 21:09:16 --> Final output sent to browser
DEBUG - 2017-07-27 21:09:16 --> Total execution time: 0.0520
ERROR - 2017-07-27 21:09:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-27 21:09:20 --> Config Class Initialized
INFO - 2017-07-27 21:09:20 --> Hooks Class Initialized
DEBUG - 2017-07-27 21:09:20 --> UTF-8 Support Enabled
INFO - 2017-07-27 21:09:20 --> Utf8 Class Initialized
INFO - 2017-07-27 21:09:20 --> URI Class Initialized
INFO - 2017-07-27 21:09:20 --> Router Class Initialized
INFO - 2017-07-27 21:09:20 --> Output Class Initialized
INFO - 2017-07-27 21:09:20 --> Security Class Initialized
DEBUG - 2017-07-27 21:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 21:09:20 --> Input Class Initialized
INFO - 2017-07-27 21:09:20 --> Language Class Initialized
INFO - 2017-07-27 21:09:20 --> Loader Class Initialized
INFO - 2017-07-27 21:09:20 --> Controller Class Initialized
INFO - 2017-07-27 21:09:20 --> Database Driver Class Initialized
INFO - 2017-07-27 21:09:20 --> Model Class Initialized
INFO - 2017-07-27 21:09:20 --> Helper loaded: form_helper
INFO - 2017-07-27 21:09:20 --> Helper loaded: url_helper
INFO - 2017-07-27 21:09:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-27 21:09:20 --> Model Class Initialized
INFO - 2017-07-27 21:09:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\users.php
INFO - 2017-07-27 21:09:20 --> Final output sent to browser
DEBUG - 2017-07-27 21:09:20 --> Total execution time: 0.0450
