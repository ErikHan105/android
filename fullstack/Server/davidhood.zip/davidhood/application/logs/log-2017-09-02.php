<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-02 18:43:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-02 18:43:04 --> Config Class Initialized
INFO - 2017-09-02 18:43:04 --> Hooks Class Initialized
DEBUG - 2017-09-02 18:43:04 --> UTF-8 Support Enabled
INFO - 2017-09-02 18:43:04 --> Utf8 Class Initialized
INFO - 2017-09-02 18:43:04 --> URI Class Initialized
DEBUG - 2017-09-02 18:43:04 --> No URI present. Default controller set.
INFO - 2017-09-02 18:43:04 --> Router Class Initialized
INFO - 2017-09-02 18:43:04 --> Output Class Initialized
INFO - 2017-09-02 18:43:04 --> Security Class Initialized
DEBUG - 2017-09-02 18:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-02 18:43:04 --> Input Class Initialized
INFO - 2017-09-02 18:43:04 --> Language Class Initialized
INFO - 2017-09-02 18:43:04 --> Loader Class Initialized
INFO - 2017-09-02 18:43:04 --> Controller Class Initialized
INFO - 2017-09-02 18:43:04 --> Database Driver Class Initialized
INFO - 2017-09-02 18:43:04 --> Model Class Initialized
INFO - 2017-09-02 18:43:05 --> Helper loaded: form_helper
INFO - 2017-09-02 18:43:05 --> Helper loaded: url_helper
INFO - 2017-09-02 18:43:05 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-09-02 18:43:05 --> Final output sent to browser
DEBUG - 2017-09-02 18:43:05 --> Total execution time: 0.4990
ERROR - 2017-09-02 18:43:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-02 18:43:07 --> Config Class Initialized
INFO - 2017-09-02 18:43:07 --> Hooks Class Initialized
DEBUG - 2017-09-02 18:43:07 --> UTF-8 Support Enabled
INFO - 2017-09-02 18:43:07 --> Utf8 Class Initialized
INFO - 2017-09-02 18:43:07 --> URI Class Initialized
INFO - 2017-09-02 18:43:07 --> Router Class Initialized
INFO - 2017-09-02 18:43:07 --> Output Class Initialized
INFO - 2017-09-02 18:43:07 --> Security Class Initialized
DEBUG - 2017-09-02 18:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-02 18:43:07 --> Input Class Initialized
INFO - 2017-09-02 18:43:07 --> Language Class Initialized
INFO - 2017-09-02 18:43:07 --> Loader Class Initialized
INFO - 2017-09-02 18:43:07 --> Controller Class Initialized
INFO - 2017-09-02 18:43:07 --> Database Driver Class Initialized
INFO - 2017-09-02 18:43:07 --> Model Class Initialized
INFO - 2017-09-02 18:43:07 --> Helper loaded: form_helper
INFO - 2017-09-02 18:43:07 --> Helper loaded: url_helper
INFO - 2017-09-02 18:43:07 --> Model Class Initialized
ERROR - 2017-09-02 18:43:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-02 18:43:07 --> Config Class Initialized
INFO - 2017-09-02 18:43:07 --> Hooks Class Initialized
DEBUG - 2017-09-02 18:43:07 --> UTF-8 Support Enabled
INFO - 2017-09-02 18:43:07 --> Utf8 Class Initialized
INFO - 2017-09-02 18:43:07 --> URI Class Initialized
INFO - 2017-09-02 18:43:07 --> Router Class Initialized
INFO - 2017-09-02 18:43:07 --> Output Class Initialized
INFO - 2017-09-02 18:43:07 --> Security Class Initialized
DEBUG - 2017-09-02 18:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-02 18:43:07 --> Input Class Initialized
INFO - 2017-09-02 18:43:07 --> Language Class Initialized
INFO - 2017-09-02 18:43:07 --> Loader Class Initialized
INFO - 2017-09-02 18:43:07 --> Controller Class Initialized
INFO - 2017-09-02 18:43:07 --> Database Driver Class Initialized
INFO - 2017-09-02 18:43:07 --> Model Class Initialized
INFO - 2017-09-02 18:43:07 --> Helper loaded: form_helper
INFO - 2017-09-02 18:43:07 --> Helper loaded: url_helper
INFO - 2017-09-02 18:43:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-09-02 18:43:07 --> Model Class Initialized
INFO - 2017-09-02 18:43:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-09-02 18:43:07 --> Final output sent to browser
DEBUG - 2017-09-02 18:43:07 --> Total execution time: 0.3180
ERROR - 2017-09-02 18:43:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-02 18:43:09 --> Config Class Initialized
INFO - 2017-09-02 18:43:09 --> Hooks Class Initialized
DEBUG - 2017-09-02 18:43:09 --> UTF-8 Support Enabled
INFO - 2017-09-02 18:43:09 --> Utf8 Class Initialized
INFO - 2017-09-02 18:43:09 --> URI Class Initialized
INFO - 2017-09-02 18:43:09 --> Router Class Initialized
INFO - 2017-09-02 18:43:09 --> Output Class Initialized
INFO - 2017-09-02 18:43:09 --> Security Class Initialized
DEBUG - 2017-09-02 18:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-02 18:43:09 --> Input Class Initialized
INFO - 2017-09-02 18:43:09 --> Language Class Initialized
INFO - 2017-09-02 18:43:09 --> Loader Class Initialized
INFO - 2017-09-02 18:43:09 --> Controller Class Initialized
INFO - 2017-09-02 18:43:09 --> Database Driver Class Initialized
INFO - 2017-09-02 18:43:09 --> Model Class Initialized
INFO - 2017-09-02 18:43:09 --> Helper loaded: form_helper
INFO - 2017-09-02 18:43:09 --> Helper loaded: url_helper
INFO - 2017-09-02 18:43:09 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-09-02 18:43:09 --> Model Class Initialized
INFO - 2017-09-02 18:43:09 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-09-02 18:43:09 --> Final output sent to browser
DEBUG - 2017-09-02 18:43:09 --> Total execution time: 0.1460
ERROR - 2017-09-02 18:43:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-02 18:43:22 --> Config Class Initialized
INFO - 2017-09-02 18:43:22 --> Hooks Class Initialized
DEBUG - 2017-09-02 18:43:22 --> UTF-8 Support Enabled
INFO - 2017-09-02 18:43:22 --> Utf8 Class Initialized
INFO - 2017-09-02 18:43:22 --> URI Class Initialized
INFO - 2017-09-02 18:43:22 --> Router Class Initialized
INFO - 2017-09-02 18:43:22 --> Output Class Initialized
INFO - 2017-09-02 18:43:22 --> Security Class Initialized
DEBUG - 2017-09-02 18:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-02 18:43:22 --> Input Class Initialized
INFO - 2017-09-02 18:43:22 --> Language Class Initialized
INFO - 2017-09-02 18:43:22 --> Loader Class Initialized
INFO - 2017-09-02 18:43:22 --> Controller Class Initialized
INFO - 2017-09-02 18:43:22 --> Database Driver Class Initialized
INFO - 2017-09-02 18:43:22 --> Model Class Initialized
INFO - 2017-09-02 18:43:22 --> Helper loaded: form_helper
INFO - 2017-09-02 18:43:22 --> Helper loaded: url_helper
INFO - 2017-09-02 18:43:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-09-02 18:43:22 --> Model Class Initialized
INFO - 2017-09-02 18:43:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-09-02 18:43:22 --> Final output sent to browser
DEBUG - 2017-09-02 18:43:22 --> Total execution time: 0.2320
