<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-04 03:53:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 03:53:51 --> Config Class Initialized
INFO - 2017-07-04 03:53:51 --> Hooks Class Initialized
DEBUG - 2017-07-04 03:53:51 --> UTF-8 Support Enabled
INFO - 2017-07-04 03:53:51 --> Utf8 Class Initialized
INFO - 2017-07-04 03:53:52 --> URI Class Initialized
INFO - 2017-07-04 03:53:52 --> Router Class Initialized
INFO - 2017-07-04 03:53:52 --> Output Class Initialized
INFO - 2017-07-04 03:53:52 --> Security Class Initialized
DEBUG - 2017-07-04 03:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 03:53:52 --> Input Class Initialized
INFO - 2017-07-04 03:53:52 --> Language Class Initialized
INFO - 2017-07-04 03:53:52 --> Loader Class Initialized
INFO - 2017-07-04 03:53:52 --> Controller Class Initialized
INFO - 2017-07-04 03:53:52 --> Database Driver Class Initialized
INFO - 2017-07-04 03:53:52 --> Model Class Initialized
INFO - 2017-07-04 03:53:52 --> Helper loaded: form_helper
INFO - 2017-07-04 03:53:52 --> Helper loaded: url_helper
INFO - 2017-07-04 03:53:52 --> Model Class Initialized
INFO - 2017-07-04 03:53:52 --> Final output sent to browser
DEBUG - 2017-07-04 03:53:52 --> Total execution time: 0.1580
ERROR - 2017-07-04 03:54:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 03:54:18 --> Config Class Initialized
INFO - 2017-07-04 03:54:18 --> Hooks Class Initialized
DEBUG - 2017-07-04 03:54:18 --> UTF-8 Support Enabled
INFO - 2017-07-04 03:54:18 --> Utf8 Class Initialized
INFO - 2017-07-04 03:54:18 --> URI Class Initialized
INFO - 2017-07-04 03:54:18 --> Router Class Initialized
INFO - 2017-07-04 03:54:18 --> Output Class Initialized
INFO - 2017-07-04 03:54:18 --> Security Class Initialized
DEBUG - 2017-07-04 03:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 03:54:18 --> Input Class Initialized
INFO - 2017-07-04 03:54:18 --> Language Class Initialized
INFO - 2017-07-04 03:54:18 --> Loader Class Initialized
INFO - 2017-07-04 03:54:18 --> Controller Class Initialized
INFO - 2017-07-04 03:54:18 --> Database Driver Class Initialized
INFO - 2017-07-04 03:54:18 --> Model Class Initialized
INFO - 2017-07-04 03:54:18 --> Helper loaded: form_helper
INFO - 2017-07-04 03:54:18 --> Helper loaded: url_helper
INFO - 2017-07-04 03:54:18 --> Model Class Initialized
INFO - 2017-07-04 03:54:18 --> Final output sent to browser
DEBUG - 2017-07-04 03:54:18 --> Total execution time: 0.0590
ERROR - 2017-07-04 04:45:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 04:45:44 --> Config Class Initialized
INFO - 2017-07-04 04:45:44 --> Hooks Class Initialized
DEBUG - 2017-07-04 04:45:44 --> UTF-8 Support Enabled
INFO - 2017-07-04 04:45:44 --> Utf8 Class Initialized
INFO - 2017-07-04 04:45:44 --> URI Class Initialized
INFO - 2017-07-04 04:45:44 --> Router Class Initialized
INFO - 2017-07-04 04:45:44 --> Output Class Initialized
INFO - 2017-07-04 04:45:44 --> Security Class Initialized
DEBUG - 2017-07-04 04:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 04:45:44 --> Input Class Initialized
INFO - 2017-07-04 04:45:44 --> Language Class Initialized
INFO - 2017-07-04 04:45:44 --> Loader Class Initialized
INFO - 2017-07-04 04:45:44 --> Controller Class Initialized
INFO - 2017-07-04 04:45:44 --> Database Driver Class Initialized
INFO - 2017-07-04 04:45:44 --> Model Class Initialized
INFO - 2017-07-04 04:45:44 --> Helper loaded: form_helper
INFO - 2017-07-04 04:45:44 --> Helper loaded: url_helper
INFO - 2017-07-04 04:45:44 --> Model Class Initialized
INFO - 2017-07-04 04:45:45 --> Final output sent to browser
DEBUG - 2017-07-04 04:45:45 --> Total execution time: 0.2790
ERROR - 2017-07-04 04:45:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 04:45:45 --> Config Class Initialized
INFO - 2017-07-04 04:45:45 --> Hooks Class Initialized
DEBUG - 2017-07-04 04:45:45 --> UTF-8 Support Enabled
INFO - 2017-07-04 04:45:45 --> Utf8 Class Initialized
INFO - 2017-07-04 04:45:45 --> URI Class Initialized
INFO - 2017-07-04 04:45:45 --> Router Class Initialized
INFO - 2017-07-04 04:45:45 --> Output Class Initialized
INFO - 2017-07-04 04:45:45 --> Security Class Initialized
DEBUG - 2017-07-04 04:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 04:45:45 --> Input Class Initialized
INFO - 2017-07-04 04:45:45 --> Language Class Initialized
INFO - 2017-07-04 04:45:45 --> Loader Class Initialized
INFO - 2017-07-04 04:45:45 --> Controller Class Initialized
INFO - 2017-07-04 04:45:46 --> Database Driver Class Initialized
INFO - 2017-07-04 04:45:46 --> Model Class Initialized
INFO - 2017-07-04 04:45:46 --> Helper loaded: form_helper
INFO - 2017-07-04 04:45:46 --> Helper loaded: url_helper
INFO - 2017-07-04 04:45:46 --> Model Class Initialized
INFO - 2017-07-04 04:45:46 --> Final output sent to browser
DEBUG - 2017-07-04 04:45:46 --> Total execution time: 0.0470
ERROR - 2017-07-04 04:45:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 04:45:58 --> Config Class Initialized
INFO - 2017-07-04 04:45:58 --> Hooks Class Initialized
DEBUG - 2017-07-04 04:45:58 --> UTF-8 Support Enabled
INFO - 2017-07-04 04:45:58 --> Utf8 Class Initialized
INFO - 2017-07-04 04:45:58 --> URI Class Initialized
INFO - 2017-07-04 04:45:58 --> Router Class Initialized
INFO - 2017-07-04 04:45:58 --> Output Class Initialized
INFO - 2017-07-04 04:45:58 --> Security Class Initialized
DEBUG - 2017-07-04 04:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 04:45:58 --> Input Class Initialized
INFO - 2017-07-04 04:45:58 --> Language Class Initialized
INFO - 2017-07-04 04:45:58 --> Loader Class Initialized
INFO - 2017-07-04 04:45:58 --> Controller Class Initialized
INFO - 2017-07-04 04:45:58 --> Database Driver Class Initialized
INFO - 2017-07-04 04:45:58 --> Model Class Initialized
INFO - 2017-07-04 04:45:58 --> Helper loaded: form_helper
INFO - 2017-07-04 04:45:58 --> Helper loaded: url_helper
INFO - 2017-07-04 04:45:58 --> Model Class Initialized
INFO - 2017-07-04 04:45:58 --> Final output sent to browser
DEBUG - 2017-07-04 04:45:58 --> Total execution time: 0.0650
ERROR - 2017-07-04 04:46:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 04:46:08 --> Config Class Initialized
INFO - 2017-07-04 04:46:08 --> Hooks Class Initialized
DEBUG - 2017-07-04 04:46:08 --> UTF-8 Support Enabled
INFO - 2017-07-04 04:46:08 --> Utf8 Class Initialized
INFO - 2017-07-04 04:46:08 --> URI Class Initialized
INFO - 2017-07-04 04:46:08 --> Router Class Initialized
INFO - 2017-07-04 04:46:08 --> Output Class Initialized
INFO - 2017-07-04 04:46:08 --> Security Class Initialized
DEBUG - 2017-07-04 04:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 04:46:08 --> Input Class Initialized
INFO - 2017-07-04 04:46:08 --> Language Class Initialized
INFO - 2017-07-04 04:46:08 --> Loader Class Initialized
INFO - 2017-07-04 04:46:08 --> Controller Class Initialized
INFO - 2017-07-04 04:46:08 --> Database Driver Class Initialized
INFO - 2017-07-04 04:46:08 --> Model Class Initialized
INFO - 2017-07-04 04:46:08 --> Helper loaded: form_helper
INFO - 2017-07-04 04:46:08 --> Helper loaded: url_helper
INFO - 2017-07-04 04:46:08 --> Model Class Initialized
INFO - 2017-07-04 04:46:08 --> Final output sent to browser
DEBUG - 2017-07-04 04:46:08 --> Total execution time: 0.0470
ERROR - 2017-07-04 04:46:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 04:46:17 --> Config Class Initialized
INFO - 2017-07-04 04:46:17 --> Hooks Class Initialized
DEBUG - 2017-07-04 04:46:17 --> UTF-8 Support Enabled
INFO - 2017-07-04 04:46:17 --> Utf8 Class Initialized
INFO - 2017-07-04 04:46:17 --> URI Class Initialized
INFO - 2017-07-04 04:46:17 --> Router Class Initialized
INFO - 2017-07-04 04:46:17 --> Output Class Initialized
INFO - 2017-07-04 04:46:17 --> Security Class Initialized
DEBUG - 2017-07-04 04:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 04:46:17 --> Input Class Initialized
INFO - 2017-07-04 04:46:17 --> Language Class Initialized
INFO - 2017-07-04 04:46:17 --> Loader Class Initialized
INFO - 2017-07-04 04:46:17 --> Controller Class Initialized
INFO - 2017-07-04 04:46:17 --> Database Driver Class Initialized
INFO - 2017-07-04 04:46:17 --> Model Class Initialized
INFO - 2017-07-04 04:46:17 --> Helper loaded: form_helper
INFO - 2017-07-04 04:46:17 --> Helper loaded: url_helper
INFO - 2017-07-04 04:46:17 --> Model Class Initialized
INFO - 2017-07-04 04:46:17 --> Final output sent to browser
DEBUG - 2017-07-04 04:46:17 --> Total execution time: 0.0530
ERROR - 2017-07-04 04:47:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 04:47:10 --> Config Class Initialized
INFO - 2017-07-04 04:47:10 --> Hooks Class Initialized
DEBUG - 2017-07-04 04:47:10 --> UTF-8 Support Enabled
INFO - 2017-07-04 04:47:10 --> Utf8 Class Initialized
INFO - 2017-07-04 04:47:10 --> URI Class Initialized
INFO - 2017-07-04 04:47:10 --> Router Class Initialized
INFO - 2017-07-04 04:47:10 --> Output Class Initialized
INFO - 2017-07-04 04:47:10 --> Security Class Initialized
DEBUG - 2017-07-04 04:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 04:47:10 --> Input Class Initialized
INFO - 2017-07-04 04:47:10 --> Language Class Initialized
INFO - 2017-07-04 04:47:10 --> Loader Class Initialized
INFO - 2017-07-04 04:47:10 --> Controller Class Initialized
INFO - 2017-07-04 04:47:10 --> Database Driver Class Initialized
INFO - 2017-07-04 04:47:10 --> Model Class Initialized
INFO - 2017-07-04 04:47:10 --> Helper loaded: form_helper
INFO - 2017-07-04 04:47:10 --> Helper loaded: url_helper
INFO - 2017-07-04 04:47:10 --> Model Class Initialized
INFO - 2017-07-04 04:47:10 --> Final output sent to browser
DEBUG - 2017-07-04 04:47:10 --> Total execution time: 0.0410
ERROR - 2017-07-04 04:47:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 04:47:33 --> Config Class Initialized
INFO - 2017-07-04 04:47:33 --> Hooks Class Initialized
DEBUG - 2017-07-04 04:47:33 --> UTF-8 Support Enabled
INFO - 2017-07-04 04:47:33 --> Utf8 Class Initialized
INFO - 2017-07-04 04:47:33 --> URI Class Initialized
INFO - 2017-07-04 04:47:33 --> Router Class Initialized
INFO - 2017-07-04 04:47:33 --> Output Class Initialized
INFO - 2017-07-04 04:47:33 --> Security Class Initialized
DEBUG - 2017-07-04 04:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 04:47:33 --> Input Class Initialized
INFO - 2017-07-04 04:47:33 --> Language Class Initialized
INFO - 2017-07-04 04:47:33 --> Loader Class Initialized
INFO - 2017-07-04 04:47:33 --> Controller Class Initialized
INFO - 2017-07-04 04:47:33 --> Database Driver Class Initialized
INFO - 2017-07-04 04:47:33 --> Model Class Initialized
INFO - 2017-07-04 04:47:33 --> Helper loaded: form_helper
INFO - 2017-07-04 04:47:33 --> Helper loaded: url_helper
INFO - 2017-07-04 04:47:33 --> Model Class Initialized
INFO - 2017-07-04 04:47:33 --> Final output sent to browser
DEBUG - 2017-07-04 04:47:33 --> Total execution time: 0.0430
ERROR - 2017-07-04 04:47:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 04:47:43 --> Config Class Initialized
INFO - 2017-07-04 04:47:43 --> Hooks Class Initialized
DEBUG - 2017-07-04 04:47:43 --> UTF-8 Support Enabled
INFO - 2017-07-04 04:47:43 --> Utf8 Class Initialized
INFO - 2017-07-04 04:47:43 --> URI Class Initialized
INFO - 2017-07-04 04:47:43 --> Router Class Initialized
INFO - 2017-07-04 04:47:43 --> Output Class Initialized
INFO - 2017-07-04 04:47:43 --> Security Class Initialized
DEBUG - 2017-07-04 04:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 04:47:43 --> Input Class Initialized
INFO - 2017-07-04 04:47:43 --> Language Class Initialized
INFO - 2017-07-04 04:47:43 --> Loader Class Initialized
INFO - 2017-07-04 04:47:43 --> Controller Class Initialized
INFO - 2017-07-04 04:47:43 --> Database Driver Class Initialized
INFO - 2017-07-04 04:47:43 --> Model Class Initialized
INFO - 2017-07-04 04:47:43 --> Helper loaded: form_helper
INFO - 2017-07-04 04:47:43 --> Helper loaded: url_helper
INFO - 2017-07-04 04:47:43 --> Model Class Initialized
INFO - 2017-07-04 04:47:43 --> Final output sent to browser
DEBUG - 2017-07-04 04:47:43 --> Total execution time: 0.0580
ERROR - 2017-07-04 04:47:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 04:47:53 --> Config Class Initialized
INFO - 2017-07-04 04:47:53 --> Hooks Class Initialized
DEBUG - 2017-07-04 04:47:53 --> UTF-8 Support Enabled
INFO - 2017-07-04 04:47:53 --> Utf8 Class Initialized
INFO - 2017-07-04 04:47:53 --> URI Class Initialized
INFO - 2017-07-04 04:47:53 --> Router Class Initialized
INFO - 2017-07-04 04:47:53 --> Output Class Initialized
INFO - 2017-07-04 04:47:53 --> Security Class Initialized
DEBUG - 2017-07-04 04:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 04:47:53 --> Input Class Initialized
INFO - 2017-07-04 04:47:53 --> Language Class Initialized
INFO - 2017-07-04 04:47:53 --> Loader Class Initialized
INFO - 2017-07-04 04:47:53 --> Controller Class Initialized
INFO - 2017-07-04 04:47:53 --> Database Driver Class Initialized
INFO - 2017-07-04 04:47:53 --> Model Class Initialized
INFO - 2017-07-04 04:47:53 --> Helper loaded: form_helper
INFO - 2017-07-04 04:47:53 --> Helper loaded: url_helper
INFO - 2017-07-04 04:47:53 --> Model Class Initialized
INFO - 2017-07-04 04:47:53 --> Final output sent to browser
DEBUG - 2017-07-04 04:47:53 --> Total execution time: 0.0470
ERROR - 2017-07-04 04:49:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 04:49:22 --> Config Class Initialized
INFO - 2017-07-04 04:49:22 --> Hooks Class Initialized
DEBUG - 2017-07-04 04:49:22 --> UTF-8 Support Enabled
INFO - 2017-07-04 04:49:22 --> Utf8 Class Initialized
INFO - 2017-07-04 04:49:22 --> URI Class Initialized
INFO - 2017-07-04 04:49:22 --> Router Class Initialized
INFO - 2017-07-04 04:49:22 --> Output Class Initialized
INFO - 2017-07-04 04:49:22 --> Security Class Initialized
DEBUG - 2017-07-04 04:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 04:49:22 --> Input Class Initialized
INFO - 2017-07-04 04:49:22 --> Language Class Initialized
INFO - 2017-07-04 04:49:22 --> Loader Class Initialized
INFO - 2017-07-04 04:49:22 --> Controller Class Initialized
INFO - 2017-07-04 04:49:22 --> Database Driver Class Initialized
INFO - 2017-07-04 04:49:22 --> Model Class Initialized
INFO - 2017-07-04 04:49:22 --> Helper loaded: form_helper
INFO - 2017-07-04 04:49:22 --> Helper loaded: url_helper
INFO - 2017-07-04 04:49:22 --> Model Class Initialized
INFO - 2017-07-04 04:49:22 --> Final output sent to browser
DEBUG - 2017-07-04 04:49:22 --> Total execution time: 0.0510
ERROR - 2017-07-04 05:07:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:07:18 --> Config Class Initialized
INFO - 2017-07-04 05:07:18 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:07:18 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:07:18 --> Utf8 Class Initialized
INFO - 2017-07-04 05:07:18 --> URI Class Initialized
INFO - 2017-07-04 05:07:18 --> Router Class Initialized
INFO - 2017-07-04 05:07:18 --> Output Class Initialized
INFO - 2017-07-04 05:07:18 --> Security Class Initialized
DEBUG - 2017-07-04 05:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:07:18 --> Input Class Initialized
INFO - 2017-07-04 05:07:18 --> Language Class Initialized
INFO - 2017-07-04 05:07:18 --> Loader Class Initialized
INFO - 2017-07-04 05:07:18 --> Controller Class Initialized
INFO - 2017-07-04 05:07:18 --> Database Driver Class Initialized
INFO - 2017-07-04 05:07:18 --> Model Class Initialized
INFO - 2017-07-04 05:07:18 --> Helper loaded: form_helper
INFO - 2017-07-04 05:07:18 --> Helper loaded: url_helper
INFO - 2017-07-04 05:07:18 --> Model Class Initialized
INFO - 2017-07-04 05:07:18 --> Final output sent to browser
DEBUG - 2017-07-04 05:07:18 --> Total execution time: 0.0600
ERROR - 2017-07-04 05:07:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:07:19 --> Config Class Initialized
INFO - 2017-07-04 05:07:19 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:07:19 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:07:19 --> Utf8 Class Initialized
INFO - 2017-07-04 05:07:19 --> URI Class Initialized
INFO - 2017-07-04 05:07:19 --> Router Class Initialized
INFO - 2017-07-04 05:07:19 --> Output Class Initialized
INFO - 2017-07-04 05:07:19 --> Security Class Initialized
DEBUG - 2017-07-04 05:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:07:19 --> Input Class Initialized
INFO - 2017-07-04 05:07:19 --> Language Class Initialized
INFO - 2017-07-04 05:07:19 --> Loader Class Initialized
INFO - 2017-07-04 05:07:19 --> Controller Class Initialized
INFO - 2017-07-04 05:07:19 --> Database Driver Class Initialized
INFO - 2017-07-04 05:07:19 --> Model Class Initialized
INFO - 2017-07-04 05:07:19 --> Helper loaded: form_helper
INFO - 2017-07-04 05:07:19 --> Helper loaded: url_helper
INFO - 2017-07-04 05:07:19 --> Model Class Initialized
INFO - 2017-07-04 05:07:19 --> Final output sent to browser
DEBUG - 2017-07-04 05:07:19 --> Total execution time: 0.0420
ERROR - 2017-07-04 05:07:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:07:27 --> Config Class Initialized
INFO - 2017-07-04 05:07:27 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:07:27 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:07:27 --> Utf8 Class Initialized
INFO - 2017-07-04 05:07:27 --> URI Class Initialized
INFO - 2017-07-04 05:07:27 --> Router Class Initialized
INFO - 2017-07-04 05:07:27 --> Output Class Initialized
INFO - 2017-07-04 05:07:27 --> Security Class Initialized
DEBUG - 2017-07-04 05:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:07:27 --> Input Class Initialized
INFO - 2017-07-04 05:07:27 --> Language Class Initialized
INFO - 2017-07-04 05:07:27 --> Loader Class Initialized
INFO - 2017-07-04 05:07:27 --> Controller Class Initialized
INFO - 2017-07-04 05:07:27 --> Database Driver Class Initialized
INFO - 2017-07-04 05:07:27 --> Model Class Initialized
INFO - 2017-07-04 05:07:27 --> Helper loaded: form_helper
INFO - 2017-07-04 05:07:27 --> Helper loaded: url_helper
INFO - 2017-07-04 05:07:27 --> Model Class Initialized
INFO - 2017-07-04 05:07:27 --> Final output sent to browser
DEBUG - 2017-07-04 05:07:27 --> Total execution time: 0.0500
ERROR - 2017-07-04 05:09:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:09:50 --> Config Class Initialized
INFO - 2017-07-04 05:09:50 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:09:50 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:09:50 --> Utf8 Class Initialized
INFO - 2017-07-04 05:09:50 --> URI Class Initialized
INFO - 2017-07-04 05:09:50 --> Router Class Initialized
INFO - 2017-07-04 05:09:50 --> Output Class Initialized
INFO - 2017-07-04 05:09:50 --> Security Class Initialized
DEBUG - 2017-07-04 05:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:09:50 --> Input Class Initialized
INFO - 2017-07-04 05:09:50 --> Language Class Initialized
INFO - 2017-07-04 05:09:50 --> Loader Class Initialized
INFO - 2017-07-04 05:09:50 --> Controller Class Initialized
INFO - 2017-07-04 05:09:50 --> Database Driver Class Initialized
INFO - 2017-07-04 05:09:50 --> Model Class Initialized
INFO - 2017-07-04 05:09:50 --> Helper loaded: form_helper
INFO - 2017-07-04 05:09:50 --> Helper loaded: url_helper
INFO - 2017-07-04 05:09:50 --> Model Class Initialized
INFO - 2017-07-04 05:09:50 --> Final output sent to browser
DEBUG - 2017-07-04 05:09:50 --> Total execution time: 0.0580
ERROR - 2017-07-04 05:09:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:09:51 --> Config Class Initialized
INFO - 2017-07-04 05:09:51 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:09:51 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:09:51 --> Utf8 Class Initialized
INFO - 2017-07-04 05:09:51 --> URI Class Initialized
INFO - 2017-07-04 05:09:51 --> Router Class Initialized
INFO - 2017-07-04 05:09:51 --> Output Class Initialized
INFO - 2017-07-04 05:09:51 --> Security Class Initialized
DEBUG - 2017-07-04 05:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:09:51 --> Input Class Initialized
INFO - 2017-07-04 05:09:51 --> Language Class Initialized
INFO - 2017-07-04 05:09:51 --> Loader Class Initialized
INFO - 2017-07-04 05:09:51 --> Controller Class Initialized
INFO - 2017-07-04 05:09:51 --> Database Driver Class Initialized
INFO - 2017-07-04 05:09:51 --> Model Class Initialized
INFO - 2017-07-04 05:09:51 --> Helper loaded: form_helper
INFO - 2017-07-04 05:09:51 --> Helper loaded: url_helper
INFO - 2017-07-04 05:09:51 --> Model Class Initialized
INFO - 2017-07-04 05:09:51 --> Final output sent to browser
DEBUG - 2017-07-04 05:09:51 --> Total execution time: 0.0460
ERROR - 2017-07-04 05:10:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:10:29 --> Config Class Initialized
INFO - 2017-07-04 05:10:29 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:10:29 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:10:29 --> Utf8 Class Initialized
INFO - 2017-07-04 05:10:29 --> URI Class Initialized
INFO - 2017-07-04 05:10:29 --> Router Class Initialized
INFO - 2017-07-04 05:10:29 --> Output Class Initialized
INFO - 2017-07-04 05:10:29 --> Security Class Initialized
DEBUG - 2017-07-04 05:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:10:29 --> Input Class Initialized
INFO - 2017-07-04 05:10:29 --> Language Class Initialized
INFO - 2017-07-04 05:10:29 --> Loader Class Initialized
INFO - 2017-07-04 05:10:29 --> Controller Class Initialized
INFO - 2017-07-04 05:10:29 --> Database Driver Class Initialized
INFO - 2017-07-04 05:10:29 --> Model Class Initialized
INFO - 2017-07-04 05:10:29 --> Helper loaded: form_helper
INFO - 2017-07-04 05:10:29 --> Helper loaded: url_helper
INFO - 2017-07-04 05:10:29 --> Model Class Initialized
INFO - 2017-07-04 05:10:29 --> Final output sent to browser
DEBUG - 2017-07-04 05:10:29 --> Total execution time: 0.0520
ERROR - 2017-07-04 05:10:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:10:30 --> Config Class Initialized
INFO - 2017-07-04 05:10:30 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:10:30 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:10:30 --> Utf8 Class Initialized
INFO - 2017-07-04 05:10:30 --> URI Class Initialized
INFO - 2017-07-04 05:10:30 --> Router Class Initialized
INFO - 2017-07-04 05:10:30 --> Output Class Initialized
INFO - 2017-07-04 05:10:30 --> Security Class Initialized
DEBUG - 2017-07-04 05:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:10:30 --> Input Class Initialized
INFO - 2017-07-04 05:10:30 --> Language Class Initialized
INFO - 2017-07-04 05:10:30 --> Loader Class Initialized
INFO - 2017-07-04 05:10:30 --> Controller Class Initialized
INFO - 2017-07-04 05:10:30 --> Database Driver Class Initialized
INFO - 2017-07-04 05:10:30 --> Model Class Initialized
INFO - 2017-07-04 05:10:30 --> Helper loaded: form_helper
INFO - 2017-07-04 05:10:30 --> Helper loaded: url_helper
INFO - 2017-07-04 05:10:30 --> Model Class Initialized
INFO - 2017-07-04 05:10:30 --> Final output sent to browser
DEBUG - 2017-07-04 05:10:30 --> Total execution time: 0.0440
ERROR - 2017-07-04 05:10:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:10:40 --> Config Class Initialized
INFO - 2017-07-04 05:10:40 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:10:40 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:10:40 --> Utf8 Class Initialized
INFO - 2017-07-04 05:10:40 --> URI Class Initialized
INFO - 2017-07-04 05:10:40 --> Router Class Initialized
INFO - 2017-07-04 05:10:40 --> Output Class Initialized
INFO - 2017-07-04 05:10:40 --> Security Class Initialized
DEBUG - 2017-07-04 05:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:10:40 --> Input Class Initialized
INFO - 2017-07-04 05:10:40 --> Language Class Initialized
INFO - 2017-07-04 05:10:40 --> Loader Class Initialized
INFO - 2017-07-04 05:10:40 --> Controller Class Initialized
INFO - 2017-07-04 05:10:40 --> Database Driver Class Initialized
INFO - 2017-07-04 05:10:40 --> Model Class Initialized
INFO - 2017-07-04 05:10:40 --> Helper loaded: form_helper
INFO - 2017-07-04 05:10:40 --> Helper loaded: url_helper
INFO - 2017-07-04 05:10:40 --> Model Class Initialized
INFO - 2017-07-04 05:10:40 --> Final output sent to browser
DEBUG - 2017-07-04 05:10:40 --> Total execution time: 0.0600
ERROR - 2017-07-04 05:12:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:12:23 --> Config Class Initialized
INFO - 2017-07-04 05:12:23 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:12:23 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:12:23 --> Utf8 Class Initialized
INFO - 2017-07-04 05:12:23 --> URI Class Initialized
INFO - 2017-07-04 05:12:23 --> Router Class Initialized
INFO - 2017-07-04 05:12:23 --> Output Class Initialized
INFO - 2017-07-04 05:12:23 --> Security Class Initialized
DEBUG - 2017-07-04 05:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:12:23 --> Input Class Initialized
INFO - 2017-07-04 05:12:23 --> Language Class Initialized
INFO - 2017-07-04 05:12:23 --> Loader Class Initialized
INFO - 2017-07-04 05:12:23 --> Controller Class Initialized
INFO - 2017-07-04 05:12:23 --> Database Driver Class Initialized
INFO - 2017-07-04 05:12:23 --> Model Class Initialized
INFO - 2017-07-04 05:12:23 --> Helper loaded: form_helper
INFO - 2017-07-04 05:12:23 --> Helper loaded: url_helper
INFO - 2017-07-04 05:12:23 --> Model Class Initialized
INFO - 2017-07-04 05:12:23 --> Final output sent to browser
DEBUG - 2017-07-04 05:12:23 --> Total execution time: 0.0500
ERROR - 2017-07-04 05:12:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:12:24 --> Config Class Initialized
INFO - 2017-07-04 05:12:24 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:12:24 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:12:24 --> Utf8 Class Initialized
INFO - 2017-07-04 05:12:24 --> URI Class Initialized
INFO - 2017-07-04 05:12:24 --> Router Class Initialized
INFO - 2017-07-04 05:12:24 --> Output Class Initialized
INFO - 2017-07-04 05:12:24 --> Security Class Initialized
DEBUG - 2017-07-04 05:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:12:24 --> Input Class Initialized
INFO - 2017-07-04 05:12:24 --> Language Class Initialized
INFO - 2017-07-04 05:12:24 --> Loader Class Initialized
INFO - 2017-07-04 05:12:24 --> Controller Class Initialized
INFO - 2017-07-04 05:12:24 --> Database Driver Class Initialized
INFO - 2017-07-04 05:12:24 --> Model Class Initialized
INFO - 2017-07-04 05:12:24 --> Helper loaded: form_helper
INFO - 2017-07-04 05:12:24 --> Helper loaded: url_helper
INFO - 2017-07-04 05:12:24 --> Model Class Initialized
INFO - 2017-07-04 05:12:24 --> Final output sent to browser
DEBUG - 2017-07-04 05:12:24 --> Total execution time: 0.0460
ERROR - 2017-07-04 05:12:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:12:31 --> Config Class Initialized
INFO - 2017-07-04 05:12:31 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:12:31 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:12:31 --> Utf8 Class Initialized
INFO - 2017-07-04 05:12:31 --> URI Class Initialized
INFO - 2017-07-04 05:12:31 --> Router Class Initialized
INFO - 2017-07-04 05:12:31 --> Output Class Initialized
INFO - 2017-07-04 05:12:31 --> Security Class Initialized
DEBUG - 2017-07-04 05:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:12:31 --> Input Class Initialized
INFO - 2017-07-04 05:12:31 --> Language Class Initialized
INFO - 2017-07-04 05:12:31 --> Loader Class Initialized
INFO - 2017-07-04 05:12:31 --> Controller Class Initialized
INFO - 2017-07-04 05:12:31 --> Database Driver Class Initialized
INFO - 2017-07-04 05:12:31 --> Model Class Initialized
INFO - 2017-07-04 05:12:31 --> Helper loaded: form_helper
INFO - 2017-07-04 05:12:31 --> Helper loaded: url_helper
INFO - 2017-07-04 05:12:31 --> Model Class Initialized
INFO - 2017-07-04 05:12:31 --> Final output sent to browser
DEBUG - 2017-07-04 05:12:31 --> Total execution time: 0.0460
ERROR - 2017-07-04 05:12:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:12:56 --> Config Class Initialized
INFO - 2017-07-04 05:12:56 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:12:56 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:12:56 --> Utf8 Class Initialized
INFO - 2017-07-04 05:12:56 --> URI Class Initialized
INFO - 2017-07-04 05:12:56 --> Router Class Initialized
INFO - 2017-07-04 05:12:56 --> Output Class Initialized
INFO - 2017-07-04 05:12:56 --> Security Class Initialized
DEBUG - 2017-07-04 05:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:12:56 --> Input Class Initialized
INFO - 2017-07-04 05:12:56 --> Language Class Initialized
INFO - 2017-07-04 05:12:56 --> Loader Class Initialized
INFO - 2017-07-04 05:12:56 --> Controller Class Initialized
INFO - 2017-07-04 05:12:56 --> Database Driver Class Initialized
INFO - 2017-07-04 05:12:56 --> Model Class Initialized
INFO - 2017-07-04 05:12:56 --> Helper loaded: form_helper
INFO - 2017-07-04 05:12:56 --> Helper loaded: url_helper
INFO - 2017-07-04 05:12:56 --> Final output sent to browser
DEBUG - 2017-07-04 05:12:56 --> Total execution time: 0.0410
ERROR - 2017-07-04 05:13:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:13:25 --> Config Class Initialized
INFO - 2017-07-04 05:13:25 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:13:25 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:13:25 --> Utf8 Class Initialized
INFO - 2017-07-04 05:13:25 --> URI Class Initialized
INFO - 2017-07-04 05:13:25 --> Router Class Initialized
INFO - 2017-07-04 05:13:25 --> Output Class Initialized
INFO - 2017-07-04 05:13:25 --> Security Class Initialized
DEBUG - 2017-07-04 05:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:13:25 --> Input Class Initialized
INFO - 2017-07-04 05:13:25 --> Language Class Initialized
INFO - 2017-07-04 05:13:25 --> Loader Class Initialized
INFO - 2017-07-04 05:13:25 --> Controller Class Initialized
INFO - 2017-07-04 05:13:25 --> Database Driver Class Initialized
INFO - 2017-07-04 05:13:25 --> Model Class Initialized
INFO - 2017-07-04 05:13:25 --> Helper loaded: form_helper
INFO - 2017-07-04 05:13:25 --> Helper loaded: url_helper
INFO - 2017-07-04 05:13:25 --> Model Class Initialized
INFO - 2017-07-04 05:13:25 --> Final output sent to browser
DEBUG - 2017-07-04 05:13:25 --> Total execution time: 0.0490
ERROR - 2017-07-04 05:13:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:13:26 --> Config Class Initialized
INFO - 2017-07-04 05:13:26 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:13:26 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:13:26 --> Utf8 Class Initialized
INFO - 2017-07-04 05:13:26 --> URI Class Initialized
INFO - 2017-07-04 05:13:26 --> Router Class Initialized
INFO - 2017-07-04 05:13:26 --> Output Class Initialized
INFO - 2017-07-04 05:13:26 --> Security Class Initialized
DEBUG - 2017-07-04 05:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:13:26 --> Input Class Initialized
INFO - 2017-07-04 05:13:26 --> Language Class Initialized
INFO - 2017-07-04 05:13:26 --> Loader Class Initialized
INFO - 2017-07-04 05:13:26 --> Controller Class Initialized
INFO - 2017-07-04 05:13:26 --> Database Driver Class Initialized
INFO - 2017-07-04 05:13:26 --> Model Class Initialized
INFO - 2017-07-04 05:13:26 --> Helper loaded: form_helper
INFO - 2017-07-04 05:13:26 --> Helper loaded: url_helper
INFO - 2017-07-04 05:13:26 --> Model Class Initialized
INFO - 2017-07-04 05:13:26 --> Final output sent to browser
DEBUG - 2017-07-04 05:13:26 --> Total execution time: 0.0470
ERROR - 2017-07-04 05:13:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:13:30 --> Config Class Initialized
INFO - 2017-07-04 05:13:30 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:13:30 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:13:30 --> Utf8 Class Initialized
INFO - 2017-07-04 05:13:30 --> URI Class Initialized
INFO - 2017-07-04 05:13:30 --> Router Class Initialized
INFO - 2017-07-04 05:13:30 --> Output Class Initialized
INFO - 2017-07-04 05:13:30 --> Security Class Initialized
DEBUG - 2017-07-04 05:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:13:30 --> Input Class Initialized
INFO - 2017-07-04 05:13:30 --> Language Class Initialized
INFO - 2017-07-04 05:13:30 --> Loader Class Initialized
INFO - 2017-07-04 05:13:30 --> Controller Class Initialized
INFO - 2017-07-04 05:13:30 --> Database Driver Class Initialized
INFO - 2017-07-04 05:13:30 --> Model Class Initialized
INFO - 2017-07-04 05:13:30 --> Helper loaded: form_helper
INFO - 2017-07-04 05:13:30 --> Helper loaded: url_helper
INFO - 2017-07-04 05:13:30 --> Model Class Initialized
INFO - 2017-07-04 05:13:30 --> Final output sent to browser
DEBUG - 2017-07-04 05:13:30 --> Total execution time: 0.0560
ERROR - 2017-07-04 05:14:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:14:16 --> Config Class Initialized
INFO - 2017-07-04 05:14:16 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:14:16 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:14:16 --> Utf8 Class Initialized
INFO - 2017-07-04 05:14:16 --> URI Class Initialized
INFO - 2017-07-04 05:14:16 --> Router Class Initialized
INFO - 2017-07-04 05:14:16 --> Output Class Initialized
INFO - 2017-07-04 05:14:16 --> Security Class Initialized
DEBUG - 2017-07-04 05:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:14:16 --> Input Class Initialized
INFO - 2017-07-04 05:14:16 --> Language Class Initialized
INFO - 2017-07-04 05:14:16 --> Loader Class Initialized
INFO - 2017-07-04 05:14:16 --> Controller Class Initialized
INFO - 2017-07-04 05:14:16 --> Database Driver Class Initialized
INFO - 2017-07-04 05:14:16 --> Model Class Initialized
INFO - 2017-07-04 05:14:16 --> Helper loaded: form_helper
INFO - 2017-07-04 05:14:16 --> Helper loaded: url_helper
INFO - 2017-07-04 05:14:16 --> Model Class Initialized
INFO - 2017-07-04 05:14:16 --> Final output sent to browser
DEBUG - 2017-07-04 05:14:16 --> Total execution time: 0.0500
ERROR - 2017-07-04 05:14:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:14:17 --> Config Class Initialized
INFO - 2017-07-04 05:14:17 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:14:17 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:14:17 --> Utf8 Class Initialized
INFO - 2017-07-04 05:14:17 --> URI Class Initialized
INFO - 2017-07-04 05:14:17 --> Router Class Initialized
INFO - 2017-07-04 05:14:17 --> Output Class Initialized
INFO - 2017-07-04 05:14:17 --> Security Class Initialized
DEBUG - 2017-07-04 05:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:14:17 --> Input Class Initialized
INFO - 2017-07-04 05:14:17 --> Language Class Initialized
INFO - 2017-07-04 05:14:17 --> Loader Class Initialized
INFO - 2017-07-04 05:14:17 --> Controller Class Initialized
INFO - 2017-07-04 05:14:17 --> Database Driver Class Initialized
INFO - 2017-07-04 05:14:17 --> Model Class Initialized
INFO - 2017-07-04 05:14:17 --> Helper loaded: form_helper
INFO - 2017-07-04 05:14:17 --> Helper loaded: url_helper
INFO - 2017-07-04 05:14:17 --> Model Class Initialized
INFO - 2017-07-04 05:14:17 --> Final output sent to browser
DEBUG - 2017-07-04 05:14:17 --> Total execution time: 0.1110
ERROR - 2017-07-04 05:15:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:15:31 --> Config Class Initialized
INFO - 2017-07-04 05:15:31 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:15:31 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:15:31 --> Utf8 Class Initialized
INFO - 2017-07-04 05:15:31 --> URI Class Initialized
INFO - 2017-07-04 05:15:31 --> Router Class Initialized
INFO - 2017-07-04 05:15:31 --> Output Class Initialized
INFO - 2017-07-04 05:15:31 --> Security Class Initialized
DEBUG - 2017-07-04 05:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:15:31 --> Input Class Initialized
INFO - 2017-07-04 05:15:31 --> Language Class Initialized
INFO - 2017-07-04 05:15:31 --> Loader Class Initialized
INFO - 2017-07-04 05:15:31 --> Controller Class Initialized
INFO - 2017-07-04 05:15:31 --> Database Driver Class Initialized
INFO - 2017-07-04 05:15:31 --> Model Class Initialized
INFO - 2017-07-04 05:15:31 --> Helper loaded: form_helper
INFO - 2017-07-04 05:15:31 --> Helper loaded: url_helper
INFO - 2017-07-04 05:15:31 --> Model Class Initialized
INFO - 2017-07-04 05:15:31 --> Final output sent to browser
DEBUG - 2017-07-04 05:15:31 --> Total execution time: 0.0520
ERROR - 2017-07-04 05:15:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:15:32 --> Config Class Initialized
INFO - 2017-07-04 05:15:32 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:15:32 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:15:32 --> Utf8 Class Initialized
INFO - 2017-07-04 05:15:32 --> URI Class Initialized
INFO - 2017-07-04 05:15:32 --> Router Class Initialized
INFO - 2017-07-04 05:15:32 --> Output Class Initialized
INFO - 2017-07-04 05:15:32 --> Security Class Initialized
DEBUG - 2017-07-04 05:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:15:32 --> Input Class Initialized
INFO - 2017-07-04 05:15:32 --> Language Class Initialized
INFO - 2017-07-04 05:15:32 --> Loader Class Initialized
INFO - 2017-07-04 05:15:32 --> Controller Class Initialized
INFO - 2017-07-04 05:15:32 --> Database Driver Class Initialized
INFO - 2017-07-04 05:15:32 --> Model Class Initialized
INFO - 2017-07-04 05:15:32 --> Helper loaded: form_helper
INFO - 2017-07-04 05:15:32 --> Helper loaded: url_helper
INFO - 2017-07-04 05:15:32 --> Model Class Initialized
INFO - 2017-07-04 05:15:32 --> Final output sent to browser
DEBUG - 2017-07-04 05:15:32 --> Total execution time: 0.0440
ERROR - 2017-07-04 05:15:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:15:40 --> Config Class Initialized
INFO - 2017-07-04 05:15:40 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:15:40 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:15:40 --> Utf8 Class Initialized
INFO - 2017-07-04 05:15:40 --> URI Class Initialized
INFO - 2017-07-04 05:15:40 --> Router Class Initialized
INFO - 2017-07-04 05:15:40 --> Output Class Initialized
INFO - 2017-07-04 05:15:40 --> Security Class Initialized
DEBUG - 2017-07-04 05:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:15:40 --> Input Class Initialized
INFO - 2017-07-04 05:15:40 --> Language Class Initialized
INFO - 2017-07-04 05:15:40 --> Loader Class Initialized
INFO - 2017-07-04 05:15:40 --> Controller Class Initialized
INFO - 2017-07-04 05:15:40 --> Database Driver Class Initialized
INFO - 2017-07-04 05:15:40 --> Model Class Initialized
INFO - 2017-07-04 05:15:40 --> Helper loaded: form_helper
INFO - 2017-07-04 05:15:40 --> Helper loaded: url_helper
INFO - 2017-07-04 05:15:40 --> Model Class Initialized
INFO - 2017-07-04 05:15:40 --> Final output sent to browser
DEBUG - 2017-07-04 05:15:40 --> Total execution time: 0.0460
ERROR - 2017-07-04 05:16:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:16:16 --> Config Class Initialized
INFO - 2017-07-04 05:16:16 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:16:16 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:16:16 --> Utf8 Class Initialized
INFO - 2017-07-04 05:16:16 --> URI Class Initialized
INFO - 2017-07-04 05:16:16 --> Router Class Initialized
INFO - 2017-07-04 05:16:16 --> Output Class Initialized
INFO - 2017-07-04 05:16:16 --> Security Class Initialized
DEBUG - 2017-07-04 05:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:16:16 --> Input Class Initialized
INFO - 2017-07-04 05:16:16 --> Language Class Initialized
INFO - 2017-07-04 05:16:16 --> Loader Class Initialized
INFO - 2017-07-04 05:16:16 --> Controller Class Initialized
INFO - 2017-07-04 05:16:16 --> Database Driver Class Initialized
INFO - 2017-07-04 05:16:16 --> Model Class Initialized
INFO - 2017-07-04 05:16:16 --> Helper loaded: form_helper
INFO - 2017-07-04 05:16:16 --> Helper loaded: url_helper
INFO - 2017-07-04 05:16:16 --> Model Class Initialized
INFO - 2017-07-04 05:16:16 --> Final output sent to browser
DEBUG - 2017-07-04 05:16:16 --> Total execution time: 0.0610
ERROR - 2017-07-04 05:16:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:16:17 --> Config Class Initialized
INFO - 2017-07-04 05:16:17 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:16:17 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:16:17 --> Utf8 Class Initialized
INFO - 2017-07-04 05:16:17 --> URI Class Initialized
INFO - 2017-07-04 05:16:17 --> Router Class Initialized
INFO - 2017-07-04 05:16:17 --> Output Class Initialized
INFO - 2017-07-04 05:16:17 --> Security Class Initialized
DEBUG - 2017-07-04 05:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:16:17 --> Input Class Initialized
INFO - 2017-07-04 05:16:17 --> Language Class Initialized
INFO - 2017-07-04 05:16:17 --> Loader Class Initialized
INFO - 2017-07-04 05:16:17 --> Controller Class Initialized
INFO - 2017-07-04 05:16:17 --> Database Driver Class Initialized
INFO - 2017-07-04 05:16:17 --> Model Class Initialized
INFO - 2017-07-04 05:16:17 --> Helper loaded: form_helper
INFO - 2017-07-04 05:16:17 --> Helper loaded: url_helper
INFO - 2017-07-04 05:16:17 --> Model Class Initialized
INFO - 2017-07-04 05:16:17 --> Final output sent to browser
DEBUG - 2017-07-04 05:16:17 --> Total execution time: 0.0450
ERROR - 2017-07-04 05:16:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:16:26 --> Config Class Initialized
INFO - 2017-07-04 05:16:26 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:16:26 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:16:26 --> Utf8 Class Initialized
INFO - 2017-07-04 05:16:26 --> URI Class Initialized
INFO - 2017-07-04 05:16:26 --> Router Class Initialized
INFO - 2017-07-04 05:16:26 --> Output Class Initialized
INFO - 2017-07-04 05:16:26 --> Security Class Initialized
DEBUG - 2017-07-04 05:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:16:26 --> Input Class Initialized
INFO - 2017-07-04 05:16:26 --> Language Class Initialized
INFO - 2017-07-04 05:16:26 --> Loader Class Initialized
INFO - 2017-07-04 05:16:26 --> Controller Class Initialized
INFO - 2017-07-04 05:16:26 --> Database Driver Class Initialized
INFO - 2017-07-04 05:16:26 --> Model Class Initialized
INFO - 2017-07-04 05:16:26 --> Helper loaded: form_helper
INFO - 2017-07-04 05:16:26 --> Helper loaded: url_helper
INFO - 2017-07-04 05:16:26 --> Model Class Initialized
INFO - 2017-07-04 05:16:26 --> Final output sent to browser
DEBUG - 2017-07-04 05:16:26 --> Total execution time: 0.0520
ERROR - 2017-07-04 05:18:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:18:17 --> Config Class Initialized
INFO - 2017-07-04 05:18:17 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:18:17 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:18:17 --> Utf8 Class Initialized
INFO - 2017-07-04 05:18:17 --> URI Class Initialized
INFO - 2017-07-04 05:18:17 --> Router Class Initialized
INFO - 2017-07-04 05:18:17 --> Output Class Initialized
INFO - 2017-07-04 05:18:17 --> Security Class Initialized
DEBUG - 2017-07-04 05:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:18:17 --> Input Class Initialized
INFO - 2017-07-04 05:18:17 --> Language Class Initialized
INFO - 2017-07-04 05:18:17 --> Loader Class Initialized
INFO - 2017-07-04 05:18:17 --> Controller Class Initialized
INFO - 2017-07-04 05:18:17 --> Database Driver Class Initialized
INFO - 2017-07-04 05:18:17 --> Model Class Initialized
INFO - 2017-07-04 05:18:17 --> Helper loaded: form_helper
INFO - 2017-07-04 05:18:17 --> Helper loaded: url_helper
INFO - 2017-07-04 05:18:17 --> Model Class Initialized
INFO - 2017-07-04 05:18:17 --> Final output sent to browser
DEBUG - 2017-07-04 05:18:17 --> Total execution time: 0.0580
ERROR - 2017-07-04 05:18:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:18:18 --> Config Class Initialized
INFO - 2017-07-04 05:18:18 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:18:18 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:18:18 --> Utf8 Class Initialized
INFO - 2017-07-04 05:18:18 --> URI Class Initialized
INFO - 2017-07-04 05:18:18 --> Router Class Initialized
INFO - 2017-07-04 05:18:18 --> Output Class Initialized
INFO - 2017-07-04 05:18:18 --> Security Class Initialized
DEBUG - 2017-07-04 05:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:18:18 --> Input Class Initialized
INFO - 2017-07-04 05:18:18 --> Language Class Initialized
INFO - 2017-07-04 05:18:18 --> Loader Class Initialized
INFO - 2017-07-04 05:18:18 --> Controller Class Initialized
INFO - 2017-07-04 05:18:18 --> Database Driver Class Initialized
INFO - 2017-07-04 05:18:18 --> Model Class Initialized
INFO - 2017-07-04 05:18:18 --> Helper loaded: form_helper
INFO - 2017-07-04 05:18:18 --> Helper loaded: url_helper
INFO - 2017-07-04 05:18:18 --> Model Class Initialized
INFO - 2017-07-04 05:18:18 --> Final output sent to browser
DEBUG - 2017-07-04 05:18:18 --> Total execution time: 0.0460
ERROR - 2017-07-04 05:18:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:18:40 --> Config Class Initialized
INFO - 2017-07-04 05:18:40 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:18:40 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:18:40 --> Utf8 Class Initialized
INFO - 2017-07-04 05:18:40 --> URI Class Initialized
INFO - 2017-07-04 05:18:40 --> Router Class Initialized
INFO - 2017-07-04 05:18:40 --> Output Class Initialized
INFO - 2017-07-04 05:18:40 --> Security Class Initialized
DEBUG - 2017-07-04 05:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:18:40 --> Input Class Initialized
INFO - 2017-07-04 05:18:40 --> Language Class Initialized
INFO - 2017-07-04 05:18:40 --> Loader Class Initialized
INFO - 2017-07-04 05:18:40 --> Controller Class Initialized
INFO - 2017-07-04 05:18:40 --> Database Driver Class Initialized
INFO - 2017-07-04 05:18:40 --> Model Class Initialized
INFO - 2017-07-04 05:18:40 --> Helper loaded: form_helper
INFO - 2017-07-04 05:18:40 --> Helper loaded: url_helper
INFO - 2017-07-04 05:18:40 --> Model Class Initialized
INFO - 2017-07-04 05:18:40 --> Final output sent to browser
DEBUG - 2017-07-04 05:18:40 --> Total execution time: 0.0580
ERROR - 2017-07-04 05:19:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:19:14 --> Config Class Initialized
INFO - 2017-07-04 05:19:14 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:19:14 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:19:14 --> Utf8 Class Initialized
INFO - 2017-07-04 05:19:14 --> URI Class Initialized
INFO - 2017-07-04 05:19:14 --> Router Class Initialized
INFO - 2017-07-04 05:19:14 --> Output Class Initialized
INFO - 2017-07-04 05:19:14 --> Security Class Initialized
DEBUG - 2017-07-04 05:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:19:14 --> Input Class Initialized
INFO - 2017-07-04 05:19:14 --> Language Class Initialized
INFO - 2017-07-04 05:19:14 --> Loader Class Initialized
INFO - 2017-07-04 05:19:14 --> Controller Class Initialized
INFO - 2017-07-04 05:19:14 --> Database Driver Class Initialized
INFO - 2017-07-04 05:19:14 --> Model Class Initialized
INFO - 2017-07-04 05:19:14 --> Helper loaded: form_helper
INFO - 2017-07-04 05:19:14 --> Helper loaded: url_helper
INFO - 2017-07-04 05:19:14 --> Model Class Initialized
INFO - 2017-07-04 05:19:14 --> Final output sent to browser
DEBUG - 2017-07-04 05:19:14 --> Total execution time: 0.0670
ERROR - 2017-07-04 05:19:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:19:15 --> Config Class Initialized
INFO - 2017-07-04 05:19:15 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:19:15 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:19:15 --> Utf8 Class Initialized
INFO - 2017-07-04 05:19:15 --> URI Class Initialized
INFO - 2017-07-04 05:19:15 --> Router Class Initialized
INFO - 2017-07-04 05:19:15 --> Output Class Initialized
INFO - 2017-07-04 05:19:15 --> Security Class Initialized
DEBUG - 2017-07-04 05:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:19:15 --> Input Class Initialized
INFO - 2017-07-04 05:19:15 --> Language Class Initialized
INFO - 2017-07-04 05:19:15 --> Loader Class Initialized
INFO - 2017-07-04 05:19:15 --> Controller Class Initialized
INFO - 2017-07-04 05:19:15 --> Database Driver Class Initialized
INFO - 2017-07-04 05:19:15 --> Model Class Initialized
INFO - 2017-07-04 05:19:15 --> Helper loaded: form_helper
INFO - 2017-07-04 05:19:15 --> Helper loaded: url_helper
INFO - 2017-07-04 05:19:15 --> Model Class Initialized
INFO - 2017-07-04 05:19:15 --> Final output sent to browser
DEBUG - 2017-07-04 05:19:15 --> Total execution time: 0.0470
ERROR - 2017-07-04 05:19:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:19:29 --> Config Class Initialized
INFO - 2017-07-04 05:19:29 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:19:29 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:19:29 --> Utf8 Class Initialized
INFO - 2017-07-04 05:19:29 --> URI Class Initialized
INFO - 2017-07-04 05:19:29 --> Router Class Initialized
INFO - 2017-07-04 05:19:29 --> Output Class Initialized
INFO - 2017-07-04 05:19:29 --> Security Class Initialized
DEBUG - 2017-07-04 05:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:19:29 --> Input Class Initialized
INFO - 2017-07-04 05:19:29 --> Language Class Initialized
INFO - 2017-07-04 05:19:29 --> Loader Class Initialized
INFO - 2017-07-04 05:19:29 --> Controller Class Initialized
INFO - 2017-07-04 05:19:29 --> Database Driver Class Initialized
INFO - 2017-07-04 05:19:29 --> Model Class Initialized
INFO - 2017-07-04 05:19:29 --> Helper loaded: form_helper
INFO - 2017-07-04 05:19:29 --> Helper loaded: url_helper
INFO - 2017-07-04 05:19:29 --> Model Class Initialized
INFO - 2017-07-04 05:19:29 --> Final output sent to browser
DEBUG - 2017-07-04 05:19:29 --> Total execution time: 0.0580
ERROR - 2017-07-04 05:22:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:22:19 --> Config Class Initialized
INFO - 2017-07-04 05:22:19 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:22:19 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:22:19 --> Utf8 Class Initialized
INFO - 2017-07-04 05:22:19 --> URI Class Initialized
INFO - 2017-07-04 05:22:19 --> Router Class Initialized
INFO - 2017-07-04 05:22:19 --> Output Class Initialized
INFO - 2017-07-04 05:22:19 --> Security Class Initialized
DEBUG - 2017-07-04 05:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:22:19 --> Input Class Initialized
INFO - 2017-07-04 05:22:19 --> Language Class Initialized
INFO - 2017-07-04 05:22:19 --> Loader Class Initialized
INFO - 2017-07-04 05:22:19 --> Controller Class Initialized
INFO - 2017-07-04 05:22:19 --> Database Driver Class Initialized
INFO - 2017-07-04 05:22:19 --> Model Class Initialized
INFO - 2017-07-04 05:22:19 --> Helper loaded: form_helper
INFO - 2017-07-04 05:22:19 --> Helper loaded: url_helper
INFO - 2017-07-04 05:22:19 --> Model Class Initialized
INFO - 2017-07-04 05:22:19 --> Final output sent to browser
DEBUG - 2017-07-04 05:22:19 --> Total execution time: 0.1560
ERROR - 2017-07-04 05:22:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:22:20 --> Config Class Initialized
INFO - 2017-07-04 05:22:20 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:22:20 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:22:20 --> Utf8 Class Initialized
INFO - 2017-07-04 05:22:20 --> URI Class Initialized
INFO - 2017-07-04 05:22:20 --> Router Class Initialized
INFO - 2017-07-04 05:22:20 --> Output Class Initialized
INFO - 2017-07-04 05:22:20 --> Security Class Initialized
DEBUG - 2017-07-04 05:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:22:20 --> Input Class Initialized
INFO - 2017-07-04 05:22:20 --> Language Class Initialized
INFO - 2017-07-04 05:22:20 --> Loader Class Initialized
INFO - 2017-07-04 05:22:20 --> Controller Class Initialized
INFO - 2017-07-04 05:22:20 --> Database Driver Class Initialized
INFO - 2017-07-04 05:22:20 --> Model Class Initialized
INFO - 2017-07-04 05:22:20 --> Helper loaded: form_helper
INFO - 2017-07-04 05:22:20 --> Helper loaded: url_helper
INFO - 2017-07-04 05:22:20 --> Model Class Initialized
INFO - 2017-07-04 05:22:20 --> Final output sent to browser
DEBUG - 2017-07-04 05:22:20 --> Total execution time: 0.0720
ERROR - 2017-07-04 05:22:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:22:25 --> Config Class Initialized
INFO - 2017-07-04 05:22:25 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:22:25 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:22:25 --> Utf8 Class Initialized
INFO - 2017-07-04 05:22:25 --> URI Class Initialized
INFO - 2017-07-04 05:22:25 --> Router Class Initialized
INFO - 2017-07-04 05:22:25 --> Output Class Initialized
INFO - 2017-07-04 05:22:25 --> Security Class Initialized
DEBUG - 2017-07-04 05:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:22:25 --> Input Class Initialized
INFO - 2017-07-04 05:22:25 --> Language Class Initialized
INFO - 2017-07-04 05:22:25 --> Loader Class Initialized
INFO - 2017-07-04 05:22:25 --> Controller Class Initialized
INFO - 2017-07-04 05:22:25 --> Database Driver Class Initialized
INFO - 2017-07-04 05:22:25 --> Model Class Initialized
INFO - 2017-07-04 05:22:25 --> Helper loaded: form_helper
INFO - 2017-07-04 05:22:25 --> Helper loaded: url_helper
INFO - 2017-07-04 05:22:25 --> Model Class Initialized
INFO - 2017-07-04 05:22:25 --> Final output sent to browser
DEBUG - 2017-07-04 05:22:25 --> Total execution time: 0.0430
ERROR - 2017-07-04 05:23:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:23:33 --> Config Class Initialized
INFO - 2017-07-04 05:23:33 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:23:33 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:23:33 --> Utf8 Class Initialized
INFO - 2017-07-04 05:23:33 --> URI Class Initialized
INFO - 2017-07-04 05:23:33 --> Router Class Initialized
INFO - 2017-07-04 05:23:33 --> Output Class Initialized
INFO - 2017-07-04 05:23:33 --> Security Class Initialized
DEBUG - 2017-07-04 05:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:23:33 --> Input Class Initialized
INFO - 2017-07-04 05:23:33 --> Language Class Initialized
INFO - 2017-07-04 05:23:33 --> Loader Class Initialized
INFO - 2017-07-04 05:23:33 --> Controller Class Initialized
INFO - 2017-07-04 05:23:33 --> Database Driver Class Initialized
INFO - 2017-07-04 05:23:33 --> Model Class Initialized
INFO - 2017-07-04 05:23:33 --> Helper loaded: form_helper
INFO - 2017-07-04 05:23:33 --> Helper loaded: url_helper
INFO - 2017-07-04 05:23:33 --> Model Class Initialized
INFO - 2017-07-04 05:23:33 --> Final output sent to browser
DEBUG - 2017-07-04 05:23:33 --> Total execution time: 0.0520
ERROR - 2017-07-04 05:23:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:23:35 --> Config Class Initialized
INFO - 2017-07-04 05:23:35 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:23:35 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:23:35 --> Utf8 Class Initialized
INFO - 2017-07-04 05:23:35 --> URI Class Initialized
INFO - 2017-07-04 05:23:35 --> Router Class Initialized
INFO - 2017-07-04 05:23:35 --> Output Class Initialized
INFO - 2017-07-04 05:23:35 --> Security Class Initialized
DEBUG - 2017-07-04 05:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:23:35 --> Input Class Initialized
INFO - 2017-07-04 05:23:35 --> Language Class Initialized
INFO - 2017-07-04 05:23:35 --> Loader Class Initialized
INFO - 2017-07-04 05:23:35 --> Controller Class Initialized
INFO - 2017-07-04 05:23:35 --> Database Driver Class Initialized
INFO - 2017-07-04 05:23:35 --> Model Class Initialized
INFO - 2017-07-04 05:23:35 --> Helper loaded: form_helper
INFO - 2017-07-04 05:23:35 --> Helper loaded: url_helper
INFO - 2017-07-04 05:23:35 --> Model Class Initialized
INFO - 2017-07-04 05:23:35 --> Final output sent to browser
DEBUG - 2017-07-04 05:23:35 --> Total execution time: 0.0480
ERROR - 2017-07-04 05:23:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:23:41 --> Config Class Initialized
INFO - 2017-07-04 05:23:41 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:23:41 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:23:41 --> Utf8 Class Initialized
INFO - 2017-07-04 05:23:41 --> URI Class Initialized
INFO - 2017-07-04 05:23:41 --> Router Class Initialized
INFO - 2017-07-04 05:23:41 --> Output Class Initialized
INFO - 2017-07-04 05:23:41 --> Security Class Initialized
DEBUG - 2017-07-04 05:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:23:41 --> Input Class Initialized
INFO - 2017-07-04 05:23:41 --> Language Class Initialized
INFO - 2017-07-04 05:23:41 --> Loader Class Initialized
INFO - 2017-07-04 05:23:41 --> Controller Class Initialized
INFO - 2017-07-04 05:23:41 --> Database Driver Class Initialized
INFO - 2017-07-04 05:23:41 --> Model Class Initialized
INFO - 2017-07-04 05:23:41 --> Helper loaded: form_helper
INFO - 2017-07-04 05:23:41 --> Helper loaded: url_helper
INFO - 2017-07-04 05:23:41 --> Model Class Initialized
INFO - 2017-07-04 05:23:41 --> Final output sent to browser
DEBUG - 2017-07-04 05:23:41 --> Total execution time: 0.0600
ERROR - 2017-07-04 05:24:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:24:16 --> Config Class Initialized
INFO - 2017-07-04 05:24:16 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:24:16 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:24:16 --> Utf8 Class Initialized
INFO - 2017-07-04 05:24:16 --> URI Class Initialized
INFO - 2017-07-04 05:24:16 --> Router Class Initialized
INFO - 2017-07-04 05:24:16 --> Output Class Initialized
INFO - 2017-07-04 05:24:16 --> Security Class Initialized
DEBUG - 2017-07-04 05:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:24:16 --> Input Class Initialized
INFO - 2017-07-04 05:24:16 --> Language Class Initialized
INFO - 2017-07-04 05:24:16 --> Loader Class Initialized
INFO - 2017-07-04 05:24:16 --> Controller Class Initialized
INFO - 2017-07-04 05:24:16 --> Database Driver Class Initialized
INFO - 2017-07-04 05:24:16 --> Model Class Initialized
INFO - 2017-07-04 05:24:16 --> Helper loaded: form_helper
INFO - 2017-07-04 05:24:16 --> Helper loaded: url_helper
INFO - 2017-07-04 05:24:16 --> Model Class Initialized
INFO - 2017-07-04 05:24:16 --> Final output sent to browser
DEBUG - 2017-07-04 05:24:16 --> Total execution time: 0.0510
ERROR - 2017-07-04 05:24:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:24:17 --> Config Class Initialized
INFO - 2017-07-04 05:24:17 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:24:17 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:24:17 --> Utf8 Class Initialized
INFO - 2017-07-04 05:24:17 --> URI Class Initialized
INFO - 2017-07-04 05:24:17 --> Router Class Initialized
INFO - 2017-07-04 05:24:17 --> Output Class Initialized
INFO - 2017-07-04 05:24:17 --> Security Class Initialized
DEBUG - 2017-07-04 05:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:24:17 --> Input Class Initialized
INFO - 2017-07-04 05:24:17 --> Language Class Initialized
INFO - 2017-07-04 05:24:17 --> Loader Class Initialized
INFO - 2017-07-04 05:24:17 --> Controller Class Initialized
INFO - 2017-07-04 05:24:17 --> Database Driver Class Initialized
INFO - 2017-07-04 05:24:17 --> Model Class Initialized
INFO - 2017-07-04 05:24:17 --> Helper loaded: form_helper
INFO - 2017-07-04 05:24:17 --> Helper loaded: url_helper
INFO - 2017-07-04 05:24:17 --> Model Class Initialized
INFO - 2017-07-04 05:24:17 --> Final output sent to browser
DEBUG - 2017-07-04 05:24:17 --> Total execution time: 0.0440
ERROR - 2017-07-04 05:24:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:24:36 --> Config Class Initialized
INFO - 2017-07-04 05:24:36 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:24:36 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:24:36 --> Utf8 Class Initialized
INFO - 2017-07-04 05:24:36 --> URI Class Initialized
INFO - 2017-07-04 05:24:36 --> Router Class Initialized
INFO - 2017-07-04 05:24:36 --> Output Class Initialized
INFO - 2017-07-04 05:24:36 --> Security Class Initialized
DEBUG - 2017-07-04 05:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:24:36 --> Input Class Initialized
INFO - 2017-07-04 05:24:36 --> Language Class Initialized
INFO - 2017-07-04 05:24:36 --> Loader Class Initialized
INFO - 2017-07-04 05:24:36 --> Controller Class Initialized
INFO - 2017-07-04 05:24:36 --> Database Driver Class Initialized
INFO - 2017-07-04 05:24:36 --> Model Class Initialized
INFO - 2017-07-04 05:24:36 --> Helper loaded: form_helper
INFO - 2017-07-04 05:24:36 --> Helper loaded: url_helper
INFO - 2017-07-04 05:24:36 --> Model Class Initialized
INFO - 2017-07-04 05:24:36 --> Final output sent to browser
DEBUG - 2017-07-04 05:24:36 --> Total execution time: 0.0430
ERROR - 2017-07-04 05:29:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:29:08 --> Config Class Initialized
INFO - 2017-07-04 05:29:08 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:29:08 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:29:08 --> Utf8 Class Initialized
INFO - 2017-07-04 05:29:08 --> URI Class Initialized
INFO - 2017-07-04 05:29:08 --> Router Class Initialized
INFO - 2017-07-04 05:29:08 --> Output Class Initialized
INFO - 2017-07-04 05:29:08 --> Security Class Initialized
DEBUG - 2017-07-04 05:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:29:08 --> Input Class Initialized
INFO - 2017-07-04 05:29:08 --> Language Class Initialized
INFO - 2017-07-04 05:29:08 --> Loader Class Initialized
INFO - 2017-07-04 05:29:08 --> Controller Class Initialized
INFO - 2017-07-04 05:29:08 --> Database Driver Class Initialized
INFO - 2017-07-04 05:29:08 --> Model Class Initialized
INFO - 2017-07-04 05:29:08 --> Helper loaded: form_helper
INFO - 2017-07-04 05:29:08 --> Helper loaded: url_helper
INFO - 2017-07-04 05:29:08 --> Model Class Initialized
INFO - 2017-07-04 05:29:08 --> Final output sent to browser
DEBUG - 2017-07-04 05:29:08 --> Total execution time: 0.0580
ERROR - 2017-07-04 05:29:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:29:09 --> Config Class Initialized
INFO - 2017-07-04 05:29:09 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:29:09 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:29:09 --> Utf8 Class Initialized
INFO - 2017-07-04 05:29:09 --> URI Class Initialized
INFO - 2017-07-04 05:29:09 --> Router Class Initialized
INFO - 2017-07-04 05:29:09 --> Output Class Initialized
INFO - 2017-07-04 05:29:09 --> Security Class Initialized
DEBUG - 2017-07-04 05:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:29:09 --> Input Class Initialized
INFO - 2017-07-04 05:29:09 --> Language Class Initialized
INFO - 2017-07-04 05:29:09 --> Loader Class Initialized
INFO - 2017-07-04 05:29:09 --> Controller Class Initialized
INFO - 2017-07-04 05:29:09 --> Database Driver Class Initialized
INFO - 2017-07-04 05:29:09 --> Model Class Initialized
INFO - 2017-07-04 05:29:09 --> Helper loaded: form_helper
INFO - 2017-07-04 05:29:09 --> Helper loaded: url_helper
INFO - 2017-07-04 05:29:09 --> Model Class Initialized
INFO - 2017-07-04 05:29:09 --> Final output sent to browser
DEBUG - 2017-07-04 05:29:09 --> Total execution time: 0.0560
ERROR - 2017-07-04 05:29:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:29:15 --> Config Class Initialized
INFO - 2017-07-04 05:29:15 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:29:15 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:29:15 --> Utf8 Class Initialized
INFO - 2017-07-04 05:29:15 --> URI Class Initialized
INFO - 2017-07-04 05:29:15 --> Router Class Initialized
INFO - 2017-07-04 05:29:15 --> Output Class Initialized
INFO - 2017-07-04 05:29:15 --> Security Class Initialized
DEBUG - 2017-07-04 05:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:29:15 --> Input Class Initialized
INFO - 2017-07-04 05:29:15 --> Language Class Initialized
INFO - 2017-07-04 05:29:15 --> Loader Class Initialized
INFO - 2017-07-04 05:29:15 --> Controller Class Initialized
INFO - 2017-07-04 05:29:15 --> Database Driver Class Initialized
INFO - 2017-07-04 05:29:15 --> Model Class Initialized
INFO - 2017-07-04 05:29:15 --> Helper loaded: form_helper
INFO - 2017-07-04 05:29:15 --> Helper loaded: url_helper
INFO - 2017-07-04 05:29:15 --> Model Class Initialized
INFO - 2017-07-04 05:29:15 --> Final output sent to browser
DEBUG - 2017-07-04 05:29:15 --> Total execution time: 0.0490
ERROR - 2017-07-04 05:29:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:29:34 --> Config Class Initialized
INFO - 2017-07-04 05:29:34 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:29:34 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:29:34 --> Utf8 Class Initialized
INFO - 2017-07-04 05:29:34 --> URI Class Initialized
INFO - 2017-07-04 05:29:34 --> Router Class Initialized
INFO - 2017-07-04 05:29:34 --> Output Class Initialized
INFO - 2017-07-04 05:29:34 --> Security Class Initialized
DEBUG - 2017-07-04 05:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:29:34 --> Input Class Initialized
INFO - 2017-07-04 05:29:34 --> Language Class Initialized
INFO - 2017-07-04 05:29:34 --> Loader Class Initialized
INFO - 2017-07-04 05:29:34 --> Controller Class Initialized
INFO - 2017-07-04 05:29:34 --> Database Driver Class Initialized
INFO - 2017-07-04 05:29:34 --> Model Class Initialized
INFO - 2017-07-04 05:29:34 --> Helper loaded: form_helper
INFO - 2017-07-04 05:29:34 --> Helper loaded: url_helper
INFO - 2017-07-04 05:29:34 --> Model Class Initialized
INFO - 2017-07-04 05:29:34 --> Final output sent to browser
DEBUG - 2017-07-04 05:29:34 --> Total execution time: 0.0850
ERROR - 2017-07-04 05:30:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:30:20 --> Config Class Initialized
INFO - 2017-07-04 05:30:20 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:30:20 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:30:20 --> Utf8 Class Initialized
INFO - 2017-07-04 05:30:20 --> URI Class Initialized
INFO - 2017-07-04 05:30:20 --> Router Class Initialized
INFO - 2017-07-04 05:30:20 --> Output Class Initialized
INFO - 2017-07-04 05:30:20 --> Security Class Initialized
DEBUG - 2017-07-04 05:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:30:20 --> Input Class Initialized
INFO - 2017-07-04 05:30:20 --> Language Class Initialized
INFO - 2017-07-04 05:30:20 --> Loader Class Initialized
INFO - 2017-07-04 05:30:20 --> Controller Class Initialized
INFO - 2017-07-04 05:30:20 --> Database Driver Class Initialized
INFO - 2017-07-04 05:30:20 --> Model Class Initialized
INFO - 2017-07-04 05:30:20 --> Helper loaded: form_helper
INFO - 2017-07-04 05:30:20 --> Helper loaded: url_helper
INFO - 2017-07-04 05:30:20 --> Model Class Initialized
INFO - 2017-07-04 05:30:20 --> Final output sent to browser
DEBUG - 2017-07-04 05:30:20 --> Total execution time: 0.0550
ERROR - 2017-07-04 05:30:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:30:21 --> Config Class Initialized
INFO - 2017-07-04 05:30:21 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:30:21 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:30:21 --> Utf8 Class Initialized
INFO - 2017-07-04 05:30:21 --> URI Class Initialized
INFO - 2017-07-04 05:30:21 --> Router Class Initialized
INFO - 2017-07-04 05:30:21 --> Output Class Initialized
INFO - 2017-07-04 05:30:21 --> Security Class Initialized
DEBUG - 2017-07-04 05:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:30:21 --> Input Class Initialized
INFO - 2017-07-04 05:30:21 --> Language Class Initialized
INFO - 2017-07-04 05:30:21 --> Loader Class Initialized
INFO - 2017-07-04 05:30:21 --> Controller Class Initialized
INFO - 2017-07-04 05:30:21 --> Database Driver Class Initialized
INFO - 2017-07-04 05:30:21 --> Model Class Initialized
INFO - 2017-07-04 05:30:21 --> Helper loaded: form_helper
INFO - 2017-07-04 05:30:21 --> Helper loaded: url_helper
INFO - 2017-07-04 05:30:21 --> Model Class Initialized
INFO - 2017-07-04 05:30:21 --> Final output sent to browser
DEBUG - 2017-07-04 05:30:21 --> Total execution time: 0.0580
ERROR - 2017-07-04 05:30:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:30:31 --> Config Class Initialized
INFO - 2017-07-04 05:30:31 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:30:31 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:30:31 --> Utf8 Class Initialized
INFO - 2017-07-04 05:30:31 --> URI Class Initialized
INFO - 2017-07-04 05:30:31 --> Router Class Initialized
INFO - 2017-07-04 05:30:31 --> Output Class Initialized
INFO - 2017-07-04 05:30:31 --> Security Class Initialized
DEBUG - 2017-07-04 05:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:30:31 --> Input Class Initialized
INFO - 2017-07-04 05:30:31 --> Language Class Initialized
INFO - 2017-07-04 05:30:31 --> Loader Class Initialized
INFO - 2017-07-04 05:30:31 --> Controller Class Initialized
INFO - 2017-07-04 05:30:31 --> Database Driver Class Initialized
INFO - 2017-07-04 05:30:31 --> Model Class Initialized
INFO - 2017-07-04 05:30:31 --> Helper loaded: form_helper
INFO - 2017-07-04 05:30:31 --> Helper loaded: url_helper
INFO - 2017-07-04 05:30:31 --> Model Class Initialized
INFO - 2017-07-04 05:30:31 --> Final output sent to browser
DEBUG - 2017-07-04 05:30:31 --> Total execution time: 0.0440
ERROR - 2017-07-04 05:30:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:30:47 --> Config Class Initialized
INFO - 2017-07-04 05:30:47 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:30:47 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:30:47 --> Utf8 Class Initialized
INFO - 2017-07-04 05:30:47 --> URI Class Initialized
INFO - 2017-07-04 05:30:47 --> Router Class Initialized
INFO - 2017-07-04 05:30:47 --> Output Class Initialized
INFO - 2017-07-04 05:30:47 --> Security Class Initialized
DEBUG - 2017-07-04 05:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:30:47 --> Input Class Initialized
INFO - 2017-07-04 05:30:47 --> Language Class Initialized
INFO - 2017-07-04 05:30:47 --> Loader Class Initialized
INFO - 2017-07-04 05:30:47 --> Controller Class Initialized
INFO - 2017-07-04 05:30:47 --> Database Driver Class Initialized
INFO - 2017-07-04 05:30:48 --> Model Class Initialized
INFO - 2017-07-04 05:30:48 --> Helper loaded: form_helper
INFO - 2017-07-04 05:30:48 --> Helper loaded: url_helper
INFO - 2017-07-04 05:30:48 --> Model Class Initialized
INFO - 2017-07-04 05:30:48 --> Final output sent to browser
DEBUG - 2017-07-04 05:30:48 --> Total execution time: 0.0890
ERROR - 2017-07-04 05:32:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:32:17 --> Config Class Initialized
INFO - 2017-07-04 05:32:17 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:32:17 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:32:17 --> Utf8 Class Initialized
INFO - 2017-07-04 05:32:17 --> URI Class Initialized
INFO - 2017-07-04 05:32:17 --> Router Class Initialized
INFO - 2017-07-04 05:32:17 --> Output Class Initialized
INFO - 2017-07-04 05:32:17 --> Security Class Initialized
DEBUG - 2017-07-04 05:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:32:17 --> Input Class Initialized
INFO - 2017-07-04 05:32:17 --> Language Class Initialized
INFO - 2017-07-04 05:32:17 --> Loader Class Initialized
INFO - 2017-07-04 05:32:17 --> Controller Class Initialized
INFO - 2017-07-04 05:32:17 --> Database Driver Class Initialized
INFO - 2017-07-04 05:32:17 --> Model Class Initialized
INFO - 2017-07-04 05:32:17 --> Helper loaded: form_helper
INFO - 2017-07-04 05:32:17 --> Helper loaded: url_helper
INFO - 2017-07-04 05:32:17 --> Model Class Initialized
INFO - 2017-07-04 05:32:17 --> Final output sent to browser
DEBUG - 2017-07-04 05:32:17 --> Total execution time: 0.0570
ERROR - 2017-07-04 05:32:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:32:18 --> Config Class Initialized
INFO - 2017-07-04 05:32:18 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:32:18 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:32:18 --> Utf8 Class Initialized
INFO - 2017-07-04 05:32:18 --> URI Class Initialized
INFO - 2017-07-04 05:32:18 --> Router Class Initialized
INFO - 2017-07-04 05:32:18 --> Output Class Initialized
INFO - 2017-07-04 05:32:18 --> Security Class Initialized
DEBUG - 2017-07-04 05:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:32:18 --> Input Class Initialized
INFO - 2017-07-04 05:32:18 --> Language Class Initialized
INFO - 2017-07-04 05:32:18 --> Loader Class Initialized
INFO - 2017-07-04 05:32:18 --> Controller Class Initialized
INFO - 2017-07-04 05:32:18 --> Database Driver Class Initialized
INFO - 2017-07-04 05:32:18 --> Model Class Initialized
INFO - 2017-07-04 05:32:18 --> Helper loaded: form_helper
INFO - 2017-07-04 05:32:18 --> Helper loaded: url_helper
INFO - 2017-07-04 05:32:18 --> Model Class Initialized
INFO - 2017-07-04 05:32:18 --> Final output sent to browser
DEBUG - 2017-07-04 05:32:18 --> Total execution time: 0.0570
ERROR - 2017-07-04 05:32:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:32:23 --> Config Class Initialized
INFO - 2017-07-04 05:32:23 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:32:23 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:32:23 --> Utf8 Class Initialized
INFO - 2017-07-04 05:32:23 --> URI Class Initialized
INFO - 2017-07-04 05:32:23 --> Router Class Initialized
INFO - 2017-07-04 05:32:23 --> Output Class Initialized
INFO - 2017-07-04 05:32:23 --> Security Class Initialized
DEBUG - 2017-07-04 05:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:32:23 --> Input Class Initialized
INFO - 2017-07-04 05:32:23 --> Language Class Initialized
INFO - 2017-07-04 05:32:23 --> Loader Class Initialized
INFO - 2017-07-04 05:32:23 --> Controller Class Initialized
INFO - 2017-07-04 05:32:23 --> Database Driver Class Initialized
INFO - 2017-07-04 05:32:23 --> Model Class Initialized
INFO - 2017-07-04 05:32:23 --> Helper loaded: form_helper
INFO - 2017-07-04 05:32:23 --> Helper loaded: url_helper
INFO - 2017-07-04 05:32:23 --> Model Class Initialized
INFO - 2017-07-04 05:32:23 --> Final output sent to browser
DEBUG - 2017-07-04 05:32:23 --> Total execution time: 0.0560
ERROR - 2017-07-04 05:32:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:32:29 --> Config Class Initialized
INFO - 2017-07-04 05:32:29 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:32:29 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:32:29 --> Utf8 Class Initialized
INFO - 2017-07-04 05:32:29 --> URI Class Initialized
INFO - 2017-07-04 05:32:29 --> Router Class Initialized
INFO - 2017-07-04 05:32:29 --> Output Class Initialized
INFO - 2017-07-04 05:32:29 --> Security Class Initialized
DEBUG - 2017-07-04 05:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:32:29 --> Input Class Initialized
INFO - 2017-07-04 05:32:29 --> Language Class Initialized
INFO - 2017-07-04 05:32:29 --> Loader Class Initialized
INFO - 2017-07-04 05:32:29 --> Controller Class Initialized
INFO - 2017-07-04 05:32:29 --> Database Driver Class Initialized
INFO - 2017-07-04 05:32:29 --> Model Class Initialized
INFO - 2017-07-04 05:32:29 --> Helper loaded: form_helper
INFO - 2017-07-04 05:32:29 --> Helper loaded: url_helper
INFO - 2017-07-04 05:32:29 --> Model Class Initialized
INFO - 2017-07-04 05:32:30 --> Final output sent to browser
DEBUG - 2017-07-04 05:32:30 --> Total execution time: 0.3590
ERROR - 2017-07-04 05:35:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:35:28 --> Config Class Initialized
INFO - 2017-07-04 05:35:28 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:35:28 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:35:28 --> Utf8 Class Initialized
INFO - 2017-07-04 05:35:28 --> URI Class Initialized
INFO - 2017-07-04 05:35:28 --> Router Class Initialized
INFO - 2017-07-04 05:35:28 --> Output Class Initialized
INFO - 2017-07-04 05:35:28 --> Security Class Initialized
DEBUG - 2017-07-04 05:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:35:28 --> Input Class Initialized
INFO - 2017-07-04 05:35:28 --> Language Class Initialized
INFO - 2017-07-04 05:35:28 --> Loader Class Initialized
INFO - 2017-07-04 05:35:28 --> Controller Class Initialized
INFO - 2017-07-04 05:35:28 --> Database Driver Class Initialized
INFO - 2017-07-04 05:35:28 --> Model Class Initialized
INFO - 2017-07-04 05:35:28 --> Helper loaded: form_helper
INFO - 2017-07-04 05:35:28 --> Helper loaded: url_helper
INFO - 2017-07-04 05:35:28 --> Model Class Initialized
INFO - 2017-07-04 05:35:28 --> Final output sent to browser
DEBUG - 2017-07-04 05:35:28 --> Total execution time: 0.0500
ERROR - 2017-07-04 05:35:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:35:29 --> Config Class Initialized
INFO - 2017-07-04 05:35:29 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:35:29 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:35:29 --> Utf8 Class Initialized
INFO - 2017-07-04 05:35:29 --> URI Class Initialized
INFO - 2017-07-04 05:35:29 --> Router Class Initialized
INFO - 2017-07-04 05:35:29 --> Output Class Initialized
INFO - 2017-07-04 05:35:29 --> Security Class Initialized
DEBUG - 2017-07-04 05:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:35:29 --> Input Class Initialized
INFO - 2017-07-04 05:35:29 --> Language Class Initialized
INFO - 2017-07-04 05:35:29 --> Loader Class Initialized
INFO - 2017-07-04 05:35:29 --> Controller Class Initialized
INFO - 2017-07-04 05:35:29 --> Database Driver Class Initialized
INFO - 2017-07-04 05:35:29 --> Model Class Initialized
INFO - 2017-07-04 05:35:29 --> Helper loaded: form_helper
INFO - 2017-07-04 05:35:29 --> Helper loaded: url_helper
INFO - 2017-07-04 05:35:29 --> Model Class Initialized
INFO - 2017-07-04 05:35:29 --> Final output sent to browser
DEBUG - 2017-07-04 05:35:29 --> Total execution time: 0.0460
ERROR - 2017-07-04 05:35:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:35:34 --> Config Class Initialized
INFO - 2017-07-04 05:35:34 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:35:34 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:35:34 --> Utf8 Class Initialized
INFO - 2017-07-04 05:35:34 --> URI Class Initialized
INFO - 2017-07-04 05:35:34 --> Router Class Initialized
INFO - 2017-07-04 05:35:34 --> Output Class Initialized
INFO - 2017-07-04 05:35:34 --> Security Class Initialized
DEBUG - 2017-07-04 05:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:35:34 --> Input Class Initialized
INFO - 2017-07-04 05:35:34 --> Language Class Initialized
INFO - 2017-07-04 05:35:34 --> Loader Class Initialized
INFO - 2017-07-04 05:35:34 --> Controller Class Initialized
INFO - 2017-07-04 05:35:34 --> Database Driver Class Initialized
INFO - 2017-07-04 05:35:34 --> Model Class Initialized
INFO - 2017-07-04 05:35:34 --> Helper loaded: form_helper
INFO - 2017-07-04 05:35:34 --> Helper loaded: url_helper
INFO - 2017-07-04 05:35:34 --> Model Class Initialized
INFO - 2017-07-04 05:35:34 --> Final output sent to browser
DEBUG - 2017-07-04 05:35:34 --> Total execution time: 0.0530
ERROR - 2017-07-04 05:35:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:35:36 --> Config Class Initialized
INFO - 2017-07-04 05:35:36 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:35:36 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:35:36 --> Utf8 Class Initialized
INFO - 2017-07-04 05:35:36 --> URI Class Initialized
INFO - 2017-07-04 05:35:36 --> Router Class Initialized
INFO - 2017-07-04 05:35:36 --> Output Class Initialized
INFO - 2017-07-04 05:35:36 --> Security Class Initialized
DEBUG - 2017-07-04 05:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:35:36 --> Input Class Initialized
INFO - 2017-07-04 05:35:36 --> Language Class Initialized
INFO - 2017-07-04 05:35:36 --> Loader Class Initialized
INFO - 2017-07-04 05:35:36 --> Controller Class Initialized
INFO - 2017-07-04 05:35:36 --> Database Driver Class Initialized
INFO - 2017-07-04 05:35:36 --> Model Class Initialized
INFO - 2017-07-04 05:35:36 --> Helper loaded: form_helper
INFO - 2017-07-04 05:35:36 --> Helper loaded: url_helper
INFO - 2017-07-04 05:35:36 --> Model Class Initialized
INFO - 2017-07-04 05:35:37 --> Final output sent to browser
DEBUG - 2017-07-04 05:35:37 --> Total execution time: 0.1910
ERROR - 2017-07-04 05:36:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:36:26 --> Config Class Initialized
INFO - 2017-07-04 05:36:26 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:36:26 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:36:26 --> Utf8 Class Initialized
INFO - 2017-07-04 05:36:26 --> URI Class Initialized
INFO - 2017-07-04 05:36:26 --> Router Class Initialized
INFO - 2017-07-04 05:36:26 --> Output Class Initialized
INFO - 2017-07-04 05:36:26 --> Security Class Initialized
DEBUG - 2017-07-04 05:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:36:26 --> Input Class Initialized
INFO - 2017-07-04 05:36:26 --> Language Class Initialized
INFO - 2017-07-04 05:36:26 --> Loader Class Initialized
INFO - 2017-07-04 05:36:26 --> Controller Class Initialized
INFO - 2017-07-04 05:36:26 --> Database Driver Class Initialized
INFO - 2017-07-04 05:36:26 --> Model Class Initialized
INFO - 2017-07-04 05:36:26 --> Helper loaded: form_helper
INFO - 2017-07-04 05:36:26 --> Helper loaded: url_helper
INFO - 2017-07-04 05:36:26 --> Model Class Initialized
INFO - 2017-07-04 05:36:26 --> Final output sent to browser
DEBUG - 2017-07-04 05:36:26 --> Total execution time: 0.0580
ERROR - 2017-07-04 05:36:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:36:27 --> Config Class Initialized
INFO - 2017-07-04 05:36:27 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:36:27 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:36:27 --> Utf8 Class Initialized
INFO - 2017-07-04 05:36:27 --> URI Class Initialized
INFO - 2017-07-04 05:36:27 --> Router Class Initialized
INFO - 2017-07-04 05:36:27 --> Output Class Initialized
INFO - 2017-07-04 05:36:27 --> Security Class Initialized
DEBUG - 2017-07-04 05:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:36:27 --> Input Class Initialized
INFO - 2017-07-04 05:36:27 --> Language Class Initialized
INFO - 2017-07-04 05:36:27 --> Loader Class Initialized
INFO - 2017-07-04 05:36:27 --> Controller Class Initialized
INFO - 2017-07-04 05:36:27 --> Database Driver Class Initialized
INFO - 2017-07-04 05:36:27 --> Model Class Initialized
INFO - 2017-07-04 05:36:27 --> Helper loaded: form_helper
INFO - 2017-07-04 05:36:27 --> Helper loaded: url_helper
INFO - 2017-07-04 05:36:27 --> Model Class Initialized
INFO - 2017-07-04 05:36:27 --> Final output sent to browser
DEBUG - 2017-07-04 05:36:27 --> Total execution time: 0.0450
ERROR - 2017-07-04 05:36:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:36:28 --> Config Class Initialized
INFO - 2017-07-04 05:36:28 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:36:28 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:36:28 --> Utf8 Class Initialized
INFO - 2017-07-04 05:36:28 --> URI Class Initialized
INFO - 2017-07-04 05:36:28 --> Router Class Initialized
INFO - 2017-07-04 05:36:28 --> Output Class Initialized
INFO - 2017-07-04 05:36:28 --> Security Class Initialized
DEBUG - 2017-07-04 05:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:36:28 --> Input Class Initialized
INFO - 2017-07-04 05:36:28 --> Language Class Initialized
INFO - 2017-07-04 05:36:28 --> Loader Class Initialized
INFO - 2017-07-04 05:36:28 --> Controller Class Initialized
INFO - 2017-07-04 05:36:28 --> Database Driver Class Initialized
INFO - 2017-07-04 05:36:28 --> Model Class Initialized
INFO - 2017-07-04 05:36:28 --> Helper loaded: form_helper
INFO - 2017-07-04 05:36:28 --> Helper loaded: url_helper
INFO - 2017-07-04 05:36:28 --> Model Class Initialized
INFO - 2017-07-04 05:36:28 --> Final output sent to browser
DEBUG - 2017-07-04 05:36:28 --> Total execution time: 0.1320
ERROR - 2017-07-04 05:36:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:36:38 --> Config Class Initialized
INFO - 2017-07-04 05:36:38 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:36:38 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:36:38 --> Utf8 Class Initialized
INFO - 2017-07-04 05:36:38 --> URI Class Initialized
INFO - 2017-07-04 05:36:38 --> Router Class Initialized
INFO - 2017-07-04 05:36:38 --> Output Class Initialized
INFO - 2017-07-04 05:36:38 --> Security Class Initialized
DEBUG - 2017-07-04 05:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:36:38 --> Input Class Initialized
INFO - 2017-07-04 05:36:38 --> Language Class Initialized
INFO - 2017-07-04 05:36:38 --> Loader Class Initialized
INFO - 2017-07-04 05:36:38 --> Controller Class Initialized
INFO - 2017-07-04 05:36:38 --> Database Driver Class Initialized
INFO - 2017-07-04 05:36:38 --> Model Class Initialized
INFO - 2017-07-04 05:36:38 --> Helper loaded: form_helper
INFO - 2017-07-04 05:36:38 --> Helper loaded: url_helper
INFO - 2017-07-04 05:36:38 --> Model Class Initialized
INFO - 2017-07-04 05:36:38 --> Final output sent to browser
DEBUG - 2017-07-04 05:36:38 --> Total execution time: 0.0460
ERROR - 2017-07-04 05:36:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:36:44 --> Config Class Initialized
INFO - 2017-07-04 05:36:44 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:36:44 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:36:44 --> Utf8 Class Initialized
INFO - 2017-07-04 05:36:44 --> URI Class Initialized
INFO - 2017-07-04 05:36:44 --> Router Class Initialized
INFO - 2017-07-04 05:36:44 --> Output Class Initialized
INFO - 2017-07-04 05:36:44 --> Security Class Initialized
DEBUG - 2017-07-04 05:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:36:44 --> Input Class Initialized
INFO - 2017-07-04 05:36:44 --> Language Class Initialized
INFO - 2017-07-04 05:36:44 --> Loader Class Initialized
INFO - 2017-07-04 05:36:44 --> Controller Class Initialized
INFO - 2017-07-04 05:36:44 --> Database Driver Class Initialized
INFO - 2017-07-04 05:36:44 --> Model Class Initialized
INFO - 2017-07-04 05:36:44 --> Helper loaded: form_helper
INFO - 2017-07-04 05:36:44 --> Helper loaded: url_helper
INFO - 2017-07-04 05:36:44 --> Model Class Initialized
INFO - 2017-07-04 05:36:44 --> Final output sent to browser
DEBUG - 2017-07-04 05:36:44 --> Total execution time: 0.0660
ERROR - 2017-07-04 05:36:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:36:49 --> Config Class Initialized
INFO - 2017-07-04 05:36:49 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:36:49 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:36:49 --> Utf8 Class Initialized
INFO - 2017-07-04 05:36:49 --> URI Class Initialized
INFO - 2017-07-04 05:36:49 --> Router Class Initialized
INFO - 2017-07-04 05:36:49 --> Output Class Initialized
INFO - 2017-07-04 05:36:49 --> Security Class Initialized
DEBUG - 2017-07-04 05:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:36:49 --> Input Class Initialized
INFO - 2017-07-04 05:36:49 --> Language Class Initialized
INFO - 2017-07-04 05:36:49 --> Loader Class Initialized
INFO - 2017-07-04 05:36:49 --> Controller Class Initialized
INFO - 2017-07-04 05:36:49 --> Database Driver Class Initialized
INFO - 2017-07-04 05:36:49 --> Model Class Initialized
INFO - 2017-07-04 05:36:49 --> Helper loaded: form_helper
INFO - 2017-07-04 05:36:49 --> Helper loaded: url_helper
INFO - 2017-07-04 05:36:49 --> Model Class Initialized
INFO - 2017-07-04 05:36:49 --> Final output sent to browser
DEBUG - 2017-07-04 05:36:49 --> Total execution time: 0.0610
ERROR - 2017-07-04 05:36:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:36:52 --> Config Class Initialized
INFO - 2017-07-04 05:36:52 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:36:52 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:36:52 --> Utf8 Class Initialized
INFO - 2017-07-04 05:36:52 --> URI Class Initialized
INFO - 2017-07-04 05:36:52 --> Router Class Initialized
INFO - 2017-07-04 05:36:52 --> Output Class Initialized
INFO - 2017-07-04 05:36:52 --> Security Class Initialized
DEBUG - 2017-07-04 05:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:36:52 --> Input Class Initialized
INFO - 2017-07-04 05:36:52 --> Language Class Initialized
INFO - 2017-07-04 05:36:52 --> Loader Class Initialized
INFO - 2017-07-04 05:36:52 --> Controller Class Initialized
INFO - 2017-07-04 05:36:52 --> Database Driver Class Initialized
INFO - 2017-07-04 05:36:53 --> Model Class Initialized
INFO - 2017-07-04 05:36:53 --> Helper loaded: form_helper
INFO - 2017-07-04 05:36:53 --> Helper loaded: url_helper
INFO - 2017-07-04 05:36:53 --> Model Class Initialized
INFO - 2017-07-04 05:36:53 --> Final output sent to browser
DEBUG - 2017-07-04 05:36:53 --> Total execution time: 0.0620
ERROR - 2017-07-04 05:37:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:37:48 --> Config Class Initialized
INFO - 2017-07-04 05:37:48 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:37:48 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:37:48 --> Utf8 Class Initialized
INFO - 2017-07-04 05:37:48 --> URI Class Initialized
INFO - 2017-07-04 05:37:48 --> Router Class Initialized
INFO - 2017-07-04 05:37:48 --> Output Class Initialized
INFO - 2017-07-04 05:37:48 --> Security Class Initialized
DEBUG - 2017-07-04 05:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:37:48 --> Input Class Initialized
INFO - 2017-07-04 05:37:48 --> Language Class Initialized
INFO - 2017-07-04 05:37:48 --> Loader Class Initialized
INFO - 2017-07-04 05:37:48 --> Controller Class Initialized
INFO - 2017-07-04 05:37:48 --> Database Driver Class Initialized
INFO - 2017-07-04 05:37:48 --> Model Class Initialized
INFO - 2017-07-04 05:37:48 --> Helper loaded: form_helper
INFO - 2017-07-04 05:37:48 --> Helper loaded: url_helper
INFO - 2017-07-04 05:37:48 --> Model Class Initialized
INFO - 2017-07-04 05:37:48 --> Final output sent to browser
DEBUG - 2017-07-04 05:37:48 --> Total execution time: 0.0490
ERROR - 2017-07-04 05:37:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 05:37:49 --> Config Class Initialized
INFO - 2017-07-04 05:37:49 --> Hooks Class Initialized
DEBUG - 2017-07-04 05:37:49 --> UTF-8 Support Enabled
INFO - 2017-07-04 05:37:49 --> Utf8 Class Initialized
INFO - 2017-07-04 05:37:49 --> URI Class Initialized
INFO - 2017-07-04 05:37:49 --> Router Class Initialized
INFO - 2017-07-04 05:37:49 --> Output Class Initialized
INFO - 2017-07-04 05:37:49 --> Security Class Initialized
DEBUG - 2017-07-04 05:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 05:37:49 --> Input Class Initialized
INFO - 2017-07-04 05:37:49 --> Language Class Initialized
INFO - 2017-07-04 05:37:49 --> Loader Class Initialized
INFO - 2017-07-04 05:37:49 --> Controller Class Initialized
INFO - 2017-07-04 05:37:49 --> Database Driver Class Initialized
INFO - 2017-07-04 05:37:49 --> Model Class Initialized
INFO - 2017-07-04 05:37:49 --> Helper loaded: form_helper
INFO - 2017-07-04 05:37:49 --> Helper loaded: url_helper
INFO - 2017-07-04 05:37:49 --> Model Class Initialized
INFO - 2017-07-04 05:37:49 --> Final output sent to browser
DEBUG - 2017-07-04 05:37:49 --> Total execution time: 0.0560
ERROR - 2017-07-04 14:17:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 14:17:04 --> Config Class Initialized
INFO - 2017-07-04 14:17:04 --> Hooks Class Initialized
DEBUG - 2017-07-04 14:17:04 --> UTF-8 Support Enabled
INFO - 2017-07-04 14:17:04 --> Utf8 Class Initialized
INFO - 2017-07-04 14:17:04 --> URI Class Initialized
INFO - 2017-07-04 14:17:04 --> Router Class Initialized
INFO - 2017-07-04 14:17:04 --> Output Class Initialized
INFO - 2017-07-04 14:17:04 --> Security Class Initialized
DEBUG - 2017-07-04 14:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 14:17:04 --> Input Class Initialized
INFO - 2017-07-04 14:17:04 --> Language Class Initialized
INFO - 2017-07-04 14:17:04 --> Loader Class Initialized
INFO - 2017-07-04 14:17:04 --> Controller Class Initialized
INFO - 2017-07-04 14:17:04 --> Database Driver Class Initialized
INFO - 2017-07-04 14:17:04 --> Model Class Initialized
INFO - 2017-07-04 14:17:04 --> Helper loaded: form_helper
INFO - 2017-07-04 14:17:04 --> Helper loaded: url_helper
INFO - 2017-07-04 14:17:04 --> Model Class Initialized
INFO - 2017-07-04 14:17:04 --> Final output sent to browser
DEBUG - 2017-07-04 14:17:04 --> Total execution time: 0.0510
ERROR - 2017-07-04 14:17:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 14:17:07 --> Config Class Initialized
INFO - 2017-07-04 14:17:07 --> Hooks Class Initialized
DEBUG - 2017-07-04 14:17:07 --> UTF-8 Support Enabled
INFO - 2017-07-04 14:17:07 --> Utf8 Class Initialized
INFO - 2017-07-04 14:17:07 --> URI Class Initialized
INFO - 2017-07-04 14:17:07 --> Router Class Initialized
INFO - 2017-07-04 14:17:07 --> Output Class Initialized
INFO - 2017-07-04 14:17:07 --> Security Class Initialized
DEBUG - 2017-07-04 14:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 14:17:07 --> Input Class Initialized
INFO - 2017-07-04 14:17:07 --> Language Class Initialized
INFO - 2017-07-04 14:17:07 --> Loader Class Initialized
INFO - 2017-07-04 14:17:07 --> Controller Class Initialized
INFO - 2017-07-04 14:17:07 --> Database Driver Class Initialized
INFO - 2017-07-04 14:17:07 --> Model Class Initialized
INFO - 2017-07-04 14:17:07 --> Helper loaded: form_helper
INFO - 2017-07-04 14:17:07 --> Helper loaded: url_helper
INFO - 2017-07-04 14:17:07 --> Model Class Initialized
INFO - 2017-07-04 14:17:07 --> Final output sent to browser
DEBUG - 2017-07-04 14:17:07 --> Total execution time: 0.0510
ERROR - 2017-07-04 14:17:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 14:17:28 --> Config Class Initialized
INFO - 2017-07-04 14:17:28 --> Hooks Class Initialized
DEBUG - 2017-07-04 14:17:28 --> UTF-8 Support Enabled
INFO - 2017-07-04 14:17:28 --> Utf8 Class Initialized
INFO - 2017-07-04 14:17:28 --> URI Class Initialized
INFO - 2017-07-04 14:17:28 --> Router Class Initialized
INFO - 2017-07-04 14:17:28 --> Output Class Initialized
INFO - 2017-07-04 14:17:28 --> Security Class Initialized
DEBUG - 2017-07-04 14:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 14:17:28 --> Input Class Initialized
INFO - 2017-07-04 14:17:28 --> Language Class Initialized
INFO - 2017-07-04 14:17:28 --> Loader Class Initialized
INFO - 2017-07-04 14:17:28 --> Controller Class Initialized
INFO - 2017-07-04 14:17:28 --> Database Driver Class Initialized
INFO - 2017-07-04 14:17:28 --> Model Class Initialized
INFO - 2017-07-04 14:17:28 --> Helper loaded: form_helper
INFO - 2017-07-04 14:17:28 --> Helper loaded: url_helper
INFO - 2017-07-04 14:17:28 --> Model Class Initialized
INFO - 2017-07-04 14:17:28 --> Final output sent to browser
DEBUG - 2017-07-04 14:17:28 --> Total execution time: 0.1040
ERROR - 2017-07-04 14:17:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 14:17:39 --> Config Class Initialized
INFO - 2017-07-04 14:17:39 --> Hooks Class Initialized
DEBUG - 2017-07-04 14:17:39 --> UTF-8 Support Enabled
INFO - 2017-07-04 14:17:39 --> Utf8 Class Initialized
INFO - 2017-07-04 14:17:39 --> URI Class Initialized
INFO - 2017-07-04 14:17:39 --> Router Class Initialized
INFO - 2017-07-04 14:17:39 --> Output Class Initialized
INFO - 2017-07-04 14:17:39 --> Security Class Initialized
DEBUG - 2017-07-04 14:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 14:17:39 --> Input Class Initialized
INFO - 2017-07-04 14:17:39 --> Language Class Initialized
INFO - 2017-07-04 14:17:39 --> Loader Class Initialized
INFO - 2017-07-04 14:17:39 --> Controller Class Initialized
INFO - 2017-07-04 14:17:39 --> Database Driver Class Initialized
INFO - 2017-07-04 14:17:39 --> Model Class Initialized
INFO - 2017-07-04 14:17:39 --> Helper loaded: form_helper
INFO - 2017-07-04 14:17:39 --> Helper loaded: url_helper
INFO - 2017-07-04 14:17:39 --> Model Class Initialized
INFO - 2017-07-04 14:17:39 --> Final output sent to browser
DEBUG - 2017-07-04 14:17:39 --> Total execution time: 0.0950
ERROR - 2017-07-04 14:17:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 14:17:40 --> Config Class Initialized
INFO - 2017-07-04 14:17:40 --> Hooks Class Initialized
DEBUG - 2017-07-04 14:17:40 --> UTF-8 Support Enabled
INFO - 2017-07-04 14:17:40 --> Utf8 Class Initialized
INFO - 2017-07-04 14:17:40 --> URI Class Initialized
INFO - 2017-07-04 14:17:40 --> Router Class Initialized
INFO - 2017-07-04 14:17:40 --> Output Class Initialized
INFO - 2017-07-04 14:17:40 --> Security Class Initialized
DEBUG - 2017-07-04 14:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 14:17:40 --> Input Class Initialized
INFO - 2017-07-04 14:17:40 --> Language Class Initialized
INFO - 2017-07-04 14:17:40 --> Loader Class Initialized
INFO - 2017-07-04 14:17:40 --> Controller Class Initialized
INFO - 2017-07-04 14:17:40 --> Database Driver Class Initialized
INFO - 2017-07-04 14:17:40 --> Model Class Initialized
INFO - 2017-07-04 14:17:40 --> Helper loaded: form_helper
INFO - 2017-07-04 14:17:40 --> Helper loaded: url_helper
INFO - 2017-07-04 14:17:40 --> Model Class Initialized
INFO - 2017-07-04 14:17:40 --> Final output sent to browser
DEBUG - 2017-07-04 14:17:40 --> Total execution time: 0.0550
ERROR - 2017-07-04 14:17:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 14:17:48 --> Config Class Initialized
INFO - 2017-07-04 14:17:48 --> Hooks Class Initialized
DEBUG - 2017-07-04 14:17:48 --> UTF-8 Support Enabled
INFO - 2017-07-04 14:17:48 --> Utf8 Class Initialized
INFO - 2017-07-04 14:17:48 --> URI Class Initialized
INFO - 2017-07-04 14:17:48 --> Router Class Initialized
INFO - 2017-07-04 14:17:48 --> Output Class Initialized
INFO - 2017-07-04 14:17:48 --> Security Class Initialized
DEBUG - 2017-07-04 14:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 14:17:48 --> Input Class Initialized
INFO - 2017-07-04 14:17:48 --> Language Class Initialized
INFO - 2017-07-04 14:17:48 --> Loader Class Initialized
INFO - 2017-07-04 14:17:48 --> Controller Class Initialized
INFO - 2017-07-04 14:17:48 --> Database Driver Class Initialized
INFO - 2017-07-04 14:17:48 --> Model Class Initialized
INFO - 2017-07-04 14:17:48 --> Helper loaded: form_helper
INFO - 2017-07-04 14:17:48 --> Helper loaded: url_helper
INFO - 2017-07-04 14:17:48 --> Model Class Initialized
INFO - 2017-07-04 14:17:48 --> Final output sent to browser
DEBUG - 2017-07-04 14:17:48 --> Total execution time: 0.0470
ERROR - 2017-07-04 14:17:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 14:17:56 --> Config Class Initialized
INFO - 2017-07-04 14:17:56 --> Hooks Class Initialized
DEBUG - 2017-07-04 14:17:56 --> UTF-8 Support Enabled
INFO - 2017-07-04 14:17:56 --> Utf8 Class Initialized
INFO - 2017-07-04 14:17:56 --> URI Class Initialized
INFO - 2017-07-04 14:17:56 --> Router Class Initialized
INFO - 2017-07-04 14:17:56 --> Output Class Initialized
INFO - 2017-07-04 14:17:56 --> Security Class Initialized
DEBUG - 2017-07-04 14:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 14:17:56 --> Input Class Initialized
INFO - 2017-07-04 14:17:56 --> Language Class Initialized
INFO - 2017-07-04 14:17:56 --> Loader Class Initialized
INFO - 2017-07-04 14:17:56 --> Controller Class Initialized
INFO - 2017-07-04 14:17:56 --> Database Driver Class Initialized
INFO - 2017-07-04 14:17:56 --> Model Class Initialized
INFO - 2017-07-04 14:17:56 --> Helper loaded: form_helper
INFO - 2017-07-04 14:17:56 --> Helper loaded: url_helper
INFO - 2017-07-04 14:17:56 --> Model Class Initialized
INFO - 2017-07-04 14:17:56 --> Final output sent to browser
DEBUG - 2017-07-04 14:17:56 --> Total execution time: 0.0460
ERROR - 2017-07-04 14:18:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 14:18:27 --> Config Class Initialized
INFO - 2017-07-04 14:18:27 --> Hooks Class Initialized
DEBUG - 2017-07-04 14:18:27 --> UTF-8 Support Enabled
INFO - 2017-07-04 14:18:27 --> Utf8 Class Initialized
INFO - 2017-07-04 14:18:27 --> URI Class Initialized
INFO - 2017-07-04 14:18:27 --> Router Class Initialized
INFO - 2017-07-04 14:18:27 --> Output Class Initialized
INFO - 2017-07-04 14:18:27 --> Security Class Initialized
DEBUG - 2017-07-04 14:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 14:18:27 --> Input Class Initialized
INFO - 2017-07-04 14:18:27 --> Language Class Initialized
INFO - 2017-07-04 14:18:27 --> Loader Class Initialized
INFO - 2017-07-04 14:18:27 --> Controller Class Initialized
INFO - 2017-07-04 14:18:27 --> Database Driver Class Initialized
INFO - 2017-07-04 14:18:27 --> Model Class Initialized
INFO - 2017-07-04 14:18:27 --> Helper loaded: form_helper
INFO - 2017-07-04 14:18:27 --> Helper loaded: url_helper
INFO - 2017-07-04 14:18:27 --> Model Class Initialized
INFO - 2017-07-04 14:18:27 --> Final output sent to browser
DEBUG - 2017-07-04 14:18:27 --> Total execution time: 0.0560
ERROR - 2017-07-04 16:36:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 16:36:34 --> Config Class Initialized
INFO - 2017-07-04 16:36:34 --> Hooks Class Initialized
DEBUG - 2017-07-04 16:36:34 --> UTF-8 Support Enabled
INFO - 2017-07-04 16:36:34 --> Utf8 Class Initialized
INFO - 2017-07-04 16:36:34 --> URI Class Initialized
DEBUG - 2017-07-04 16:36:34 --> No URI present. Default controller set.
INFO - 2017-07-04 16:36:34 --> Router Class Initialized
INFO - 2017-07-04 16:36:34 --> Output Class Initialized
INFO - 2017-07-04 16:36:34 --> Security Class Initialized
DEBUG - 2017-07-04 16:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 16:36:34 --> Input Class Initialized
INFO - 2017-07-04 16:36:34 --> Language Class Initialized
INFO - 2017-07-04 16:36:34 --> Loader Class Initialized
INFO - 2017-07-04 16:36:34 --> Controller Class Initialized
INFO - 2017-07-04 16:36:34 --> Database Driver Class Initialized
INFO - 2017-07-04 16:36:34 --> Model Class Initialized
INFO - 2017-07-04 16:36:34 --> Helper loaded: form_helper
INFO - 2017-07-04 16:36:34 --> Helper loaded: url_helper
INFO - 2017-07-04 16:36:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-04 16:36:34 --> Final output sent to browser
DEBUG - 2017-07-04 16:36:34 --> Total execution time: 0.1480
ERROR - 2017-07-04 16:36:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 16:36:40 --> Config Class Initialized
INFO - 2017-07-04 16:36:40 --> Hooks Class Initialized
DEBUG - 2017-07-04 16:36:40 --> UTF-8 Support Enabled
INFO - 2017-07-04 16:36:40 --> Utf8 Class Initialized
INFO - 2017-07-04 16:36:40 --> URI Class Initialized
INFO - 2017-07-04 16:36:40 --> Router Class Initialized
INFO - 2017-07-04 16:36:40 --> Output Class Initialized
INFO - 2017-07-04 16:36:40 --> Security Class Initialized
DEBUG - 2017-07-04 16:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 16:36:40 --> Input Class Initialized
INFO - 2017-07-04 16:36:40 --> Language Class Initialized
INFO - 2017-07-04 16:36:40 --> Loader Class Initialized
INFO - 2017-07-04 16:36:40 --> Controller Class Initialized
INFO - 2017-07-04 16:36:40 --> Database Driver Class Initialized
INFO - 2017-07-04 16:36:40 --> Model Class Initialized
INFO - 2017-07-04 16:36:40 --> Helper loaded: form_helper
INFO - 2017-07-04 16:36:40 --> Helper loaded: url_helper
INFO - 2017-07-04 16:36:40 --> Model Class Initialized
ERROR - 2017-07-04 16:36:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 16:36:40 --> Config Class Initialized
INFO - 2017-07-04 16:36:40 --> Hooks Class Initialized
DEBUG - 2017-07-04 16:36:40 --> UTF-8 Support Enabled
INFO - 2017-07-04 16:36:40 --> Utf8 Class Initialized
INFO - 2017-07-04 16:36:40 --> URI Class Initialized
INFO - 2017-07-04 16:36:40 --> Router Class Initialized
INFO - 2017-07-04 16:36:40 --> Output Class Initialized
INFO - 2017-07-04 16:36:40 --> Security Class Initialized
DEBUG - 2017-07-04 16:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 16:36:40 --> Input Class Initialized
INFO - 2017-07-04 16:36:40 --> Language Class Initialized
INFO - 2017-07-04 16:36:40 --> Loader Class Initialized
INFO - 2017-07-04 16:36:40 --> Controller Class Initialized
INFO - 2017-07-04 16:36:40 --> Database Driver Class Initialized
INFO - 2017-07-04 16:36:40 --> Model Class Initialized
INFO - 2017-07-04 16:36:40 --> Helper loaded: form_helper
INFO - 2017-07-04 16:36:40 --> Helper loaded: url_helper
INFO - 2017-07-04 16:36:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 16:36:40 --> Model Class Initialized
INFO - 2017-07-04 16:36:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-04 16:36:40 --> Final output sent to browser
DEBUG - 2017-07-04 16:36:40 --> Total execution time: 0.1270
ERROR - 2017-07-04 16:37:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 16:37:28 --> Config Class Initialized
INFO - 2017-07-04 16:37:28 --> Hooks Class Initialized
DEBUG - 2017-07-04 16:37:28 --> UTF-8 Support Enabled
INFO - 2017-07-04 16:37:28 --> Utf8 Class Initialized
INFO - 2017-07-04 16:37:28 --> URI Class Initialized
INFO - 2017-07-04 16:37:28 --> Router Class Initialized
INFO - 2017-07-04 16:37:28 --> Output Class Initialized
INFO - 2017-07-04 16:37:28 --> Security Class Initialized
DEBUG - 2017-07-04 16:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 16:37:28 --> Input Class Initialized
INFO - 2017-07-04 16:37:28 --> Language Class Initialized
INFO - 2017-07-04 16:37:28 --> Loader Class Initialized
INFO - 2017-07-04 16:37:28 --> Controller Class Initialized
INFO - 2017-07-04 16:37:28 --> Database Driver Class Initialized
INFO - 2017-07-04 16:37:28 --> Model Class Initialized
INFO - 2017-07-04 16:37:28 --> Helper loaded: form_helper
INFO - 2017-07-04 16:37:28 --> Helper loaded: url_helper
INFO - 2017-07-04 16:37:28 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 16:37:28 --> Model Class Initialized
INFO - 2017-07-04 16:37:28 --> File loaded: C:\xampp\htdocs\mystage\application\views\users.php
INFO - 2017-07-04 16:37:28 --> Final output sent to browser
DEBUG - 2017-07-04 16:37:28 --> Total execution time: 0.0940
ERROR - 2017-07-04 16:37:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 16:37:31 --> Config Class Initialized
INFO - 2017-07-04 16:37:31 --> Hooks Class Initialized
DEBUG - 2017-07-04 16:37:31 --> UTF-8 Support Enabled
INFO - 2017-07-04 16:37:31 --> Utf8 Class Initialized
INFO - 2017-07-04 16:37:31 --> URI Class Initialized
INFO - 2017-07-04 16:37:31 --> Router Class Initialized
INFO - 2017-07-04 16:37:31 --> Output Class Initialized
INFO - 2017-07-04 16:37:31 --> Security Class Initialized
DEBUG - 2017-07-04 16:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 16:37:31 --> Input Class Initialized
INFO - 2017-07-04 16:37:31 --> Language Class Initialized
INFO - 2017-07-04 16:37:31 --> Loader Class Initialized
INFO - 2017-07-04 16:37:31 --> Controller Class Initialized
INFO - 2017-07-04 16:37:31 --> Database Driver Class Initialized
INFO - 2017-07-04 16:37:31 --> Model Class Initialized
INFO - 2017-07-04 16:37:31 --> Helper loaded: form_helper
INFO - 2017-07-04 16:37:31 --> Helper loaded: url_helper
INFO - 2017-07-04 16:37:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 16:37:31 --> Model Class Initialized
INFO - 2017-07-04 16:37:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-04 16:37:31 --> Final output sent to browser
DEBUG - 2017-07-04 16:37:31 --> Total execution time: 0.1200
ERROR - 2017-07-04 18:18:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:18:26 --> Config Class Initialized
INFO - 2017-07-04 18:18:26 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:18:26 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:18:26 --> Utf8 Class Initialized
INFO - 2017-07-04 18:18:26 --> URI Class Initialized
INFO - 2017-07-04 18:18:26 --> Router Class Initialized
INFO - 2017-07-04 18:18:26 --> Output Class Initialized
INFO - 2017-07-04 18:18:26 --> Security Class Initialized
DEBUG - 2017-07-04 18:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:18:26 --> Input Class Initialized
INFO - 2017-07-04 18:18:26 --> Language Class Initialized
INFO - 2017-07-04 18:18:26 --> Loader Class Initialized
INFO - 2017-07-04 18:18:26 --> Controller Class Initialized
INFO - 2017-07-04 18:18:26 --> Database Driver Class Initialized
INFO - 2017-07-04 18:18:26 --> Model Class Initialized
INFO - 2017-07-04 18:18:26 --> Helper loaded: form_helper
INFO - 2017-07-04 18:18:26 --> Helper loaded: url_helper
INFO - 2017-07-04 18:18:26 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 18:18:26 --> Model Class Initialized
INFO - 2017-07-04 18:18:26 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-04 18:18:26 --> Final output sent to browser
DEBUG - 2017-07-04 18:18:26 --> Total execution time: 0.0680
ERROR - 2017-07-04 18:19:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:19:52 --> Config Class Initialized
INFO - 2017-07-04 18:19:52 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:19:52 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:19:52 --> Utf8 Class Initialized
INFO - 2017-07-04 18:19:52 --> URI Class Initialized
INFO - 2017-07-04 18:19:52 --> Router Class Initialized
INFO - 2017-07-04 18:19:52 --> Output Class Initialized
INFO - 2017-07-04 18:19:52 --> Security Class Initialized
DEBUG - 2017-07-04 18:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:19:52 --> Input Class Initialized
INFO - 2017-07-04 18:19:52 --> Language Class Initialized
INFO - 2017-07-04 18:19:52 --> Loader Class Initialized
INFO - 2017-07-04 18:19:52 --> Controller Class Initialized
INFO - 2017-07-04 18:19:52 --> Database Driver Class Initialized
INFO - 2017-07-04 18:19:52 --> Model Class Initialized
INFO - 2017-07-04 18:19:52 --> Helper loaded: form_helper
INFO - 2017-07-04 18:19:52 --> Helper loaded: url_helper
INFO - 2017-07-04 18:19:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 18:19:52 --> Model Class Initialized
INFO - 2017-07-04 18:19:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-04 18:19:52 --> Final output sent to browser
DEBUG - 2017-07-04 18:19:52 --> Total execution time: 0.0490
ERROR - 2017-07-04 18:19:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:19:55 --> Config Class Initialized
INFO - 2017-07-04 18:19:55 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:19:55 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:19:55 --> Utf8 Class Initialized
INFO - 2017-07-04 18:19:55 --> URI Class Initialized
INFO - 2017-07-04 18:19:55 --> Router Class Initialized
INFO - 2017-07-04 18:19:55 --> Output Class Initialized
INFO - 2017-07-04 18:19:55 --> Security Class Initialized
DEBUG - 2017-07-04 18:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:19:55 --> Input Class Initialized
INFO - 2017-07-04 18:19:55 --> Language Class Initialized
INFO - 2017-07-04 18:19:55 --> Loader Class Initialized
INFO - 2017-07-04 18:19:55 --> Controller Class Initialized
INFO - 2017-07-04 18:19:55 --> Database Driver Class Initialized
INFO - 2017-07-04 18:19:55 --> Model Class Initialized
INFO - 2017-07-04 18:19:55 --> Helper loaded: form_helper
INFO - 2017-07-04 18:19:55 --> Helper loaded: url_helper
INFO - 2017-07-04 18:19:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 18:19:55 --> Model Class Initialized
INFO - 2017-07-04 18:19:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\purchase.php
INFO - 2017-07-04 18:19:55 --> Final output sent to browser
DEBUG - 2017-07-04 18:19:55 --> Total execution time: 0.1110
ERROR - 2017-07-04 18:27:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:27:00 --> Config Class Initialized
INFO - 2017-07-04 18:27:00 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:27:00 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:27:00 --> Utf8 Class Initialized
INFO - 2017-07-04 18:27:00 --> URI Class Initialized
INFO - 2017-07-04 18:27:00 --> Router Class Initialized
INFO - 2017-07-04 18:27:00 --> Output Class Initialized
INFO - 2017-07-04 18:27:00 --> Security Class Initialized
DEBUG - 2017-07-04 18:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:27:00 --> Input Class Initialized
INFO - 2017-07-04 18:27:00 --> Language Class Initialized
INFO - 2017-07-04 18:27:00 --> Loader Class Initialized
INFO - 2017-07-04 18:27:00 --> Controller Class Initialized
INFO - 2017-07-04 18:27:00 --> Database Driver Class Initialized
INFO - 2017-07-04 18:27:00 --> Model Class Initialized
INFO - 2017-07-04 18:27:00 --> Helper loaded: form_helper
INFO - 2017-07-04 18:27:00 --> Helper loaded: url_helper
INFO - 2017-07-04 18:27:00 --> Model Class Initialized
INFO - 2017-07-04 18:27:00 --> Final output sent to browser
DEBUG - 2017-07-04 18:27:00 --> Total execution time: 0.0600
ERROR - 2017-07-04 18:27:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:27:01 --> Config Class Initialized
INFO - 2017-07-04 18:27:01 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:27:01 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:27:01 --> Utf8 Class Initialized
INFO - 2017-07-04 18:27:01 --> URI Class Initialized
INFO - 2017-07-04 18:27:01 --> Router Class Initialized
INFO - 2017-07-04 18:27:01 --> Output Class Initialized
INFO - 2017-07-04 18:27:01 --> Security Class Initialized
DEBUG - 2017-07-04 18:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:27:01 --> Input Class Initialized
INFO - 2017-07-04 18:27:01 --> Language Class Initialized
INFO - 2017-07-04 18:27:01 --> Loader Class Initialized
INFO - 2017-07-04 18:27:01 --> Controller Class Initialized
INFO - 2017-07-04 18:27:01 --> Database Driver Class Initialized
INFO - 2017-07-04 18:27:01 --> Model Class Initialized
INFO - 2017-07-04 18:27:01 --> Helper loaded: form_helper
INFO - 2017-07-04 18:27:01 --> Helper loaded: url_helper
INFO - 2017-07-04 18:27:01 --> Model Class Initialized
INFO - 2017-07-04 18:27:01 --> Final output sent to browser
DEBUG - 2017-07-04 18:27:01 --> Total execution time: 0.0470
ERROR - 2017-07-04 18:27:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:27:13 --> Config Class Initialized
INFO - 2017-07-04 18:27:13 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:27:13 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:27:13 --> Utf8 Class Initialized
INFO - 2017-07-04 18:27:13 --> URI Class Initialized
INFO - 2017-07-04 18:27:13 --> Router Class Initialized
INFO - 2017-07-04 18:27:13 --> Output Class Initialized
INFO - 2017-07-04 18:27:13 --> Security Class Initialized
DEBUG - 2017-07-04 18:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:27:13 --> Input Class Initialized
INFO - 2017-07-04 18:27:13 --> Language Class Initialized
INFO - 2017-07-04 18:27:13 --> Loader Class Initialized
INFO - 2017-07-04 18:27:13 --> Controller Class Initialized
INFO - 2017-07-04 18:27:13 --> Database Driver Class Initialized
INFO - 2017-07-04 18:27:13 --> Model Class Initialized
INFO - 2017-07-04 18:27:13 --> Helper loaded: form_helper
INFO - 2017-07-04 18:27:13 --> Helper loaded: url_helper
INFO - 2017-07-04 18:27:13 --> Model Class Initialized
INFO - 2017-07-04 18:27:13 --> Final output sent to browser
DEBUG - 2017-07-04 18:27:13 --> Total execution time: 0.0460
ERROR - 2017-07-04 18:28:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:28:05 --> Config Class Initialized
INFO - 2017-07-04 18:28:05 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:28:05 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:28:05 --> Utf8 Class Initialized
INFO - 2017-07-04 18:28:05 --> URI Class Initialized
INFO - 2017-07-04 18:28:05 --> Router Class Initialized
INFO - 2017-07-04 18:28:05 --> Output Class Initialized
INFO - 2017-07-04 18:28:05 --> Security Class Initialized
DEBUG - 2017-07-04 18:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:28:05 --> Input Class Initialized
INFO - 2017-07-04 18:28:05 --> Language Class Initialized
INFO - 2017-07-04 18:28:05 --> Loader Class Initialized
INFO - 2017-07-04 18:28:05 --> Controller Class Initialized
INFO - 2017-07-04 18:28:05 --> Database Driver Class Initialized
INFO - 2017-07-04 18:28:05 --> Model Class Initialized
INFO - 2017-07-04 18:28:05 --> Helper loaded: form_helper
INFO - 2017-07-04 18:28:05 --> Helper loaded: url_helper
INFO - 2017-07-04 18:28:05 --> Model Class Initialized
INFO - 2017-07-04 18:28:05 --> Final output sent to browser
DEBUG - 2017-07-04 18:28:05 --> Total execution time: 0.0560
ERROR - 2017-07-04 18:28:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:28:05 --> Config Class Initialized
INFO - 2017-07-04 18:28:05 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:28:05 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:28:05 --> Utf8 Class Initialized
INFO - 2017-07-04 18:28:05 --> URI Class Initialized
INFO - 2017-07-04 18:28:05 --> Router Class Initialized
INFO - 2017-07-04 18:28:05 --> Output Class Initialized
INFO - 2017-07-04 18:28:05 --> Security Class Initialized
DEBUG - 2017-07-04 18:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:28:05 --> Input Class Initialized
INFO - 2017-07-04 18:28:05 --> Language Class Initialized
INFO - 2017-07-04 18:28:05 --> Loader Class Initialized
INFO - 2017-07-04 18:28:05 --> Controller Class Initialized
INFO - 2017-07-04 18:28:05 --> Database Driver Class Initialized
INFO - 2017-07-04 18:28:05 --> Model Class Initialized
INFO - 2017-07-04 18:28:05 --> Helper loaded: form_helper
INFO - 2017-07-04 18:28:05 --> Helper loaded: url_helper
INFO - 2017-07-04 18:28:05 --> Model Class Initialized
INFO - 2017-07-04 18:28:05 --> Final output sent to browser
DEBUG - 2017-07-04 18:28:05 --> Total execution time: 0.0450
ERROR - 2017-07-04 18:28:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:28:08 --> Config Class Initialized
INFO - 2017-07-04 18:28:08 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:28:08 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:28:08 --> Utf8 Class Initialized
INFO - 2017-07-04 18:28:08 --> URI Class Initialized
INFO - 2017-07-04 18:28:08 --> Router Class Initialized
INFO - 2017-07-04 18:28:08 --> Output Class Initialized
INFO - 2017-07-04 18:28:08 --> Security Class Initialized
DEBUG - 2017-07-04 18:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:28:08 --> Input Class Initialized
INFO - 2017-07-04 18:28:08 --> Language Class Initialized
INFO - 2017-07-04 18:28:08 --> Loader Class Initialized
INFO - 2017-07-04 18:28:08 --> Controller Class Initialized
INFO - 2017-07-04 18:28:08 --> Database Driver Class Initialized
INFO - 2017-07-04 18:28:08 --> Model Class Initialized
INFO - 2017-07-04 18:28:08 --> Helper loaded: form_helper
INFO - 2017-07-04 18:28:08 --> Helper loaded: url_helper
INFO - 2017-07-04 18:28:08 --> Model Class Initialized
INFO - 2017-07-04 18:28:08 --> Final output sent to browser
DEBUG - 2017-07-04 18:28:08 --> Total execution time: 0.0490
ERROR - 2017-07-04 18:28:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:28:10 --> Config Class Initialized
INFO - 2017-07-04 18:28:10 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:28:10 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:28:10 --> Utf8 Class Initialized
INFO - 2017-07-04 18:28:10 --> URI Class Initialized
INFO - 2017-07-04 18:28:10 --> Router Class Initialized
INFO - 2017-07-04 18:28:10 --> Output Class Initialized
INFO - 2017-07-04 18:28:10 --> Security Class Initialized
DEBUG - 2017-07-04 18:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:28:10 --> Input Class Initialized
INFO - 2017-07-04 18:28:10 --> Language Class Initialized
INFO - 2017-07-04 18:28:10 --> Loader Class Initialized
INFO - 2017-07-04 18:28:10 --> Controller Class Initialized
INFO - 2017-07-04 18:28:10 --> Database Driver Class Initialized
INFO - 2017-07-04 18:28:10 --> Model Class Initialized
INFO - 2017-07-04 18:28:10 --> Helper loaded: form_helper
INFO - 2017-07-04 18:28:10 --> Helper loaded: url_helper
INFO - 2017-07-04 18:28:10 --> Model Class Initialized
INFO - 2017-07-04 18:28:10 --> Final output sent to browser
DEBUG - 2017-07-04 18:28:10 --> Total execution time: 0.0440
ERROR - 2017-07-04 18:28:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:28:13 --> Config Class Initialized
INFO - 2017-07-04 18:28:13 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:28:13 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:28:13 --> Utf8 Class Initialized
INFO - 2017-07-04 18:28:13 --> URI Class Initialized
INFO - 2017-07-04 18:28:13 --> Router Class Initialized
INFO - 2017-07-04 18:28:13 --> Output Class Initialized
INFO - 2017-07-04 18:28:13 --> Security Class Initialized
DEBUG - 2017-07-04 18:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:28:13 --> Input Class Initialized
INFO - 2017-07-04 18:28:13 --> Language Class Initialized
INFO - 2017-07-04 18:28:13 --> Loader Class Initialized
INFO - 2017-07-04 18:28:13 --> Controller Class Initialized
INFO - 2017-07-04 18:28:13 --> Database Driver Class Initialized
INFO - 2017-07-04 18:28:13 --> Model Class Initialized
INFO - 2017-07-04 18:28:13 --> Helper loaded: form_helper
INFO - 2017-07-04 18:28:13 --> Helper loaded: url_helper
INFO - 2017-07-04 18:28:13 --> Model Class Initialized
INFO - 2017-07-04 18:28:13 --> Final output sent to browser
DEBUG - 2017-07-04 18:28:13 --> Total execution time: 0.0640
ERROR - 2017-07-04 18:28:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:28:16 --> Config Class Initialized
INFO - 2017-07-04 18:28:16 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:28:16 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:28:16 --> Utf8 Class Initialized
INFO - 2017-07-04 18:28:16 --> URI Class Initialized
INFO - 2017-07-04 18:28:16 --> Router Class Initialized
INFO - 2017-07-04 18:28:16 --> Output Class Initialized
INFO - 2017-07-04 18:28:16 --> Security Class Initialized
DEBUG - 2017-07-04 18:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:28:16 --> Input Class Initialized
INFO - 2017-07-04 18:28:16 --> Language Class Initialized
INFO - 2017-07-04 18:28:16 --> Loader Class Initialized
INFO - 2017-07-04 18:28:16 --> Controller Class Initialized
INFO - 2017-07-04 18:28:16 --> Database Driver Class Initialized
INFO - 2017-07-04 18:28:16 --> Model Class Initialized
INFO - 2017-07-04 18:28:16 --> Helper loaded: form_helper
INFO - 2017-07-04 18:28:16 --> Helper loaded: url_helper
INFO - 2017-07-04 18:28:16 --> Model Class Initialized
INFO - 2017-07-04 18:28:16 --> Final output sent to browser
DEBUG - 2017-07-04 18:28:16 --> Total execution time: 0.0450
ERROR - 2017-07-04 18:28:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:28:36 --> Config Class Initialized
INFO - 2017-07-04 18:28:36 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:28:36 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:28:36 --> Utf8 Class Initialized
INFO - 2017-07-04 18:28:36 --> URI Class Initialized
INFO - 2017-07-04 18:28:36 --> Router Class Initialized
INFO - 2017-07-04 18:28:36 --> Output Class Initialized
INFO - 2017-07-04 18:28:36 --> Security Class Initialized
DEBUG - 2017-07-04 18:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:28:36 --> Input Class Initialized
INFO - 2017-07-04 18:28:36 --> Language Class Initialized
INFO - 2017-07-04 18:28:36 --> Loader Class Initialized
INFO - 2017-07-04 18:28:36 --> Controller Class Initialized
INFO - 2017-07-04 18:28:36 --> Database Driver Class Initialized
INFO - 2017-07-04 18:28:36 --> Model Class Initialized
INFO - 2017-07-04 18:28:36 --> Helper loaded: form_helper
INFO - 2017-07-04 18:28:36 --> Helper loaded: url_helper
INFO - 2017-07-04 18:28:36 --> Model Class Initialized
INFO - 2017-07-04 18:28:36 --> Final output sent to browser
DEBUG - 2017-07-04 18:28:36 --> Total execution time: 0.0550
ERROR - 2017-07-04 18:28:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:28:45 --> Config Class Initialized
INFO - 2017-07-04 18:28:45 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:28:45 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:28:45 --> Utf8 Class Initialized
INFO - 2017-07-04 18:28:45 --> URI Class Initialized
INFO - 2017-07-04 18:28:45 --> Router Class Initialized
INFO - 2017-07-04 18:28:45 --> Output Class Initialized
INFO - 2017-07-04 18:28:45 --> Security Class Initialized
DEBUG - 2017-07-04 18:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:28:45 --> Input Class Initialized
INFO - 2017-07-04 18:28:45 --> Language Class Initialized
INFO - 2017-07-04 18:28:45 --> Loader Class Initialized
INFO - 2017-07-04 18:28:45 --> Controller Class Initialized
INFO - 2017-07-04 18:28:45 --> Database Driver Class Initialized
INFO - 2017-07-04 18:28:45 --> Model Class Initialized
INFO - 2017-07-04 18:28:45 --> Helper loaded: form_helper
INFO - 2017-07-04 18:28:45 --> Helper loaded: url_helper
INFO - 2017-07-04 18:28:45 --> Model Class Initialized
INFO - 2017-07-04 18:28:45 --> Final output sent to browser
DEBUG - 2017-07-04 18:28:45 --> Total execution time: 0.0700
ERROR - 2017-07-04 18:29:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:29:19 --> Config Class Initialized
INFO - 2017-07-04 18:29:19 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:29:19 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:29:19 --> Utf8 Class Initialized
INFO - 2017-07-04 18:29:19 --> URI Class Initialized
INFO - 2017-07-04 18:29:19 --> Router Class Initialized
INFO - 2017-07-04 18:29:19 --> Output Class Initialized
INFO - 2017-07-04 18:29:19 --> Security Class Initialized
DEBUG - 2017-07-04 18:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:29:19 --> Input Class Initialized
INFO - 2017-07-04 18:29:19 --> Language Class Initialized
INFO - 2017-07-04 18:29:19 --> Loader Class Initialized
INFO - 2017-07-04 18:29:19 --> Controller Class Initialized
INFO - 2017-07-04 18:29:19 --> Database Driver Class Initialized
INFO - 2017-07-04 18:29:19 --> Model Class Initialized
INFO - 2017-07-04 18:29:19 --> Helper loaded: form_helper
INFO - 2017-07-04 18:29:19 --> Helper loaded: url_helper
INFO - 2017-07-04 18:29:19 --> Model Class Initialized
INFO - 2017-07-04 18:29:19 --> Final output sent to browser
DEBUG - 2017-07-04 18:29:19 --> Total execution time: 0.0470
ERROR - 2017-07-04 18:29:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:29:26 --> Config Class Initialized
INFO - 2017-07-04 18:29:26 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:29:26 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:29:26 --> Utf8 Class Initialized
INFO - 2017-07-04 18:29:26 --> URI Class Initialized
INFO - 2017-07-04 18:29:26 --> Router Class Initialized
INFO - 2017-07-04 18:29:26 --> Output Class Initialized
INFO - 2017-07-04 18:29:26 --> Security Class Initialized
DEBUG - 2017-07-04 18:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:29:26 --> Input Class Initialized
INFO - 2017-07-04 18:29:26 --> Language Class Initialized
INFO - 2017-07-04 18:29:26 --> Loader Class Initialized
INFO - 2017-07-04 18:29:26 --> Controller Class Initialized
INFO - 2017-07-04 18:29:26 --> Database Driver Class Initialized
INFO - 2017-07-04 18:29:26 --> Model Class Initialized
INFO - 2017-07-04 18:29:26 --> Helper loaded: form_helper
INFO - 2017-07-04 18:29:26 --> Helper loaded: url_helper
INFO - 2017-07-04 18:29:26 --> Model Class Initialized
INFO - 2017-07-04 18:29:26 --> Final output sent to browser
DEBUG - 2017-07-04 18:29:26 --> Total execution time: 0.0840
ERROR - 2017-07-04 18:29:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:29:33 --> Config Class Initialized
INFO - 2017-07-04 18:29:33 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:29:33 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:29:33 --> Utf8 Class Initialized
INFO - 2017-07-04 18:29:33 --> URI Class Initialized
INFO - 2017-07-04 18:29:33 --> Router Class Initialized
INFO - 2017-07-04 18:29:33 --> Output Class Initialized
INFO - 2017-07-04 18:29:33 --> Security Class Initialized
DEBUG - 2017-07-04 18:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:29:33 --> Input Class Initialized
INFO - 2017-07-04 18:29:33 --> Language Class Initialized
INFO - 2017-07-04 18:29:33 --> Loader Class Initialized
INFO - 2017-07-04 18:29:33 --> Controller Class Initialized
INFO - 2017-07-04 18:29:33 --> Database Driver Class Initialized
INFO - 2017-07-04 18:29:33 --> Model Class Initialized
INFO - 2017-07-04 18:29:33 --> Helper loaded: form_helper
INFO - 2017-07-04 18:29:33 --> Helper loaded: url_helper
INFO - 2017-07-04 18:29:33 --> Model Class Initialized
INFO - 2017-07-04 18:29:33 --> Final output sent to browser
DEBUG - 2017-07-04 18:29:33 --> Total execution time: 0.0530
ERROR - 2017-07-04 18:29:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:29:35 --> Config Class Initialized
INFO - 2017-07-04 18:29:35 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:29:35 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:29:35 --> Utf8 Class Initialized
INFO - 2017-07-04 18:29:35 --> URI Class Initialized
INFO - 2017-07-04 18:29:35 --> Router Class Initialized
INFO - 2017-07-04 18:29:35 --> Output Class Initialized
INFO - 2017-07-04 18:29:35 --> Security Class Initialized
DEBUG - 2017-07-04 18:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:29:35 --> Input Class Initialized
INFO - 2017-07-04 18:29:35 --> Language Class Initialized
INFO - 2017-07-04 18:29:35 --> Loader Class Initialized
INFO - 2017-07-04 18:29:35 --> Controller Class Initialized
INFO - 2017-07-04 18:29:35 --> Database Driver Class Initialized
INFO - 2017-07-04 18:29:35 --> Model Class Initialized
INFO - 2017-07-04 18:29:35 --> Helper loaded: form_helper
INFO - 2017-07-04 18:29:35 --> Helper loaded: url_helper
INFO - 2017-07-04 18:29:35 --> Model Class Initialized
INFO - 2017-07-04 18:29:35 --> Final output sent to browser
DEBUG - 2017-07-04 18:29:35 --> Total execution time: 0.3140
ERROR - 2017-07-04 18:29:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:29:53 --> Config Class Initialized
INFO - 2017-07-04 18:29:53 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:29:53 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:29:53 --> Utf8 Class Initialized
INFO - 2017-07-04 18:29:53 --> URI Class Initialized
INFO - 2017-07-04 18:29:53 --> Router Class Initialized
INFO - 2017-07-04 18:29:53 --> Output Class Initialized
INFO - 2017-07-04 18:29:53 --> Security Class Initialized
DEBUG - 2017-07-04 18:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:29:53 --> Input Class Initialized
INFO - 2017-07-04 18:29:53 --> Language Class Initialized
INFO - 2017-07-04 18:29:53 --> Loader Class Initialized
INFO - 2017-07-04 18:29:53 --> Controller Class Initialized
INFO - 2017-07-04 18:29:53 --> Database Driver Class Initialized
INFO - 2017-07-04 18:29:53 --> Model Class Initialized
INFO - 2017-07-04 18:29:53 --> Helper loaded: form_helper
INFO - 2017-07-04 18:29:53 --> Helper loaded: url_helper
INFO - 2017-07-04 18:29:53 --> Model Class Initialized
INFO - 2017-07-04 18:29:53 --> Final output sent to browser
DEBUG - 2017-07-04 18:29:53 --> Total execution time: 0.0860
ERROR - 2017-07-04 18:29:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:29:55 --> Config Class Initialized
INFO - 2017-07-04 18:29:55 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:29:55 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:29:55 --> Utf8 Class Initialized
INFO - 2017-07-04 18:29:55 --> URI Class Initialized
INFO - 2017-07-04 18:29:55 --> Router Class Initialized
INFO - 2017-07-04 18:29:55 --> Output Class Initialized
INFO - 2017-07-04 18:29:55 --> Security Class Initialized
DEBUG - 2017-07-04 18:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:29:55 --> Input Class Initialized
INFO - 2017-07-04 18:29:55 --> Language Class Initialized
INFO - 2017-07-04 18:29:55 --> Loader Class Initialized
INFO - 2017-07-04 18:29:55 --> Controller Class Initialized
INFO - 2017-07-04 18:29:55 --> Database Driver Class Initialized
INFO - 2017-07-04 18:29:55 --> Model Class Initialized
INFO - 2017-07-04 18:29:55 --> Helper loaded: form_helper
INFO - 2017-07-04 18:29:55 --> Helper loaded: url_helper
INFO - 2017-07-04 18:29:55 --> Model Class Initialized
INFO - 2017-07-04 18:29:55 --> Final output sent to browser
DEBUG - 2017-07-04 18:29:55 --> Total execution time: 0.0520
ERROR - 2017-07-04 18:29:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:29:57 --> Config Class Initialized
INFO - 2017-07-04 18:29:57 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:29:57 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:29:57 --> Utf8 Class Initialized
INFO - 2017-07-04 18:29:57 --> URI Class Initialized
INFO - 2017-07-04 18:29:57 --> Router Class Initialized
INFO - 2017-07-04 18:29:57 --> Output Class Initialized
INFO - 2017-07-04 18:29:57 --> Security Class Initialized
DEBUG - 2017-07-04 18:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:29:57 --> Input Class Initialized
INFO - 2017-07-04 18:29:57 --> Language Class Initialized
INFO - 2017-07-04 18:29:57 --> Loader Class Initialized
INFO - 2017-07-04 18:29:57 --> Controller Class Initialized
INFO - 2017-07-04 18:29:57 --> Database Driver Class Initialized
INFO - 2017-07-04 18:29:57 --> Model Class Initialized
INFO - 2017-07-04 18:29:57 --> Helper loaded: form_helper
INFO - 2017-07-04 18:29:57 --> Helper loaded: url_helper
INFO - 2017-07-04 18:29:57 --> Model Class Initialized
INFO - 2017-07-04 18:29:57 --> Final output sent to browser
DEBUG - 2017-07-04 18:29:57 --> Total execution time: 0.0620
ERROR - 2017-07-04 18:30:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:30:21 --> Config Class Initialized
INFO - 2017-07-04 18:30:21 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:30:21 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:30:21 --> Utf8 Class Initialized
INFO - 2017-07-04 18:30:21 --> URI Class Initialized
INFO - 2017-07-04 18:30:21 --> Router Class Initialized
INFO - 2017-07-04 18:30:21 --> Output Class Initialized
INFO - 2017-07-04 18:30:21 --> Security Class Initialized
DEBUG - 2017-07-04 18:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:30:21 --> Input Class Initialized
INFO - 2017-07-04 18:30:21 --> Language Class Initialized
INFO - 2017-07-04 18:30:21 --> Loader Class Initialized
INFO - 2017-07-04 18:30:21 --> Controller Class Initialized
INFO - 2017-07-04 18:30:21 --> Database Driver Class Initialized
INFO - 2017-07-04 18:30:21 --> Model Class Initialized
INFO - 2017-07-04 18:30:21 --> Helper loaded: form_helper
INFO - 2017-07-04 18:30:21 --> Helper loaded: url_helper
INFO - 2017-07-04 18:30:21 --> Model Class Initialized
INFO - 2017-07-04 18:30:21 --> Final output sent to browser
DEBUG - 2017-07-04 18:30:21 --> Total execution time: 0.0480
ERROR - 2017-07-04 18:48:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:48:21 --> Config Class Initialized
INFO - 2017-07-04 18:48:21 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:48:21 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:48:21 --> Utf8 Class Initialized
INFO - 2017-07-04 18:48:21 --> URI Class Initialized
INFO - 2017-07-04 18:48:21 --> Router Class Initialized
INFO - 2017-07-04 18:48:21 --> Output Class Initialized
INFO - 2017-07-04 18:48:21 --> Security Class Initialized
DEBUG - 2017-07-04 18:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:48:21 --> Input Class Initialized
INFO - 2017-07-04 18:48:21 --> Language Class Initialized
INFO - 2017-07-04 18:48:21 --> Loader Class Initialized
INFO - 2017-07-04 18:48:21 --> Controller Class Initialized
INFO - 2017-07-04 18:48:21 --> Database Driver Class Initialized
INFO - 2017-07-04 18:48:21 --> Model Class Initialized
INFO - 2017-07-04 18:48:21 --> Helper loaded: form_helper
INFO - 2017-07-04 18:48:21 --> Helper loaded: url_helper
INFO - 2017-07-04 18:48:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 18:48:21 --> Model Class Initialized
INFO - 2017-07-04 18:48:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-04 18:48:21 --> Final output sent to browser
DEBUG - 2017-07-04 18:48:21 --> Total execution time: 0.1020
ERROR - 2017-07-04 18:57:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:57:00 --> Config Class Initialized
INFO - 2017-07-04 18:57:00 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:57:00 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:57:00 --> Utf8 Class Initialized
INFO - 2017-07-04 18:57:00 --> URI Class Initialized
INFO - 2017-07-04 18:57:00 --> Router Class Initialized
INFO - 2017-07-04 18:57:00 --> Output Class Initialized
INFO - 2017-07-04 18:57:00 --> Security Class Initialized
DEBUG - 2017-07-04 18:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:57:00 --> Input Class Initialized
INFO - 2017-07-04 18:57:00 --> Language Class Initialized
INFO - 2017-07-04 18:57:00 --> Loader Class Initialized
INFO - 2017-07-04 18:57:00 --> Controller Class Initialized
INFO - 2017-07-04 18:57:00 --> Database Driver Class Initialized
INFO - 2017-07-04 18:57:00 --> Model Class Initialized
INFO - 2017-07-04 18:57:00 --> Helper loaded: form_helper
INFO - 2017-07-04 18:57:00 --> Helper loaded: url_helper
INFO - 2017-07-04 18:57:00 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 18:57:00 --> Model Class Initialized
INFO - 2017-07-04 18:57:00 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-04 18:57:00 --> Final output sent to browser
DEBUG - 2017-07-04 18:57:00 --> Total execution time: 0.0620
ERROR - 2017-07-04 18:57:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:57:02 --> Config Class Initialized
INFO - 2017-07-04 18:57:02 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:57:02 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:57:02 --> Utf8 Class Initialized
INFO - 2017-07-04 18:57:02 --> URI Class Initialized
INFO - 2017-07-04 18:57:02 --> Router Class Initialized
INFO - 2017-07-04 18:57:02 --> Output Class Initialized
INFO - 2017-07-04 18:57:02 --> Security Class Initialized
DEBUG - 2017-07-04 18:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:57:02 --> Input Class Initialized
INFO - 2017-07-04 18:57:02 --> Language Class Initialized
INFO - 2017-07-04 18:57:02 --> Loader Class Initialized
INFO - 2017-07-04 18:57:02 --> Controller Class Initialized
INFO - 2017-07-04 18:57:02 --> Database Driver Class Initialized
INFO - 2017-07-04 18:57:02 --> Model Class Initialized
INFO - 2017-07-04 18:57:02 --> Helper loaded: form_helper
INFO - 2017-07-04 18:57:02 --> Helper loaded: url_helper
INFO - 2017-07-04 18:57:02 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 18:57:02 --> Model Class Initialized
INFO - 2017-07-04 18:57:02 --> File loaded: C:\xampp\htdocs\mystage\application\views\purchase.php
INFO - 2017-07-04 18:57:02 --> Final output sent to browser
DEBUG - 2017-07-04 18:57:02 --> Total execution time: 0.0590
ERROR - 2017-07-04 18:58:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:58:01 --> Config Class Initialized
INFO - 2017-07-04 18:58:01 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:58:01 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:58:01 --> Utf8 Class Initialized
INFO - 2017-07-04 18:58:01 --> URI Class Initialized
INFO - 2017-07-04 18:58:01 --> Router Class Initialized
INFO - 2017-07-04 18:58:01 --> Output Class Initialized
INFO - 2017-07-04 18:58:01 --> Security Class Initialized
DEBUG - 2017-07-04 18:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:58:01 --> Input Class Initialized
INFO - 2017-07-04 18:58:01 --> Language Class Initialized
INFO - 2017-07-04 18:58:01 --> Loader Class Initialized
INFO - 2017-07-04 18:58:01 --> Controller Class Initialized
INFO - 2017-07-04 18:58:01 --> Database Driver Class Initialized
INFO - 2017-07-04 18:58:01 --> Model Class Initialized
INFO - 2017-07-04 18:58:01 --> Helper loaded: form_helper
INFO - 2017-07-04 18:58:01 --> Helper loaded: url_helper
INFO - 2017-07-04 18:58:01 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 18:58:01 --> Model Class Initialized
INFO - 2017-07-04 18:58:01 --> File loaded: C:\xampp\htdocs\mystage\application\views\purchase.php
INFO - 2017-07-04 18:58:01 --> Final output sent to browser
DEBUG - 2017-07-04 18:58:01 --> Total execution time: 0.1040
ERROR - 2017-07-04 18:58:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:58:02 --> Config Class Initialized
INFO - 2017-07-04 18:58:02 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:58:02 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:58:02 --> Utf8 Class Initialized
INFO - 2017-07-04 18:58:02 --> URI Class Initialized
INFO - 2017-07-04 18:58:02 --> Router Class Initialized
INFO - 2017-07-04 18:58:02 --> Output Class Initialized
INFO - 2017-07-04 18:58:02 --> Security Class Initialized
DEBUG - 2017-07-04 18:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:58:02 --> Input Class Initialized
INFO - 2017-07-04 18:58:02 --> Language Class Initialized
INFO - 2017-07-04 18:58:02 --> Loader Class Initialized
INFO - 2017-07-04 18:58:02 --> Controller Class Initialized
INFO - 2017-07-04 18:58:02 --> Database Driver Class Initialized
INFO - 2017-07-04 18:58:02 --> Model Class Initialized
INFO - 2017-07-04 18:58:02 --> Helper loaded: form_helper
INFO - 2017-07-04 18:58:02 --> Helper loaded: url_helper
INFO - 2017-07-04 18:58:02 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 18:58:02 --> Model Class Initialized
ERROR - 2017-07-04 18:58:02 --> Severity: Notice --> Undefined index: buyer C:\xampp\htdocs\mystage\application\views\share.php 74
ERROR - 2017-07-04 18:58:02 --> Severity: Notice --> Undefined index: key C:\xampp\htdocs\mystage\application\views\share.php 78
ERROR - 2017-07-04 18:58:02 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\mystage\application\views\share.php 87
ERROR - 2017-07-04 18:58:02 --> Severity: Notice --> Undefined index: buyer C:\xampp\htdocs\mystage\application\views\share.php 74
ERROR - 2017-07-04 18:58:03 --> Severity: Notice --> Undefined index: key C:\xampp\htdocs\mystage\application\views\share.php 78
ERROR - 2017-07-04 18:58:03 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\mystage\application\views\share.php 87
INFO - 2017-07-04 18:58:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 18:58:03 --> Final output sent to browser
DEBUG - 2017-07-04 18:58:03 --> Total execution time: 0.1000
ERROR - 2017-07-04 18:58:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:58:03 --> Config Class Initialized
INFO - 2017-07-04 18:58:03 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:58:03 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:58:03 --> Utf8 Class Initialized
INFO - 2017-07-04 18:58:03 --> URI Class Initialized
INFO - 2017-07-04 18:58:03 --> Router Class Initialized
INFO - 2017-07-04 18:58:03 --> Output Class Initialized
INFO - 2017-07-04 18:58:03 --> Security Class Initialized
DEBUG - 2017-07-04 18:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:58:03 --> Input Class Initialized
INFO - 2017-07-04 18:58:03 --> Language Class Initialized
ERROR - 2017-07-04 18:58:03 --> 404 Page Not Found: Services/1498030024.jpg
ERROR - 2017-07-04 18:58:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:58:03 --> Config Class Initialized
INFO - 2017-07-04 18:58:03 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:58:03 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:58:03 --> Utf8 Class Initialized
INFO - 2017-07-04 18:58:03 --> URI Class Initialized
INFO - 2017-07-04 18:58:03 --> Router Class Initialized
INFO - 2017-07-04 18:58:03 --> Output Class Initialized
INFO - 2017-07-04 18:58:03 --> Security Class Initialized
DEBUG - 2017-07-04 18:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:58:03 --> Input Class Initialized
INFO - 2017-07-04 18:58:03 --> Language Class Initialized
ERROR - 2017-07-04 18:58:03 --> 404 Page Not Found: Services/1497983387.jpg
ERROR - 2017-07-04 18:58:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:58:03 --> Config Class Initialized
INFO - 2017-07-04 18:58:03 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:58:03 --> UTF-8 Support Enabled
ERROR - 2017-07-04 18:58:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:58:03 --> Utf8 Class Initialized
INFO - 2017-07-04 18:58:03 --> URI Class Initialized
INFO - 2017-07-04 18:58:03 --> Router Class Initialized
INFO - 2017-07-04 18:58:03 --> Output Class Initialized
INFO - 2017-07-04 18:58:03 --> Config Class Initialized
INFO - 2017-07-04 18:58:03 --> Security Class Initialized
DEBUG - 2017-07-04 18:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:58:03 --> Input Class Initialized
INFO - 2017-07-04 18:58:03 --> Language Class Initialized
INFO - 2017-07-04 18:58:03 --> Hooks Class Initialized
ERROR - 2017-07-04 18:58:03 --> 404 Page Not Found: Services/1498030057.mp3
DEBUG - 2017-07-04 18:58:03 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:58:03 --> Utf8 Class Initialized
INFO - 2017-07-04 18:58:03 --> URI Class Initialized
INFO - 2017-07-04 18:58:03 --> Router Class Initialized
INFO - 2017-07-04 18:58:03 --> Output Class Initialized
INFO - 2017-07-04 18:58:03 --> Security Class Initialized
DEBUG - 2017-07-04 18:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:58:03 --> Input Class Initialized
INFO - 2017-07-04 18:58:03 --> Language Class Initialized
ERROR - 2017-07-04 18:58:03 --> 404 Page Not Found: Services/1497983379.mp3
ERROR - 2017-07-04 18:58:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:58:26 --> Config Class Initialized
INFO - 2017-07-04 18:58:26 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:58:26 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:58:26 --> Utf8 Class Initialized
INFO - 2017-07-04 18:58:26 --> URI Class Initialized
INFO - 2017-07-04 18:58:26 --> Router Class Initialized
INFO - 2017-07-04 18:58:26 --> Output Class Initialized
INFO - 2017-07-04 18:58:26 --> Security Class Initialized
DEBUG - 2017-07-04 18:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:58:26 --> Input Class Initialized
INFO - 2017-07-04 18:58:26 --> Language Class Initialized
INFO - 2017-07-04 18:58:26 --> Loader Class Initialized
INFO - 2017-07-04 18:58:26 --> Controller Class Initialized
INFO - 2017-07-04 18:58:26 --> Database Driver Class Initialized
INFO - 2017-07-04 18:58:26 --> Model Class Initialized
INFO - 2017-07-04 18:58:26 --> Helper loaded: form_helper
INFO - 2017-07-04 18:58:26 --> Helper loaded: url_helper
INFO - 2017-07-04 18:58:26 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 18:58:26 --> Model Class Initialized
ERROR - 2017-07-04 18:58:26 --> Severity: Notice --> Undefined index: buyer C:\xampp\htdocs\mystage\application\views\share.php 74
ERROR - 2017-07-04 18:58:26 --> Severity: Notice --> Undefined index: key C:\xampp\htdocs\mystage\application\views\share.php 78
ERROR - 2017-07-04 18:58:26 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\mystage\application\views\share.php 87
ERROR - 2017-07-04 18:58:26 --> Severity: Notice --> Undefined index: buyer C:\xampp\htdocs\mystage\application\views\share.php 74
ERROR - 2017-07-04 18:58:26 --> Severity: Notice --> Undefined index: key C:\xampp\htdocs\mystage\application\views\share.php 78
ERROR - 2017-07-04 18:58:26 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\mystage\application\views\share.php 87
INFO - 2017-07-04 18:58:26 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 18:58:26 --> Final output sent to browser
DEBUG - 2017-07-04 18:58:26 --> Total execution time: 0.1300
ERROR - 2017-07-04 18:58:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
ERROR - 2017-07-04 18:58:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:58:27 --> Config Class Initialized
INFO - 2017-07-04 18:58:27 --> Config Class Initialized
INFO - 2017-07-04 18:58:27 --> Hooks Class Initialized
INFO - 2017-07-04 18:58:27 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:58:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-04 18:58:27 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:58:27 --> Utf8 Class Initialized
INFO - 2017-07-04 18:58:27 --> Utf8 Class Initialized
INFO - 2017-07-04 18:58:27 --> URI Class Initialized
INFO - 2017-07-04 18:58:27 --> URI Class Initialized
INFO - 2017-07-04 18:58:27 --> Router Class Initialized
INFO - 2017-07-04 18:58:27 --> Router Class Initialized
INFO - 2017-07-04 18:58:27 --> Output Class Initialized
INFO - 2017-07-04 18:58:27 --> Output Class Initialized
INFO - 2017-07-04 18:58:27 --> Security Class Initialized
INFO - 2017-07-04 18:58:27 --> Security Class Initialized
DEBUG - 2017-07-04 18:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-04 18:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:58:27 --> Input Class Initialized
INFO - 2017-07-04 18:58:27 --> Input Class Initialized
INFO - 2017-07-04 18:58:27 --> Language Class Initialized
INFO - 2017-07-04 18:58:27 --> Language Class Initialized
ERROR - 2017-07-04 18:58:27 --> 404 Page Not Found: Services/1498030024.jpg
ERROR - 2017-07-04 18:58:27 --> 404 Page Not Found: Services/1497983387.jpg
ERROR - 2017-07-04 18:58:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
ERROR - 2017-07-04 18:58:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 18:58:27 --> Config Class Initialized
INFO - 2017-07-04 18:58:27 --> Hooks Class Initialized
INFO - 2017-07-04 18:58:27 --> Config Class Initialized
INFO - 2017-07-04 18:58:27 --> Hooks Class Initialized
DEBUG - 2017-07-04 18:58:27 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:58:27 --> Utf8 Class Initialized
DEBUG - 2017-07-04 18:58:27 --> UTF-8 Support Enabled
INFO - 2017-07-04 18:58:27 --> Utf8 Class Initialized
INFO - 2017-07-04 18:58:27 --> URI Class Initialized
INFO - 2017-07-04 18:58:27 --> URI Class Initialized
INFO - 2017-07-04 18:58:27 --> Router Class Initialized
INFO - 2017-07-04 18:58:27 --> Router Class Initialized
INFO - 2017-07-04 18:58:27 --> Output Class Initialized
INFO - 2017-07-04 18:58:27 --> Output Class Initialized
INFO - 2017-07-04 18:58:27 --> Security Class Initialized
DEBUG - 2017-07-04 18:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:58:27 --> Security Class Initialized
INFO - 2017-07-04 18:58:27 --> Input Class Initialized
DEBUG - 2017-07-04 18:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 18:58:27 --> Language Class Initialized
INFO - 2017-07-04 18:58:27 --> Input Class Initialized
INFO - 2017-07-04 18:58:27 --> Language Class Initialized
ERROR - 2017-07-04 18:58:27 --> 404 Page Not Found: Services/1497983379.mp3
ERROR - 2017-07-04 18:58:27 --> 404 Page Not Found: Services/1498030057.mp3
ERROR - 2017-07-04 19:00:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:00:37 --> Config Class Initialized
INFO - 2017-07-04 19:00:37 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:00:37 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:00:37 --> Utf8 Class Initialized
INFO - 2017-07-04 19:00:37 --> URI Class Initialized
INFO - 2017-07-04 19:00:37 --> Router Class Initialized
INFO - 2017-07-04 19:00:37 --> Output Class Initialized
INFO - 2017-07-04 19:00:37 --> Security Class Initialized
DEBUG - 2017-07-04 19:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:00:37 --> Input Class Initialized
INFO - 2017-07-04 19:00:37 --> Language Class Initialized
INFO - 2017-07-04 19:00:37 --> Loader Class Initialized
INFO - 2017-07-04 19:00:37 --> Controller Class Initialized
INFO - 2017-07-04 19:00:37 --> Database Driver Class Initialized
INFO - 2017-07-04 19:00:37 --> Model Class Initialized
INFO - 2017-07-04 19:00:37 --> Helper loaded: form_helper
INFO - 2017-07-04 19:00:37 --> Helper loaded: url_helper
INFO - 2017-07-04 19:00:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:00:38 --> Model Class Initialized
ERROR - 2017-07-04 19:00:38 --> Severity: Notice --> Undefined variable: arr_guests C:\xampp\htdocs\mystage\application\models\Service_model.php 118
ERROR - 2017-07-04 19:00:38 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\mystage\application\models\Service_model.php 128
ERROR - 2017-07-04 19:00:38 --> Severity: Notice --> Undefined variable: arr_guests C:\xampp\htdocs\mystage\application\models\Service_model.php 118
ERROR - 2017-07-04 19:00:38 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\mystage\application\models\Service_model.php 128
ERROR - 2017-07-04 19:00:38 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\mystage\application\views\share.php 87
ERROR - 2017-07-04 19:00:38 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\mystage\application\views\share.php 87
INFO - 2017-07-04 19:00:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:00:38 --> Final output sent to browser
DEBUG - 2017-07-04 19:00:38 --> Total execution time: 0.0920
ERROR - 2017-07-04 19:00:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
ERROR - 2017-07-04 19:00:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:00:38 --> Config Class Initialized
INFO - 2017-07-04 19:00:38 --> Config Class Initialized
INFO - 2017-07-04 19:00:38 --> Hooks Class Initialized
INFO - 2017-07-04 19:00:38 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:00:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-04 19:00:38 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:00:38 --> Utf8 Class Initialized
INFO - 2017-07-04 19:00:38 --> Utf8 Class Initialized
INFO - 2017-07-04 19:00:38 --> URI Class Initialized
INFO - 2017-07-04 19:00:38 --> URI Class Initialized
INFO - 2017-07-04 19:00:38 --> Router Class Initialized
INFO - 2017-07-04 19:00:38 --> Router Class Initialized
INFO - 2017-07-04 19:00:38 --> Output Class Initialized
INFO - 2017-07-04 19:00:38 --> Output Class Initialized
INFO - 2017-07-04 19:00:38 --> Security Class Initialized
INFO - 2017-07-04 19:00:38 --> Security Class Initialized
DEBUG - 2017-07-04 19:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-04 19:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:00:38 --> Input Class Initialized
INFO - 2017-07-04 19:00:38 --> Input Class Initialized
INFO - 2017-07-04 19:00:38 --> Language Class Initialized
INFO - 2017-07-04 19:00:38 --> Language Class Initialized
ERROR - 2017-07-04 19:00:38 --> 404 Page Not Found: Services/1497983387.jpg
ERROR - 2017-07-04 19:00:38 --> 404 Page Not Found: Services/1498030024.jpg
ERROR - 2017-07-04 19:00:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
ERROR - 2017-07-04 19:00:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:00:38 --> Config Class Initialized
INFO - 2017-07-04 19:00:38 --> Config Class Initialized
INFO - 2017-07-04 19:00:38 --> Hooks Class Initialized
INFO - 2017-07-04 19:00:38 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:00:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-04 19:00:38 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:00:38 --> Utf8 Class Initialized
INFO - 2017-07-04 19:00:38 --> Utf8 Class Initialized
INFO - 2017-07-04 19:00:38 --> URI Class Initialized
INFO - 2017-07-04 19:00:38 --> URI Class Initialized
INFO - 2017-07-04 19:00:38 --> Router Class Initialized
INFO - 2017-07-04 19:00:38 --> Router Class Initialized
INFO - 2017-07-04 19:00:38 --> Output Class Initialized
INFO - 2017-07-04 19:00:38 --> Output Class Initialized
INFO - 2017-07-04 19:00:38 --> Security Class Initialized
INFO - 2017-07-04 19:00:38 --> Security Class Initialized
DEBUG - 2017-07-04 19:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:00:38 --> Input Class Initialized
DEBUG - 2017-07-04 19:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:00:38 --> Language Class Initialized
INFO - 2017-07-04 19:00:38 --> Input Class Initialized
INFO - 2017-07-04 19:00:38 --> Language Class Initialized
ERROR - 2017-07-04 19:00:38 --> 404 Page Not Found: Services/1498030057.mp3
ERROR - 2017-07-04 19:00:38 --> 404 Page Not Found: Services/1497983379.mp3
ERROR - 2017-07-04 19:01:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:01:02 --> Config Class Initialized
INFO - 2017-07-04 19:01:02 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:01:02 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:01:02 --> Utf8 Class Initialized
INFO - 2017-07-04 19:01:02 --> URI Class Initialized
INFO - 2017-07-04 19:01:02 --> Router Class Initialized
INFO - 2017-07-04 19:01:02 --> Output Class Initialized
INFO - 2017-07-04 19:01:02 --> Security Class Initialized
DEBUG - 2017-07-04 19:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:01:02 --> Input Class Initialized
INFO - 2017-07-04 19:01:02 --> Language Class Initialized
INFO - 2017-07-04 19:01:02 --> Loader Class Initialized
INFO - 2017-07-04 19:01:02 --> Controller Class Initialized
INFO - 2017-07-04 19:01:02 --> Database Driver Class Initialized
INFO - 2017-07-04 19:01:02 --> Model Class Initialized
INFO - 2017-07-04 19:01:02 --> Helper loaded: form_helper
INFO - 2017-07-04 19:01:02 --> Helper loaded: url_helper
INFO - 2017-07-04 19:01:02 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:01:02 --> Model Class Initialized
ERROR - 2017-07-04 19:01:02 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\mystage\application\models\Service_model.php 128
ERROR - 2017-07-04 19:01:02 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\mystage\application\models\Service_model.php 128
ERROR - 2017-07-04 19:01:02 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\mystage\application\views\share.php 87
ERROR - 2017-07-04 19:01:02 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\mystage\application\views\share.php 87
INFO - 2017-07-04 19:01:02 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:01:02 --> Final output sent to browser
DEBUG - 2017-07-04 19:01:02 --> Total execution time: 0.0610
ERROR - 2017-07-04 19:01:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
ERROR - 2017-07-04 19:01:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:01:02 --> Config Class Initialized
INFO - 2017-07-04 19:01:02 --> Config Class Initialized
INFO - 2017-07-04 19:01:02 --> Hooks Class Initialized
INFO - 2017-07-04 19:01:02 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:01:02 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:01:02 --> Utf8 Class Initialized
INFO - 2017-07-04 19:01:02 --> URI Class Initialized
INFO - 2017-07-04 19:01:02 --> Router Class Initialized
DEBUG - 2017-07-04 19:01:02 --> UTF-8 Support Enabled
ERROR - 2017-07-04 19:01:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:01:02 --> Output Class Initialized
INFO - 2017-07-04 19:01:02 --> Utf8 Class Initialized
ERROR - 2017-07-04 19:01:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:01:02 --> URI Class Initialized
INFO - 2017-07-04 19:01:02 --> Config Class Initialized
INFO - 2017-07-04 19:01:02 --> Security Class Initialized
INFO - 2017-07-04 19:01:02 --> Router Class Initialized
DEBUG - 2017-07-04 19:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:01:02 --> Hooks Class Initialized
INFO - 2017-07-04 19:01:02 --> Output Class Initialized
INFO - 2017-07-04 19:01:02 --> Input Class Initialized
INFO - 2017-07-04 19:01:02 --> Security Class Initialized
DEBUG - 2017-07-04 19:01:02 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:01:02 --> Language Class Initialized
DEBUG - 2017-07-04 19:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:01:02 --> Utf8 Class Initialized
INFO - 2017-07-04 19:01:02 --> Input Class Initialized
INFO - 2017-07-04 19:01:02 --> URI Class Initialized
ERROR - 2017-07-04 19:01:02 --> 404 Page Not Found: Services/1498030024.jpg
INFO - 2017-07-04 19:01:02 --> Config Class Initialized
INFO - 2017-07-04 19:01:02 --> Router Class Initialized
INFO - 2017-07-04 19:01:02 --> Language Class Initialized
INFO - 2017-07-04 19:01:02 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:01:02 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:01:02 --> Output Class Initialized
INFO - 2017-07-04 19:01:02 --> Utf8 Class Initialized
ERROR - 2017-07-04 19:01:02 --> 404 Page Not Found: Services/1497983387.jpg
INFO - 2017-07-04 19:01:02 --> Security Class Initialized
DEBUG - 2017-07-04 19:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:01:02 --> URI Class Initialized
INFO - 2017-07-04 19:01:02 --> Input Class Initialized
INFO - 2017-07-04 19:01:02 --> Router Class Initialized
INFO - 2017-07-04 19:01:02 --> Language Class Initialized
ERROR - 2017-07-04 19:01:02 --> 404 Page Not Found: Services/1498030057.mp3
INFO - 2017-07-04 19:01:02 --> Output Class Initialized
INFO - 2017-07-04 19:01:02 --> Security Class Initialized
DEBUG - 2017-07-04 19:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:01:02 --> Input Class Initialized
INFO - 2017-07-04 19:01:02 --> Language Class Initialized
ERROR - 2017-07-04 19:01:02 --> 404 Page Not Found: Services/1497983379.mp3
ERROR - 2017-07-04 19:01:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:01:21 --> Config Class Initialized
INFO - 2017-07-04 19:01:21 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:01:21 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:01:21 --> Utf8 Class Initialized
INFO - 2017-07-04 19:01:21 --> URI Class Initialized
INFO - 2017-07-04 19:01:21 --> Router Class Initialized
INFO - 2017-07-04 19:01:21 --> Output Class Initialized
INFO - 2017-07-04 19:01:21 --> Security Class Initialized
DEBUG - 2017-07-04 19:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:01:21 --> Input Class Initialized
INFO - 2017-07-04 19:01:21 --> Language Class Initialized
INFO - 2017-07-04 19:01:21 --> Loader Class Initialized
INFO - 2017-07-04 19:01:21 --> Controller Class Initialized
INFO - 2017-07-04 19:01:21 --> Database Driver Class Initialized
INFO - 2017-07-04 19:01:21 --> Model Class Initialized
INFO - 2017-07-04 19:01:21 --> Helper loaded: form_helper
INFO - 2017-07-04 19:01:21 --> Helper loaded: url_helper
INFO - 2017-07-04 19:01:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:01:21 --> Model Class Initialized
ERROR - 2017-07-04 19:01:22 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\mystage\application\views\share.php 87
ERROR - 2017-07-04 19:01:22 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\mystage\application\views\share.php 87
INFO - 2017-07-04 19:01:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:01:22 --> Final output sent to browser
DEBUG - 2017-07-04 19:01:22 --> Total execution time: 0.0880
ERROR - 2017-07-04 19:01:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
ERROR - 2017-07-04 19:01:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:01:22 --> Config Class Initialized
INFO - 2017-07-04 19:01:22 --> Config Class Initialized
INFO - 2017-07-04 19:01:22 --> Hooks Class Initialized
INFO - 2017-07-04 19:01:22 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:01:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-04 19:01:22 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:01:22 --> Utf8 Class Initialized
INFO - 2017-07-04 19:01:22 --> Utf8 Class Initialized
INFO - 2017-07-04 19:01:22 --> URI Class Initialized
INFO - 2017-07-04 19:01:22 --> URI Class Initialized
INFO - 2017-07-04 19:01:22 --> Router Class Initialized
INFO - 2017-07-04 19:01:22 --> Router Class Initialized
INFO - 2017-07-04 19:01:22 --> Output Class Initialized
INFO - 2017-07-04 19:01:22 --> Output Class Initialized
INFO - 2017-07-04 19:01:22 --> Security Class Initialized
INFO - 2017-07-04 19:01:22 --> Security Class Initialized
DEBUG - 2017-07-04 19:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-04 19:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:01:22 --> Input Class Initialized
INFO - 2017-07-04 19:01:22 --> Input Class Initialized
INFO - 2017-07-04 19:01:22 --> Language Class Initialized
INFO - 2017-07-04 19:01:22 --> Language Class Initialized
ERROR - 2017-07-04 19:01:22 --> 404 Page Not Found: Services/1497983387.jpg
ERROR - 2017-07-04 19:01:22 --> 404 Page Not Found: Services/1498030024.jpg
ERROR - 2017-07-04 19:01:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
ERROR - 2017-07-04 19:01:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:01:22 --> Config Class Initialized
INFO - 2017-07-04 19:01:22 --> Hooks Class Initialized
INFO - 2017-07-04 19:01:22 --> Config Class Initialized
INFO - 2017-07-04 19:01:22 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:01:22 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:01:22 --> Utf8 Class Initialized
DEBUG - 2017-07-04 19:01:22 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:01:22 --> Utf8 Class Initialized
INFO - 2017-07-04 19:01:22 --> URI Class Initialized
INFO - 2017-07-04 19:01:22 --> URI Class Initialized
INFO - 2017-07-04 19:01:22 --> Router Class Initialized
INFO - 2017-07-04 19:01:22 --> Router Class Initialized
INFO - 2017-07-04 19:01:22 --> Output Class Initialized
INFO - 2017-07-04 19:01:22 --> Security Class Initialized
INFO - 2017-07-04 19:01:22 --> Output Class Initialized
INFO - 2017-07-04 19:01:22 --> Security Class Initialized
DEBUG - 2017-07-04 19:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:01:22 --> Input Class Initialized
DEBUG - 2017-07-04 19:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:01:22 --> Language Class Initialized
INFO - 2017-07-04 19:01:22 --> Input Class Initialized
INFO - 2017-07-04 19:01:22 --> Language Class Initialized
ERROR - 2017-07-04 19:01:22 --> 404 Page Not Found: Services/1498030057.mp3
ERROR - 2017-07-04 19:01:22 --> 404 Page Not Found: Services/1497983379.mp3
ERROR - 2017-07-04 19:03:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:03:16 --> Config Class Initialized
INFO - 2017-07-04 19:03:16 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:03:16 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:03:16 --> Utf8 Class Initialized
INFO - 2017-07-04 19:03:16 --> URI Class Initialized
INFO - 2017-07-04 19:03:16 --> Router Class Initialized
INFO - 2017-07-04 19:03:16 --> Output Class Initialized
INFO - 2017-07-04 19:03:16 --> Security Class Initialized
DEBUG - 2017-07-04 19:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:03:16 --> Input Class Initialized
INFO - 2017-07-04 19:03:16 --> Language Class Initialized
INFO - 2017-07-04 19:03:16 --> Loader Class Initialized
INFO - 2017-07-04 19:03:16 --> Controller Class Initialized
INFO - 2017-07-04 19:03:16 --> Database Driver Class Initialized
INFO - 2017-07-04 19:03:16 --> Model Class Initialized
INFO - 2017-07-04 19:03:16 --> Helper loaded: form_helper
INFO - 2017-07-04 19:03:16 --> Helper loaded: url_helper
INFO - 2017-07-04 19:03:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:03:16 --> Model Class Initialized
ERROR - 2017-07-04 19:03:16 --> Severity: Notice --> Undefined index: photo C:\xampp\htdocs\mystage\application\models\Service_model.php 131
ERROR - 2017-07-04 19:03:16 --> Severity: Notice --> Undefined index: photo C:\xampp\htdocs\mystage\application\models\Service_model.php 131
ERROR - 2017-07-04 19:03:16 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\mystage\application\views\share.php 87
ERROR - 2017-07-04 19:03:16 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\mystage\application\views\share.php 87
INFO - 2017-07-04 19:03:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:03:16 --> Final output sent to browser
DEBUG - 2017-07-04 19:03:16 --> Total execution time: 0.0740
ERROR - 2017-07-04 19:03:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:03:17 --> Config Class Initialized
INFO - 2017-07-04 19:03:17 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:03:17 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:03:17 --> Utf8 Class Initialized
INFO - 2017-07-04 19:03:17 --> URI Class Initialized
INFO - 2017-07-04 19:03:17 --> Router Class Initialized
INFO - 2017-07-04 19:03:17 --> Output Class Initialized
ERROR - 2017-07-04 19:03:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:03:17 --> Security Class Initialized
DEBUG - 2017-07-04 19:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:03:17 --> Input Class Initialized
INFO - 2017-07-04 19:03:17 --> Language Class Initialized
ERROR - 2017-07-04 19:03:17 --> 404 Page Not Found: Services/1498030057.mp3
INFO - 2017-07-04 19:03:17 --> Config Class Initialized
INFO - 2017-07-04 19:03:17 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:03:17 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:03:17 --> Utf8 Class Initialized
INFO - 2017-07-04 19:03:17 --> URI Class Initialized
INFO - 2017-07-04 19:03:17 --> Router Class Initialized
INFO - 2017-07-04 19:03:17 --> Output Class Initialized
INFO - 2017-07-04 19:03:17 --> Security Class Initialized
DEBUG - 2017-07-04 19:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:03:17 --> Input Class Initialized
INFO - 2017-07-04 19:03:17 --> Language Class Initialized
ERROR - 2017-07-04 19:03:17 --> 404 Page Not Found: Services/1497983379.mp3
ERROR - 2017-07-04 19:03:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:03:34 --> Config Class Initialized
INFO - 2017-07-04 19:03:34 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:03:34 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:03:34 --> Utf8 Class Initialized
INFO - 2017-07-04 19:03:34 --> URI Class Initialized
INFO - 2017-07-04 19:03:34 --> Router Class Initialized
INFO - 2017-07-04 19:03:34 --> Output Class Initialized
INFO - 2017-07-04 19:03:34 --> Security Class Initialized
DEBUG - 2017-07-04 19:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:03:34 --> Input Class Initialized
INFO - 2017-07-04 19:03:34 --> Language Class Initialized
INFO - 2017-07-04 19:03:34 --> Loader Class Initialized
INFO - 2017-07-04 19:03:34 --> Controller Class Initialized
INFO - 2017-07-04 19:03:34 --> Database Driver Class Initialized
INFO - 2017-07-04 19:03:34 --> Model Class Initialized
INFO - 2017-07-04 19:03:34 --> Helper loaded: form_helper
INFO - 2017-07-04 19:03:34 --> Helper loaded: url_helper
INFO - 2017-07-04 19:03:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:03:34 --> Model Class Initialized
ERROR - 2017-07-04 19:03:34 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\mystage\application\views\share.php 87
ERROR - 2017-07-04 19:03:34 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\mystage\application\views\share.php 87
INFO - 2017-07-04 19:03:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:03:34 --> Final output sent to browser
DEBUG - 2017-07-04 19:03:34 --> Total execution time: 0.0680
ERROR - 2017-07-04 19:03:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:03:35 --> Config Class Initialized
INFO - 2017-07-04 19:03:35 --> Hooks Class Initialized
ERROR - 2017-07-04 19:03:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
DEBUG - 2017-07-04 19:03:35 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:03:35 --> Config Class Initialized
INFO - 2017-07-04 19:03:35 --> Utf8 Class Initialized
INFO - 2017-07-04 19:03:35 --> URI Class Initialized
INFO - 2017-07-04 19:03:35 --> Router Class Initialized
INFO - 2017-07-04 19:03:35 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:03:35 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:03:35 --> Output Class Initialized
INFO - 2017-07-04 19:03:35 --> Utf8 Class Initialized
INFO - 2017-07-04 19:03:35 --> URI Class Initialized
INFO - 2017-07-04 19:03:35 --> Security Class Initialized
INFO - 2017-07-04 19:03:35 --> Router Class Initialized
DEBUG - 2017-07-04 19:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:03:35 --> Output Class Initialized
INFO - 2017-07-04 19:03:35 --> Security Class Initialized
INFO - 2017-07-04 19:03:35 --> Input Class Initialized
DEBUG - 2017-07-04 19:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:03:35 --> Language Class Initialized
INFO - 2017-07-04 19:03:35 --> Input Class Initialized
INFO - 2017-07-04 19:03:35 --> Language Class Initialized
ERROR - 2017-07-04 19:03:35 --> 404 Page Not Found: Services/1498030057.mp3
ERROR - 2017-07-04 19:03:35 --> 404 Page Not Found: Services/1497983379.mp3
ERROR - 2017-07-04 19:04:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:04:28 --> Config Class Initialized
INFO - 2017-07-04 19:04:28 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:04:28 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:04:28 --> Utf8 Class Initialized
INFO - 2017-07-04 19:04:28 --> URI Class Initialized
INFO - 2017-07-04 19:04:28 --> Router Class Initialized
INFO - 2017-07-04 19:04:28 --> Output Class Initialized
INFO - 2017-07-04 19:04:28 --> Security Class Initialized
DEBUG - 2017-07-04 19:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:04:28 --> Input Class Initialized
INFO - 2017-07-04 19:04:28 --> Language Class Initialized
INFO - 2017-07-04 19:04:28 --> Loader Class Initialized
INFO - 2017-07-04 19:04:28 --> Controller Class Initialized
INFO - 2017-07-04 19:04:28 --> Database Driver Class Initialized
INFO - 2017-07-04 19:04:28 --> Model Class Initialized
INFO - 2017-07-04 19:04:29 --> Helper loaded: form_helper
INFO - 2017-07-04 19:04:29 --> Helper loaded: url_helper
INFO - 2017-07-04 19:04:29 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:04:29 --> Model Class Initialized
ERROR - 2017-07-04 19:04:29 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\mystage\application\views\share.php 87
ERROR - 2017-07-04 19:04:29 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\mystage\application\views\share.php 87
INFO - 2017-07-04 19:04:29 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:04:29 --> Final output sent to browser
DEBUG - 2017-07-04 19:04:29 --> Total execution time: 0.0550
ERROR - 2017-07-04 19:04:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:04:55 --> Config Class Initialized
INFO - 2017-07-04 19:04:55 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:04:55 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:04:55 --> Utf8 Class Initialized
INFO - 2017-07-04 19:04:55 --> URI Class Initialized
INFO - 2017-07-04 19:04:55 --> Router Class Initialized
INFO - 2017-07-04 19:04:55 --> Output Class Initialized
INFO - 2017-07-04 19:04:55 --> Security Class Initialized
DEBUG - 2017-07-04 19:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:04:55 --> Input Class Initialized
INFO - 2017-07-04 19:04:55 --> Language Class Initialized
INFO - 2017-07-04 19:04:55 --> Loader Class Initialized
INFO - 2017-07-04 19:04:55 --> Controller Class Initialized
INFO - 2017-07-04 19:04:55 --> Database Driver Class Initialized
INFO - 2017-07-04 19:04:55 --> Model Class Initialized
INFO - 2017-07-04 19:04:55 --> Helper loaded: form_helper
INFO - 2017-07-04 19:04:55 --> Helper loaded: url_helper
INFO - 2017-07-04 19:04:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:04:55 --> Model Class Initialized
INFO - 2017-07-04 19:04:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:04:55 --> Final output sent to browser
DEBUG - 2017-07-04 19:04:55 --> Total execution time: 0.0690
ERROR - 2017-07-04 19:05:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:05:15 --> Config Class Initialized
INFO - 2017-07-04 19:05:15 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:05:15 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:05:15 --> Utf8 Class Initialized
INFO - 2017-07-04 19:05:15 --> URI Class Initialized
INFO - 2017-07-04 19:05:15 --> Router Class Initialized
INFO - 2017-07-04 19:05:15 --> Output Class Initialized
INFO - 2017-07-04 19:05:15 --> Security Class Initialized
DEBUG - 2017-07-04 19:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:05:15 --> Input Class Initialized
INFO - 2017-07-04 19:05:15 --> Language Class Initialized
INFO - 2017-07-04 19:05:15 --> Loader Class Initialized
INFO - 2017-07-04 19:05:15 --> Controller Class Initialized
INFO - 2017-07-04 19:05:15 --> Database Driver Class Initialized
INFO - 2017-07-04 19:05:15 --> Model Class Initialized
INFO - 2017-07-04 19:05:15 --> Helper loaded: form_helper
INFO - 2017-07-04 19:05:15 --> Helper loaded: url_helper
INFO - 2017-07-04 19:05:15 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:05:15 --> Model Class Initialized
INFO - 2017-07-04 19:05:15 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-07-04 19:05:15 --> Final output sent to browser
DEBUG - 2017-07-04 19:05:15 --> Total execution time: 0.0770
ERROR - 2017-07-04 19:05:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:05:19 --> Config Class Initialized
INFO - 2017-07-04 19:05:19 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:05:19 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:05:19 --> Utf8 Class Initialized
INFO - 2017-07-04 19:05:19 --> URI Class Initialized
INFO - 2017-07-04 19:05:19 --> Router Class Initialized
INFO - 2017-07-04 19:05:19 --> Output Class Initialized
INFO - 2017-07-04 19:05:19 --> Security Class Initialized
DEBUG - 2017-07-04 19:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:05:19 --> Input Class Initialized
INFO - 2017-07-04 19:05:19 --> Language Class Initialized
INFO - 2017-07-04 19:05:19 --> Loader Class Initialized
INFO - 2017-07-04 19:05:19 --> Controller Class Initialized
INFO - 2017-07-04 19:05:19 --> Database Driver Class Initialized
INFO - 2017-07-04 19:05:19 --> Model Class Initialized
INFO - 2017-07-04 19:05:19 --> Helper loaded: form_helper
INFO - 2017-07-04 19:05:19 --> Helper loaded: url_helper
INFO - 2017-07-04 19:05:19 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:05:19 --> Model Class Initialized
INFO - 2017-07-04 19:05:19 --> File loaded: C:\xampp\htdocs\mystage\application\views\purchase.php
INFO - 2017-07-04 19:05:19 --> Final output sent to browser
DEBUG - 2017-07-04 19:05:19 --> Total execution time: 0.0600
ERROR - 2017-07-04 19:05:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:05:21 --> Config Class Initialized
INFO - 2017-07-04 19:05:21 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:05:21 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:05:21 --> Utf8 Class Initialized
INFO - 2017-07-04 19:05:21 --> URI Class Initialized
INFO - 2017-07-04 19:05:21 --> Router Class Initialized
INFO - 2017-07-04 19:05:21 --> Output Class Initialized
INFO - 2017-07-04 19:05:21 --> Security Class Initialized
DEBUG - 2017-07-04 19:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:05:21 --> Input Class Initialized
INFO - 2017-07-04 19:05:21 --> Language Class Initialized
INFO - 2017-07-04 19:05:21 --> Loader Class Initialized
INFO - 2017-07-04 19:05:21 --> Controller Class Initialized
INFO - 2017-07-04 19:05:21 --> Database Driver Class Initialized
INFO - 2017-07-04 19:05:21 --> Model Class Initialized
INFO - 2017-07-04 19:05:21 --> Helper loaded: form_helper
INFO - 2017-07-04 19:05:21 --> Helper loaded: url_helper
INFO - 2017-07-04 19:05:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:05:21 --> Model Class Initialized
INFO - 2017-07-04 19:05:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:05:21 --> Final output sent to browser
DEBUG - 2017-07-04 19:05:21 --> Total execution time: 0.0560
ERROR - 2017-07-04 19:05:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:05:22 --> Config Class Initialized
INFO - 2017-07-04 19:05:22 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:05:22 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:05:22 --> Utf8 Class Initialized
INFO - 2017-07-04 19:05:22 --> URI Class Initialized
INFO - 2017-07-04 19:05:22 --> Router Class Initialized
INFO - 2017-07-04 19:05:22 --> Output Class Initialized
INFO - 2017-07-04 19:05:22 --> Security Class Initialized
DEBUG - 2017-07-04 19:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:05:22 --> Input Class Initialized
INFO - 2017-07-04 19:05:22 --> Language Class Initialized
INFO - 2017-07-04 19:05:22 --> Loader Class Initialized
INFO - 2017-07-04 19:05:22 --> Controller Class Initialized
INFO - 2017-07-04 19:05:22 --> Database Driver Class Initialized
INFO - 2017-07-04 19:05:22 --> Model Class Initialized
INFO - 2017-07-04 19:05:22 --> Helper loaded: form_helper
INFO - 2017-07-04 19:05:22 --> Helper loaded: url_helper
INFO - 2017-07-04 19:05:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:05:22 --> Model Class Initialized
INFO - 2017-07-04 19:05:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\purchase.php
INFO - 2017-07-04 19:05:22 --> Final output sent to browser
DEBUG - 2017-07-04 19:05:22 --> Total execution time: 0.0570
ERROR - 2017-07-04 19:05:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:05:26 --> Config Class Initialized
INFO - 2017-07-04 19:05:26 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:05:26 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:05:26 --> Utf8 Class Initialized
INFO - 2017-07-04 19:05:26 --> URI Class Initialized
INFO - 2017-07-04 19:05:26 --> Router Class Initialized
INFO - 2017-07-04 19:05:26 --> Output Class Initialized
INFO - 2017-07-04 19:05:26 --> Security Class Initialized
DEBUG - 2017-07-04 19:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:05:26 --> Input Class Initialized
INFO - 2017-07-04 19:05:26 --> Language Class Initialized
INFO - 2017-07-04 19:05:26 --> Loader Class Initialized
INFO - 2017-07-04 19:05:26 --> Controller Class Initialized
INFO - 2017-07-04 19:05:26 --> Database Driver Class Initialized
INFO - 2017-07-04 19:05:26 --> Model Class Initialized
INFO - 2017-07-04 19:05:26 --> Helper loaded: form_helper
INFO - 2017-07-04 19:05:26 --> Helper loaded: url_helper
INFO - 2017-07-04 19:05:26 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:05:26 --> Model Class Initialized
INFO - 2017-07-04 19:05:26 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:05:26 --> Final output sent to browser
DEBUG - 2017-07-04 19:05:26 --> Total execution time: 0.0540
ERROR - 2017-07-04 19:07:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:07:24 --> Config Class Initialized
INFO - 2017-07-04 19:07:24 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:07:24 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:07:24 --> Utf8 Class Initialized
INFO - 2017-07-04 19:07:24 --> URI Class Initialized
INFO - 2017-07-04 19:07:24 --> Router Class Initialized
INFO - 2017-07-04 19:07:24 --> Output Class Initialized
INFO - 2017-07-04 19:07:24 --> Security Class Initialized
DEBUG - 2017-07-04 19:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:07:24 --> Input Class Initialized
INFO - 2017-07-04 19:07:24 --> Language Class Initialized
INFO - 2017-07-04 19:07:24 --> Loader Class Initialized
INFO - 2017-07-04 19:07:24 --> Controller Class Initialized
INFO - 2017-07-04 19:07:24 --> Database Driver Class Initialized
INFO - 2017-07-04 19:07:24 --> Model Class Initialized
INFO - 2017-07-04 19:07:24 --> Helper loaded: form_helper
INFO - 2017-07-04 19:07:24 --> Helper loaded: url_helper
INFO - 2017-07-04 19:07:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:07:24 --> Model Class Initialized
INFO - 2017-07-04 19:07:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:07:24 --> Final output sent to browser
DEBUG - 2017-07-04 19:07:24 --> Total execution time: 0.0770
ERROR - 2017-07-04 19:07:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:07:57 --> Config Class Initialized
INFO - 2017-07-04 19:07:57 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:07:57 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:07:57 --> Utf8 Class Initialized
INFO - 2017-07-04 19:07:57 --> URI Class Initialized
INFO - 2017-07-04 19:07:57 --> Router Class Initialized
INFO - 2017-07-04 19:07:57 --> Output Class Initialized
INFO - 2017-07-04 19:07:57 --> Security Class Initialized
DEBUG - 2017-07-04 19:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:07:57 --> Input Class Initialized
INFO - 2017-07-04 19:07:57 --> Language Class Initialized
INFO - 2017-07-04 19:07:57 --> Loader Class Initialized
INFO - 2017-07-04 19:07:57 --> Controller Class Initialized
INFO - 2017-07-04 19:07:57 --> Database Driver Class Initialized
INFO - 2017-07-04 19:07:57 --> Model Class Initialized
INFO - 2017-07-04 19:07:57 --> Helper loaded: form_helper
INFO - 2017-07-04 19:07:57 --> Helper loaded: url_helper
INFO - 2017-07-04 19:07:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:07:57 --> Model Class Initialized
INFO - 2017-07-04 19:07:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:07:57 --> Final output sent to browser
DEBUG - 2017-07-04 19:07:57 --> Total execution time: 0.0700
ERROR - 2017-07-04 19:09:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:09:22 --> Config Class Initialized
INFO - 2017-07-04 19:09:22 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:09:22 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:09:22 --> Utf8 Class Initialized
INFO - 2017-07-04 19:09:22 --> URI Class Initialized
INFO - 2017-07-04 19:09:22 --> Router Class Initialized
INFO - 2017-07-04 19:09:22 --> Output Class Initialized
INFO - 2017-07-04 19:09:22 --> Security Class Initialized
DEBUG - 2017-07-04 19:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:09:22 --> Input Class Initialized
INFO - 2017-07-04 19:09:22 --> Language Class Initialized
INFO - 2017-07-04 19:09:22 --> Loader Class Initialized
INFO - 2017-07-04 19:09:22 --> Controller Class Initialized
INFO - 2017-07-04 19:09:22 --> Database Driver Class Initialized
INFO - 2017-07-04 19:09:22 --> Model Class Initialized
INFO - 2017-07-04 19:09:22 --> Helper loaded: form_helper
INFO - 2017-07-04 19:09:22 --> Helper loaded: url_helper
INFO - 2017-07-04 19:09:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:09:22 --> Model Class Initialized
INFO - 2017-07-04 19:09:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:09:22 --> Final output sent to browser
DEBUG - 2017-07-04 19:09:22 --> Total execution time: 0.0660
ERROR - 2017-07-04 19:09:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:09:24 --> Config Class Initialized
INFO - 2017-07-04 19:09:24 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:09:24 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:09:24 --> Utf8 Class Initialized
INFO - 2017-07-04 19:09:24 --> URI Class Initialized
INFO - 2017-07-04 19:09:24 --> Router Class Initialized
INFO - 2017-07-04 19:09:24 --> Output Class Initialized
INFO - 2017-07-04 19:09:24 --> Security Class Initialized
DEBUG - 2017-07-04 19:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:09:24 --> Input Class Initialized
INFO - 2017-07-04 19:09:24 --> Language Class Initialized
INFO - 2017-07-04 19:09:24 --> Loader Class Initialized
INFO - 2017-07-04 19:09:24 --> Controller Class Initialized
INFO - 2017-07-04 19:09:24 --> Database Driver Class Initialized
INFO - 2017-07-04 19:09:24 --> Model Class Initialized
INFO - 2017-07-04 19:09:24 --> Helper loaded: form_helper
INFO - 2017-07-04 19:09:24 --> Helper loaded: url_helper
INFO - 2017-07-04 19:09:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:09:24 --> Model Class Initialized
INFO - 2017-07-04 19:09:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:09:24 --> Final output sent to browser
DEBUG - 2017-07-04 19:09:24 --> Total execution time: 0.0730
ERROR - 2017-07-04 19:09:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:09:26 --> Config Class Initialized
INFO - 2017-07-04 19:09:26 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:09:26 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:09:26 --> Utf8 Class Initialized
INFO - 2017-07-04 19:09:26 --> URI Class Initialized
INFO - 2017-07-04 19:09:26 --> Router Class Initialized
INFO - 2017-07-04 19:09:26 --> Output Class Initialized
INFO - 2017-07-04 19:09:26 --> Security Class Initialized
DEBUG - 2017-07-04 19:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:09:26 --> Input Class Initialized
INFO - 2017-07-04 19:09:26 --> Language Class Initialized
INFO - 2017-07-04 19:09:26 --> Loader Class Initialized
INFO - 2017-07-04 19:09:26 --> Controller Class Initialized
INFO - 2017-07-04 19:09:26 --> Database Driver Class Initialized
INFO - 2017-07-04 19:09:26 --> Model Class Initialized
INFO - 2017-07-04 19:09:26 --> Helper loaded: form_helper
INFO - 2017-07-04 19:09:26 --> Helper loaded: url_helper
INFO - 2017-07-04 19:09:26 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:09:26 --> Model Class Initialized
INFO - 2017-07-04 19:09:26 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:09:26 --> Final output sent to browser
DEBUG - 2017-07-04 19:09:26 --> Total execution time: 0.0940
ERROR - 2017-07-04 19:09:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:09:46 --> Config Class Initialized
INFO - 2017-07-04 19:09:46 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:09:46 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:09:46 --> Utf8 Class Initialized
INFO - 2017-07-04 19:09:46 --> URI Class Initialized
INFO - 2017-07-04 19:09:46 --> Router Class Initialized
INFO - 2017-07-04 19:09:46 --> Output Class Initialized
INFO - 2017-07-04 19:09:46 --> Security Class Initialized
DEBUG - 2017-07-04 19:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:09:46 --> Input Class Initialized
INFO - 2017-07-04 19:09:46 --> Language Class Initialized
INFO - 2017-07-04 19:09:46 --> Loader Class Initialized
INFO - 2017-07-04 19:09:46 --> Controller Class Initialized
INFO - 2017-07-04 19:09:46 --> Database Driver Class Initialized
INFO - 2017-07-04 19:09:46 --> Model Class Initialized
INFO - 2017-07-04 19:09:46 --> Helper loaded: form_helper
INFO - 2017-07-04 19:09:46 --> Helper loaded: url_helper
INFO - 2017-07-04 19:09:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:09:46 --> Model Class Initialized
INFO - 2017-07-04 19:09:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:09:46 --> Final output sent to browser
DEBUG - 2017-07-04 19:09:46 --> Total execution time: 0.0710
ERROR - 2017-07-04 19:09:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:09:49 --> Config Class Initialized
INFO - 2017-07-04 19:09:49 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:09:49 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:09:49 --> Utf8 Class Initialized
INFO - 2017-07-04 19:09:49 --> URI Class Initialized
INFO - 2017-07-04 19:09:49 --> Router Class Initialized
INFO - 2017-07-04 19:09:49 --> Output Class Initialized
INFO - 2017-07-04 19:09:49 --> Security Class Initialized
DEBUG - 2017-07-04 19:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:09:49 --> Input Class Initialized
INFO - 2017-07-04 19:09:49 --> Language Class Initialized
INFO - 2017-07-04 19:09:49 --> Loader Class Initialized
INFO - 2017-07-04 19:09:49 --> Controller Class Initialized
INFO - 2017-07-04 19:09:49 --> Database Driver Class Initialized
INFO - 2017-07-04 19:09:49 --> Model Class Initialized
INFO - 2017-07-04 19:09:49 --> Helper loaded: form_helper
INFO - 2017-07-04 19:09:49 --> Helper loaded: url_helper
INFO - 2017-07-04 19:09:49 --> Model Class Initialized
INFO - 2017-07-04 19:09:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:09:50 --> Model Class Initialized
INFO - 2017-07-04 19:09:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:09:50 --> Final output sent to browser
DEBUG - 2017-07-04 19:09:50 --> Total execution time: 0.2630
ERROR - 2017-07-04 19:09:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:09:55 --> Config Class Initialized
INFO - 2017-07-04 19:09:55 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:09:55 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:09:55 --> Utf8 Class Initialized
INFO - 2017-07-04 19:09:55 --> URI Class Initialized
INFO - 2017-07-04 19:09:55 --> Router Class Initialized
INFO - 2017-07-04 19:09:55 --> Output Class Initialized
INFO - 2017-07-04 19:09:55 --> Security Class Initialized
DEBUG - 2017-07-04 19:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:09:55 --> Input Class Initialized
INFO - 2017-07-04 19:09:55 --> Language Class Initialized
INFO - 2017-07-04 19:09:55 --> Loader Class Initialized
INFO - 2017-07-04 19:09:55 --> Controller Class Initialized
INFO - 2017-07-04 19:09:55 --> Database Driver Class Initialized
INFO - 2017-07-04 19:09:55 --> Model Class Initialized
INFO - 2017-07-04 19:09:55 --> Helper loaded: form_helper
INFO - 2017-07-04 19:09:55 --> Helper loaded: url_helper
INFO - 2017-07-04 19:09:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:09:55 --> Model Class Initialized
INFO - 2017-07-04 19:09:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:09:55 --> Final output sent to browser
DEBUG - 2017-07-04 19:09:55 --> Total execution time: 0.0630
ERROR - 2017-07-04 19:10:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:10:39 --> Config Class Initialized
INFO - 2017-07-04 19:10:39 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:10:39 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:10:39 --> Utf8 Class Initialized
INFO - 2017-07-04 19:10:39 --> URI Class Initialized
INFO - 2017-07-04 19:10:39 --> Router Class Initialized
INFO - 2017-07-04 19:10:39 --> Output Class Initialized
INFO - 2017-07-04 19:10:39 --> Security Class Initialized
DEBUG - 2017-07-04 19:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:10:39 --> Input Class Initialized
INFO - 2017-07-04 19:10:39 --> Language Class Initialized
INFO - 2017-07-04 19:10:39 --> Loader Class Initialized
INFO - 2017-07-04 19:10:39 --> Controller Class Initialized
INFO - 2017-07-04 19:10:39 --> Database Driver Class Initialized
INFO - 2017-07-04 19:10:39 --> Model Class Initialized
INFO - 2017-07-04 19:10:39 --> Helper loaded: form_helper
INFO - 2017-07-04 19:10:39 --> Helper loaded: url_helper
INFO - 2017-07-04 19:10:39 --> Model Class Initialized
INFO - 2017-07-04 19:10:39 --> Final output sent to browser
DEBUG - 2017-07-04 19:10:39 --> Total execution time: 0.0610
ERROR - 2017-07-04 19:10:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:10:41 --> Config Class Initialized
INFO - 2017-07-04 19:10:41 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:10:41 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:10:41 --> Utf8 Class Initialized
INFO - 2017-07-04 19:10:41 --> URI Class Initialized
INFO - 2017-07-04 19:10:41 --> Router Class Initialized
INFO - 2017-07-04 19:10:41 --> Output Class Initialized
INFO - 2017-07-04 19:10:41 --> Security Class Initialized
DEBUG - 2017-07-04 19:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:10:41 --> Input Class Initialized
INFO - 2017-07-04 19:10:41 --> Language Class Initialized
INFO - 2017-07-04 19:10:41 --> Loader Class Initialized
INFO - 2017-07-04 19:10:41 --> Controller Class Initialized
INFO - 2017-07-04 19:10:41 --> Database Driver Class Initialized
INFO - 2017-07-04 19:10:41 --> Model Class Initialized
INFO - 2017-07-04 19:10:41 --> Helper loaded: form_helper
INFO - 2017-07-04 19:10:41 --> Helper loaded: url_helper
INFO - 2017-07-04 19:10:41 --> Model Class Initialized
INFO - 2017-07-04 19:10:41 --> Final output sent to browser
DEBUG - 2017-07-04 19:10:41 --> Total execution time: 0.0600
ERROR - 2017-07-04 19:10:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:10:53 --> Config Class Initialized
INFO - 2017-07-04 19:10:53 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:10:53 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:10:53 --> Utf8 Class Initialized
INFO - 2017-07-04 19:10:53 --> URI Class Initialized
INFO - 2017-07-04 19:10:53 --> Router Class Initialized
INFO - 2017-07-04 19:10:53 --> Output Class Initialized
INFO - 2017-07-04 19:10:53 --> Security Class Initialized
DEBUG - 2017-07-04 19:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:10:53 --> Input Class Initialized
INFO - 2017-07-04 19:10:53 --> Language Class Initialized
INFO - 2017-07-04 19:10:53 --> Loader Class Initialized
INFO - 2017-07-04 19:10:53 --> Controller Class Initialized
INFO - 2017-07-04 19:10:53 --> Database Driver Class Initialized
INFO - 2017-07-04 19:10:53 --> Model Class Initialized
INFO - 2017-07-04 19:10:53 --> Helper loaded: form_helper
INFO - 2017-07-04 19:10:53 --> Helper loaded: url_helper
INFO - 2017-07-04 19:10:53 --> Model Class Initialized
INFO - 2017-07-04 19:10:54 --> Final output sent to browser
DEBUG - 2017-07-04 19:10:54 --> Total execution time: 0.0800
ERROR - 2017-07-04 19:10:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:10:54 --> Config Class Initialized
INFO - 2017-07-04 19:10:54 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:10:54 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:10:54 --> Utf8 Class Initialized
INFO - 2017-07-04 19:10:54 --> URI Class Initialized
INFO - 2017-07-04 19:10:54 --> Router Class Initialized
INFO - 2017-07-04 19:10:54 --> Output Class Initialized
INFO - 2017-07-04 19:10:54 --> Security Class Initialized
DEBUG - 2017-07-04 19:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:10:54 --> Input Class Initialized
INFO - 2017-07-04 19:10:54 --> Language Class Initialized
INFO - 2017-07-04 19:10:54 --> Loader Class Initialized
INFO - 2017-07-04 19:10:54 --> Controller Class Initialized
INFO - 2017-07-04 19:10:54 --> Database Driver Class Initialized
INFO - 2017-07-04 19:10:54 --> Model Class Initialized
INFO - 2017-07-04 19:10:54 --> Helper loaded: form_helper
INFO - 2017-07-04 19:10:54 --> Helper loaded: url_helper
INFO - 2017-07-04 19:10:54 --> Model Class Initialized
INFO - 2017-07-04 19:10:54 --> Final output sent to browser
DEBUG - 2017-07-04 19:10:54 --> Total execution time: 0.0430
ERROR - 2017-07-04 19:11:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:11:02 --> Config Class Initialized
INFO - 2017-07-04 19:11:02 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:11:02 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:11:02 --> Utf8 Class Initialized
INFO - 2017-07-04 19:11:02 --> URI Class Initialized
INFO - 2017-07-04 19:11:02 --> Router Class Initialized
INFO - 2017-07-04 19:11:02 --> Output Class Initialized
INFO - 2017-07-04 19:11:02 --> Security Class Initialized
DEBUG - 2017-07-04 19:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:11:02 --> Input Class Initialized
INFO - 2017-07-04 19:11:02 --> Language Class Initialized
INFO - 2017-07-04 19:11:02 --> Loader Class Initialized
INFO - 2017-07-04 19:11:02 --> Controller Class Initialized
INFO - 2017-07-04 19:11:02 --> Database Driver Class Initialized
INFO - 2017-07-04 19:11:02 --> Model Class Initialized
INFO - 2017-07-04 19:11:02 --> Helper loaded: form_helper
INFO - 2017-07-04 19:11:02 --> Helper loaded: url_helper
INFO - 2017-07-04 19:11:02 --> Model Class Initialized
INFO - 2017-07-04 19:11:02 --> Final output sent to browser
DEBUG - 2017-07-04 19:11:02 --> Total execution time: 0.0460
ERROR - 2017-07-04 19:13:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:13:54 --> Config Class Initialized
INFO - 2017-07-04 19:13:54 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:13:54 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:13:54 --> Utf8 Class Initialized
INFO - 2017-07-04 19:13:54 --> URI Class Initialized
INFO - 2017-07-04 19:13:54 --> Router Class Initialized
INFO - 2017-07-04 19:13:54 --> Output Class Initialized
INFO - 2017-07-04 19:13:54 --> Security Class Initialized
DEBUG - 2017-07-04 19:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:13:54 --> Input Class Initialized
INFO - 2017-07-04 19:13:54 --> Language Class Initialized
INFO - 2017-07-04 19:13:54 --> Loader Class Initialized
INFO - 2017-07-04 19:13:54 --> Controller Class Initialized
INFO - 2017-07-04 19:13:54 --> Database Driver Class Initialized
INFO - 2017-07-04 19:13:54 --> Model Class Initialized
INFO - 2017-07-04 19:13:54 --> Helper loaded: form_helper
INFO - 2017-07-04 19:13:54 --> Helper loaded: url_helper
INFO - 2017-07-04 19:13:54 --> Model Class Initialized
INFO - 2017-07-04 19:13:54 --> Final output sent to browser
DEBUG - 2017-07-04 19:13:54 --> Total execution time: 0.0570
ERROR - 2017-07-04 19:13:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:13:55 --> Config Class Initialized
INFO - 2017-07-04 19:13:55 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:13:55 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:13:55 --> Utf8 Class Initialized
INFO - 2017-07-04 19:13:55 --> URI Class Initialized
INFO - 2017-07-04 19:13:55 --> Router Class Initialized
INFO - 2017-07-04 19:13:55 --> Output Class Initialized
INFO - 2017-07-04 19:13:55 --> Security Class Initialized
DEBUG - 2017-07-04 19:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:13:55 --> Input Class Initialized
INFO - 2017-07-04 19:13:55 --> Language Class Initialized
INFO - 2017-07-04 19:13:55 --> Loader Class Initialized
INFO - 2017-07-04 19:13:55 --> Controller Class Initialized
INFO - 2017-07-04 19:13:55 --> Database Driver Class Initialized
INFO - 2017-07-04 19:13:55 --> Model Class Initialized
INFO - 2017-07-04 19:13:55 --> Helper loaded: form_helper
INFO - 2017-07-04 19:13:55 --> Helper loaded: url_helper
INFO - 2017-07-04 19:13:55 --> Model Class Initialized
INFO - 2017-07-04 19:13:55 --> Final output sent to browser
DEBUG - 2017-07-04 19:13:55 --> Total execution time: 0.0830
ERROR - 2017-07-04 19:14:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:14:04 --> Config Class Initialized
INFO - 2017-07-04 19:14:04 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:14:04 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:14:04 --> Utf8 Class Initialized
INFO - 2017-07-04 19:14:04 --> URI Class Initialized
INFO - 2017-07-04 19:14:04 --> Router Class Initialized
INFO - 2017-07-04 19:14:04 --> Output Class Initialized
INFO - 2017-07-04 19:14:04 --> Security Class Initialized
DEBUG - 2017-07-04 19:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:14:04 --> Input Class Initialized
INFO - 2017-07-04 19:14:04 --> Language Class Initialized
INFO - 2017-07-04 19:14:04 --> Loader Class Initialized
INFO - 2017-07-04 19:14:04 --> Controller Class Initialized
INFO - 2017-07-04 19:14:04 --> Database Driver Class Initialized
INFO - 2017-07-04 19:14:04 --> Model Class Initialized
INFO - 2017-07-04 19:14:04 --> Helper loaded: form_helper
INFO - 2017-07-04 19:14:04 --> Helper loaded: url_helper
INFO - 2017-07-04 19:14:04 --> Model Class Initialized
INFO - 2017-07-04 19:14:04 --> Final output sent to browser
DEBUG - 2017-07-04 19:14:04 --> Total execution time: 0.0780
ERROR - 2017-07-04 19:14:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:14:10 --> Config Class Initialized
INFO - 2017-07-04 19:14:10 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:14:10 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:14:10 --> Utf8 Class Initialized
INFO - 2017-07-04 19:14:10 --> URI Class Initialized
INFO - 2017-07-04 19:14:10 --> Router Class Initialized
INFO - 2017-07-04 19:14:10 --> Output Class Initialized
INFO - 2017-07-04 19:14:10 --> Security Class Initialized
DEBUG - 2017-07-04 19:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:14:10 --> Input Class Initialized
INFO - 2017-07-04 19:14:10 --> Language Class Initialized
INFO - 2017-07-04 19:14:10 --> Loader Class Initialized
INFO - 2017-07-04 19:14:10 --> Controller Class Initialized
INFO - 2017-07-04 19:14:10 --> Database Driver Class Initialized
INFO - 2017-07-04 19:14:10 --> Model Class Initialized
INFO - 2017-07-04 19:14:10 --> Helper loaded: form_helper
INFO - 2017-07-04 19:14:10 --> Helper loaded: url_helper
INFO - 2017-07-04 19:14:10 --> Model Class Initialized
INFO - 2017-07-04 19:14:10 --> Final output sent to browser
DEBUG - 2017-07-04 19:14:10 --> Total execution time: 0.3760
ERROR - 2017-07-04 19:14:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:14:20 --> Config Class Initialized
INFO - 2017-07-04 19:14:20 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:14:20 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:14:20 --> Utf8 Class Initialized
INFO - 2017-07-04 19:14:20 --> URI Class Initialized
INFO - 2017-07-04 19:14:20 --> Router Class Initialized
INFO - 2017-07-04 19:14:20 --> Output Class Initialized
INFO - 2017-07-04 19:14:20 --> Security Class Initialized
DEBUG - 2017-07-04 19:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:14:20 --> Input Class Initialized
INFO - 2017-07-04 19:14:20 --> Language Class Initialized
INFO - 2017-07-04 19:14:20 --> Loader Class Initialized
INFO - 2017-07-04 19:14:20 --> Controller Class Initialized
INFO - 2017-07-04 19:14:20 --> Database Driver Class Initialized
INFO - 2017-07-04 19:14:20 --> Model Class Initialized
INFO - 2017-07-04 19:14:20 --> Helper loaded: form_helper
INFO - 2017-07-04 19:14:20 --> Helper loaded: url_helper
INFO - 2017-07-04 19:14:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:14:20 --> Model Class Initialized
INFO - 2017-07-04 19:14:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:14:20 --> Final output sent to browser
DEBUG - 2017-07-04 19:14:20 --> Total execution time: 0.0720
ERROR - 2017-07-04 19:14:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:14:32 --> Config Class Initialized
INFO - 2017-07-04 19:14:32 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:14:32 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:14:32 --> Utf8 Class Initialized
INFO - 2017-07-04 19:14:32 --> URI Class Initialized
INFO - 2017-07-04 19:14:32 --> Router Class Initialized
INFO - 2017-07-04 19:14:32 --> Output Class Initialized
INFO - 2017-07-04 19:14:32 --> Security Class Initialized
DEBUG - 2017-07-04 19:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:14:32 --> Input Class Initialized
INFO - 2017-07-04 19:14:32 --> Language Class Initialized
INFO - 2017-07-04 19:14:32 --> Loader Class Initialized
INFO - 2017-07-04 19:14:32 --> Controller Class Initialized
INFO - 2017-07-04 19:14:32 --> Database Driver Class Initialized
INFO - 2017-07-04 19:14:32 --> Model Class Initialized
INFO - 2017-07-04 19:14:32 --> Helper loaded: form_helper
INFO - 2017-07-04 19:14:32 --> Helper loaded: url_helper
INFO - 2017-07-04 19:14:32 --> Model Class Initialized
INFO - 2017-07-04 19:14:32 --> Final output sent to browser
DEBUG - 2017-07-04 19:14:32 --> Total execution time: 0.0470
ERROR - 2017-07-04 19:14:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:14:59 --> Config Class Initialized
INFO - 2017-07-04 19:14:59 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:14:59 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:14:59 --> Utf8 Class Initialized
INFO - 2017-07-04 19:14:59 --> URI Class Initialized
INFO - 2017-07-04 19:14:59 --> Router Class Initialized
INFO - 2017-07-04 19:14:59 --> Output Class Initialized
INFO - 2017-07-04 19:14:59 --> Security Class Initialized
DEBUG - 2017-07-04 19:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:14:59 --> Input Class Initialized
INFO - 2017-07-04 19:14:59 --> Language Class Initialized
INFO - 2017-07-04 19:14:59 --> Loader Class Initialized
INFO - 2017-07-04 19:14:59 --> Controller Class Initialized
INFO - 2017-07-04 19:14:59 --> Database Driver Class Initialized
INFO - 2017-07-04 19:14:59 --> Model Class Initialized
INFO - 2017-07-04 19:14:59 --> Helper loaded: form_helper
INFO - 2017-07-04 19:14:59 --> Helper loaded: url_helper
INFO - 2017-07-04 19:14:59 --> Model Class Initialized
INFO - 2017-07-04 19:14:59 --> Final output sent to browser
DEBUG - 2017-07-04 19:14:59 --> Total execution time: 0.0970
ERROR - 2017-07-04 19:15:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:15:06 --> Config Class Initialized
INFO - 2017-07-04 19:15:06 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:15:06 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:15:06 --> Utf8 Class Initialized
INFO - 2017-07-04 19:15:06 --> URI Class Initialized
INFO - 2017-07-04 19:15:06 --> Router Class Initialized
INFO - 2017-07-04 19:15:06 --> Output Class Initialized
INFO - 2017-07-04 19:15:06 --> Security Class Initialized
DEBUG - 2017-07-04 19:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:15:06 --> Input Class Initialized
INFO - 2017-07-04 19:15:06 --> Language Class Initialized
INFO - 2017-07-04 19:15:06 --> Loader Class Initialized
INFO - 2017-07-04 19:15:06 --> Controller Class Initialized
INFO - 2017-07-04 19:15:06 --> Database Driver Class Initialized
INFO - 2017-07-04 19:15:06 --> Model Class Initialized
INFO - 2017-07-04 19:15:06 --> Helper loaded: form_helper
INFO - 2017-07-04 19:15:06 --> Helper loaded: url_helper
INFO - 2017-07-04 19:15:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:15:06 --> Model Class Initialized
INFO - 2017-07-04 19:15:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:15:06 --> Final output sent to browser
DEBUG - 2017-07-04 19:15:06 --> Total execution time: 0.0490
ERROR - 2017-07-04 19:15:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:15:20 --> Config Class Initialized
INFO - 2017-07-04 19:15:20 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:15:20 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:15:20 --> Utf8 Class Initialized
INFO - 2017-07-04 19:15:20 --> URI Class Initialized
INFO - 2017-07-04 19:15:20 --> Router Class Initialized
INFO - 2017-07-04 19:15:20 --> Output Class Initialized
INFO - 2017-07-04 19:15:20 --> Security Class Initialized
DEBUG - 2017-07-04 19:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:15:20 --> Input Class Initialized
INFO - 2017-07-04 19:15:20 --> Language Class Initialized
INFO - 2017-07-04 19:15:20 --> Loader Class Initialized
INFO - 2017-07-04 19:15:20 --> Controller Class Initialized
INFO - 2017-07-04 19:15:20 --> Database Driver Class Initialized
INFO - 2017-07-04 19:15:20 --> Model Class Initialized
INFO - 2017-07-04 19:15:20 --> Helper loaded: form_helper
INFO - 2017-07-04 19:15:20 --> Helper loaded: url_helper
INFO - 2017-07-04 19:15:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:15:20 --> Model Class Initialized
INFO - 2017-07-04 19:15:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\users.php
INFO - 2017-07-04 19:15:20 --> Final output sent to browser
DEBUG - 2017-07-04 19:15:20 --> Total execution time: 0.0640
ERROR - 2017-07-04 19:15:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:15:30 --> Config Class Initialized
INFO - 2017-07-04 19:15:30 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:15:30 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:15:30 --> Utf8 Class Initialized
INFO - 2017-07-04 19:15:30 --> URI Class Initialized
INFO - 2017-07-04 19:15:30 --> Router Class Initialized
INFO - 2017-07-04 19:15:30 --> Output Class Initialized
INFO - 2017-07-04 19:15:30 --> Security Class Initialized
DEBUG - 2017-07-04 19:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:15:30 --> Input Class Initialized
INFO - 2017-07-04 19:15:30 --> Language Class Initialized
INFO - 2017-07-04 19:15:30 --> Loader Class Initialized
INFO - 2017-07-04 19:15:30 --> Controller Class Initialized
INFO - 2017-07-04 19:15:30 --> Database Driver Class Initialized
INFO - 2017-07-04 19:15:30 --> Model Class Initialized
INFO - 2017-07-04 19:15:30 --> Helper loaded: form_helper
INFO - 2017-07-04 19:15:30 --> Helper loaded: url_helper
INFO - 2017-07-04 19:15:30 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:15:30 --> Model Class Initialized
INFO - 2017-07-04 19:15:30 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-04 19:15:30 --> Final output sent to browser
DEBUG - 2017-07-04 19:15:30 --> Total execution time: 0.0600
ERROR - 2017-07-04 19:15:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:15:33 --> Config Class Initialized
INFO - 2017-07-04 19:15:33 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:15:33 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:15:33 --> Utf8 Class Initialized
INFO - 2017-07-04 19:15:33 --> URI Class Initialized
INFO - 2017-07-04 19:15:33 --> Router Class Initialized
INFO - 2017-07-04 19:15:33 --> Output Class Initialized
INFO - 2017-07-04 19:15:33 --> Security Class Initialized
DEBUG - 2017-07-04 19:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:15:33 --> Input Class Initialized
INFO - 2017-07-04 19:15:33 --> Language Class Initialized
INFO - 2017-07-04 19:15:33 --> Loader Class Initialized
INFO - 2017-07-04 19:15:33 --> Controller Class Initialized
INFO - 2017-07-04 19:15:33 --> Database Driver Class Initialized
INFO - 2017-07-04 19:15:33 --> Model Class Initialized
INFO - 2017-07-04 19:15:33 --> Helper loaded: form_helper
INFO - 2017-07-04 19:15:33 --> Helper loaded: url_helper
INFO - 2017-07-04 19:15:33 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:15:33 --> Model Class Initialized
INFO - 2017-07-04 19:15:33 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-04 19:15:33 --> Final output sent to browser
DEBUG - 2017-07-04 19:15:33 --> Total execution time: 0.1010
ERROR - 2017-07-04 19:15:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:15:40 --> Config Class Initialized
INFO - 2017-07-04 19:15:40 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:15:40 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:15:40 --> Utf8 Class Initialized
INFO - 2017-07-04 19:15:40 --> URI Class Initialized
INFO - 2017-07-04 19:15:40 --> Router Class Initialized
INFO - 2017-07-04 19:15:40 --> Output Class Initialized
INFO - 2017-07-04 19:15:40 --> Security Class Initialized
DEBUG - 2017-07-04 19:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:15:40 --> Input Class Initialized
INFO - 2017-07-04 19:15:40 --> Language Class Initialized
INFO - 2017-07-04 19:15:40 --> Loader Class Initialized
INFO - 2017-07-04 19:15:40 --> Controller Class Initialized
INFO - 2017-07-04 19:15:40 --> Database Driver Class Initialized
INFO - 2017-07-04 19:15:40 --> Model Class Initialized
INFO - 2017-07-04 19:15:40 --> Helper loaded: form_helper
INFO - 2017-07-04 19:15:40 --> Helper loaded: url_helper
INFO - 2017-07-04 19:15:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:15:40 --> Model Class Initialized
INFO - 2017-07-04 19:15:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\purchase.php
INFO - 2017-07-04 19:15:40 --> Final output sent to browser
DEBUG - 2017-07-04 19:15:40 --> Total execution time: 0.0780
ERROR - 2017-07-04 19:15:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:15:42 --> Config Class Initialized
INFO - 2017-07-04 19:15:42 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:15:42 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:15:42 --> Utf8 Class Initialized
INFO - 2017-07-04 19:15:42 --> URI Class Initialized
INFO - 2017-07-04 19:15:42 --> Router Class Initialized
INFO - 2017-07-04 19:15:42 --> Output Class Initialized
INFO - 2017-07-04 19:15:42 --> Security Class Initialized
DEBUG - 2017-07-04 19:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:15:42 --> Input Class Initialized
INFO - 2017-07-04 19:15:42 --> Language Class Initialized
INFO - 2017-07-04 19:15:42 --> Loader Class Initialized
INFO - 2017-07-04 19:15:42 --> Controller Class Initialized
INFO - 2017-07-04 19:15:42 --> Database Driver Class Initialized
INFO - 2017-07-04 19:15:42 --> Model Class Initialized
INFO - 2017-07-04 19:15:42 --> Helper loaded: form_helper
INFO - 2017-07-04 19:15:42 --> Helper loaded: url_helper
INFO - 2017-07-04 19:15:42 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:15:42 --> Model Class Initialized
INFO - 2017-07-04 19:15:42 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:15:42 --> Final output sent to browser
DEBUG - 2017-07-04 19:15:42 --> Total execution time: 0.0540
ERROR - 2017-07-04 19:15:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:15:44 --> Config Class Initialized
INFO - 2017-07-04 19:15:44 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:15:44 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:15:44 --> Utf8 Class Initialized
INFO - 2017-07-04 19:15:44 --> URI Class Initialized
INFO - 2017-07-04 19:15:44 --> Router Class Initialized
INFO - 2017-07-04 19:15:44 --> Output Class Initialized
INFO - 2017-07-04 19:15:44 --> Security Class Initialized
DEBUG - 2017-07-04 19:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:15:44 --> Input Class Initialized
INFO - 2017-07-04 19:15:44 --> Language Class Initialized
INFO - 2017-07-04 19:15:44 --> Loader Class Initialized
INFO - 2017-07-04 19:15:44 --> Controller Class Initialized
INFO - 2017-07-04 19:15:44 --> Database Driver Class Initialized
INFO - 2017-07-04 19:15:44 --> Model Class Initialized
INFO - 2017-07-04 19:15:44 --> Helper loaded: form_helper
INFO - 2017-07-04 19:15:44 --> Helper loaded: url_helper
INFO - 2017-07-04 19:15:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:15:44 --> Model Class Initialized
INFO - 2017-07-04 19:15:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\purchase.php
INFO - 2017-07-04 19:15:44 --> Final output sent to browser
DEBUG - 2017-07-04 19:15:44 --> Total execution time: 0.0580
ERROR - 2017-07-04 19:15:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:15:52 --> Config Class Initialized
INFO - 2017-07-04 19:15:52 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:15:52 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:15:52 --> Utf8 Class Initialized
INFO - 2017-07-04 19:15:52 --> URI Class Initialized
INFO - 2017-07-04 19:15:52 --> Router Class Initialized
INFO - 2017-07-04 19:15:52 --> Output Class Initialized
INFO - 2017-07-04 19:15:52 --> Security Class Initialized
DEBUG - 2017-07-04 19:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:15:52 --> Input Class Initialized
INFO - 2017-07-04 19:15:52 --> Language Class Initialized
INFO - 2017-07-04 19:15:52 --> Loader Class Initialized
INFO - 2017-07-04 19:15:52 --> Controller Class Initialized
INFO - 2017-07-04 19:15:52 --> Database Driver Class Initialized
INFO - 2017-07-04 19:15:52 --> Model Class Initialized
INFO - 2017-07-04 19:15:52 --> Helper loaded: form_helper
INFO - 2017-07-04 19:15:52 --> Helper loaded: url_helper
INFO - 2017-07-04 19:15:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:15:52 --> Model Class Initialized
INFO - 2017-07-04 19:15:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:15:52 --> Final output sent to browser
DEBUG - 2017-07-04 19:15:52 --> Total execution time: 0.0570
ERROR - 2017-07-04 19:16:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:16:35 --> Config Class Initialized
INFO - 2017-07-04 19:16:35 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:16:35 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:16:35 --> Utf8 Class Initialized
INFO - 2017-07-04 19:16:35 --> URI Class Initialized
INFO - 2017-07-04 19:16:35 --> Router Class Initialized
INFO - 2017-07-04 19:16:35 --> Output Class Initialized
INFO - 2017-07-04 19:16:35 --> Security Class Initialized
DEBUG - 2017-07-04 19:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:16:35 --> Input Class Initialized
INFO - 2017-07-04 19:16:35 --> Language Class Initialized
INFO - 2017-07-04 19:16:35 --> Loader Class Initialized
INFO - 2017-07-04 19:16:35 --> Controller Class Initialized
INFO - 2017-07-04 19:16:35 --> Database Driver Class Initialized
INFO - 2017-07-04 19:16:35 --> Model Class Initialized
INFO - 2017-07-04 19:16:35 --> Helper loaded: form_helper
INFO - 2017-07-04 19:16:35 --> Helper loaded: url_helper
INFO - 2017-07-04 19:16:35 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:16:35 --> Model Class Initialized
INFO - 2017-07-04 19:16:35 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:16:35 --> Final output sent to browser
DEBUG - 2017-07-04 19:16:35 --> Total execution time: 0.0670
ERROR - 2017-07-04 19:16:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:16:56 --> Config Class Initialized
INFO - 2017-07-04 19:16:56 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:16:56 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:16:56 --> Utf8 Class Initialized
INFO - 2017-07-04 19:16:56 --> URI Class Initialized
INFO - 2017-07-04 19:16:56 --> Router Class Initialized
INFO - 2017-07-04 19:16:56 --> Output Class Initialized
INFO - 2017-07-04 19:16:56 --> Security Class Initialized
DEBUG - 2017-07-04 19:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:16:56 --> Input Class Initialized
INFO - 2017-07-04 19:16:56 --> Language Class Initialized
INFO - 2017-07-04 19:16:56 --> Loader Class Initialized
INFO - 2017-07-04 19:16:56 --> Controller Class Initialized
INFO - 2017-07-04 19:16:56 --> Database Driver Class Initialized
INFO - 2017-07-04 19:16:56 --> Model Class Initialized
INFO - 2017-07-04 19:16:56 --> Helper loaded: form_helper
INFO - 2017-07-04 19:16:56 --> Helper loaded: url_helper
INFO - 2017-07-04 19:16:56 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:16:56 --> Model Class Initialized
INFO - 2017-07-04 19:16:56 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:16:56 --> Final output sent to browser
DEBUG - 2017-07-04 19:16:56 --> Total execution time: 0.0700
ERROR - 2017-07-04 19:17:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:17:36 --> Config Class Initialized
INFO - 2017-07-04 19:17:36 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:17:36 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:17:36 --> Utf8 Class Initialized
INFO - 2017-07-04 19:17:36 --> URI Class Initialized
INFO - 2017-07-04 19:17:36 --> Router Class Initialized
INFO - 2017-07-04 19:17:36 --> Output Class Initialized
INFO - 2017-07-04 19:17:36 --> Security Class Initialized
DEBUG - 2017-07-04 19:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:17:36 --> Input Class Initialized
INFO - 2017-07-04 19:17:36 --> Language Class Initialized
INFO - 2017-07-04 19:17:36 --> Loader Class Initialized
INFO - 2017-07-04 19:17:36 --> Controller Class Initialized
INFO - 2017-07-04 19:17:36 --> Database Driver Class Initialized
INFO - 2017-07-04 19:17:36 --> Model Class Initialized
INFO - 2017-07-04 19:17:36 --> Helper loaded: form_helper
INFO - 2017-07-04 19:17:36 --> Helper loaded: url_helper
INFO - 2017-07-04 19:17:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:17:36 --> Model Class Initialized
INFO - 2017-07-04 19:17:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:17:36 --> Final output sent to browser
DEBUG - 2017-07-04 19:17:36 --> Total execution time: 0.0890
ERROR - 2017-07-04 19:17:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:17:50 --> Config Class Initialized
INFO - 2017-07-04 19:17:50 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:17:50 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:17:50 --> Utf8 Class Initialized
INFO - 2017-07-04 19:17:50 --> URI Class Initialized
INFO - 2017-07-04 19:17:50 --> Router Class Initialized
INFO - 2017-07-04 19:17:50 --> Output Class Initialized
INFO - 2017-07-04 19:17:50 --> Security Class Initialized
DEBUG - 2017-07-04 19:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:17:50 --> Input Class Initialized
INFO - 2017-07-04 19:17:50 --> Language Class Initialized
INFO - 2017-07-04 19:17:50 --> Loader Class Initialized
INFO - 2017-07-04 19:17:50 --> Controller Class Initialized
INFO - 2017-07-04 19:17:50 --> Database Driver Class Initialized
INFO - 2017-07-04 19:17:50 --> Model Class Initialized
INFO - 2017-07-04 19:17:50 --> Helper loaded: form_helper
INFO - 2017-07-04 19:17:50 --> Helper loaded: url_helper
INFO - 2017-07-04 19:17:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:17:50 --> Model Class Initialized
INFO - 2017-07-04 19:17:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:17:50 --> Final output sent to browser
DEBUG - 2017-07-04 19:17:50 --> Total execution time: 0.0490
ERROR - 2017-07-04 19:18:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:18:10 --> Config Class Initialized
INFO - 2017-07-04 19:18:10 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:18:10 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:18:10 --> Utf8 Class Initialized
INFO - 2017-07-04 19:18:10 --> URI Class Initialized
INFO - 2017-07-04 19:18:10 --> Router Class Initialized
INFO - 2017-07-04 19:18:10 --> Output Class Initialized
INFO - 2017-07-04 19:18:10 --> Security Class Initialized
DEBUG - 2017-07-04 19:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:18:10 --> Input Class Initialized
INFO - 2017-07-04 19:18:10 --> Language Class Initialized
INFO - 2017-07-04 19:18:10 --> Loader Class Initialized
INFO - 2017-07-04 19:18:10 --> Controller Class Initialized
INFO - 2017-07-04 19:18:10 --> Database Driver Class Initialized
INFO - 2017-07-04 19:18:10 --> Model Class Initialized
INFO - 2017-07-04 19:18:10 --> Helper loaded: form_helper
INFO - 2017-07-04 19:18:10 --> Helper loaded: url_helper
INFO - 2017-07-04 19:18:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:18:10 --> Model Class Initialized
INFO - 2017-07-04 19:18:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:18:10 --> Final output sent to browser
DEBUG - 2017-07-04 19:18:10 --> Total execution time: 0.0650
ERROR - 2017-07-04 19:18:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:18:34 --> Config Class Initialized
INFO - 2017-07-04 19:18:34 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:18:34 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:18:34 --> Utf8 Class Initialized
INFO - 2017-07-04 19:18:34 --> URI Class Initialized
INFO - 2017-07-04 19:18:34 --> Router Class Initialized
INFO - 2017-07-04 19:18:34 --> Output Class Initialized
INFO - 2017-07-04 19:18:34 --> Security Class Initialized
DEBUG - 2017-07-04 19:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:18:34 --> Input Class Initialized
INFO - 2017-07-04 19:18:34 --> Language Class Initialized
INFO - 2017-07-04 19:18:34 --> Loader Class Initialized
INFO - 2017-07-04 19:18:34 --> Controller Class Initialized
INFO - 2017-07-04 19:18:34 --> Database Driver Class Initialized
INFO - 2017-07-04 19:18:34 --> Model Class Initialized
INFO - 2017-07-04 19:18:34 --> Helper loaded: form_helper
INFO - 2017-07-04 19:18:34 --> Helper loaded: url_helper
INFO - 2017-07-04 19:18:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:18:34 --> Model Class Initialized
INFO - 2017-07-04 19:18:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:18:34 --> Final output sent to browser
DEBUG - 2017-07-04 19:18:34 --> Total execution time: 0.0660
ERROR - 2017-07-04 19:18:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:18:49 --> Config Class Initialized
INFO - 2017-07-04 19:18:49 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:18:49 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:18:49 --> Utf8 Class Initialized
INFO - 2017-07-04 19:18:49 --> URI Class Initialized
INFO - 2017-07-04 19:18:49 --> Router Class Initialized
INFO - 2017-07-04 19:18:49 --> Output Class Initialized
INFO - 2017-07-04 19:18:49 --> Security Class Initialized
DEBUG - 2017-07-04 19:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:18:49 --> Input Class Initialized
INFO - 2017-07-04 19:18:49 --> Language Class Initialized
INFO - 2017-07-04 19:18:49 --> Loader Class Initialized
INFO - 2017-07-04 19:18:49 --> Controller Class Initialized
INFO - 2017-07-04 19:18:49 --> Database Driver Class Initialized
INFO - 2017-07-04 19:18:49 --> Model Class Initialized
INFO - 2017-07-04 19:18:49 --> Helper loaded: form_helper
INFO - 2017-07-04 19:18:49 --> Helper loaded: url_helper
INFO - 2017-07-04 19:18:49 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-04 19:18:49 --> Model Class Initialized
INFO - 2017-07-04 19:18:49 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-04 19:18:49 --> Final output sent to browser
DEBUG - 2017-07-04 19:18:49 --> Total execution time: 0.0610
ERROR - 2017-07-04 19:20:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:20:30 --> Config Class Initialized
INFO - 2017-07-04 19:20:30 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:20:30 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:20:30 --> Utf8 Class Initialized
INFO - 2017-07-04 19:20:30 --> URI Class Initialized
INFO - 2017-07-04 19:20:30 --> Router Class Initialized
INFO - 2017-07-04 19:20:30 --> Output Class Initialized
INFO - 2017-07-04 19:20:30 --> Security Class Initialized
DEBUG - 2017-07-04 19:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:20:30 --> Input Class Initialized
INFO - 2017-07-04 19:20:30 --> Language Class Initialized
INFO - 2017-07-04 19:20:30 --> Loader Class Initialized
INFO - 2017-07-04 19:20:30 --> Controller Class Initialized
INFO - 2017-07-04 19:20:30 --> Database Driver Class Initialized
INFO - 2017-07-04 19:20:30 --> Model Class Initialized
INFO - 2017-07-04 19:20:30 --> Helper loaded: form_helper
INFO - 2017-07-04 19:20:30 --> Helper loaded: url_helper
INFO - 2017-07-04 19:20:30 --> Model Class Initialized
INFO - 2017-07-04 19:20:31 --> Final output sent to browser
DEBUG - 2017-07-04 19:20:31 --> Total execution time: 0.0920
ERROR - 2017-07-04 19:20:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:20:31 --> Config Class Initialized
INFO - 2017-07-04 19:20:31 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:20:31 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:20:31 --> Utf8 Class Initialized
INFO - 2017-07-04 19:20:31 --> URI Class Initialized
INFO - 2017-07-04 19:20:31 --> Router Class Initialized
INFO - 2017-07-04 19:20:32 --> Output Class Initialized
INFO - 2017-07-04 19:20:32 --> Security Class Initialized
DEBUG - 2017-07-04 19:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:20:32 --> Input Class Initialized
INFO - 2017-07-04 19:20:32 --> Language Class Initialized
INFO - 2017-07-04 19:20:32 --> Loader Class Initialized
INFO - 2017-07-04 19:20:32 --> Controller Class Initialized
INFO - 2017-07-04 19:20:32 --> Database Driver Class Initialized
INFO - 2017-07-04 19:20:32 --> Model Class Initialized
INFO - 2017-07-04 19:20:32 --> Helper loaded: form_helper
INFO - 2017-07-04 19:20:32 --> Helper loaded: url_helper
INFO - 2017-07-04 19:20:32 --> Model Class Initialized
INFO - 2017-07-04 19:20:32 --> Final output sent to browser
DEBUG - 2017-07-04 19:20:32 --> Total execution time: 0.0460
ERROR - 2017-07-04 19:20:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:20:32 --> Config Class Initialized
INFO - 2017-07-04 19:20:32 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:20:32 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:20:32 --> Utf8 Class Initialized
INFO - 2017-07-04 19:20:32 --> URI Class Initialized
INFO - 2017-07-04 19:20:32 --> Router Class Initialized
INFO - 2017-07-04 19:20:32 --> Output Class Initialized
INFO - 2017-07-04 19:20:32 --> Security Class Initialized
DEBUG - 2017-07-04 19:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:20:32 --> Input Class Initialized
INFO - 2017-07-04 19:20:32 --> Language Class Initialized
INFO - 2017-07-04 19:20:32 --> Loader Class Initialized
INFO - 2017-07-04 19:20:32 --> Controller Class Initialized
INFO - 2017-07-04 19:20:32 --> Database Driver Class Initialized
INFO - 2017-07-04 19:20:32 --> Model Class Initialized
INFO - 2017-07-04 19:20:32 --> Helper loaded: form_helper
INFO - 2017-07-04 19:20:32 --> Helper loaded: url_helper
INFO - 2017-07-04 19:20:32 --> Model Class Initialized
INFO - 2017-07-04 19:20:32 --> Final output sent to browser
DEBUG - 2017-07-04 19:20:32 --> Total execution time: 0.0620
ERROR - 2017-07-04 19:20:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:20:47 --> Config Class Initialized
INFO - 2017-07-04 19:20:47 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:20:47 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:20:47 --> Utf8 Class Initialized
INFO - 2017-07-04 19:20:47 --> URI Class Initialized
INFO - 2017-07-04 19:20:47 --> Router Class Initialized
INFO - 2017-07-04 19:20:47 --> Output Class Initialized
INFO - 2017-07-04 19:20:47 --> Security Class Initialized
DEBUG - 2017-07-04 19:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:20:47 --> Input Class Initialized
INFO - 2017-07-04 19:20:47 --> Language Class Initialized
INFO - 2017-07-04 19:20:47 --> Loader Class Initialized
INFO - 2017-07-04 19:20:47 --> Controller Class Initialized
INFO - 2017-07-04 19:20:47 --> Database Driver Class Initialized
INFO - 2017-07-04 19:20:47 --> Model Class Initialized
INFO - 2017-07-04 19:20:47 --> Helper loaded: form_helper
INFO - 2017-07-04 19:20:47 --> Helper loaded: url_helper
INFO - 2017-07-04 19:20:47 --> Model Class Initialized
INFO - 2017-07-04 19:20:47 --> Final output sent to browser
DEBUG - 2017-07-04 19:20:47 --> Total execution time: 0.0850
ERROR - 2017-07-04 19:20:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:20:49 --> Config Class Initialized
INFO - 2017-07-04 19:20:49 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:20:49 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:20:49 --> Utf8 Class Initialized
INFO - 2017-07-04 19:20:49 --> URI Class Initialized
INFO - 2017-07-04 19:20:49 --> Router Class Initialized
INFO - 2017-07-04 19:20:49 --> Output Class Initialized
INFO - 2017-07-04 19:20:49 --> Security Class Initialized
DEBUG - 2017-07-04 19:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:20:49 --> Input Class Initialized
INFO - 2017-07-04 19:20:49 --> Language Class Initialized
INFO - 2017-07-04 19:20:49 --> Loader Class Initialized
INFO - 2017-07-04 19:20:49 --> Controller Class Initialized
INFO - 2017-07-04 19:20:49 --> Database Driver Class Initialized
INFO - 2017-07-04 19:20:49 --> Model Class Initialized
INFO - 2017-07-04 19:20:49 --> Helper loaded: form_helper
INFO - 2017-07-04 19:20:49 --> Helper loaded: url_helper
INFO - 2017-07-04 19:20:49 --> Model Class Initialized
INFO - 2017-07-04 19:20:49 --> Final output sent to browser
DEBUG - 2017-07-04 19:20:49 --> Total execution time: 0.0500
ERROR - 2017-07-04 19:20:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-04 19:20:51 --> Config Class Initialized
INFO - 2017-07-04 19:20:51 --> Hooks Class Initialized
DEBUG - 2017-07-04 19:20:51 --> UTF-8 Support Enabled
INFO - 2017-07-04 19:20:51 --> Utf8 Class Initialized
INFO - 2017-07-04 19:20:51 --> URI Class Initialized
INFO - 2017-07-04 19:20:51 --> Router Class Initialized
INFO - 2017-07-04 19:20:51 --> Output Class Initialized
INFO - 2017-07-04 19:20:51 --> Security Class Initialized
DEBUG - 2017-07-04 19:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-04 19:20:51 --> Input Class Initialized
INFO - 2017-07-04 19:20:51 --> Language Class Initialized
INFO - 2017-07-04 19:20:51 --> Loader Class Initialized
INFO - 2017-07-04 19:20:51 --> Controller Class Initialized
INFO - 2017-07-04 19:20:51 --> Database Driver Class Initialized
INFO - 2017-07-04 19:20:51 --> Model Class Initialized
INFO - 2017-07-04 19:20:51 --> Helper loaded: form_helper
INFO - 2017-07-04 19:20:51 --> Helper loaded: url_helper
INFO - 2017-07-04 19:20:51 --> Model Class Initialized
INFO - 2017-07-04 19:20:51 --> Final output sent to browser
DEBUG - 2017-07-04 19:20:51 --> Total execution time: 0.0690
