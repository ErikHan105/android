<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-28 06:18:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-28 06:18:20 --> Config Class Initialized
INFO - 2017-07-28 06:18:20 --> Hooks Class Initialized
DEBUG - 2017-07-28 06:18:20 --> UTF-8 Support Enabled
INFO - 2017-07-28 06:18:20 --> Utf8 Class Initialized
INFO - 2017-07-28 06:18:20 --> URI Class Initialized
INFO - 2017-07-28 06:18:20 --> Router Class Initialized
INFO - 2017-07-28 06:18:20 --> Output Class Initialized
INFO - 2017-07-28 06:18:20 --> Security Class Initialized
DEBUG - 2017-07-28 06:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 06:18:20 --> Input Class Initialized
INFO - 2017-07-28 06:18:20 --> Language Class Initialized
INFO - 2017-07-28 06:18:20 --> Loader Class Initialized
INFO - 2017-07-28 06:18:20 --> Controller Class Initialized
INFO - 2017-07-28 06:18:20 --> Database Driver Class Initialized
INFO - 2017-07-28 06:18:20 --> Model Class Initialized
INFO - 2017-07-28 06:18:20 --> Helper loaded: form_helper
INFO - 2017-07-28 06:18:20 --> Helper loaded: url_helper
INFO - 2017-07-28 06:18:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-28 06:18:20 --> Model Class Initialized
INFO - 2017-07-28 06:18:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-28 06:18:20 --> Final output sent to browser
DEBUG - 2017-07-28 06:18:20 --> Total execution time: 0.0410
ERROR - 2017-07-28 06:18:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-28 06:18:22 --> Config Class Initialized
INFO - 2017-07-28 06:18:22 --> Hooks Class Initialized
DEBUG - 2017-07-28 06:18:22 --> UTF-8 Support Enabled
INFO - 2017-07-28 06:18:22 --> Utf8 Class Initialized
INFO - 2017-07-28 06:18:22 --> URI Class Initialized
INFO - 2017-07-28 06:18:22 --> Router Class Initialized
INFO - 2017-07-28 06:18:22 --> Output Class Initialized
INFO - 2017-07-28 06:18:22 --> Security Class Initialized
DEBUG - 2017-07-28 06:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 06:18:22 --> Input Class Initialized
INFO - 2017-07-28 06:18:22 --> Language Class Initialized
INFO - 2017-07-28 06:18:22 --> Loader Class Initialized
INFO - 2017-07-28 06:18:22 --> Controller Class Initialized
INFO - 2017-07-28 06:18:22 --> Database Driver Class Initialized
INFO - 2017-07-28 06:18:22 --> Model Class Initialized
INFO - 2017-07-28 06:18:22 --> Helper loaded: form_helper
INFO - 2017-07-28 06:18:22 --> Helper loaded: url_helper
INFO - 2017-07-28 06:18:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-28 06:18:22 --> Model Class Initialized
INFO - 2017-07-28 06:18:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-28 06:18:22 --> Final output sent to browser
DEBUG - 2017-07-28 06:18:22 --> Total execution time: 0.0700
ERROR - 2017-07-28 12:58:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-28 12:58:04 --> Config Class Initialized
INFO - 2017-07-28 12:58:04 --> Hooks Class Initialized
DEBUG - 2017-07-28 12:58:04 --> UTF-8 Support Enabled
INFO - 2017-07-28 12:58:04 --> Utf8 Class Initialized
INFO - 2017-07-28 12:58:04 --> URI Class Initialized
DEBUG - 2017-07-28 12:58:04 --> No URI present. Default controller set.
INFO - 2017-07-28 12:58:04 --> Router Class Initialized
INFO - 2017-07-28 12:58:04 --> Output Class Initialized
INFO - 2017-07-28 12:58:04 --> Security Class Initialized
DEBUG - 2017-07-28 12:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 12:58:04 --> Input Class Initialized
INFO - 2017-07-28 12:58:04 --> Language Class Initialized
INFO - 2017-07-28 12:58:04 --> Loader Class Initialized
INFO - 2017-07-28 12:58:04 --> Controller Class Initialized
INFO - 2017-07-28 12:58:04 --> Database Driver Class Initialized
INFO - 2017-07-28 12:58:04 --> Model Class Initialized
INFO - 2017-07-28 12:58:04 --> Helper loaded: form_helper
INFO - 2017-07-28 12:58:04 --> Helper loaded: url_helper
INFO - 2017-07-28 12:58:04 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-28 12:58:04 --> Final output sent to browser
DEBUG - 2017-07-28 12:58:04 --> Total execution time: 0.0520
ERROR - 2017-07-28 12:58:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-28 12:58:07 --> Config Class Initialized
INFO - 2017-07-28 12:58:07 --> Hooks Class Initialized
DEBUG - 2017-07-28 12:58:07 --> UTF-8 Support Enabled
INFO - 2017-07-28 12:58:07 --> Utf8 Class Initialized
INFO - 2017-07-28 12:58:07 --> URI Class Initialized
INFO - 2017-07-28 12:58:07 --> Router Class Initialized
INFO - 2017-07-28 12:58:07 --> Output Class Initialized
INFO - 2017-07-28 12:58:07 --> Security Class Initialized
DEBUG - 2017-07-28 12:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 12:58:07 --> Input Class Initialized
INFO - 2017-07-28 12:58:07 --> Language Class Initialized
INFO - 2017-07-28 12:58:07 --> Loader Class Initialized
INFO - 2017-07-28 12:58:07 --> Controller Class Initialized
INFO - 2017-07-28 12:58:07 --> Database Driver Class Initialized
INFO - 2017-07-28 12:58:07 --> Model Class Initialized
INFO - 2017-07-28 12:58:07 --> Helper loaded: form_helper
INFO - 2017-07-28 12:58:07 --> Helper loaded: url_helper
INFO - 2017-07-28 12:58:07 --> Model Class Initialized
ERROR - 2017-07-28 12:58:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-28 12:58:07 --> Config Class Initialized
INFO - 2017-07-28 12:58:07 --> Hooks Class Initialized
DEBUG - 2017-07-28 12:58:07 --> UTF-8 Support Enabled
INFO - 2017-07-28 12:58:07 --> Utf8 Class Initialized
INFO - 2017-07-28 12:58:07 --> URI Class Initialized
INFO - 2017-07-28 12:58:07 --> Router Class Initialized
INFO - 2017-07-28 12:58:07 --> Output Class Initialized
INFO - 2017-07-28 12:58:07 --> Security Class Initialized
DEBUG - 2017-07-28 12:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 12:58:07 --> Input Class Initialized
INFO - 2017-07-28 12:58:07 --> Language Class Initialized
INFO - 2017-07-28 12:58:07 --> Loader Class Initialized
INFO - 2017-07-28 12:58:07 --> Controller Class Initialized
INFO - 2017-07-28 12:58:07 --> Database Driver Class Initialized
INFO - 2017-07-28 12:58:07 --> Model Class Initialized
INFO - 2017-07-28 12:58:07 --> Helper loaded: form_helper
INFO - 2017-07-28 12:58:07 --> Helper loaded: url_helper
INFO - 2017-07-28 12:58:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-28 12:58:07 --> Model Class Initialized
INFO - 2017-07-28 12:58:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-28 12:58:07 --> Final output sent to browser
DEBUG - 2017-07-28 12:58:07 --> Total execution time: 0.0660
ERROR - 2017-07-28 12:58:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-28 12:58:14 --> Config Class Initialized
INFO - 2017-07-28 12:58:14 --> Hooks Class Initialized
DEBUG - 2017-07-28 12:58:14 --> UTF-8 Support Enabled
INFO - 2017-07-28 12:58:14 --> Utf8 Class Initialized
INFO - 2017-07-28 12:58:14 --> URI Class Initialized
INFO - 2017-07-28 12:58:14 --> Router Class Initialized
INFO - 2017-07-28 12:58:14 --> Output Class Initialized
INFO - 2017-07-28 12:58:14 --> Security Class Initialized
DEBUG - 2017-07-28 12:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 12:58:14 --> Input Class Initialized
INFO - 2017-07-28 12:58:14 --> Language Class Initialized
INFO - 2017-07-28 12:58:14 --> Loader Class Initialized
INFO - 2017-07-28 12:58:14 --> Controller Class Initialized
INFO - 2017-07-28 12:58:14 --> Database Driver Class Initialized
INFO - 2017-07-28 12:58:14 --> Model Class Initialized
INFO - 2017-07-28 12:58:14 --> Helper loaded: form_helper
INFO - 2017-07-28 12:58:14 --> Helper loaded: url_helper
INFO - 2017-07-28 12:58:14 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-28 12:58:14 --> Model Class Initialized
INFO - 2017-07-28 12:58:14 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-28 12:58:14 --> Final output sent to browser
DEBUG - 2017-07-28 12:58:14 --> Total execution time: 0.0610
ERROR - 2017-07-28 12:58:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-28 12:58:18 --> Config Class Initialized
INFO - 2017-07-28 12:58:18 --> Hooks Class Initialized
DEBUG - 2017-07-28 12:58:18 --> UTF-8 Support Enabled
INFO - 2017-07-28 12:58:18 --> Utf8 Class Initialized
INFO - 2017-07-28 12:58:18 --> URI Class Initialized
INFO - 2017-07-28 12:58:18 --> Router Class Initialized
INFO - 2017-07-28 12:58:18 --> Output Class Initialized
INFO - 2017-07-28 12:58:18 --> Security Class Initialized
DEBUG - 2017-07-28 12:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 12:58:18 --> Input Class Initialized
INFO - 2017-07-28 12:58:18 --> Language Class Initialized
INFO - 2017-07-28 12:58:18 --> Loader Class Initialized
INFO - 2017-07-28 12:58:18 --> Controller Class Initialized
INFO - 2017-07-28 12:58:18 --> Database Driver Class Initialized
INFO - 2017-07-28 12:58:18 --> Model Class Initialized
INFO - 2017-07-28 12:58:18 --> Helper loaded: form_helper
INFO - 2017-07-28 12:58:18 --> Helper loaded: url_helper
INFO - 2017-07-28 12:58:18 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-28 12:58:18 --> Model Class Initialized
INFO - 2017-07-28 12:58:18 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-28 12:58:18 --> Final output sent to browser
DEBUG - 2017-07-28 12:58:18 --> Total execution time: 0.0650
ERROR - 2017-07-28 13:10:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-28 13:10:34 --> Config Class Initialized
INFO - 2017-07-28 13:10:34 --> Hooks Class Initialized
DEBUG - 2017-07-28 13:10:34 --> UTF-8 Support Enabled
INFO - 2017-07-28 13:10:34 --> Utf8 Class Initialized
INFO - 2017-07-28 13:10:34 --> URI Class Initialized
INFO - 2017-07-28 13:10:34 --> Router Class Initialized
INFO - 2017-07-28 13:10:34 --> Output Class Initialized
INFO - 2017-07-28 13:10:34 --> Security Class Initialized
DEBUG - 2017-07-28 13:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 13:10:34 --> Input Class Initialized
INFO - 2017-07-28 13:10:34 --> Language Class Initialized
INFO - 2017-07-28 13:10:34 --> Loader Class Initialized
INFO - 2017-07-28 13:10:34 --> Controller Class Initialized
INFO - 2017-07-28 13:10:34 --> Database Driver Class Initialized
INFO - 2017-07-28 13:10:34 --> Model Class Initialized
INFO - 2017-07-28 13:10:34 --> Helper loaded: form_helper
INFO - 2017-07-28 13:10:34 --> Helper loaded: url_helper
INFO - 2017-07-28 13:10:34 --> Upload Class Initialized
INFO - 2017-07-28 13:10:34 --> Final output sent to browser
DEBUG - 2017-07-28 13:10:34 --> Total execution time: 0.1500
ERROR - 2017-07-28 13:10:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-28 13:10:36 --> Config Class Initialized
INFO - 2017-07-28 13:10:36 --> Hooks Class Initialized
DEBUG - 2017-07-28 13:10:36 --> UTF-8 Support Enabled
INFO - 2017-07-28 13:10:36 --> Utf8 Class Initialized
INFO - 2017-07-28 13:10:36 --> URI Class Initialized
INFO - 2017-07-28 13:10:36 --> Router Class Initialized
INFO - 2017-07-28 13:10:36 --> Output Class Initialized
INFO - 2017-07-28 13:10:36 --> Security Class Initialized
DEBUG - 2017-07-28 13:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 13:10:36 --> Input Class Initialized
INFO - 2017-07-28 13:10:36 --> Language Class Initialized
INFO - 2017-07-28 13:10:36 --> Loader Class Initialized
INFO - 2017-07-28 13:10:36 --> Controller Class Initialized
INFO - 2017-07-28 13:10:36 --> Database Driver Class Initialized
INFO - 2017-07-28 13:10:36 --> Model Class Initialized
INFO - 2017-07-28 13:10:36 --> Helper loaded: form_helper
INFO - 2017-07-28 13:10:36 --> Helper loaded: url_helper
INFO - 2017-07-28 13:10:36 --> Model Class Initialized
INFO - 2017-07-28 13:10:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-28 13:10:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-28 13:10:36 --> Final output sent to browser
DEBUG - 2017-07-28 13:10:36 --> Total execution time: 0.3550
