<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-24 07:29:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-24 07:29:24 --> Config Class Initialized
INFO - 2017-06-24 07:29:24 --> Hooks Class Initialized
DEBUG - 2017-06-24 07:29:24 --> UTF-8 Support Enabled
INFO - 2017-06-24 07:29:24 --> Utf8 Class Initialized
INFO - 2017-06-24 07:29:24 --> URI Class Initialized
INFO - 2017-06-24 07:29:24 --> Router Class Initialized
INFO - 2017-06-24 07:29:24 --> Output Class Initialized
INFO - 2017-06-24 07:29:24 --> Security Class Initialized
DEBUG - 2017-06-24 07:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-24 07:29:24 --> Input Class Initialized
INFO - 2017-06-24 07:29:24 --> Language Class Initialized
INFO - 2017-06-24 07:29:24 --> Loader Class Initialized
INFO - 2017-06-24 07:29:24 --> Controller Class Initialized
INFO - 2017-06-24 07:29:24 --> Database Driver Class Initialized
INFO - 2017-06-24 07:29:24 --> Model Class Initialized
INFO - 2017-06-24 07:29:24 --> Helper loaded: form_helper
INFO - 2017-06-24 07:29:24 --> Helper loaded: url_helper
INFO - 2017-06-24 07:29:24 --> Final output sent to browser
DEBUG - 2017-06-24 07:29:24 --> Total execution time: 0.0550
ERROR - 2017-06-24 10:17:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-24 10:17:05 --> Config Class Initialized
INFO - 2017-06-24 10:17:05 --> Hooks Class Initialized
DEBUG - 2017-06-24 10:17:05 --> UTF-8 Support Enabled
INFO - 2017-06-24 10:17:05 --> Utf8 Class Initialized
INFO - 2017-06-24 10:17:05 --> URI Class Initialized
INFO - 2017-06-24 10:17:05 --> Router Class Initialized
INFO - 2017-06-24 10:17:05 --> Output Class Initialized
INFO - 2017-06-24 10:17:05 --> Security Class Initialized
DEBUG - 2017-06-24 10:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-24 10:17:05 --> Input Class Initialized
INFO - 2017-06-24 10:17:05 --> Language Class Initialized
INFO - 2017-06-24 10:17:05 --> Loader Class Initialized
INFO - 2017-06-24 10:17:05 --> Controller Class Initialized
INFO - 2017-06-24 10:17:05 --> Database Driver Class Initialized
INFO - 2017-06-24 10:17:05 --> Model Class Initialized
INFO - 2017-06-24 10:17:05 --> Helper loaded: form_helper
INFO - 2017-06-24 10:17:05 --> Helper loaded: url_helper
INFO - 2017-06-24 10:17:05 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-24 10:17:05 --> Model Class Initialized
INFO - 2017-06-24 10:17:05 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-24 10:17:05 --> Final output sent to browser
DEBUG - 2017-06-24 10:17:05 --> Total execution time: 0.1040
