<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-30 06:31:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-30 06:31:36 --> Config Class Initialized
INFO - 2017-07-30 06:31:36 --> Hooks Class Initialized
DEBUG - 2017-07-30 06:31:36 --> UTF-8 Support Enabled
INFO - 2017-07-30 06:31:36 --> Utf8 Class Initialized
INFO - 2017-07-30 06:31:36 --> URI Class Initialized
DEBUG - 2017-07-30 06:31:36 --> No URI present. Default controller set.
INFO - 2017-07-30 06:31:36 --> Router Class Initialized
INFO - 2017-07-30 06:31:36 --> Output Class Initialized
INFO - 2017-07-30 06:31:36 --> Security Class Initialized
DEBUG - 2017-07-30 06:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-30 06:31:36 --> Input Class Initialized
INFO - 2017-07-30 06:31:36 --> Language Class Initialized
INFO - 2017-07-30 06:31:36 --> Loader Class Initialized
INFO - 2017-07-30 06:31:36 --> Controller Class Initialized
INFO - 2017-07-30 06:31:36 --> Database Driver Class Initialized
INFO - 2017-07-30 06:31:36 --> Model Class Initialized
INFO - 2017-07-30 06:31:36 --> Helper loaded: form_helper
INFO - 2017-07-30 06:31:36 --> Helper loaded: url_helper
INFO - 2017-07-30 06:31:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-30 06:31:36 --> Final output sent to browser
DEBUG - 2017-07-30 06:31:36 --> Total execution time: 0.0930
ERROR - 2017-07-30 06:31:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-30 06:31:39 --> Config Class Initialized
INFO - 2017-07-30 06:31:39 --> Hooks Class Initialized
DEBUG - 2017-07-30 06:31:39 --> UTF-8 Support Enabled
INFO - 2017-07-30 06:31:39 --> Utf8 Class Initialized
INFO - 2017-07-30 06:31:39 --> URI Class Initialized
INFO - 2017-07-30 06:31:39 --> Router Class Initialized
INFO - 2017-07-30 06:31:39 --> Output Class Initialized
INFO - 2017-07-30 06:31:39 --> Security Class Initialized
DEBUG - 2017-07-30 06:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-30 06:31:39 --> Input Class Initialized
INFO - 2017-07-30 06:31:39 --> Language Class Initialized
INFO - 2017-07-30 06:31:39 --> Loader Class Initialized
INFO - 2017-07-30 06:31:39 --> Controller Class Initialized
INFO - 2017-07-30 06:31:39 --> Database Driver Class Initialized
INFO - 2017-07-30 06:31:39 --> Model Class Initialized
INFO - 2017-07-30 06:31:39 --> Helper loaded: form_helper
INFO - 2017-07-30 06:31:39 --> Helper loaded: url_helper
INFO - 2017-07-30 06:31:39 --> Model Class Initialized
ERROR - 2017-07-30 06:31:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-30 06:31:39 --> Config Class Initialized
INFO - 2017-07-30 06:31:39 --> Hooks Class Initialized
DEBUG - 2017-07-30 06:31:39 --> UTF-8 Support Enabled
INFO - 2017-07-30 06:31:39 --> Utf8 Class Initialized
INFO - 2017-07-30 06:31:39 --> URI Class Initialized
INFO - 2017-07-30 06:31:39 --> Router Class Initialized
INFO - 2017-07-30 06:31:39 --> Output Class Initialized
INFO - 2017-07-30 06:31:39 --> Security Class Initialized
DEBUG - 2017-07-30 06:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-30 06:31:39 --> Input Class Initialized
INFO - 2017-07-30 06:31:39 --> Language Class Initialized
INFO - 2017-07-30 06:31:39 --> Loader Class Initialized
INFO - 2017-07-30 06:31:39 --> Controller Class Initialized
INFO - 2017-07-30 06:31:39 --> Database Driver Class Initialized
INFO - 2017-07-30 06:31:39 --> Model Class Initialized
INFO - 2017-07-30 06:31:39 --> Helper loaded: form_helper
INFO - 2017-07-30 06:31:39 --> Helper loaded: url_helper
INFO - 2017-07-30 06:31:39 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-30 06:31:39 --> Model Class Initialized
INFO - 2017-07-30 06:31:39 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-30 06:31:39 --> Final output sent to browser
DEBUG - 2017-07-30 06:31:39 --> Total execution time: 0.0940
ERROR - 2017-07-30 06:31:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-30 06:31:41 --> Config Class Initialized
INFO - 2017-07-30 06:31:41 --> Hooks Class Initialized
DEBUG - 2017-07-30 06:31:41 --> UTF-8 Support Enabled
INFO - 2017-07-30 06:31:41 --> Utf8 Class Initialized
INFO - 2017-07-30 06:31:41 --> URI Class Initialized
INFO - 2017-07-30 06:31:41 --> Router Class Initialized
INFO - 2017-07-30 06:31:41 --> Output Class Initialized
INFO - 2017-07-30 06:31:41 --> Security Class Initialized
DEBUG - 2017-07-30 06:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-30 06:31:41 --> Input Class Initialized
INFO - 2017-07-30 06:31:41 --> Language Class Initialized
INFO - 2017-07-30 06:31:41 --> Loader Class Initialized
INFO - 2017-07-30 06:31:41 --> Controller Class Initialized
INFO - 2017-07-30 06:31:41 --> Database Driver Class Initialized
INFO - 2017-07-30 06:31:41 --> Model Class Initialized
INFO - 2017-07-30 06:31:41 --> Helper loaded: form_helper
INFO - 2017-07-30 06:31:41 --> Helper loaded: url_helper
INFO - 2017-07-30 06:31:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-30 06:31:41 --> Model Class Initialized
INFO - 2017-07-30 06:31:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-30 06:31:41 --> Final output sent to browser
DEBUG - 2017-07-30 06:31:41 --> Total execution time: 0.0660
ERROR - 2017-07-30 06:31:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-30 06:31:43 --> Config Class Initialized
INFO - 2017-07-30 06:31:43 --> Hooks Class Initialized
DEBUG - 2017-07-30 06:31:43 --> UTF-8 Support Enabled
INFO - 2017-07-30 06:31:43 --> Utf8 Class Initialized
INFO - 2017-07-30 06:31:43 --> URI Class Initialized
INFO - 2017-07-30 06:31:43 --> Router Class Initialized
INFO - 2017-07-30 06:31:43 --> Output Class Initialized
INFO - 2017-07-30 06:31:43 --> Security Class Initialized
DEBUG - 2017-07-30 06:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-30 06:31:43 --> Input Class Initialized
INFO - 2017-07-30 06:31:43 --> Language Class Initialized
INFO - 2017-07-30 06:31:43 --> Loader Class Initialized
INFO - 2017-07-30 06:31:43 --> Controller Class Initialized
INFO - 2017-07-30 06:31:43 --> Database Driver Class Initialized
INFO - 2017-07-30 06:31:43 --> Model Class Initialized
INFO - 2017-07-30 06:31:43 --> Helper loaded: form_helper
INFO - 2017-07-30 06:31:43 --> Helper loaded: url_helper
INFO - 2017-07-30 06:31:43 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-30 06:31:43 --> Model Class Initialized
INFO - 2017-07-30 06:31:43 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-30 06:31:43 --> Final output sent to browser
DEBUG - 2017-07-30 06:31:43 --> Total execution time: 0.0960
ERROR - 2017-07-30 16:06:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-30 16:06:26 --> Config Class Initialized
INFO - 2017-07-30 16:06:26 --> Hooks Class Initialized
DEBUG - 2017-07-30 16:06:26 --> UTF-8 Support Enabled
INFO - 2017-07-30 16:06:26 --> Utf8 Class Initialized
INFO - 2017-07-30 16:06:26 --> URI Class Initialized
DEBUG - 2017-07-30 16:06:26 --> No URI present. Default controller set.
INFO - 2017-07-30 16:06:26 --> Router Class Initialized
INFO - 2017-07-30 16:06:26 --> Output Class Initialized
INFO - 2017-07-30 16:06:26 --> Security Class Initialized
DEBUG - 2017-07-30 16:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-30 16:06:26 --> Input Class Initialized
INFO - 2017-07-30 16:06:26 --> Language Class Initialized
INFO - 2017-07-30 16:06:26 --> Loader Class Initialized
INFO - 2017-07-30 16:06:26 --> Controller Class Initialized
INFO - 2017-07-30 16:06:26 --> Database Driver Class Initialized
INFO - 2017-07-30 16:06:26 --> Model Class Initialized
INFO - 2017-07-30 16:06:26 --> Helper loaded: form_helper
INFO - 2017-07-30 16:06:26 --> Helper loaded: url_helper
INFO - 2017-07-30 16:06:26 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-30 16:06:26 --> Final output sent to browser
DEBUG - 2017-07-30 16:06:26 --> Total execution time: 0.0440
ERROR - 2017-07-30 16:06:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-30 16:06:27 --> Config Class Initialized
INFO - 2017-07-30 16:06:27 --> Hooks Class Initialized
DEBUG - 2017-07-30 16:06:27 --> UTF-8 Support Enabled
INFO - 2017-07-30 16:06:27 --> Utf8 Class Initialized
INFO - 2017-07-30 16:06:27 --> URI Class Initialized
INFO - 2017-07-30 16:06:27 --> Router Class Initialized
INFO - 2017-07-30 16:06:27 --> Output Class Initialized
INFO - 2017-07-30 16:06:27 --> Security Class Initialized
DEBUG - 2017-07-30 16:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-30 16:06:27 --> Input Class Initialized
INFO - 2017-07-30 16:06:27 --> Language Class Initialized
INFO - 2017-07-30 16:06:27 --> Loader Class Initialized
INFO - 2017-07-30 16:06:27 --> Controller Class Initialized
INFO - 2017-07-30 16:06:27 --> Database Driver Class Initialized
INFO - 2017-07-30 16:06:27 --> Model Class Initialized
INFO - 2017-07-30 16:06:27 --> Helper loaded: form_helper
INFO - 2017-07-30 16:06:27 --> Helper loaded: url_helper
INFO - 2017-07-30 16:06:27 --> Model Class Initialized
ERROR - 2017-07-30 16:06:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-30 16:06:27 --> Config Class Initialized
INFO - 2017-07-30 16:06:27 --> Hooks Class Initialized
DEBUG - 2017-07-30 16:06:27 --> UTF-8 Support Enabled
INFO - 2017-07-30 16:06:27 --> Utf8 Class Initialized
INFO - 2017-07-30 16:06:27 --> URI Class Initialized
INFO - 2017-07-30 16:06:27 --> Router Class Initialized
INFO - 2017-07-30 16:06:27 --> Output Class Initialized
INFO - 2017-07-30 16:06:27 --> Security Class Initialized
DEBUG - 2017-07-30 16:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-30 16:06:27 --> Input Class Initialized
INFO - 2017-07-30 16:06:27 --> Language Class Initialized
INFO - 2017-07-30 16:06:27 --> Loader Class Initialized
INFO - 2017-07-30 16:06:27 --> Controller Class Initialized
INFO - 2017-07-30 16:06:27 --> Database Driver Class Initialized
INFO - 2017-07-30 16:06:27 --> Model Class Initialized
INFO - 2017-07-30 16:06:27 --> Helper loaded: form_helper
INFO - 2017-07-30 16:06:27 --> Helper loaded: url_helper
INFO - 2017-07-30 16:06:27 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-30 16:06:27 --> Model Class Initialized
INFO - 2017-07-30 16:06:27 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-30 16:06:27 --> Final output sent to browser
DEBUG - 2017-07-30 16:06:27 --> Total execution time: 0.0660
ERROR - 2017-07-30 16:06:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-30 16:06:31 --> Config Class Initialized
INFO - 2017-07-30 16:06:31 --> Hooks Class Initialized
DEBUG - 2017-07-30 16:06:31 --> UTF-8 Support Enabled
INFO - 2017-07-30 16:06:31 --> Utf8 Class Initialized
INFO - 2017-07-30 16:06:31 --> URI Class Initialized
INFO - 2017-07-30 16:06:31 --> Router Class Initialized
INFO - 2017-07-30 16:06:31 --> Output Class Initialized
INFO - 2017-07-30 16:06:31 --> Security Class Initialized
DEBUG - 2017-07-30 16:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-30 16:06:31 --> Input Class Initialized
INFO - 2017-07-30 16:06:31 --> Language Class Initialized
INFO - 2017-07-30 16:06:31 --> Loader Class Initialized
INFO - 2017-07-30 16:06:31 --> Controller Class Initialized
INFO - 2017-07-30 16:06:31 --> Database Driver Class Initialized
INFO - 2017-07-30 16:06:31 --> Model Class Initialized
INFO - 2017-07-30 16:06:31 --> Helper loaded: form_helper
INFO - 2017-07-30 16:06:31 --> Helper loaded: url_helper
INFO - 2017-07-30 16:06:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-30 16:06:31 --> Model Class Initialized
INFO - 2017-07-30 16:06:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-30 16:06:31 --> Final output sent to browser
DEBUG - 2017-07-30 16:06:31 --> Total execution time: 0.0500
ERROR - 2017-07-30 16:06:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-30 16:06:34 --> Config Class Initialized
INFO - 2017-07-30 16:06:34 --> Hooks Class Initialized
DEBUG - 2017-07-30 16:06:34 --> UTF-8 Support Enabled
INFO - 2017-07-30 16:06:34 --> Utf8 Class Initialized
INFO - 2017-07-30 16:06:34 --> URI Class Initialized
INFO - 2017-07-30 16:06:34 --> Router Class Initialized
INFO - 2017-07-30 16:06:34 --> Output Class Initialized
INFO - 2017-07-30 16:06:34 --> Security Class Initialized
DEBUG - 2017-07-30 16:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-30 16:06:34 --> Input Class Initialized
INFO - 2017-07-30 16:06:34 --> Language Class Initialized
INFO - 2017-07-30 16:06:34 --> Loader Class Initialized
INFO - 2017-07-30 16:06:34 --> Controller Class Initialized
INFO - 2017-07-30 16:06:34 --> Database Driver Class Initialized
INFO - 2017-07-30 16:06:34 --> Model Class Initialized
INFO - 2017-07-30 16:06:34 --> Helper loaded: form_helper
INFO - 2017-07-30 16:06:34 --> Helper loaded: url_helper
INFO - 2017-07-30 16:06:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-30 16:06:34 --> Model Class Initialized
INFO - 2017-07-30 16:06:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-30 16:06:34 --> Final output sent to browser
DEBUG - 2017-07-30 16:06:34 --> Total execution time: 0.0840
