<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-20 04:01:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 04:01:58 --> Config Class Initialized
INFO - 2017-06-20 04:01:58 --> Hooks Class Initialized
DEBUG - 2017-06-20 04:01:58 --> UTF-8 Support Enabled
INFO - 2017-06-20 04:01:58 --> Utf8 Class Initialized
INFO - 2017-06-20 04:01:58 --> URI Class Initialized
INFO - 2017-06-20 04:01:58 --> Router Class Initialized
INFO - 2017-06-20 04:01:58 --> Output Class Initialized
INFO - 2017-06-20 04:01:58 --> Security Class Initialized
DEBUG - 2017-06-20 04:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 04:01:58 --> Input Class Initialized
INFO - 2017-06-20 04:01:58 --> Language Class Initialized
INFO - 2017-06-20 04:01:58 --> Loader Class Initialized
INFO - 2017-06-20 04:01:58 --> Controller Class Initialized
INFO - 2017-06-20 04:01:58 --> Database Driver Class Initialized
INFO - 2017-06-20 04:01:58 --> Model Class Initialized
INFO - 2017-06-20 04:01:59 --> Helper loaded: form_helper
INFO - 2017-06-20 04:01:59 --> Helper loaded: url_helper
INFO - 2017-06-20 04:01:59 --> Model Class Initialized
ERROR - 2017-06-20 04:01:59 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\mystage\application\controllers\Mobile.php 23
ERROR - 2017-06-20 04:01:59 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\mystage\application\controllers\Mobile.php 23
ERROR - 2017-06-20 04:01:59 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `tbl_user` (`name`, `email`, `password`, `status`, `created`) VALUES ('test@email=test@password=test', NULL, NULL, 'active', 1497924119)
INFO - 2017-06-20 04:01:59 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-06-20 04:02:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 04:02:09 --> Config Class Initialized
INFO - 2017-06-20 04:02:09 --> Hooks Class Initialized
DEBUG - 2017-06-20 04:02:09 --> UTF-8 Support Enabled
INFO - 2017-06-20 04:02:09 --> Utf8 Class Initialized
INFO - 2017-06-20 04:02:09 --> URI Class Initialized
INFO - 2017-06-20 04:02:09 --> Router Class Initialized
INFO - 2017-06-20 04:02:09 --> Output Class Initialized
INFO - 2017-06-20 04:02:09 --> Security Class Initialized
DEBUG - 2017-06-20 04:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 04:02:09 --> Input Class Initialized
INFO - 2017-06-20 04:02:09 --> Language Class Initialized
INFO - 2017-06-20 04:02:09 --> Loader Class Initialized
INFO - 2017-06-20 04:02:09 --> Controller Class Initialized
INFO - 2017-06-20 04:02:09 --> Database Driver Class Initialized
INFO - 2017-06-20 04:02:09 --> Model Class Initialized
INFO - 2017-06-20 04:02:09 --> Helper loaded: form_helper
INFO - 2017-06-20 04:02:09 --> Helper loaded: url_helper
INFO - 2017-06-20 04:02:09 --> Model Class Initialized
ERROR - 2017-06-20 04:02:09 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `tbl_user` (`name`, `email`, `password`, `status`, `created`) VALUES ('test', 'test', 'test', 'active', 1497924129)
INFO - 2017-06-20 04:02:09 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-06-20 04:04:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 04:04:16 --> Config Class Initialized
INFO - 2017-06-20 04:04:16 --> Hooks Class Initialized
DEBUG - 2017-06-20 04:04:16 --> UTF-8 Support Enabled
INFO - 2017-06-20 04:04:16 --> Utf8 Class Initialized
INFO - 2017-06-20 04:04:16 --> URI Class Initialized
INFO - 2017-06-20 04:04:16 --> Router Class Initialized
INFO - 2017-06-20 04:04:16 --> Output Class Initialized
INFO - 2017-06-20 04:04:16 --> Security Class Initialized
DEBUG - 2017-06-20 04:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 04:04:16 --> Input Class Initialized
INFO - 2017-06-20 04:04:16 --> Language Class Initialized
INFO - 2017-06-20 04:04:16 --> Loader Class Initialized
INFO - 2017-06-20 04:04:16 --> Controller Class Initialized
INFO - 2017-06-20 04:04:16 --> Database Driver Class Initialized
INFO - 2017-06-20 04:04:16 --> Model Class Initialized
INFO - 2017-06-20 04:04:16 --> Helper loaded: form_helper
INFO - 2017-06-20 04:04:16 --> Helper loaded: url_helper
INFO - 2017-06-20 04:04:16 --> Model Class Initialized
ERROR - 2017-06-20 04:04:16 --> Severity: Notice --> Undefined index: username C:\xampp\htdocs\mystage\application\controllers\Mobile.php 23
ERROR - 2017-06-20 04:04:16 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `tbl_user` (`username`, `email`, `password`, `status`, `created`) VALUES (NULL, 'test', 'test', 'active', 1497924256)
INFO - 2017-06-20 04:04:16 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-06-20 04:04:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 04:04:24 --> Config Class Initialized
INFO - 2017-06-20 04:04:24 --> Hooks Class Initialized
DEBUG - 2017-06-20 04:04:24 --> UTF-8 Support Enabled
INFO - 2017-06-20 04:04:24 --> Utf8 Class Initialized
INFO - 2017-06-20 04:04:24 --> URI Class Initialized
INFO - 2017-06-20 04:04:24 --> Router Class Initialized
INFO - 2017-06-20 04:04:24 --> Output Class Initialized
INFO - 2017-06-20 04:04:24 --> Security Class Initialized
DEBUG - 2017-06-20 04:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 04:04:24 --> Input Class Initialized
INFO - 2017-06-20 04:04:24 --> Language Class Initialized
INFO - 2017-06-20 04:04:24 --> Loader Class Initialized
INFO - 2017-06-20 04:04:24 --> Controller Class Initialized
INFO - 2017-06-20 04:04:24 --> Database Driver Class Initialized
INFO - 2017-06-20 04:04:24 --> Model Class Initialized
INFO - 2017-06-20 04:04:24 --> Helper loaded: form_helper
INFO - 2017-06-20 04:04:24 --> Helper loaded: url_helper
INFO - 2017-06-20 04:04:24 --> Model Class Initialized
INFO - 2017-06-20 04:04:24 --> Final output sent to browser
DEBUG - 2017-06-20 04:04:24 --> Total execution time: 0.0710
ERROR - 2017-06-20 04:05:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 04:05:09 --> Config Class Initialized
INFO - 2017-06-20 04:05:09 --> Hooks Class Initialized
DEBUG - 2017-06-20 04:05:09 --> UTF-8 Support Enabled
INFO - 2017-06-20 04:05:09 --> Utf8 Class Initialized
INFO - 2017-06-20 04:05:09 --> URI Class Initialized
INFO - 2017-06-20 04:05:09 --> Router Class Initialized
INFO - 2017-06-20 04:05:09 --> Output Class Initialized
INFO - 2017-06-20 04:05:09 --> Security Class Initialized
DEBUG - 2017-06-20 04:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 04:05:09 --> Input Class Initialized
INFO - 2017-06-20 04:05:09 --> Language Class Initialized
INFO - 2017-06-20 04:05:09 --> Loader Class Initialized
INFO - 2017-06-20 04:05:09 --> Controller Class Initialized
INFO - 2017-06-20 04:05:09 --> Database Driver Class Initialized
INFO - 2017-06-20 04:05:09 --> Model Class Initialized
INFO - 2017-06-20 04:05:09 --> Helper loaded: form_helper
INFO - 2017-06-20 04:05:09 --> Helper loaded: url_helper
INFO - 2017-06-20 04:05:09 --> Model Class Initialized
INFO - 2017-06-20 04:05:09 --> Final output sent to browser
DEBUG - 2017-06-20 04:05:09 --> Total execution time: 0.0390
ERROR - 2017-06-20 04:05:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 04:05:12 --> Config Class Initialized
INFO - 2017-06-20 04:05:12 --> Hooks Class Initialized
DEBUG - 2017-06-20 04:05:12 --> UTF-8 Support Enabled
INFO - 2017-06-20 04:05:12 --> Utf8 Class Initialized
INFO - 2017-06-20 04:05:12 --> URI Class Initialized
INFO - 2017-06-20 04:05:12 --> Router Class Initialized
INFO - 2017-06-20 04:05:12 --> Output Class Initialized
INFO - 2017-06-20 04:05:12 --> Security Class Initialized
DEBUG - 2017-06-20 04:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 04:05:12 --> Input Class Initialized
INFO - 2017-06-20 04:05:12 --> Language Class Initialized
INFO - 2017-06-20 04:05:12 --> Loader Class Initialized
INFO - 2017-06-20 04:05:12 --> Controller Class Initialized
INFO - 2017-06-20 04:05:12 --> Database Driver Class Initialized
INFO - 2017-06-20 04:05:12 --> Model Class Initialized
INFO - 2017-06-20 04:05:12 --> Helper loaded: form_helper
INFO - 2017-06-20 04:05:12 --> Helper loaded: url_helper
INFO - 2017-06-20 04:05:12 --> Model Class Initialized
INFO - 2017-06-20 04:05:12 --> Final output sent to browser
DEBUG - 2017-06-20 04:05:12 --> Total execution time: 0.0500
ERROR - 2017-06-20 04:06:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 04:06:07 --> Config Class Initialized
INFO - 2017-06-20 04:06:07 --> Hooks Class Initialized
DEBUG - 2017-06-20 04:06:07 --> UTF-8 Support Enabled
INFO - 2017-06-20 04:06:07 --> Utf8 Class Initialized
INFO - 2017-06-20 04:06:07 --> URI Class Initialized
INFO - 2017-06-20 04:06:07 --> Router Class Initialized
INFO - 2017-06-20 04:06:07 --> Output Class Initialized
INFO - 2017-06-20 04:06:07 --> Security Class Initialized
DEBUG - 2017-06-20 04:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 04:06:07 --> Input Class Initialized
INFO - 2017-06-20 04:06:07 --> Language Class Initialized
INFO - 2017-06-20 04:06:07 --> Loader Class Initialized
INFO - 2017-06-20 04:06:07 --> Controller Class Initialized
INFO - 2017-06-20 04:06:07 --> Database Driver Class Initialized
INFO - 2017-06-20 04:06:07 --> Model Class Initialized
INFO - 2017-06-20 04:06:07 --> Helper loaded: form_helper
INFO - 2017-06-20 04:06:07 --> Helper loaded: url_helper
INFO - 2017-06-20 04:06:07 --> Model Class Initialized
ERROR - 2017-06-20 04:06:07 --> Severity: Warning --> Missing argument 6 for Mobile_model::signup(), called in C:\xampp\htdocs\mystage\application\controllers\Mobile.php on line 23 and defined C:\xampp\htdocs\mystage\application\models\Mobile_model.php 9
INFO - 2017-06-20 04:06:07 --> Final output sent to browser
DEBUG - 2017-06-20 04:06:07 --> Total execution time: 0.0500
ERROR - 2017-06-20 04:06:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 04:06:58 --> Config Class Initialized
INFO - 2017-06-20 04:06:58 --> Hooks Class Initialized
DEBUG - 2017-06-20 04:06:58 --> UTF-8 Support Enabled
INFO - 2017-06-20 04:06:58 --> Utf8 Class Initialized
INFO - 2017-06-20 04:06:58 --> URI Class Initialized
INFO - 2017-06-20 04:06:58 --> Router Class Initialized
INFO - 2017-06-20 04:06:58 --> Output Class Initialized
INFO - 2017-06-20 04:06:58 --> Security Class Initialized
DEBUG - 2017-06-20 04:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 04:06:58 --> Input Class Initialized
INFO - 2017-06-20 04:06:58 --> Language Class Initialized
INFO - 2017-06-20 04:06:58 --> Loader Class Initialized
INFO - 2017-06-20 04:06:58 --> Controller Class Initialized
INFO - 2017-06-20 04:06:58 --> Database Driver Class Initialized
INFO - 2017-06-20 04:06:58 --> Model Class Initialized
INFO - 2017-06-20 04:06:58 --> Helper loaded: form_helper
INFO - 2017-06-20 04:06:58 --> Helper loaded: url_helper
INFO - 2017-06-20 04:06:58 --> Model Class Initialized
INFO - 2017-06-20 04:06:58 --> Final output sent to browser
DEBUG - 2017-06-20 04:06:58 --> Total execution time: 0.0470
ERROR - 2017-06-20 04:07:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 04:07:07 --> Config Class Initialized
INFO - 2017-06-20 04:07:07 --> Hooks Class Initialized
DEBUG - 2017-06-20 04:07:07 --> UTF-8 Support Enabled
INFO - 2017-06-20 04:07:07 --> Utf8 Class Initialized
INFO - 2017-06-20 04:07:07 --> URI Class Initialized
INFO - 2017-06-20 04:07:07 --> Router Class Initialized
INFO - 2017-06-20 04:07:07 --> Output Class Initialized
INFO - 2017-06-20 04:07:07 --> Security Class Initialized
DEBUG - 2017-06-20 04:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 04:07:07 --> Input Class Initialized
INFO - 2017-06-20 04:07:07 --> Language Class Initialized
INFO - 2017-06-20 04:07:07 --> Loader Class Initialized
INFO - 2017-06-20 04:07:07 --> Controller Class Initialized
INFO - 2017-06-20 04:07:07 --> Database Driver Class Initialized
INFO - 2017-06-20 04:07:07 --> Model Class Initialized
INFO - 2017-06-20 04:07:07 --> Helper loaded: form_helper
INFO - 2017-06-20 04:07:07 --> Helper loaded: url_helper
INFO - 2017-06-20 04:07:07 --> Model Class Initialized
INFO - 2017-06-20 04:07:07 --> Final output sent to browser
DEBUG - 2017-06-20 04:07:07 --> Total execution time: 0.2260
ERROR - 2017-06-20 04:15:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 04:15:23 --> Config Class Initialized
INFO - 2017-06-20 04:15:23 --> Hooks Class Initialized
DEBUG - 2017-06-20 04:15:23 --> UTF-8 Support Enabled
INFO - 2017-06-20 04:15:23 --> Utf8 Class Initialized
INFO - 2017-06-20 04:15:23 --> URI Class Initialized
INFO - 2017-06-20 04:15:23 --> Router Class Initialized
INFO - 2017-06-20 04:15:23 --> Output Class Initialized
INFO - 2017-06-20 04:15:23 --> Security Class Initialized
DEBUG - 2017-06-20 04:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 04:15:23 --> Input Class Initialized
INFO - 2017-06-20 04:15:23 --> Language Class Initialized
INFO - 2017-06-20 04:15:23 --> Loader Class Initialized
INFO - 2017-06-20 04:15:23 --> Controller Class Initialized
INFO - 2017-06-20 04:15:23 --> Database Driver Class Initialized
INFO - 2017-06-20 04:15:23 --> Model Class Initialized
INFO - 2017-06-20 04:15:23 --> Helper loaded: form_helper
INFO - 2017-06-20 04:15:23 --> Helper loaded: url_helper
INFO - 2017-06-20 04:15:23 --> Model Class Initialized
INFO - 2017-06-20 04:15:23 --> Final output sent to browser
DEBUG - 2017-06-20 04:15:23 --> Total execution time: 0.0770
ERROR - 2017-06-20 04:16:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 04:16:23 --> Config Class Initialized
INFO - 2017-06-20 04:16:23 --> Hooks Class Initialized
DEBUG - 2017-06-20 04:16:23 --> UTF-8 Support Enabled
INFO - 2017-06-20 04:16:23 --> Utf8 Class Initialized
INFO - 2017-06-20 04:16:23 --> URI Class Initialized
INFO - 2017-06-20 04:16:23 --> Router Class Initialized
INFO - 2017-06-20 04:16:23 --> Output Class Initialized
INFO - 2017-06-20 04:16:23 --> Security Class Initialized
DEBUG - 2017-06-20 04:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 04:16:23 --> Input Class Initialized
INFO - 2017-06-20 04:16:23 --> Language Class Initialized
INFO - 2017-06-20 04:16:23 --> Loader Class Initialized
INFO - 2017-06-20 04:16:23 --> Controller Class Initialized
INFO - 2017-06-20 04:16:23 --> Database Driver Class Initialized
INFO - 2017-06-20 04:16:23 --> Model Class Initialized
INFO - 2017-06-20 04:16:23 --> Helper loaded: form_helper
INFO - 2017-06-20 04:16:23 --> Helper loaded: url_helper
INFO - 2017-06-20 04:16:23 --> Model Class Initialized
INFO - 2017-06-20 04:16:23 --> Final output sent to browser
DEBUG - 2017-06-20 04:16:23 --> Total execution time: 0.0450
ERROR - 2017-06-20 04:16:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 04:16:45 --> Config Class Initialized
INFO - 2017-06-20 04:16:45 --> Hooks Class Initialized
DEBUG - 2017-06-20 04:16:45 --> UTF-8 Support Enabled
INFO - 2017-06-20 04:16:45 --> Utf8 Class Initialized
INFO - 2017-06-20 04:16:45 --> URI Class Initialized
INFO - 2017-06-20 04:16:45 --> Router Class Initialized
INFO - 2017-06-20 04:16:45 --> Output Class Initialized
INFO - 2017-06-20 04:16:45 --> Security Class Initialized
DEBUG - 2017-06-20 04:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 04:16:45 --> Input Class Initialized
INFO - 2017-06-20 04:16:45 --> Language Class Initialized
INFO - 2017-06-20 04:16:45 --> Loader Class Initialized
INFO - 2017-06-20 04:16:45 --> Controller Class Initialized
INFO - 2017-06-20 04:16:45 --> Database Driver Class Initialized
INFO - 2017-06-20 04:16:45 --> Model Class Initialized
INFO - 2017-06-20 04:16:45 --> Helper loaded: form_helper
INFO - 2017-06-20 04:16:45 --> Helper loaded: url_helper
INFO - 2017-06-20 04:16:45 --> Model Class Initialized
INFO - 2017-06-20 04:16:46 --> Final output sent to browser
DEBUG - 2017-06-20 04:16:46 --> Total execution time: 0.3970
ERROR - 2017-06-20 04:20:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 04:20:35 --> Config Class Initialized
INFO - 2017-06-20 04:20:35 --> Hooks Class Initialized
DEBUG - 2017-06-20 04:20:35 --> UTF-8 Support Enabled
INFO - 2017-06-20 04:20:35 --> Utf8 Class Initialized
INFO - 2017-06-20 04:20:35 --> URI Class Initialized
INFO - 2017-06-20 04:20:35 --> Router Class Initialized
INFO - 2017-06-20 04:20:35 --> Output Class Initialized
INFO - 2017-06-20 04:20:35 --> Security Class Initialized
DEBUG - 2017-06-20 04:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 04:20:35 --> Input Class Initialized
INFO - 2017-06-20 04:20:35 --> Language Class Initialized
INFO - 2017-06-20 04:20:35 --> Loader Class Initialized
INFO - 2017-06-20 04:20:35 --> Controller Class Initialized
INFO - 2017-06-20 04:20:35 --> Database Driver Class Initialized
INFO - 2017-06-20 04:20:35 --> Model Class Initialized
INFO - 2017-06-20 04:20:35 --> Helper loaded: form_helper
INFO - 2017-06-20 04:20:35 --> Helper loaded: url_helper
INFO - 2017-06-20 04:20:35 --> Model Class Initialized
INFO - 2017-06-20 04:20:35 --> Final output sent to browser
DEBUG - 2017-06-20 04:20:35 --> Total execution time: 0.1250
ERROR - 2017-06-20 07:45:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 07:45:36 --> Config Class Initialized
INFO - 2017-06-20 07:45:36 --> Hooks Class Initialized
DEBUG - 2017-06-20 07:45:36 --> UTF-8 Support Enabled
INFO - 2017-06-20 07:45:36 --> Utf8 Class Initialized
INFO - 2017-06-20 07:45:36 --> URI Class Initialized
INFO - 2017-06-20 07:45:36 --> Router Class Initialized
INFO - 2017-06-20 07:45:36 --> Output Class Initialized
INFO - 2017-06-20 07:45:36 --> Security Class Initialized
DEBUG - 2017-06-20 07:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 07:45:36 --> Input Class Initialized
INFO - 2017-06-20 07:45:36 --> Language Class Initialized
INFO - 2017-06-20 07:45:36 --> Loader Class Initialized
INFO - 2017-06-20 07:45:36 --> Controller Class Initialized
INFO - 2017-06-20 07:45:36 --> Database Driver Class Initialized
INFO - 2017-06-20 07:45:36 --> Model Class Initialized
INFO - 2017-06-20 07:45:36 --> Helper loaded: form_helper
INFO - 2017-06-20 07:45:36 --> Helper loaded: url_helper
INFO - 2017-06-20 07:45:36 --> Model Class Initialized
INFO - 2017-06-20 07:45:36 --> Final output sent to browser
DEBUG - 2017-06-20 07:45:36 --> Total execution time: 0.0750
ERROR - 2017-06-20 07:45:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 07:45:40 --> Config Class Initialized
INFO - 2017-06-20 07:45:40 --> Hooks Class Initialized
DEBUG - 2017-06-20 07:45:40 --> UTF-8 Support Enabled
INFO - 2017-06-20 07:45:40 --> Utf8 Class Initialized
INFO - 2017-06-20 07:45:40 --> URI Class Initialized
INFO - 2017-06-20 07:45:40 --> Router Class Initialized
INFO - 2017-06-20 07:45:40 --> Output Class Initialized
INFO - 2017-06-20 07:45:40 --> Security Class Initialized
DEBUG - 2017-06-20 07:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 07:45:40 --> Input Class Initialized
INFO - 2017-06-20 07:45:40 --> Language Class Initialized
INFO - 2017-06-20 07:45:40 --> Loader Class Initialized
INFO - 2017-06-20 07:45:40 --> Controller Class Initialized
INFO - 2017-06-20 07:45:40 --> Database Driver Class Initialized
INFO - 2017-06-20 07:45:40 --> Model Class Initialized
INFO - 2017-06-20 07:45:40 --> Helper loaded: form_helper
INFO - 2017-06-20 07:45:40 --> Helper loaded: url_helper
INFO - 2017-06-20 07:45:40 --> Model Class Initialized
INFO - 2017-06-20 07:45:40 --> Final output sent to browser
DEBUG - 2017-06-20 07:45:40 --> Total execution time: 0.0400
ERROR - 2017-06-20 08:12:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 08:12:51 --> Config Class Initialized
INFO - 2017-06-20 08:12:51 --> Hooks Class Initialized
DEBUG - 2017-06-20 08:12:51 --> UTF-8 Support Enabled
INFO - 2017-06-20 08:12:51 --> Utf8 Class Initialized
INFO - 2017-06-20 08:12:51 --> URI Class Initialized
INFO - 2017-06-20 08:12:51 --> Router Class Initialized
INFO - 2017-06-20 08:12:51 --> Output Class Initialized
INFO - 2017-06-20 08:12:51 --> Security Class Initialized
DEBUG - 2017-06-20 08:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 08:12:51 --> Input Class Initialized
INFO - 2017-06-20 08:12:51 --> Language Class Initialized
INFO - 2017-06-20 08:12:51 --> Loader Class Initialized
INFO - 2017-06-20 08:12:51 --> Controller Class Initialized
INFO - 2017-06-20 08:12:51 --> Database Driver Class Initialized
INFO - 2017-06-20 08:12:51 --> Model Class Initialized
INFO - 2017-06-20 08:12:51 --> Helper loaded: form_helper
INFO - 2017-06-20 08:12:51 --> Helper loaded: url_helper
INFO - 2017-06-20 08:12:51 --> Model Class Initialized
INFO - 2017-06-20 08:12:51 --> Final output sent to browser
DEBUG - 2017-06-20 08:12:51 --> Total execution time: 0.0500
ERROR - 2017-06-20 08:13:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 08:13:00 --> Config Class Initialized
INFO - 2017-06-20 08:13:00 --> Hooks Class Initialized
DEBUG - 2017-06-20 08:13:00 --> UTF-8 Support Enabled
INFO - 2017-06-20 08:13:00 --> Utf8 Class Initialized
INFO - 2017-06-20 08:13:00 --> URI Class Initialized
INFO - 2017-06-20 08:13:00 --> Router Class Initialized
INFO - 2017-06-20 08:13:00 --> Output Class Initialized
INFO - 2017-06-20 08:13:00 --> Security Class Initialized
DEBUG - 2017-06-20 08:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 08:13:00 --> Input Class Initialized
INFO - 2017-06-20 08:13:00 --> Language Class Initialized
INFO - 2017-06-20 08:13:00 --> Loader Class Initialized
INFO - 2017-06-20 08:13:00 --> Controller Class Initialized
INFO - 2017-06-20 08:13:00 --> Database Driver Class Initialized
INFO - 2017-06-20 08:13:00 --> Model Class Initialized
INFO - 2017-06-20 08:13:00 --> Helper loaded: form_helper
INFO - 2017-06-20 08:13:00 --> Helper loaded: url_helper
INFO - 2017-06-20 08:13:00 --> Model Class Initialized
INFO - 2017-06-20 08:13:00 --> Final output sent to browser
DEBUG - 2017-06-20 08:13:00 --> Total execution time: 0.0440
ERROR - 2017-06-20 08:13:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 08:13:09 --> Config Class Initialized
INFO - 2017-06-20 08:13:09 --> Hooks Class Initialized
DEBUG - 2017-06-20 08:13:09 --> UTF-8 Support Enabled
INFO - 2017-06-20 08:13:09 --> Utf8 Class Initialized
INFO - 2017-06-20 08:13:09 --> URI Class Initialized
INFO - 2017-06-20 08:13:09 --> Router Class Initialized
INFO - 2017-06-20 08:13:09 --> Output Class Initialized
INFO - 2017-06-20 08:13:09 --> Security Class Initialized
DEBUG - 2017-06-20 08:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 08:13:09 --> Input Class Initialized
INFO - 2017-06-20 08:13:09 --> Language Class Initialized
INFO - 2017-06-20 08:13:09 --> Loader Class Initialized
INFO - 2017-06-20 08:13:09 --> Controller Class Initialized
INFO - 2017-06-20 08:13:09 --> Database Driver Class Initialized
INFO - 2017-06-20 08:13:09 --> Model Class Initialized
INFO - 2017-06-20 08:13:09 --> Helper loaded: form_helper
INFO - 2017-06-20 08:13:09 --> Helper loaded: url_helper
INFO - 2017-06-20 08:13:09 --> Model Class Initialized
INFO - 2017-06-20 08:13:09 --> Final output sent to browser
DEBUG - 2017-06-20 08:13:09 --> Total execution time: 0.0460
ERROR - 2017-06-20 10:38:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 10:38:24 --> Config Class Initialized
INFO - 2017-06-20 10:38:24 --> Hooks Class Initialized
DEBUG - 2017-06-20 10:38:24 --> UTF-8 Support Enabled
INFO - 2017-06-20 10:38:24 --> Utf8 Class Initialized
INFO - 2017-06-20 10:38:24 --> URI Class Initialized
INFO - 2017-06-20 10:38:24 --> Router Class Initialized
INFO - 2017-06-20 10:38:24 --> Output Class Initialized
INFO - 2017-06-20 10:38:24 --> Security Class Initialized
DEBUG - 2017-06-20 10:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 10:38:24 --> Input Class Initialized
INFO - 2017-06-20 10:38:24 --> Language Class Initialized
INFO - 2017-06-20 10:38:24 --> Loader Class Initialized
INFO - 2017-06-20 10:38:24 --> Controller Class Initialized
INFO - 2017-06-20 10:38:24 --> Database Driver Class Initialized
INFO - 2017-06-20 10:38:24 --> Model Class Initialized
INFO - 2017-06-20 10:38:24 --> Helper loaded: form_helper
INFO - 2017-06-20 10:38:24 --> Helper loaded: url_helper
INFO - 2017-06-20 10:38:24 --> Model Class Initialized
ERROR - 2017-06-20 10:38:24 --> Severity: Notice --> Undefined index: user_id C:\xampp\htdocs\mystage\application\controllers\Mobile.php 31
ERROR - 2017-06-20 10:38:24 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\mystage\application\models\Mobile_model.php 73
INFO - 2017-06-20 10:38:24 --> Final output sent to browser
DEBUG - 2017-06-20 10:38:24 --> Total execution time: 0.0860
ERROR - 2017-06-20 10:38:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 10:38:43 --> Config Class Initialized
INFO - 2017-06-20 10:38:43 --> Hooks Class Initialized
DEBUG - 2017-06-20 10:38:43 --> UTF-8 Support Enabled
INFO - 2017-06-20 10:38:43 --> Utf8 Class Initialized
INFO - 2017-06-20 10:38:43 --> URI Class Initialized
INFO - 2017-06-20 10:38:43 --> Router Class Initialized
INFO - 2017-06-20 10:38:43 --> Output Class Initialized
INFO - 2017-06-20 10:38:43 --> Security Class Initialized
DEBUG - 2017-06-20 10:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 10:38:43 --> Input Class Initialized
INFO - 2017-06-20 10:38:43 --> Language Class Initialized
INFO - 2017-06-20 10:38:43 --> Loader Class Initialized
INFO - 2017-06-20 10:38:43 --> Controller Class Initialized
INFO - 2017-06-20 10:38:43 --> Database Driver Class Initialized
INFO - 2017-06-20 10:38:43 --> Model Class Initialized
INFO - 2017-06-20 10:38:43 --> Helper loaded: form_helper
INFO - 2017-06-20 10:38:43 --> Helper loaded: url_helper
INFO - 2017-06-20 10:38:43 --> Model Class Initialized
ERROR - 2017-06-20 10:38:43 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\mystage\application\models\Mobile_model.php 73
INFO - 2017-06-20 10:38:43 --> Final output sent to browser
DEBUG - 2017-06-20 10:38:43 --> Total execution time: 0.1280
ERROR - 2017-06-20 10:39:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 10:39:02 --> Config Class Initialized
INFO - 2017-06-20 10:39:02 --> Hooks Class Initialized
DEBUG - 2017-06-20 10:39:02 --> UTF-8 Support Enabled
INFO - 2017-06-20 10:39:02 --> Utf8 Class Initialized
INFO - 2017-06-20 10:39:02 --> URI Class Initialized
INFO - 2017-06-20 10:39:02 --> Router Class Initialized
INFO - 2017-06-20 10:39:02 --> Output Class Initialized
INFO - 2017-06-20 10:39:02 --> Security Class Initialized
DEBUG - 2017-06-20 10:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 10:39:02 --> Input Class Initialized
INFO - 2017-06-20 10:39:02 --> Language Class Initialized
INFO - 2017-06-20 10:39:02 --> Loader Class Initialized
INFO - 2017-06-20 10:39:02 --> Controller Class Initialized
INFO - 2017-06-20 10:39:02 --> Database Driver Class Initialized
INFO - 2017-06-20 10:39:02 --> Model Class Initialized
INFO - 2017-06-20 10:39:02 --> Helper loaded: form_helper
INFO - 2017-06-20 10:39:02 --> Helper loaded: url_helper
INFO - 2017-06-20 10:39:02 --> Model Class Initialized
INFO - 2017-06-20 10:39:02 --> Final output sent to browser
DEBUG - 2017-06-20 10:39:02 --> Total execution time: 0.0520
ERROR - 2017-06-20 10:45:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 10:45:56 --> Config Class Initialized
INFO - 2017-06-20 10:45:56 --> Hooks Class Initialized
DEBUG - 2017-06-20 10:45:56 --> UTF-8 Support Enabled
INFO - 2017-06-20 10:45:56 --> Utf8 Class Initialized
INFO - 2017-06-20 10:45:56 --> URI Class Initialized
INFO - 2017-06-20 10:45:56 --> Router Class Initialized
INFO - 2017-06-20 10:45:56 --> Output Class Initialized
INFO - 2017-06-20 10:45:56 --> Security Class Initialized
DEBUG - 2017-06-20 10:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 10:45:56 --> Input Class Initialized
INFO - 2017-06-20 10:45:56 --> Language Class Initialized
INFO - 2017-06-20 10:45:56 --> Loader Class Initialized
INFO - 2017-06-20 10:45:56 --> Controller Class Initialized
INFO - 2017-06-20 10:45:56 --> Database Driver Class Initialized
INFO - 2017-06-20 10:45:56 --> Model Class Initialized
INFO - 2017-06-20 10:45:56 --> Helper loaded: form_helper
INFO - 2017-06-20 10:45:56 --> Helper loaded: url_helper
INFO - 2017-06-20 10:45:56 --> Model Class Initialized
INFO - 2017-06-20 10:45:56 --> Final output sent to browser
DEBUG - 2017-06-20 10:45:56 --> Total execution time: 0.0480
ERROR - 2017-06-20 10:45:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 10:45:56 --> Config Class Initialized
INFO - 2017-06-20 10:45:56 --> Hooks Class Initialized
DEBUG - 2017-06-20 10:45:56 --> UTF-8 Support Enabled
INFO - 2017-06-20 10:45:56 --> Utf8 Class Initialized
INFO - 2017-06-20 10:45:56 --> URI Class Initialized
INFO - 2017-06-20 10:45:56 --> Router Class Initialized
INFO - 2017-06-20 10:45:56 --> Output Class Initialized
INFO - 2017-06-20 10:45:56 --> Security Class Initialized
DEBUG - 2017-06-20 10:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 10:45:56 --> Input Class Initialized
INFO - 2017-06-20 10:45:56 --> Language Class Initialized
INFO - 2017-06-20 10:45:56 --> Loader Class Initialized
INFO - 2017-06-20 10:45:56 --> Controller Class Initialized
INFO - 2017-06-20 10:45:56 --> Database Driver Class Initialized
INFO - 2017-06-20 10:45:56 --> Model Class Initialized
INFO - 2017-06-20 10:45:56 --> Helper loaded: form_helper
INFO - 2017-06-20 10:45:56 --> Helper loaded: url_helper
INFO - 2017-06-20 10:45:56 --> Model Class Initialized
ERROR - 2017-06-20 10:45:56 --> Severity: Notice --> Undefined index: user_id C:\xampp\htdocs\mystage\application\controllers\Mobile.php 31
INFO - 2017-06-20 10:45:56 --> Final output sent to browser
DEBUG - 2017-06-20 10:45:56 --> Total execution time: 0.0600
ERROR - 2017-06-20 10:48:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 10:48:44 --> Config Class Initialized
INFO - 2017-06-20 10:48:44 --> Hooks Class Initialized
DEBUG - 2017-06-20 10:48:44 --> UTF-8 Support Enabled
INFO - 2017-06-20 10:48:44 --> Utf8 Class Initialized
INFO - 2017-06-20 10:48:44 --> URI Class Initialized
INFO - 2017-06-20 10:48:44 --> Router Class Initialized
INFO - 2017-06-20 10:48:44 --> Output Class Initialized
INFO - 2017-06-20 10:48:44 --> Security Class Initialized
DEBUG - 2017-06-20 10:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 10:48:44 --> Input Class Initialized
INFO - 2017-06-20 10:48:44 --> Language Class Initialized
INFO - 2017-06-20 10:48:44 --> Loader Class Initialized
INFO - 2017-06-20 10:48:44 --> Controller Class Initialized
INFO - 2017-06-20 10:48:44 --> Database Driver Class Initialized
INFO - 2017-06-20 10:48:44 --> Model Class Initialized
INFO - 2017-06-20 10:48:44 --> Helper loaded: form_helper
INFO - 2017-06-20 10:48:44 --> Helper loaded: url_helper
INFO - 2017-06-20 10:48:44 --> Model Class Initialized
INFO - 2017-06-20 10:48:44 --> Final output sent to browser
DEBUG - 2017-06-20 10:48:44 --> Total execution time: 0.0580
ERROR - 2017-06-20 10:48:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 10:48:45 --> Config Class Initialized
INFO - 2017-06-20 10:48:45 --> Hooks Class Initialized
DEBUG - 2017-06-20 10:48:45 --> UTF-8 Support Enabled
INFO - 2017-06-20 10:48:45 --> Utf8 Class Initialized
INFO - 2017-06-20 10:48:45 --> URI Class Initialized
INFO - 2017-06-20 10:48:45 --> Router Class Initialized
INFO - 2017-06-20 10:48:45 --> Output Class Initialized
INFO - 2017-06-20 10:48:45 --> Security Class Initialized
DEBUG - 2017-06-20 10:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 10:48:45 --> Input Class Initialized
INFO - 2017-06-20 10:48:45 --> Language Class Initialized
INFO - 2017-06-20 10:48:45 --> Loader Class Initialized
INFO - 2017-06-20 10:48:45 --> Controller Class Initialized
INFO - 2017-06-20 10:48:45 --> Database Driver Class Initialized
INFO - 2017-06-20 10:48:45 --> Model Class Initialized
INFO - 2017-06-20 10:48:45 --> Helper loaded: form_helper
INFO - 2017-06-20 10:48:45 --> Helper loaded: url_helper
INFO - 2017-06-20 10:48:45 --> Model Class Initialized
INFO - 2017-06-20 10:48:45 --> Final output sent to browser
DEBUG - 2017-06-20 10:48:45 --> Total execution time: 0.0430
ERROR - 2017-06-20 10:51:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 10:51:03 --> Config Class Initialized
INFO - 2017-06-20 10:51:03 --> Hooks Class Initialized
DEBUG - 2017-06-20 10:51:03 --> UTF-8 Support Enabled
INFO - 2017-06-20 10:51:03 --> Utf8 Class Initialized
INFO - 2017-06-20 10:51:03 --> URI Class Initialized
INFO - 2017-06-20 10:51:03 --> Router Class Initialized
INFO - 2017-06-20 10:51:03 --> Output Class Initialized
INFO - 2017-06-20 10:51:03 --> Security Class Initialized
DEBUG - 2017-06-20 10:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 10:51:03 --> Input Class Initialized
INFO - 2017-06-20 10:51:03 --> Language Class Initialized
INFO - 2017-06-20 10:51:03 --> Loader Class Initialized
INFO - 2017-06-20 10:51:03 --> Controller Class Initialized
INFO - 2017-06-20 10:51:03 --> Database Driver Class Initialized
INFO - 2017-06-20 10:51:03 --> Model Class Initialized
INFO - 2017-06-20 10:51:03 --> Helper loaded: form_helper
INFO - 2017-06-20 10:51:03 --> Helper loaded: url_helper
INFO - 2017-06-20 10:51:03 --> Model Class Initialized
INFO - 2017-06-20 10:51:03 --> Final output sent to browser
DEBUG - 2017-06-20 10:51:03 --> Total execution time: 0.0470
ERROR - 2017-06-20 10:51:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 10:51:03 --> Config Class Initialized
INFO - 2017-06-20 10:51:03 --> Hooks Class Initialized
DEBUG - 2017-06-20 10:51:03 --> UTF-8 Support Enabled
INFO - 2017-06-20 10:51:03 --> Utf8 Class Initialized
INFO - 2017-06-20 10:51:03 --> URI Class Initialized
INFO - 2017-06-20 10:51:03 --> Router Class Initialized
INFO - 2017-06-20 10:51:03 --> Output Class Initialized
INFO - 2017-06-20 10:51:03 --> Security Class Initialized
DEBUG - 2017-06-20 10:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 10:51:03 --> Input Class Initialized
INFO - 2017-06-20 10:51:03 --> Language Class Initialized
INFO - 2017-06-20 10:51:03 --> Loader Class Initialized
INFO - 2017-06-20 10:51:03 --> Controller Class Initialized
INFO - 2017-06-20 10:51:03 --> Database Driver Class Initialized
INFO - 2017-06-20 10:51:03 --> Model Class Initialized
INFO - 2017-06-20 10:51:03 --> Helper loaded: form_helper
INFO - 2017-06-20 10:51:03 --> Helper loaded: url_helper
INFO - 2017-06-20 10:51:03 --> Model Class Initialized
INFO - 2017-06-20 10:51:03 --> Final output sent to browser
DEBUG - 2017-06-20 10:51:03 --> Total execution time: 0.0540
ERROR - 2017-06-20 11:12:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 11:12:25 --> Config Class Initialized
INFO - 2017-06-20 11:12:25 --> Hooks Class Initialized
DEBUG - 2017-06-20 11:12:25 --> UTF-8 Support Enabled
INFO - 2017-06-20 11:12:25 --> Utf8 Class Initialized
INFO - 2017-06-20 11:12:25 --> URI Class Initialized
INFO - 2017-06-20 11:12:25 --> Router Class Initialized
INFO - 2017-06-20 11:12:25 --> Output Class Initialized
INFO - 2017-06-20 11:12:25 --> Security Class Initialized
DEBUG - 2017-06-20 11:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 11:12:25 --> Input Class Initialized
INFO - 2017-06-20 11:12:25 --> Language Class Initialized
INFO - 2017-06-20 11:12:25 --> Loader Class Initialized
INFO - 2017-06-20 11:12:25 --> Controller Class Initialized
INFO - 2017-06-20 11:12:25 --> Database Driver Class Initialized
INFO - 2017-06-20 11:12:25 --> Model Class Initialized
INFO - 2017-06-20 11:12:25 --> Helper loaded: form_helper
INFO - 2017-06-20 11:12:25 --> Helper loaded: url_helper
INFO - 2017-06-20 11:12:25 --> Model Class Initialized
INFO - 2017-06-20 11:12:25 --> Final output sent to browser
DEBUG - 2017-06-20 11:12:25 --> Total execution time: 0.0470
ERROR - 2017-06-20 11:14:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 11:14:30 --> Config Class Initialized
INFO - 2017-06-20 11:14:30 --> Hooks Class Initialized
DEBUG - 2017-06-20 11:14:30 --> UTF-8 Support Enabled
INFO - 2017-06-20 11:14:30 --> Utf8 Class Initialized
INFO - 2017-06-20 11:14:30 --> URI Class Initialized
INFO - 2017-06-20 11:14:30 --> Router Class Initialized
INFO - 2017-06-20 11:14:30 --> Output Class Initialized
INFO - 2017-06-20 11:14:30 --> Security Class Initialized
DEBUG - 2017-06-20 11:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 11:14:30 --> Input Class Initialized
INFO - 2017-06-20 11:14:30 --> Language Class Initialized
INFO - 2017-06-20 11:14:30 --> Loader Class Initialized
INFO - 2017-06-20 11:14:30 --> Controller Class Initialized
INFO - 2017-06-20 11:14:30 --> Database Driver Class Initialized
INFO - 2017-06-20 11:14:30 --> Model Class Initialized
INFO - 2017-06-20 11:14:30 --> Helper loaded: form_helper
INFO - 2017-06-20 11:14:30 --> Helper loaded: url_helper
INFO - 2017-06-20 11:14:30 --> Model Class Initialized
INFO - 2017-06-20 11:14:30 --> Final output sent to browser
DEBUG - 2017-06-20 11:14:30 --> Total execution time: 0.0480
ERROR - 2017-06-20 12:37:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 12:37:11 --> Config Class Initialized
INFO - 2017-06-20 12:37:11 --> Hooks Class Initialized
DEBUG - 2017-06-20 12:37:11 --> UTF-8 Support Enabled
INFO - 2017-06-20 12:37:11 --> Utf8 Class Initialized
INFO - 2017-06-20 12:37:11 --> URI Class Initialized
INFO - 2017-06-20 12:37:11 --> Router Class Initialized
INFO - 2017-06-20 12:37:11 --> Output Class Initialized
INFO - 2017-06-20 12:37:11 --> Security Class Initialized
DEBUG - 2017-06-20 12:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 12:37:11 --> Input Class Initialized
INFO - 2017-06-20 12:37:11 --> Language Class Initialized
INFO - 2017-06-20 12:37:11 --> Loader Class Initialized
INFO - 2017-06-20 12:37:11 --> Controller Class Initialized
INFO - 2017-06-20 12:37:11 --> Database Driver Class Initialized
INFO - 2017-06-20 12:37:11 --> Model Class Initialized
INFO - 2017-06-20 12:37:11 --> Helper loaded: form_helper
INFO - 2017-06-20 12:37:11 --> Helper loaded: url_helper
INFO - 2017-06-20 12:37:11 --> Model Class Initialized
INFO - 2017-06-20 12:37:11 --> Final output sent to browser
DEBUG - 2017-06-20 12:37:11 --> Total execution time: 0.0560
ERROR - 2017-06-20 12:47:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 12:47:05 --> Config Class Initialized
INFO - 2017-06-20 12:47:05 --> Hooks Class Initialized
DEBUG - 2017-06-20 12:47:05 --> UTF-8 Support Enabled
INFO - 2017-06-20 12:47:05 --> Utf8 Class Initialized
INFO - 2017-06-20 12:47:05 --> URI Class Initialized
INFO - 2017-06-20 12:47:05 --> Router Class Initialized
INFO - 2017-06-20 12:47:05 --> Output Class Initialized
INFO - 2017-06-20 12:47:05 --> Security Class Initialized
DEBUG - 2017-06-20 12:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 12:47:05 --> Input Class Initialized
INFO - 2017-06-20 12:47:05 --> Language Class Initialized
INFO - 2017-06-20 12:47:05 --> Loader Class Initialized
INFO - 2017-06-20 12:47:05 --> Controller Class Initialized
INFO - 2017-06-20 12:47:05 --> Database Driver Class Initialized
INFO - 2017-06-20 12:47:05 --> Model Class Initialized
INFO - 2017-06-20 12:47:05 --> Helper loaded: form_helper
INFO - 2017-06-20 12:47:05 --> Helper loaded: url_helper
INFO - 2017-06-20 12:47:05 --> Model Class Initialized
INFO - 2017-06-20 12:47:05 --> Final output sent to browser
DEBUG - 2017-06-20 12:47:05 --> Total execution time: 0.0520
ERROR - 2017-06-20 12:47:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 12:47:05 --> Config Class Initialized
INFO - 2017-06-20 12:47:05 --> Hooks Class Initialized
DEBUG - 2017-06-20 12:47:05 --> UTF-8 Support Enabled
INFO - 2017-06-20 12:47:05 --> Utf8 Class Initialized
INFO - 2017-06-20 12:47:05 --> URI Class Initialized
INFO - 2017-06-20 12:47:05 --> Router Class Initialized
INFO - 2017-06-20 12:47:05 --> Output Class Initialized
INFO - 2017-06-20 12:47:05 --> Security Class Initialized
DEBUG - 2017-06-20 12:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 12:47:05 --> Input Class Initialized
INFO - 2017-06-20 12:47:05 --> Language Class Initialized
INFO - 2017-06-20 12:47:05 --> Loader Class Initialized
INFO - 2017-06-20 12:47:05 --> Controller Class Initialized
INFO - 2017-06-20 12:47:05 --> Database Driver Class Initialized
INFO - 2017-06-20 12:47:05 --> Model Class Initialized
INFO - 2017-06-20 12:47:05 --> Helper loaded: form_helper
INFO - 2017-06-20 12:47:05 --> Helper loaded: url_helper
INFO - 2017-06-20 12:47:05 --> Model Class Initialized
INFO - 2017-06-20 12:47:05 --> Final output sent to browser
DEBUG - 2017-06-20 12:47:05 --> Total execution time: 0.0470
ERROR - 2017-06-20 12:48:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 12:48:26 --> Config Class Initialized
INFO - 2017-06-20 12:48:26 --> Hooks Class Initialized
DEBUG - 2017-06-20 12:48:26 --> UTF-8 Support Enabled
INFO - 2017-06-20 12:48:26 --> Utf8 Class Initialized
INFO - 2017-06-20 12:48:26 --> URI Class Initialized
INFO - 2017-06-20 12:48:26 --> Router Class Initialized
INFO - 2017-06-20 12:48:26 --> Output Class Initialized
INFO - 2017-06-20 12:48:26 --> Security Class Initialized
DEBUG - 2017-06-20 12:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 12:48:26 --> Input Class Initialized
INFO - 2017-06-20 12:48:26 --> Language Class Initialized
INFO - 2017-06-20 12:48:26 --> Loader Class Initialized
INFO - 2017-06-20 12:48:26 --> Controller Class Initialized
INFO - 2017-06-20 12:48:26 --> Database Driver Class Initialized
INFO - 2017-06-20 12:48:26 --> Model Class Initialized
INFO - 2017-06-20 12:48:26 --> Helper loaded: form_helper
INFO - 2017-06-20 12:48:26 --> Helper loaded: url_helper
INFO - 2017-06-20 12:48:26 --> Model Class Initialized
INFO - 2017-06-20 12:48:26 --> Final output sent to browser
DEBUG - 2017-06-20 12:48:26 --> Total execution time: 0.0590
ERROR - 2017-06-20 12:48:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 12:48:26 --> Config Class Initialized
INFO - 2017-06-20 12:48:26 --> Hooks Class Initialized
DEBUG - 2017-06-20 12:48:26 --> UTF-8 Support Enabled
INFO - 2017-06-20 12:48:26 --> Utf8 Class Initialized
INFO - 2017-06-20 12:48:26 --> URI Class Initialized
INFO - 2017-06-20 12:48:26 --> Router Class Initialized
INFO - 2017-06-20 12:48:26 --> Output Class Initialized
INFO - 2017-06-20 12:48:26 --> Security Class Initialized
DEBUG - 2017-06-20 12:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 12:48:26 --> Input Class Initialized
INFO - 2017-06-20 12:48:26 --> Language Class Initialized
INFO - 2017-06-20 12:48:26 --> Loader Class Initialized
INFO - 2017-06-20 12:48:26 --> Controller Class Initialized
INFO - 2017-06-20 12:48:26 --> Database Driver Class Initialized
INFO - 2017-06-20 12:48:26 --> Model Class Initialized
INFO - 2017-06-20 12:48:26 --> Helper loaded: form_helper
INFO - 2017-06-20 12:48:26 --> Helper loaded: url_helper
INFO - 2017-06-20 12:48:26 --> Model Class Initialized
INFO - 2017-06-20 12:48:26 --> Final output sent to browser
DEBUG - 2017-06-20 12:48:26 --> Total execution time: 0.0450
ERROR - 2017-06-20 12:48:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 12:48:50 --> Config Class Initialized
INFO - 2017-06-20 12:48:50 --> Hooks Class Initialized
DEBUG - 2017-06-20 12:48:50 --> UTF-8 Support Enabled
INFO - 2017-06-20 12:48:50 --> Utf8 Class Initialized
INFO - 2017-06-20 12:48:50 --> URI Class Initialized
INFO - 2017-06-20 12:48:50 --> Router Class Initialized
INFO - 2017-06-20 12:48:50 --> Output Class Initialized
INFO - 2017-06-20 12:48:50 --> Security Class Initialized
DEBUG - 2017-06-20 12:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 12:48:50 --> Input Class Initialized
INFO - 2017-06-20 12:48:50 --> Language Class Initialized
INFO - 2017-06-20 12:48:50 --> Loader Class Initialized
INFO - 2017-06-20 12:48:50 --> Controller Class Initialized
INFO - 2017-06-20 12:48:50 --> Database Driver Class Initialized
INFO - 2017-06-20 12:48:50 --> Model Class Initialized
INFO - 2017-06-20 12:48:50 --> Helper loaded: form_helper
INFO - 2017-06-20 12:48:50 --> Helper loaded: url_helper
INFO - 2017-06-20 12:48:50 --> Model Class Initialized
INFO - 2017-06-20 12:48:50 --> Final output sent to browser
DEBUG - 2017-06-20 12:48:50 --> Total execution time: 0.0600
ERROR - 2017-06-20 12:48:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 12:48:59 --> Config Class Initialized
INFO - 2017-06-20 12:48:59 --> Hooks Class Initialized
DEBUG - 2017-06-20 12:48:59 --> UTF-8 Support Enabled
INFO - 2017-06-20 12:48:59 --> Utf8 Class Initialized
INFO - 2017-06-20 12:48:59 --> URI Class Initialized
INFO - 2017-06-20 12:48:59 --> Router Class Initialized
INFO - 2017-06-20 12:48:59 --> Output Class Initialized
INFO - 2017-06-20 12:48:59 --> Security Class Initialized
DEBUG - 2017-06-20 12:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 12:48:59 --> Input Class Initialized
INFO - 2017-06-20 12:48:59 --> Language Class Initialized
INFO - 2017-06-20 12:48:59 --> Loader Class Initialized
INFO - 2017-06-20 12:48:59 --> Controller Class Initialized
INFO - 2017-06-20 12:48:59 --> Database Driver Class Initialized
INFO - 2017-06-20 12:48:59 --> Model Class Initialized
INFO - 2017-06-20 12:48:59 --> Helper loaded: form_helper
INFO - 2017-06-20 12:48:59 --> Helper loaded: url_helper
INFO - 2017-06-20 12:48:59 --> Model Class Initialized
INFO - 2017-06-20 12:48:59 --> Final output sent to browser
DEBUG - 2017-06-20 12:48:59 --> Total execution time: 0.0490
ERROR - 2017-06-20 12:49:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 12:49:28 --> Config Class Initialized
INFO - 2017-06-20 12:49:28 --> Hooks Class Initialized
DEBUG - 2017-06-20 12:49:28 --> UTF-8 Support Enabled
INFO - 2017-06-20 12:49:28 --> Utf8 Class Initialized
INFO - 2017-06-20 12:49:28 --> URI Class Initialized
INFO - 2017-06-20 12:49:28 --> Router Class Initialized
INFO - 2017-06-20 12:49:28 --> Output Class Initialized
INFO - 2017-06-20 12:49:28 --> Security Class Initialized
DEBUG - 2017-06-20 12:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 12:49:28 --> Input Class Initialized
INFO - 2017-06-20 12:49:28 --> Language Class Initialized
INFO - 2017-06-20 12:49:28 --> Loader Class Initialized
INFO - 2017-06-20 12:49:28 --> Controller Class Initialized
INFO - 2017-06-20 12:49:28 --> Database Driver Class Initialized
INFO - 2017-06-20 12:49:28 --> Model Class Initialized
INFO - 2017-06-20 12:49:28 --> Helper loaded: form_helper
INFO - 2017-06-20 12:49:28 --> Helper loaded: url_helper
INFO - 2017-06-20 12:49:28 --> Model Class Initialized
INFO - 2017-06-20 12:49:28 --> Final output sent to browser
DEBUG - 2017-06-20 12:49:28 --> Total execution time: 0.0570
ERROR - 2017-06-20 12:50:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 12:50:08 --> Config Class Initialized
INFO - 2017-06-20 12:50:08 --> Hooks Class Initialized
DEBUG - 2017-06-20 12:50:08 --> UTF-8 Support Enabled
INFO - 2017-06-20 12:50:08 --> Utf8 Class Initialized
INFO - 2017-06-20 12:50:08 --> URI Class Initialized
INFO - 2017-06-20 12:50:08 --> Router Class Initialized
INFO - 2017-06-20 12:50:08 --> Output Class Initialized
INFO - 2017-06-20 12:50:08 --> Security Class Initialized
DEBUG - 2017-06-20 12:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 12:50:08 --> Input Class Initialized
INFO - 2017-06-20 12:50:08 --> Language Class Initialized
INFO - 2017-06-20 12:50:08 --> Loader Class Initialized
INFO - 2017-06-20 12:50:08 --> Controller Class Initialized
INFO - 2017-06-20 12:50:08 --> Database Driver Class Initialized
INFO - 2017-06-20 12:50:08 --> Model Class Initialized
INFO - 2017-06-20 12:50:08 --> Helper loaded: form_helper
INFO - 2017-06-20 12:50:08 --> Helper loaded: url_helper
INFO - 2017-06-20 12:50:08 --> Model Class Initialized
INFO - 2017-06-20 12:50:08 --> Final output sent to browser
DEBUG - 2017-06-20 12:50:08 --> Total execution time: 0.0590
ERROR - 2017-06-20 12:50:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 12:50:09 --> Config Class Initialized
INFO - 2017-06-20 12:50:09 --> Hooks Class Initialized
DEBUG - 2017-06-20 12:50:09 --> UTF-8 Support Enabled
INFO - 2017-06-20 12:50:09 --> Utf8 Class Initialized
INFO - 2017-06-20 12:50:09 --> URI Class Initialized
INFO - 2017-06-20 12:50:09 --> Router Class Initialized
INFO - 2017-06-20 12:50:09 --> Output Class Initialized
INFO - 2017-06-20 12:50:09 --> Security Class Initialized
DEBUG - 2017-06-20 12:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 12:50:09 --> Input Class Initialized
INFO - 2017-06-20 12:50:09 --> Language Class Initialized
INFO - 2017-06-20 12:50:09 --> Loader Class Initialized
INFO - 2017-06-20 12:50:09 --> Controller Class Initialized
INFO - 2017-06-20 12:50:09 --> Database Driver Class Initialized
INFO - 2017-06-20 12:50:09 --> Model Class Initialized
INFO - 2017-06-20 12:50:09 --> Helper loaded: form_helper
INFO - 2017-06-20 12:50:09 --> Helper loaded: url_helper
INFO - 2017-06-20 12:50:09 --> Model Class Initialized
INFO - 2017-06-20 12:50:09 --> Final output sent to browser
DEBUG - 2017-06-20 12:50:09 --> Total execution time: 0.0570
ERROR - 2017-06-20 12:51:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 12:51:23 --> Config Class Initialized
INFO - 2017-06-20 12:51:23 --> Hooks Class Initialized
DEBUG - 2017-06-20 12:51:23 --> UTF-8 Support Enabled
INFO - 2017-06-20 12:51:23 --> Utf8 Class Initialized
INFO - 2017-06-20 12:51:23 --> URI Class Initialized
INFO - 2017-06-20 12:51:23 --> Router Class Initialized
INFO - 2017-06-20 12:51:23 --> Output Class Initialized
INFO - 2017-06-20 12:51:23 --> Security Class Initialized
DEBUG - 2017-06-20 12:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 12:51:23 --> Input Class Initialized
INFO - 2017-06-20 12:51:23 --> Language Class Initialized
INFO - 2017-06-20 12:51:23 --> Loader Class Initialized
INFO - 2017-06-20 12:51:23 --> Controller Class Initialized
INFO - 2017-06-20 12:51:23 --> Database Driver Class Initialized
INFO - 2017-06-20 12:51:23 --> Model Class Initialized
INFO - 2017-06-20 12:51:23 --> Helper loaded: form_helper
INFO - 2017-06-20 12:51:23 --> Helper loaded: url_helper
INFO - 2017-06-20 12:51:23 --> Model Class Initialized
INFO - 2017-06-20 12:51:23 --> Final output sent to browser
DEBUG - 2017-06-20 12:51:23 --> Total execution time: 0.0690
ERROR - 2017-06-20 12:51:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 12:51:24 --> Config Class Initialized
INFO - 2017-06-20 12:51:24 --> Hooks Class Initialized
DEBUG - 2017-06-20 12:51:24 --> UTF-8 Support Enabled
INFO - 2017-06-20 12:51:24 --> Utf8 Class Initialized
INFO - 2017-06-20 12:51:24 --> URI Class Initialized
INFO - 2017-06-20 12:51:24 --> Router Class Initialized
INFO - 2017-06-20 12:51:24 --> Output Class Initialized
INFO - 2017-06-20 12:51:24 --> Security Class Initialized
DEBUG - 2017-06-20 12:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 12:51:24 --> Input Class Initialized
INFO - 2017-06-20 12:51:24 --> Language Class Initialized
INFO - 2017-06-20 12:51:24 --> Loader Class Initialized
INFO - 2017-06-20 12:51:24 --> Controller Class Initialized
INFO - 2017-06-20 12:51:24 --> Database Driver Class Initialized
INFO - 2017-06-20 12:51:24 --> Model Class Initialized
INFO - 2017-06-20 12:51:24 --> Helper loaded: form_helper
INFO - 2017-06-20 12:51:24 --> Helper loaded: url_helper
INFO - 2017-06-20 12:51:24 --> Model Class Initialized
INFO - 2017-06-20 12:51:24 --> Final output sent to browser
DEBUG - 2017-06-20 12:51:24 --> Total execution time: 0.0470
ERROR - 2017-06-20 12:52:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 12:52:22 --> Config Class Initialized
INFO - 2017-06-20 12:52:22 --> Hooks Class Initialized
DEBUG - 2017-06-20 12:52:22 --> UTF-8 Support Enabled
INFO - 2017-06-20 12:52:22 --> Utf8 Class Initialized
INFO - 2017-06-20 12:52:22 --> URI Class Initialized
INFO - 2017-06-20 12:52:22 --> Router Class Initialized
INFO - 2017-06-20 12:52:22 --> Output Class Initialized
INFO - 2017-06-20 12:52:22 --> Security Class Initialized
DEBUG - 2017-06-20 12:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 12:52:22 --> Input Class Initialized
INFO - 2017-06-20 12:52:22 --> Language Class Initialized
INFO - 2017-06-20 12:52:22 --> Loader Class Initialized
INFO - 2017-06-20 12:52:22 --> Controller Class Initialized
INFO - 2017-06-20 12:52:22 --> Database Driver Class Initialized
INFO - 2017-06-20 12:52:22 --> Model Class Initialized
INFO - 2017-06-20 12:52:22 --> Helper loaded: form_helper
INFO - 2017-06-20 12:52:22 --> Helper loaded: url_helper
INFO - 2017-06-20 12:52:22 --> Model Class Initialized
INFO - 2017-06-20 12:52:22 --> Final output sent to browser
DEBUG - 2017-06-20 12:52:22 --> Total execution time: 0.0640
ERROR - 2017-06-20 12:52:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 12:52:23 --> Config Class Initialized
INFO - 2017-06-20 12:52:23 --> Hooks Class Initialized
DEBUG - 2017-06-20 12:52:23 --> UTF-8 Support Enabled
INFO - 2017-06-20 12:52:23 --> Utf8 Class Initialized
INFO - 2017-06-20 12:52:23 --> URI Class Initialized
INFO - 2017-06-20 12:52:23 --> Router Class Initialized
INFO - 2017-06-20 12:52:23 --> Output Class Initialized
INFO - 2017-06-20 12:52:23 --> Security Class Initialized
DEBUG - 2017-06-20 12:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 12:52:23 --> Input Class Initialized
INFO - 2017-06-20 12:52:23 --> Language Class Initialized
INFO - 2017-06-20 12:52:23 --> Loader Class Initialized
INFO - 2017-06-20 12:52:23 --> Controller Class Initialized
INFO - 2017-06-20 12:52:23 --> Database Driver Class Initialized
INFO - 2017-06-20 12:52:23 --> Model Class Initialized
INFO - 2017-06-20 12:52:23 --> Helper loaded: form_helper
INFO - 2017-06-20 12:52:23 --> Helper loaded: url_helper
INFO - 2017-06-20 12:52:23 --> Model Class Initialized
INFO - 2017-06-20 12:52:23 --> Final output sent to browser
DEBUG - 2017-06-20 12:52:23 --> Total execution time: 0.0560
ERROR - 2017-06-20 13:08:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 13:08:56 --> Config Class Initialized
INFO - 2017-06-20 13:08:56 --> Hooks Class Initialized
DEBUG - 2017-06-20 13:08:56 --> UTF-8 Support Enabled
INFO - 2017-06-20 13:08:56 --> Utf8 Class Initialized
INFO - 2017-06-20 13:08:56 --> URI Class Initialized
INFO - 2017-06-20 13:08:56 --> Router Class Initialized
INFO - 2017-06-20 13:08:56 --> Output Class Initialized
INFO - 2017-06-20 13:08:56 --> Security Class Initialized
DEBUG - 2017-06-20 13:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 13:08:56 --> Input Class Initialized
INFO - 2017-06-20 13:08:56 --> Language Class Initialized
INFO - 2017-06-20 13:08:56 --> Loader Class Initialized
INFO - 2017-06-20 13:08:56 --> Controller Class Initialized
INFO - 2017-06-20 13:08:56 --> Database Driver Class Initialized
INFO - 2017-06-20 13:08:56 --> Model Class Initialized
INFO - 2017-06-20 13:08:56 --> Helper loaded: form_helper
INFO - 2017-06-20 13:08:56 --> Helper loaded: url_helper
INFO - 2017-06-20 13:08:56 --> Model Class Initialized
INFO - 2017-06-20 13:08:56 --> Final output sent to browser
DEBUG - 2017-06-20 13:08:56 --> Total execution time: 0.0550
ERROR - 2017-06-20 13:08:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 13:08:57 --> Config Class Initialized
INFO - 2017-06-20 13:08:57 --> Hooks Class Initialized
DEBUG - 2017-06-20 13:08:57 --> UTF-8 Support Enabled
INFO - 2017-06-20 13:08:57 --> Utf8 Class Initialized
INFO - 2017-06-20 13:08:57 --> URI Class Initialized
INFO - 2017-06-20 13:08:57 --> Router Class Initialized
INFO - 2017-06-20 13:08:57 --> Output Class Initialized
INFO - 2017-06-20 13:08:57 --> Security Class Initialized
DEBUG - 2017-06-20 13:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 13:08:57 --> Input Class Initialized
INFO - 2017-06-20 13:08:57 --> Language Class Initialized
INFO - 2017-06-20 13:08:57 --> Loader Class Initialized
INFO - 2017-06-20 13:08:57 --> Controller Class Initialized
INFO - 2017-06-20 13:08:57 --> Database Driver Class Initialized
INFO - 2017-06-20 13:08:57 --> Model Class Initialized
INFO - 2017-06-20 13:08:57 --> Helper loaded: form_helper
INFO - 2017-06-20 13:08:57 --> Helper loaded: url_helper
INFO - 2017-06-20 13:08:57 --> Model Class Initialized
INFO - 2017-06-20 13:08:57 --> Final output sent to browser
DEBUG - 2017-06-20 13:08:57 --> Total execution time: 0.0450
ERROR - 2017-06-20 13:09:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 13:09:23 --> Config Class Initialized
INFO - 2017-06-20 13:09:23 --> Hooks Class Initialized
DEBUG - 2017-06-20 13:09:23 --> UTF-8 Support Enabled
INFO - 2017-06-20 13:09:23 --> Utf8 Class Initialized
INFO - 2017-06-20 13:09:23 --> URI Class Initialized
INFO - 2017-06-20 13:09:23 --> Router Class Initialized
INFO - 2017-06-20 13:09:23 --> Output Class Initialized
INFO - 2017-06-20 13:09:23 --> Security Class Initialized
DEBUG - 2017-06-20 13:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 13:09:23 --> Input Class Initialized
INFO - 2017-06-20 13:09:23 --> Language Class Initialized
INFO - 2017-06-20 13:09:23 --> Loader Class Initialized
INFO - 2017-06-20 13:09:23 --> Controller Class Initialized
INFO - 2017-06-20 13:09:23 --> Database Driver Class Initialized
INFO - 2017-06-20 13:09:23 --> Model Class Initialized
INFO - 2017-06-20 13:09:23 --> Helper loaded: form_helper
INFO - 2017-06-20 13:09:23 --> Helper loaded: url_helper
INFO - 2017-06-20 13:09:23 --> Model Class Initialized
INFO - 2017-06-20 13:09:23 --> Final output sent to browser
DEBUG - 2017-06-20 13:09:23 --> Total execution time: 0.0540
ERROR - 2017-06-20 13:09:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 13:09:23 --> Config Class Initialized
INFO - 2017-06-20 13:09:23 --> Hooks Class Initialized
DEBUG - 2017-06-20 13:09:23 --> UTF-8 Support Enabled
INFO - 2017-06-20 13:09:23 --> Utf8 Class Initialized
INFO - 2017-06-20 13:09:23 --> URI Class Initialized
INFO - 2017-06-20 13:09:23 --> Router Class Initialized
INFO - 2017-06-20 13:09:23 --> Output Class Initialized
INFO - 2017-06-20 13:09:23 --> Security Class Initialized
DEBUG - 2017-06-20 13:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 13:09:23 --> Input Class Initialized
INFO - 2017-06-20 13:09:23 --> Language Class Initialized
INFO - 2017-06-20 13:09:23 --> Loader Class Initialized
INFO - 2017-06-20 13:09:23 --> Controller Class Initialized
INFO - 2017-06-20 13:09:24 --> Database Driver Class Initialized
INFO - 2017-06-20 13:09:24 --> Model Class Initialized
INFO - 2017-06-20 13:09:24 --> Helper loaded: form_helper
INFO - 2017-06-20 13:09:24 --> Helper loaded: url_helper
INFO - 2017-06-20 13:09:24 --> Model Class Initialized
INFO - 2017-06-20 13:09:24 --> Final output sent to browser
DEBUG - 2017-06-20 13:09:24 --> Total execution time: 0.0440
ERROR - 2017-06-20 13:11:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 13:11:23 --> Config Class Initialized
INFO - 2017-06-20 13:11:23 --> Hooks Class Initialized
DEBUG - 2017-06-20 13:11:23 --> UTF-8 Support Enabled
INFO - 2017-06-20 13:11:23 --> Utf8 Class Initialized
INFO - 2017-06-20 13:11:23 --> URI Class Initialized
INFO - 2017-06-20 13:11:23 --> Router Class Initialized
INFO - 2017-06-20 13:11:23 --> Output Class Initialized
INFO - 2017-06-20 13:11:23 --> Security Class Initialized
DEBUG - 2017-06-20 13:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 13:11:23 --> Input Class Initialized
INFO - 2017-06-20 13:11:23 --> Language Class Initialized
INFO - 2017-06-20 13:11:23 --> Loader Class Initialized
INFO - 2017-06-20 13:11:23 --> Controller Class Initialized
INFO - 2017-06-20 13:11:23 --> Database Driver Class Initialized
INFO - 2017-06-20 13:11:23 --> Model Class Initialized
INFO - 2017-06-20 13:11:23 --> Helper loaded: form_helper
INFO - 2017-06-20 13:11:23 --> Helper loaded: url_helper
INFO - 2017-06-20 13:11:23 --> Model Class Initialized
INFO - 2017-06-20 13:11:23 --> Final output sent to browser
DEBUG - 2017-06-20 13:11:23 --> Total execution time: 0.0490
ERROR - 2017-06-20 13:11:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 13:11:23 --> Config Class Initialized
INFO - 2017-06-20 13:11:23 --> Hooks Class Initialized
DEBUG - 2017-06-20 13:11:23 --> UTF-8 Support Enabled
INFO - 2017-06-20 13:11:23 --> Utf8 Class Initialized
INFO - 2017-06-20 13:11:23 --> URI Class Initialized
INFO - 2017-06-20 13:11:23 --> Router Class Initialized
INFO - 2017-06-20 13:11:23 --> Output Class Initialized
INFO - 2017-06-20 13:11:23 --> Security Class Initialized
DEBUG - 2017-06-20 13:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 13:11:23 --> Input Class Initialized
INFO - 2017-06-20 13:11:23 --> Language Class Initialized
INFO - 2017-06-20 13:11:23 --> Loader Class Initialized
INFO - 2017-06-20 13:11:23 --> Controller Class Initialized
INFO - 2017-06-20 13:11:23 --> Database Driver Class Initialized
INFO - 2017-06-20 13:11:23 --> Model Class Initialized
INFO - 2017-06-20 13:11:23 --> Helper loaded: form_helper
INFO - 2017-06-20 13:11:23 --> Helper loaded: url_helper
INFO - 2017-06-20 13:11:23 --> Model Class Initialized
INFO - 2017-06-20 13:11:23 --> Final output sent to browser
DEBUG - 2017-06-20 13:11:23 --> Total execution time: 0.0450
ERROR - 2017-06-20 13:29:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 13:29:25 --> Config Class Initialized
INFO - 2017-06-20 13:29:25 --> Hooks Class Initialized
DEBUG - 2017-06-20 13:29:25 --> UTF-8 Support Enabled
INFO - 2017-06-20 13:29:25 --> Utf8 Class Initialized
INFO - 2017-06-20 13:29:25 --> URI Class Initialized
INFO - 2017-06-20 13:29:25 --> Router Class Initialized
INFO - 2017-06-20 13:29:25 --> Output Class Initialized
INFO - 2017-06-20 13:29:25 --> Security Class Initialized
DEBUG - 2017-06-20 13:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 13:29:25 --> Input Class Initialized
INFO - 2017-06-20 13:29:25 --> Language Class Initialized
INFO - 2017-06-20 13:29:25 --> Loader Class Initialized
INFO - 2017-06-20 13:29:25 --> Controller Class Initialized
INFO - 2017-06-20 13:29:25 --> Database Driver Class Initialized
INFO - 2017-06-20 13:29:25 --> Model Class Initialized
INFO - 2017-06-20 13:29:25 --> Helper loaded: form_helper
INFO - 2017-06-20 13:29:25 --> Helper loaded: url_helper
INFO - 2017-06-20 13:29:25 --> Model Class Initialized
INFO - 2017-06-20 13:29:25 --> Final output sent to browser
DEBUG - 2017-06-20 13:29:25 --> Total execution time: 0.0525
ERROR - 2017-06-20 13:29:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 13:29:25 --> Config Class Initialized
INFO - 2017-06-20 13:29:25 --> Hooks Class Initialized
DEBUG - 2017-06-20 13:29:25 --> UTF-8 Support Enabled
INFO - 2017-06-20 13:29:25 --> Utf8 Class Initialized
INFO - 2017-06-20 13:29:25 --> URI Class Initialized
INFO - 2017-06-20 13:29:25 --> Router Class Initialized
INFO - 2017-06-20 13:29:25 --> Output Class Initialized
INFO - 2017-06-20 13:29:25 --> Security Class Initialized
DEBUG - 2017-06-20 13:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 13:29:25 --> Input Class Initialized
INFO - 2017-06-20 13:29:25 --> Language Class Initialized
INFO - 2017-06-20 13:29:25 --> Loader Class Initialized
INFO - 2017-06-20 13:29:25 --> Controller Class Initialized
INFO - 2017-06-20 13:29:25 --> Database Driver Class Initialized
INFO - 2017-06-20 13:29:25 --> Model Class Initialized
INFO - 2017-06-20 13:29:25 --> Helper loaded: form_helper
INFO - 2017-06-20 13:29:25 --> Helper loaded: url_helper
INFO - 2017-06-20 13:29:25 --> Model Class Initialized
INFO - 2017-06-20 13:29:25 --> Final output sent to browser
DEBUG - 2017-06-20 13:29:25 --> Total execution time: 0.0540
ERROR - 2017-06-20 13:55:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 13:55:12 --> Config Class Initialized
INFO - 2017-06-20 13:55:12 --> Hooks Class Initialized
DEBUG - 2017-06-20 13:55:12 --> UTF-8 Support Enabled
INFO - 2017-06-20 13:55:12 --> Utf8 Class Initialized
INFO - 2017-06-20 13:55:12 --> URI Class Initialized
INFO - 2017-06-20 13:55:12 --> Router Class Initialized
INFO - 2017-06-20 13:55:12 --> Output Class Initialized
INFO - 2017-06-20 13:55:12 --> Security Class Initialized
DEBUG - 2017-06-20 13:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 13:55:12 --> Input Class Initialized
INFO - 2017-06-20 13:55:12 --> Language Class Initialized
INFO - 2017-06-20 13:55:12 --> Loader Class Initialized
INFO - 2017-06-20 13:55:12 --> Controller Class Initialized
INFO - 2017-06-20 13:55:12 --> Database Driver Class Initialized
INFO - 2017-06-20 13:55:12 --> Model Class Initialized
INFO - 2017-06-20 13:55:12 --> Helper loaded: form_helper
INFO - 2017-06-20 13:55:12 --> Helper loaded: url_helper
INFO - 2017-06-20 13:55:12 --> Model Class Initialized
INFO - 2017-06-20 13:55:12 --> Final output sent to browser
DEBUG - 2017-06-20 13:55:12 --> Total execution time: 0.0540
ERROR - 2017-06-20 13:55:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 13:55:12 --> Config Class Initialized
INFO - 2017-06-20 13:55:12 --> Hooks Class Initialized
DEBUG - 2017-06-20 13:55:12 --> UTF-8 Support Enabled
INFO - 2017-06-20 13:55:12 --> Utf8 Class Initialized
INFO - 2017-06-20 13:55:12 --> URI Class Initialized
INFO - 2017-06-20 13:55:12 --> Router Class Initialized
INFO - 2017-06-20 13:55:12 --> Output Class Initialized
INFO - 2017-06-20 13:55:12 --> Security Class Initialized
DEBUG - 2017-06-20 13:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 13:55:12 --> Input Class Initialized
INFO - 2017-06-20 13:55:12 --> Language Class Initialized
INFO - 2017-06-20 13:55:12 --> Loader Class Initialized
INFO - 2017-06-20 13:55:12 --> Controller Class Initialized
INFO - 2017-06-20 13:55:12 --> Database Driver Class Initialized
INFO - 2017-06-20 13:55:12 --> Model Class Initialized
INFO - 2017-06-20 13:55:12 --> Helper loaded: form_helper
INFO - 2017-06-20 13:55:12 --> Helper loaded: url_helper
INFO - 2017-06-20 13:55:12 --> Model Class Initialized
INFO - 2017-06-20 13:55:12 --> Final output sent to browser
DEBUG - 2017-06-20 13:55:12 --> Total execution time: 0.0570
ERROR - 2017-06-20 13:58:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 13:58:06 --> Config Class Initialized
INFO - 2017-06-20 13:58:06 --> Hooks Class Initialized
DEBUG - 2017-06-20 13:58:06 --> UTF-8 Support Enabled
INFO - 2017-06-20 13:58:06 --> Utf8 Class Initialized
INFO - 2017-06-20 13:58:06 --> URI Class Initialized
INFO - 2017-06-20 13:58:06 --> Router Class Initialized
INFO - 2017-06-20 13:58:06 --> Output Class Initialized
INFO - 2017-06-20 13:58:06 --> Security Class Initialized
DEBUG - 2017-06-20 13:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 13:58:06 --> Input Class Initialized
INFO - 2017-06-20 13:58:06 --> Language Class Initialized
INFO - 2017-06-20 13:58:06 --> Loader Class Initialized
INFO - 2017-06-20 13:58:06 --> Controller Class Initialized
INFO - 2017-06-20 13:58:06 --> Database Driver Class Initialized
INFO - 2017-06-20 13:58:06 --> Model Class Initialized
INFO - 2017-06-20 13:58:06 --> Helper loaded: form_helper
INFO - 2017-06-20 13:58:06 --> Helper loaded: url_helper
INFO - 2017-06-20 13:58:06 --> Model Class Initialized
INFO - 2017-06-20 13:58:06 --> Final output sent to browser
DEBUG - 2017-06-20 13:58:06 --> Total execution time: 0.0600
ERROR - 2017-06-20 13:58:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 13:58:06 --> Config Class Initialized
INFO - 2017-06-20 13:58:06 --> Hooks Class Initialized
DEBUG - 2017-06-20 13:58:06 --> UTF-8 Support Enabled
INFO - 2017-06-20 13:58:06 --> Utf8 Class Initialized
INFO - 2017-06-20 13:58:06 --> URI Class Initialized
INFO - 2017-06-20 13:58:06 --> Router Class Initialized
INFO - 2017-06-20 13:58:06 --> Output Class Initialized
INFO - 2017-06-20 13:58:06 --> Security Class Initialized
DEBUG - 2017-06-20 13:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 13:58:06 --> Input Class Initialized
INFO - 2017-06-20 13:58:06 --> Language Class Initialized
INFO - 2017-06-20 13:58:06 --> Loader Class Initialized
INFO - 2017-06-20 13:58:06 --> Controller Class Initialized
INFO - 2017-06-20 13:58:06 --> Database Driver Class Initialized
INFO - 2017-06-20 13:58:06 --> Model Class Initialized
INFO - 2017-06-20 13:58:06 --> Helper loaded: form_helper
INFO - 2017-06-20 13:58:06 --> Helper loaded: url_helper
INFO - 2017-06-20 13:58:06 --> Model Class Initialized
INFO - 2017-06-20 13:58:06 --> Final output sent to browser
DEBUG - 2017-06-20 13:58:06 --> Total execution time: 0.0440
ERROR - 2017-06-20 16:20:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 16:20:54 --> Config Class Initialized
INFO - 2017-06-20 16:20:54 --> Hooks Class Initialized
DEBUG - 2017-06-20 16:20:55 --> UTF-8 Support Enabled
INFO - 2017-06-20 16:20:55 --> Utf8 Class Initialized
INFO - 2017-06-20 16:20:55 --> URI Class Initialized
INFO - 2017-06-20 16:20:55 --> Router Class Initialized
INFO - 2017-06-20 16:20:55 --> Output Class Initialized
INFO - 2017-06-20 16:20:55 --> Security Class Initialized
DEBUG - 2017-06-20 16:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 16:20:55 --> Input Class Initialized
INFO - 2017-06-20 16:20:55 --> Language Class Initialized
INFO - 2017-06-20 16:20:55 --> Loader Class Initialized
INFO - 2017-06-20 16:20:55 --> Controller Class Initialized
INFO - 2017-06-20 16:20:55 --> Database Driver Class Initialized
INFO - 2017-06-20 16:20:55 --> Model Class Initialized
INFO - 2017-06-20 16:20:55 --> Helper loaded: form_helper
INFO - 2017-06-20 16:20:55 --> Helper loaded: url_helper
INFO - 2017-06-20 16:20:55 --> Model Class Initialized
INFO - 2017-06-20 16:20:55 --> Final output sent to browser
DEBUG - 2017-06-20 16:20:55 --> Total execution time: 0.0530
ERROR - 2017-06-20 16:20:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 16:20:55 --> Config Class Initialized
INFO - 2017-06-20 16:20:55 --> Hooks Class Initialized
DEBUG - 2017-06-20 16:20:55 --> UTF-8 Support Enabled
INFO - 2017-06-20 16:20:55 --> Utf8 Class Initialized
INFO - 2017-06-20 16:20:55 --> URI Class Initialized
INFO - 2017-06-20 16:20:55 --> Router Class Initialized
INFO - 2017-06-20 16:20:55 --> Output Class Initialized
INFO - 2017-06-20 16:20:55 --> Security Class Initialized
DEBUG - 2017-06-20 16:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 16:20:55 --> Input Class Initialized
INFO - 2017-06-20 16:20:55 --> Language Class Initialized
INFO - 2017-06-20 16:20:55 --> Loader Class Initialized
INFO - 2017-06-20 16:20:55 --> Controller Class Initialized
INFO - 2017-06-20 16:20:55 --> Database Driver Class Initialized
INFO - 2017-06-20 16:20:55 --> Model Class Initialized
INFO - 2017-06-20 16:20:55 --> Helper loaded: form_helper
INFO - 2017-06-20 16:20:55 --> Helper loaded: url_helper
INFO - 2017-06-20 16:20:55 --> Model Class Initialized
INFO - 2017-06-20 16:20:55 --> Final output sent to browser
DEBUG - 2017-06-20 16:20:55 --> Total execution time: 0.0590
ERROR - 2017-06-20 16:22:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 16:22:26 --> Config Class Initialized
INFO - 2017-06-20 16:22:26 --> Hooks Class Initialized
DEBUG - 2017-06-20 16:22:26 --> UTF-8 Support Enabled
INFO - 2017-06-20 16:22:26 --> Utf8 Class Initialized
INFO - 2017-06-20 16:22:26 --> URI Class Initialized
INFO - 2017-06-20 16:22:26 --> Router Class Initialized
INFO - 2017-06-20 16:22:26 --> Output Class Initialized
INFO - 2017-06-20 16:22:26 --> Security Class Initialized
DEBUG - 2017-06-20 16:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 16:22:26 --> Input Class Initialized
INFO - 2017-06-20 16:22:26 --> Language Class Initialized
INFO - 2017-06-20 16:22:26 --> Loader Class Initialized
INFO - 2017-06-20 16:22:26 --> Controller Class Initialized
INFO - 2017-06-20 16:22:26 --> Database Driver Class Initialized
INFO - 2017-06-20 16:22:26 --> Model Class Initialized
INFO - 2017-06-20 16:22:26 --> Helper loaded: form_helper
INFO - 2017-06-20 16:22:26 --> Helper loaded: url_helper
INFO - 2017-06-20 16:22:26 --> Model Class Initialized
INFO - 2017-06-20 16:22:26 --> Final output sent to browser
DEBUG - 2017-06-20 16:22:26 --> Total execution time: 0.1205
ERROR - 2017-06-20 16:22:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 16:22:26 --> Config Class Initialized
INFO - 2017-06-20 16:22:26 --> Hooks Class Initialized
DEBUG - 2017-06-20 16:22:26 --> UTF-8 Support Enabled
INFO - 2017-06-20 16:22:26 --> Utf8 Class Initialized
INFO - 2017-06-20 16:22:26 --> URI Class Initialized
INFO - 2017-06-20 16:22:26 --> Router Class Initialized
INFO - 2017-06-20 16:22:26 --> Output Class Initialized
INFO - 2017-06-20 16:22:26 --> Security Class Initialized
DEBUG - 2017-06-20 16:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 16:22:26 --> Input Class Initialized
INFO - 2017-06-20 16:22:26 --> Language Class Initialized
INFO - 2017-06-20 16:22:26 --> Loader Class Initialized
INFO - 2017-06-20 16:22:26 --> Controller Class Initialized
INFO - 2017-06-20 16:22:26 --> Database Driver Class Initialized
INFO - 2017-06-20 16:22:26 --> Model Class Initialized
INFO - 2017-06-20 16:22:26 --> Helper loaded: form_helper
INFO - 2017-06-20 16:22:26 --> Helper loaded: url_helper
INFO - 2017-06-20 16:22:26 --> Model Class Initialized
INFO - 2017-06-20 16:22:26 --> Final output sent to browser
DEBUG - 2017-06-20 16:22:26 --> Total execution time: 0.0430
ERROR - 2017-06-20 16:24:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 16:24:08 --> Config Class Initialized
INFO - 2017-06-20 16:24:08 --> Hooks Class Initialized
DEBUG - 2017-06-20 16:24:08 --> UTF-8 Support Enabled
INFO - 2017-06-20 16:24:08 --> Utf8 Class Initialized
INFO - 2017-06-20 16:24:08 --> URI Class Initialized
INFO - 2017-06-20 16:24:08 --> Router Class Initialized
INFO - 2017-06-20 16:24:08 --> Output Class Initialized
INFO - 2017-06-20 16:24:08 --> Security Class Initialized
DEBUG - 2017-06-20 16:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 16:24:08 --> Input Class Initialized
INFO - 2017-06-20 16:24:08 --> Language Class Initialized
INFO - 2017-06-20 16:24:08 --> Loader Class Initialized
INFO - 2017-06-20 16:24:08 --> Controller Class Initialized
INFO - 2017-06-20 16:24:08 --> Database Driver Class Initialized
INFO - 2017-06-20 16:24:08 --> Model Class Initialized
INFO - 2017-06-20 16:24:08 --> Helper loaded: form_helper
INFO - 2017-06-20 16:24:08 --> Helper loaded: url_helper
INFO - 2017-06-20 16:24:08 --> Model Class Initialized
INFO - 2017-06-20 16:24:08 --> Final output sent to browser
DEBUG - 2017-06-20 16:24:08 --> Total execution time: 0.1245
ERROR - 2017-06-20 16:24:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 16:24:09 --> Config Class Initialized
INFO - 2017-06-20 16:24:09 --> Hooks Class Initialized
DEBUG - 2017-06-20 16:24:09 --> UTF-8 Support Enabled
INFO - 2017-06-20 16:24:09 --> Utf8 Class Initialized
INFO - 2017-06-20 16:24:09 --> URI Class Initialized
INFO - 2017-06-20 16:24:09 --> Router Class Initialized
INFO - 2017-06-20 16:24:09 --> Output Class Initialized
INFO - 2017-06-20 16:24:09 --> Security Class Initialized
DEBUG - 2017-06-20 16:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 16:24:09 --> Input Class Initialized
INFO - 2017-06-20 16:24:09 --> Language Class Initialized
INFO - 2017-06-20 16:24:09 --> Loader Class Initialized
INFO - 2017-06-20 16:24:09 --> Controller Class Initialized
INFO - 2017-06-20 16:24:09 --> Database Driver Class Initialized
INFO - 2017-06-20 16:24:09 --> Model Class Initialized
INFO - 2017-06-20 16:24:09 --> Helper loaded: form_helper
INFO - 2017-06-20 16:24:09 --> Helper loaded: url_helper
INFO - 2017-06-20 16:24:09 --> Model Class Initialized
INFO - 2017-06-20 16:24:09 --> Final output sent to browser
DEBUG - 2017-06-20 16:24:09 --> Total execution time: 0.0550
ERROR - 2017-06-20 16:52:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 16:52:05 --> Config Class Initialized
INFO - 2017-06-20 16:52:05 --> Hooks Class Initialized
DEBUG - 2017-06-20 16:52:05 --> UTF-8 Support Enabled
INFO - 2017-06-20 16:52:05 --> Utf8 Class Initialized
INFO - 2017-06-20 16:52:05 --> URI Class Initialized
INFO - 2017-06-20 16:52:05 --> Router Class Initialized
INFO - 2017-06-20 16:52:05 --> Output Class Initialized
INFO - 2017-06-20 16:52:05 --> Security Class Initialized
DEBUG - 2017-06-20 16:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 16:52:05 --> Input Class Initialized
INFO - 2017-06-20 16:52:05 --> Language Class Initialized
INFO - 2017-06-20 16:52:05 --> Loader Class Initialized
INFO - 2017-06-20 16:52:05 --> Controller Class Initialized
INFO - 2017-06-20 16:52:05 --> Database Driver Class Initialized
INFO - 2017-06-20 16:52:05 --> Model Class Initialized
INFO - 2017-06-20 16:52:05 --> Helper loaded: form_helper
INFO - 2017-06-20 16:52:05 --> Helper loaded: url_helper
INFO - 2017-06-20 16:52:05 --> Final output sent to browser
DEBUG - 2017-06-20 16:52:05 --> Total execution time: 0.0550
ERROR - 2017-06-20 16:52:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 16:52:31 --> Config Class Initialized
INFO - 2017-06-20 16:52:31 --> Hooks Class Initialized
DEBUG - 2017-06-20 16:52:31 --> UTF-8 Support Enabled
INFO - 2017-06-20 16:52:31 --> Utf8 Class Initialized
INFO - 2017-06-20 16:52:31 --> URI Class Initialized
INFO - 2017-06-20 16:52:31 --> Router Class Initialized
INFO - 2017-06-20 16:52:31 --> Output Class Initialized
INFO - 2017-06-20 16:52:31 --> Security Class Initialized
DEBUG - 2017-06-20 16:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 16:52:31 --> Input Class Initialized
INFO - 2017-06-20 16:52:31 --> Language Class Initialized
INFO - 2017-06-20 16:52:31 --> Loader Class Initialized
INFO - 2017-06-20 16:52:31 --> Controller Class Initialized
INFO - 2017-06-20 16:52:31 --> Database Driver Class Initialized
INFO - 2017-06-20 16:52:31 --> Model Class Initialized
INFO - 2017-06-20 16:52:31 --> Helper loaded: form_helper
INFO - 2017-06-20 16:52:31 --> Helper loaded: url_helper
INFO - 2017-06-20 16:52:31 --> Final output sent to browser
DEBUG - 2017-06-20 16:52:31 --> Total execution time: 0.0420
ERROR - 2017-06-20 16:52:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 16:52:37 --> Config Class Initialized
INFO - 2017-06-20 16:52:37 --> Hooks Class Initialized
DEBUG - 2017-06-20 16:52:37 --> UTF-8 Support Enabled
INFO - 2017-06-20 16:52:37 --> Utf8 Class Initialized
INFO - 2017-06-20 16:52:37 --> URI Class Initialized
INFO - 2017-06-20 16:52:37 --> Router Class Initialized
INFO - 2017-06-20 16:52:37 --> Output Class Initialized
INFO - 2017-06-20 16:52:37 --> Security Class Initialized
DEBUG - 2017-06-20 16:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 16:52:37 --> Input Class Initialized
INFO - 2017-06-20 16:52:37 --> Language Class Initialized
INFO - 2017-06-20 16:52:37 --> Loader Class Initialized
INFO - 2017-06-20 16:52:37 --> Controller Class Initialized
INFO - 2017-06-20 16:52:37 --> Database Driver Class Initialized
INFO - 2017-06-20 16:52:37 --> Model Class Initialized
INFO - 2017-06-20 16:52:37 --> Helper loaded: form_helper
INFO - 2017-06-20 16:52:37 --> Helper loaded: url_helper
INFO - 2017-06-20 16:52:37 --> Final output sent to browser
DEBUG - 2017-06-20 16:52:37 --> Total execution time: 0.0870
ERROR - 2017-06-20 16:53:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 16:53:15 --> Config Class Initialized
INFO - 2017-06-20 16:53:15 --> Hooks Class Initialized
DEBUG - 2017-06-20 16:53:15 --> UTF-8 Support Enabled
INFO - 2017-06-20 16:53:15 --> Utf8 Class Initialized
INFO - 2017-06-20 16:53:15 --> URI Class Initialized
INFO - 2017-06-20 16:53:15 --> Router Class Initialized
INFO - 2017-06-20 16:53:15 --> Output Class Initialized
INFO - 2017-06-20 16:53:15 --> Security Class Initialized
DEBUG - 2017-06-20 16:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 16:53:15 --> Input Class Initialized
INFO - 2017-06-20 16:53:15 --> Language Class Initialized
INFO - 2017-06-20 16:53:15 --> Loader Class Initialized
INFO - 2017-06-20 16:53:15 --> Controller Class Initialized
INFO - 2017-06-20 16:53:15 --> Database Driver Class Initialized
INFO - 2017-06-20 16:53:15 --> Model Class Initialized
INFO - 2017-06-20 16:53:15 --> Helper loaded: form_helper
INFO - 2017-06-20 16:53:15 --> Helper loaded: url_helper
INFO - 2017-06-20 16:53:15 --> Final output sent to browser
DEBUG - 2017-06-20 16:53:15 --> Total execution time: 0.0990
ERROR - 2017-06-20 16:53:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 16:53:18 --> Config Class Initialized
INFO - 2017-06-20 16:53:18 --> Hooks Class Initialized
DEBUG - 2017-06-20 16:53:18 --> UTF-8 Support Enabled
INFO - 2017-06-20 16:53:18 --> Utf8 Class Initialized
INFO - 2017-06-20 16:53:18 --> URI Class Initialized
INFO - 2017-06-20 16:53:18 --> Router Class Initialized
INFO - 2017-06-20 16:53:18 --> Output Class Initialized
INFO - 2017-06-20 16:53:18 --> Security Class Initialized
DEBUG - 2017-06-20 16:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 16:53:18 --> Input Class Initialized
INFO - 2017-06-20 16:53:18 --> Language Class Initialized
INFO - 2017-06-20 16:53:18 --> Loader Class Initialized
INFO - 2017-06-20 16:53:18 --> Controller Class Initialized
INFO - 2017-06-20 16:53:18 --> Database Driver Class Initialized
INFO - 2017-06-20 16:53:18 --> Model Class Initialized
INFO - 2017-06-20 16:53:18 --> Helper loaded: form_helper
INFO - 2017-06-20 16:53:18 --> Helper loaded: url_helper
INFO - 2017-06-20 16:53:18 --> Final output sent to browser
DEBUG - 2017-06-20 16:53:18 --> Total execution time: 0.0610
ERROR - 2017-06-20 16:53:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 16:53:22 --> Config Class Initialized
INFO - 2017-06-20 16:53:22 --> Hooks Class Initialized
DEBUG - 2017-06-20 16:53:22 --> UTF-8 Support Enabled
INFO - 2017-06-20 16:53:22 --> Utf8 Class Initialized
INFO - 2017-06-20 16:53:22 --> URI Class Initialized
INFO - 2017-06-20 16:53:22 --> Router Class Initialized
INFO - 2017-06-20 16:53:22 --> Output Class Initialized
INFO - 2017-06-20 16:53:22 --> Security Class Initialized
DEBUG - 2017-06-20 16:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 16:53:22 --> Input Class Initialized
INFO - 2017-06-20 16:53:22 --> Language Class Initialized
INFO - 2017-06-20 16:53:22 --> Loader Class Initialized
INFO - 2017-06-20 16:53:22 --> Controller Class Initialized
INFO - 2017-06-20 16:53:22 --> Database Driver Class Initialized
INFO - 2017-06-20 16:53:22 --> Model Class Initialized
INFO - 2017-06-20 16:53:22 --> Helper loaded: form_helper
INFO - 2017-06-20 16:53:22 --> Helper loaded: url_helper
INFO - 2017-06-20 16:53:22 --> Final output sent to browser
DEBUG - 2017-06-20 16:53:22 --> Total execution time: 0.0500
ERROR - 2017-06-20 16:53:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 16:53:39 --> Config Class Initialized
INFO - 2017-06-20 16:53:39 --> Hooks Class Initialized
DEBUG - 2017-06-20 16:53:39 --> UTF-8 Support Enabled
INFO - 2017-06-20 16:53:39 --> Utf8 Class Initialized
INFO - 2017-06-20 16:53:39 --> URI Class Initialized
INFO - 2017-06-20 16:53:39 --> Router Class Initialized
INFO - 2017-06-20 16:53:39 --> Output Class Initialized
INFO - 2017-06-20 16:53:39 --> Security Class Initialized
DEBUG - 2017-06-20 16:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 16:53:39 --> Input Class Initialized
INFO - 2017-06-20 16:53:39 --> Language Class Initialized
INFO - 2017-06-20 16:53:39 --> Loader Class Initialized
INFO - 2017-06-20 16:53:39 --> Controller Class Initialized
INFO - 2017-06-20 16:53:39 --> Database Driver Class Initialized
INFO - 2017-06-20 16:53:39 --> Model Class Initialized
INFO - 2017-06-20 16:53:39 --> Helper loaded: form_helper
INFO - 2017-06-20 16:53:39 --> Helper loaded: url_helper
INFO - 2017-06-20 16:53:39 --> Final output sent to browser
DEBUG - 2017-06-20 16:53:39 --> Total execution time: 0.0590
ERROR - 2017-06-20 16:54:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 16:54:04 --> Config Class Initialized
INFO - 2017-06-20 16:54:04 --> Hooks Class Initialized
DEBUG - 2017-06-20 16:54:04 --> UTF-8 Support Enabled
INFO - 2017-06-20 16:54:04 --> Utf8 Class Initialized
INFO - 2017-06-20 16:54:04 --> URI Class Initialized
INFO - 2017-06-20 16:54:04 --> Router Class Initialized
INFO - 2017-06-20 16:54:04 --> Output Class Initialized
INFO - 2017-06-20 16:54:04 --> Security Class Initialized
DEBUG - 2017-06-20 16:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 16:54:04 --> Input Class Initialized
INFO - 2017-06-20 16:54:04 --> Language Class Initialized
INFO - 2017-06-20 16:54:04 --> Loader Class Initialized
INFO - 2017-06-20 16:54:04 --> Controller Class Initialized
INFO - 2017-06-20 16:54:04 --> Database Driver Class Initialized
INFO - 2017-06-20 16:54:04 --> Model Class Initialized
INFO - 2017-06-20 16:54:04 --> Helper loaded: form_helper
INFO - 2017-06-20 16:54:04 --> Helper loaded: url_helper
INFO - 2017-06-20 16:54:04 --> Final output sent to browser
DEBUG - 2017-06-20 16:54:04 --> Total execution time: 0.0870
ERROR - 2017-06-20 16:54:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 16:54:34 --> Config Class Initialized
INFO - 2017-06-20 16:54:34 --> Hooks Class Initialized
DEBUG - 2017-06-20 16:54:34 --> UTF-8 Support Enabled
INFO - 2017-06-20 16:54:34 --> Utf8 Class Initialized
INFO - 2017-06-20 16:54:34 --> URI Class Initialized
INFO - 2017-06-20 16:54:34 --> Router Class Initialized
INFO - 2017-06-20 16:54:34 --> Output Class Initialized
INFO - 2017-06-20 16:54:34 --> Security Class Initialized
DEBUG - 2017-06-20 16:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 16:54:34 --> Input Class Initialized
INFO - 2017-06-20 16:54:34 --> Language Class Initialized
INFO - 2017-06-20 16:54:34 --> Loader Class Initialized
INFO - 2017-06-20 16:54:34 --> Controller Class Initialized
INFO - 2017-06-20 16:54:34 --> Database Driver Class Initialized
INFO - 2017-06-20 16:54:34 --> Model Class Initialized
INFO - 2017-06-20 16:54:34 --> Helper loaded: form_helper
INFO - 2017-06-20 16:54:34 --> Helper loaded: url_helper
INFO - 2017-06-20 16:54:34 --> Model Class Initialized
INFO - 2017-06-20 16:54:34 --> Final output sent to browser
DEBUG - 2017-06-20 16:54:34 --> Total execution time: 0.0890
ERROR - 2017-06-20 16:54:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 16:54:43 --> Config Class Initialized
INFO - 2017-06-20 16:54:43 --> Hooks Class Initialized
DEBUG - 2017-06-20 16:54:43 --> UTF-8 Support Enabled
INFO - 2017-06-20 16:54:43 --> Utf8 Class Initialized
INFO - 2017-06-20 16:54:43 --> URI Class Initialized
INFO - 2017-06-20 16:54:43 --> Router Class Initialized
INFO - 2017-06-20 16:54:43 --> Output Class Initialized
INFO - 2017-06-20 16:54:43 --> Security Class Initialized
DEBUG - 2017-06-20 16:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 16:54:43 --> Input Class Initialized
INFO - 2017-06-20 16:54:43 --> Language Class Initialized
INFO - 2017-06-20 16:54:43 --> Loader Class Initialized
INFO - 2017-06-20 16:54:43 --> Controller Class Initialized
INFO - 2017-06-20 16:54:43 --> Database Driver Class Initialized
INFO - 2017-06-20 16:54:43 --> Model Class Initialized
INFO - 2017-06-20 16:54:43 --> Helper loaded: form_helper
INFO - 2017-06-20 16:54:43 --> Helper loaded: url_helper
INFO - 2017-06-20 16:54:43 --> Model Class Initialized
INFO - 2017-06-20 16:54:43 --> Final output sent to browser
DEBUG - 2017-06-20 16:54:43 --> Total execution time: 0.1320
ERROR - 2017-06-20 17:35:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 17:35:33 --> Config Class Initialized
INFO - 2017-06-20 17:35:33 --> Hooks Class Initialized
DEBUG - 2017-06-20 17:35:33 --> UTF-8 Support Enabled
INFO - 2017-06-20 17:35:33 --> Utf8 Class Initialized
INFO - 2017-06-20 17:35:33 --> URI Class Initialized
INFO - 2017-06-20 17:35:33 --> Router Class Initialized
INFO - 2017-06-20 17:35:33 --> Output Class Initialized
INFO - 2017-06-20 17:35:33 --> Security Class Initialized
DEBUG - 2017-06-20 17:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 17:35:33 --> Input Class Initialized
INFO - 2017-06-20 17:35:33 --> Language Class Initialized
INFO - 2017-06-20 17:35:33 --> Loader Class Initialized
INFO - 2017-06-20 17:35:33 --> Controller Class Initialized
INFO - 2017-06-20 17:35:33 --> Database Driver Class Initialized
INFO - 2017-06-20 17:35:33 --> Model Class Initialized
INFO - 2017-06-20 17:35:33 --> Helper loaded: form_helper
INFO - 2017-06-20 17:35:33 --> Helper loaded: url_helper
INFO - 2017-06-20 17:35:33 --> Model Class Initialized
INFO - 2017-06-20 17:35:33 --> Final output sent to browser
DEBUG - 2017-06-20 17:35:33 --> Total execution time: 0.0605
ERROR - 2017-06-20 17:38:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 17:38:58 --> Config Class Initialized
INFO - 2017-06-20 17:38:58 --> Hooks Class Initialized
DEBUG - 2017-06-20 17:38:58 --> UTF-8 Support Enabled
INFO - 2017-06-20 17:38:58 --> Utf8 Class Initialized
INFO - 2017-06-20 17:38:58 --> URI Class Initialized
INFO - 2017-06-20 17:38:58 --> Router Class Initialized
INFO - 2017-06-20 17:38:58 --> Output Class Initialized
INFO - 2017-06-20 17:38:58 --> Security Class Initialized
DEBUG - 2017-06-20 17:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 17:38:58 --> Input Class Initialized
INFO - 2017-06-20 17:38:58 --> Language Class Initialized
INFO - 2017-06-20 17:38:58 --> Loader Class Initialized
INFO - 2017-06-20 17:38:58 --> Controller Class Initialized
INFO - 2017-06-20 17:38:59 --> Database Driver Class Initialized
INFO - 2017-06-20 17:38:59 --> Model Class Initialized
INFO - 2017-06-20 17:38:59 --> Helper loaded: form_helper
INFO - 2017-06-20 17:38:59 --> Helper loaded: url_helper
INFO - 2017-06-20 17:38:59 --> Model Class Initialized
INFO - 2017-06-20 17:38:59 --> Final output sent to browser
DEBUG - 2017-06-20 17:38:59 --> Total execution time: 0.0640
ERROR - 2017-06-20 17:38:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 17:38:59 --> Config Class Initialized
INFO - 2017-06-20 17:38:59 --> Hooks Class Initialized
DEBUG - 2017-06-20 17:38:59 --> UTF-8 Support Enabled
INFO - 2017-06-20 17:38:59 --> Utf8 Class Initialized
INFO - 2017-06-20 17:38:59 --> URI Class Initialized
INFO - 2017-06-20 17:38:59 --> Router Class Initialized
INFO - 2017-06-20 17:38:59 --> Output Class Initialized
INFO - 2017-06-20 17:38:59 --> Security Class Initialized
DEBUG - 2017-06-20 17:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 17:38:59 --> Input Class Initialized
INFO - 2017-06-20 17:38:59 --> Language Class Initialized
INFO - 2017-06-20 17:38:59 --> Loader Class Initialized
INFO - 2017-06-20 17:38:59 --> Controller Class Initialized
INFO - 2017-06-20 17:38:59 --> Database Driver Class Initialized
INFO - 2017-06-20 17:38:59 --> Model Class Initialized
INFO - 2017-06-20 17:38:59 --> Helper loaded: form_helper
INFO - 2017-06-20 17:38:59 --> Helper loaded: url_helper
INFO - 2017-06-20 17:38:59 --> Model Class Initialized
INFO - 2017-06-20 17:38:59 --> Final output sent to browser
DEBUG - 2017-06-20 17:38:59 --> Total execution time: 0.0460
ERROR - 2017-06-20 17:39:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 17:39:12 --> Config Class Initialized
INFO - 2017-06-20 17:39:12 --> Hooks Class Initialized
DEBUG - 2017-06-20 17:39:12 --> UTF-8 Support Enabled
INFO - 2017-06-20 17:39:12 --> Utf8 Class Initialized
INFO - 2017-06-20 17:39:12 --> URI Class Initialized
INFO - 2017-06-20 17:39:12 --> Router Class Initialized
INFO - 2017-06-20 17:39:12 --> Output Class Initialized
INFO - 2017-06-20 17:39:12 --> Security Class Initialized
DEBUG - 2017-06-20 17:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 17:39:12 --> Input Class Initialized
INFO - 2017-06-20 17:39:12 --> Language Class Initialized
INFO - 2017-06-20 17:39:12 --> Loader Class Initialized
INFO - 2017-06-20 17:39:12 --> Controller Class Initialized
INFO - 2017-06-20 17:39:12 --> Database Driver Class Initialized
INFO - 2017-06-20 17:39:12 --> Model Class Initialized
INFO - 2017-06-20 17:39:12 --> Helper loaded: form_helper
INFO - 2017-06-20 17:39:12 --> Helper loaded: url_helper
INFO - 2017-06-20 17:39:12 --> Model Class Initialized
INFO - 2017-06-20 17:39:12 --> Final output sent to browser
DEBUG - 2017-06-20 17:39:12 --> Total execution time: 0.0500
ERROR - 2017-06-20 17:40:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 17:40:15 --> Config Class Initialized
INFO - 2017-06-20 17:40:15 --> Hooks Class Initialized
DEBUG - 2017-06-20 17:40:15 --> UTF-8 Support Enabled
INFO - 2017-06-20 17:40:15 --> Utf8 Class Initialized
INFO - 2017-06-20 17:40:15 --> URI Class Initialized
INFO - 2017-06-20 17:40:15 --> Router Class Initialized
INFO - 2017-06-20 17:40:15 --> Output Class Initialized
INFO - 2017-06-20 17:40:15 --> Security Class Initialized
DEBUG - 2017-06-20 17:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 17:40:15 --> Input Class Initialized
INFO - 2017-06-20 17:40:15 --> Language Class Initialized
INFO - 2017-06-20 17:40:15 --> Loader Class Initialized
INFO - 2017-06-20 17:40:15 --> Controller Class Initialized
INFO - 2017-06-20 17:40:15 --> Database Driver Class Initialized
INFO - 2017-06-20 17:40:15 --> Model Class Initialized
INFO - 2017-06-20 17:40:15 --> Helper loaded: form_helper
INFO - 2017-06-20 17:40:15 --> Helper loaded: url_helper
INFO - 2017-06-20 17:40:15 --> Model Class Initialized
INFO - 2017-06-20 17:40:15 --> Final output sent to browser
DEBUG - 2017-06-20 17:40:15 --> Total execution time: 0.0525
ERROR - 2017-06-20 17:40:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 17:40:15 --> Config Class Initialized
INFO - 2017-06-20 17:40:15 --> Hooks Class Initialized
DEBUG - 2017-06-20 17:40:15 --> UTF-8 Support Enabled
INFO - 2017-06-20 17:40:15 --> Utf8 Class Initialized
INFO - 2017-06-20 17:40:15 --> URI Class Initialized
INFO - 2017-06-20 17:40:15 --> Router Class Initialized
INFO - 2017-06-20 17:40:15 --> Output Class Initialized
INFO - 2017-06-20 17:40:15 --> Security Class Initialized
DEBUG - 2017-06-20 17:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 17:40:15 --> Input Class Initialized
INFO - 2017-06-20 17:40:15 --> Language Class Initialized
INFO - 2017-06-20 17:40:15 --> Loader Class Initialized
INFO - 2017-06-20 17:40:15 --> Controller Class Initialized
INFO - 2017-06-20 17:40:15 --> Database Driver Class Initialized
INFO - 2017-06-20 17:40:15 --> Model Class Initialized
INFO - 2017-06-20 17:40:15 --> Helper loaded: form_helper
INFO - 2017-06-20 17:40:15 --> Helper loaded: url_helper
INFO - 2017-06-20 17:40:15 --> Model Class Initialized
INFO - 2017-06-20 17:40:15 --> Final output sent to browser
DEBUG - 2017-06-20 17:40:15 --> Total execution time: 0.0540
ERROR - 2017-06-20 17:40:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 17:40:17 --> Config Class Initialized
INFO - 2017-06-20 17:40:17 --> Hooks Class Initialized
DEBUG - 2017-06-20 17:40:17 --> UTF-8 Support Enabled
INFO - 2017-06-20 17:40:17 --> Utf8 Class Initialized
INFO - 2017-06-20 17:40:17 --> URI Class Initialized
INFO - 2017-06-20 17:40:17 --> Router Class Initialized
INFO - 2017-06-20 17:40:17 --> Output Class Initialized
INFO - 2017-06-20 17:40:17 --> Security Class Initialized
DEBUG - 2017-06-20 17:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 17:40:17 --> Input Class Initialized
INFO - 2017-06-20 17:40:17 --> Language Class Initialized
INFO - 2017-06-20 17:40:17 --> Loader Class Initialized
INFO - 2017-06-20 17:40:17 --> Controller Class Initialized
INFO - 2017-06-20 17:40:17 --> Database Driver Class Initialized
INFO - 2017-06-20 17:40:17 --> Model Class Initialized
INFO - 2017-06-20 17:40:17 --> Helper loaded: form_helper
INFO - 2017-06-20 17:40:17 --> Helper loaded: url_helper
INFO - 2017-06-20 17:40:17 --> Model Class Initialized
INFO - 2017-06-20 17:40:17 --> Final output sent to browser
DEBUG - 2017-06-20 17:40:17 --> Total execution time: 0.0480
ERROR - 2017-06-20 17:43:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 17:43:22 --> Config Class Initialized
INFO - 2017-06-20 17:43:22 --> Hooks Class Initialized
DEBUG - 2017-06-20 17:43:22 --> UTF-8 Support Enabled
INFO - 2017-06-20 17:43:22 --> Utf8 Class Initialized
INFO - 2017-06-20 17:43:22 --> URI Class Initialized
INFO - 2017-06-20 17:43:22 --> Router Class Initialized
INFO - 2017-06-20 17:43:22 --> Output Class Initialized
INFO - 2017-06-20 17:43:22 --> Security Class Initialized
DEBUG - 2017-06-20 17:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 17:43:22 --> Input Class Initialized
INFO - 2017-06-20 17:43:22 --> Language Class Initialized
INFO - 2017-06-20 17:43:22 --> Loader Class Initialized
INFO - 2017-06-20 17:43:22 --> Controller Class Initialized
INFO - 2017-06-20 17:43:22 --> Database Driver Class Initialized
INFO - 2017-06-20 17:43:22 --> Model Class Initialized
INFO - 2017-06-20 17:43:22 --> Helper loaded: form_helper
INFO - 2017-06-20 17:43:22 --> Helper loaded: url_helper
INFO - 2017-06-20 17:43:22 --> Model Class Initialized
INFO - 2017-06-20 17:43:22 --> Final output sent to browser
DEBUG - 2017-06-20 17:43:22 --> Total execution time: 0.0680
ERROR - 2017-06-20 17:43:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 17:43:23 --> Config Class Initialized
INFO - 2017-06-20 17:43:23 --> Hooks Class Initialized
DEBUG - 2017-06-20 17:43:23 --> UTF-8 Support Enabled
INFO - 2017-06-20 17:43:23 --> Utf8 Class Initialized
INFO - 2017-06-20 17:43:23 --> URI Class Initialized
INFO - 2017-06-20 17:43:23 --> Router Class Initialized
INFO - 2017-06-20 17:43:23 --> Output Class Initialized
INFO - 2017-06-20 17:43:23 --> Security Class Initialized
DEBUG - 2017-06-20 17:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 17:43:23 --> Input Class Initialized
INFO - 2017-06-20 17:43:23 --> Language Class Initialized
INFO - 2017-06-20 17:43:23 --> Loader Class Initialized
INFO - 2017-06-20 17:43:23 --> Controller Class Initialized
INFO - 2017-06-20 17:43:23 --> Database Driver Class Initialized
INFO - 2017-06-20 17:43:23 --> Model Class Initialized
INFO - 2017-06-20 17:43:23 --> Helper loaded: form_helper
INFO - 2017-06-20 17:43:23 --> Helper loaded: url_helper
INFO - 2017-06-20 17:43:23 --> Model Class Initialized
INFO - 2017-06-20 17:43:23 --> Final output sent to browser
DEBUG - 2017-06-20 17:43:23 --> Total execution time: 0.0450
ERROR - 2017-06-20 17:43:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 17:43:25 --> Config Class Initialized
INFO - 2017-06-20 17:43:25 --> Hooks Class Initialized
DEBUG - 2017-06-20 17:43:25 --> UTF-8 Support Enabled
INFO - 2017-06-20 17:43:25 --> Utf8 Class Initialized
INFO - 2017-06-20 17:43:25 --> URI Class Initialized
INFO - 2017-06-20 17:43:25 --> Router Class Initialized
INFO - 2017-06-20 17:43:25 --> Output Class Initialized
INFO - 2017-06-20 17:43:25 --> Security Class Initialized
DEBUG - 2017-06-20 17:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 17:43:25 --> Input Class Initialized
INFO - 2017-06-20 17:43:25 --> Language Class Initialized
INFO - 2017-06-20 17:43:25 --> Loader Class Initialized
INFO - 2017-06-20 17:43:25 --> Controller Class Initialized
INFO - 2017-06-20 17:43:25 --> Database Driver Class Initialized
INFO - 2017-06-20 17:43:25 --> Model Class Initialized
INFO - 2017-06-20 17:43:25 --> Helper loaded: form_helper
INFO - 2017-06-20 17:43:25 --> Helper loaded: url_helper
INFO - 2017-06-20 17:43:25 --> Model Class Initialized
INFO - 2017-06-20 17:43:25 --> Final output sent to browser
DEBUG - 2017-06-20 17:43:25 --> Total execution time: 0.0610
ERROR - 2017-06-20 17:47:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 17:47:59 --> Config Class Initialized
INFO - 2017-06-20 17:47:59 --> Hooks Class Initialized
DEBUG - 2017-06-20 17:47:59 --> UTF-8 Support Enabled
INFO - 2017-06-20 17:47:59 --> Utf8 Class Initialized
INFO - 2017-06-20 17:47:59 --> URI Class Initialized
INFO - 2017-06-20 17:47:59 --> Router Class Initialized
INFO - 2017-06-20 17:47:59 --> Output Class Initialized
INFO - 2017-06-20 17:47:59 --> Security Class Initialized
DEBUG - 2017-06-20 17:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 17:47:59 --> Input Class Initialized
INFO - 2017-06-20 17:47:59 --> Language Class Initialized
INFO - 2017-06-20 17:47:59 --> Loader Class Initialized
INFO - 2017-06-20 17:47:59 --> Controller Class Initialized
INFO - 2017-06-20 17:47:59 --> Database Driver Class Initialized
INFO - 2017-06-20 17:47:59 --> Model Class Initialized
INFO - 2017-06-20 17:47:59 --> Helper loaded: form_helper
INFO - 2017-06-20 17:47:59 --> Helper loaded: url_helper
INFO - 2017-06-20 17:47:59 --> Model Class Initialized
INFO - 2017-06-20 17:47:59 --> Final output sent to browser
DEBUG - 2017-06-20 17:47:59 --> Total execution time: 0.0610
ERROR - 2017-06-20 17:47:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 17:47:59 --> Config Class Initialized
INFO - 2017-06-20 17:47:59 --> Hooks Class Initialized
DEBUG - 2017-06-20 17:47:59 --> UTF-8 Support Enabled
INFO - 2017-06-20 17:47:59 --> Utf8 Class Initialized
INFO - 2017-06-20 17:47:59 --> URI Class Initialized
INFO - 2017-06-20 17:47:59 --> Router Class Initialized
INFO - 2017-06-20 17:47:59 --> Output Class Initialized
INFO - 2017-06-20 17:47:59 --> Security Class Initialized
DEBUG - 2017-06-20 17:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 17:47:59 --> Input Class Initialized
INFO - 2017-06-20 17:47:59 --> Language Class Initialized
INFO - 2017-06-20 17:47:59 --> Loader Class Initialized
INFO - 2017-06-20 17:47:59 --> Controller Class Initialized
INFO - 2017-06-20 17:47:59 --> Database Driver Class Initialized
INFO - 2017-06-20 17:47:59 --> Model Class Initialized
INFO - 2017-06-20 17:47:59 --> Helper loaded: form_helper
INFO - 2017-06-20 17:47:59 --> Helper loaded: url_helper
INFO - 2017-06-20 17:47:59 --> Model Class Initialized
INFO - 2017-06-20 17:47:59 --> Final output sent to browser
DEBUG - 2017-06-20 17:47:59 --> Total execution time: 0.0460
ERROR - 2017-06-20 17:48:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 17:48:01 --> Config Class Initialized
INFO - 2017-06-20 17:48:01 --> Hooks Class Initialized
DEBUG - 2017-06-20 17:48:01 --> UTF-8 Support Enabled
INFO - 2017-06-20 17:48:01 --> Utf8 Class Initialized
INFO - 2017-06-20 17:48:01 --> URI Class Initialized
INFO - 2017-06-20 17:48:01 --> Router Class Initialized
INFO - 2017-06-20 17:48:01 --> Output Class Initialized
INFO - 2017-06-20 17:48:01 --> Security Class Initialized
DEBUG - 2017-06-20 17:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 17:48:01 --> Input Class Initialized
INFO - 2017-06-20 17:48:01 --> Language Class Initialized
INFO - 2017-06-20 17:48:01 --> Loader Class Initialized
INFO - 2017-06-20 17:48:01 --> Controller Class Initialized
INFO - 2017-06-20 17:48:01 --> Database Driver Class Initialized
INFO - 2017-06-20 17:48:01 --> Model Class Initialized
INFO - 2017-06-20 17:48:01 --> Helper loaded: form_helper
INFO - 2017-06-20 17:48:01 --> Helper loaded: url_helper
INFO - 2017-06-20 17:48:01 --> Model Class Initialized
INFO - 2017-06-20 17:48:01 --> Final output sent to browser
DEBUG - 2017-06-20 17:48:01 --> Total execution time: 0.0560
ERROR - 2017-06-20 18:00:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:00:55 --> Config Class Initialized
INFO - 2017-06-20 18:00:55 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:00:55 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:00:55 --> Utf8 Class Initialized
INFO - 2017-06-20 18:00:55 --> URI Class Initialized
INFO - 2017-06-20 18:00:55 --> Router Class Initialized
INFO - 2017-06-20 18:00:55 --> Output Class Initialized
INFO - 2017-06-20 18:00:55 --> Security Class Initialized
DEBUG - 2017-06-20 18:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:00:55 --> Input Class Initialized
INFO - 2017-06-20 18:00:55 --> Language Class Initialized
INFO - 2017-06-20 18:00:55 --> Loader Class Initialized
INFO - 2017-06-20 18:00:55 --> Controller Class Initialized
INFO - 2017-06-20 18:00:55 --> Database Driver Class Initialized
INFO - 2017-06-20 18:00:55 --> Model Class Initialized
INFO - 2017-06-20 18:00:55 --> Helper loaded: form_helper
INFO - 2017-06-20 18:00:55 --> Helper loaded: url_helper
INFO - 2017-06-20 18:00:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-20 18:00:55 --> Model Class Initialized
INFO - 2017-06-20 18:00:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\users.php
INFO - 2017-06-20 18:00:55 --> Final output sent to browser
DEBUG - 2017-06-20 18:00:55 --> Total execution time: 0.1040
ERROR - 2017-06-20 18:00:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:00:57 --> Config Class Initialized
INFO - 2017-06-20 18:00:57 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:00:57 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:00:57 --> Utf8 Class Initialized
INFO - 2017-06-20 18:00:57 --> URI Class Initialized
INFO - 2017-06-20 18:00:57 --> Router Class Initialized
INFO - 2017-06-20 18:00:57 --> Output Class Initialized
INFO - 2017-06-20 18:00:57 --> Security Class Initialized
DEBUG - 2017-06-20 18:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:00:57 --> Input Class Initialized
INFO - 2017-06-20 18:00:57 --> Language Class Initialized
INFO - 2017-06-20 18:00:57 --> Loader Class Initialized
INFO - 2017-06-20 18:00:57 --> Controller Class Initialized
INFO - 2017-06-20 18:00:57 --> Database Driver Class Initialized
INFO - 2017-06-20 18:00:57 --> Model Class Initialized
INFO - 2017-06-20 18:00:57 --> Helper loaded: form_helper
INFO - 2017-06-20 18:00:57 --> Helper loaded: url_helper
ERROR - 2017-06-20 18:00:57 --> Severity: Notice --> Undefined index: mystage C:\xampp\htdocs\mystage\application\views\header.php 82
ERROR - 2017-06-20 18:00:57 --> Severity: Notice --> Undefined index: mystage C:\xampp\htdocs\mystage\application\views\header.php 83
INFO - 2017-06-20 18:00:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-20 18:00:57 --> Model Class Initialized
INFO - 2017-06-20 18:00:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-20 18:00:57 --> Final output sent to browser
DEBUG - 2017-06-20 18:00:57 --> Total execution time: 0.0640
ERROR - 2017-06-20 18:00:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:00:57 --> Config Class Initialized
INFO - 2017-06-20 18:00:57 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:00:57 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:00:57 --> Utf8 Class Initialized
ERROR - 2017-06-20 18:00:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:00:57 --> Config Class Initialized
INFO - 2017-06-20 18:00:57 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:00:57 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:00:57 --> Utf8 Class Initialized
ERROR - 2017-06-20 18:00:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:00:58 --> Config Class Initialized
INFO - 2017-06-20 18:00:58 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:00:58 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:00:58 --> Utf8 Class Initialized
INFO - 2017-06-20 18:00:58 --> URI Class Initialized
DEBUG - 2017-06-20 18:00:58 --> No URI present. Default controller set.
INFO - 2017-06-20 18:00:58 --> Router Class Initialized
INFO - 2017-06-20 18:00:58 --> Output Class Initialized
INFO - 2017-06-20 18:00:58 --> Security Class Initialized
DEBUG - 2017-06-20 18:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:00:58 --> Input Class Initialized
INFO - 2017-06-20 18:00:58 --> Language Class Initialized
INFO - 2017-06-20 18:00:58 --> Loader Class Initialized
INFO - 2017-06-20 18:00:58 --> Controller Class Initialized
INFO - 2017-06-20 18:00:58 --> Database Driver Class Initialized
INFO - 2017-06-20 18:00:58 --> Model Class Initialized
INFO - 2017-06-20 18:00:58 --> Helper loaded: form_helper
INFO - 2017-06-20 18:00:58 --> Helper loaded: url_helper
INFO - 2017-06-20 18:00:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-06-20 18:00:58 --> Final output sent to browser
DEBUG - 2017-06-20 18:00:58 --> Total execution time: 0.0520
ERROR - 2017-06-20 18:01:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:01:00 --> Config Class Initialized
INFO - 2017-06-20 18:01:00 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:01:00 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:01:00 --> Utf8 Class Initialized
INFO - 2017-06-20 18:01:00 --> URI Class Initialized
INFO - 2017-06-20 18:01:00 --> Router Class Initialized
INFO - 2017-06-20 18:01:00 --> Output Class Initialized
INFO - 2017-06-20 18:01:00 --> Security Class Initialized
DEBUG - 2017-06-20 18:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:01:00 --> Input Class Initialized
INFO - 2017-06-20 18:01:00 --> Language Class Initialized
INFO - 2017-06-20 18:01:00 --> Loader Class Initialized
INFO - 2017-06-20 18:01:00 --> Controller Class Initialized
INFO - 2017-06-20 18:01:00 --> Database Driver Class Initialized
INFO - 2017-06-20 18:01:00 --> Model Class Initialized
INFO - 2017-06-20 18:01:00 --> Helper loaded: form_helper
INFO - 2017-06-20 18:01:00 --> Helper loaded: url_helper
INFO - 2017-06-20 18:01:00 --> Model Class Initialized
ERROR - 2017-06-20 18:01:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:01:00 --> Config Class Initialized
INFO - 2017-06-20 18:01:00 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:01:00 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:01:00 --> Utf8 Class Initialized
INFO - 2017-06-20 18:01:00 --> URI Class Initialized
INFO - 2017-06-20 18:01:00 --> Router Class Initialized
INFO - 2017-06-20 18:01:00 --> Output Class Initialized
INFO - 2017-06-20 18:01:00 --> Security Class Initialized
DEBUG - 2017-06-20 18:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:01:00 --> Input Class Initialized
INFO - 2017-06-20 18:01:00 --> Language Class Initialized
INFO - 2017-06-20 18:01:00 --> Loader Class Initialized
INFO - 2017-06-20 18:01:00 --> Controller Class Initialized
INFO - 2017-06-20 18:01:00 --> Database Driver Class Initialized
INFO - 2017-06-20 18:01:00 --> Model Class Initialized
INFO - 2017-06-20 18:01:00 --> Helper loaded: form_helper
INFO - 2017-06-20 18:01:00 --> Helper loaded: url_helper
INFO - 2017-06-20 18:01:00 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-20 18:01:00 --> Model Class Initialized
INFO - 2017-06-20 18:01:00 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-20 18:01:00 --> Final output sent to browser
DEBUG - 2017-06-20 18:01:00 --> Total execution time: 0.0690
ERROR - 2017-06-20 18:01:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:01:04 --> Config Class Initialized
INFO - 2017-06-20 18:01:04 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:01:04 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:01:04 --> Utf8 Class Initialized
INFO - 2017-06-20 18:01:04 --> URI Class Initialized
INFO - 2017-06-20 18:01:04 --> Router Class Initialized
INFO - 2017-06-20 18:01:04 --> Output Class Initialized
INFO - 2017-06-20 18:01:04 --> Security Class Initialized
DEBUG - 2017-06-20 18:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:01:04 --> Input Class Initialized
INFO - 2017-06-20 18:01:04 --> Language Class Initialized
INFO - 2017-06-20 18:01:04 --> Loader Class Initialized
INFO - 2017-06-20 18:01:04 --> Controller Class Initialized
INFO - 2017-06-20 18:01:04 --> Database Driver Class Initialized
INFO - 2017-06-20 18:01:04 --> Model Class Initialized
INFO - 2017-06-20 18:01:04 --> Helper loaded: form_helper
INFO - 2017-06-20 18:01:04 --> Helper loaded: url_helper
INFO - 2017-06-20 18:01:04 --> Model Class Initialized
INFO - 2017-06-20 18:01:04 --> Final output sent to browser
DEBUG - 2017-06-20 18:01:04 --> Total execution time: 0.0595
ERROR - 2017-06-20 18:01:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:01:04 --> Config Class Initialized
INFO - 2017-06-20 18:01:04 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:01:04 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:01:04 --> Utf8 Class Initialized
INFO - 2017-06-20 18:01:04 --> URI Class Initialized
INFO - 2017-06-20 18:01:04 --> Router Class Initialized
INFO - 2017-06-20 18:01:04 --> Output Class Initialized
INFO - 2017-06-20 18:01:04 --> Security Class Initialized
DEBUG - 2017-06-20 18:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:01:04 --> Input Class Initialized
INFO - 2017-06-20 18:01:04 --> Language Class Initialized
INFO - 2017-06-20 18:01:04 --> Loader Class Initialized
INFO - 2017-06-20 18:01:04 --> Controller Class Initialized
INFO - 2017-06-20 18:01:04 --> Database Driver Class Initialized
INFO - 2017-06-20 18:01:04 --> Model Class Initialized
INFO - 2017-06-20 18:01:04 --> Helper loaded: form_helper
INFO - 2017-06-20 18:01:04 --> Helper loaded: url_helper
INFO - 2017-06-20 18:01:04 --> Model Class Initialized
INFO - 2017-06-20 18:01:04 --> Final output sent to browser
DEBUG - 2017-06-20 18:01:04 --> Total execution time: 0.0580
ERROR - 2017-06-20 18:01:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:01:25 --> Config Class Initialized
INFO - 2017-06-20 18:01:25 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:01:25 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:01:25 --> Utf8 Class Initialized
INFO - 2017-06-20 18:01:25 --> URI Class Initialized
INFO - 2017-06-20 18:01:25 --> Router Class Initialized
INFO - 2017-06-20 18:01:25 --> Output Class Initialized
INFO - 2017-06-20 18:01:25 --> Security Class Initialized
DEBUG - 2017-06-20 18:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:01:25 --> Input Class Initialized
INFO - 2017-06-20 18:01:25 --> Language Class Initialized
INFO - 2017-06-20 18:01:25 --> Loader Class Initialized
INFO - 2017-06-20 18:01:25 --> Controller Class Initialized
INFO - 2017-06-20 18:01:25 --> Database Driver Class Initialized
INFO - 2017-06-20 18:01:25 --> Model Class Initialized
INFO - 2017-06-20 18:01:25 --> Helper loaded: form_helper
INFO - 2017-06-20 18:01:25 --> Helper loaded: url_helper
INFO - 2017-06-20 18:01:25 --> Model Class Initialized
INFO - 2017-06-20 18:01:25 --> Final output sent to browser
DEBUG - 2017-06-20 18:01:25 --> Total execution time: 0.0550
ERROR - 2017-06-20 18:01:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:01:25 --> Config Class Initialized
INFO - 2017-06-20 18:01:25 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:01:25 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:01:25 --> Utf8 Class Initialized
INFO - 2017-06-20 18:01:25 --> URI Class Initialized
INFO - 2017-06-20 18:01:25 --> Router Class Initialized
INFO - 2017-06-20 18:01:25 --> Output Class Initialized
INFO - 2017-06-20 18:01:25 --> Security Class Initialized
DEBUG - 2017-06-20 18:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:01:25 --> Input Class Initialized
INFO - 2017-06-20 18:01:25 --> Language Class Initialized
INFO - 2017-06-20 18:01:25 --> Loader Class Initialized
INFO - 2017-06-20 18:01:25 --> Controller Class Initialized
INFO - 2017-06-20 18:01:25 --> Database Driver Class Initialized
INFO - 2017-06-20 18:01:25 --> Model Class Initialized
INFO - 2017-06-20 18:01:25 --> Helper loaded: form_helper
INFO - 2017-06-20 18:01:25 --> Helper loaded: url_helper
INFO - 2017-06-20 18:01:25 --> Model Class Initialized
INFO - 2017-06-20 18:01:25 --> Final output sent to browser
DEBUG - 2017-06-20 18:01:25 --> Total execution time: 0.1050
ERROR - 2017-06-20 18:01:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:01:25 --> Config Class Initialized
INFO - 2017-06-20 18:01:25 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:01:25 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:01:25 --> Utf8 Class Initialized
INFO - 2017-06-20 18:01:25 --> URI Class Initialized
INFO - 2017-06-20 18:01:25 --> Router Class Initialized
INFO - 2017-06-20 18:01:25 --> Output Class Initialized
INFO - 2017-06-20 18:01:25 --> Security Class Initialized
DEBUG - 2017-06-20 18:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:01:25 --> Input Class Initialized
INFO - 2017-06-20 18:01:25 --> Language Class Initialized
INFO - 2017-06-20 18:01:25 --> Loader Class Initialized
INFO - 2017-06-20 18:01:25 --> Controller Class Initialized
INFO - 2017-06-20 18:01:25 --> Database Driver Class Initialized
INFO - 2017-06-20 18:01:25 --> Model Class Initialized
INFO - 2017-06-20 18:01:25 --> Helper loaded: form_helper
INFO - 2017-06-20 18:01:25 --> Helper loaded: url_helper
INFO - 2017-06-20 18:01:25 --> Model Class Initialized
INFO - 2017-06-20 18:01:25 --> Final output sent to browser
DEBUG - 2017-06-20 18:01:25 --> Total execution time: 0.0485
ERROR - 2017-06-20 18:05:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:05:02 --> Config Class Initialized
INFO - 2017-06-20 18:05:02 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:05:02 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:05:02 --> Utf8 Class Initialized
INFO - 2017-06-20 18:05:02 --> URI Class Initialized
INFO - 2017-06-20 18:05:02 --> Router Class Initialized
INFO - 2017-06-20 18:05:02 --> Output Class Initialized
INFO - 2017-06-20 18:05:02 --> Security Class Initialized
DEBUG - 2017-06-20 18:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:05:02 --> Input Class Initialized
INFO - 2017-06-20 18:05:02 --> Language Class Initialized
INFO - 2017-06-20 18:05:02 --> Loader Class Initialized
INFO - 2017-06-20 18:05:02 --> Controller Class Initialized
INFO - 2017-06-20 18:05:02 --> Database Driver Class Initialized
INFO - 2017-06-20 18:05:02 --> Model Class Initialized
INFO - 2017-06-20 18:05:02 --> Helper loaded: form_helper
INFO - 2017-06-20 18:05:02 --> Helper loaded: url_helper
INFO - 2017-06-20 18:05:02 --> Model Class Initialized
INFO - 2017-06-20 18:05:02 --> Final output sent to browser
DEBUG - 2017-06-20 18:05:02 --> Total execution time: 0.0620
ERROR - 2017-06-20 18:05:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:05:02 --> Config Class Initialized
INFO - 2017-06-20 18:05:02 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:05:02 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:05:02 --> Utf8 Class Initialized
INFO - 2017-06-20 18:05:02 --> URI Class Initialized
INFO - 2017-06-20 18:05:02 --> Router Class Initialized
INFO - 2017-06-20 18:05:02 --> Output Class Initialized
INFO - 2017-06-20 18:05:02 --> Security Class Initialized
DEBUG - 2017-06-20 18:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:05:02 --> Input Class Initialized
INFO - 2017-06-20 18:05:02 --> Language Class Initialized
INFO - 2017-06-20 18:05:02 --> Loader Class Initialized
INFO - 2017-06-20 18:05:02 --> Controller Class Initialized
INFO - 2017-06-20 18:05:02 --> Database Driver Class Initialized
INFO - 2017-06-20 18:05:02 --> Model Class Initialized
INFO - 2017-06-20 18:05:02 --> Helper loaded: form_helper
INFO - 2017-06-20 18:05:02 --> Helper loaded: url_helper
INFO - 2017-06-20 18:05:02 --> Model Class Initialized
INFO - 2017-06-20 18:05:02 --> Final output sent to browser
DEBUG - 2017-06-20 18:05:02 --> Total execution time: 0.0460
ERROR - 2017-06-20 18:06:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:06:48 --> Config Class Initialized
INFO - 2017-06-20 18:06:48 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:06:48 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:06:48 --> Utf8 Class Initialized
INFO - 2017-06-20 18:06:48 --> URI Class Initialized
INFO - 2017-06-20 18:06:48 --> Router Class Initialized
INFO - 2017-06-20 18:06:48 --> Output Class Initialized
INFO - 2017-06-20 18:06:48 --> Security Class Initialized
DEBUG - 2017-06-20 18:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:06:48 --> Input Class Initialized
INFO - 2017-06-20 18:06:48 --> Language Class Initialized
INFO - 2017-06-20 18:06:48 --> Loader Class Initialized
INFO - 2017-06-20 18:06:48 --> Controller Class Initialized
INFO - 2017-06-20 18:06:48 --> Database Driver Class Initialized
INFO - 2017-06-20 18:06:48 --> Model Class Initialized
INFO - 2017-06-20 18:06:48 --> Helper loaded: form_helper
INFO - 2017-06-20 18:06:48 --> Helper loaded: url_helper
INFO - 2017-06-20 18:06:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-20 18:06:48 --> Model Class Initialized
INFO - 2017-06-20 18:06:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-20 18:06:48 --> Final output sent to browser
DEBUG - 2017-06-20 18:06:48 --> Total execution time: 0.1060
ERROR - 2017-06-20 18:07:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:07:01 --> Config Class Initialized
INFO - 2017-06-20 18:07:01 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:07:01 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:07:01 --> Utf8 Class Initialized
INFO - 2017-06-20 18:07:01 --> URI Class Initialized
INFO - 2017-06-20 18:07:01 --> Router Class Initialized
INFO - 2017-06-20 18:07:01 --> Output Class Initialized
INFO - 2017-06-20 18:07:01 --> Security Class Initialized
DEBUG - 2017-06-20 18:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:07:01 --> Input Class Initialized
INFO - 2017-06-20 18:07:01 --> Language Class Initialized
INFO - 2017-06-20 18:07:01 --> Loader Class Initialized
INFO - 2017-06-20 18:07:01 --> Controller Class Initialized
INFO - 2017-06-20 18:07:01 --> Database Driver Class Initialized
INFO - 2017-06-20 18:07:01 --> Model Class Initialized
INFO - 2017-06-20 18:07:01 --> Helper loaded: form_helper
INFO - 2017-06-20 18:07:01 --> Helper loaded: url_helper
INFO - 2017-06-20 18:07:01 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-20 18:07:01 --> Model Class Initialized
INFO - 2017-06-20 18:07:01 --> File loaded: C:\xampp\htdocs\mystage\application\views\purchase.php
INFO - 2017-06-20 18:07:01 --> Final output sent to browser
DEBUG - 2017-06-20 18:07:01 --> Total execution time: 0.0780
ERROR - 2017-06-20 18:07:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:07:14 --> Config Class Initialized
INFO - 2017-06-20 18:07:14 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:07:14 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:07:14 --> Utf8 Class Initialized
INFO - 2017-06-20 18:07:14 --> URI Class Initialized
INFO - 2017-06-20 18:07:14 --> Router Class Initialized
INFO - 2017-06-20 18:07:14 --> Output Class Initialized
INFO - 2017-06-20 18:07:14 --> Security Class Initialized
DEBUG - 2017-06-20 18:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:07:14 --> Input Class Initialized
INFO - 2017-06-20 18:07:14 --> Language Class Initialized
INFO - 2017-06-20 18:07:14 --> Loader Class Initialized
INFO - 2017-06-20 18:07:14 --> Controller Class Initialized
INFO - 2017-06-20 18:07:14 --> Database Driver Class Initialized
INFO - 2017-06-20 18:07:14 --> Model Class Initialized
INFO - 2017-06-20 18:07:14 --> Helper loaded: form_helper
INFO - 2017-06-20 18:07:14 --> Helper loaded: url_helper
INFO - 2017-06-20 18:07:14 --> Model Class Initialized
INFO - 2017-06-20 18:07:14 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-20 18:07:14 --> File loaded: C:\xampp\htdocs\mystage\application\views\purchase.php
INFO - 2017-06-20 18:07:14 --> Final output sent to browser
DEBUG - 2017-06-20 18:07:14 --> Total execution time: 0.3760
ERROR - 2017-06-20 18:07:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:07:26 --> Config Class Initialized
INFO - 2017-06-20 18:07:26 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:07:26 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:07:26 --> Utf8 Class Initialized
INFO - 2017-06-20 18:07:26 --> URI Class Initialized
INFO - 2017-06-20 18:07:26 --> Router Class Initialized
INFO - 2017-06-20 18:07:26 --> Output Class Initialized
INFO - 2017-06-20 18:07:26 --> Security Class Initialized
DEBUG - 2017-06-20 18:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:07:26 --> Input Class Initialized
INFO - 2017-06-20 18:07:26 --> Language Class Initialized
INFO - 2017-06-20 18:07:26 --> Loader Class Initialized
INFO - 2017-06-20 18:07:26 --> Controller Class Initialized
INFO - 2017-06-20 18:07:26 --> Database Driver Class Initialized
INFO - 2017-06-20 18:07:26 --> Model Class Initialized
INFO - 2017-06-20 18:07:26 --> Helper loaded: form_helper
INFO - 2017-06-20 18:07:26 --> Helper loaded: url_helper
INFO - 2017-06-20 18:07:26 --> Model Class Initialized
INFO - 2017-06-20 18:07:26 --> Final output sent to browser
DEBUG - 2017-06-20 18:07:26 --> Total execution time: 0.0570
ERROR - 2017-06-20 18:07:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:07:26 --> Config Class Initialized
INFO - 2017-06-20 18:07:26 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:07:26 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:07:26 --> Utf8 Class Initialized
INFO - 2017-06-20 18:07:26 --> URI Class Initialized
INFO - 2017-06-20 18:07:26 --> Router Class Initialized
INFO - 2017-06-20 18:07:26 --> Output Class Initialized
INFO - 2017-06-20 18:07:26 --> Security Class Initialized
DEBUG - 2017-06-20 18:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:07:26 --> Input Class Initialized
INFO - 2017-06-20 18:07:26 --> Language Class Initialized
INFO - 2017-06-20 18:07:26 --> Loader Class Initialized
INFO - 2017-06-20 18:07:26 --> Controller Class Initialized
INFO - 2017-06-20 18:07:26 --> Database Driver Class Initialized
INFO - 2017-06-20 18:07:26 --> Model Class Initialized
INFO - 2017-06-20 18:07:26 --> Helper loaded: form_helper
INFO - 2017-06-20 18:07:26 --> Helper loaded: url_helper
INFO - 2017-06-20 18:07:26 --> Model Class Initialized
INFO - 2017-06-20 18:07:26 --> Final output sent to browser
DEBUG - 2017-06-20 18:07:26 --> Total execution time: 0.0470
ERROR - 2017-06-20 18:07:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:07:48 --> Config Class Initialized
INFO - 2017-06-20 18:07:48 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:07:48 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:07:48 --> Utf8 Class Initialized
INFO - 2017-06-20 18:07:48 --> URI Class Initialized
INFO - 2017-06-20 18:07:48 --> Router Class Initialized
INFO - 2017-06-20 18:07:48 --> Output Class Initialized
INFO - 2017-06-20 18:07:48 --> Security Class Initialized
DEBUG - 2017-06-20 18:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:07:48 --> Input Class Initialized
INFO - 2017-06-20 18:07:48 --> Language Class Initialized
INFO - 2017-06-20 18:07:48 --> Loader Class Initialized
INFO - 2017-06-20 18:07:48 --> Controller Class Initialized
INFO - 2017-06-20 18:07:48 --> Database Driver Class Initialized
INFO - 2017-06-20 18:07:48 --> Model Class Initialized
INFO - 2017-06-20 18:07:48 --> Helper loaded: form_helper
INFO - 2017-06-20 18:07:48 --> Helper loaded: url_helper
INFO - 2017-06-20 18:07:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-20 18:07:48 --> Model Class Initialized
INFO - 2017-06-20 18:07:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\purchase.php
INFO - 2017-06-20 18:07:48 --> Final output sent to browser
DEBUG - 2017-06-20 18:07:48 --> Total execution time: 0.0840
ERROR - 2017-06-20 18:07:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:07:57 --> Config Class Initialized
INFO - 2017-06-20 18:07:57 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:07:57 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:07:57 --> Utf8 Class Initialized
INFO - 2017-06-20 18:07:57 --> URI Class Initialized
INFO - 2017-06-20 18:07:57 --> Router Class Initialized
INFO - 2017-06-20 18:07:57 --> Output Class Initialized
INFO - 2017-06-20 18:07:57 --> Security Class Initialized
DEBUG - 2017-06-20 18:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:07:57 --> Input Class Initialized
INFO - 2017-06-20 18:07:57 --> Language Class Initialized
INFO - 2017-06-20 18:07:57 --> Loader Class Initialized
INFO - 2017-06-20 18:07:57 --> Controller Class Initialized
INFO - 2017-06-20 18:07:57 --> Database Driver Class Initialized
INFO - 2017-06-20 18:07:57 --> Model Class Initialized
INFO - 2017-06-20 18:07:57 --> Helper loaded: form_helper
INFO - 2017-06-20 18:07:57 --> Helper loaded: url_helper
INFO - 2017-06-20 18:07:57 --> Model Class Initialized
INFO - 2017-06-20 18:07:57 --> Final output sent to browser
DEBUG - 2017-06-20 18:07:57 --> Total execution time: 0.0470
ERROR - 2017-06-20 18:07:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:07:57 --> Config Class Initialized
INFO - 2017-06-20 18:07:57 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:07:57 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:07:57 --> Utf8 Class Initialized
INFO - 2017-06-20 18:07:57 --> URI Class Initialized
INFO - 2017-06-20 18:07:57 --> Router Class Initialized
INFO - 2017-06-20 18:07:57 --> Output Class Initialized
INFO - 2017-06-20 18:07:57 --> Security Class Initialized
DEBUG - 2017-06-20 18:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:07:57 --> Input Class Initialized
INFO - 2017-06-20 18:07:57 --> Language Class Initialized
INFO - 2017-06-20 18:07:57 --> Loader Class Initialized
INFO - 2017-06-20 18:07:57 --> Controller Class Initialized
INFO - 2017-06-20 18:07:57 --> Database Driver Class Initialized
INFO - 2017-06-20 18:07:57 --> Model Class Initialized
INFO - 2017-06-20 18:07:57 --> Helper loaded: form_helper
INFO - 2017-06-20 18:07:57 --> Helper loaded: url_helper
INFO - 2017-06-20 18:07:57 --> Model Class Initialized
INFO - 2017-06-20 18:07:57 --> Final output sent to browser
DEBUG - 2017-06-20 18:07:57 --> Total execution time: 0.0490
ERROR - 2017-06-20 18:08:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:08:39 --> Config Class Initialized
INFO - 2017-06-20 18:08:39 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:08:39 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:08:39 --> Utf8 Class Initialized
INFO - 2017-06-20 18:08:39 --> URI Class Initialized
INFO - 2017-06-20 18:08:39 --> Router Class Initialized
INFO - 2017-06-20 18:08:39 --> Output Class Initialized
INFO - 2017-06-20 18:08:39 --> Security Class Initialized
DEBUG - 2017-06-20 18:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:08:39 --> Input Class Initialized
INFO - 2017-06-20 18:08:39 --> Language Class Initialized
INFO - 2017-06-20 18:08:39 --> Loader Class Initialized
INFO - 2017-06-20 18:08:39 --> Controller Class Initialized
INFO - 2017-06-20 18:08:39 --> Database Driver Class Initialized
INFO - 2017-06-20 18:08:39 --> Model Class Initialized
INFO - 2017-06-20 18:08:39 --> Helper loaded: form_helper
INFO - 2017-06-20 18:08:39 --> Helper loaded: url_helper
INFO - 2017-06-20 18:08:39 --> Model Class Initialized
INFO - 2017-06-20 18:08:39 --> Final output sent to browser
DEBUG - 2017-06-20 18:08:39 --> Total execution time: 0.0590
ERROR - 2017-06-20 18:08:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:08:39 --> Config Class Initialized
INFO - 2017-06-20 18:08:39 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:08:39 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:08:39 --> Utf8 Class Initialized
INFO - 2017-06-20 18:08:39 --> URI Class Initialized
INFO - 2017-06-20 18:08:39 --> Router Class Initialized
INFO - 2017-06-20 18:08:39 --> Output Class Initialized
INFO - 2017-06-20 18:08:39 --> Security Class Initialized
DEBUG - 2017-06-20 18:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:08:39 --> Input Class Initialized
INFO - 2017-06-20 18:08:39 --> Language Class Initialized
INFO - 2017-06-20 18:08:39 --> Loader Class Initialized
INFO - 2017-06-20 18:08:39 --> Controller Class Initialized
INFO - 2017-06-20 18:08:39 --> Database Driver Class Initialized
INFO - 2017-06-20 18:08:39 --> Model Class Initialized
INFO - 2017-06-20 18:08:39 --> Helper loaded: form_helper
INFO - 2017-06-20 18:08:39 --> Helper loaded: url_helper
INFO - 2017-06-20 18:08:39 --> Model Class Initialized
INFO - 2017-06-20 18:08:39 --> Final output sent to browser
DEBUG - 2017-06-20 18:08:39 --> Total execution time: 0.0470
ERROR - 2017-06-20 18:10:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:10:05 --> Config Class Initialized
INFO - 2017-06-20 18:10:05 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:10:05 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:10:05 --> Utf8 Class Initialized
INFO - 2017-06-20 18:10:05 --> URI Class Initialized
INFO - 2017-06-20 18:10:05 --> Router Class Initialized
INFO - 2017-06-20 18:10:05 --> Output Class Initialized
INFO - 2017-06-20 18:10:05 --> Security Class Initialized
DEBUG - 2017-06-20 18:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:10:05 --> Input Class Initialized
INFO - 2017-06-20 18:10:05 --> Language Class Initialized
INFO - 2017-06-20 18:10:05 --> Loader Class Initialized
INFO - 2017-06-20 18:10:05 --> Controller Class Initialized
INFO - 2017-06-20 18:10:05 --> Database Driver Class Initialized
INFO - 2017-06-20 18:10:05 --> Model Class Initialized
INFO - 2017-06-20 18:10:05 --> Helper loaded: form_helper
INFO - 2017-06-20 18:10:05 --> Helper loaded: url_helper
INFO - 2017-06-20 18:10:05 --> Model Class Initialized
INFO - 2017-06-20 18:10:05 --> Final output sent to browser
DEBUG - 2017-06-20 18:10:05 --> Total execution time: 0.0630
ERROR - 2017-06-20 18:10:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:10:05 --> Config Class Initialized
INFO - 2017-06-20 18:10:05 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:10:05 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:10:05 --> Utf8 Class Initialized
INFO - 2017-06-20 18:10:05 --> URI Class Initialized
INFO - 2017-06-20 18:10:05 --> Router Class Initialized
INFO - 2017-06-20 18:10:05 --> Output Class Initialized
INFO - 2017-06-20 18:10:05 --> Security Class Initialized
DEBUG - 2017-06-20 18:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:10:05 --> Input Class Initialized
INFO - 2017-06-20 18:10:05 --> Language Class Initialized
INFO - 2017-06-20 18:10:05 --> Loader Class Initialized
INFO - 2017-06-20 18:10:05 --> Controller Class Initialized
INFO - 2017-06-20 18:10:05 --> Database Driver Class Initialized
INFO - 2017-06-20 18:10:05 --> Model Class Initialized
INFO - 2017-06-20 18:10:05 --> Helper loaded: form_helper
INFO - 2017-06-20 18:10:05 --> Helper loaded: url_helper
INFO - 2017-06-20 18:10:05 --> Model Class Initialized
INFO - 2017-06-20 18:10:05 --> Final output sent to browser
DEBUG - 2017-06-20 18:10:05 --> Total execution time: 0.0460
ERROR - 2017-06-20 18:10:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:10:09 --> Config Class Initialized
INFO - 2017-06-20 18:10:09 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:10:09 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:10:09 --> Utf8 Class Initialized
INFO - 2017-06-20 18:10:09 --> URI Class Initialized
INFO - 2017-06-20 18:10:09 --> Router Class Initialized
INFO - 2017-06-20 18:10:09 --> Output Class Initialized
INFO - 2017-06-20 18:10:09 --> Security Class Initialized
DEBUG - 2017-06-20 18:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:10:09 --> Input Class Initialized
INFO - 2017-06-20 18:10:09 --> Language Class Initialized
INFO - 2017-06-20 18:10:09 --> Loader Class Initialized
INFO - 2017-06-20 18:10:09 --> Controller Class Initialized
INFO - 2017-06-20 18:10:09 --> Database Driver Class Initialized
INFO - 2017-06-20 18:10:09 --> Model Class Initialized
INFO - 2017-06-20 18:10:09 --> Helper loaded: form_helper
INFO - 2017-06-20 18:10:09 --> Helper loaded: url_helper
INFO - 2017-06-20 18:10:09 --> Model Class Initialized
INFO - 2017-06-20 18:10:09 --> Final output sent to browser
DEBUG - 2017-06-20 18:10:09 --> Total execution time: 0.0490
ERROR - 2017-06-20 18:10:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:10:09 --> Config Class Initialized
INFO - 2017-06-20 18:10:09 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:10:09 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:10:09 --> Utf8 Class Initialized
INFO - 2017-06-20 18:10:09 --> URI Class Initialized
INFO - 2017-06-20 18:10:09 --> Router Class Initialized
INFO - 2017-06-20 18:10:09 --> Output Class Initialized
INFO - 2017-06-20 18:10:09 --> Security Class Initialized
DEBUG - 2017-06-20 18:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:10:09 --> Input Class Initialized
INFO - 2017-06-20 18:10:09 --> Language Class Initialized
INFO - 2017-06-20 18:10:09 --> Loader Class Initialized
INFO - 2017-06-20 18:10:09 --> Controller Class Initialized
INFO - 2017-06-20 18:10:09 --> Database Driver Class Initialized
INFO - 2017-06-20 18:10:09 --> Model Class Initialized
INFO - 2017-06-20 18:10:09 --> Helper loaded: form_helper
INFO - 2017-06-20 18:10:09 --> Helper loaded: url_helper
INFO - 2017-06-20 18:10:09 --> Model Class Initialized
INFO - 2017-06-20 18:10:09 --> Final output sent to browser
DEBUG - 2017-06-20 18:10:09 --> Total execution time: 0.0760
ERROR - 2017-06-20 18:10:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 18:10:10 --> Config Class Initialized
INFO - 2017-06-20 18:10:10 --> Hooks Class Initialized
DEBUG - 2017-06-20 18:10:10 --> UTF-8 Support Enabled
INFO - 2017-06-20 18:10:10 --> Utf8 Class Initialized
INFO - 2017-06-20 18:10:10 --> URI Class Initialized
INFO - 2017-06-20 18:10:10 --> Router Class Initialized
INFO - 2017-06-20 18:10:10 --> Output Class Initialized
INFO - 2017-06-20 18:10:10 --> Security Class Initialized
DEBUG - 2017-06-20 18:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 18:10:10 --> Input Class Initialized
INFO - 2017-06-20 18:10:10 --> Language Class Initialized
INFO - 2017-06-20 18:10:10 --> Loader Class Initialized
INFO - 2017-06-20 18:10:10 --> Controller Class Initialized
INFO - 2017-06-20 18:10:10 --> Database Driver Class Initialized
INFO - 2017-06-20 18:10:10 --> Model Class Initialized
INFO - 2017-06-20 18:10:10 --> Helper loaded: form_helper
INFO - 2017-06-20 18:10:10 --> Helper loaded: url_helper
INFO - 2017-06-20 18:10:10 --> Model Class Initialized
INFO - 2017-06-20 18:10:10 --> Final output sent to browser
DEBUG - 2017-06-20 18:10:10 --> Total execution time: 0.0450
ERROR - 2017-06-20 19:48:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 19:48:15 --> Config Class Initialized
INFO - 2017-06-20 19:48:15 --> Hooks Class Initialized
DEBUG - 2017-06-20 19:48:15 --> UTF-8 Support Enabled
INFO - 2017-06-20 19:48:15 --> Utf8 Class Initialized
INFO - 2017-06-20 19:48:15 --> URI Class Initialized
INFO - 2017-06-20 19:48:15 --> Router Class Initialized
INFO - 2017-06-20 19:48:15 --> Output Class Initialized
INFO - 2017-06-20 19:48:15 --> Security Class Initialized
DEBUG - 2017-06-20 19:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 19:48:15 --> Input Class Initialized
INFO - 2017-06-20 19:48:15 --> Language Class Initialized
INFO - 2017-06-20 19:48:15 --> Loader Class Initialized
INFO - 2017-06-20 19:48:15 --> Controller Class Initialized
INFO - 2017-06-20 19:48:15 --> Database Driver Class Initialized
INFO - 2017-06-20 19:48:15 --> Model Class Initialized
INFO - 2017-06-20 19:48:15 --> Helper loaded: form_helper
INFO - 2017-06-20 19:48:15 --> Helper loaded: url_helper
INFO - 2017-06-20 19:48:15 --> Model Class Initialized
INFO - 2017-06-20 19:48:15 --> Final output sent to browser
DEBUG - 2017-06-20 19:48:15 --> Total execution time: 0.0550
ERROR - 2017-06-20 19:48:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 19:48:20 --> Config Class Initialized
INFO - 2017-06-20 19:48:20 --> Hooks Class Initialized
DEBUG - 2017-06-20 19:48:20 --> UTF-8 Support Enabled
INFO - 2017-06-20 19:48:20 --> Utf8 Class Initialized
INFO - 2017-06-20 19:48:20 --> URI Class Initialized
INFO - 2017-06-20 19:48:20 --> Router Class Initialized
INFO - 2017-06-20 19:48:20 --> Output Class Initialized
INFO - 2017-06-20 19:48:20 --> Security Class Initialized
DEBUG - 2017-06-20 19:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 19:48:20 --> Input Class Initialized
INFO - 2017-06-20 19:48:20 --> Language Class Initialized
INFO - 2017-06-20 19:48:20 --> Loader Class Initialized
INFO - 2017-06-20 19:48:20 --> Controller Class Initialized
INFO - 2017-06-20 19:48:20 --> Database Driver Class Initialized
INFO - 2017-06-20 19:48:20 --> Model Class Initialized
INFO - 2017-06-20 19:48:20 --> Helper loaded: form_helper
INFO - 2017-06-20 19:48:20 --> Helper loaded: url_helper
INFO - 2017-06-20 19:48:20 --> Model Class Initialized
INFO - 2017-06-20 19:48:20 --> Final output sent to browser
DEBUG - 2017-06-20 19:48:20 --> Total execution time: 0.0410
ERROR - 2017-06-20 19:49:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 19:49:26 --> Config Class Initialized
INFO - 2017-06-20 19:49:26 --> Hooks Class Initialized
DEBUG - 2017-06-20 19:49:26 --> UTF-8 Support Enabled
INFO - 2017-06-20 19:49:26 --> Utf8 Class Initialized
INFO - 2017-06-20 19:49:26 --> URI Class Initialized
INFO - 2017-06-20 19:49:26 --> Router Class Initialized
INFO - 2017-06-20 19:49:26 --> Output Class Initialized
INFO - 2017-06-20 19:49:26 --> Security Class Initialized
DEBUG - 2017-06-20 19:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 19:49:26 --> Input Class Initialized
INFO - 2017-06-20 19:49:26 --> Language Class Initialized
INFO - 2017-06-20 19:49:26 --> Loader Class Initialized
INFO - 2017-06-20 19:49:26 --> Controller Class Initialized
INFO - 2017-06-20 19:49:26 --> Database Driver Class Initialized
INFO - 2017-06-20 19:49:26 --> Model Class Initialized
INFO - 2017-06-20 19:49:26 --> Helper loaded: form_helper
INFO - 2017-06-20 19:49:26 --> Helper loaded: url_helper
INFO - 2017-06-20 19:49:26 --> Model Class Initialized
INFO - 2017-06-20 19:49:26 --> Final output sent to browser
DEBUG - 2017-06-20 19:49:26 --> Total execution time: 0.0520
ERROR - 2017-06-20 19:49:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 19:49:27 --> Config Class Initialized
INFO - 2017-06-20 19:49:27 --> Hooks Class Initialized
DEBUG - 2017-06-20 19:49:27 --> UTF-8 Support Enabled
INFO - 2017-06-20 19:49:27 --> Utf8 Class Initialized
INFO - 2017-06-20 19:49:27 --> URI Class Initialized
INFO - 2017-06-20 19:49:27 --> Router Class Initialized
INFO - 2017-06-20 19:49:27 --> Output Class Initialized
INFO - 2017-06-20 19:49:27 --> Security Class Initialized
DEBUG - 2017-06-20 19:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 19:49:27 --> Input Class Initialized
INFO - 2017-06-20 19:49:27 --> Language Class Initialized
INFO - 2017-06-20 19:49:27 --> Loader Class Initialized
INFO - 2017-06-20 19:49:27 --> Controller Class Initialized
INFO - 2017-06-20 19:49:27 --> Database Driver Class Initialized
INFO - 2017-06-20 19:49:27 --> Model Class Initialized
INFO - 2017-06-20 19:49:27 --> Helper loaded: form_helper
INFO - 2017-06-20 19:49:27 --> Helper loaded: url_helper
INFO - 2017-06-20 19:49:27 --> Model Class Initialized
INFO - 2017-06-20 19:49:27 --> Final output sent to browser
DEBUG - 2017-06-20 19:49:27 --> Total execution time: 0.0440
ERROR - 2017-06-20 19:49:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 19:49:37 --> Config Class Initialized
INFO - 2017-06-20 19:49:37 --> Hooks Class Initialized
DEBUG - 2017-06-20 19:49:37 --> UTF-8 Support Enabled
INFO - 2017-06-20 19:49:37 --> Utf8 Class Initialized
INFO - 2017-06-20 19:49:37 --> URI Class Initialized
INFO - 2017-06-20 19:49:37 --> Router Class Initialized
INFO - 2017-06-20 19:49:37 --> Output Class Initialized
INFO - 2017-06-20 19:49:37 --> Security Class Initialized
DEBUG - 2017-06-20 19:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 19:49:37 --> Input Class Initialized
INFO - 2017-06-20 19:49:37 --> Language Class Initialized
INFO - 2017-06-20 19:49:37 --> Loader Class Initialized
INFO - 2017-06-20 19:49:37 --> Controller Class Initialized
INFO - 2017-06-20 19:49:37 --> Database Driver Class Initialized
INFO - 2017-06-20 19:49:37 --> Model Class Initialized
INFO - 2017-06-20 19:49:37 --> Helper loaded: form_helper
INFO - 2017-06-20 19:49:37 --> Helper loaded: url_helper
INFO - 2017-06-20 19:49:37 --> Model Class Initialized
INFO - 2017-06-20 19:49:37 --> Final output sent to browser
DEBUG - 2017-06-20 19:49:37 --> Total execution time: 0.0650
ERROR - 2017-06-20 20:26:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:26:10 --> Config Class Initialized
INFO - 2017-06-20 20:26:10 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:26:10 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:26:10 --> Utf8 Class Initialized
INFO - 2017-06-20 20:26:10 --> URI Class Initialized
INFO - 2017-06-20 20:26:10 --> Router Class Initialized
INFO - 2017-06-20 20:26:10 --> Output Class Initialized
INFO - 2017-06-20 20:26:10 --> Security Class Initialized
DEBUG - 2017-06-20 20:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:26:10 --> Input Class Initialized
INFO - 2017-06-20 20:26:10 --> Language Class Initialized
INFO - 2017-06-20 20:26:10 --> Loader Class Initialized
INFO - 2017-06-20 20:26:10 --> Controller Class Initialized
INFO - 2017-06-20 20:26:10 --> Database Driver Class Initialized
INFO - 2017-06-20 20:26:10 --> Model Class Initialized
INFO - 2017-06-20 20:26:10 --> Helper loaded: form_helper
INFO - 2017-06-20 20:26:10 --> Helper loaded: url_helper
INFO - 2017-06-20 20:26:10 --> Model Class Initialized
INFO - 2017-06-20 20:26:10 --> Final output sent to browser
DEBUG - 2017-06-20 20:26:10 --> Total execution time: 0.0520
ERROR - 2017-06-20 20:26:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:26:11 --> Config Class Initialized
INFO - 2017-06-20 20:26:11 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:26:11 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:26:11 --> Utf8 Class Initialized
INFO - 2017-06-20 20:26:11 --> URI Class Initialized
INFO - 2017-06-20 20:26:11 --> Router Class Initialized
INFO - 2017-06-20 20:26:11 --> Output Class Initialized
INFO - 2017-06-20 20:26:11 --> Security Class Initialized
DEBUG - 2017-06-20 20:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:26:11 --> Input Class Initialized
INFO - 2017-06-20 20:26:11 --> Language Class Initialized
INFO - 2017-06-20 20:26:11 --> Loader Class Initialized
INFO - 2017-06-20 20:26:11 --> Controller Class Initialized
INFO - 2017-06-20 20:26:11 --> Database Driver Class Initialized
INFO - 2017-06-20 20:26:11 --> Model Class Initialized
INFO - 2017-06-20 20:26:11 --> Helper loaded: form_helper
INFO - 2017-06-20 20:26:11 --> Helper loaded: url_helper
INFO - 2017-06-20 20:26:11 --> Model Class Initialized
INFO - 2017-06-20 20:26:11 --> Final output sent to browser
DEBUG - 2017-06-20 20:26:11 --> Total execution time: 0.0580
ERROR - 2017-06-20 20:26:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:26:15 --> Config Class Initialized
INFO - 2017-06-20 20:26:15 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:26:15 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:26:15 --> Utf8 Class Initialized
INFO - 2017-06-20 20:26:15 --> URI Class Initialized
INFO - 2017-06-20 20:26:15 --> Router Class Initialized
INFO - 2017-06-20 20:26:15 --> Output Class Initialized
INFO - 2017-06-20 20:26:15 --> Security Class Initialized
DEBUG - 2017-06-20 20:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:26:15 --> Input Class Initialized
INFO - 2017-06-20 20:26:15 --> Language Class Initialized
INFO - 2017-06-20 20:26:15 --> Loader Class Initialized
INFO - 2017-06-20 20:26:15 --> Controller Class Initialized
INFO - 2017-06-20 20:26:15 --> Database Driver Class Initialized
INFO - 2017-06-20 20:26:15 --> Model Class Initialized
INFO - 2017-06-20 20:26:15 --> Helper loaded: form_helper
INFO - 2017-06-20 20:26:15 --> Helper loaded: url_helper
INFO - 2017-06-20 20:26:15 --> Model Class Initialized
INFO - 2017-06-20 20:26:15 --> Final output sent to browser
DEBUG - 2017-06-20 20:26:15 --> Total execution time: 0.0690
ERROR - 2017-06-20 20:27:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:27:01 --> Config Class Initialized
INFO - 2017-06-20 20:27:01 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:27:01 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:27:01 --> Utf8 Class Initialized
INFO - 2017-06-20 20:27:01 --> URI Class Initialized
INFO - 2017-06-20 20:27:01 --> Router Class Initialized
INFO - 2017-06-20 20:27:01 --> Output Class Initialized
INFO - 2017-06-20 20:27:01 --> Security Class Initialized
DEBUG - 2017-06-20 20:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:27:01 --> Input Class Initialized
INFO - 2017-06-20 20:27:01 --> Language Class Initialized
INFO - 2017-06-20 20:27:01 --> Loader Class Initialized
INFO - 2017-06-20 20:27:01 --> Controller Class Initialized
INFO - 2017-06-20 20:27:01 --> Database Driver Class Initialized
INFO - 2017-06-20 20:27:01 --> Model Class Initialized
INFO - 2017-06-20 20:27:01 --> Helper loaded: form_helper
INFO - 2017-06-20 20:27:01 --> Helper loaded: url_helper
INFO - 2017-06-20 20:27:01 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-20 20:27:01 --> Model Class Initialized
INFO - 2017-06-20 20:27:01 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-20 20:27:01 --> Final output sent to browser
DEBUG - 2017-06-20 20:27:01 --> Total execution time: 0.0760
ERROR - 2017-06-20 20:28:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:28:15 --> Config Class Initialized
INFO - 2017-06-20 20:28:15 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:28:15 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:28:15 --> Utf8 Class Initialized
INFO - 2017-06-20 20:28:15 --> URI Class Initialized
INFO - 2017-06-20 20:28:15 --> Router Class Initialized
INFO - 2017-06-20 20:28:15 --> Output Class Initialized
INFO - 2017-06-20 20:28:15 --> Security Class Initialized
DEBUG - 2017-06-20 20:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:28:15 --> Input Class Initialized
INFO - 2017-06-20 20:28:15 --> Language Class Initialized
INFO - 2017-06-20 20:28:15 --> Loader Class Initialized
INFO - 2017-06-20 20:28:15 --> Controller Class Initialized
INFO - 2017-06-20 20:28:15 --> Database Driver Class Initialized
INFO - 2017-06-20 20:28:15 --> Model Class Initialized
INFO - 2017-06-20 20:28:15 --> Helper loaded: form_helper
INFO - 2017-06-20 20:28:15 --> Helper loaded: url_helper
INFO - 2017-06-20 20:28:15 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-20 20:28:15 --> Model Class Initialized
INFO - 2017-06-20 20:28:15 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-20 20:28:15 --> Final output sent to browser
DEBUG - 2017-06-20 20:28:15 --> Total execution time: 0.0780
ERROR - 2017-06-20 20:28:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:28:17 --> Config Class Initialized
INFO - 2017-06-20 20:28:17 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:28:17 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:28:17 --> Utf8 Class Initialized
INFO - 2017-06-20 20:28:17 --> URI Class Initialized
INFO - 2017-06-20 20:28:17 --> Router Class Initialized
INFO - 2017-06-20 20:28:17 --> Output Class Initialized
INFO - 2017-06-20 20:28:17 --> Security Class Initialized
DEBUG - 2017-06-20 20:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:28:17 --> Input Class Initialized
INFO - 2017-06-20 20:28:17 --> Language Class Initialized
INFO - 2017-06-20 20:28:17 --> Loader Class Initialized
INFO - 2017-06-20 20:28:17 --> Controller Class Initialized
INFO - 2017-06-20 20:28:17 --> Database Driver Class Initialized
INFO - 2017-06-20 20:28:17 --> Model Class Initialized
INFO - 2017-06-20 20:28:17 --> Helper loaded: form_helper
INFO - 2017-06-20 20:28:17 --> Helper loaded: url_helper
INFO - 2017-06-20 20:28:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-20 20:28:17 --> Model Class Initialized
INFO - 2017-06-20 20:28:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-20 20:28:17 --> Final output sent to browser
DEBUG - 2017-06-20 20:28:17 --> Total execution time: 0.0920
ERROR - 2017-06-20 20:29:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:29:38 --> Config Class Initialized
INFO - 2017-06-20 20:29:39 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:29:39 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:29:39 --> Utf8 Class Initialized
INFO - 2017-06-20 20:29:39 --> URI Class Initialized
INFO - 2017-06-20 20:29:39 --> Router Class Initialized
INFO - 2017-06-20 20:29:39 --> Output Class Initialized
INFO - 2017-06-20 20:29:39 --> Security Class Initialized
DEBUG - 2017-06-20 20:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:29:39 --> Input Class Initialized
INFO - 2017-06-20 20:29:39 --> Language Class Initialized
INFO - 2017-06-20 20:29:39 --> Loader Class Initialized
INFO - 2017-06-20 20:29:39 --> Controller Class Initialized
INFO - 2017-06-20 20:29:39 --> Database Driver Class Initialized
INFO - 2017-06-20 20:29:39 --> Model Class Initialized
INFO - 2017-06-20 20:29:39 --> Helper loaded: form_helper
INFO - 2017-06-20 20:29:39 --> Helper loaded: url_helper
INFO - 2017-06-20 20:29:39 --> Upload Class Initialized
INFO - 2017-06-20 20:29:39 --> Final output sent to browser
DEBUG - 2017-06-20 20:29:39 --> Total execution time: 0.1030
ERROR - 2017-06-20 20:29:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:29:47 --> Config Class Initialized
INFO - 2017-06-20 20:29:47 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:29:47 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:29:47 --> Utf8 Class Initialized
INFO - 2017-06-20 20:29:47 --> URI Class Initialized
INFO - 2017-06-20 20:29:47 --> Router Class Initialized
INFO - 2017-06-20 20:29:47 --> Output Class Initialized
INFO - 2017-06-20 20:29:47 --> Security Class Initialized
DEBUG - 2017-06-20 20:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:29:47 --> Input Class Initialized
INFO - 2017-06-20 20:29:47 --> Language Class Initialized
INFO - 2017-06-20 20:29:47 --> Loader Class Initialized
INFO - 2017-06-20 20:29:47 --> Controller Class Initialized
INFO - 2017-06-20 20:29:47 --> Database Driver Class Initialized
INFO - 2017-06-20 20:29:47 --> Model Class Initialized
INFO - 2017-06-20 20:29:47 --> Helper loaded: form_helper
INFO - 2017-06-20 20:29:47 --> Helper loaded: url_helper
INFO - 2017-06-20 20:29:47 --> Upload Class Initialized
INFO - 2017-06-20 20:29:47 --> Final output sent to browser
DEBUG - 2017-06-20 20:29:47 --> Total execution time: 0.0670
ERROR - 2017-06-20 20:29:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:29:54 --> Config Class Initialized
INFO - 2017-06-20 20:29:54 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:29:54 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:29:54 --> Utf8 Class Initialized
INFO - 2017-06-20 20:29:54 --> URI Class Initialized
INFO - 2017-06-20 20:29:54 --> Router Class Initialized
INFO - 2017-06-20 20:29:54 --> Output Class Initialized
INFO - 2017-06-20 20:29:54 --> Security Class Initialized
DEBUG - 2017-06-20 20:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:29:54 --> Input Class Initialized
INFO - 2017-06-20 20:29:54 --> Language Class Initialized
INFO - 2017-06-20 20:29:54 --> Loader Class Initialized
INFO - 2017-06-20 20:29:54 --> Controller Class Initialized
INFO - 2017-06-20 20:29:54 --> Database Driver Class Initialized
INFO - 2017-06-20 20:29:54 --> Model Class Initialized
INFO - 2017-06-20 20:29:54 --> Helper loaded: form_helper
INFO - 2017-06-20 20:29:54 --> Helper loaded: url_helper
INFO - 2017-06-20 20:29:54 --> Model Class Initialized
INFO - 2017-06-20 20:29:54 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-20 20:29:54 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-20 20:29:54 --> Final output sent to browser
DEBUG - 2017-06-20 20:29:54 --> Total execution time: 0.0950
ERROR - 2017-06-20 20:29:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:29:58 --> Config Class Initialized
INFO - 2017-06-20 20:29:58 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:29:58 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:29:58 --> Utf8 Class Initialized
INFO - 2017-06-20 20:29:58 --> URI Class Initialized
INFO - 2017-06-20 20:29:58 --> Router Class Initialized
INFO - 2017-06-20 20:29:58 --> Output Class Initialized
INFO - 2017-06-20 20:29:58 --> Security Class Initialized
DEBUG - 2017-06-20 20:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:29:58 --> Input Class Initialized
INFO - 2017-06-20 20:29:58 --> Language Class Initialized
INFO - 2017-06-20 20:29:58 --> Loader Class Initialized
INFO - 2017-06-20 20:29:58 --> Controller Class Initialized
INFO - 2017-06-20 20:29:58 --> Database Driver Class Initialized
INFO - 2017-06-20 20:29:58 --> Model Class Initialized
INFO - 2017-06-20 20:29:58 --> Helper loaded: form_helper
INFO - 2017-06-20 20:29:58 --> Helper loaded: url_helper
INFO - 2017-06-20 20:29:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-20 20:29:58 --> Model Class Initialized
INFO - 2017-06-20 20:29:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-20 20:29:58 --> Final output sent to browser
DEBUG - 2017-06-20 20:29:58 --> Total execution time: 0.0670
ERROR - 2017-06-20 20:31:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:31:39 --> Config Class Initialized
INFO - 2017-06-20 20:31:39 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:31:39 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:31:39 --> Utf8 Class Initialized
INFO - 2017-06-20 20:31:39 --> URI Class Initialized
INFO - 2017-06-20 20:31:39 --> Router Class Initialized
INFO - 2017-06-20 20:31:39 --> Output Class Initialized
INFO - 2017-06-20 20:31:39 --> Security Class Initialized
DEBUG - 2017-06-20 20:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:31:39 --> Input Class Initialized
INFO - 2017-06-20 20:31:39 --> Language Class Initialized
INFO - 2017-06-20 20:31:39 --> Loader Class Initialized
INFO - 2017-06-20 20:31:39 --> Controller Class Initialized
INFO - 2017-06-20 20:31:39 --> Database Driver Class Initialized
INFO - 2017-06-20 20:31:39 --> Model Class Initialized
INFO - 2017-06-20 20:31:39 --> Helper loaded: form_helper
INFO - 2017-06-20 20:31:39 --> Helper loaded: url_helper
INFO - 2017-06-20 20:31:39 --> Model Class Initialized
INFO - 2017-06-20 20:31:39 --> Final output sent to browser
DEBUG - 2017-06-20 20:31:39 --> Total execution time: 0.0910
ERROR - 2017-06-20 20:31:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:31:39 --> Config Class Initialized
INFO - 2017-06-20 20:31:39 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:31:39 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:31:39 --> Utf8 Class Initialized
INFO - 2017-06-20 20:31:39 --> URI Class Initialized
INFO - 2017-06-20 20:31:39 --> Router Class Initialized
INFO - 2017-06-20 20:31:39 --> Output Class Initialized
INFO - 2017-06-20 20:31:39 --> Security Class Initialized
DEBUG - 2017-06-20 20:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:31:39 --> Input Class Initialized
INFO - 2017-06-20 20:31:39 --> Language Class Initialized
INFO - 2017-06-20 20:31:39 --> Loader Class Initialized
INFO - 2017-06-20 20:31:39 --> Controller Class Initialized
INFO - 2017-06-20 20:31:39 --> Database Driver Class Initialized
INFO - 2017-06-20 20:31:39 --> Model Class Initialized
INFO - 2017-06-20 20:31:39 --> Helper loaded: form_helper
INFO - 2017-06-20 20:31:39 --> Helper loaded: url_helper
INFO - 2017-06-20 20:31:39 --> Model Class Initialized
INFO - 2017-06-20 20:31:39 --> Final output sent to browser
DEBUG - 2017-06-20 20:31:39 --> Total execution time: 0.0450
ERROR - 2017-06-20 20:31:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:31:41 --> Config Class Initialized
INFO - 2017-06-20 20:31:41 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:31:41 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:31:41 --> Utf8 Class Initialized
INFO - 2017-06-20 20:31:41 --> URI Class Initialized
INFO - 2017-06-20 20:31:41 --> Router Class Initialized
INFO - 2017-06-20 20:31:41 --> Output Class Initialized
INFO - 2017-06-20 20:31:41 --> Security Class Initialized
DEBUG - 2017-06-20 20:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:31:41 --> Input Class Initialized
INFO - 2017-06-20 20:31:41 --> Language Class Initialized
INFO - 2017-06-20 20:31:41 --> Loader Class Initialized
INFO - 2017-06-20 20:31:41 --> Controller Class Initialized
INFO - 2017-06-20 20:31:41 --> Database Driver Class Initialized
INFO - 2017-06-20 20:31:41 --> Model Class Initialized
INFO - 2017-06-20 20:31:41 --> Helper loaded: form_helper
INFO - 2017-06-20 20:31:41 --> Helper loaded: url_helper
INFO - 2017-06-20 20:31:41 --> Model Class Initialized
INFO - 2017-06-20 20:31:41 --> Final output sent to browser
DEBUG - 2017-06-20 20:31:41 --> Total execution time: 0.0470
ERROR - 2017-06-20 20:38:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:38:57 --> Config Class Initialized
INFO - 2017-06-20 20:38:57 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:38:57 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:38:57 --> Utf8 Class Initialized
INFO - 2017-06-20 20:38:57 --> URI Class Initialized
INFO - 2017-06-20 20:38:57 --> Router Class Initialized
INFO - 2017-06-20 20:38:57 --> Output Class Initialized
INFO - 2017-06-20 20:38:57 --> Security Class Initialized
DEBUG - 2017-06-20 20:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:38:57 --> Input Class Initialized
INFO - 2017-06-20 20:38:57 --> Language Class Initialized
INFO - 2017-06-20 20:38:57 --> Loader Class Initialized
INFO - 2017-06-20 20:38:57 --> Controller Class Initialized
INFO - 2017-06-20 20:38:57 --> Database Driver Class Initialized
INFO - 2017-06-20 20:38:57 --> Model Class Initialized
INFO - 2017-06-20 20:38:57 --> Helper loaded: form_helper
INFO - 2017-06-20 20:38:57 --> Helper loaded: url_helper
INFO - 2017-06-20 20:38:57 --> Model Class Initialized
INFO - 2017-06-20 20:38:57 --> Final output sent to browser
DEBUG - 2017-06-20 20:38:57 --> Total execution time: 0.0710
ERROR - 2017-06-20 20:38:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:38:58 --> Config Class Initialized
INFO - 2017-06-20 20:38:58 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:38:58 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:38:58 --> Utf8 Class Initialized
INFO - 2017-06-20 20:38:58 --> URI Class Initialized
INFO - 2017-06-20 20:38:58 --> Router Class Initialized
INFO - 2017-06-20 20:38:58 --> Output Class Initialized
INFO - 2017-06-20 20:38:58 --> Security Class Initialized
DEBUG - 2017-06-20 20:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:38:58 --> Input Class Initialized
INFO - 2017-06-20 20:38:58 --> Language Class Initialized
INFO - 2017-06-20 20:38:58 --> Loader Class Initialized
INFO - 2017-06-20 20:38:58 --> Controller Class Initialized
INFO - 2017-06-20 20:38:58 --> Database Driver Class Initialized
INFO - 2017-06-20 20:38:58 --> Model Class Initialized
INFO - 2017-06-20 20:38:58 --> Helper loaded: form_helper
INFO - 2017-06-20 20:38:58 --> Helper loaded: url_helper
INFO - 2017-06-20 20:38:58 --> Model Class Initialized
INFO - 2017-06-20 20:38:58 --> Final output sent to browser
DEBUG - 2017-06-20 20:38:58 --> Total execution time: 0.0580
ERROR - 2017-06-20 20:38:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:38:59 --> Config Class Initialized
INFO - 2017-06-20 20:38:59 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:38:59 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:38:59 --> Utf8 Class Initialized
INFO - 2017-06-20 20:38:59 --> URI Class Initialized
INFO - 2017-06-20 20:38:59 --> Router Class Initialized
INFO - 2017-06-20 20:38:59 --> Output Class Initialized
INFO - 2017-06-20 20:38:59 --> Security Class Initialized
DEBUG - 2017-06-20 20:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:38:59 --> Input Class Initialized
INFO - 2017-06-20 20:38:59 --> Language Class Initialized
INFO - 2017-06-20 20:38:59 --> Loader Class Initialized
INFO - 2017-06-20 20:38:59 --> Controller Class Initialized
INFO - 2017-06-20 20:38:59 --> Database Driver Class Initialized
INFO - 2017-06-20 20:38:59 --> Model Class Initialized
INFO - 2017-06-20 20:38:59 --> Helper loaded: form_helper
INFO - 2017-06-20 20:38:59 --> Helper loaded: url_helper
INFO - 2017-06-20 20:38:59 --> Model Class Initialized
INFO - 2017-06-20 20:38:59 --> Final output sent to browser
DEBUG - 2017-06-20 20:38:59 --> Total execution time: 0.0485
ERROR - 2017-06-20 20:42:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:42:07 --> Config Class Initialized
INFO - 2017-06-20 20:42:07 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:42:07 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:42:07 --> Utf8 Class Initialized
INFO - 2017-06-20 20:42:07 --> URI Class Initialized
INFO - 2017-06-20 20:42:07 --> Router Class Initialized
INFO - 2017-06-20 20:42:07 --> Output Class Initialized
INFO - 2017-06-20 20:42:07 --> Security Class Initialized
DEBUG - 2017-06-20 20:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:42:07 --> Input Class Initialized
INFO - 2017-06-20 20:42:07 --> Language Class Initialized
INFO - 2017-06-20 20:42:07 --> Loader Class Initialized
INFO - 2017-06-20 20:42:07 --> Controller Class Initialized
INFO - 2017-06-20 20:42:07 --> Database Driver Class Initialized
INFO - 2017-06-20 20:42:07 --> Model Class Initialized
INFO - 2017-06-20 20:42:07 --> Helper loaded: form_helper
INFO - 2017-06-20 20:42:07 --> Helper loaded: url_helper
INFO - 2017-06-20 20:42:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-20 20:42:07 --> Model Class Initialized
INFO - 2017-06-20 20:42:07 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-20 20:42:07 --> Final output sent to browser
DEBUG - 2017-06-20 20:42:07 --> Total execution time: 0.0760
ERROR - 2017-06-20 20:42:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:42:17 --> Config Class Initialized
INFO - 2017-06-20 20:42:17 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:42:17 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:42:17 --> Utf8 Class Initialized
INFO - 2017-06-20 20:42:17 --> URI Class Initialized
INFO - 2017-06-20 20:42:17 --> Router Class Initialized
INFO - 2017-06-20 20:42:17 --> Output Class Initialized
INFO - 2017-06-20 20:42:17 --> Security Class Initialized
DEBUG - 2017-06-20 20:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:42:17 --> Input Class Initialized
INFO - 2017-06-20 20:42:17 --> Language Class Initialized
INFO - 2017-06-20 20:42:17 --> Loader Class Initialized
INFO - 2017-06-20 20:42:17 --> Controller Class Initialized
INFO - 2017-06-20 20:42:17 --> Database Driver Class Initialized
INFO - 2017-06-20 20:42:17 --> Model Class Initialized
INFO - 2017-06-20 20:42:17 --> Helper loaded: form_helper
INFO - 2017-06-20 20:42:17 --> Helper loaded: url_helper
INFO - 2017-06-20 20:42:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-20 20:42:17 --> Model Class Initialized
INFO - 2017-06-20 20:42:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-20 20:42:17 --> Final output sent to browser
DEBUG - 2017-06-20 20:42:17 --> Total execution time: 0.0750
ERROR - 2017-06-20 20:42:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:42:21 --> Config Class Initialized
INFO - 2017-06-20 20:42:21 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:42:21 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:42:21 --> Utf8 Class Initialized
INFO - 2017-06-20 20:42:21 --> URI Class Initialized
INFO - 2017-06-20 20:42:21 --> Router Class Initialized
INFO - 2017-06-20 20:42:21 --> Output Class Initialized
INFO - 2017-06-20 20:42:21 --> Security Class Initialized
DEBUG - 2017-06-20 20:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:42:21 --> Input Class Initialized
INFO - 2017-06-20 20:42:21 --> Language Class Initialized
INFO - 2017-06-20 20:42:21 --> Loader Class Initialized
INFO - 2017-06-20 20:42:21 --> Controller Class Initialized
INFO - 2017-06-20 20:42:21 --> Database Driver Class Initialized
INFO - 2017-06-20 20:42:21 --> Model Class Initialized
INFO - 2017-06-20 20:42:21 --> Helper loaded: form_helper
INFO - 2017-06-20 20:42:21 --> Helper loaded: url_helper
INFO - 2017-06-20 20:42:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-20 20:42:21 --> Model Class Initialized
INFO - 2017-06-20 20:42:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-20 20:42:21 --> Final output sent to browser
DEBUG - 2017-06-20 20:42:21 --> Total execution time: 0.0680
ERROR - 2017-06-20 20:42:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:42:31 --> Config Class Initialized
INFO - 2017-06-20 20:42:31 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:42:31 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:42:31 --> Utf8 Class Initialized
INFO - 2017-06-20 20:42:31 --> URI Class Initialized
INFO - 2017-06-20 20:42:31 --> Router Class Initialized
INFO - 2017-06-20 20:42:31 --> Output Class Initialized
INFO - 2017-06-20 20:42:31 --> Security Class Initialized
DEBUG - 2017-06-20 20:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:42:31 --> Input Class Initialized
INFO - 2017-06-20 20:42:31 --> Language Class Initialized
INFO - 2017-06-20 20:42:31 --> Loader Class Initialized
INFO - 2017-06-20 20:42:31 --> Controller Class Initialized
INFO - 2017-06-20 20:42:31 --> Database Driver Class Initialized
INFO - 2017-06-20 20:42:31 --> Model Class Initialized
INFO - 2017-06-20 20:42:31 --> Helper loaded: form_helper
INFO - 2017-06-20 20:42:31 --> Helper loaded: url_helper
INFO - 2017-06-20 20:42:31 --> Model Class Initialized
INFO - 2017-06-20 20:42:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-20 20:42:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-20 20:42:31 --> Final output sent to browser
DEBUG - 2017-06-20 20:42:31 --> Total execution time: 0.0890
ERROR - 2017-06-20 20:42:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:42:33 --> Config Class Initialized
INFO - 2017-06-20 20:42:33 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:42:33 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:42:33 --> Utf8 Class Initialized
INFO - 2017-06-20 20:42:33 --> URI Class Initialized
INFO - 2017-06-20 20:42:33 --> Router Class Initialized
INFO - 2017-06-20 20:42:33 --> Output Class Initialized
INFO - 2017-06-20 20:42:33 --> Security Class Initialized
DEBUG - 2017-06-20 20:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:42:33 --> Input Class Initialized
INFO - 2017-06-20 20:42:33 --> Language Class Initialized
INFO - 2017-06-20 20:42:33 --> Loader Class Initialized
INFO - 2017-06-20 20:42:33 --> Controller Class Initialized
INFO - 2017-06-20 20:42:33 --> Database Driver Class Initialized
INFO - 2017-06-20 20:42:33 --> Model Class Initialized
INFO - 2017-06-20 20:42:33 --> Helper loaded: form_helper
INFO - 2017-06-20 20:42:33 --> Helper loaded: url_helper
INFO - 2017-06-20 20:42:33 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-20 20:42:33 --> Model Class Initialized
INFO - 2017-06-20 20:42:33 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-20 20:42:33 --> Final output sent to browser
DEBUG - 2017-06-20 20:42:33 --> Total execution time: 0.0640
ERROR - 2017-06-20 20:43:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:43:08 --> Config Class Initialized
INFO - 2017-06-20 20:43:08 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:43:08 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:43:08 --> Utf8 Class Initialized
INFO - 2017-06-20 20:43:08 --> URI Class Initialized
INFO - 2017-06-20 20:43:08 --> Router Class Initialized
INFO - 2017-06-20 20:43:08 --> Output Class Initialized
INFO - 2017-06-20 20:43:08 --> Security Class Initialized
DEBUG - 2017-06-20 20:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:43:08 --> Input Class Initialized
INFO - 2017-06-20 20:43:08 --> Language Class Initialized
INFO - 2017-06-20 20:43:08 --> Loader Class Initialized
INFO - 2017-06-20 20:43:08 --> Controller Class Initialized
INFO - 2017-06-20 20:43:08 --> Database Driver Class Initialized
INFO - 2017-06-20 20:43:08 --> Model Class Initialized
INFO - 2017-06-20 20:43:08 --> Helper loaded: form_helper
INFO - 2017-06-20 20:43:08 --> Helper loaded: url_helper
INFO - 2017-06-20 20:43:08 --> Model Class Initialized
INFO - 2017-06-20 20:43:08 --> Final output sent to browser
DEBUG - 2017-06-20 20:43:08 --> Total execution time: 0.1700
ERROR - 2017-06-20 20:43:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:43:08 --> Config Class Initialized
INFO - 2017-06-20 20:43:08 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:43:08 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:43:08 --> Utf8 Class Initialized
INFO - 2017-06-20 20:43:08 --> URI Class Initialized
INFO - 2017-06-20 20:43:08 --> Router Class Initialized
INFO - 2017-06-20 20:43:08 --> Output Class Initialized
INFO - 2017-06-20 20:43:08 --> Security Class Initialized
DEBUG - 2017-06-20 20:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:43:08 --> Input Class Initialized
INFO - 2017-06-20 20:43:08 --> Language Class Initialized
INFO - 2017-06-20 20:43:08 --> Loader Class Initialized
INFO - 2017-06-20 20:43:08 --> Controller Class Initialized
INFO - 2017-06-20 20:43:08 --> Database Driver Class Initialized
INFO - 2017-06-20 20:43:08 --> Model Class Initialized
INFO - 2017-06-20 20:43:08 --> Helper loaded: form_helper
INFO - 2017-06-20 20:43:08 --> Helper loaded: url_helper
INFO - 2017-06-20 20:43:08 --> Model Class Initialized
INFO - 2017-06-20 20:43:08 --> Final output sent to browser
DEBUG - 2017-06-20 20:43:08 --> Total execution time: 0.0545
ERROR - 2017-06-20 20:43:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:43:10 --> Config Class Initialized
INFO - 2017-06-20 20:43:10 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:43:10 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:43:10 --> Utf8 Class Initialized
INFO - 2017-06-20 20:43:10 --> URI Class Initialized
INFO - 2017-06-20 20:43:10 --> Router Class Initialized
INFO - 2017-06-20 20:43:10 --> Output Class Initialized
INFO - 2017-06-20 20:43:10 --> Security Class Initialized
DEBUG - 2017-06-20 20:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:43:10 --> Input Class Initialized
INFO - 2017-06-20 20:43:10 --> Language Class Initialized
INFO - 2017-06-20 20:43:10 --> Loader Class Initialized
INFO - 2017-06-20 20:43:10 --> Controller Class Initialized
INFO - 2017-06-20 20:43:10 --> Database Driver Class Initialized
INFO - 2017-06-20 20:43:10 --> Model Class Initialized
INFO - 2017-06-20 20:43:10 --> Helper loaded: form_helper
INFO - 2017-06-20 20:43:10 --> Helper loaded: url_helper
INFO - 2017-06-20 20:43:10 --> Model Class Initialized
INFO - 2017-06-20 20:43:10 --> Final output sent to browser
DEBUG - 2017-06-20 20:43:10 --> Total execution time: 0.0590
ERROR - 2017-06-20 20:46:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:46:29 --> Config Class Initialized
INFO - 2017-06-20 20:46:29 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:46:29 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:46:29 --> Utf8 Class Initialized
INFO - 2017-06-20 20:46:29 --> URI Class Initialized
INFO - 2017-06-20 20:46:29 --> Router Class Initialized
INFO - 2017-06-20 20:46:29 --> Output Class Initialized
INFO - 2017-06-20 20:46:29 --> Security Class Initialized
DEBUG - 2017-06-20 20:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:46:29 --> Input Class Initialized
INFO - 2017-06-20 20:46:29 --> Language Class Initialized
INFO - 2017-06-20 20:46:29 --> Loader Class Initialized
INFO - 2017-06-20 20:46:29 --> Controller Class Initialized
INFO - 2017-06-20 20:46:29 --> Database Driver Class Initialized
INFO - 2017-06-20 20:46:29 --> Model Class Initialized
INFO - 2017-06-20 20:46:29 --> Helper loaded: form_helper
INFO - 2017-06-20 20:46:29 --> Helper loaded: url_helper
INFO - 2017-06-20 20:46:29 --> Model Class Initialized
INFO - 2017-06-20 20:46:29 --> Final output sent to browser
DEBUG - 2017-06-20 20:46:29 --> Total execution time: 0.0630
ERROR - 2017-06-20 20:46:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:46:30 --> Config Class Initialized
INFO - 2017-06-20 20:46:30 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:46:30 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:46:30 --> Utf8 Class Initialized
INFO - 2017-06-20 20:46:30 --> URI Class Initialized
INFO - 2017-06-20 20:46:30 --> Router Class Initialized
INFO - 2017-06-20 20:46:30 --> Output Class Initialized
INFO - 2017-06-20 20:46:30 --> Security Class Initialized
DEBUG - 2017-06-20 20:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:46:30 --> Input Class Initialized
INFO - 2017-06-20 20:46:30 --> Language Class Initialized
INFO - 2017-06-20 20:46:30 --> Loader Class Initialized
INFO - 2017-06-20 20:46:30 --> Controller Class Initialized
INFO - 2017-06-20 20:46:30 --> Database Driver Class Initialized
INFO - 2017-06-20 20:46:30 --> Model Class Initialized
INFO - 2017-06-20 20:46:30 --> Helper loaded: form_helper
INFO - 2017-06-20 20:46:30 --> Helper loaded: url_helper
INFO - 2017-06-20 20:46:30 --> Model Class Initialized
INFO - 2017-06-20 20:46:30 --> Final output sent to browser
DEBUG - 2017-06-20 20:46:30 --> Total execution time: 0.0570
ERROR - 2017-06-20 20:46:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:46:31 --> Config Class Initialized
INFO - 2017-06-20 20:46:31 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:46:31 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:46:31 --> Utf8 Class Initialized
INFO - 2017-06-20 20:46:31 --> URI Class Initialized
INFO - 2017-06-20 20:46:31 --> Router Class Initialized
INFO - 2017-06-20 20:46:31 --> Output Class Initialized
INFO - 2017-06-20 20:46:31 --> Security Class Initialized
DEBUG - 2017-06-20 20:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:46:31 --> Input Class Initialized
INFO - 2017-06-20 20:46:31 --> Language Class Initialized
INFO - 2017-06-20 20:46:31 --> Loader Class Initialized
INFO - 2017-06-20 20:46:31 --> Controller Class Initialized
INFO - 2017-06-20 20:46:31 --> Database Driver Class Initialized
INFO - 2017-06-20 20:46:31 --> Model Class Initialized
INFO - 2017-06-20 20:46:31 --> Helper loaded: form_helper
INFO - 2017-06-20 20:46:31 --> Helper loaded: url_helper
INFO - 2017-06-20 20:46:31 --> Model Class Initialized
INFO - 2017-06-20 20:46:31 --> Final output sent to browser
DEBUG - 2017-06-20 20:46:31 --> Total execution time: 0.0490
ERROR - 2017-06-20 20:50:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:50:47 --> Config Class Initialized
INFO - 2017-06-20 20:50:47 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:50:47 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:50:47 --> Utf8 Class Initialized
INFO - 2017-06-20 20:50:47 --> URI Class Initialized
INFO - 2017-06-20 20:50:47 --> Router Class Initialized
INFO - 2017-06-20 20:50:47 --> Output Class Initialized
INFO - 2017-06-20 20:50:47 --> Security Class Initialized
DEBUG - 2017-06-20 20:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:50:47 --> Input Class Initialized
INFO - 2017-06-20 20:50:47 --> Language Class Initialized
INFO - 2017-06-20 20:50:47 --> Loader Class Initialized
INFO - 2017-06-20 20:50:47 --> Controller Class Initialized
INFO - 2017-06-20 20:50:47 --> Database Driver Class Initialized
INFO - 2017-06-20 20:50:47 --> Model Class Initialized
INFO - 2017-06-20 20:50:47 --> Helper loaded: form_helper
INFO - 2017-06-20 20:50:47 --> Helper loaded: url_helper
INFO - 2017-06-20 20:50:47 --> Model Class Initialized
INFO - 2017-06-20 20:50:47 --> Final output sent to browser
DEBUG - 2017-06-20 20:50:47 --> Total execution time: 0.0560
ERROR - 2017-06-20 20:50:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:50:47 --> Config Class Initialized
INFO - 2017-06-20 20:50:47 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:50:47 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:50:47 --> Utf8 Class Initialized
INFO - 2017-06-20 20:50:47 --> URI Class Initialized
INFO - 2017-06-20 20:50:47 --> Router Class Initialized
INFO - 2017-06-20 20:50:47 --> Output Class Initialized
INFO - 2017-06-20 20:50:47 --> Security Class Initialized
DEBUG - 2017-06-20 20:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:50:47 --> Input Class Initialized
INFO - 2017-06-20 20:50:47 --> Language Class Initialized
INFO - 2017-06-20 20:50:47 --> Loader Class Initialized
INFO - 2017-06-20 20:50:47 --> Controller Class Initialized
INFO - 2017-06-20 20:50:47 --> Database Driver Class Initialized
INFO - 2017-06-20 20:50:47 --> Model Class Initialized
INFO - 2017-06-20 20:50:47 --> Helper loaded: form_helper
INFO - 2017-06-20 20:50:47 --> Helper loaded: url_helper
INFO - 2017-06-20 20:50:47 --> Model Class Initialized
INFO - 2017-06-20 20:50:47 --> Final output sent to browser
DEBUG - 2017-06-20 20:50:47 --> Total execution time: 0.0610
ERROR - 2017-06-20 20:50:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:50:51 --> Config Class Initialized
INFO - 2017-06-20 20:50:51 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:50:51 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:50:51 --> Utf8 Class Initialized
INFO - 2017-06-20 20:50:51 --> URI Class Initialized
INFO - 2017-06-20 20:50:51 --> Router Class Initialized
INFO - 2017-06-20 20:50:51 --> Output Class Initialized
INFO - 2017-06-20 20:50:51 --> Security Class Initialized
DEBUG - 2017-06-20 20:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:50:51 --> Input Class Initialized
INFO - 2017-06-20 20:50:51 --> Language Class Initialized
INFO - 2017-06-20 20:50:51 --> Loader Class Initialized
INFO - 2017-06-20 20:50:51 --> Controller Class Initialized
INFO - 2017-06-20 20:50:51 --> Database Driver Class Initialized
INFO - 2017-06-20 20:50:51 --> Model Class Initialized
INFO - 2017-06-20 20:50:51 --> Helper loaded: form_helper
INFO - 2017-06-20 20:50:51 --> Helper loaded: url_helper
INFO - 2017-06-20 20:50:51 --> Model Class Initialized
INFO - 2017-06-20 20:50:51 --> Final output sent to browser
DEBUG - 2017-06-20 20:50:51 --> Total execution time: 0.0530
ERROR - 2017-06-20 20:53:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:53:26 --> Config Class Initialized
INFO - 2017-06-20 20:53:26 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:53:26 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:53:26 --> Utf8 Class Initialized
INFO - 2017-06-20 20:53:26 --> URI Class Initialized
INFO - 2017-06-20 20:53:26 --> Router Class Initialized
INFO - 2017-06-20 20:53:26 --> Output Class Initialized
INFO - 2017-06-20 20:53:26 --> Security Class Initialized
DEBUG - 2017-06-20 20:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:53:26 --> Input Class Initialized
INFO - 2017-06-20 20:53:26 --> Language Class Initialized
INFO - 2017-06-20 20:53:26 --> Loader Class Initialized
INFO - 2017-06-20 20:53:26 --> Controller Class Initialized
INFO - 2017-06-20 20:53:26 --> Database Driver Class Initialized
INFO - 2017-06-20 20:53:26 --> Model Class Initialized
INFO - 2017-06-20 20:53:26 --> Helper loaded: form_helper
INFO - 2017-06-20 20:53:26 --> Helper loaded: url_helper
INFO - 2017-06-20 20:53:26 --> Model Class Initialized
INFO - 2017-06-20 20:53:26 --> Final output sent to browser
DEBUG - 2017-06-20 20:53:26 --> Total execution time: 0.0650
ERROR - 2017-06-20 20:53:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:53:27 --> Config Class Initialized
INFO - 2017-06-20 20:53:27 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:53:27 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:53:27 --> Utf8 Class Initialized
INFO - 2017-06-20 20:53:27 --> URI Class Initialized
INFO - 2017-06-20 20:53:27 --> Router Class Initialized
INFO - 2017-06-20 20:53:27 --> Output Class Initialized
INFO - 2017-06-20 20:53:27 --> Security Class Initialized
DEBUG - 2017-06-20 20:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:53:27 --> Input Class Initialized
INFO - 2017-06-20 20:53:27 --> Language Class Initialized
INFO - 2017-06-20 20:53:27 --> Loader Class Initialized
INFO - 2017-06-20 20:53:27 --> Controller Class Initialized
INFO - 2017-06-20 20:53:27 --> Database Driver Class Initialized
INFO - 2017-06-20 20:53:27 --> Model Class Initialized
INFO - 2017-06-20 20:53:27 --> Helper loaded: form_helper
INFO - 2017-06-20 20:53:27 --> Helper loaded: url_helper
INFO - 2017-06-20 20:53:27 --> Model Class Initialized
INFO - 2017-06-20 20:53:27 --> Final output sent to browser
DEBUG - 2017-06-20 20:53:27 --> Total execution time: 0.0620
ERROR - 2017-06-20 20:53:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:53:29 --> Config Class Initialized
INFO - 2017-06-20 20:53:29 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:53:29 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:53:29 --> Utf8 Class Initialized
INFO - 2017-06-20 20:53:29 --> URI Class Initialized
INFO - 2017-06-20 20:53:29 --> Router Class Initialized
INFO - 2017-06-20 20:53:29 --> Output Class Initialized
INFO - 2017-06-20 20:53:29 --> Security Class Initialized
DEBUG - 2017-06-20 20:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:53:29 --> Input Class Initialized
INFO - 2017-06-20 20:53:29 --> Language Class Initialized
INFO - 2017-06-20 20:53:29 --> Loader Class Initialized
INFO - 2017-06-20 20:53:29 --> Controller Class Initialized
INFO - 2017-06-20 20:53:29 --> Database Driver Class Initialized
INFO - 2017-06-20 20:53:29 --> Model Class Initialized
INFO - 2017-06-20 20:53:29 --> Helper loaded: form_helper
INFO - 2017-06-20 20:53:29 --> Helper loaded: url_helper
INFO - 2017-06-20 20:53:29 --> Model Class Initialized
INFO - 2017-06-20 20:53:29 --> Final output sent to browser
DEBUG - 2017-06-20 20:53:29 --> Total execution time: 0.0600
ERROR - 2017-06-20 20:57:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:57:26 --> Config Class Initialized
INFO - 2017-06-20 20:57:26 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:57:26 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:57:26 --> Utf8 Class Initialized
INFO - 2017-06-20 20:57:26 --> URI Class Initialized
INFO - 2017-06-20 20:57:26 --> Router Class Initialized
INFO - 2017-06-20 20:57:26 --> Output Class Initialized
INFO - 2017-06-20 20:57:26 --> Security Class Initialized
DEBUG - 2017-06-20 20:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:57:26 --> Input Class Initialized
INFO - 2017-06-20 20:57:26 --> Language Class Initialized
INFO - 2017-06-20 20:57:26 --> Loader Class Initialized
INFO - 2017-06-20 20:57:26 --> Controller Class Initialized
INFO - 2017-06-20 20:57:26 --> Database Driver Class Initialized
INFO - 2017-06-20 20:57:26 --> Model Class Initialized
INFO - 2017-06-20 20:57:26 --> Helper loaded: form_helper
INFO - 2017-06-20 20:57:26 --> Helper loaded: url_helper
INFO - 2017-06-20 20:57:26 --> Model Class Initialized
INFO - 2017-06-20 20:57:26 --> Final output sent to browser
DEBUG - 2017-06-20 20:57:26 --> Total execution time: 0.0740
ERROR - 2017-06-20 20:57:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:57:26 --> Config Class Initialized
INFO - 2017-06-20 20:57:26 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:57:26 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:57:26 --> Utf8 Class Initialized
INFO - 2017-06-20 20:57:26 --> URI Class Initialized
INFO - 2017-06-20 20:57:26 --> Router Class Initialized
INFO - 2017-06-20 20:57:26 --> Output Class Initialized
INFO - 2017-06-20 20:57:26 --> Security Class Initialized
DEBUG - 2017-06-20 20:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:57:26 --> Input Class Initialized
INFO - 2017-06-20 20:57:26 --> Language Class Initialized
INFO - 2017-06-20 20:57:26 --> Loader Class Initialized
INFO - 2017-06-20 20:57:26 --> Controller Class Initialized
INFO - 2017-06-20 20:57:26 --> Database Driver Class Initialized
INFO - 2017-06-20 20:57:26 --> Model Class Initialized
INFO - 2017-06-20 20:57:26 --> Helper loaded: form_helper
INFO - 2017-06-20 20:57:26 --> Helper loaded: url_helper
INFO - 2017-06-20 20:57:26 --> Model Class Initialized
INFO - 2017-06-20 20:57:26 --> Final output sent to browser
DEBUG - 2017-06-20 20:57:26 --> Total execution time: 0.0530
ERROR - 2017-06-20 20:57:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 20:57:54 --> Config Class Initialized
INFO - 2017-06-20 20:57:54 --> Hooks Class Initialized
DEBUG - 2017-06-20 20:57:54 --> UTF-8 Support Enabled
INFO - 2017-06-20 20:57:54 --> Utf8 Class Initialized
INFO - 2017-06-20 20:57:54 --> URI Class Initialized
INFO - 2017-06-20 20:57:54 --> Router Class Initialized
INFO - 2017-06-20 20:57:54 --> Output Class Initialized
INFO - 2017-06-20 20:57:54 --> Security Class Initialized
DEBUG - 2017-06-20 20:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 20:57:54 --> Input Class Initialized
INFO - 2017-06-20 20:57:54 --> Language Class Initialized
INFO - 2017-06-20 20:57:54 --> Loader Class Initialized
INFO - 2017-06-20 20:57:54 --> Controller Class Initialized
INFO - 2017-06-20 20:57:54 --> Database Driver Class Initialized
INFO - 2017-06-20 20:57:54 --> Model Class Initialized
INFO - 2017-06-20 20:57:54 --> Helper loaded: form_helper
INFO - 2017-06-20 20:57:54 --> Helper loaded: url_helper
INFO - 2017-06-20 20:57:54 --> Model Class Initialized
INFO - 2017-06-20 20:57:54 --> Final output sent to browser
DEBUG - 2017-06-20 20:57:54 --> Total execution time: 0.0600
ERROR - 2017-06-20 21:03:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 21:03:00 --> Config Class Initialized
INFO - 2017-06-20 21:03:01 --> Hooks Class Initialized
DEBUG - 2017-06-20 21:03:01 --> UTF-8 Support Enabled
INFO - 2017-06-20 21:03:01 --> Utf8 Class Initialized
INFO - 2017-06-20 21:03:01 --> URI Class Initialized
INFO - 2017-06-20 21:03:01 --> Router Class Initialized
INFO - 2017-06-20 21:03:01 --> Output Class Initialized
INFO - 2017-06-20 21:03:01 --> Security Class Initialized
DEBUG - 2017-06-20 21:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 21:03:01 --> Input Class Initialized
INFO - 2017-06-20 21:03:01 --> Language Class Initialized
INFO - 2017-06-20 21:03:01 --> Loader Class Initialized
INFO - 2017-06-20 21:03:01 --> Controller Class Initialized
INFO - 2017-06-20 21:03:01 --> Database Driver Class Initialized
INFO - 2017-06-20 21:03:01 --> Model Class Initialized
INFO - 2017-06-20 21:03:01 --> Helper loaded: form_helper
INFO - 2017-06-20 21:03:01 --> Helper loaded: url_helper
INFO - 2017-06-20 21:03:01 --> Model Class Initialized
INFO - 2017-06-20 21:03:01 --> Final output sent to browser
DEBUG - 2017-06-20 21:03:01 --> Total execution time: 0.0600
ERROR - 2017-06-20 21:03:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 21:03:01 --> Config Class Initialized
INFO - 2017-06-20 21:03:01 --> Hooks Class Initialized
DEBUG - 2017-06-20 21:03:01 --> UTF-8 Support Enabled
INFO - 2017-06-20 21:03:01 --> Utf8 Class Initialized
INFO - 2017-06-20 21:03:01 --> URI Class Initialized
INFO - 2017-06-20 21:03:01 --> Router Class Initialized
INFO - 2017-06-20 21:03:01 --> Output Class Initialized
INFO - 2017-06-20 21:03:01 --> Security Class Initialized
DEBUG - 2017-06-20 21:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 21:03:01 --> Input Class Initialized
INFO - 2017-06-20 21:03:01 --> Language Class Initialized
INFO - 2017-06-20 21:03:01 --> Loader Class Initialized
INFO - 2017-06-20 21:03:01 --> Controller Class Initialized
INFO - 2017-06-20 21:03:01 --> Database Driver Class Initialized
INFO - 2017-06-20 21:03:01 --> Model Class Initialized
INFO - 2017-06-20 21:03:01 --> Helper loaded: form_helper
INFO - 2017-06-20 21:03:01 --> Helper loaded: url_helper
INFO - 2017-06-20 21:03:01 --> Model Class Initialized
INFO - 2017-06-20 21:03:01 --> Final output sent to browser
DEBUG - 2017-06-20 21:03:01 --> Total execution time: 0.0535
ERROR - 2017-06-20 21:03:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 21:03:04 --> Config Class Initialized
INFO - 2017-06-20 21:03:04 --> Hooks Class Initialized
DEBUG - 2017-06-20 21:03:04 --> UTF-8 Support Enabled
INFO - 2017-06-20 21:03:04 --> Utf8 Class Initialized
INFO - 2017-06-20 21:03:04 --> URI Class Initialized
INFO - 2017-06-20 21:03:04 --> Router Class Initialized
INFO - 2017-06-20 21:03:04 --> Output Class Initialized
INFO - 2017-06-20 21:03:04 --> Security Class Initialized
DEBUG - 2017-06-20 21:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 21:03:04 --> Input Class Initialized
INFO - 2017-06-20 21:03:04 --> Language Class Initialized
INFO - 2017-06-20 21:03:04 --> Loader Class Initialized
INFO - 2017-06-20 21:03:04 --> Controller Class Initialized
INFO - 2017-06-20 21:03:04 --> Database Driver Class Initialized
INFO - 2017-06-20 21:03:04 --> Model Class Initialized
INFO - 2017-06-20 21:03:04 --> Helper loaded: form_helper
INFO - 2017-06-20 21:03:04 --> Helper loaded: url_helper
INFO - 2017-06-20 21:03:04 --> Model Class Initialized
INFO - 2017-06-20 21:03:04 --> Final output sent to browser
DEBUG - 2017-06-20 21:03:04 --> Total execution time: 0.0510
ERROR - 2017-06-20 21:06:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 21:06:19 --> Config Class Initialized
INFO - 2017-06-20 21:06:19 --> Hooks Class Initialized
DEBUG - 2017-06-20 21:06:19 --> UTF-8 Support Enabled
INFO - 2017-06-20 21:06:19 --> Utf8 Class Initialized
INFO - 2017-06-20 21:06:19 --> URI Class Initialized
INFO - 2017-06-20 21:06:19 --> Router Class Initialized
INFO - 2017-06-20 21:06:19 --> Output Class Initialized
INFO - 2017-06-20 21:06:19 --> Security Class Initialized
DEBUG - 2017-06-20 21:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 21:06:19 --> Input Class Initialized
INFO - 2017-06-20 21:06:19 --> Language Class Initialized
INFO - 2017-06-20 21:06:19 --> Loader Class Initialized
INFO - 2017-06-20 21:06:19 --> Controller Class Initialized
INFO - 2017-06-20 21:06:19 --> Database Driver Class Initialized
INFO - 2017-06-20 21:06:19 --> Model Class Initialized
INFO - 2017-06-20 21:06:19 --> Helper loaded: form_helper
INFO - 2017-06-20 21:06:19 --> Helper loaded: url_helper
INFO - 2017-06-20 21:06:19 --> Model Class Initialized
INFO - 2017-06-20 21:06:19 --> Final output sent to browser
DEBUG - 2017-06-20 21:06:19 --> Total execution time: 0.0660
ERROR - 2017-06-20 21:06:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 21:06:20 --> Config Class Initialized
INFO - 2017-06-20 21:06:20 --> Hooks Class Initialized
DEBUG - 2017-06-20 21:06:20 --> UTF-8 Support Enabled
INFO - 2017-06-20 21:06:20 --> Utf8 Class Initialized
INFO - 2017-06-20 21:06:20 --> URI Class Initialized
INFO - 2017-06-20 21:06:20 --> Router Class Initialized
INFO - 2017-06-20 21:06:20 --> Output Class Initialized
INFO - 2017-06-20 21:06:20 --> Security Class Initialized
DEBUG - 2017-06-20 21:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 21:06:20 --> Input Class Initialized
INFO - 2017-06-20 21:06:20 --> Language Class Initialized
INFO - 2017-06-20 21:06:20 --> Loader Class Initialized
INFO - 2017-06-20 21:06:20 --> Controller Class Initialized
INFO - 2017-06-20 21:06:20 --> Database Driver Class Initialized
INFO - 2017-06-20 21:06:20 --> Model Class Initialized
INFO - 2017-06-20 21:06:20 --> Helper loaded: form_helper
INFO - 2017-06-20 21:06:20 --> Helper loaded: url_helper
INFO - 2017-06-20 21:06:20 --> Model Class Initialized
INFO - 2017-06-20 21:06:20 --> Final output sent to browser
DEBUG - 2017-06-20 21:06:20 --> Total execution time: 0.0480
ERROR - 2017-06-20 21:06:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-20 21:06:22 --> Config Class Initialized
INFO - 2017-06-20 21:06:22 --> Hooks Class Initialized
DEBUG - 2017-06-20 21:06:22 --> UTF-8 Support Enabled
INFO - 2017-06-20 21:06:22 --> Utf8 Class Initialized
INFO - 2017-06-20 21:06:22 --> URI Class Initialized
INFO - 2017-06-20 21:06:22 --> Router Class Initialized
INFO - 2017-06-20 21:06:22 --> Output Class Initialized
INFO - 2017-06-20 21:06:22 --> Security Class Initialized
DEBUG - 2017-06-20 21:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-20 21:06:22 --> Input Class Initialized
INFO - 2017-06-20 21:06:22 --> Language Class Initialized
INFO - 2017-06-20 21:06:22 --> Loader Class Initialized
INFO - 2017-06-20 21:06:22 --> Controller Class Initialized
INFO - 2017-06-20 21:06:22 --> Database Driver Class Initialized
INFO - 2017-06-20 21:06:22 --> Model Class Initialized
INFO - 2017-06-20 21:06:22 --> Helper loaded: form_helper
INFO - 2017-06-20 21:06:22 --> Helper loaded: url_helper
INFO - 2017-06-20 21:06:22 --> Model Class Initialized
INFO - 2017-06-20 21:06:22 --> Final output sent to browser
DEBUG - 2017-06-20 21:06:22 --> Total execution time: 0.0500
