<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-16 18:56:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 18:56:56 --> Config Class Initialized
INFO - 2018-08-16 18:56:56 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:56:56 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:56:56 --> Utf8 Class Initialized
INFO - 2018-08-16 18:56:56 --> URI Class Initialized
DEBUG - 2018-08-16 18:56:57 --> No URI present. Default controller set.
INFO - 2018-08-16 18:56:57 --> Router Class Initialized
INFO - 2018-08-16 18:56:57 --> Output Class Initialized
INFO - 2018-08-16 18:56:57 --> Security Class Initialized
DEBUG - 2018-08-16 18:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:56:57 --> Input Class Initialized
INFO - 2018-08-16 18:56:57 --> Language Class Initialized
INFO - 2018-08-16 18:56:57 --> Loader Class Initialized
INFO - 2018-08-16 18:56:57 --> Controller Class Initialized
INFO - 2018-08-16 18:56:57 --> Database Driver Class Initialized
INFO - 2018-08-16 18:56:57 --> Model Class Initialized
INFO - 2018-08-16 18:56:57 --> Helper loaded: url_helper
DEBUG - 2018-08-16 18:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:56:57 --> Model Class Initialized
INFO - 2018-08-16 18:56:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 18:56:57 --> Final output sent to browser
DEBUG - 2018-08-16 18:56:57 --> Total execution time: 0.6060
ERROR - 2018-08-16 18:56:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 18:56:57 --> Config Class Initialized
INFO - 2018-08-16 18:56:57 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:56:57 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:56:57 --> Utf8 Class Initialized
INFO - 2018-08-16 18:56:57 --> URI Class Initialized
DEBUG - 2018-08-16 18:56:57 --> No URI present. Default controller set.
INFO - 2018-08-16 18:56:57 --> Router Class Initialized
INFO - 2018-08-16 18:56:57 --> Output Class Initialized
INFO - 2018-08-16 18:56:57 --> Security Class Initialized
DEBUG - 2018-08-16 18:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:56:57 --> Input Class Initialized
INFO - 2018-08-16 18:56:57 --> Language Class Initialized
INFO - 2018-08-16 18:56:57 --> Loader Class Initialized
INFO - 2018-08-16 18:56:57 --> Controller Class Initialized
INFO - 2018-08-16 18:56:57 --> Database Driver Class Initialized
INFO - 2018-08-16 18:56:57 --> Model Class Initialized
INFO - 2018-08-16 18:56:57 --> Helper loaded: url_helper
DEBUG - 2018-08-16 18:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:56:57 --> Model Class Initialized
INFO - 2018-08-16 18:56:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 18:56:57 --> Final output sent to browser
DEBUG - 2018-08-16 18:56:57 --> Total execution time: 0.1495
ERROR - 2018-08-16 18:56:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 18:56:59 --> Config Class Initialized
INFO - 2018-08-16 18:56:59 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:56:59 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:56:59 --> Utf8 Class Initialized
INFO - 2018-08-16 18:56:59 --> URI Class Initialized
INFO - 2018-08-16 18:56:59 --> Router Class Initialized
INFO - 2018-08-16 18:56:59 --> Output Class Initialized
INFO - 2018-08-16 18:56:59 --> Security Class Initialized
DEBUG - 2018-08-16 18:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:56:59 --> Input Class Initialized
INFO - 2018-08-16 18:56:59 --> Language Class Initialized
INFO - 2018-08-16 18:56:59 --> Loader Class Initialized
INFO - 2018-08-16 18:56:59 --> Controller Class Initialized
INFO - 2018-08-16 18:56:59 --> Database Driver Class Initialized
INFO - 2018-08-16 18:56:59 --> Model Class Initialized
INFO - 2018-08-16 18:56:59 --> Helper loaded: url_helper
DEBUG - 2018-08-16 18:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:56:59 --> Model Class Initialized
ERROR - 2018-08-16 18:56:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 18:56:59 --> Config Class Initialized
INFO - 2018-08-16 18:56:59 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:56:59 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:56:59 --> Utf8 Class Initialized
INFO - 2018-08-16 18:56:59 --> URI Class Initialized
INFO - 2018-08-16 18:56:59 --> Router Class Initialized
INFO - 2018-08-16 18:56:59 --> Output Class Initialized
INFO - 2018-08-16 18:56:59 --> Security Class Initialized
DEBUG - 2018-08-16 18:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:56:59 --> Input Class Initialized
INFO - 2018-08-16 18:56:59 --> Language Class Initialized
INFO - 2018-08-16 18:56:59 --> Loader Class Initialized
INFO - 2018-08-16 18:56:59 --> Controller Class Initialized
INFO - 2018-08-16 18:56:59 --> Database Driver Class Initialized
INFO - 2018-08-16 18:56:59 --> Model Class Initialized
INFO - 2018-08-16 18:56:59 --> Helper loaded: url_helper
DEBUG - 2018-08-16 18:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:56:59 --> Model Class Initialized
INFO - 2018-08-16 18:56:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 18:56:59 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 18:56:59 --> Final output sent to browser
DEBUG - 2018-08-16 18:56:59 --> Total execution time: 0.1993
ERROR - 2018-08-16 18:57:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 18:57:01 --> Config Class Initialized
INFO - 2018-08-16 18:57:01 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:57:01 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:57:01 --> Utf8 Class Initialized
INFO - 2018-08-16 18:57:01 --> URI Class Initialized
INFO - 2018-08-16 18:57:01 --> Router Class Initialized
INFO - 2018-08-16 18:57:01 --> Output Class Initialized
INFO - 2018-08-16 18:57:01 --> Security Class Initialized
DEBUG - 2018-08-16 18:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:57:01 --> Input Class Initialized
INFO - 2018-08-16 18:57:01 --> Language Class Initialized
INFO - 2018-08-16 18:57:01 --> Loader Class Initialized
INFO - 2018-08-16 18:57:01 --> Controller Class Initialized
INFO - 2018-08-16 18:57:01 --> Database Driver Class Initialized
INFO - 2018-08-16 18:57:01 --> Model Class Initialized
INFO - 2018-08-16 18:57:01 --> Helper loaded: url_helper
DEBUG - 2018-08-16 18:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:57:01 --> Model Class Initialized
INFO - 2018-08-16 18:57:01 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 18:57:01 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 18:57:01 --> Final output sent to browser
DEBUG - 2018-08-16 18:57:01 --> Total execution time: 0.1870
ERROR - 2018-08-16 18:57:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 18:57:02 --> Config Class Initialized
INFO - 2018-08-16 18:57:02 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:57:02 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:57:02 --> Utf8 Class Initialized
INFO - 2018-08-16 18:57:02 --> URI Class Initialized
INFO - 2018-08-16 18:57:02 --> Router Class Initialized
INFO - 2018-08-16 18:57:02 --> Output Class Initialized
INFO - 2018-08-16 18:57:02 --> Security Class Initialized
DEBUG - 2018-08-16 18:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:57:02 --> Input Class Initialized
INFO - 2018-08-16 18:57:02 --> Language Class Initialized
INFO - 2018-08-16 18:57:02 --> Loader Class Initialized
INFO - 2018-08-16 18:57:02 --> Controller Class Initialized
INFO - 2018-08-16 18:57:02 --> Database Driver Class Initialized
INFO - 2018-08-16 18:57:02 --> Model Class Initialized
INFO - 2018-08-16 18:57:02 --> Helper loaded: url_helper
DEBUG - 2018-08-16 18:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:57:02 --> Model Class Initialized
ERROR - 2018-08-16 18:57:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 18:57:02 --> Config Class Initialized
INFO - 2018-08-16 18:57:02 --> Hooks Class Initialized
DEBUG - 2018-08-16 18:57:03 --> UTF-8 Support Enabled
INFO - 2018-08-16 18:57:03 --> Utf8 Class Initialized
INFO - 2018-08-16 18:57:03 --> URI Class Initialized
INFO - 2018-08-16 18:57:03 --> Router Class Initialized
INFO - 2018-08-16 18:57:03 --> Output Class Initialized
INFO - 2018-08-16 18:57:03 --> Security Class Initialized
DEBUG - 2018-08-16 18:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 18:57:03 --> Input Class Initialized
INFO - 2018-08-16 18:57:03 --> Language Class Initialized
INFO - 2018-08-16 18:57:03 --> Loader Class Initialized
INFO - 2018-08-16 18:57:03 --> Controller Class Initialized
INFO - 2018-08-16 18:57:03 --> Database Driver Class Initialized
INFO - 2018-08-16 18:57:03 --> Model Class Initialized
INFO - 2018-08-16 18:57:03 --> Helper loaded: url_helper
DEBUG - 2018-08-16 18:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 18:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 18:57:03 --> Model Class Initialized
INFO - 2018-08-16 18:57:03 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 18:57:03 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 18:57:03 --> Final output sent to browser
DEBUG - 2018-08-16 18:57:03 --> Total execution time: 0.1348
ERROR - 2018-08-16 19:00:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:00:17 --> Config Class Initialized
INFO - 2018-08-16 19:00:17 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:00:17 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:00:17 --> Utf8 Class Initialized
INFO - 2018-08-16 19:00:17 --> URI Class Initialized
INFO - 2018-08-16 19:00:17 --> Router Class Initialized
INFO - 2018-08-16 19:00:17 --> Output Class Initialized
INFO - 2018-08-16 19:00:17 --> Security Class Initialized
DEBUG - 2018-08-16 19:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:00:17 --> Input Class Initialized
INFO - 2018-08-16 19:00:17 --> Language Class Initialized
INFO - 2018-08-16 19:00:17 --> Loader Class Initialized
INFO - 2018-08-16 19:00:17 --> Controller Class Initialized
INFO - 2018-08-16 19:00:17 --> Database Driver Class Initialized
INFO - 2018-08-16 19:00:17 --> Model Class Initialized
INFO - 2018-08-16 19:00:17 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:00:17 --> Model Class Initialized
INFO - 2018-08-16 19:00:17 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:00:17 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:00:17 --> Final output sent to browser
DEBUG - 2018-08-16 19:00:17 --> Total execution time: 0.1368
ERROR - 2018-08-16 19:00:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:00:19 --> Config Class Initialized
INFO - 2018-08-16 19:00:19 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:00:19 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:00:19 --> Utf8 Class Initialized
INFO - 2018-08-16 19:00:19 --> URI Class Initialized
INFO - 2018-08-16 19:00:19 --> Router Class Initialized
INFO - 2018-08-16 19:00:19 --> Output Class Initialized
INFO - 2018-08-16 19:00:19 --> Security Class Initialized
DEBUG - 2018-08-16 19:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:00:19 --> Input Class Initialized
INFO - 2018-08-16 19:00:19 --> Language Class Initialized
INFO - 2018-08-16 19:00:19 --> Loader Class Initialized
INFO - 2018-08-16 19:00:19 --> Controller Class Initialized
INFO - 2018-08-16 19:00:19 --> Database Driver Class Initialized
INFO - 2018-08-16 19:00:19 --> Model Class Initialized
INFO - 2018-08-16 19:00:19 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:00:19 --> Model Class Initialized
INFO - 2018-08-16 19:00:19 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:00:19 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:00:19 --> Final output sent to browser
DEBUG - 2018-08-16 19:00:19 --> Total execution time: 0.1477
ERROR - 2018-08-16 19:02:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:02:13 --> Config Class Initialized
INFO - 2018-08-16 19:02:13 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:02:13 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:02:13 --> Utf8 Class Initialized
INFO - 2018-08-16 19:02:13 --> URI Class Initialized
INFO - 2018-08-16 19:02:13 --> Router Class Initialized
INFO - 2018-08-16 19:02:13 --> Output Class Initialized
INFO - 2018-08-16 19:02:13 --> Security Class Initialized
DEBUG - 2018-08-16 19:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:02:13 --> Input Class Initialized
INFO - 2018-08-16 19:02:13 --> Language Class Initialized
INFO - 2018-08-16 19:02:13 --> Loader Class Initialized
INFO - 2018-08-16 19:02:13 --> Controller Class Initialized
INFO - 2018-08-16 19:02:13 --> Database Driver Class Initialized
INFO - 2018-08-16 19:02:13 --> Model Class Initialized
INFO - 2018-08-16 19:02:13 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:02:13 --> Model Class Initialized
INFO - 2018-08-16 19:02:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:02:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:02:13 --> Final output sent to browser
DEBUG - 2018-08-16 19:02:13 --> Total execution time: 0.1539
ERROR - 2018-08-16 19:02:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:02:54 --> Config Class Initialized
INFO - 2018-08-16 19:02:54 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:02:54 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:02:54 --> Utf8 Class Initialized
INFO - 2018-08-16 19:02:54 --> URI Class Initialized
INFO - 2018-08-16 19:02:54 --> Router Class Initialized
INFO - 2018-08-16 19:02:54 --> Output Class Initialized
INFO - 2018-08-16 19:02:54 --> Security Class Initialized
DEBUG - 2018-08-16 19:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:02:54 --> Input Class Initialized
INFO - 2018-08-16 19:02:54 --> Language Class Initialized
INFO - 2018-08-16 19:02:54 --> Loader Class Initialized
INFO - 2018-08-16 19:02:54 --> Controller Class Initialized
INFO - 2018-08-16 19:02:54 --> Database Driver Class Initialized
INFO - 2018-08-16 19:02:54 --> Model Class Initialized
INFO - 2018-08-16 19:02:54 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:02:54 --> Model Class Initialized
INFO - 2018-08-16 19:02:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:02:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:02:54 --> Final output sent to browser
DEBUG - 2018-08-16 19:02:54 --> Total execution time: 0.1556
ERROR - 2018-08-16 19:03:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:03:04 --> Config Class Initialized
INFO - 2018-08-16 19:03:04 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:03:04 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:03:04 --> Utf8 Class Initialized
INFO - 2018-08-16 19:03:04 --> URI Class Initialized
INFO - 2018-08-16 19:03:04 --> Router Class Initialized
INFO - 2018-08-16 19:03:04 --> Output Class Initialized
INFO - 2018-08-16 19:03:04 --> Security Class Initialized
DEBUG - 2018-08-16 19:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:03:04 --> Input Class Initialized
INFO - 2018-08-16 19:03:04 --> Language Class Initialized
INFO - 2018-08-16 19:03:04 --> Loader Class Initialized
INFO - 2018-08-16 19:03:04 --> Controller Class Initialized
INFO - 2018-08-16 19:03:04 --> Database Driver Class Initialized
INFO - 2018-08-16 19:03:04 --> Model Class Initialized
INFO - 2018-08-16 19:03:04 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:03:04 --> Model Class Initialized
INFO - 2018-08-16 19:03:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:03:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:03:04 --> Final output sent to browser
DEBUG - 2018-08-16 19:03:04 --> Total execution time: 0.1449
ERROR - 2018-08-16 19:03:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:03:32 --> Config Class Initialized
INFO - 2018-08-16 19:03:32 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:03:32 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:03:32 --> Utf8 Class Initialized
INFO - 2018-08-16 19:03:32 --> URI Class Initialized
INFO - 2018-08-16 19:03:32 --> Router Class Initialized
INFO - 2018-08-16 19:03:32 --> Output Class Initialized
INFO - 2018-08-16 19:03:32 --> Security Class Initialized
DEBUG - 2018-08-16 19:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:03:32 --> Input Class Initialized
INFO - 2018-08-16 19:03:32 --> Language Class Initialized
INFO - 2018-08-16 19:03:32 --> Loader Class Initialized
INFO - 2018-08-16 19:03:32 --> Controller Class Initialized
INFO - 2018-08-16 19:03:32 --> Database Driver Class Initialized
INFO - 2018-08-16 19:03:32 --> Model Class Initialized
INFO - 2018-08-16 19:03:32 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:03:32 --> Model Class Initialized
INFO - 2018-08-16 19:03:32 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:03:32 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 19:03:32 --> Final output sent to browser
DEBUG - 2018-08-16 19:03:32 --> Total execution time: 0.1401
ERROR - 2018-08-16 19:03:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:03:35 --> Config Class Initialized
INFO - 2018-08-16 19:03:35 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:03:35 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:03:35 --> Utf8 Class Initialized
INFO - 2018-08-16 19:03:35 --> URI Class Initialized
INFO - 2018-08-16 19:03:35 --> Router Class Initialized
INFO - 2018-08-16 19:03:35 --> Output Class Initialized
INFO - 2018-08-16 19:03:35 --> Security Class Initialized
DEBUG - 2018-08-16 19:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:03:35 --> Input Class Initialized
INFO - 2018-08-16 19:03:35 --> Language Class Initialized
INFO - 2018-08-16 19:03:35 --> Loader Class Initialized
INFO - 2018-08-16 19:03:35 --> Controller Class Initialized
INFO - 2018-08-16 19:03:35 --> Database Driver Class Initialized
INFO - 2018-08-16 19:03:35 --> Model Class Initialized
INFO - 2018-08-16 19:03:35 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:03:35 --> Model Class Initialized
INFO - 2018-08-16 19:03:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:03:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-08-16 19:03:35 --> Final output sent to browser
DEBUG - 2018-08-16 19:03:35 --> Total execution time: 0.1852
ERROR - 2018-08-16 19:12:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:12:42 --> Config Class Initialized
INFO - 2018-08-16 19:12:42 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:12:42 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:12:42 --> Utf8 Class Initialized
INFO - 2018-08-16 19:12:42 --> URI Class Initialized
INFO - 2018-08-16 19:12:42 --> Router Class Initialized
INFO - 2018-08-16 19:12:42 --> Output Class Initialized
INFO - 2018-08-16 19:12:42 --> Security Class Initialized
DEBUG - 2018-08-16 19:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:12:42 --> Input Class Initialized
INFO - 2018-08-16 19:12:42 --> Language Class Initialized
INFO - 2018-08-16 19:12:42 --> Loader Class Initialized
INFO - 2018-08-16 19:12:42 --> Controller Class Initialized
INFO - 2018-08-16 19:12:42 --> Database Driver Class Initialized
INFO - 2018-08-16 19:12:42 --> Model Class Initialized
INFO - 2018-08-16 19:12:42 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:12:42 --> Model Class Initialized
INFO - 2018-08-16 19:12:42 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:12:42 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:12:42 --> Final output sent to browser
DEBUG - 2018-08-16 19:12:42 --> Total execution time: 0.1442
ERROR - 2018-08-16 19:12:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:12:52 --> Config Class Initialized
INFO - 2018-08-16 19:12:52 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:12:52 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:12:52 --> Utf8 Class Initialized
INFO - 2018-08-16 19:12:52 --> URI Class Initialized
INFO - 2018-08-16 19:12:52 --> Router Class Initialized
INFO - 2018-08-16 19:12:52 --> Output Class Initialized
INFO - 2018-08-16 19:12:52 --> Security Class Initialized
DEBUG - 2018-08-16 19:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:12:52 --> Input Class Initialized
INFO - 2018-08-16 19:12:52 --> Language Class Initialized
INFO - 2018-08-16 19:12:52 --> Loader Class Initialized
INFO - 2018-08-16 19:12:52 --> Controller Class Initialized
INFO - 2018-08-16 19:12:53 --> Database Driver Class Initialized
INFO - 2018-08-16 19:12:53 --> Model Class Initialized
INFO - 2018-08-16 19:12:53 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:12:53 --> Model Class Initialized
INFO - 2018-08-16 19:12:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:12:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:12:53 --> Final output sent to browser
DEBUG - 2018-08-16 19:12:53 --> Total execution time: 0.1480
ERROR - 2018-08-16 19:13:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:13:09 --> Config Class Initialized
INFO - 2018-08-16 19:13:09 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:13:09 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:13:09 --> Utf8 Class Initialized
INFO - 2018-08-16 19:13:09 --> URI Class Initialized
INFO - 2018-08-16 19:13:09 --> Router Class Initialized
INFO - 2018-08-16 19:13:09 --> Output Class Initialized
INFO - 2018-08-16 19:13:09 --> Security Class Initialized
DEBUG - 2018-08-16 19:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:13:09 --> Input Class Initialized
INFO - 2018-08-16 19:13:09 --> Language Class Initialized
INFO - 2018-08-16 19:13:09 --> Loader Class Initialized
INFO - 2018-08-16 19:13:09 --> Controller Class Initialized
INFO - 2018-08-16 19:13:09 --> Database Driver Class Initialized
INFO - 2018-08-16 19:13:09 --> Model Class Initialized
INFO - 2018-08-16 19:13:09 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:13:09 --> Model Class Initialized
INFO - 2018-08-16 19:13:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:13:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:13:09 --> Final output sent to browser
DEBUG - 2018-08-16 19:13:09 --> Total execution time: 0.1353
ERROR - 2018-08-16 19:13:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:13:16 --> Config Class Initialized
INFO - 2018-08-16 19:13:16 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:13:16 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:13:16 --> Utf8 Class Initialized
INFO - 2018-08-16 19:13:16 --> URI Class Initialized
INFO - 2018-08-16 19:13:16 --> Router Class Initialized
INFO - 2018-08-16 19:13:16 --> Output Class Initialized
INFO - 2018-08-16 19:13:16 --> Security Class Initialized
DEBUG - 2018-08-16 19:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:13:16 --> Input Class Initialized
INFO - 2018-08-16 19:13:16 --> Language Class Initialized
INFO - 2018-08-16 19:13:16 --> Loader Class Initialized
INFO - 2018-08-16 19:13:16 --> Controller Class Initialized
INFO - 2018-08-16 19:13:16 --> Database Driver Class Initialized
INFO - 2018-08-16 19:13:16 --> Model Class Initialized
INFO - 2018-08-16 19:13:16 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:13:16 --> Model Class Initialized
INFO - 2018-08-16 19:13:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:13:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:13:16 --> Final output sent to browser
DEBUG - 2018-08-16 19:13:16 --> Total execution time: 0.1378
ERROR - 2018-08-16 19:14:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:14:05 --> Config Class Initialized
INFO - 2018-08-16 19:14:05 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:14:05 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:14:05 --> Utf8 Class Initialized
INFO - 2018-08-16 19:14:05 --> URI Class Initialized
INFO - 2018-08-16 19:14:05 --> Router Class Initialized
INFO - 2018-08-16 19:14:05 --> Output Class Initialized
INFO - 2018-08-16 19:14:05 --> Security Class Initialized
DEBUG - 2018-08-16 19:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:14:05 --> Input Class Initialized
INFO - 2018-08-16 19:14:05 --> Language Class Initialized
INFO - 2018-08-16 19:14:05 --> Loader Class Initialized
INFO - 2018-08-16 19:14:05 --> Controller Class Initialized
INFO - 2018-08-16 19:14:05 --> Database Driver Class Initialized
INFO - 2018-08-16 19:14:05 --> Model Class Initialized
INFO - 2018-08-16 19:14:05 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:14:05 --> Model Class Initialized
INFO - 2018-08-16 19:14:05 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:14:05 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:14:05 --> Final output sent to browser
DEBUG - 2018-08-16 19:14:05 --> Total execution time: 0.1356
ERROR - 2018-08-16 19:14:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:14:09 --> Config Class Initialized
INFO - 2018-08-16 19:14:09 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:14:09 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:14:09 --> Utf8 Class Initialized
INFO - 2018-08-16 19:14:09 --> URI Class Initialized
INFO - 2018-08-16 19:14:09 --> Router Class Initialized
INFO - 2018-08-16 19:14:09 --> Output Class Initialized
INFO - 2018-08-16 19:14:09 --> Security Class Initialized
DEBUG - 2018-08-16 19:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:14:09 --> Input Class Initialized
INFO - 2018-08-16 19:14:09 --> Language Class Initialized
INFO - 2018-08-16 19:14:09 --> Loader Class Initialized
INFO - 2018-08-16 19:14:09 --> Controller Class Initialized
INFO - 2018-08-16 19:14:09 --> Database Driver Class Initialized
INFO - 2018-08-16 19:14:09 --> Model Class Initialized
INFO - 2018-08-16 19:14:09 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:14:09 --> Model Class Initialized
INFO - 2018-08-16 19:14:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:14:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:14:09 --> Final output sent to browser
DEBUG - 2018-08-16 19:14:09 --> Total execution time: 0.1477
ERROR - 2018-08-16 19:14:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:14:14 --> Config Class Initialized
INFO - 2018-08-16 19:14:14 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:14:14 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:14:14 --> Utf8 Class Initialized
INFO - 2018-08-16 19:14:14 --> URI Class Initialized
INFO - 2018-08-16 19:14:14 --> Router Class Initialized
INFO - 2018-08-16 19:14:14 --> Output Class Initialized
INFO - 2018-08-16 19:14:14 --> Security Class Initialized
DEBUG - 2018-08-16 19:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:14:14 --> Input Class Initialized
INFO - 2018-08-16 19:14:14 --> Language Class Initialized
INFO - 2018-08-16 19:14:14 --> Loader Class Initialized
INFO - 2018-08-16 19:14:14 --> Controller Class Initialized
INFO - 2018-08-16 19:14:14 --> Database Driver Class Initialized
INFO - 2018-08-16 19:14:14 --> Model Class Initialized
INFO - 2018-08-16 19:14:14 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:14:14 --> Model Class Initialized
INFO - 2018-08-16 19:14:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:14:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:14:14 --> Final output sent to browser
DEBUG - 2018-08-16 19:14:14 --> Total execution time: 0.1442
ERROR - 2018-08-16 19:14:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:14:26 --> Config Class Initialized
INFO - 2018-08-16 19:14:26 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:14:26 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:14:26 --> Utf8 Class Initialized
INFO - 2018-08-16 19:14:26 --> URI Class Initialized
DEBUG - 2018-08-16 19:14:26 --> No URI present. Default controller set.
INFO - 2018-08-16 19:14:26 --> Router Class Initialized
INFO - 2018-08-16 19:14:26 --> Output Class Initialized
INFO - 2018-08-16 19:14:26 --> Security Class Initialized
DEBUG - 2018-08-16 19:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:14:26 --> Input Class Initialized
INFO - 2018-08-16 19:14:26 --> Language Class Initialized
INFO - 2018-08-16 19:14:26 --> Loader Class Initialized
INFO - 2018-08-16 19:14:26 --> Controller Class Initialized
INFO - 2018-08-16 19:14:26 --> Database Driver Class Initialized
INFO - 2018-08-16 19:14:26 --> Model Class Initialized
INFO - 2018-08-16 19:14:26 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:14:26 --> Model Class Initialized
INFO - 2018-08-16 19:14:26 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 19:14:26 --> Final output sent to browser
DEBUG - 2018-08-16 19:14:26 --> Total execution time: 0.1568
ERROR - 2018-08-16 19:14:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:14:28 --> Config Class Initialized
INFO - 2018-08-16 19:14:28 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:14:28 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:14:28 --> Utf8 Class Initialized
INFO - 2018-08-16 19:14:28 --> URI Class Initialized
INFO - 2018-08-16 19:14:28 --> Router Class Initialized
INFO - 2018-08-16 19:14:28 --> Output Class Initialized
INFO - 2018-08-16 19:14:28 --> Security Class Initialized
DEBUG - 2018-08-16 19:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:14:28 --> Input Class Initialized
INFO - 2018-08-16 19:14:28 --> Language Class Initialized
INFO - 2018-08-16 19:14:28 --> Loader Class Initialized
INFO - 2018-08-16 19:14:28 --> Controller Class Initialized
INFO - 2018-08-16 19:14:28 --> Database Driver Class Initialized
INFO - 2018-08-16 19:14:28 --> Model Class Initialized
INFO - 2018-08-16 19:14:28 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:14:28 --> Model Class Initialized
ERROR - 2018-08-16 19:14:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:14:28 --> Config Class Initialized
INFO - 2018-08-16 19:14:28 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:14:28 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:14:28 --> Utf8 Class Initialized
INFO - 2018-08-16 19:14:28 --> URI Class Initialized
INFO - 2018-08-16 19:14:28 --> Router Class Initialized
INFO - 2018-08-16 19:14:28 --> Output Class Initialized
INFO - 2018-08-16 19:14:28 --> Security Class Initialized
DEBUG - 2018-08-16 19:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:14:28 --> Input Class Initialized
INFO - 2018-08-16 19:14:28 --> Language Class Initialized
INFO - 2018-08-16 19:14:28 --> Loader Class Initialized
INFO - 2018-08-16 19:14:28 --> Controller Class Initialized
INFO - 2018-08-16 19:14:28 --> Database Driver Class Initialized
INFO - 2018-08-16 19:14:28 --> Model Class Initialized
INFO - 2018-08-16 19:14:28 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:14:28 --> Model Class Initialized
INFO - 2018-08-16 19:14:28 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:14:28 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 19:14:28 --> Final output sent to browser
DEBUG - 2018-08-16 19:14:28 --> Total execution time: 0.1391
ERROR - 2018-08-16 19:14:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:14:31 --> Config Class Initialized
INFO - 2018-08-16 19:14:31 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:14:31 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:14:31 --> Utf8 Class Initialized
INFO - 2018-08-16 19:14:31 --> URI Class Initialized
INFO - 2018-08-16 19:14:31 --> Router Class Initialized
INFO - 2018-08-16 19:14:31 --> Output Class Initialized
INFO - 2018-08-16 19:14:31 --> Security Class Initialized
DEBUG - 2018-08-16 19:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:14:31 --> Input Class Initialized
INFO - 2018-08-16 19:14:31 --> Language Class Initialized
INFO - 2018-08-16 19:14:31 --> Loader Class Initialized
INFO - 2018-08-16 19:14:31 --> Controller Class Initialized
INFO - 2018-08-16 19:14:31 --> Database Driver Class Initialized
INFO - 2018-08-16 19:14:31 --> Model Class Initialized
INFO - 2018-08-16 19:14:31 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:14:31 --> Model Class Initialized
INFO - 2018-08-16 19:14:31 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:14:31 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:14:31 --> Final output sent to browser
DEBUG - 2018-08-16 19:14:31 --> Total execution time: 0.1642
ERROR - 2018-08-16 19:15:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:15:00 --> Config Class Initialized
INFO - 2018-08-16 19:15:00 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:15:00 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:15:00 --> Utf8 Class Initialized
INFO - 2018-08-16 19:15:00 --> URI Class Initialized
INFO - 2018-08-16 19:15:00 --> Router Class Initialized
INFO - 2018-08-16 19:15:00 --> Output Class Initialized
INFO - 2018-08-16 19:15:00 --> Security Class Initialized
DEBUG - 2018-08-16 19:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:15:00 --> Input Class Initialized
INFO - 2018-08-16 19:15:00 --> Language Class Initialized
INFO - 2018-08-16 19:15:00 --> Loader Class Initialized
INFO - 2018-08-16 19:15:00 --> Controller Class Initialized
INFO - 2018-08-16 19:15:00 --> Database Driver Class Initialized
INFO - 2018-08-16 19:15:00 --> Model Class Initialized
INFO - 2018-08-16 19:15:00 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:15:00 --> Model Class Initialized
INFO - 2018-08-16 19:15:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:15:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:15:00 --> Final output sent to browser
DEBUG - 2018-08-16 19:15:00 --> Total execution time: 0.1546
ERROR - 2018-08-16 19:15:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:15:14 --> Config Class Initialized
INFO - 2018-08-16 19:15:14 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:15:14 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:15:14 --> Utf8 Class Initialized
INFO - 2018-08-16 19:15:14 --> URI Class Initialized
INFO - 2018-08-16 19:15:14 --> Router Class Initialized
INFO - 2018-08-16 19:15:14 --> Output Class Initialized
INFO - 2018-08-16 19:15:14 --> Security Class Initialized
DEBUG - 2018-08-16 19:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:15:14 --> Input Class Initialized
INFO - 2018-08-16 19:15:14 --> Language Class Initialized
INFO - 2018-08-16 19:15:14 --> Loader Class Initialized
INFO - 2018-08-16 19:15:14 --> Controller Class Initialized
INFO - 2018-08-16 19:15:14 --> Database Driver Class Initialized
INFO - 2018-08-16 19:15:14 --> Model Class Initialized
INFO - 2018-08-16 19:15:14 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:15:14 --> Model Class Initialized
INFO - 2018-08-16 19:15:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:15:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:15:14 --> Final output sent to browser
DEBUG - 2018-08-16 19:15:14 --> Total execution time: 0.1418
ERROR - 2018-08-16 19:15:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:15:16 --> Config Class Initialized
INFO - 2018-08-16 19:15:16 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:15:16 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:15:16 --> Utf8 Class Initialized
INFO - 2018-08-16 19:15:16 --> URI Class Initialized
INFO - 2018-08-16 19:15:16 --> Router Class Initialized
INFO - 2018-08-16 19:15:16 --> Output Class Initialized
INFO - 2018-08-16 19:15:16 --> Security Class Initialized
DEBUG - 2018-08-16 19:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:15:16 --> Input Class Initialized
INFO - 2018-08-16 19:15:16 --> Language Class Initialized
INFO - 2018-08-16 19:15:16 --> Loader Class Initialized
INFO - 2018-08-16 19:15:16 --> Controller Class Initialized
INFO - 2018-08-16 19:15:16 --> Database Driver Class Initialized
INFO - 2018-08-16 19:15:16 --> Model Class Initialized
INFO - 2018-08-16 19:15:16 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:15:16 --> Model Class Initialized
INFO - 2018-08-16 19:15:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:15:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:15:16 --> Final output sent to browser
DEBUG - 2018-08-16 19:15:16 --> Total execution time: 0.1590
ERROR - 2018-08-16 19:15:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:15:17 --> Config Class Initialized
INFO - 2018-08-16 19:15:17 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:15:17 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:15:17 --> Utf8 Class Initialized
INFO - 2018-08-16 19:15:17 --> URI Class Initialized
INFO - 2018-08-16 19:15:17 --> Router Class Initialized
INFO - 2018-08-16 19:15:17 --> Output Class Initialized
INFO - 2018-08-16 19:15:17 --> Security Class Initialized
DEBUG - 2018-08-16 19:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:15:17 --> Input Class Initialized
INFO - 2018-08-16 19:15:17 --> Language Class Initialized
INFO - 2018-08-16 19:15:17 --> Loader Class Initialized
INFO - 2018-08-16 19:15:17 --> Controller Class Initialized
INFO - 2018-08-16 19:15:17 --> Database Driver Class Initialized
INFO - 2018-08-16 19:15:17 --> Model Class Initialized
INFO - 2018-08-16 19:15:17 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:15:17 --> Model Class Initialized
INFO - 2018-08-16 19:15:17 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:15:17 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 19:15:17 --> Final output sent to browser
DEBUG - 2018-08-16 19:15:17 --> Total execution time: 0.1557
ERROR - 2018-08-16 19:15:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:15:18 --> Config Class Initialized
INFO - 2018-08-16 19:15:18 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:15:18 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:15:18 --> Utf8 Class Initialized
INFO - 2018-08-16 19:15:18 --> URI Class Initialized
INFO - 2018-08-16 19:15:18 --> Router Class Initialized
INFO - 2018-08-16 19:15:18 --> Output Class Initialized
INFO - 2018-08-16 19:15:18 --> Security Class Initialized
DEBUG - 2018-08-16 19:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:15:18 --> Input Class Initialized
INFO - 2018-08-16 19:15:18 --> Language Class Initialized
INFO - 2018-08-16 19:15:18 --> Loader Class Initialized
INFO - 2018-08-16 19:15:18 --> Controller Class Initialized
INFO - 2018-08-16 19:15:18 --> Database Driver Class Initialized
INFO - 2018-08-16 19:15:18 --> Model Class Initialized
INFO - 2018-08-16 19:15:18 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:15:18 --> Model Class Initialized
INFO - 2018-08-16 19:15:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:15:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:15:18 --> Final output sent to browser
DEBUG - 2018-08-16 19:15:18 --> Total execution time: 0.1628
ERROR - 2018-08-16 19:16:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:16:40 --> Config Class Initialized
INFO - 2018-08-16 19:16:40 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:16:40 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:16:40 --> Utf8 Class Initialized
INFO - 2018-08-16 19:16:40 --> URI Class Initialized
INFO - 2018-08-16 19:16:40 --> Router Class Initialized
INFO - 2018-08-16 19:16:40 --> Output Class Initialized
INFO - 2018-08-16 19:16:40 --> Security Class Initialized
DEBUG - 2018-08-16 19:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:16:40 --> Input Class Initialized
INFO - 2018-08-16 19:16:40 --> Language Class Initialized
INFO - 2018-08-16 19:16:40 --> Loader Class Initialized
INFO - 2018-08-16 19:16:40 --> Controller Class Initialized
INFO - 2018-08-16 19:16:40 --> Database Driver Class Initialized
INFO - 2018-08-16 19:16:40 --> Model Class Initialized
INFO - 2018-08-16 19:16:40 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:16:40 --> Model Class Initialized
INFO - 2018-08-16 19:16:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:16:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:16:40 --> Final output sent to browser
DEBUG - 2018-08-16 19:16:40 --> Total execution time: 0.1506
ERROR - 2018-08-16 19:25:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:25:33 --> Config Class Initialized
INFO - 2018-08-16 19:25:33 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:25:33 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:25:33 --> Utf8 Class Initialized
INFO - 2018-08-16 19:25:33 --> URI Class Initialized
INFO - 2018-08-16 19:25:33 --> Router Class Initialized
INFO - 2018-08-16 19:25:33 --> Output Class Initialized
INFO - 2018-08-16 19:25:33 --> Security Class Initialized
DEBUG - 2018-08-16 19:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:25:33 --> Input Class Initialized
INFO - 2018-08-16 19:25:33 --> Language Class Initialized
INFO - 2018-08-16 19:25:33 --> Loader Class Initialized
INFO - 2018-08-16 19:25:33 --> Controller Class Initialized
INFO - 2018-08-16 19:25:33 --> Database Driver Class Initialized
INFO - 2018-08-16 19:25:33 --> Model Class Initialized
INFO - 2018-08-16 19:25:33 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:25:33 --> Model Class Initialized
INFO - 2018-08-16 19:25:33 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:25:33 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:25:33 --> Final output sent to browser
DEBUG - 2018-08-16 19:25:33 --> Total execution time: 0.1548
ERROR - 2018-08-16 19:25:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:25:37 --> Config Class Initialized
INFO - 2018-08-16 19:25:37 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:25:37 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:25:37 --> Utf8 Class Initialized
INFO - 2018-08-16 19:25:37 --> URI Class Initialized
INFO - 2018-08-16 19:25:37 --> Router Class Initialized
INFO - 2018-08-16 19:25:37 --> Output Class Initialized
INFO - 2018-08-16 19:25:37 --> Security Class Initialized
DEBUG - 2018-08-16 19:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:25:37 --> Input Class Initialized
INFO - 2018-08-16 19:25:37 --> Language Class Initialized
INFO - 2018-08-16 19:25:37 --> Loader Class Initialized
INFO - 2018-08-16 19:25:37 --> Controller Class Initialized
INFO - 2018-08-16 19:25:37 --> Database Driver Class Initialized
INFO - 2018-08-16 19:25:37 --> Model Class Initialized
INFO - 2018-08-16 19:25:37 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:25:37 --> Model Class Initialized
INFO - 2018-08-16 19:25:37 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:25:37 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:25:37 --> Final output sent to browser
DEBUG - 2018-08-16 19:25:37 --> Total execution time: 0.1537
ERROR - 2018-08-16 19:26:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:26:04 --> Config Class Initialized
INFO - 2018-08-16 19:26:04 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:26:04 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:26:04 --> Utf8 Class Initialized
INFO - 2018-08-16 19:26:04 --> URI Class Initialized
INFO - 2018-08-16 19:26:04 --> Router Class Initialized
INFO - 2018-08-16 19:26:04 --> Output Class Initialized
INFO - 2018-08-16 19:26:04 --> Security Class Initialized
DEBUG - 2018-08-16 19:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:26:04 --> Input Class Initialized
INFO - 2018-08-16 19:26:04 --> Language Class Initialized
INFO - 2018-08-16 19:26:04 --> Loader Class Initialized
INFO - 2018-08-16 19:26:04 --> Controller Class Initialized
INFO - 2018-08-16 19:26:04 --> Database Driver Class Initialized
INFO - 2018-08-16 19:26:04 --> Model Class Initialized
INFO - 2018-08-16 19:26:04 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:26:04 --> Model Class Initialized
INFO - 2018-08-16 19:26:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:26:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:26:04 --> Final output sent to browser
DEBUG - 2018-08-16 19:26:04 --> Total execution time: 0.1666
ERROR - 2018-08-16 19:30:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:30:54 --> Config Class Initialized
INFO - 2018-08-16 19:30:54 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:30:54 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:30:54 --> Utf8 Class Initialized
INFO - 2018-08-16 19:30:54 --> URI Class Initialized
INFO - 2018-08-16 19:30:54 --> Router Class Initialized
INFO - 2018-08-16 19:30:54 --> Output Class Initialized
INFO - 2018-08-16 19:30:54 --> Security Class Initialized
DEBUG - 2018-08-16 19:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:30:54 --> Input Class Initialized
INFO - 2018-08-16 19:30:54 --> Language Class Initialized
INFO - 2018-08-16 19:30:54 --> Loader Class Initialized
INFO - 2018-08-16 19:30:54 --> Controller Class Initialized
INFO - 2018-08-16 19:30:54 --> Database Driver Class Initialized
INFO - 2018-08-16 19:30:54 --> Model Class Initialized
INFO - 2018-08-16 19:30:54 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:30:54 --> Model Class Initialized
INFO - 2018-08-16 19:30:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 19:30:54 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\davidhood\application\views\user.php 119
INFO - 2018-08-16 19:30:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:30:54 --> Final output sent to browser
DEBUG - 2018-08-16 19:30:54 --> Total execution time: 0.2043
ERROR - 2018-08-16 19:33:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:33:04 --> Config Class Initialized
INFO - 2018-08-16 19:33:04 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:33:04 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:33:04 --> Utf8 Class Initialized
INFO - 2018-08-16 19:33:04 --> URI Class Initialized
INFO - 2018-08-16 19:33:04 --> Router Class Initialized
INFO - 2018-08-16 19:33:04 --> Output Class Initialized
INFO - 2018-08-16 19:33:04 --> Security Class Initialized
DEBUG - 2018-08-16 19:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:33:04 --> Input Class Initialized
INFO - 2018-08-16 19:33:04 --> Language Class Initialized
INFO - 2018-08-16 19:33:04 --> Loader Class Initialized
INFO - 2018-08-16 19:33:04 --> Controller Class Initialized
INFO - 2018-08-16 19:33:04 --> Database Driver Class Initialized
INFO - 2018-08-16 19:33:04 --> Model Class Initialized
INFO - 2018-08-16 19:33:04 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:33:04 --> Model Class Initialized
INFO - 2018-08-16 19:33:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 19:33:04 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\davidhood\application\views\user.php 144
INFO - 2018-08-16 19:33:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:33:04 --> Final output sent to browser
DEBUG - 2018-08-16 19:33:04 --> Total execution time: 0.1560
ERROR - 2018-08-16 19:35:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:35:48 --> Config Class Initialized
INFO - 2018-08-16 19:35:48 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:35:48 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:35:48 --> Utf8 Class Initialized
INFO - 2018-08-16 19:35:48 --> URI Class Initialized
INFO - 2018-08-16 19:35:48 --> Router Class Initialized
INFO - 2018-08-16 19:35:48 --> Output Class Initialized
INFO - 2018-08-16 19:35:48 --> Security Class Initialized
DEBUG - 2018-08-16 19:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:35:48 --> Input Class Initialized
INFO - 2018-08-16 19:35:48 --> Language Class Initialized
INFO - 2018-08-16 19:35:48 --> Loader Class Initialized
INFO - 2018-08-16 19:35:48 --> Controller Class Initialized
INFO - 2018-08-16 19:35:48 --> Database Driver Class Initialized
INFO - 2018-08-16 19:35:48 --> Model Class Initialized
INFO - 2018-08-16 19:35:48 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:35:48 --> Model Class Initialized
INFO - 2018-08-16 19:35:48 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 19:35:48 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\davidhood\application\views\user.php 146
INFO - 2018-08-16 19:35:48 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:35:48 --> Final output sent to browser
DEBUG - 2018-08-16 19:35:48 --> Total execution time: 0.1581
ERROR - 2018-08-16 19:37:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:37:29 --> Config Class Initialized
INFO - 2018-08-16 19:37:29 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:37:29 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:37:29 --> Utf8 Class Initialized
INFO - 2018-08-16 19:37:29 --> URI Class Initialized
INFO - 2018-08-16 19:37:29 --> Router Class Initialized
INFO - 2018-08-16 19:37:29 --> Output Class Initialized
INFO - 2018-08-16 19:37:29 --> Security Class Initialized
DEBUG - 2018-08-16 19:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:37:29 --> Input Class Initialized
INFO - 2018-08-16 19:37:29 --> Language Class Initialized
INFO - 2018-08-16 19:37:29 --> Loader Class Initialized
INFO - 2018-08-16 19:37:29 --> Controller Class Initialized
INFO - 2018-08-16 19:37:29 --> Database Driver Class Initialized
INFO - 2018-08-16 19:37:29 --> Model Class Initialized
INFO - 2018-08-16 19:37:29 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:37:29 --> Model Class Initialized
INFO - 2018-08-16 19:37:29 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 19:37:29 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\davidhood\application\views\user.php 146
INFO - 2018-08-16 19:37:29 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:37:29 --> Final output sent to browser
DEBUG - 2018-08-16 19:37:29 --> Total execution time: 0.1718
ERROR - 2018-08-16 19:37:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:37:49 --> Config Class Initialized
INFO - 2018-08-16 19:37:49 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:37:49 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:37:49 --> Utf8 Class Initialized
INFO - 2018-08-16 19:37:49 --> URI Class Initialized
INFO - 2018-08-16 19:37:49 --> Router Class Initialized
INFO - 2018-08-16 19:37:49 --> Output Class Initialized
INFO - 2018-08-16 19:37:49 --> Security Class Initialized
DEBUG - 2018-08-16 19:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:37:49 --> Input Class Initialized
INFO - 2018-08-16 19:37:49 --> Language Class Initialized
INFO - 2018-08-16 19:37:49 --> Loader Class Initialized
INFO - 2018-08-16 19:37:49 --> Controller Class Initialized
INFO - 2018-08-16 19:37:49 --> Database Driver Class Initialized
INFO - 2018-08-16 19:37:49 --> Model Class Initialized
INFO - 2018-08-16 19:37:49 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:37:49 --> Model Class Initialized
ERROR - 2018-08-16 19:37:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:37:49 --> Config Class Initialized
INFO - 2018-08-16 19:37:49 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:37:49 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:37:49 --> Utf8 Class Initialized
INFO - 2018-08-16 19:37:49 --> URI Class Initialized
INFO - 2018-08-16 19:37:49 --> Router Class Initialized
INFO - 2018-08-16 19:37:49 --> Output Class Initialized
INFO - 2018-08-16 19:37:49 --> Security Class Initialized
DEBUG - 2018-08-16 19:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:37:49 --> Input Class Initialized
INFO - 2018-08-16 19:37:49 --> Language Class Initialized
INFO - 2018-08-16 19:37:49 --> Loader Class Initialized
INFO - 2018-08-16 19:37:49 --> Controller Class Initialized
INFO - 2018-08-16 19:37:49 --> Database Driver Class Initialized
INFO - 2018-08-16 19:37:49 --> Model Class Initialized
INFO - 2018-08-16 19:37:49 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:37:49 --> Model Class Initialized
INFO - 2018-08-16 19:37:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 19:37:49 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\davidhood\application\views\user.php 146
INFO - 2018-08-16 19:37:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:37:49 --> Final output sent to browser
DEBUG - 2018-08-16 19:37:49 --> Total execution time: 0.1569
ERROR - 2018-08-16 19:37:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:37:53 --> Config Class Initialized
INFO - 2018-08-16 19:37:53 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:37:53 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:37:53 --> Utf8 Class Initialized
INFO - 2018-08-16 19:37:53 --> URI Class Initialized
INFO - 2018-08-16 19:37:53 --> Router Class Initialized
INFO - 2018-08-16 19:37:53 --> Output Class Initialized
INFO - 2018-08-16 19:37:53 --> Security Class Initialized
DEBUG - 2018-08-16 19:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:37:53 --> Input Class Initialized
INFO - 2018-08-16 19:37:53 --> Language Class Initialized
INFO - 2018-08-16 19:37:53 --> Loader Class Initialized
INFO - 2018-08-16 19:37:53 --> Controller Class Initialized
INFO - 2018-08-16 19:37:53 --> Database Driver Class Initialized
INFO - 2018-08-16 19:37:53 --> Model Class Initialized
INFO - 2018-08-16 19:37:53 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:37:53 --> Model Class Initialized
ERROR - 2018-08-16 19:37:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:37:53 --> Config Class Initialized
INFO - 2018-08-16 19:37:53 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:37:53 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:37:53 --> Utf8 Class Initialized
INFO - 2018-08-16 19:37:53 --> URI Class Initialized
INFO - 2018-08-16 19:37:53 --> Router Class Initialized
INFO - 2018-08-16 19:37:53 --> Output Class Initialized
INFO - 2018-08-16 19:37:53 --> Security Class Initialized
DEBUG - 2018-08-16 19:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:37:53 --> Input Class Initialized
INFO - 2018-08-16 19:37:53 --> Language Class Initialized
INFO - 2018-08-16 19:37:53 --> Loader Class Initialized
INFO - 2018-08-16 19:37:53 --> Controller Class Initialized
INFO - 2018-08-16 19:37:54 --> Database Driver Class Initialized
INFO - 2018-08-16 19:37:54 --> Model Class Initialized
INFO - 2018-08-16 19:37:54 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:37:54 --> Model Class Initialized
INFO - 2018-08-16 19:37:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 19:37:54 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 146
INFO - 2018-08-16 19:37:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 19:37:54 --> Final output sent to browser
DEBUG - 2018-08-16 19:37:54 --> Total execution time: 0.1636
ERROR - 2018-08-16 19:41:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:41:39 --> Config Class Initialized
INFO - 2018-08-16 19:41:39 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:41:39 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:41:39 --> Utf8 Class Initialized
INFO - 2018-08-16 19:41:39 --> URI Class Initialized
INFO - 2018-08-16 19:41:39 --> Router Class Initialized
INFO - 2018-08-16 19:41:39 --> Output Class Initialized
INFO - 2018-08-16 19:41:39 --> Security Class Initialized
DEBUG - 2018-08-16 19:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:41:39 --> Input Class Initialized
INFO - 2018-08-16 19:41:39 --> Language Class Initialized
INFO - 2018-08-16 19:41:39 --> Loader Class Initialized
INFO - 2018-08-16 19:41:39 --> Controller Class Initialized
INFO - 2018-08-16 19:41:39 --> Database Driver Class Initialized
INFO - 2018-08-16 19:41:39 --> Model Class Initialized
INFO - 2018-08-16 19:41:39 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:41:39 --> Model Class Initialized
INFO - 2018-08-16 19:41:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:41:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-08-16 19:41:39 --> Final output sent to browser
DEBUG - 2018-08-16 19:41:39 --> Total execution time: 0.1959
ERROR - 2018-08-16 19:57:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:57:13 --> Config Class Initialized
INFO - 2018-08-16 19:57:13 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:57:13 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:57:13 --> Utf8 Class Initialized
INFO - 2018-08-16 19:57:13 --> URI Class Initialized
INFO - 2018-08-16 19:57:13 --> Router Class Initialized
INFO - 2018-08-16 19:57:13 --> Output Class Initialized
INFO - 2018-08-16 19:57:13 --> Security Class Initialized
DEBUG - 2018-08-16 19:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:57:13 --> Input Class Initialized
INFO - 2018-08-16 19:57:13 --> Language Class Initialized
INFO - 2018-08-16 19:57:13 --> Loader Class Initialized
INFO - 2018-08-16 19:57:13 --> Controller Class Initialized
INFO - 2018-08-16 19:57:13 --> Database Driver Class Initialized
INFO - 2018-08-16 19:57:13 --> Model Class Initialized
INFO - 2018-08-16 19:57:13 --> Helper loaded: form_helper
INFO - 2018-08-16 19:57:13 --> Helper loaded: url_helper
ERROR - 2018-08-16 19:57:13 --> Severity: Notice --> Undefined index: Davidhood C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-08-16 19:57:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 19:57:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:57:52 --> Config Class Initialized
INFO - 2018-08-16 19:57:52 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:57:52 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:57:52 --> Utf8 Class Initialized
INFO - 2018-08-16 19:57:52 --> URI Class Initialized
INFO - 2018-08-16 19:57:52 --> Router Class Initialized
INFO - 2018-08-16 19:57:52 --> Output Class Initialized
INFO - 2018-08-16 19:57:52 --> Security Class Initialized
DEBUG - 2018-08-16 19:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:57:52 --> Input Class Initialized
INFO - 2018-08-16 19:57:52 --> Language Class Initialized
INFO - 2018-08-16 19:57:52 --> Loader Class Initialized
INFO - 2018-08-16 19:57:52 --> Controller Class Initialized
INFO - 2018-08-16 19:57:52 --> Database Driver Class Initialized
INFO - 2018-08-16 19:57:52 --> Model Class Initialized
INFO - 2018-08-16 19:57:52 --> Helper loaded: form_helper
INFO - 2018-08-16 19:57:52 --> Helper loaded: url_helper
ERROR - 2018-08-16 19:57:52 --> Severity: Notice --> Undefined index: Davidhood C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-08-16 19:57:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 19:57:52 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 68
ERROR - 2018-08-16 19:57:52 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 73
ERROR - 2018-08-16 19:57:52 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 82
ERROR - 2018-08-16 19:57:52 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 92
ERROR - 2018-08-16 19:57:52 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 101
INFO - 2018-08-16 19:57:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 19:57:52 --> Final output sent to browser
DEBUG - 2018-08-16 19:57:52 --> Total execution time: 0.2117
ERROR - 2018-08-16 19:57:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:57:52 --> Config Class Initialized
INFO - 2018-08-16 19:57:52 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:57:52 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:57:52 --> Utf8 Class Initialized
INFO - 2018-08-16 19:57:52 --> URI Class Initialized
INFO - 2018-08-16 19:57:52 --> Router Class Initialized
INFO - 2018-08-16 19:57:52 --> Output Class Initialized
INFO - 2018-08-16 19:57:52 --> Security Class Initialized
DEBUG - 2018-08-16 19:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:57:52 --> Input Class Initialized
INFO - 2018-08-16 19:57:52 --> Language Class Initialized
ERROR - 2018-08-16 19:57:52 --> 404 Page Not Found: UploadImages/admin
ERROR - 2018-08-16 19:57:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:57:52 --> Config Class Initialized
INFO - 2018-08-16 19:57:52 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:57:52 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:57:52 --> Utf8 Class Initialized
INFO - 2018-08-16 19:57:52 --> URI Class Initialized
DEBUG - 2018-08-16 19:57:52 --> No URI present. Default controller set.
INFO - 2018-08-16 19:57:52 --> Router Class Initialized
INFO - 2018-08-16 19:57:52 --> Output Class Initialized
INFO - 2018-08-16 19:57:52 --> Security Class Initialized
DEBUG - 2018-08-16 19:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:57:52 --> Input Class Initialized
INFO - 2018-08-16 19:57:52 --> Language Class Initialized
INFO - 2018-08-16 19:57:52 --> Loader Class Initialized
INFO - 2018-08-16 19:57:52 --> Controller Class Initialized
INFO - 2018-08-16 19:57:52 --> Database Driver Class Initialized
INFO - 2018-08-16 19:57:52 --> Model Class Initialized
INFO - 2018-08-16 19:57:52 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:57:52 --> Model Class Initialized
INFO - 2018-08-16 19:57:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 19:57:52 --> Final output sent to browser
DEBUG - 2018-08-16 19:57:52 --> Total execution time: 0.1707
ERROR - 2018-08-16 19:57:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:57:54 --> Config Class Initialized
INFO - 2018-08-16 19:57:54 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:57:54 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:57:54 --> Utf8 Class Initialized
INFO - 2018-08-16 19:57:54 --> URI Class Initialized
INFO - 2018-08-16 19:57:54 --> Router Class Initialized
INFO - 2018-08-16 19:57:54 --> Output Class Initialized
INFO - 2018-08-16 19:57:54 --> Security Class Initialized
DEBUG - 2018-08-16 19:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:57:54 --> Input Class Initialized
INFO - 2018-08-16 19:57:54 --> Language Class Initialized
INFO - 2018-08-16 19:57:54 --> Loader Class Initialized
INFO - 2018-08-16 19:57:54 --> Controller Class Initialized
INFO - 2018-08-16 19:57:54 --> Database Driver Class Initialized
INFO - 2018-08-16 19:57:54 --> Model Class Initialized
INFO - 2018-08-16 19:57:54 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:57:55 --> Model Class Initialized
ERROR - 2018-08-16 19:57:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:57:55 --> Config Class Initialized
INFO - 2018-08-16 19:57:55 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:57:55 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:57:55 --> Utf8 Class Initialized
INFO - 2018-08-16 19:57:55 --> URI Class Initialized
INFO - 2018-08-16 19:57:55 --> Router Class Initialized
INFO - 2018-08-16 19:57:55 --> Output Class Initialized
INFO - 2018-08-16 19:57:55 --> Security Class Initialized
DEBUG - 2018-08-16 19:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:57:55 --> Input Class Initialized
INFO - 2018-08-16 19:57:55 --> Language Class Initialized
INFO - 2018-08-16 19:57:55 --> Loader Class Initialized
INFO - 2018-08-16 19:57:55 --> Controller Class Initialized
INFO - 2018-08-16 19:57:55 --> Database Driver Class Initialized
INFO - 2018-08-16 19:57:55 --> Model Class Initialized
INFO - 2018-08-16 19:57:55 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:57:55 --> Model Class Initialized
INFO - 2018-08-16 19:57:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:57:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 19:57:55 --> Final output sent to browser
DEBUG - 2018-08-16 19:57:55 --> Total execution time: 0.1832
ERROR - 2018-08-16 19:57:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:57:57 --> Config Class Initialized
INFO - 2018-08-16 19:57:57 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:57:57 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:57:57 --> Utf8 Class Initialized
INFO - 2018-08-16 19:57:57 --> URI Class Initialized
INFO - 2018-08-16 19:57:57 --> Router Class Initialized
INFO - 2018-08-16 19:57:57 --> Output Class Initialized
INFO - 2018-08-16 19:57:57 --> Security Class Initialized
DEBUG - 2018-08-16 19:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:57:57 --> Input Class Initialized
INFO - 2018-08-16 19:57:57 --> Language Class Initialized
INFO - 2018-08-16 19:57:57 --> Loader Class Initialized
INFO - 2018-08-16 19:57:57 --> Controller Class Initialized
INFO - 2018-08-16 19:57:57 --> Database Driver Class Initialized
INFO - 2018-08-16 19:57:57 --> Model Class Initialized
INFO - 2018-08-16 19:57:57 --> Helper loaded: form_helper
INFO - 2018-08-16 19:57:57 --> Helper loaded: url_helper
ERROR - 2018-08-16 19:57:57 --> Severity: Notice --> Undefined index: Davidhood C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-08-16 19:57:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 19:57:57 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 68
ERROR - 2018-08-16 19:57:57 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 73
ERROR - 2018-08-16 19:57:57 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 82
ERROR - 2018-08-16 19:57:57 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 92
ERROR - 2018-08-16 19:57:57 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 101
INFO - 2018-08-16 19:57:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 19:57:57 --> Final output sent to browser
DEBUG - 2018-08-16 19:57:57 --> Total execution time: 0.2150
ERROR - 2018-08-16 19:57:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:57:57 --> Config Class Initialized
INFO - 2018-08-16 19:57:57 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:57:57 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:57:57 --> Utf8 Class Initialized
INFO - 2018-08-16 19:57:57 --> URI Class Initialized
INFO - 2018-08-16 19:57:57 --> Router Class Initialized
INFO - 2018-08-16 19:57:57 --> Output Class Initialized
INFO - 2018-08-16 19:57:57 --> Security Class Initialized
DEBUG - 2018-08-16 19:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:57:57 --> Input Class Initialized
INFO - 2018-08-16 19:57:57 --> Language Class Initialized
ERROR - 2018-08-16 19:57:57 --> 404 Page Not Found: UploadImages/admin
ERROR - 2018-08-16 19:57:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:57:57 --> Config Class Initialized
INFO - 2018-08-16 19:57:57 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:57:57 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:57:57 --> Utf8 Class Initialized
INFO - 2018-08-16 19:57:57 --> URI Class Initialized
DEBUG - 2018-08-16 19:57:57 --> No URI present. Default controller set.
INFO - 2018-08-16 19:57:57 --> Router Class Initialized
INFO - 2018-08-16 19:57:57 --> Output Class Initialized
INFO - 2018-08-16 19:57:57 --> Security Class Initialized
DEBUG - 2018-08-16 19:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:57:57 --> Input Class Initialized
INFO - 2018-08-16 19:57:57 --> Language Class Initialized
INFO - 2018-08-16 19:57:57 --> Loader Class Initialized
INFO - 2018-08-16 19:57:57 --> Controller Class Initialized
INFO - 2018-08-16 19:57:57 --> Database Driver Class Initialized
INFO - 2018-08-16 19:57:57 --> Model Class Initialized
INFO - 2018-08-16 19:57:57 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:57:57 --> Model Class Initialized
INFO - 2018-08-16 19:57:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 19:57:57 --> Final output sent to browser
DEBUG - 2018-08-16 19:57:57 --> Total execution time: 0.1952
ERROR - 2018-08-16 19:59:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:59:13 --> Config Class Initialized
INFO - 2018-08-16 19:59:13 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:59:13 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:59:13 --> Utf8 Class Initialized
INFO - 2018-08-16 19:59:13 --> URI Class Initialized
INFO - 2018-08-16 19:59:13 --> Router Class Initialized
INFO - 2018-08-16 19:59:13 --> Output Class Initialized
INFO - 2018-08-16 19:59:13 --> Security Class Initialized
DEBUG - 2018-08-16 19:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:59:13 --> Input Class Initialized
INFO - 2018-08-16 19:59:13 --> Language Class Initialized
INFO - 2018-08-16 19:59:13 --> Loader Class Initialized
INFO - 2018-08-16 19:59:13 --> Controller Class Initialized
INFO - 2018-08-16 19:59:13 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:13 --> Model Class Initialized
INFO - 2018-08-16 19:59:13 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:59:13 --> Model Class Initialized
INFO - 2018-08-16 19:59:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:59:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 19:59:13 --> Final output sent to browser
DEBUG - 2018-08-16 19:59:13 --> Total execution time: 0.1704
ERROR - 2018-08-16 19:59:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:59:16 --> Config Class Initialized
INFO - 2018-08-16 19:59:16 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:59:16 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:59:16 --> Utf8 Class Initialized
INFO - 2018-08-16 19:59:16 --> URI Class Initialized
INFO - 2018-08-16 19:59:16 --> Router Class Initialized
INFO - 2018-08-16 19:59:16 --> Output Class Initialized
INFO - 2018-08-16 19:59:16 --> Security Class Initialized
DEBUG - 2018-08-16 19:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:59:16 --> Input Class Initialized
INFO - 2018-08-16 19:59:16 --> Language Class Initialized
INFO - 2018-08-16 19:59:16 --> Loader Class Initialized
INFO - 2018-08-16 19:59:16 --> Controller Class Initialized
INFO - 2018-08-16 19:59:16 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:16 --> Model Class Initialized
INFO - 2018-08-16 19:59:16 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:59:16 --> Model Class Initialized
INFO - 2018-08-16 19:59:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 19:59:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 19:59:16 --> Final output sent to browser
DEBUG - 2018-08-16 19:59:16 --> Total execution time: 0.1873
ERROR - 2018-08-16 19:59:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:59:27 --> Config Class Initialized
INFO - 2018-08-16 19:59:27 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:59:27 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:59:27 --> Utf8 Class Initialized
INFO - 2018-08-16 19:59:27 --> URI Class Initialized
INFO - 2018-08-16 19:59:27 --> Router Class Initialized
INFO - 2018-08-16 19:59:27 --> Output Class Initialized
INFO - 2018-08-16 19:59:27 --> Security Class Initialized
DEBUG - 2018-08-16 19:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:59:27 --> Input Class Initialized
INFO - 2018-08-16 19:59:27 --> Language Class Initialized
INFO - 2018-08-16 19:59:27 --> Loader Class Initialized
INFO - 2018-08-16 19:59:27 --> Controller Class Initialized
INFO - 2018-08-16 19:59:27 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:27 --> Model Class Initialized
INFO - 2018-08-16 19:59:27 --> Helper loaded: form_helper
INFO - 2018-08-16 19:59:27 --> Helper loaded: url_helper
ERROR - 2018-08-16 19:59:27 --> Severity: Notice --> Undefined index: Davidhood C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-08-16 19:59:27 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 19:59:27 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 57
ERROR - 2018-08-16 19:59:27 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 62
ERROR - 2018-08-16 19:59:27 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 71
ERROR - 2018-08-16 19:59:27 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 81
ERROR - 2018-08-16 19:59:27 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 90
INFO - 2018-08-16 19:59:27 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 19:59:27 --> Final output sent to browser
DEBUG - 2018-08-16 19:59:27 --> Total execution time: 0.2301
ERROR - 2018-08-16 19:59:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:59:27 --> Config Class Initialized
INFO - 2018-08-16 19:59:27 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:59:27 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:59:27 --> Utf8 Class Initialized
INFO - 2018-08-16 19:59:27 --> URI Class Initialized
INFO - 2018-08-16 19:59:27 --> Router Class Initialized
INFO - 2018-08-16 19:59:27 --> Output Class Initialized
INFO - 2018-08-16 19:59:28 --> Security Class Initialized
DEBUG - 2018-08-16 19:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:59:28 --> Input Class Initialized
INFO - 2018-08-16 19:59:28 --> Language Class Initialized
ERROR - 2018-08-16 19:59:28 --> 404 Page Not Found: UploadImages/admin
ERROR - 2018-08-16 19:59:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 19:59:28 --> Config Class Initialized
INFO - 2018-08-16 19:59:28 --> Hooks Class Initialized
DEBUG - 2018-08-16 19:59:28 --> UTF-8 Support Enabled
INFO - 2018-08-16 19:59:28 --> Utf8 Class Initialized
INFO - 2018-08-16 19:59:28 --> URI Class Initialized
DEBUG - 2018-08-16 19:59:28 --> No URI present. Default controller set.
INFO - 2018-08-16 19:59:28 --> Router Class Initialized
INFO - 2018-08-16 19:59:28 --> Output Class Initialized
INFO - 2018-08-16 19:59:28 --> Security Class Initialized
DEBUG - 2018-08-16 19:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 19:59:28 --> Input Class Initialized
INFO - 2018-08-16 19:59:28 --> Language Class Initialized
INFO - 2018-08-16 19:59:28 --> Loader Class Initialized
INFO - 2018-08-16 19:59:28 --> Controller Class Initialized
INFO - 2018-08-16 19:59:28 --> Database Driver Class Initialized
INFO - 2018-08-16 19:59:28 --> Model Class Initialized
INFO - 2018-08-16 19:59:28 --> Helper loaded: url_helper
DEBUG - 2018-08-16 19:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 19:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 19:59:28 --> Model Class Initialized
INFO - 2018-08-16 19:59:28 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 19:59:28 --> Final output sent to browser
DEBUG - 2018-08-16 19:59:28 --> Total execution time: 0.1746
ERROR - 2018-08-16 20:00:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:00:04 --> Config Class Initialized
INFO - 2018-08-16 20:00:04 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:00:04 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:00:04 --> Utf8 Class Initialized
INFO - 2018-08-16 20:00:04 --> URI Class Initialized
INFO - 2018-08-16 20:00:04 --> Router Class Initialized
INFO - 2018-08-16 20:00:04 --> Output Class Initialized
INFO - 2018-08-16 20:00:04 --> Security Class Initialized
DEBUG - 2018-08-16 20:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:00:04 --> Input Class Initialized
INFO - 2018-08-16 20:00:04 --> Language Class Initialized
INFO - 2018-08-16 20:00:04 --> Loader Class Initialized
INFO - 2018-08-16 20:00:05 --> Controller Class Initialized
INFO - 2018-08-16 20:00:05 --> Database Driver Class Initialized
INFO - 2018-08-16 20:00:05 --> Model Class Initialized
INFO - 2018-08-16 20:00:05 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:00:05 --> Model Class Initialized
INFO - 2018-08-16 20:00:05 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:00:05 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 20:00:05 --> Final output sent to browser
DEBUG - 2018-08-16 20:00:05 --> Total execution time: 0.1782
ERROR - 2018-08-16 20:02:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:02:13 --> Config Class Initialized
INFO - 2018-08-16 20:02:13 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:02:13 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:02:13 --> Utf8 Class Initialized
INFO - 2018-08-16 20:02:13 --> URI Class Initialized
INFO - 2018-08-16 20:02:14 --> Router Class Initialized
INFO - 2018-08-16 20:02:14 --> Output Class Initialized
INFO - 2018-08-16 20:02:14 --> Security Class Initialized
DEBUG - 2018-08-16 20:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:02:14 --> Input Class Initialized
INFO - 2018-08-16 20:02:14 --> Language Class Initialized
INFO - 2018-08-16 20:02:14 --> Loader Class Initialized
INFO - 2018-08-16 20:02:14 --> Controller Class Initialized
INFO - 2018-08-16 20:02:14 --> Database Driver Class Initialized
INFO - 2018-08-16 20:02:14 --> Model Class Initialized
INFO - 2018-08-16 20:02:14 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:02:14 --> Model Class Initialized
INFO - 2018-08-16 20:02:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:02:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 20:02:14 --> Final output sent to browser
DEBUG - 2018-08-16 20:02:14 --> Total execution time: 0.1852
ERROR - 2018-08-16 20:02:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:02:21 --> Config Class Initialized
INFO - 2018-08-16 20:02:21 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:02:21 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:02:21 --> Utf8 Class Initialized
INFO - 2018-08-16 20:02:21 --> URI Class Initialized
INFO - 2018-08-16 20:02:21 --> Router Class Initialized
INFO - 2018-08-16 20:02:21 --> Output Class Initialized
INFO - 2018-08-16 20:02:22 --> Security Class Initialized
DEBUG - 2018-08-16 20:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:02:22 --> Input Class Initialized
INFO - 2018-08-16 20:02:22 --> Language Class Initialized
INFO - 2018-08-16 20:02:22 --> Loader Class Initialized
INFO - 2018-08-16 20:02:22 --> Controller Class Initialized
INFO - 2018-08-16 20:02:22 --> Database Driver Class Initialized
INFO - 2018-08-16 20:02:22 --> Model Class Initialized
INFO - 2018-08-16 20:02:22 --> Helper loaded: form_helper
INFO - 2018-08-16 20:02:22 --> Helper loaded: url_helper
ERROR - 2018-08-16 20:02:22 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-08-16 20:02:22 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:02:22 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 57
ERROR - 2018-08-16 20:02:22 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 62
ERROR - 2018-08-16 20:02:22 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 71
ERROR - 2018-08-16 20:02:22 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 81
ERROR - 2018-08-16 20:02:22 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 90
INFO - 2018-08-16 20:02:22 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:02:22 --> Final output sent to browser
DEBUG - 2018-08-16 20:02:22 --> Total execution time: 0.2829
ERROR - 2018-08-16 20:02:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:02:22 --> Config Class Initialized
INFO - 2018-08-16 20:02:22 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:02:22 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:02:22 --> Utf8 Class Initialized
INFO - 2018-08-16 20:02:22 --> URI Class Initialized
INFO - 2018-08-16 20:02:22 --> Router Class Initialized
INFO - 2018-08-16 20:02:22 --> Output Class Initialized
INFO - 2018-08-16 20:02:22 --> Security Class Initialized
DEBUG - 2018-08-16 20:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:02:22 --> Input Class Initialized
INFO - 2018-08-16 20:02:22 --> Language Class Initialized
ERROR - 2018-08-16 20:02:22 --> 404 Page Not Found: UploadImages/admin
ERROR - 2018-08-16 20:02:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:02:22 --> Config Class Initialized
INFO - 2018-08-16 20:02:22 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:02:22 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:02:22 --> Utf8 Class Initialized
INFO - 2018-08-16 20:02:22 --> URI Class Initialized
DEBUG - 2018-08-16 20:02:22 --> No URI present. Default controller set.
INFO - 2018-08-16 20:02:22 --> Router Class Initialized
INFO - 2018-08-16 20:02:22 --> Output Class Initialized
INFO - 2018-08-16 20:02:22 --> Security Class Initialized
DEBUG - 2018-08-16 20:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:02:22 --> Input Class Initialized
INFO - 2018-08-16 20:02:22 --> Language Class Initialized
INFO - 2018-08-16 20:02:22 --> Loader Class Initialized
INFO - 2018-08-16 20:02:22 --> Controller Class Initialized
INFO - 2018-08-16 20:02:22 --> Database Driver Class Initialized
INFO - 2018-08-16 20:02:22 --> Model Class Initialized
INFO - 2018-08-16 20:02:22 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:02:22 --> Model Class Initialized
INFO - 2018-08-16 20:02:22 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:02:22 --> Final output sent to browser
DEBUG - 2018-08-16 20:02:22 --> Total execution time: 0.1964
ERROR - 2018-08-16 20:02:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:02:25 --> Config Class Initialized
INFO - 2018-08-16 20:02:25 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:02:25 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:02:25 --> Utf8 Class Initialized
INFO - 2018-08-16 20:02:25 --> URI Class Initialized
INFO - 2018-08-16 20:02:25 --> Router Class Initialized
INFO - 2018-08-16 20:02:25 --> Output Class Initialized
INFO - 2018-08-16 20:02:25 --> Security Class Initialized
DEBUG - 2018-08-16 20:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:02:25 --> Input Class Initialized
INFO - 2018-08-16 20:02:25 --> Language Class Initialized
INFO - 2018-08-16 20:02:25 --> Loader Class Initialized
INFO - 2018-08-16 20:02:25 --> Controller Class Initialized
INFO - 2018-08-16 20:02:25 --> Database Driver Class Initialized
INFO - 2018-08-16 20:02:25 --> Model Class Initialized
INFO - 2018-08-16 20:02:25 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:02:25 --> Model Class Initialized
INFO - 2018-08-16 20:02:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:02:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 20:02:25 --> Final output sent to browser
DEBUG - 2018-08-16 20:02:25 --> Total execution time: 0.1753
ERROR - 2018-08-16 20:02:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:02:28 --> Config Class Initialized
INFO - 2018-08-16 20:02:28 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:02:28 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:02:28 --> Utf8 Class Initialized
INFO - 2018-08-16 20:02:28 --> URI Class Initialized
INFO - 2018-08-16 20:02:28 --> Router Class Initialized
INFO - 2018-08-16 20:02:28 --> Output Class Initialized
INFO - 2018-08-16 20:02:28 --> Security Class Initialized
DEBUG - 2018-08-16 20:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:02:28 --> Input Class Initialized
INFO - 2018-08-16 20:02:28 --> Language Class Initialized
INFO - 2018-08-16 20:02:28 --> Loader Class Initialized
INFO - 2018-08-16 20:02:28 --> Controller Class Initialized
INFO - 2018-08-16 20:02:28 --> Database Driver Class Initialized
INFO - 2018-08-16 20:02:28 --> Model Class Initialized
INFO - 2018-08-16 20:02:28 --> Helper loaded: form_helper
INFO - 2018-08-16 20:02:28 --> Helper loaded: url_helper
ERROR - 2018-08-16 20:02:28 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-08-16 20:02:28 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:02:28 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 57
ERROR - 2018-08-16 20:02:28 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 62
ERROR - 2018-08-16 20:02:28 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 71
ERROR - 2018-08-16 20:02:28 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 81
ERROR - 2018-08-16 20:02:28 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 90
INFO - 2018-08-16 20:02:28 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:02:28 --> Final output sent to browser
DEBUG - 2018-08-16 20:02:28 --> Total execution time: 0.2721
ERROR - 2018-08-16 20:02:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:02:28 --> Config Class Initialized
INFO - 2018-08-16 20:02:28 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:02:28 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:02:28 --> Utf8 Class Initialized
INFO - 2018-08-16 20:02:28 --> URI Class Initialized
INFO - 2018-08-16 20:02:28 --> Router Class Initialized
INFO - 2018-08-16 20:02:28 --> Output Class Initialized
INFO - 2018-08-16 20:02:28 --> Security Class Initialized
DEBUG - 2018-08-16 20:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:02:28 --> Input Class Initialized
INFO - 2018-08-16 20:02:28 --> Language Class Initialized
ERROR - 2018-08-16 20:02:28 --> 404 Page Not Found: UploadImages/admin
ERROR - 2018-08-16 20:02:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:02:28 --> Config Class Initialized
INFO - 2018-08-16 20:02:28 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:02:28 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:02:28 --> Utf8 Class Initialized
INFO - 2018-08-16 20:02:28 --> URI Class Initialized
DEBUG - 2018-08-16 20:02:28 --> No URI present. Default controller set.
INFO - 2018-08-16 20:02:28 --> Router Class Initialized
INFO - 2018-08-16 20:02:28 --> Output Class Initialized
INFO - 2018-08-16 20:02:28 --> Security Class Initialized
DEBUG - 2018-08-16 20:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:02:28 --> Input Class Initialized
INFO - 2018-08-16 20:02:28 --> Language Class Initialized
INFO - 2018-08-16 20:02:28 --> Loader Class Initialized
INFO - 2018-08-16 20:02:28 --> Controller Class Initialized
INFO - 2018-08-16 20:02:29 --> Database Driver Class Initialized
INFO - 2018-08-16 20:02:29 --> Model Class Initialized
INFO - 2018-08-16 20:02:29 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:02:29 --> Model Class Initialized
INFO - 2018-08-16 20:02:29 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:02:29 --> Final output sent to browser
DEBUG - 2018-08-16 20:02:29 --> Total execution time: 0.2050
ERROR - 2018-08-16 20:02:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:02:31 --> Config Class Initialized
INFO - 2018-08-16 20:02:31 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:02:31 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:02:31 --> Utf8 Class Initialized
INFO - 2018-08-16 20:02:31 --> URI Class Initialized
INFO - 2018-08-16 20:02:31 --> Router Class Initialized
INFO - 2018-08-16 20:02:31 --> Output Class Initialized
INFO - 2018-08-16 20:02:31 --> Security Class Initialized
DEBUG - 2018-08-16 20:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:02:31 --> Input Class Initialized
INFO - 2018-08-16 20:02:31 --> Language Class Initialized
INFO - 2018-08-16 20:02:31 --> Loader Class Initialized
INFO - 2018-08-16 20:02:31 --> Controller Class Initialized
INFO - 2018-08-16 20:02:31 --> Database Driver Class Initialized
INFO - 2018-08-16 20:02:31 --> Model Class Initialized
INFO - 2018-08-16 20:02:31 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:02:31 --> Model Class Initialized
INFO - 2018-08-16 20:02:31 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:02:31 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 20:02:31 --> Final output sent to browser
DEBUG - 2018-08-16 20:02:31 --> Total execution time: 0.2057
ERROR - 2018-08-16 20:02:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:02:33 --> Config Class Initialized
INFO - 2018-08-16 20:02:33 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:02:33 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:02:33 --> Utf8 Class Initialized
INFO - 2018-08-16 20:02:33 --> URI Class Initialized
INFO - 2018-08-16 20:02:33 --> Router Class Initialized
INFO - 2018-08-16 20:02:33 --> Output Class Initialized
INFO - 2018-08-16 20:02:33 --> Security Class Initialized
DEBUG - 2018-08-16 20:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:02:33 --> Input Class Initialized
INFO - 2018-08-16 20:02:33 --> Language Class Initialized
INFO - 2018-08-16 20:02:33 --> Loader Class Initialized
INFO - 2018-08-16 20:02:33 --> Controller Class Initialized
INFO - 2018-08-16 20:02:33 --> Database Driver Class Initialized
INFO - 2018-08-16 20:02:33 --> Model Class Initialized
INFO - 2018-08-16 20:02:33 --> Helper loaded: form_helper
INFO - 2018-08-16 20:02:33 --> Helper loaded: url_helper
ERROR - 2018-08-16 20:02:33 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-08-16 20:02:33 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:02:33 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 57
ERROR - 2018-08-16 20:02:33 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 62
ERROR - 2018-08-16 20:02:33 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 71
ERROR - 2018-08-16 20:02:33 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 81
ERROR - 2018-08-16 20:02:33 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 90
INFO - 2018-08-16 20:02:33 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:02:33 --> Final output sent to browser
DEBUG - 2018-08-16 20:02:33 --> Total execution time: 0.2109
ERROR - 2018-08-16 20:02:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:02:33 --> Config Class Initialized
INFO - 2018-08-16 20:02:33 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:02:33 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:02:33 --> Utf8 Class Initialized
INFO - 2018-08-16 20:02:33 --> URI Class Initialized
INFO - 2018-08-16 20:02:33 --> Router Class Initialized
INFO - 2018-08-16 20:02:33 --> Output Class Initialized
INFO - 2018-08-16 20:02:33 --> Security Class Initialized
DEBUG - 2018-08-16 20:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:02:33 --> Input Class Initialized
INFO - 2018-08-16 20:02:33 --> Language Class Initialized
ERROR - 2018-08-16 20:02:33 --> 404 Page Not Found: UploadImages/admin
ERROR - 2018-08-16 20:02:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:02:33 --> Config Class Initialized
INFO - 2018-08-16 20:02:33 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:02:33 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:02:33 --> Utf8 Class Initialized
INFO - 2018-08-16 20:02:33 --> URI Class Initialized
DEBUG - 2018-08-16 20:02:33 --> No URI present. Default controller set.
INFO - 2018-08-16 20:02:33 --> Router Class Initialized
INFO - 2018-08-16 20:02:33 --> Output Class Initialized
INFO - 2018-08-16 20:02:33 --> Security Class Initialized
DEBUG - 2018-08-16 20:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:02:33 --> Input Class Initialized
INFO - 2018-08-16 20:02:33 --> Language Class Initialized
INFO - 2018-08-16 20:02:33 --> Loader Class Initialized
INFO - 2018-08-16 20:02:33 --> Controller Class Initialized
INFO - 2018-08-16 20:02:33 --> Database Driver Class Initialized
INFO - 2018-08-16 20:02:33 --> Model Class Initialized
INFO - 2018-08-16 20:02:33 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:02:33 --> Model Class Initialized
INFO - 2018-08-16 20:02:33 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:02:33 --> Final output sent to browser
DEBUG - 2018-08-16 20:02:33 --> Total execution time: 0.2001
ERROR - 2018-08-16 20:02:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:02:58 --> Config Class Initialized
INFO - 2018-08-16 20:02:58 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:02:58 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:02:58 --> Utf8 Class Initialized
INFO - 2018-08-16 20:02:58 --> URI Class Initialized
INFO - 2018-08-16 20:02:58 --> Router Class Initialized
INFO - 2018-08-16 20:02:58 --> Output Class Initialized
INFO - 2018-08-16 20:02:58 --> Security Class Initialized
DEBUG - 2018-08-16 20:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:02:58 --> Input Class Initialized
INFO - 2018-08-16 20:02:58 --> Language Class Initialized
INFO - 2018-08-16 20:02:58 --> Loader Class Initialized
INFO - 2018-08-16 20:02:58 --> Controller Class Initialized
INFO - 2018-08-16 20:02:58 --> Database Driver Class Initialized
INFO - 2018-08-16 20:02:58 --> Model Class Initialized
INFO - 2018-08-16 20:02:58 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:02:58 --> Model Class Initialized
INFO - 2018-08-16 20:02:58 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:02:58 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 20:02:58 --> Final output sent to browser
DEBUG - 2018-08-16 20:02:58 --> Total execution time: 0.2055
ERROR - 2018-08-16 20:03:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:03:01 --> Config Class Initialized
INFO - 2018-08-16 20:03:01 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:03:01 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:03:01 --> Utf8 Class Initialized
INFO - 2018-08-16 20:03:01 --> URI Class Initialized
INFO - 2018-08-16 20:03:01 --> Router Class Initialized
INFO - 2018-08-16 20:03:01 --> Output Class Initialized
INFO - 2018-08-16 20:03:01 --> Security Class Initialized
DEBUG - 2018-08-16 20:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:03:01 --> Input Class Initialized
INFO - 2018-08-16 20:03:01 --> Language Class Initialized
INFO - 2018-08-16 20:03:01 --> Loader Class Initialized
INFO - 2018-08-16 20:03:01 --> Controller Class Initialized
INFO - 2018-08-16 20:03:01 --> Database Driver Class Initialized
INFO - 2018-08-16 20:03:01 --> Model Class Initialized
INFO - 2018-08-16 20:03:01 --> Helper loaded: form_helper
INFO - 2018-08-16 20:03:01 --> Helper loaded: url_helper
INFO - 2018-08-16 20:03:01 --> Final output sent to browser
DEBUG - 2018-08-16 20:03:01 --> Total execution time: 0.1685
ERROR - 2018-08-16 20:03:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:03:12 --> Config Class Initialized
INFO - 2018-08-16 20:03:12 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:03:12 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:03:12 --> Utf8 Class Initialized
INFO - 2018-08-16 20:03:12 --> URI Class Initialized
INFO - 2018-08-16 20:03:12 --> Router Class Initialized
INFO - 2018-08-16 20:03:12 --> Output Class Initialized
INFO - 2018-08-16 20:03:12 --> Security Class Initialized
DEBUG - 2018-08-16 20:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:03:12 --> Input Class Initialized
INFO - 2018-08-16 20:03:12 --> Language Class Initialized
INFO - 2018-08-16 20:03:12 --> Loader Class Initialized
INFO - 2018-08-16 20:03:12 --> Controller Class Initialized
INFO - 2018-08-16 20:03:12 --> Database Driver Class Initialized
INFO - 2018-08-16 20:03:12 --> Model Class Initialized
INFO - 2018-08-16 20:03:12 --> Helper loaded: form_helper
INFO - 2018-08-16 20:03:12 --> Helper loaded: url_helper
ERROR - 2018-08-16 20:03:12 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-08-16 20:03:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:03:12 --> Final output sent to browser
DEBUG - 2018-08-16 20:03:12 --> Total execution time: 0.1599
ERROR - 2018-08-16 20:03:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:03:13 --> Config Class Initialized
INFO - 2018-08-16 20:03:13 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:03:13 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:03:13 --> Utf8 Class Initialized
INFO - 2018-08-16 20:03:13 --> URI Class Initialized
DEBUG - 2018-08-16 20:03:13 --> No URI present. Default controller set.
INFO - 2018-08-16 20:03:13 --> Router Class Initialized
INFO - 2018-08-16 20:03:13 --> Output Class Initialized
INFO - 2018-08-16 20:03:13 --> Security Class Initialized
DEBUG - 2018-08-16 20:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:03:13 --> Input Class Initialized
INFO - 2018-08-16 20:03:13 --> Language Class Initialized
INFO - 2018-08-16 20:03:13 --> Loader Class Initialized
INFO - 2018-08-16 20:03:13 --> Controller Class Initialized
INFO - 2018-08-16 20:03:13 --> Database Driver Class Initialized
INFO - 2018-08-16 20:03:13 --> Model Class Initialized
INFO - 2018-08-16 20:03:13 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:03:13 --> Model Class Initialized
INFO - 2018-08-16 20:03:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:03:13 --> Final output sent to browser
DEBUG - 2018-08-16 20:03:13 --> Total execution time: 0.1929
ERROR - 2018-08-16 20:03:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:03:15 --> Config Class Initialized
INFO - 2018-08-16 20:03:15 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:03:15 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:03:15 --> Utf8 Class Initialized
INFO - 2018-08-16 20:03:15 --> URI Class Initialized
INFO - 2018-08-16 20:03:15 --> Router Class Initialized
INFO - 2018-08-16 20:03:15 --> Output Class Initialized
INFO - 2018-08-16 20:03:15 --> Security Class Initialized
DEBUG - 2018-08-16 20:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:03:15 --> Input Class Initialized
INFO - 2018-08-16 20:03:15 --> Language Class Initialized
INFO - 2018-08-16 20:03:15 --> Loader Class Initialized
INFO - 2018-08-16 20:03:15 --> Controller Class Initialized
INFO - 2018-08-16 20:03:15 --> Database Driver Class Initialized
INFO - 2018-08-16 20:03:15 --> Model Class Initialized
INFO - 2018-08-16 20:03:15 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:03:15 --> Model Class Initialized
INFO - 2018-08-16 20:03:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:03:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 20:03:15 --> Final output sent to browser
DEBUG - 2018-08-16 20:03:15 --> Total execution time: 0.1814
ERROR - 2018-08-16 20:04:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:04:07 --> Config Class Initialized
INFO - 2018-08-16 20:04:07 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:04:07 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:04:07 --> Utf8 Class Initialized
INFO - 2018-08-16 20:04:07 --> URI Class Initialized
INFO - 2018-08-16 20:04:07 --> Router Class Initialized
INFO - 2018-08-16 20:04:07 --> Output Class Initialized
INFO - 2018-08-16 20:04:07 --> Security Class Initialized
DEBUG - 2018-08-16 20:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:04:07 --> Input Class Initialized
INFO - 2018-08-16 20:04:07 --> Language Class Initialized
INFO - 2018-08-16 20:04:07 --> Loader Class Initialized
INFO - 2018-08-16 20:04:07 --> Controller Class Initialized
INFO - 2018-08-16 20:04:07 --> Database Driver Class Initialized
INFO - 2018-08-16 20:04:07 --> Model Class Initialized
INFO - 2018-08-16 20:04:07 --> Helper loaded: form_helper
INFO - 2018-08-16 20:04:07 --> Helper loaded: url_helper
ERROR - 2018-08-16 20:04:07 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-08-16 20:04:07 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:04:07 --> Severity: Notice --> Undefined property: Admin::$model C:\xampp\htdocs\davidhood\application\controllers\Admin.php 36
ERROR - 2018-08-16 20:04:07 --> Severity: error --> Exception: Call to a member function get_user() on null C:\xampp\htdocs\davidhood\application\controllers\Admin.php 36
ERROR - 2018-08-16 20:05:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:05:05 --> Config Class Initialized
INFO - 2018-08-16 20:05:05 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:05:05 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:05:05 --> Utf8 Class Initialized
INFO - 2018-08-16 20:05:05 --> URI Class Initialized
INFO - 2018-08-16 20:05:05 --> Router Class Initialized
INFO - 2018-08-16 20:05:05 --> Output Class Initialized
INFO - 2018-08-16 20:05:05 --> Security Class Initialized
DEBUG - 2018-08-16 20:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:05:05 --> Input Class Initialized
INFO - 2018-08-16 20:05:05 --> Language Class Initialized
INFO - 2018-08-16 20:05:05 --> Loader Class Initialized
INFO - 2018-08-16 20:05:05 --> Controller Class Initialized
INFO - 2018-08-16 20:05:05 --> Database Driver Class Initialized
INFO - 2018-08-16 20:05:05 --> Model Class Initialized
INFO - 2018-08-16 20:05:05 --> Helper loaded: form_helper
INFO - 2018-08-16 20:05:05 --> Helper loaded: url_helper
ERROR - 2018-08-16 20:05:05 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-08-16 20:05:05 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:05:05 --> Severity: Notice --> Undefined property: Admin::$model C:\xampp\htdocs\davidhood\application\controllers\Admin.php 37
ERROR - 2018-08-16 20:05:05 --> Severity: error --> Exception: Call to a member function get_user() on null C:\xampp\htdocs\davidhood\application\controllers\Admin.php 37
ERROR - 2018-08-16 20:05:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:05:07 --> Config Class Initialized
INFO - 2018-08-16 20:05:07 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:05:07 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:05:07 --> Utf8 Class Initialized
INFO - 2018-08-16 20:05:07 --> URI Class Initialized
INFO - 2018-08-16 20:05:07 --> Router Class Initialized
INFO - 2018-08-16 20:05:07 --> Output Class Initialized
INFO - 2018-08-16 20:05:07 --> Security Class Initialized
DEBUG - 2018-08-16 20:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:05:07 --> Input Class Initialized
INFO - 2018-08-16 20:05:07 --> Language Class Initialized
INFO - 2018-08-16 20:05:07 --> Loader Class Initialized
INFO - 2018-08-16 20:05:07 --> Controller Class Initialized
INFO - 2018-08-16 20:05:07 --> Database Driver Class Initialized
INFO - 2018-08-16 20:05:07 --> Model Class Initialized
INFO - 2018-08-16 20:05:07 --> Helper loaded: form_helper
INFO - 2018-08-16 20:05:07 --> Helper loaded: url_helper
ERROR - 2018-08-16 20:05:07 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-08-16 20:05:07 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:05:07 --> Severity: Notice --> Undefined property: Admin::$model C:\xampp\htdocs\davidhood\application\controllers\Admin.php 37
ERROR - 2018-08-16 20:05:07 --> Severity: error --> Exception: Call to a member function get_user() on null C:\xampp\htdocs\davidhood\application\controllers\Admin.php 37
ERROR - 2018-08-16 20:06:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:06:01 --> Config Class Initialized
INFO - 2018-08-16 20:06:01 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:06:01 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:06:01 --> Utf8 Class Initialized
INFO - 2018-08-16 20:06:01 --> URI Class Initialized
INFO - 2018-08-16 20:06:01 --> Router Class Initialized
INFO - 2018-08-16 20:06:01 --> Output Class Initialized
INFO - 2018-08-16 20:06:01 --> Security Class Initialized
DEBUG - 2018-08-16 20:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:06:01 --> Input Class Initialized
INFO - 2018-08-16 20:06:02 --> Language Class Initialized
INFO - 2018-08-16 20:06:02 --> Loader Class Initialized
INFO - 2018-08-16 20:06:02 --> Controller Class Initialized
INFO - 2018-08-16 20:06:02 --> Database Driver Class Initialized
INFO - 2018-08-16 20:06:02 --> Model Class Initialized
INFO - 2018-08-16 20:06:02 --> Helper loaded: form_helper
INFO - 2018-08-16 20:06:02 --> Helper loaded: url_helper
ERROR - 2018-08-16 20:06:02 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-08-16 20:06:02 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:06:02 --> Final output sent to browser
DEBUG - 2018-08-16 20:06:02 --> Total execution time: 0.1751
ERROR - 2018-08-16 20:06:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:06:02 --> Config Class Initialized
INFO - 2018-08-16 20:06:02 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:06:02 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:06:02 --> Utf8 Class Initialized
INFO - 2018-08-16 20:06:02 --> URI Class Initialized
DEBUG - 2018-08-16 20:06:02 --> No URI present. Default controller set.
INFO - 2018-08-16 20:06:02 --> Router Class Initialized
INFO - 2018-08-16 20:06:02 --> Output Class Initialized
INFO - 2018-08-16 20:06:02 --> Security Class Initialized
DEBUG - 2018-08-16 20:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:06:02 --> Input Class Initialized
INFO - 2018-08-16 20:06:02 --> Language Class Initialized
INFO - 2018-08-16 20:06:02 --> Loader Class Initialized
INFO - 2018-08-16 20:06:02 --> Controller Class Initialized
INFO - 2018-08-16 20:06:02 --> Database Driver Class Initialized
INFO - 2018-08-16 20:06:02 --> Model Class Initialized
INFO - 2018-08-16 20:06:02 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:06:02 --> Model Class Initialized
INFO - 2018-08-16 20:06:02 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:06:02 --> Final output sent to browser
DEBUG - 2018-08-16 20:06:02 --> Total execution time: 0.2274
ERROR - 2018-08-16 20:06:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:06:04 --> Config Class Initialized
INFO - 2018-08-16 20:06:04 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:06:04 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:06:04 --> Utf8 Class Initialized
INFO - 2018-08-16 20:06:04 --> URI Class Initialized
INFO - 2018-08-16 20:06:04 --> Router Class Initialized
INFO - 2018-08-16 20:06:04 --> Output Class Initialized
INFO - 2018-08-16 20:06:04 --> Security Class Initialized
DEBUG - 2018-08-16 20:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:06:04 --> Input Class Initialized
INFO - 2018-08-16 20:06:04 --> Language Class Initialized
INFO - 2018-08-16 20:06:04 --> Loader Class Initialized
INFO - 2018-08-16 20:06:04 --> Controller Class Initialized
INFO - 2018-08-16 20:06:04 --> Database Driver Class Initialized
INFO - 2018-08-16 20:06:04 --> Model Class Initialized
INFO - 2018-08-16 20:06:04 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:06:04 --> Model Class Initialized
INFO - 2018-08-16 20:06:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:06:04 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 20:06:04 --> Final output sent to browser
DEBUG - 2018-08-16 20:06:04 --> Total execution time: 0.1959
ERROR - 2018-08-16 20:07:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:07:47 --> Config Class Initialized
INFO - 2018-08-16 20:07:47 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:07:47 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:07:47 --> Utf8 Class Initialized
INFO - 2018-08-16 20:07:47 --> URI Class Initialized
INFO - 2018-08-16 20:07:47 --> Router Class Initialized
INFO - 2018-08-16 20:07:47 --> Output Class Initialized
INFO - 2018-08-16 20:07:47 --> Security Class Initialized
DEBUG - 2018-08-16 20:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:07:47 --> Input Class Initialized
INFO - 2018-08-16 20:07:47 --> Language Class Initialized
INFO - 2018-08-16 20:07:47 --> Loader Class Initialized
INFO - 2018-08-16 20:07:47 --> Controller Class Initialized
INFO - 2018-08-16 20:07:47 --> Database Driver Class Initialized
INFO - 2018-08-16 20:07:47 --> Model Class Initialized
INFO - 2018-08-16 20:07:47 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:07:47 --> Model Class Initialized
INFO - 2018-08-16 20:07:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:07:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 20:07:47 --> Final output sent to browser
DEBUG - 2018-08-16 20:07:47 --> Total execution time: 0.1889
ERROR - 2018-08-16 20:07:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:07:53 --> Config Class Initialized
INFO - 2018-08-16 20:07:53 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:07:53 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:07:53 --> Utf8 Class Initialized
INFO - 2018-08-16 20:07:53 --> URI Class Initialized
INFO - 2018-08-16 20:07:53 --> Router Class Initialized
INFO - 2018-08-16 20:07:53 --> Output Class Initialized
INFO - 2018-08-16 20:07:53 --> Security Class Initialized
DEBUG - 2018-08-16 20:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:07:53 --> Input Class Initialized
INFO - 2018-08-16 20:07:53 --> Language Class Initialized
INFO - 2018-08-16 20:07:53 --> Loader Class Initialized
INFO - 2018-08-16 20:07:53 --> Controller Class Initialized
INFO - 2018-08-16 20:07:53 --> Database Driver Class Initialized
INFO - 2018-08-16 20:07:53 --> Model Class Initialized
INFO - 2018-08-16 20:07:53 --> Helper loaded: form_helper
INFO - 2018-08-16 20:07:53 --> Helper loaded: url_helper
ERROR - 2018-08-16 20:07:53 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-08-16 20:07:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:07:53 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 57
ERROR - 2018-08-16 20:07:53 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 62
ERROR - 2018-08-16 20:07:53 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 71
ERROR - 2018-08-16 20:07:53 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 81
ERROR - 2018-08-16 20:07:53 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 90
INFO - 2018-08-16 20:07:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:07:53 --> Final output sent to browser
DEBUG - 2018-08-16 20:07:53 --> Total execution time: 0.2506
ERROR - 2018-08-16 20:07:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:07:53 --> Config Class Initialized
INFO - 2018-08-16 20:07:53 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:07:53 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:07:53 --> Utf8 Class Initialized
INFO - 2018-08-16 20:07:53 --> URI Class Initialized
INFO - 2018-08-16 20:07:53 --> Router Class Initialized
INFO - 2018-08-16 20:07:53 --> Output Class Initialized
INFO - 2018-08-16 20:07:53 --> Security Class Initialized
DEBUG - 2018-08-16 20:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:07:53 --> Input Class Initialized
INFO - 2018-08-16 20:07:53 --> Language Class Initialized
ERROR - 2018-08-16 20:07:53 --> 404 Page Not Found: UploadImages/admin
ERROR - 2018-08-16 20:07:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:07:53 --> Config Class Initialized
INFO - 2018-08-16 20:07:53 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:07:53 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:07:53 --> Utf8 Class Initialized
INFO - 2018-08-16 20:07:53 --> URI Class Initialized
DEBUG - 2018-08-16 20:07:53 --> No URI present. Default controller set.
INFO - 2018-08-16 20:07:53 --> Router Class Initialized
INFO - 2018-08-16 20:07:53 --> Output Class Initialized
INFO - 2018-08-16 20:07:53 --> Security Class Initialized
DEBUG - 2018-08-16 20:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:07:53 --> Input Class Initialized
INFO - 2018-08-16 20:07:53 --> Language Class Initialized
INFO - 2018-08-16 20:07:53 --> Loader Class Initialized
INFO - 2018-08-16 20:07:53 --> Controller Class Initialized
INFO - 2018-08-16 20:07:53 --> Database Driver Class Initialized
INFO - 2018-08-16 20:07:53 --> Model Class Initialized
INFO - 2018-08-16 20:07:53 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:07:53 --> Model Class Initialized
INFO - 2018-08-16 20:07:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:07:53 --> Final output sent to browser
DEBUG - 2018-08-16 20:07:53 --> Total execution time: 0.2113
ERROR - 2018-08-16 20:08:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:08:08 --> Config Class Initialized
INFO - 2018-08-16 20:08:08 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:08:08 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:08:08 --> Utf8 Class Initialized
INFO - 2018-08-16 20:08:08 --> URI Class Initialized
INFO - 2018-08-16 20:08:08 --> Router Class Initialized
INFO - 2018-08-16 20:08:08 --> Output Class Initialized
INFO - 2018-08-16 20:08:08 --> Security Class Initialized
DEBUG - 2018-08-16 20:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:08:08 --> Input Class Initialized
INFO - 2018-08-16 20:08:08 --> Language Class Initialized
INFO - 2018-08-16 20:08:08 --> Loader Class Initialized
INFO - 2018-08-16 20:08:08 --> Controller Class Initialized
INFO - 2018-08-16 20:08:08 --> Database Driver Class Initialized
INFO - 2018-08-16 20:08:08 --> Model Class Initialized
INFO - 2018-08-16 20:08:08 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:08:08 --> Model Class Initialized
INFO - 2018-08-16 20:08:08 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:08:08 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 20:08:08 --> Final output sent to browser
DEBUG - 2018-08-16 20:08:08 --> Total execution time: 0.2147
ERROR - 2018-08-16 20:08:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:08:11 --> Config Class Initialized
INFO - 2018-08-16 20:08:11 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:08:11 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:08:11 --> Utf8 Class Initialized
INFO - 2018-08-16 20:08:11 --> URI Class Initialized
INFO - 2018-08-16 20:08:11 --> Router Class Initialized
INFO - 2018-08-16 20:08:11 --> Output Class Initialized
INFO - 2018-08-16 20:08:11 --> Security Class Initialized
DEBUG - 2018-08-16 20:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:08:11 --> Input Class Initialized
INFO - 2018-08-16 20:08:11 --> Language Class Initialized
INFO - 2018-08-16 20:08:11 --> Loader Class Initialized
INFO - 2018-08-16 20:08:11 --> Controller Class Initialized
INFO - 2018-08-16 20:08:11 --> Database Driver Class Initialized
INFO - 2018-08-16 20:08:11 --> Model Class Initialized
INFO - 2018-08-16 20:08:11 --> Helper loaded: form_helper
INFO - 2018-08-16 20:08:11 --> Helper loaded: url_helper
ERROR - 2018-08-16 20:08:11 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-08-16 20:08:11 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:08:11 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 57
ERROR - 2018-08-16 20:08:11 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 62
ERROR - 2018-08-16 20:08:11 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 71
ERROR - 2018-08-16 20:08:11 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 81
ERROR - 2018-08-16 20:08:11 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 90
INFO - 2018-08-16 20:08:11 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:08:11 --> Final output sent to browser
DEBUG - 2018-08-16 20:08:11 --> Total execution time: 0.2662
ERROR - 2018-08-16 20:08:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:08:11 --> Config Class Initialized
INFO - 2018-08-16 20:08:11 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:08:11 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:08:11 --> Utf8 Class Initialized
INFO - 2018-08-16 20:08:11 --> URI Class Initialized
INFO - 2018-08-16 20:08:11 --> Router Class Initialized
INFO - 2018-08-16 20:08:11 --> Output Class Initialized
INFO - 2018-08-16 20:08:11 --> Security Class Initialized
DEBUG - 2018-08-16 20:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:08:11 --> Input Class Initialized
INFO - 2018-08-16 20:08:11 --> Language Class Initialized
ERROR - 2018-08-16 20:08:11 --> 404 Page Not Found: UploadImages/admin
ERROR - 2018-08-16 20:08:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:08:11 --> Config Class Initialized
INFO - 2018-08-16 20:08:11 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:08:11 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:08:11 --> Utf8 Class Initialized
INFO - 2018-08-16 20:08:11 --> URI Class Initialized
DEBUG - 2018-08-16 20:08:11 --> No URI present. Default controller set.
INFO - 2018-08-16 20:08:11 --> Router Class Initialized
INFO - 2018-08-16 20:08:11 --> Output Class Initialized
INFO - 2018-08-16 20:08:11 --> Security Class Initialized
DEBUG - 2018-08-16 20:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:08:11 --> Input Class Initialized
INFO - 2018-08-16 20:08:11 --> Language Class Initialized
INFO - 2018-08-16 20:08:11 --> Loader Class Initialized
INFO - 2018-08-16 20:08:11 --> Controller Class Initialized
INFO - 2018-08-16 20:08:11 --> Database Driver Class Initialized
INFO - 2018-08-16 20:08:11 --> Model Class Initialized
INFO - 2018-08-16 20:08:11 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:08:11 --> Model Class Initialized
INFO - 2018-08-16 20:08:11 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:08:11 --> Final output sent to browser
DEBUG - 2018-08-16 20:08:11 --> Total execution time: 0.2060
ERROR - 2018-08-16 20:08:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:08:37 --> Config Class Initialized
INFO - 2018-08-16 20:08:37 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:08:37 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:08:37 --> Utf8 Class Initialized
INFO - 2018-08-16 20:08:38 --> URI Class Initialized
INFO - 2018-08-16 20:08:38 --> Router Class Initialized
INFO - 2018-08-16 20:08:38 --> Output Class Initialized
INFO - 2018-08-16 20:08:38 --> Security Class Initialized
DEBUG - 2018-08-16 20:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:08:38 --> Input Class Initialized
INFO - 2018-08-16 20:08:38 --> Language Class Initialized
INFO - 2018-08-16 20:08:38 --> Loader Class Initialized
INFO - 2018-08-16 20:08:38 --> Controller Class Initialized
INFO - 2018-08-16 20:08:38 --> Database Driver Class Initialized
INFO - 2018-08-16 20:08:38 --> Model Class Initialized
INFO - 2018-08-16 20:08:38 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:08:38 --> Model Class Initialized
INFO - 2018-08-16 20:08:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:08:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 20:08:38 --> Final output sent to browser
DEBUG - 2018-08-16 20:08:38 --> Total execution time: 0.1905
ERROR - 2018-08-16 20:08:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:08:40 --> Config Class Initialized
INFO - 2018-08-16 20:08:40 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:08:40 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:08:40 --> Utf8 Class Initialized
INFO - 2018-08-16 20:08:40 --> URI Class Initialized
INFO - 2018-08-16 20:08:40 --> Router Class Initialized
INFO - 2018-08-16 20:08:40 --> Output Class Initialized
INFO - 2018-08-16 20:08:40 --> Security Class Initialized
DEBUG - 2018-08-16 20:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:08:40 --> Input Class Initialized
INFO - 2018-08-16 20:08:40 --> Language Class Initialized
INFO - 2018-08-16 20:08:40 --> Loader Class Initialized
INFO - 2018-08-16 20:08:40 --> Controller Class Initialized
INFO - 2018-08-16 20:08:40 --> Database Driver Class Initialized
INFO - 2018-08-16 20:08:40 --> Model Class Initialized
INFO - 2018-08-16 20:08:40 --> Helper loaded: form_helper
INFO - 2018-08-16 20:08:40 --> Helper loaded: url_helper
ERROR - 2018-08-16 20:08:40 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\header.php 139
INFO - 2018-08-16 20:08:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:08:40 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 57
ERROR - 2018-08-16 20:08:40 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 62
ERROR - 2018-08-16 20:08:40 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 71
ERROR - 2018-08-16 20:08:40 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 81
ERROR - 2018-08-16 20:08:40 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\davidhood\application\views\admin_profile.php 90
INFO - 2018-08-16 20:08:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:08:40 --> Final output sent to browser
DEBUG - 2018-08-16 20:08:40 --> Total execution time: 0.2376
ERROR - 2018-08-16 20:08:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:08:40 --> Config Class Initialized
INFO - 2018-08-16 20:08:40 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:08:41 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:08:41 --> Utf8 Class Initialized
INFO - 2018-08-16 20:08:41 --> URI Class Initialized
INFO - 2018-08-16 20:08:41 --> Router Class Initialized
INFO - 2018-08-16 20:08:41 --> Output Class Initialized
INFO - 2018-08-16 20:08:41 --> Security Class Initialized
DEBUG - 2018-08-16 20:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:08:41 --> Input Class Initialized
INFO - 2018-08-16 20:08:41 --> Language Class Initialized
ERROR - 2018-08-16 20:08:41 --> 404 Page Not Found: UploadImages/admin
ERROR - 2018-08-16 20:09:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:09:31 --> Config Class Initialized
INFO - 2018-08-16 20:09:31 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:09:31 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:09:31 --> Utf8 Class Initialized
INFO - 2018-08-16 20:09:31 --> URI Class Initialized
INFO - 2018-08-16 20:09:31 --> Router Class Initialized
INFO - 2018-08-16 20:09:31 --> Output Class Initialized
INFO - 2018-08-16 20:09:31 --> Security Class Initialized
DEBUG - 2018-08-16 20:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:09:31 --> Input Class Initialized
INFO - 2018-08-16 20:09:31 --> Language Class Initialized
INFO - 2018-08-16 20:09:31 --> Loader Class Initialized
INFO - 2018-08-16 20:09:31 --> Controller Class Initialized
INFO - 2018-08-16 20:09:31 --> Database Driver Class Initialized
INFO - 2018-08-16 20:09:31 --> Model Class Initialized
INFO - 2018-08-16 20:09:32 --> Helper loaded: form_helper
INFO - 2018-08-16 20:09:32 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:09:32 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:09:32 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 57
ERROR - 2018-08-16 20:09:32 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 62
ERROR - 2018-08-16 20:09:32 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 71
ERROR - 2018-08-16 20:09:32 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 81
ERROR - 2018-08-16 20:09:32 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 90
INFO - 2018-08-16 20:09:32 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:09:32 --> Final output sent to browser
DEBUG - 2018-08-16 20:09:32 --> Total execution time: 0.2260
ERROR - 2018-08-16 20:09:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:09:32 --> Config Class Initialized
INFO - 2018-08-16 20:09:32 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:09:32 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:09:32 --> Utf8 Class Initialized
INFO - 2018-08-16 20:09:32 --> URI Class Initialized
INFO - 2018-08-16 20:09:32 --> Router Class Initialized
INFO - 2018-08-16 20:09:32 --> Output Class Initialized
INFO - 2018-08-16 20:09:32 --> Security Class Initialized
DEBUG - 2018-08-16 20:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:09:32 --> Input Class Initialized
INFO - 2018-08-16 20:09:32 --> Language Class Initialized
ERROR - 2018-08-16 20:09:32 --> 404 Page Not Found: UploadImages/admin
ERROR - 2018-08-16 20:09:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:09:39 --> Config Class Initialized
INFO - 2018-08-16 20:09:39 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:09:39 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:09:39 --> Utf8 Class Initialized
INFO - 2018-08-16 20:09:39 --> URI Class Initialized
INFO - 2018-08-16 20:09:39 --> Router Class Initialized
INFO - 2018-08-16 20:09:39 --> Output Class Initialized
INFO - 2018-08-16 20:09:39 --> Security Class Initialized
DEBUG - 2018-08-16 20:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:09:39 --> Input Class Initialized
INFO - 2018-08-16 20:09:39 --> Language Class Initialized
INFO - 2018-08-16 20:09:39 --> Loader Class Initialized
INFO - 2018-08-16 20:09:39 --> Controller Class Initialized
INFO - 2018-08-16 20:09:39 --> Database Driver Class Initialized
INFO - 2018-08-16 20:09:39 --> Model Class Initialized
INFO - 2018-08-16 20:09:39 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:09:39 --> Model Class Initialized
INFO - 2018-08-16 20:09:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:09:39 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 146
INFO - 2018-08-16 20:09:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:09:39 --> Final output sent to browser
DEBUG - 2018-08-16 20:09:39 --> Total execution time: 0.1950
ERROR - 2018-08-16 20:09:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:09:42 --> Config Class Initialized
INFO - 2018-08-16 20:09:42 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:09:42 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:09:42 --> Utf8 Class Initialized
INFO - 2018-08-16 20:09:42 --> URI Class Initialized
INFO - 2018-08-16 20:09:42 --> Router Class Initialized
INFO - 2018-08-16 20:09:42 --> Output Class Initialized
INFO - 2018-08-16 20:09:42 --> Security Class Initialized
DEBUG - 2018-08-16 20:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:09:42 --> Input Class Initialized
INFO - 2018-08-16 20:09:42 --> Language Class Initialized
INFO - 2018-08-16 20:09:42 --> Loader Class Initialized
INFO - 2018-08-16 20:09:42 --> Controller Class Initialized
INFO - 2018-08-16 20:09:42 --> Database Driver Class Initialized
INFO - 2018-08-16 20:09:42 --> Model Class Initialized
INFO - 2018-08-16 20:09:42 --> Helper loaded: form_helper
INFO - 2018-08-16 20:09:42 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:09:42 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:09:42 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 57
ERROR - 2018-08-16 20:09:42 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 62
ERROR - 2018-08-16 20:09:42 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 71
ERROR - 2018-08-16 20:09:42 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 81
ERROR - 2018-08-16 20:09:42 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 90
INFO - 2018-08-16 20:09:42 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:09:42 --> Final output sent to browser
DEBUG - 2018-08-16 20:09:42 --> Total execution time: 0.2631
ERROR - 2018-08-16 20:09:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:09:42 --> Config Class Initialized
INFO - 2018-08-16 20:09:42 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:09:42 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:09:42 --> Utf8 Class Initialized
INFO - 2018-08-16 20:09:42 --> URI Class Initialized
INFO - 2018-08-16 20:09:42 --> Router Class Initialized
INFO - 2018-08-16 20:09:42 --> Output Class Initialized
INFO - 2018-08-16 20:09:42 --> Security Class Initialized
DEBUG - 2018-08-16 20:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:09:42 --> Input Class Initialized
INFO - 2018-08-16 20:09:42 --> Language Class Initialized
ERROR - 2018-08-16 20:09:42 --> 404 Page Not Found: UploadImages/admin
ERROR - 2018-08-16 20:12:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:12:39 --> Config Class Initialized
INFO - 2018-08-16 20:12:39 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:12:39 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:12:39 --> Utf8 Class Initialized
INFO - 2018-08-16 20:12:39 --> URI Class Initialized
INFO - 2018-08-16 20:12:39 --> Router Class Initialized
INFO - 2018-08-16 20:12:39 --> Output Class Initialized
INFO - 2018-08-16 20:12:39 --> Security Class Initialized
DEBUG - 2018-08-16 20:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:12:39 --> Input Class Initialized
INFO - 2018-08-16 20:12:39 --> Language Class Initialized
INFO - 2018-08-16 20:12:39 --> Loader Class Initialized
INFO - 2018-08-16 20:12:39 --> Controller Class Initialized
INFO - 2018-08-16 20:12:39 --> Database Driver Class Initialized
INFO - 2018-08-16 20:12:39 --> Model Class Initialized
INFO - 2018-08-16 20:12:39 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:12:39 --> Model Class Initialized
ERROR - 2018-08-16 20:12:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:12:39 --> Config Class Initialized
INFO - 2018-08-16 20:12:39 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:12:39 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:12:39 --> Utf8 Class Initialized
INFO - 2018-08-16 20:12:39 --> URI Class Initialized
DEBUG - 2018-08-16 20:12:39 --> No URI present. Default controller set.
INFO - 2018-08-16 20:12:39 --> Router Class Initialized
INFO - 2018-08-16 20:12:39 --> Output Class Initialized
INFO - 2018-08-16 20:12:39 --> Security Class Initialized
DEBUG - 2018-08-16 20:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:12:39 --> Input Class Initialized
INFO - 2018-08-16 20:12:39 --> Language Class Initialized
INFO - 2018-08-16 20:12:39 --> Loader Class Initialized
INFO - 2018-08-16 20:12:39 --> Controller Class Initialized
INFO - 2018-08-16 20:12:39 --> Database Driver Class Initialized
INFO - 2018-08-16 20:12:39 --> Model Class Initialized
INFO - 2018-08-16 20:12:40 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:12:40 --> Model Class Initialized
INFO - 2018-08-16 20:12:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:12:40 --> Final output sent to browser
DEBUG - 2018-08-16 20:12:40 --> Total execution time: 0.1952
ERROR - 2018-08-16 20:12:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:12:54 --> Config Class Initialized
INFO - 2018-08-16 20:12:54 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:12:54 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:12:54 --> Utf8 Class Initialized
INFO - 2018-08-16 20:12:54 --> URI Class Initialized
INFO - 2018-08-16 20:12:54 --> Router Class Initialized
INFO - 2018-08-16 20:12:54 --> Output Class Initialized
INFO - 2018-08-16 20:12:54 --> Security Class Initialized
DEBUG - 2018-08-16 20:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:12:54 --> Input Class Initialized
INFO - 2018-08-16 20:12:54 --> Language Class Initialized
INFO - 2018-08-16 20:12:54 --> Loader Class Initialized
INFO - 2018-08-16 20:12:54 --> Controller Class Initialized
INFO - 2018-08-16 20:12:54 --> Database Driver Class Initialized
INFO - 2018-08-16 20:12:54 --> Model Class Initialized
INFO - 2018-08-16 20:12:54 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:12:54 --> Model Class Initialized
ERROR - 2018-08-16 20:12:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:12:54 --> Config Class Initialized
INFO - 2018-08-16 20:12:54 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:12:54 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:12:54 --> Utf8 Class Initialized
INFO - 2018-08-16 20:12:54 --> URI Class Initialized
INFO - 2018-08-16 20:12:54 --> Router Class Initialized
INFO - 2018-08-16 20:12:54 --> Output Class Initialized
INFO - 2018-08-16 20:12:54 --> Security Class Initialized
DEBUG - 2018-08-16 20:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:12:54 --> Input Class Initialized
INFO - 2018-08-16 20:12:54 --> Language Class Initialized
INFO - 2018-08-16 20:12:54 --> Loader Class Initialized
INFO - 2018-08-16 20:12:54 --> Controller Class Initialized
INFO - 2018-08-16 20:12:54 --> Database Driver Class Initialized
INFO - 2018-08-16 20:12:54 --> Model Class Initialized
INFO - 2018-08-16 20:12:54 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:12:54 --> Model Class Initialized
INFO - 2018-08-16 20:12:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:12:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 20:12:54 --> Final output sent to browser
DEBUG - 2018-08-16 20:12:54 --> Total execution time: 0.2061
ERROR - 2018-08-16 20:12:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:12:57 --> Config Class Initialized
INFO - 2018-08-16 20:12:57 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:12:57 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:12:57 --> Utf8 Class Initialized
INFO - 2018-08-16 20:12:57 --> URI Class Initialized
INFO - 2018-08-16 20:12:57 --> Router Class Initialized
INFO - 2018-08-16 20:12:57 --> Output Class Initialized
INFO - 2018-08-16 20:12:57 --> Security Class Initialized
DEBUG - 2018-08-16 20:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:12:57 --> Input Class Initialized
INFO - 2018-08-16 20:12:57 --> Language Class Initialized
INFO - 2018-08-16 20:12:57 --> Loader Class Initialized
INFO - 2018-08-16 20:12:57 --> Controller Class Initialized
INFO - 2018-08-16 20:12:57 --> Database Driver Class Initialized
INFO - 2018-08-16 20:12:57 --> Model Class Initialized
INFO - 2018-08-16 20:12:57 --> Helper loaded: form_helper
INFO - 2018-08-16 20:12:57 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:12:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:12:57 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 57
ERROR - 2018-08-16 20:12:57 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 62
ERROR - 2018-08-16 20:12:57 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 71
ERROR - 2018-08-16 20:12:57 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 81
ERROR - 2018-08-16 20:12:57 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\admin_profile.php 90
INFO - 2018-08-16 20:12:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:12:57 --> Final output sent to browser
DEBUG - 2018-08-16 20:12:57 --> Total execution time: 0.2678
ERROR - 2018-08-16 20:12:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:12:57 --> Config Class Initialized
INFO - 2018-08-16 20:12:57 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:12:57 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:12:57 --> Utf8 Class Initialized
INFO - 2018-08-16 20:12:57 --> URI Class Initialized
INFO - 2018-08-16 20:12:57 --> Router Class Initialized
INFO - 2018-08-16 20:12:57 --> Output Class Initialized
INFO - 2018-08-16 20:12:57 --> Security Class Initialized
DEBUG - 2018-08-16 20:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:12:57 --> Input Class Initialized
INFO - 2018-08-16 20:12:57 --> Language Class Initialized
ERROR - 2018-08-16 20:12:57 --> 404 Page Not Found: UploadImages/admin
ERROR - 2018-08-16 20:16:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:16:11 --> Config Class Initialized
INFO - 2018-08-16 20:16:11 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:16:11 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:16:11 --> Utf8 Class Initialized
INFO - 2018-08-16 20:16:11 --> URI Class Initialized
INFO - 2018-08-16 20:16:11 --> Router Class Initialized
INFO - 2018-08-16 20:16:11 --> Output Class Initialized
INFO - 2018-08-16 20:16:11 --> Security Class Initialized
DEBUG - 2018-08-16 20:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:16:11 --> Input Class Initialized
INFO - 2018-08-16 20:16:11 --> Language Class Initialized
INFO - 2018-08-16 20:16:11 --> Loader Class Initialized
INFO - 2018-08-16 20:16:11 --> Controller Class Initialized
INFO - 2018-08-16 20:16:11 --> Database Driver Class Initialized
INFO - 2018-08-16 20:16:11 --> Model Class Initialized
INFO - 2018-08-16 20:16:11 --> Helper loaded: form_helper
INFO - 2018-08-16 20:16:11 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:16:11 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:16:11 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\davidhood\application\models\Admin_model.php 43
ERROR - 2018-08-16 20:16:11 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\davidhood\application\models\Admin_model.php 44
ERROR - 2018-08-16 20:16:11 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\davidhood\application\controllers\Admin.php 37
INFO - 2018-08-16 20:16:11 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:16:11 --> Final output sent to browser
DEBUG - 2018-08-16 20:16:11 --> Total execution time: 0.2284
ERROR - 2018-08-16 20:16:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:16:11 --> Config Class Initialized
INFO - 2018-08-16 20:16:11 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:16:11 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:16:11 --> Utf8 Class Initialized
INFO - 2018-08-16 20:16:11 --> URI Class Initialized
INFO - 2018-08-16 20:16:11 --> Router Class Initialized
INFO - 2018-08-16 20:16:11 --> Output Class Initialized
INFO - 2018-08-16 20:16:11 --> Security Class Initialized
DEBUG - 2018-08-16 20:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:16:12 --> Input Class Initialized
INFO - 2018-08-16 20:16:12 --> Language Class Initialized
ERROR - 2018-08-16 20:16:12 --> 404 Page Not Found: UploadImages/admin
ERROR - 2018-08-16 20:17:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:17:30 --> Config Class Initialized
INFO - 2018-08-16 20:17:30 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:17:30 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:17:30 --> Utf8 Class Initialized
INFO - 2018-08-16 20:17:30 --> URI Class Initialized
INFO - 2018-08-16 20:17:30 --> Router Class Initialized
INFO - 2018-08-16 20:17:30 --> Output Class Initialized
INFO - 2018-08-16 20:17:30 --> Security Class Initialized
DEBUG - 2018-08-16 20:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:17:30 --> Input Class Initialized
INFO - 2018-08-16 20:17:30 --> Language Class Initialized
INFO - 2018-08-16 20:17:30 --> Loader Class Initialized
INFO - 2018-08-16 20:17:30 --> Controller Class Initialized
INFO - 2018-08-16 20:17:30 --> Database Driver Class Initialized
INFO - 2018-08-16 20:17:30 --> Model Class Initialized
INFO - 2018-08-16 20:17:31 --> Helper loaded: form_helper
INFO - 2018-08-16 20:17:31 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:17:31 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:17:31 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\davidhood\application\controllers\Admin.php 37
ERROR - 2018-08-16 20:17:31 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\davidhood\application\views\admin_profile.php 56
INFO - 2018-08-16 20:17:31 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:17:31 --> Final output sent to browser
DEBUG - 2018-08-16 20:17:31 --> Total execution time: 0.2239
ERROR - 2018-08-16 20:17:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:17:31 --> Config Class Initialized
INFO - 2018-08-16 20:17:31 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:17:31 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:17:31 --> Utf8 Class Initialized
INFO - 2018-08-16 20:17:31 --> URI Class Initialized
INFO - 2018-08-16 20:17:31 --> Router Class Initialized
INFO - 2018-08-16 20:17:31 --> Output Class Initialized
INFO - 2018-08-16 20:17:31 --> Security Class Initialized
DEBUG - 2018-08-16 20:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:17:31 --> Input Class Initialized
INFO - 2018-08-16 20:17:31 --> Language Class Initialized
ERROR - 2018-08-16 20:17:31 --> 404 Page Not Found: UploadImages/admin
ERROR - 2018-08-16 20:17:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:17:55 --> Config Class Initialized
INFO - 2018-08-16 20:17:55 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:17:55 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:17:55 --> Utf8 Class Initialized
INFO - 2018-08-16 20:17:55 --> URI Class Initialized
INFO - 2018-08-16 20:17:55 --> Router Class Initialized
INFO - 2018-08-16 20:17:55 --> Output Class Initialized
INFO - 2018-08-16 20:17:55 --> Security Class Initialized
DEBUG - 2018-08-16 20:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:17:55 --> Input Class Initialized
INFO - 2018-08-16 20:17:55 --> Language Class Initialized
INFO - 2018-08-16 20:17:55 --> Loader Class Initialized
INFO - 2018-08-16 20:17:55 --> Controller Class Initialized
INFO - 2018-08-16 20:17:55 --> Database Driver Class Initialized
INFO - 2018-08-16 20:17:55 --> Model Class Initialized
INFO - 2018-08-16 20:17:55 --> Helper loaded: form_helper
INFO - 2018-08-16 20:17:55 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:17:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:17:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\davidhood\application\views\admin_profile.php 56
ERROR - 2018-08-16 20:17:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\davidhood\application\views\admin_profile.php 65
INFO - 2018-08-16 20:17:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:17:55 --> Final output sent to browser
DEBUG - 2018-08-16 20:17:55 --> Total execution time: 0.2061
ERROR - 2018-08-16 20:17:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:17:55 --> Config Class Initialized
INFO - 2018-08-16 20:17:55 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:17:55 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:17:55 --> Utf8 Class Initialized
INFO - 2018-08-16 20:17:55 --> URI Class Initialized
INFO - 2018-08-16 20:17:55 --> Router Class Initialized
INFO - 2018-08-16 20:17:55 --> Output Class Initialized
INFO - 2018-08-16 20:17:55 --> Security Class Initialized
DEBUG - 2018-08-16 20:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:17:55 --> Input Class Initialized
INFO - 2018-08-16 20:17:55 --> Language Class Initialized
ERROR - 2018-08-16 20:17:55 --> 404 Page Not Found: UploadImages/admin
ERROR - 2018-08-16 20:18:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:18:44 --> Config Class Initialized
INFO - 2018-08-16 20:18:44 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:18:44 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:18:44 --> Utf8 Class Initialized
INFO - 2018-08-16 20:18:44 --> URI Class Initialized
INFO - 2018-08-16 20:18:44 --> Router Class Initialized
INFO - 2018-08-16 20:18:44 --> Output Class Initialized
INFO - 2018-08-16 20:18:44 --> Security Class Initialized
DEBUG - 2018-08-16 20:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:18:44 --> Input Class Initialized
INFO - 2018-08-16 20:18:44 --> Language Class Initialized
INFO - 2018-08-16 20:18:44 --> Loader Class Initialized
INFO - 2018-08-16 20:18:44 --> Controller Class Initialized
INFO - 2018-08-16 20:18:44 --> Database Driver Class Initialized
INFO - 2018-08-16 20:18:44 --> Model Class Initialized
INFO - 2018-08-16 20:18:44 --> Helper loaded: form_helper
INFO - 2018-08-16 20:18:44 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:18:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:18:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:18:44 --> Final output sent to browser
DEBUG - 2018-08-16 20:18:44 --> Total execution time: 0.1975
ERROR - 2018-08-16 20:18:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:18:44 --> Config Class Initialized
INFO - 2018-08-16 20:18:44 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:18:44 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:18:44 --> Utf8 Class Initialized
INFO - 2018-08-16 20:18:44 --> URI Class Initialized
INFO - 2018-08-16 20:18:44 --> Router Class Initialized
INFO - 2018-08-16 20:18:44 --> Output Class Initialized
INFO - 2018-08-16 20:18:44 --> Security Class Initialized
DEBUG - 2018-08-16 20:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:18:44 --> Input Class Initialized
INFO - 2018-08-16 20:18:44 --> Language Class Initialized
ERROR - 2018-08-16 20:18:44 --> 404 Page Not Found: UploadImages/admin
ERROR - 2018-08-16 20:19:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:19:45 --> Config Class Initialized
INFO - 2018-08-16 20:19:45 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:19:45 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:19:45 --> Utf8 Class Initialized
INFO - 2018-08-16 20:19:45 --> URI Class Initialized
INFO - 2018-08-16 20:19:45 --> Router Class Initialized
INFO - 2018-08-16 20:19:45 --> Output Class Initialized
INFO - 2018-08-16 20:19:45 --> Security Class Initialized
DEBUG - 2018-08-16 20:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:19:45 --> Input Class Initialized
INFO - 2018-08-16 20:19:45 --> Language Class Initialized
INFO - 2018-08-16 20:19:45 --> Loader Class Initialized
INFO - 2018-08-16 20:19:45 --> Controller Class Initialized
INFO - 2018-08-16 20:19:45 --> Database Driver Class Initialized
INFO - 2018-08-16 20:19:45 --> Model Class Initialized
INFO - 2018-08-16 20:19:45 --> Helper loaded: form_helper
INFO - 2018-08-16 20:19:45 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:19:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:19:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:19:45 --> Final output sent to browser
DEBUG - 2018-08-16 20:19:45 --> Total execution time: 0.2075
ERROR - 2018-08-16 20:21:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:21:19 --> Config Class Initialized
INFO - 2018-08-16 20:21:19 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:21:19 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:21:19 --> Utf8 Class Initialized
INFO - 2018-08-16 20:21:19 --> URI Class Initialized
INFO - 2018-08-16 20:21:19 --> Router Class Initialized
INFO - 2018-08-16 20:21:19 --> Output Class Initialized
INFO - 2018-08-16 20:21:19 --> Security Class Initialized
DEBUG - 2018-08-16 20:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:21:19 --> Input Class Initialized
INFO - 2018-08-16 20:21:19 --> Language Class Initialized
INFO - 2018-08-16 20:21:19 --> Loader Class Initialized
INFO - 2018-08-16 20:21:19 --> Controller Class Initialized
INFO - 2018-08-16 20:21:19 --> Database Driver Class Initialized
INFO - 2018-08-16 20:21:19 --> Model Class Initialized
INFO - 2018-08-16 20:21:19 --> Helper loaded: form_helper
INFO - 2018-08-16 20:21:19 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:21:19 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:21:19 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:21:19 --> Final output sent to browser
DEBUG - 2018-08-16 20:21:19 --> Total execution time: 0.1993
ERROR - 2018-08-16 20:23:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:23:57 --> Config Class Initialized
INFO - 2018-08-16 20:23:57 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:23:57 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:23:57 --> Utf8 Class Initialized
INFO - 2018-08-16 20:23:57 --> URI Class Initialized
INFO - 2018-08-16 20:23:57 --> Router Class Initialized
INFO - 2018-08-16 20:23:57 --> Output Class Initialized
INFO - 2018-08-16 20:23:57 --> Security Class Initialized
DEBUG - 2018-08-16 20:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:23:57 --> Input Class Initialized
INFO - 2018-08-16 20:23:57 --> Language Class Initialized
INFO - 2018-08-16 20:23:57 --> Loader Class Initialized
INFO - 2018-08-16 20:23:57 --> Controller Class Initialized
INFO - 2018-08-16 20:23:57 --> Database Driver Class Initialized
INFO - 2018-08-16 20:23:58 --> Model Class Initialized
INFO - 2018-08-16 20:23:58 --> Helper loaded: form_helper
INFO - 2018-08-16 20:23:58 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:23:58 --> Session: Class initialized using 'files' driver.
ERROR - 2018-08-16 20:23:58 --> Severity: error --> Exception: Too few arguments to function Admin_model::update_admin(), 2 passed in C:\xampp\htdocs\davidhood\application\controllers\Admin.php on line 46 and exactly 3 expected C:\xampp\htdocs\davidhood\application\models\Admin_model.php 32
ERROR - 2018-08-16 20:24:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:24:22 --> Config Class Initialized
INFO - 2018-08-16 20:24:22 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:24:22 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:24:22 --> Utf8 Class Initialized
INFO - 2018-08-16 20:24:22 --> URI Class Initialized
INFO - 2018-08-16 20:24:22 --> Router Class Initialized
INFO - 2018-08-16 20:24:22 --> Output Class Initialized
INFO - 2018-08-16 20:24:22 --> Security Class Initialized
DEBUG - 2018-08-16 20:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:24:22 --> Input Class Initialized
INFO - 2018-08-16 20:24:22 --> Language Class Initialized
INFO - 2018-08-16 20:24:22 --> Loader Class Initialized
INFO - 2018-08-16 20:24:22 --> Controller Class Initialized
INFO - 2018-08-16 20:24:22 --> Database Driver Class Initialized
INFO - 2018-08-16 20:24:23 --> Model Class Initialized
INFO - 2018-08-16 20:24:23 --> Helper loaded: form_helper
INFO - 2018-08-16 20:24:23 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:24:23 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:24:23 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:24:23 --> Final output sent to browser
DEBUG - 2018-08-16 20:24:23 --> Total execution time: 0.2728
ERROR - 2018-08-16 20:24:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:24:27 --> Config Class Initialized
INFO - 2018-08-16 20:24:27 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:24:27 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:24:27 --> Utf8 Class Initialized
INFO - 2018-08-16 20:24:27 --> URI Class Initialized
INFO - 2018-08-16 20:24:27 --> Router Class Initialized
INFO - 2018-08-16 20:24:27 --> Output Class Initialized
INFO - 2018-08-16 20:24:27 --> Security Class Initialized
DEBUG - 2018-08-16 20:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:24:27 --> Input Class Initialized
INFO - 2018-08-16 20:24:27 --> Language Class Initialized
INFO - 2018-08-16 20:24:27 --> Loader Class Initialized
INFO - 2018-08-16 20:24:27 --> Controller Class Initialized
INFO - 2018-08-16 20:24:27 --> Database Driver Class Initialized
INFO - 2018-08-16 20:24:27 --> Model Class Initialized
INFO - 2018-08-16 20:24:27 --> Helper loaded: form_helper
INFO - 2018-08-16 20:24:27 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:24:27 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:24:27 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:24:27 --> Final output sent to browser
DEBUG - 2018-08-16 20:24:27 --> Total execution time: 0.2426
ERROR - 2018-08-16 20:24:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:24:31 --> Config Class Initialized
INFO - 2018-08-16 20:24:31 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:24:31 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:24:31 --> Utf8 Class Initialized
INFO - 2018-08-16 20:24:31 --> URI Class Initialized
INFO - 2018-08-16 20:24:31 --> Router Class Initialized
INFO - 2018-08-16 20:24:31 --> Output Class Initialized
INFO - 2018-08-16 20:24:31 --> Security Class Initialized
DEBUG - 2018-08-16 20:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:24:31 --> Input Class Initialized
INFO - 2018-08-16 20:24:32 --> Language Class Initialized
INFO - 2018-08-16 20:24:32 --> Loader Class Initialized
INFO - 2018-08-16 20:24:32 --> Controller Class Initialized
INFO - 2018-08-16 20:24:32 --> Database Driver Class Initialized
INFO - 2018-08-16 20:24:32 --> Model Class Initialized
INFO - 2018-08-16 20:24:32 --> Helper loaded: form_helper
INFO - 2018-08-16 20:24:32 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:24:32 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:24:32 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:24:32 --> Final output sent to browser
DEBUG - 2018-08-16 20:24:32 --> Total execution time: 0.2511
ERROR - 2018-08-16 20:24:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:24:33 --> Config Class Initialized
INFO - 2018-08-16 20:24:33 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:24:33 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:24:33 --> Utf8 Class Initialized
INFO - 2018-08-16 20:24:33 --> URI Class Initialized
INFO - 2018-08-16 20:24:33 --> Router Class Initialized
INFO - 2018-08-16 20:24:33 --> Output Class Initialized
INFO - 2018-08-16 20:24:33 --> Security Class Initialized
DEBUG - 2018-08-16 20:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:24:33 --> Input Class Initialized
INFO - 2018-08-16 20:24:33 --> Language Class Initialized
INFO - 2018-08-16 20:24:33 --> Loader Class Initialized
INFO - 2018-08-16 20:24:33 --> Controller Class Initialized
INFO - 2018-08-16 20:24:33 --> Database Driver Class Initialized
INFO - 2018-08-16 20:24:33 --> Model Class Initialized
INFO - 2018-08-16 20:24:33 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:24:33 --> Model Class Initialized
INFO - 2018-08-16 20:24:33 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:24:33 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 146
INFO - 2018-08-16 20:24:33 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:24:33 --> Final output sent to browser
DEBUG - 2018-08-16 20:24:33 --> Total execution time: 0.2173
ERROR - 2018-08-16 20:24:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:24:36 --> Config Class Initialized
INFO - 2018-08-16 20:24:36 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:24:36 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:24:36 --> Utf8 Class Initialized
INFO - 2018-08-16 20:24:36 --> URI Class Initialized
INFO - 2018-08-16 20:24:36 --> Router Class Initialized
INFO - 2018-08-16 20:24:36 --> Output Class Initialized
INFO - 2018-08-16 20:24:36 --> Security Class Initialized
DEBUG - 2018-08-16 20:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:24:36 --> Input Class Initialized
INFO - 2018-08-16 20:24:36 --> Language Class Initialized
INFO - 2018-08-16 20:24:36 --> Loader Class Initialized
INFO - 2018-08-16 20:24:36 --> Controller Class Initialized
INFO - 2018-08-16 20:24:36 --> Database Driver Class Initialized
INFO - 2018-08-16 20:24:36 --> Model Class Initialized
INFO - 2018-08-16 20:24:36 --> Helper loaded: form_helper
INFO - 2018-08-16 20:24:36 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:24:36 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:24:36 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:24:36 --> Final output sent to browser
DEBUG - 2018-08-16 20:24:36 --> Total execution time: 0.2323
ERROR - 2018-08-16 20:24:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:24:38 --> Config Class Initialized
INFO - 2018-08-16 20:24:38 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:24:38 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:24:38 --> Utf8 Class Initialized
INFO - 2018-08-16 20:24:38 --> URI Class Initialized
INFO - 2018-08-16 20:24:38 --> Router Class Initialized
INFO - 2018-08-16 20:24:38 --> Output Class Initialized
INFO - 2018-08-16 20:24:38 --> Security Class Initialized
DEBUG - 2018-08-16 20:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:24:38 --> Input Class Initialized
INFO - 2018-08-16 20:24:38 --> Language Class Initialized
INFO - 2018-08-16 20:24:38 --> Loader Class Initialized
INFO - 2018-08-16 20:24:38 --> Controller Class Initialized
INFO - 2018-08-16 20:24:38 --> Database Driver Class Initialized
INFO - 2018-08-16 20:24:38 --> Model Class Initialized
INFO - 2018-08-16 20:24:38 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:24:38 --> Model Class Initialized
ERROR - 2018-08-16 20:24:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:24:38 --> Config Class Initialized
INFO - 2018-08-16 20:24:38 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:24:38 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:24:38 --> Utf8 Class Initialized
INFO - 2018-08-16 20:24:38 --> URI Class Initialized
DEBUG - 2018-08-16 20:24:38 --> No URI present. Default controller set.
INFO - 2018-08-16 20:24:38 --> Router Class Initialized
INFO - 2018-08-16 20:24:38 --> Output Class Initialized
INFO - 2018-08-16 20:24:38 --> Security Class Initialized
DEBUG - 2018-08-16 20:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:24:38 --> Input Class Initialized
INFO - 2018-08-16 20:24:38 --> Language Class Initialized
INFO - 2018-08-16 20:24:38 --> Loader Class Initialized
INFO - 2018-08-16 20:24:38 --> Controller Class Initialized
INFO - 2018-08-16 20:24:38 --> Database Driver Class Initialized
INFO - 2018-08-16 20:24:38 --> Model Class Initialized
INFO - 2018-08-16 20:24:38 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:24:38 --> Model Class Initialized
INFO - 2018-08-16 20:24:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:24:39 --> Final output sent to browser
DEBUG - 2018-08-16 20:24:39 --> Total execution time: 0.1991
ERROR - 2018-08-16 20:24:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:24:39 --> Config Class Initialized
INFO - 2018-08-16 20:24:39 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:24:39 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:24:39 --> Utf8 Class Initialized
INFO - 2018-08-16 20:24:39 --> URI Class Initialized
INFO - 2018-08-16 20:24:40 --> Router Class Initialized
INFO - 2018-08-16 20:24:40 --> Output Class Initialized
INFO - 2018-08-16 20:24:40 --> Security Class Initialized
DEBUG - 2018-08-16 20:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:24:40 --> Input Class Initialized
INFO - 2018-08-16 20:24:40 --> Language Class Initialized
INFO - 2018-08-16 20:24:40 --> Loader Class Initialized
INFO - 2018-08-16 20:24:40 --> Controller Class Initialized
INFO - 2018-08-16 20:24:40 --> Database Driver Class Initialized
INFO - 2018-08-16 20:24:40 --> Model Class Initialized
INFO - 2018-08-16 20:24:40 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:24:40 --> Model Class Initialized
INFO - 2018-08-16 20:24:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:24:40 --> Final output sent to browser
DEBUG - 2018-08-16 20:24:40 --> Total execution time: 0.2071
ERROR - 2018-08-16 20:24:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:24:40 --> Config Class Initialized
INFO - 2018-08-16 20:24:40 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:24:40 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:24:40 --> Utf8 Class Initialized
INFO - 2018-08-16 20:24:40 --> URI Class Initialized
INFO - 2018-08-16 20:24:40 --> Router Class Initialized
INFO - 2018-08-16 20:24:40 --> Output Class Initialized
INFO - 2018-08-16 20:24:40 --> Security Class Initialized
DEBUG - 2018-08-16 20:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:24:40 --> Input Class Initialized
INFO - 2018-08-16 20:24:40 --> Language Class Initialized
ERROR - 2018-08-16 20:24:40 --> 404 Page Not Found: Login/uploadImages
ERROR - 2018-08-16 20:24:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:24:47 --> Config Class Initialized
INFO - 2018-08-16 20:24:47 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:24:47 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:24:47 --> Utf8 Class Initialized
INFO - 2018-08-16 20:24:47 --> URI Class Initialized
INFO - 2018-08-16 20:24:47 --> Router Class Initialized
INFO - 2018-08-16 20:24:47 --> Output Class Initialized
INFO - 2018-08-16 20:24:47 --> Security Class Initialized
DEBUG - 2018-08-16 20:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:24:47 --> Input Class Initialized
INFO - 2018-08-16 20:24:47 --> Language Class Initialized
INFO - 2018-08-16 20:24:47 --> Loader Class Initialized
INFO - 2018-08-16 20:24:47 --> Controller Class Initialized
INFO - 2018-08-16 20:24:47 --> Database Driver Class Initialized
INFO - 2018-08-16 20:24:47 --> Model Class Initialized
INFO - 2018-08-16 20:24:47 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:24:47 --> Model Class Initialized
INFO - 2018-08-16 20:24:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:24:47 --> Final output sent to browser
DEBUG - 2018-08-16 20:24:47 --> Total execution time: 0.1892
ERROR - 2018-08-16 20:24:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:24:48 --> Config Class Initialized
INFO - 2018-08-16 20:24:48 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:24:48 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:24:48 --> Utf8 Class Initialized
INFO - 2018-08-16 20:24:48 --> URI Class Initialized
INFO - 2018-08-16 20:24:48 --> Router Class Initialized
INFO - 2018-08-16 20:24:48 --> Output Class Initialized
INFO - 2018-08-16 20:24:48 --> Security Class Initialized
DEBUG - 2018-08-16 20:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:24:48 --> Input Class Initialized
INFO - 2018-08-16 20:24:48 --> Language Class Initialized
ERROR - 2018-08-16 20:24:48 --> 404 Page Not Found: Login/uploadImages
ERROR - 2018-08-16 20:24:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:24:51 --> Config Class Initialized
INFO - 2018-08-16 20:24:51 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:24:51 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:24:51 --> Utf8 Class Initialized
INFO - 2018-08-16 20:24:51 --> URI Class Initialized
DEBUG - 2018-08-16 20:24:51 --> No URI present. Default controller set.
INFO - 2018-08-16 20:24:51 --> Router Class Initialized
INFO - 2018-08-16 20:24:51 --> Output Class Initialized
INFO - 2018-08-16 20:24:51 --> Security Class Initialized
DEBUG - 2018-08-16 20:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:24:51 --> Input Class Initialized
INFO - 2018-08-16 20:24:51 --> Language Class Initialized
INFO - 2018-08-16 20:24:51 --> Loader Class Initialized
INFO - 2018-08-16 20:24:51 --> Controller Class Initialized
INFO - 2018-08-16 20:24:51 --> Database Driver Class Initialized
INFO - 2018-08-16 20:24:51 --> Model Class Initialized
INFO - 2018-08-16 20:24:51 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:24:51 --> Model Class Initialized
INFO - 2018-08-16 20:24:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:24:51 --> Final output sent to browser
DEBUG - 2018-08-16 20:24:51 --> Total execution time: 0.1981
ERROR - 2018-08-16 20:25:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:25:40 --> Config Class Initialized
INFO - 2018-08-16 20:25:40 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:25:40 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:25:40 --> Utf8 Class Initialized
INFO - 2018-08-16 20:25:40 --> URI Class Initialized
INFO - 2018-08-16 20:25:40 --> Router Class Initialized
INFO - 2018-08-16 20:25:40 --> Output Class Initialized
INFO - 2018-08-16 20:25:40 --> Security Class Initialized
DEBUG - 2018-08-16 20:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:25:40 --> Input Class Initialized
INFO - 2018-08-16 20:25:40 --> Language Class Initialized
INFO - 2018-08-16 20:25:40 --> Loader Class Initialized
INFO - 2018-08-16 20:25:40 --> Controller Class Initialized
INFO - 2018-08-16 20:25:40 --> Database Driver Class Initialized
INFO - 2018-08-16 20:25:40 --> Model Class Initialized
INFO - 2018-08-16 20:25:40 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:25:40 --> Model Class Initialized
INFO - 2018-08-16 20:25:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:25:40 --> Final output sent to browser
DEBUG - 2018-08-16 20:25:40 --> Total execution time: 0.2106
ERROR - 2018-08-16 20:25:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:25:40 --> Config Class Initialized
INFO - 2018-08-16 20:25:40 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:25:40 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:25:40 --> Utf8 Class Initialized
INFO - 2018-08-16 20:25:40 --> URI Class Initialized
INFO - 2018-08-16 20:25:40 --> Router Class Initialized
INFO - 2018-08-16 20:25:40 --> Output Class Initialized
INFO - 2018-08-16 20:25:40 --> Security Class Initialized
DEBUG - 2018-08-16 20:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:25:40 --> Input Class Initialized
INFO - 2018-08-16 20:25:40 --> Language Class Initialized
ERROR - 2018-08-16 20:25:40 --> 404 Page Not Found: Login/uploadImages
ERROR - 2018-08-16 20:27:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:27:36 --> Config Class Initialized
INFO - 2018-08-16 20:27:36 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:27:36 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:27:36 --> Utf8 Class Initialized
INFO - 2018-08-16 20:27:36 --> URI Class Initialized
INFO - 2018-08-16 20:27:36 --> Router Class Initialized
INFO - 2018-08-16 20:27:36 --> Output Class Initialized
INFO - 2018-08-16 20:27:36 --> Security Class Initialized
DEBUG - 2018-08-16 20:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:27:36 --> Input Class Initialized
INFO - 2018-08-16 20:27:36 --> Language Class Initialized
INFO - 2018-08-16 20:27:36 --> Loader Class Initialized
INFO - 2018-08-16 20:27:36 --> Controller Class Initialized
INFO - 2018-08-16 20:27:36 --> Database Driver Class Initialized
INFO - 2018-08-16 20:27:36 --> Model Class Initialized
INFO - 2018-08-16 20:27:36 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:27:36 --> Model Class Initialized
INFO - 2018-08-16 20:27:36 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:27:36 --> Final output sent to browser
DEBUG - 2018-08-16 20:27:36 --> Total execution time: 0.2027
ERROR - 2018-08-16 20:27:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:27:36 --> Config Class Initialized
INFO - 2018-08-16 20:27:36 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:27:36 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:27:36 --> Utf8 Class Initialized
INFO - 2018-08-16 20:27:36 --> URI Class Initialized
INFO - 2018-08-16 20:27:36 --> Router Class Initialized
INFO - 2018-08-16 20:27:36 --> Output Class Initialized
INFO - 2018-08-16 20:27:36 --> Security Class Initialized
DEBUG - 2018-08-16 20:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:27:36 --> Input Class Initialized
INFO - 2018-08-16 20:27:36 --> Language Class Initialized
ERROR - 2018-08-16 20:27:36 --> 404 Page Not Found: Login/uploadImages
ERROR - 2018-08-16 20:27:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:27:37 --> Config Class Initialized
INFO - 2018-08-16 20:27:37 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:27:37 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:27:37 --> Utf8 Class Initialized
INFO - 2018-08-16 20:27:37 --> URI Class Initialized
INFO - 2018-08-16 20:27:37 --> Router Class Initialized
INFO - 2018-08-16 20:27:37 --> Output Class Initialized
INFO - 2018-08-16 20:27:37 --> Security Class Initialized
DEBUG - 2018-08-16 20:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:27:37 --> Input Class Initialized
INFO - 2018-08-16 20:27:37 --> Language Class Initialized
INFO - 2018-08-16 20:27:37 --> Loader Class Initialized
INFO - 2018-08-16 20:27:37 --> Controller Class Initialized
INFO - 2018-08-16 20:27:37 --> Database Driver Class Initialized
INFO - 2018-08-16 20:27:37 --> Model Class Initialized
INFO - 2018-08-16 20:27:37 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:27:37 --> Model Class Initialized
INFO - 2018-08-16 20:27:37 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:27:37 --> Final output sent to browser
DEBUG - 2018-08-16 20:27:37 --> Total execution time: 0.1957
ERROR - 2018-08-16 20:27:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:27:38 --> Config Class Initialized
INFO - 2018-08-16 20:27:38 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:27:38 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:27:38 --> Utf8 Class Initialized
INFO - 2018-08-16 20:27:38 --> URI Class Initialized
INFO - 2018-08-16 20:27:38 --> Router Class Initialized
INFO - 2018-08-16 20:27:38 --> Output Class Initialized
INFO - 2018-08-16 20:27:38 --> Security Class Initialized
DEBUG - 2018-08-16 20:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:27:38 --> Input Class Initialized
INFO - 2018-08-16 20:27:38 --> Language Class Initialized
ERROR - 2018-08-16 20:27:38 --> 404 Page Not Found: Login/uploadImages
ERROR - 2018-08-16 20:27:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:27:41 --> Config Class Initialized
INFO - 2018-08-16 20:27:41 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:27:41 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:27:41 --> Utf8 Class Initialized
INFO - 2018-08-16 20:27:41 --> URI Class Initialized
DEBUG - 2018-08-16 20:27:41 --> No URI present. Default controller set.
INFO - 2018-08-16 20:27:41 --> Router Class Initialized
INFO - 2018-08-16 20:27:41 --> Output Class Initialized
INFO - 2018-08-16 20:27:41 --> Security Class Initialized
DEBUG - 2018-08-16 20:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:27:41 --> Input Class Initialized
INFO - 2018-08-16 20:27:41 --> Language Class Initialized
INFO - 2018-08-16 20:27:41 --> Loader Class Initialized
INFO - 2018-08-16 20:27:41 --> Controller Class Initialized
INFO - 2018-08-16 20:27:41 --> Database Driver Class Initialized
INFO - 2018-08-16 20:27:41 --> Model Class Initialized
INFO - 2018-08-16 20:27:41 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:27:41 --> Model Class Initialized
INFO - 2018-08-16 20:27:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:27:42 --> Final output sent to browser
DEBUG - 2018-08-16 20:27:42 --> Total execution time: 0.2111
ERROR - 2018-08-16 20:27:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:27:42 --> Config Class Initialized
INFO - 2018-08-16 20:27:42 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:27:42 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:27:42 --> Utf8 Class Initialized
INFO - 2018-08-16 20:27:42 --> URI Class Initialized
DEBUG - 2018-08-16 20:27:42 --> No URI present. Default controller set.
INFO - 2018-08-16 20:27:42 --> Router Class Initialized
INFO - 2018-08-16 20:27:42 --> Output Class Initialized
INFO - 2018-08-16 20:27:42 --> Security Class Initialized
DEBUG - 2018-08-16 20:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:27:42 --> Input Class Initialized
INFO - 2018-08-16 20:27:42 --> Language Class Initialized
INFO - 2018-08-16 20:27:42 --> Loader Class Initialized
INFO - 2018-08-16 20:27:42 --> Controller Class Initialized
INFO - 2018-08-16 20:27:42 --> Database Driver Class Initialized
INFO - 2018-08-16 20:27:42 --> Model Class Initialized
INFO - 2018-08-16 20:27:42 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:27:42 --> Model Class Initialized
INFO - 2018-08-16 20:27:42 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:27:42 --> Final output sent to browser
DEBUG - 2018-08-16 20:27:42 --> Total execution time: 0.2112
ERROR - 2018-08-16 20:27:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:27:43 --> Config Class Initialized
INFO - 2018-08-16 20:27:43 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:27:43 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:27:43 --> Utf8 Class Initialized
INFO - 2018-08-16 20:27:43 --> URI Class Initialized
INFO - 2018-08-16 20:27:43 --> Router Class Initialized
INFO - 2018-08-16 20:27:43 --> Output Class Initialized
INFO - 2018-08-16 20:27:43 --> Security Class Initialized
DEBUG - 2018-08-16 20:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:27:43 --> Input Class Initialized
INFO - 2018-08-16 20:27:43 --> Language Class Initialized
INFO - 2018-08-16 20:27:43 --> Loader Class Initialized
INFO - 2018-08-16 20:27:43 --> Controller Class Initialized
INFO - 2018-08-16 20:27:43 --> Database Driver Class Initialized
INFO - 2018-08-16 20:27:43 --> Model Class Initialized
INFO - 2018-08-16 20:27:43 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:27:43 --> Model Class Initialized
INFO - 2018-08-16 20:27:43 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:27:43 --> Final output sent to browser
DEBUG - 2018-08-16 20:27:43 --> Total execution time: 0.1939
ERROR - 2018-08-16 20:27:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:27:43 --> Config Class Initialized
INFO - 2018-08-16 20:27:43 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:27:43 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:27:43 --> Utf8 Class Initialized
INFO - 2018-08-16 20:27:43 --> URI Class Initialized
INFO - 2018-08-16 20:27:44 --> Router Class Initialized
INFO - 2018-08-16 20:27:44 --> Output Class Initialized
INFO - 2018-08-16 20:27:44 --> Security Class Initialized
DEBUG - 2018-08-16 20:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:27:44 --> Input Class Initialized
INFO - 2018-08-16 20:27:44 --> Language Class Initialized
ERROR - 2018-08-16 20:27:44 --> 404 Page Not Found: Login/uploadImages
ERROR - 2018-08-16 20:29:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:29:14 --> Config Class Initialized
INFO - 2018-08-16 20:29:14 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:29:14 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:29:14 --> Utf8 Class Initialized
INFO - 2018-08-16 20:29:14 --> URI Class Initialized
INFO - 2018-08-16 20:29:14 --> Router Class Initialized
INFO - 2018-08-16 20:29:14 --> Output Class Initialized
INFO - 2018-08-16 20:29:14 --> Security Class Initialized
DEBUG - 2018-08-16 20:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:29:14 --> Input Class Initialized
INFO - 2018-08-16 20:29:14 --> Language Class Initialized
INFO - 2018-08-16 20:29:14 --> Loader Class Initialized
INFO - 2018-08-16 20:29:14 --> Controller Class Initialized
INFO - 2018-08-16 20:29:14 --> Database Driver Class Initialized
INFO - 2018-08-16 20:29:14 --> Model Class Initialized
INFO - 2018-08-16 20:29:14 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:29:14 --> Model Class Initialized
INFO - 2018-08-16 20:29:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:29:14 --> Final output sent to browser
DEBUG - 2018-08-16 20:29:14 --> Total execution time: 0.2044
ERROR - 2018-08-16 20:29:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:29:14 --> Config Class Initialized
INFO - 2018-08-16 20:29:14 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:29:14 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:29:14 --> Utf8 Class Initialized
ERROR - 2018-08-16 20:29:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:29:15 --> Config Class Initialized
INFO - 2018-08-16 20:29:15 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:29:15 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:29:15 --> Utf8 Class Initialized
INFO - 2018-08-16 20:29:15 --> URI Class Initialized
INFO - 2018-08-16 20:29:15 --> Router Class Initialized
INFO - 2018-08-16 20:29:15 --> Output Class Initialized
INFO - 2018-08-16 20:29:15 --> Security Class Initialized
DEBUG - 2018-08-16 20:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:29:15 --> Input Class Initialized
INFO - 2018-08-16 20:29:15 --> Language Class Initialized
INFO - 2018-08-16 20:29:15 --> Loader Class Initialized
INFO - 2018-08-16 20:29:15 --> Controller Class Initialized
INFO - 2018-08-16 20:29:15 --> Database Driver Class Initialized
INFO - 2018-08-16 20:29:15 --> Model Class Initialized
INFO - 2018-08-16 20:29:15 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:29:15 --> Model Class Initialized
INFO - 2018-08-16 20:29:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:29:15 --> Final output sent to browser
DEBUG - 2018-08-16 20:29:15 --> Total execution time: 0.2063
ERROR - 2018-08-16 20:29:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:29:15 --> Config Class Initialized
INFO - 2018-08-16 20:29:15 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:29:15 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:29:15 --> Utf8 Class Initialized
ERROR - 2018-08-16 20:29:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:29:31 --> Config Class Initialized
INFO - 2018-08-16 20:29:31 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:29:31 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:29:31 --> Utf8 Class Initialized
ERROR - 2018-08-16 20:30:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:30:09 --> Config Class Initialized
INFO - 2018-08-16 20:30:09 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:30:09 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:30:09 --> Utf8 Class Initialized
INFO - 2018-08-16 20:30:09 --> URI Class Initialized
INFO - 2018-08-16 20:30:09 --> Router Class Initialized
INFO - 2018-08-16 20:30:09 --> Output Class Initialized
INFO - 2018-08-16 20:30:09 --> Security Class Initialized
DEBUG - 2018-08-16 20:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:30:09 --> Input Class Initialized
INFO - 2018-08-16 20:30:09 --> Language Class Initialized
INFO - 2018-08-16 20:30:09 --> Loader Class Initialized
INFO - 2018-08-16 20:30:09 --> Controller Class Initialized
INFO - 2018-08-16 20:30:09 --> Database Driver Class Initialized
INFO - 2018-08-16 20:30:09 --> Model Class Initialized
INFO - 2018-08-16 20:30:09 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:30:09 --> Model Class Initialized
INFO - 2018-08-16 20:30:09 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:30:09 --> Final output sent to browser
DEBUG - 2018-08-16 20:30:09 --> Total execution time: 0.2018
ERROR - 2018-08-16 20:30:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:30:15 --> Config Class Initialized
INFO - 2018-08-16 20:30:15 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:30:15 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:30:15 --> Utf8 Class Initialized
INFO - 2018-08-16 20:30:15 --> URI Class Initialized
DEBUG - 2018-08-16 20:30:15 --> No URI present. Default controller set.
INFO - 2018-08-16 20:30:15 --> Router Class Initialized
INFO - 2018-08-16 20:30:15 --> Output Class Initialized
INFO - 2018-08-16 20:30:15 --> Security Class Initialized
DEBUG - 2018-08-16 20:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:30:15 --> Input Class Initialized
INFO - 2018-08-16 20:30:15 --> Language Class Initialized
INFO - 2018-08-16 20:30:15 --> Loader Class Initialized
INFO - 2018-08-16 20:30:15 --> Controller Class Initialized
INFO - 2018-08-16 20:30:15 --> Database Driver Class Initialized
INFO - 2018-08-16 20:30:15 --> Model Class Initialized
INFO - 2018-08-16 20:30:15 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:30:15 --> Model Class Initialized
INFO - 2018-08-16 20:30:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:30:15 --> Final output sent to browser
DEBUG - 2018-08-16 20:30:15 --> Total execution time: 0.2097
ERROR - 2018-08-16 20:30:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:30:17 --> Config Class Initialized
INFO - 2018-08-16 20:30:17 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:30:17 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:30:17 --> Utf8 Class Initialized
INFO - 2018-08-16 20:30:17 --> URI Class Initialized
INFO - 2018-08-16 20:30:17 --> Router Class Initialized
INFO - 2018-08-16 20:30:17 --> Output Class Initialized
INFO - 2018-08-16 20:30:17 --> Security Class Initialized
DEBUG - 2018-08-16 20:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:30:17 --> Input Class Initialized
INFO - 2018-08-16 20:30:17 --> Language Class Initialized
INFO - 2018-08-16 20:30:17 --> Loader Class Initialized
INFO - 2018-08-16 20:30:17 --> Controller Class Initialized
INFO - 2018-08-16 20:30:17 --> Database Driver Class Initialized
INFO - 2018-08-16 20:30:17 --> Model Class Initialized
INFO - 2018-08-16 20:30:17 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:30:17 --> Model Class Initialized
INFO - 2018-08-16 20:30:17 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:30:17 --> Final output sent to browser
DEBUG - 2018-08-16 20:30:17 --> Total execution time: 0.2164
ERROR - 2018-08-16 20:30:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:30:23 --> Config Class Initialized
INFO - 2018-08-16 20:30:23 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:30:23 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:30:23 --> Utf8 Class Initialized
INFO - 2018-08-16 20:30:23 --> URI Class Initialized
INFO - 2018-08-16 20:30:23 --> Router Class Initialized
INFO - 2018-08-16 20:30:23 --> Output Class Initialized
INFO - 2018-08-16 20:30:23 --> Security Class Initialized
DEBUG - 2018-08-16 20:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:30:23 --> Input Class Initialized
INFO - 2018-08-16 20:30:23 --> Language Class Initialized
INFO - 2018-08-16 20:30:23 --> Loader Class Initialized
INFO - 2018-08-16 20:30:23 --> Controller Class Initialized
INFO - 2018-08-16 20:30:23 --> Database Driver Class Initialized
INFO - 2018-08-16 20:30:23 --> Model Class Initialized
INFO - 2018-08-16 20:30:23 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:30:23 --> Model Class Initialized
ERROR - 2018-08-16 20:30:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:30:23 --> Config Class Initialized
INFO - 2018-08-16 20:30:23 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:30:23 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:30:23 --> Utf8 Class Initialized
INFO - 2018-08-16 20:30:23 --> URI Class Initialized
INFO - 2018-08-16 20:30:23 --> Router Class Initialized
INFO - 2018-08-16 20:30:23 --> Output Class Initialized
INFO - 2018-08-16 20:30:23 --> Security Class Initialized
DEBUG - 2018-08-16 20:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:30:23 --> Input Class Initialized
INFO - 2018-08-16 20:30:23 --> Language Class Initialized
INFO - 2018-08-16 20:30:23 --> Loader Class Initialized
INFO - 2018-08-16 20:30:23 --> Controller Class Initialized
INFO - 2018-08-16 20:30:24 --> Database Driver Class Initialized
INFO - 2018-08-16 20:30:24 --> Model Class Initialized
INFO - 2018-08-16 20:30:24 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:30:24 --> Model Class Initialized
INFO - 2018-08-16 20:30:24 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:30:24 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 20:30:24 --> Final output sent to browser
DEBUG - 2018-08-16 20:30:24 --> Total execution time: 0.2171
ERROR - 2018-08-16 20:30:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:30:27 --> Config Class Initialized
INFO - 2018-08-16 20:30:27 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:30:27 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:30:27 --> Utf8 Class Initialized
INFO - 2018-08-16 20:30:27 --> URI Class Initialized
INFO - 2018-08-16 20:30:27 --> Router Class Initialized
INFO - 2018-08-16 20:30:27 --> Output Class Initialized
INFO - 2018-08-16 20:30:27 --> Security Class Initialized
DEBUG - 2018-08-16 20:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:30:27 --> Input Class Initialized
INFO - 2018-08-16 20:30:27 --> Language Class Initialized
INFO - 2018-08-16 20:30:27 --> Loader Class Initialized
INFO - 2018-08-16 20:30:27 --> Controller Class Initialized
INFO - 2018-08-16 20:30:28 --> Database Driver Class Initialized
INFO - 2018-08-16 20:30:28 --> Model Class Initialized
INFO - 2018-08-16 20:30:28 --> Helper loaded: form_helper
INFO - 2018-08-16 20:30:28 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:30:28 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:30:28 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:30:28 --> Final output sent to browser
DEBUG - 2018-08-16 20:30:28 --> Total execution time: 0.2502
ERROR - 2018-08-16 20:30:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:30:34 --> Config Class Initialized
INFO - 2018-08-16 20:30:34 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:30:34 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:30:34 --> Utf8 Class Initialized
INFO - 2018-08-16 20:30:34 --> URI Class Initialized
INFO - 2018-08-16 20:30:34 --> Router Class Initialized
INFO - 2018-08-16 20:30:34 --> Output Class Initialized
INFO - 2018-08-16 20:30:34 --> Security Class Initialized
DEBUG - 2018-08-16 20:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:30:34 --> Input Class Initialized
INFO - 2018-08-16 20:30:34 --> Language Class Initialized
INFO - 2018-08-16 20:30:34 --> Loader Class Initialized
INFO - 2018-08-16 20:30:34 --> Controller Class Initialized
INFO - 2018-08-16 20:30:34 --> Database Driver Class Initialized
INFO - 2018-08-16 20:30:34 --> Model Class Initialized
INFO - 2018-08-16 20:30:34 --> Helper loaded: form_helper
INFO - 2018-08-16 20:30:34 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:30:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:30:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:30:34 --> Final output sent to browser
DEBUG - 2018-08-16 20:30:34 --> Total execution time: 0.2723
ERROR - 2018-08-16 20:30:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:30:37 --> Config Class Initialized
INFO - 2018-08-16 20:30:37 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:30:37 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:30:37 --> Utf8 Class Initialized
INFO - 2018-08-16 20:30:37 --> URI Class Initialized
INFO - 2018-08-16 20:30:37 --> Router Class Initialized
INFO - 2018-08-16 20:30:37 --> Output Class Initialized
INFO - 2018-08-16 20:30:37 --> Security Class Initialized
DEBUG - 2018-08-16 20:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:30:37 --> Input Class Initialized
INFO - 2018-08-16 20:30:37 --> Language Class Initialized
INFO - 2018-08-16 20:30:37 --> Loader Class Initialized
INFO - 2018-08-16 20:30:37 --> Controller Class Initialized
INFO - 2018-08-16 20:30:37 --> Database Driver Class Initialized
INFO - 2018-08-16 20:30:37 --> Model Class Initialized
INFO - 2018-08-16 20:30:37 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:30:37 --> Model Class Initialized
ERROR - 2018-08-16 20:30:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:30:37 --> Config Class Initialized
INFO - 2018-08-16 20:30:37 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:30:37 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:30:37 --> Utf8 Class Initialized
INFO - 2018-08-16 20:30:37 --> URI Class Initialized
DEBUG - 2018-08-16 20:30:37 --> No URI present. Default controller set.
INFO - 2018-08-16 20:30:37 --> Router Class Initialized
INFO - 2018-08-16 20:30:37 --> Output Class Initialized
INFO - 2018-08-16 20:30:37 --> Security Class Initialized
DEBUG - 2018-08-16 20:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:30:37 --> Input Class Initialized
INFO - 2018-08-16 20:30:37 --> Language Class Initialized
INFO - 2018-08-16 20:30:37 --> Loader Class Initialized
INFO - 2018-08-16 20:30:37 --> Controller Class Initialized
INFO - 2018-08-16 20:30:37 --> Database Driver Class Initialized
INFO - 2018-08-16 20:30:37 --> Model Class Initialized
INFO - 2018-08-16 20:30:37 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:30:37 --> Model Class Initialized
INFO - 2018-08-16 20:30:37 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:30:37 --> Final output sent to browser
DEBUG - 2018-08-16 20:30:37 --> Total execution time: 0.1960
ERROR - 2018-08-16 20:31:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:31:14 --> Config Class Initialized
INFO - 2018-08-16 20:31:14 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:31:15 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:31:15 --> Utf8 Class Initialized
INFO - 2018-08-16 20:31:15 --> URI Class Initialized
DEBUG - 2018-08-16 20:31:15 --> No URI present. Default controller set.
INFO - 2018-08-16 20:31:15 --> Router Class Initialized
INFO - 2018-08-16 20:31:15 --> Output Class Initialized
INFO - 2018-08-16 20:31:15 --> Security Class Initialized
DEBUG - 2018-08-16 20:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:31:15 --> Input Class Initialized
INFO - 2018-08-16 20:31:15 --> Language Class Initialized
INFO - 2018-08-16 20:31:15 --> Loader Class Initialized
INFO - 2018-08-16 20:31:15 --> Controller Class Initialized
INFO - 2018-08-16 20:31:15 --> Database Driver Class Initialized
INFO - 2018-08-16 20:31:15 --> Model Class Initialized
INFO - 2018-08-16 20:31:15 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:31:15 --> Model Class Initialized
INFO - 2018-08-16 20:31:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:31:15 --> Final output sent to browser
DEBUG - 2018-08-16 20:31:15 --> Total execution time: 0.2127
ERROR - 2018-08-16 20:31:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:31:25 --> Config Class Initialized
INFO - 2018-08-16 20:31:25 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:31:25 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:31:25 --> Utf8 Class Initialized
INFO - 2018-08-16 20:31:25 --> URI Class Initialized
DEBUG - 2018-08-16 20:31:25 --> No URI present. Default controller set.
INFO - 2018-08-16 20:31:25 --> Router Class Initialized
INFO - 2018-08-16 20:31:25 --> Output Class Initialized
INFO - 2018-08-16 20:31:25 --> Security Class Initialized
DEBUG - 2018-08-16 20:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:31:25 --> Input Class Initialized
INFO - 2018-08-16 20:31:25 --> Language Class Initialized
INFO - 2018-08-16 20:31:25 --> Loader Class Initialized
INFO - 2018-08-16 20:31:25 --> Controller Class Initialized
INFO - 2018-08-16 20:31:25 --> Database Driver Class Initialized
INFO - 2018-08-16 20:31:25 --> Model Class Initialized
INFO - 2018-08-16 20:31:25 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:31:25 --> Model Class Initialized
INFO - 2018-08-16 20:31:25 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-16 20:31:25 --> Final output sent to browser
DEBUG - 2018-08-16 20:31:25 --> Total execution time: 0.2134
ERROR - 2018-08-16 20:31:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:31:30 --> Config Class Initialized
INFO - 2018-08-16 20:31:30 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:31:30 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:31:30 --> Utf8 Class Initialized
INFO - 2018-08-16 20:31:30 --> URI Class Initialized
INFO - 2018-08-16 20:31:30 --> Router Class Initialized
INFO - 2018-08-16 20:31:30 --> Output Class Initialized
INFO - 2018-08-16 20:31:30 --> Security Class Initialized
DEBUG - 2018-08-16 20:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:31:30 --> Input Class Initialized
INFO - 2018-08-16 20:31:30 --> Language Class Initialized
INFO - 2018-08-16 20:31:30 --> Loader Class Initialized
INFO - 2018-08-16 20:31:30 --> Controller Class Initialized
INFO - 2018-08-16 20:31:30 --> Database Driver Class Initialized
INFO - 2018-08-16 20:31:30 --> Model Class Initialized
INFO - 2018-08-16 20:31:30 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:31:30 --> Model Class Initialized
ERROR - 2018-08-16 20:31:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:31:30 --> Config Class Initialized
INFO - 2018-08-16 20:31:30 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:31:30 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:31:30 --> Utf8 Class Initialized
INFO - 2018-08-16 20:31:30 --> URI Class Initialized
INFO - 2018-08-16 20:31:30 --> Router Class Initialized
INFO - 2018-08-16 20:31:30 --> Output Class Initialized
INFO - 2018-08-16 20:31:30 --> Security Class Initialized
DEBUG - 2018-08-16 20:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:31:30 --> Input Class Initialized
INFO - 2018-08-16 20:31:30 --> Language Class Initialized
INFO - 2018-08-16 20:31:30 --> Loader Class Initialized
INFO - 2018-08-16 20:31:30 --> Controller Class Initialized
INFO - 2018-08-16 20:31:30 --> Database Driver Class Initialized
INFO - 2018-08-16 20:31:30 --> Model Class Initialized
INFO - 2018-08-16 20:31:30 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:31:30 --> Model Class Initialized
INFO - 2018-08-16 20:31:30 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:31:30 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-16 20:31:30 --> Final output sent to browser
DEBUG - 2018-08-16 20:31:30 --> Total execution time: 0.2236
ERROR - 2018-08-16 20:31:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:31:34 --> Config Class Initialized
INFO - 2018-08-16 20:31:34 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:31:34 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:31:34 --> Utf8 Class Initialized
INFO - 2018-08-16 20:31:34 --> URI Class Initialized
INFO - 2018-08-16 20:31:34 --> Router Class Initialized
INFO - 2018-08-16 20:31:34 --> Output Class Initialized
INFO - 2018-08-16 20:31:34 --> Security Class Initialized
DEBUG - 2018-08-16 20:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:31:34 --> Input Class Initialized
INFO - 2018-08-16 20:31:34 --> Language Class Initialized
INFO - 2018-08-16 20:31:34 --> Loader Class Initialized
INFO - 2018-08-16 20:31:34 --> Controller Class Initialized
INFO - 2018-08-16 20:31:34 --> Database Driver Class Initialized
INFO - 2018-08-16 20:31:34 --> Model Class Initialized
INFO - 2018-08-16 20:31:34 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:31:34 --> Model Class Initialized
INFO - 2018-08-16 20:31:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:31:34 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 146
INFO - 2018-08-16 20:31:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:31:34 --> Final output sent to browser
DEBUG - 2018-08-16 20:31:34 --> Total execution time: 0.2772
ERROR - 2018-08-16 20:33:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:33:53 --> Config Class Initialized
INFO - 2018-08-16 20:33:53 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:33:53 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:33:53 --> Utf8 Class Initialized
INFO - 2018-08-16 20:33:53 --> URI Class Initialized
INFO - 2018-08-16 20:33:53 --> Router Class Initialized
INFO - 2018-08-16 20:33:53 --> Output Class Initialized
INFO - 2018-08-16 20:33:53 --> Security Class Initialized
DEBUG - 2018-08-16 20:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:33:53 --> Input Class Initialized
INFO - 2018-08-16 20:33:53 --> Language Class Initialized
INFO - 2018-08-16 20:33:53 --> Loader Class Initialized
INFO - 2018-08-16 20:33:53 --> Controller Class Initialized
INFO - 2018-08-16 20:33:53 --> Database Driver Class Initialized
INFO - 2018-08-16 20:33:53 --> Model Class Initialized
INFO - 2018-08-16 20:33:53 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:33:53 --> Model Class Initialized
INFO - 2018-08-16 20:33:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:33:53 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 167
INFO - 2018-08-16 20:33:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:33:53 --> Final output sent to browser
DEBUG - 2018-08-16 20:33:53 --> Total execution time: 0.2241
ERROR - 2018-08-16 20:34:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:34:16 --> Config Class Initialized
INFO - 2018-08-16 20:34:16 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:34:16 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:34:16 --> Utf8 Class Initialized
INFO - 2018-08-16 20:34:16 --> URI Class Initialized
INFO - 2018-08-16 20:34:16 --> Router Class Initialized
INFO - 2018-08-16 20:34:16 --> Output Class Initialized
INFO - 2018-08-16 20:34:16 --> Security Class Initialized
DEBUG - 2018-08-16 20:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:34:16 --> Input Class Initialized
INFO - 2018-08-16 20:34:16 --> Language Class Initialized
INFO - 2018-08-16 20:34:16 --> Loader Class Initialized
INFO - 2018-08-16 20:34:16 --> Controller Class Initialized
INFO - 2018-08-16 20:34:16 --> Database Driver Class Initialized
INFO - 2018-08-16 20:34:16 --> Model Class Initialized
INFO - 2018-08-16 20:34:16 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:34:16 --> Model Class Initialized
INFO - 2018-08-16 20:34:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:34:16 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 167
INFO - 2018-08-16 20:34:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:34:16 --> Final output sent to browser
DEBUG - 2018-08-16 20:34:16 --> Total execution time: 0.2448
ERROR - 2018-08-16 20:34:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:34:39 --> Config Class Initialized
INFO - 2018-08-16 20:34:39 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:34:39 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:34:39 --> Utf8 Class Initialized
INFO - 2018-08-16 20:34:39 --> URI Class Initialized
INFO - 2018-08-16 20:34:39 --> Router Class Initialized
INFO - 2018-08-16 20:34:39 --> Output Class Initialized
INFO - 2018-08-16 20:34:39 --> Security Class Initialized
DEBUG - 2018-08-16 20:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:34:39 --> Input Class Initialized
INFO - 2018-08-16 20:34:39 --> Language Class Initialized
INFO - 2018-08-16 20:34:39 --> Loader Class Initialized
INFO - 2018-08-16 20:34:39 --> Controller Class Initialized
INFO - 2018-08-16 20:34:39 --> Database Driver Class Initialized
INFO - 2018-08-16 20:34:39 --> Model Class Initialized
INFO - 2018-08-16 20:34:39 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:34:39 --> Model Class Initialized
INFO - 2018-08-16 20:34:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:34:39 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 167
INFO - 2018-08-16 20:34:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:34:39 --> Final output sent to browser
DEBUG - 2018-08-16 20:34:39 --> Total execution time: 0.2105
ERROR - 2018-08-16 20:34:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:34:53 --> Config Class Initialized
INFO - 2018-08-16 20:34:53 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:34:53 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:34:53 --> Utf8 Class Initialized
INFO - 2018-08-16 20:34:53 --> URI Class Initialized
INFO - 2018-08-16 20:34:53 --> Router Class Initialized
INFO - 2018-08-16 20:34:53 --> Output Class Initialized
INFO - 2018-08-16 20:34:53 --> Security Class Initialized
DEBUG - 2018-08-16 20:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:34:53 --> Input Class Initialized
INFO - 2018-08-16 20:34:53 --> Language Class Initialized
INFO - 2018-08-16 20:34:53 --> Loader Class Initialized
INFO - 2018-08-16 20:34:53 --> Controller Class Initialized
INFO - 2018-08-16 20:34:53 --> Database Driver Class Initialized
INFO - 2018-08-16 20:34:53 --> Model Class Initialized
INFO - 2018-08-16 20:34:53 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:34:53 --> Model Class Initialized
INFO - 2018-08-16 20:34:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:34:53 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 167
INFO - 2018-08-16 20:34:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:34:53 --> Final output sent to browser
DEBUG - 2018-08-16 20:34:53 --> Total execution time: 0.2287
ERROR - 2018-08-16 20:36:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:36:52 --> Config Class Initialized
INFO - 2018-08-16 20:36:52 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:36:52 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:36:52 --> Utf8 Class Initialized
INFO - 2018-08-16 20:36:52 --> URI Class Initialized
INFO - 2018-08-16 20:36:52 --> Router Class Initialized
INFO - 2018-08-16 20:36:52 --> Output Class Initialized
INFO - 2018-08-16 20:36:52 --> Security Class Initialized
DEBUG - 2018-08-16 20:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:36:53 --> Input Class Initialized
INFO - 2018-08-16 20:36:53 --> Language Class Initialized
INFO - 2018-08-16 20:36:53 --> Loader Class Initialized
INFO - 2018-08-16 20:36:53 --> Controller Class Initialized
INFO - 2018-08-16 20:36:53 --> Database Driver Class Initialized
INFO - 2018-08-16 20:36:53 --> Model Class Initialized
INFO - 2018-08-16 20:36:53 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:36:53 --> Model Class Initialized
INFO - 2018-08-16 20:36:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:36:53 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 167
INFO - 2018-08-16 20:36:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:36:53 --> Final output sent to browser
DEBUG - 2018-08-16 20:36:53 --> Total execution time: 0.2167
ERROR - 2018-08-16 20:40:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:40:02 --> Config Class Initialized
INFO - 2018-08-16 20:40:02 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:40:02 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:40:02 --> Utf8 Class Initialized
INFO - 2018-08-16 20:40:02 --> URI Class Initialized
INFO - 2018-08-16 20:40:02 --> Router Class Initialized
INFO - 2018-08-16 20:40:02 --> Output Class Initialized
INFO - 2018-08-16 20:40:02 --> Security Class Initialized
DEBUG - 2018-08-16 20:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:40:02 --> Input Class Initialized
INFO - 2018-08-16 20:40:02 --> Language Class Initialized
INFO - 2018-08-16 20:40:02 --> Loader Class Initialized
INFO - 2018-08-16 20:40:02 --> Controller Class Initialized
INFO - 2018-08-16 20:40:02 --> Database Driver Class Initialized
INFO - 2018-08-16 20:40:02 --> Model Class Initialized
INFO - 2018-08-16 20:40:02 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:40:02 --> Model Class Initialized
INFO - 2018-08-16 20:40:02 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:40:02 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\davidhood\application\views\user.php 112
ERROR - 2018-08-16 20:40:02 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 177
INFO - 2018-08-16 20:40:02 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:40:02 --> Final output sent to browser
DEBUG - 2018-08-16 20:40:02 --> Total execution time: 0.2424
ERROR - 2018-08-16 20:41:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:41:14 --> Config Class Initialized
INFO - 2018-08-16 20:41:14 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:41:14 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:41:14 --> Utf8 Class Initialized
INFO - 2018-08-16 20:41:14 --> URI Class Initialized
INFO - 2018-08-16 20:41:14 --> Router Class Initialized
INFO - 2018-08-16 20:41:14 --> Output Class Initialized
INFO - 2018-08-16 20:41:14 --> Security Class Initialized
DEBUG - 2018-08-16 20:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:41:14 --> Input Class Initialized
INFO - 2018-08-16 20:41:14 --> Language Class Initialized
INFO - 2018-08-16 20:41:14 --> Loader Class Initialized
INFO - 2018-08-16 20:41:14 --> Controller Class Initialized
INFO - 2018-08-16 20:41:14 --> Database Driver Class Initialized
INFO - 2018-08-16 20:41:15 --> Model Class Initialized
INFO - 2018-08-16 20:41:15 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:41:15 --> Model Class Initialized
INFO - 2018-08-16 20:41:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:41:15 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 178
INFO - 2018-08-16 20:41:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:41:15 --> Final output sent to browser
DEBUG - 2018-08-16 20:41:15 --> Total execution time: 0.2193
ERROR - 2018-08-16 20:41:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:41:39 --> Config Class Initialized
INFO - 2018-08-16 20:41:39 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:41:39 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:41:39 --> Utf8 Class Initialized
INFO - 2018-08-16 20:41:39 --> URI Class Initialized
INFO - 2018-08-16 20:41:39 --> Router Class Initialized
INFO - 2018-08-16 20:41:39 --> Output Class Initialized
INFO - 2018-08-16 20:41:39 --> Security Class Initialized
DEBUG - 2018-08-16 20:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:41:39 --> Input Class Initialized
INFO - 2018-08-16 20:41:39 --> Language Class Initialized
INFO - 2018-08-16 20:41:39 --> Loader Class Initialized
INFO - 2018-08-16 20:41:39 --> Controller Class Initialized
INFO - 2018-08-16 20:41:39 --> Database Driver Class Initialized
INFO - 2018-08-16 20:41:39 --> Model Class Initialized
INFO - 2018-08-16 20:41:39 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:41:39 --> Model Class Initialized
INFO - 2018-08-16 20:41:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:41:39 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 177
INFO - 2018-08-16 20:41:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:41:39 --> Final output sent to browser
DEBUG - 2018-08-16 20:41:39 --> Total execution time: 0.2556
ERROR - 2018-08-16 20:42:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:42:05 --> Config Class Initialized
INFO - 2018-08-16 20:42:05 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:42:05 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:42:05 --> Utf8 Class Initialized
INFO - 2018-08-16 20:42:05 --> URI Class Initialized
INFO - 2018-08-16 20:42:05 --> Router Class Initialized
INFO - 2018-08-16 20:42:05 --> Output Class Initialized
INFO - 2018-08-16 20:42:05 --> Security Class Initialized
DEBUG - 2018-08-16 20:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:42:05 --> Input Class Initialized
INFO - 2018-08-16 20:42:05 --> Language Class Initialized
INFO - 2018-08-16 20:42:05 --> Loader Class Initialized
INFO - 2018-08-16 20:42:05 --> Controller Class Initialized
INFO - 2018-08-16 20:42:05 --> Database Driver Class Initialized
INFO - 2018-08-16 20:42:05 --> Model Class Initialized
INFO - 2018-08-16 20:42:05 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:42:05 --> Model Class Initialized
INFO - 2018-08-16 20:42:05 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:42:05 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 177
INFO - 2018-08-16 20:42:05 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:42:05 --> Final output sent to browser
DEBUG - 2018-08-16 20:42:05 --> Total execution time: 0.2760
ERROR - 2018-08-16 20:42:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:42:36 --> Config Class Initialized
INFO - 2018-08-16 20:42:36 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:42:36 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:42:36 --> Utf8 Class Initialized
INFO - 2018-08-16 20:42:36 --> URI Class Initialized
INFO - 2018-08-16 20:42:36 --> Router Class Initialized
INFO - 2018-08-16 20:42:36 --> Output Class Initialized
INFO - 2018-08-16 20:42:36 --> Security Class Initialized
DEBUG - 2018-08-16 20:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:42:36 --> Input Class Initialized
INFO - 2018-08-16 20:42:36 --> Language Class Initialized
INFO - 2018-08-16 20:42:36 --> Loader Class Initialized
INFO - 2018-08-16 20:42:36 --> Controller Class Initialized
INFO - 2018-08-16 20:42:36 --> Database Driver Class Initialized
INFO - 2018-08-16 20:42:36 --> Model Class Initialized
INFO - 2018-08-16 20:42:36 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:42:36 --> Model Class Initialized
INFO - 2018-08-16 20:42:36 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:42:36 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 177
INFO - 2018-08-16 20:42:36 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:42:36 --> Final output sent to browser
DEBUG - 2018-08-16 20:42:36 --> Total execution time: 0.2262
ERROR - 2018-08-16 20:47:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:47:49 --> Config Class Initialized
INFO - 2018-08-16 20:47:49 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:47:49 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:47:49 --> Utf8 Class Initialized
INFO - 2018-08-16 20:47:49 --> URI Class Initialized
INFO - 2018-08-16 20:47:49 --> Router Class Initialized
INFO - 2018-08-16 20:47:49 --> Output Class Initialized
INFO - 2018-08-16 20:47:49 --> Security Class Initialized
DEBUG - 2018-08-16 20:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:47:49 --> Input Class Initialized
INFO - 2018-08-16 20:47:49 --> Language Class Initialized
INFO - 2018-08-16 20:47:49 --> Loader Class Initialized
INFO - 2018-08-16 20:47:49 --> Controller Class Initialized
INFO - 2018-08-16 20:47:49 --> Database Driver Class Initialized
INFO - 2018-08-16 20:47:49 --> Model Class Initialized
INFO - 2018-08-16 20:47:49 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:47:49 --> Model Class Initialized
INFO - 2018-08-16 20:47:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:47:49 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 178
INFO - 2018-08-16 20:47:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:47:49 --> Final output sent to browser
DEBUG - 2018-08-16 20:47:49 --> Total execution time: 0.2781
ERROR - 2018-08-16 20:48:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:48:44 --> Config Class Initialized
INFO - 2018-08-16 20:48:44 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:48:44 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:48:44 --> Utf8 Class Initialized
INFO - 2018-08-16 20:48:44 --> URI Class Initialized
INFO - 2018-08-16 20:48:44 --> Router Class Initialized
INFO - 2018-08-16 20:48:44 --> Output Class Initialized
INFO - 2018-08-16 20:48:44 --> Security Class Initialized
DEBUG - 2018-08-16 20:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:48:44 --> Input Class Initialized
INFO - 2018-08-16 20:48:44 --> Language Class Initialized
INFO - 2018-08-16 20:48:44 --> Loader Class Initialized
INFO - 2018-08-16 20:48:44 --> Controller Class Initialized
INFO - 2018-08-16 20:48:44 --> Database Driver Class Initialized
INFO - 2018-08-16 20:48:44 --> Model Class Initialized
INFO - 2018-08-16 20:48:44 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:48:44 --> Model Class Initialized
INFO - 2018-08-16 20:48:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:48:44 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 178
INFO - 2018-08-16 20:48:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:48:44 --> Final output sent to browser
DEBUG - 2018-08-16 20:48:44 --> Total execution time: 0.2221
ERROR - 2018-08-16 20:50:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:50:14 --> Config Class Initialized
INFO - 2018-08-16 20:50:14 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:50:14 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:50:14 --> Utf8 Class Initialized
INFO - 2018-08-16 20:50:14 --> URI Class Initialized
INFO - 2018-08-16 20:50:14 --> Router Class Initialized
INFO - 2018-08-16 20:50:14 --> Output Class Initialized
INFO - 2018-08-16 20:50:14 --> Security Class Initialized
DEBUG - 2018-08-16 20:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:50:14 --> Input Class Initialized
INFO - 2018-08-16 20:50:14 --> Language Class Initialized
INFO - 2018-08-16 20:50:14 --> Loader Class Initialized
INFO - 2018-08-16 20:50:14 --> Controller Class Initialized
INFO - 2018-08-16 20:50:14 --> Database Driver Class Initialized
INFO - 2018-08-16 20:50:14 --> Model Class Initialized
INFO - 2018-08-16 20:50:14 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:50:14 --> Model Class Initialized
INFO - 2018-08-16 20:50:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:50:14 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 178
INFO - 2018-08-16 20:50:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:50:14 --> Final output sent to browser
DEBUG - 2018-08-16 20:50:14 --> Total execution time: 0.2438
ERROR - 2018-08-16 20:51:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:51:44 --> Config Class Initialized
INFO - 2018-08-16 20:51:44 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:51:44 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:51:44 --> Utf8 Class Initialized
INFO - 2018-08-16 20:51:44 --> URI Class Initialized
INFO - 2018-08-16 20:51:44 --> Router Class Initialized
INFO - 2018-08-16 20:51:44 --> Output Class Initialized
INFO - 2018-08-16 20:51:44 --> Security Class Initialized
DEBUG - 2018-08-16 20:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:51:44 --> Input Class Initialized
INFO - 2018-08-16 20:51:44 --> Language Class Initialized
INFO - 2018-08-16 20:51:44 --> Loader Class Initialized
INFO - 2018-08-16 20:51:44 --> Controller Class Initialized
INFO - 2018-08-16 20:51:44 --> Database Driver Class Initialized
INFO - 2018-08-16 20:51:44 --> Model Class Initialized
INFO - 2018-08-16 20:51:44 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:51:44 --> Model Class Initialized
INFO - 2018-08-16 20:51:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:51:44 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 179
INFO - 2018-08-16 20:51:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:51:44 --> Final output sent to browser
DEBUG - 2018-08-16 20:51:44 --> Total execution time: 0.2493
ERROR - 2018-08-16 20:52:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:52:41 --> Config Class Initialized
INFO - 2018-08-16 20:52:41 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:52:41 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:52:41 --> Utf8 Class Initialized
INFO - 2018-08-16 20:52:41 --> URI Class Initialized
INFO - 2018-08-16 20:52:41 --> Router Class Initialized
INFO - 2018-08-16 20:52:41 --> Output Class Initialized
INFO - 2018-08-16 20:52:41 --> Security Class Initialized
DEBUG - 2018-08-16 20:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:52:41 --> Input Class Initialized
INFO - 2018-08-16 20:52:41 --> Language Class Initialized
INFO - 2018-08-16 20:52:41 --> Loader Class Initialized
INFO - 2018-08-16 20:52:41 --> Controller Class Initialized
INFO - 2018-08-16 20:52:41 --> Database Driver Class Initialized
INFO - 2018-08-16 20:52:41 --> Model Class Initialized
INFO - 2018-08-16 20:52:41 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:52:41 --> Model Class Initialized
INFO - 2018-08-16 20:52:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:52:41 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 179
INFO - 2018-08-16 20:52:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:52:41 --> Final output sent to browser
DEBUG - 2018-08-16 20:52:41 --> Total execution time: 0.2269
ERROR - 2018-08-16 20:52:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:52:57 --> Config Class Initialized
INFO - 2018-08-16 20:52:57 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:52:57 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:52:57 --> Utf8 Class Initialized
INFO - 2018-08-16 20:52:57 --> URI Class Initialized
INFO - 2018-08-16 20:52:57 --> Router Class Initialized
INFO - 2018-08-16 20:52:57 --> Output Class Initialized
INFO - 2018-08-16 20:52:57 --> Security Class Initialized
DEBUG - 2018-08-16 20:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:52:57 --> Input Class Initialized
INFO - 2018-08-16 20:52:57 --> Language Class Initialized
INFO - 2018-08-16 20:52:57 --> Loader Class Initialized
INFO - 2018-08-16 20:52:57 --> Controller Class Initialized
INFO - 2018-08-16 20:52:57 --> Database Driver Class Initialized
INFO - 2018-08-16 20:52:57 --> Model Class Initialized
INFO - 2018-08-16 20:52:57 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:52:57 --> Model Class Initialized
INFO - 2018-08-16 20:52:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:52:57 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 179
INFO - 2018-08-16 20:52:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:52:57 --> Final output sent to browser
DEBUG - 2018-08-16 20:52:58 --> Total execution time: 0.2398
ERROR - 2018-08-16 20:53:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:53:01 --> Config Class Initialized
INFO - 2018-08-16 20:53:01 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:53:01 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:53:01 --> Utf8 Class Initialized
INFO - 2018-08-16 20:53:01 --> URI Class Initialized
INFO - 2018-08-16 20:53:01 --> Router Class Initialized
INFO - 2018-08-16 20:53:01 --> Output Class Initialized
INFO - 2018-08-16 20:53:01 --> Security Class Initialized
DEBUG - 2018-08-16 20:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:53:01 --> Input Class Initialized
INFO - 2018-08-16 20:53:01 --> Language Class Initialized
INFO - 2018-08-16 20:53:01 --> Loader Class Initialized
INFO - 2018-08-16 20:53:01 --> Controller Class Initialized
INFO - 2018-08-16 20:53:01 --> Database Driver Class Initialized
INFO - 2018-08-16 20:53:01 --> Model Class Initialized
INFO - 2018-08-16 20:53:01 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:53:01 --> Model Class Initialized
INFO - 2018-08-16 20:53:01 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:53:01 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 179
INFO - 2018-08-16 20:53:01 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:53:01 --> Final output sent to browser
DEBUG - 2018-08-16 20:53:01 --> Total execution time: 0.2798
ERROR - 2018-08-16 20:53:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:53:12 --> Config Class Initialized
INFO - 2018-08-16 20:53:12 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:53:12 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:53:12 --> Utf8 Class Initialized
INFO - 2018-08-16 20:53:12 --> URI Class Initialized
INFO - 2018-08-16 20:53:12 --> Router Class Initialized
INFO - 2018-08-16 20:53:12 --> Output Class Initialized
INFO - 2018-08-16 20:53:12 --> Security Class Initialized
DEBUG - 2018-08-16 20:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:53:12 --> Input Class Initialized
INFO - 2018-08-16 20:53:12 --> Language Class Initialized
INFO - 2018-08-16 20:53:12 --> Loader Class Initialized
INFO - 2018-08-16 20:53:12 --> Controller Class Initialized
INFO - 2018-08-16 20:53:12 --> Database Driver Class Initialized
INFO - 2018-08-16 20:53:12 --> Model Class Initialized
INFO - 2018-08-16 20:53:12 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:53:12 --> Model Class Initialized
INFO - 2018-08-16 20:53:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:53:12 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 179
INFO - 2018-08-16 20:53:12 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:53:12 --> Final output sent to browser
DEBUG - 2018-08-16 20:53:12 --> Total execution time: 0.2470
ERROR - 2018-08-16 20:53:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:53:19 --> Config Class Initialized
INFO - 2018-08-16 20:53:19 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:53:19 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:53:19 --> Utf8 Class Initialized
INFO - 2018-08-16 20:53:19 --> URI Class Initialized
INFO - 2018-08-16 20:53:19 --> Router Class Initialized
INFO - 2018-08-16 20:53:19 --> Output Class Initialized
INFO - 2018-08-16 20:53:19 --> Security Class Initialized
DEBUG - 2018-08-16 20:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:53:19 --> Input Class Initialized
INFO - 2018-08-16 20:53:19 --> Language Class Initialized
INFO - 2018-08-16 20:53:19 --> Loader Class Initialized
INFO - 2018-08-16 20:53:19 --> Controller Class Initialized
INFO - 2018-08-16 20:53:19 --> Database Driver Class Initialized
INFO - 2018-08-16 20:53:19 --> Model Class Initialized
INFO - 2018-08-16 20:53:19 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:53:19 --> Model Class Initialized
INFO - 2018-08-16 20:53:19 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:53:19 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-08-16 20:53:19 --> Final output sent to browser
DEBUG - 2018-08-16 20:53:19 --> Total execution time: 0.2578
ERROR - 2018-08-16 20:53:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:53:20 --> Config Class Initialized
INFO - 2018-08-16 20:53:20 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:53:20 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:53:20 --> Utf8 Class Initialized
INFO - 2018-08-16 20:53:20 --> URI Class Initialized
INFO - 2018-08-16 20:53:20 --> Router Class Initialized
INFO - 2018-08-16 20:53:20 --> Output Class Initialized
INFO - 2018-08-16 20:53:20 --> Security Class Initialized
DEBUG - 2018-08-16 20:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:53:20 --> Input Class Initialized
INFO - 2018-08-16 20:53:20 --> Language Class Initialized
INFO - 2018-08-16 20:53:20 --> Loader Class Initialized
INFO - 2018-08-16 20:53:20 --> Controller Class Initialized
INFO - 2018-08-16 20:53:20 --> Database Driver Class Initialized
INFO - 2018-08-16 20:53:21 --> Model Class Initialized
INFO - 2018-08-16 20:53:21 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:53:21 --> Model Class Initialized
INFO - 2018-08-16 20:53:21 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:53:21 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 179
INFO - 2018-08-16 20:53:21 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:53:21 --> Final output sent to browser
DEBUG - 2018-08-16 20:53:21 --> Total execution time: 0.2677
ERROR - 2018-08-16 20:53:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:53:43 --> Config Class Initialized
INFO - 2018-08-16 20:53:43 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:53:43 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:53:43 --> Utf8 Class Initialized
INFO - 2018-08-16 20:53:43 --> URI Class Initialized
INFO - 2018-08-16 20:53:43 --> Router Class Initialized
INFO - 2018-08-16 20:53:43 --> Output Class Initialized
INFO - 2018-08-16 20:53:43 --> Security Class Initialized
DEBUG - 2018-08-16 20:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:53:43 --> Input Class Initialized
INFO - 2018-08-16 20:53:43 --> Language Class Initialized
INFO - 2018-08-16 20:53:43 --> Loader Class Initialized
INFO - 2018-08-16 20:53:43 --> Controller Class Initialized
INFO - 2018-08-16 20:53:43 --> Database Driver Class Initialized
INFO - 2018-08-16 20:53:43 --> Model Class Initialized
INFO - 2018-08-16 20:53:43 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:53:43 --> Model Class Initialized
INFO - 2018-08-16 20:53:43 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 20:53:43 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 179
INFO - 2018-08-16 20:53:43 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 20:53:43 --> Final output sent to browser
DEBUG - 2018-08-16 20:53:43 --> Total execution time: 0.2440
ERROR - 2018-08-16 20:54:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 20:54:10 --> Config Class Initialized
INFO - 2018-08-16 20:54:10 --> Hooks Class Initialized
DEBUG - 2018-08-16 20:54:10 --> UTF-8 Support Enabled
INFO - 2018-08-16 20:54:10 --> Utf8 Class Initialized
INFO - 2018-08-16 20:54:10 --> URI Class Initialized
INFO - 2018-08-16 20:54:10 --> Router Class Initialized
INFO - 2018-08-16 20:54:10 --> Output Class Initialized
INFO - 2018-08-16 20:54:10 --> Security Class Initialized
DEBUG - 2018-08-16 20:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 20:54:10 --> Input Class Initialized
INFO - 2018-08-16 20:54:10 --> Language Class Initialized
INFO - 2018-08-16 20:54:10 --> Loader Class Initialized
INFO - 2018-08-16 20:54:10 --> Controller Class Initialized
INFO - 2018-08-16 20:54:10 --> Database Driver Class Initialized
INFO - 2018-08-16 20:54:10 --> Model Class Initialized
INFO - 2018-08-16 20:54:10 --> Helper loaded: form_helper
INFO - 2018-08-16 20:54:10 --> Helper loaded: url_helper
DEBUG - 2018-08-16 20:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 20:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 20:54:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-16 20:54:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\admin_profile.php
INFO - 2018-08-16 20:54:10 --> Final output sent to browser
DEBUG - 2018-08-16 20:54:10 --> Total execution time: 0.2345
ERROR - 2018-08-16 21:03:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 21:03:24 --> Config Class Initialized
INFO - 2018-08-16 21:03:24 --> Hooks Class Initialized
DEBUG - 2018-08-16 21:03:24 --> UTF-8 Support Enabled
INFO - 2018-08-16 21:03:24 --> Utf8 Class Initialized
INFO - 2018-08-16 21:03:24 --> URI Class Initialized
INFO - 2018-08-16 21:03:24 --> Router Class Initialized
INFO - 2018-08-16 21:03:24 --> Output Class Initialized
INFO - 2018-08-16 21:03:24 --> Security Class Initialized
DEBUG - 2018-08-16 21:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 21:03:24 --> Input Class Initialized
INFO - 2018-08-16 21:03:24 --> Language Class Initialized
INFO - 2018-08-16 21:03:24 --> Loader Class Initialized
INFO - 2018-08-16 21:03:24 --> Controller Class Initialized
INFO - 2018-08-16 21:03:24 --> Database Driver Class Initialized
INFO - 2018-08-16 21:03:24 --> Model Class Initialized
INFO - 2018-08-16 21:03:24 --> Helper loaded: url_helper
DEBUG - 2018-08-16 21:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 21:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 21:03:24 --> Model Class Initialized
INFO - 2018-08-16 21:03:24 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 21:03:24 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 179
INFO - 2018-08-16 21:03:24 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 21:03:24 --> Final output sent to browser
DEBUG - 2018-08-16 21:03:24 --> Total execution time: 0.2361
ERROR - 2018-08-16 21:03:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-16 21:03:50 --> Config Class Initialized
INFO - 2018-08-16 21:03:50 --> Hooks Class Initialized
DEBUG - 2018-08-16 21:03:50 --> UTF-8 Support Enabled
INFO - 2018-08-16 21:03:50 --> Utf8 Class Initialized
INFO - 2018-08-16 21:03:50 --> URI Class Initialized
INFO - 2018-08-16 21:03:50 --> Router Class Initialized
INFO - 2018-08-16 21:03:50 --> Output Class Initialized
INFO - 2018-08-16 21:03:50 --> Security Class Initialized
DEBUG - 2018-08-16 21:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-16 21:03:50 --> Input Class Initialized
INFO - 2018-08-16 21:03:50 --> Language Class Initialized
INFO - 2018-08-16 21:03:50 --> Loader Class Initialized
INFO - 2018-08-16 21:03:50 --> Controller Class Initialized
INFO - 2018-08-16 21:03:50 --> Database Driver Class Initialized
INFO - 2018-08-16 21:03:50 --> Model Class Initialized
INFO - 2018-08-16 21:03:50 --> Helper loaded: url_helper
DEBUG - 2018-08-16 21:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-16 21:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-16 21:03:50 --> Model Class Initialized
INFO - 2018-08-16 21:03:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-08-16 21:03:50 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\davidhood\application\views\user.php 179
INFO - 2018-08-16 21:03:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-08-16 21:03:50 --> Final output sent to browser
DEBUG - 2018-08-16 21:03:50 --> Total execution time: 0.2302
