<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-16 13:25:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-16 13:25:30 --> Config Class Initialized
INFO - 2017-08-16 13:25:30 --> Hooks Class Initialized
DEBUG - 2017-08-16 13:25:30 --> UTF-8 Support Enabled
INFO - 2017-08-16 13:25:30 --> Utf8 Class Initialized
INFO - 2017-08-16 13:25:30 --> URI Class Initialized
DEBUG - 2017-08-16 13:25:30 --> No URI present. Default controller set.
INFO - 2017-08-16 13:25:30 --> Router Class Initialized
INFO - 2017-08-16 13:25:30 --> Output Class Initialized
INFO - 2017-08-16 13:25:30 --> Security Class Initialized
DEBUG - 2017-08-16 13:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 13:25:30 --> Input Class Initialized
INFO - 2017-08-16 13:25:30 --> Language Class Initialized
INFO - 2017-08-16 13:25:31 --> Loader Class Initialized
INFO - 2017-08-16 13:25:31 --> Controller Class Initialized
INFO - 2017-08-16 13:25:31 --> Database Driver Class Initialized
INFO - 2017-08-16 13:25:31 --> Model Class Initialized
INFO - 2017-08-16 13:25:31 --> Helper loaded: form_helper
INFO - 2017-08-16 13:25:31 --> Helper loaded: url_helper
INFO - 2017-08-16 13:25:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-08-16 13:25:31 --> Final output sent to browser
DEBUG - 2017-08-16 13:25:31 --> Total execution time: 0.8420
ERROR - 2017-08-16 13:25:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-16 13:25:33 --> Config Class Initialized
INFO - 2017-08-16 13:25:33 --> Hooks Class Initialized
DEBUG - 2017-08-16 13:25:33 --> UTF-8 Support Enabled
INFO - 2017-08-16 13:25:33 --> Utf8 Class Initialized
INFO - 2017-08-16 13:25:33 --> URI Class Initialized
INFO - 2017-08-16 13:25:33 --> Router Class Initialized
INFO - 2017-08-16 13:25:33 --> Output Class Initialized
INFO - 2017-08-16 13:25:33 --> Security Class Initialized
DEBUG - 2017-08-16 13:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 13:25:33 --> Input Class Initialized
INFO - 2017-08-16 13:25:33 --> Language Class Initialized
INFO - 2017-08-16 13:25:33 --> Loader Class Initialized
INFO - 2017-08-16 13:25:33 --> Controller Class Initialized
INFO - 2017-08-16 13:25:33 --> Database Driver Class Initialized
INFO - 2017-08-16 13:25:33 --> Model Class Initialized
INFO - 2017-08-16 13:25:33 --> Helper loaded: form_helper
INFO - 2017-08-16 13:25:33 --> Helper loaded: url_helper
INFO - 2017-08-16 13:25:33 --> Model Class Initialized
ERROR - 2017-08-16 13:25:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-16 13:25:33 --> Config Class Initialized
INFO - 2017-08-16 13:25:33 --> Hooks Class Initialized
DEBUG - 2017-08-16 13:25:33 --> UTF-8 Support Enabled
INFO - 2017-08-16 13:25:33 --> Utf8 Class Initialized
INFO - 2017-08-16 13:25:33 --> URI Class Initialized
INFO - 2017-08-16 13:25:33 --> Router Class Initialized
INFO - 2017-08-16 13:25:33 --> Output Class Initialized
INFO - 2017-08-16 13:25:33 --> Security Class Initialized
DEBUG - 2017-08-16 13:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 13:25:33 --> Input Class Initialized
INFO - 2017-08-16 13:25:33 --> Language Class Initialized
INFO - 2017-08-16 13:25:33 --> Loader Class Initialized
INFO - 2017-08-16 13:25:33 --> Controller Class Initialized
INFO - 2017-08-16 13:25:33 --> Database Driver Class Initialized
INFO - 2017-08-16 13:25:33 --> Model Class Initialized
INFO - 2017-08-16 13:25:33 --> Helper loaded: form_helper
INFO - 2017-08-16 13:25:33 --> Helper loaded: url_helper
INFO - 2017-08-16 13:25:33 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-16 13:25:33 --> Model Class Initialized
INFO - 2017-08-16 13:25:33 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-08-16 13:25:33 --> Final output sent to browser
DEBUG - 2017-08-16 13:25:33 --> Total execution time: 0.2530
ERROR - 2017-08-16 13:25:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-16 13:25:35 --> Config Class Initialized
INFO - 2017-08-16 13:25:35 --> Hooks Class Initialized
DEBUG - 2017-08-16 13:25:35 --> UTF-8 Support Enabled
INFO - 2017-08-16 13:25:35 --> Utf8 Class Initialized
INFO - 2017-08-16 13:25:35 --> URI Class Initialized
INFO - 2017-08-16 13:25:35 --> Router Class Initialized
INFO - 2017-08-16 13:25:35 --> Output Class Initialized
INFO - 2017-08-16 13:25:35 --> Security Class Initialized
DEBUG - 2017-08-16 13:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 13:25:35 --> Input Class Initialized
INFO - 2017-08-16 13:25:35 --> Language Class Initialized
INFO - 2017-08-16 13:25:35 --> Loader Class Initialized
INFO - 2017-08-16 13:25:35 --> Controller Class Initialized
INFO - 2017-08-16 13:25:35 --> Database Driver Class Initialized
INFO - 2017-08-16 13:25:35 --> Model Class Initialized
INFO - 2017-08-16 13:25:35 --> Helper loaded: form_helper
INFO - 2017-08-16 13:25:35 --> Helper loaded: url_helper
INFO - 2017-08-16 13:25:35 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-16 13:25:35 --> Model Class Initialized
INFO - 2017-08-16 13:25:35 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-08-16 13:25:35 --> Final output sent to browser
DEBUG - 2017-08-16 13:25:35 --> Total execution time: 0.1660
ERROR - 2017-08-16 13:25:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-16 13:25:39 --> Config Class Initialized
INFO - 2017-08-16 13:25:39 --> Hooks Class Initialized
DEBUG - 2017-08-16 13:25:39 --> UTF-8 Support Enabled
INFO - 2017-08-16 13:25:39 --> Utf8 Class Initialized
INFO - 2017-08-16 13:25:39 --> URI Class Initialized
INFO - 2017-08-16 13:25:39 --> Router Class Initialized
INFO - 2017-08-16 13:25:39 --> Output Class Initialized
INFO - 2017-08-16 13:25:39 --> Security Class Initialized
DEBUG - 2017-08-16 13:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-16 13:25:39 --> Input Class Initialized
INFO - 2017-08-16 13:25:39 --> Language Class Initialized
INFO - 2017-08-16 13:25:39 --> Loader Class Initialized
INFO - 2017-08-16 13:25:39 --> Controller Class Initialized
INFO - 2017-08-16 13:25:39 --> Database Driver Class Initialized
INFO - 2017-08-16 13:25:39 --> Model Class Initialized
INFO - 2017-08-16 13:25:39 --> Helper loaded: form_helper
INFO - 2017-08-16 13:25:39 --> Helper loaded: url_helper
INFO - 2017-08-16 13:25:39 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-16 13:25:39 --> Model Class Initialized
INFO - 2017-08-16 13:25:39 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-08-16 13:25:39 --> Final output sent to browser
DEBUG - 2017-08-16 13:25:39 --> Total execution time: 0.1480
