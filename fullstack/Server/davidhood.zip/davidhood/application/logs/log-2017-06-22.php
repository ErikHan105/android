<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-22 03:41:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 03:41:21 --> Config Class Initialized
INFO - 2017-06-22 03:41:21 --> Hooks Class Initialized
DEBUG - 2017-06-22 03:41:21 --> UTF-8 Support Enabled
INFO - 2017-06-22 03:41:21 --> Utf8 Class Initialized
INFO - 2017-06-22 03:41:21 --> URI Class Initialized
INFO - 2017-06-22 03:41:21 --> Router Class Initialized
INFO - 2017-06-22 03:41:21 --> Output Class Initialized
INFO - 2017-06-22 03:41:21 --> Security Class Initialized
DEBUG - 2017-06-22 03:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 03:41:21 --> Input Class Initialized
INFO - 2017-06-22 03:41:21 --> Language Class Initialized
INFO - 2017-06-22 03:41:21 --> Loader Class Initialized
INFO - 2017-06-22 03:41:21 --> Controller Class Initialized
INFO - 2017-06-22 03:41:21 --> Database Driver Class Initialized
INFO - 2017-06-22 03:41:21 --> Model Class Initialized
INFO - 2017-06-22 03:41:21 --> Helper loaded: form_helper
INFO - 2017-06-22 03:41:21 --> Helper loaded: url_helper
INFO - 2017-06-22 03:41:21 --> Model Class Initialized
INFO - 2017-06-22 03:41:21 --> Final output sent to browser
DEBUG - 2017-06-22 03:41:21 --> Total execution time: 0.0420
ERROR - 2017-06-22 03:41:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 03:41:22 --> Config Class Initialized
INFO - 2017-06-22 03:41:22 --> Hooks Class Initialized
DEBUG - 2017-06-22 03:41:22 --> UTF-8 Support Enabled
INFO - 2017-06-22 03:41:22 --> Utf8 Class Initialized
INFO - 2017-06-22 03:41:22 --> URI Class Initialized
INFO - 2017-06-22 03:41:22 --> Router Class Initialized
INFO - 2017-06-22 03:41:22 --> Output Class Initialized
INFO - 2017-06-22 03:41:22 --> Security Class Initialized
DEBUG - 2017-06-22 03:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 03:41:22 --> Input Class Initialized
INFO - 2017-06-22 03:41:22 --> Language Class Initialized
INFO - 2017-06-22 03:41:22 --> Loader Class Initialized
INFO - 2017-06-22 03:41:22 --> Controller Class Initialized
INFO - 2017-06-22 03:41:22 --> Database Driver Class Initialized
INFO - 2017-06-22 03:41:22 --> Model Class Initialized
INFO - 2017-06-22 03:41:22 --> Helper loaded: form_helper
INFO - 2017-06-22 03:41:22 --> Helper loaded: url_helper
INFO - 2017-06-22 03:41:22 --> Model Class Initialized
INFO - 2017-06-22 03:41:22 --> Final output sent to browser
DEBUG - 2017-06-22 03:41:22 --> Total execution time: 0.0380
ERROR - 2017-06-22 16:28:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:28:39 --> Config Class Initialized
INFO - 2017-06-22 16:28:39 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:28:39 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:28:39 --> Utf8 Class Initialized
INFO - 2017-06-22 16:28:39 --> URI Class Initialized
INFO - 2017-06-22 16:28:39 --> Router Class Initialized
INFO - 2017-06-22 16:28:39 --> Output Class Initialized
INFO - 2017-06-22 16:28:39 --> Security Class Initialized
DEBUG - 2017-06-22 16:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:28:39 --> Input Class Initialized
INFO - 2017-06-22 16:28:39 --> Language Class Initialized
INFO - 2017-06-22 16:28:39 --> Loader Class Initialized
INFO - 2017-06-22 16:28:39 --> Controller Class Initialized
INFO - 2017-06-22 16:28:39 --> Database Driver Class Initialized
INFO - 2017-06-22 16:28:40 --> Model Class Initialized
INFO - 2017-06-22 16:28:40 --> Helper loaded: form_helper
INFO - 2017-06-22 16:28:40 --> Helper loaded: url_helper
INFO - 2017-06-22 16:28:40 --> Model Class Initialized
INFO - 2017-06-22 16:28:40 --> Final output sent to browser
DEBUG - 2017-06-22 16:28:40 --> Total execution time: 0.2780
ERROR - 2017-06-22 16:49:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:49:34 --> Config Class Initialized
INFO - 2017-06-22 16:49:34 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:49:34 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:49:35 --> Utf8 Class Initialized
INFO - 2017-06-22 16:49:35 --> URI Class Initialized
INFO - 2017-06-22 16:49:35 --> Router Class Initialized
INFO - 2017-06-22 16:49:35 --> Output Class Initialized
INFO - 2017-06-22 16:49:35 --> Security Class Initialized
DEBUG - 2017-06-22 16:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:49:35 --> Input Class Initialized
INFO - 2017-06-22 16:49:35 --> Language Class Initialized
INFO - 2017-06-22 16:49:35 --> Loader Class Initialized
INFO - 2017-06-22 16:49:35 --> Controller Class Initialized
INFO - 2017-06-22 16:49:35 --> Database Driver Class Initialized
INFO - 2017-06-22 16:49:35 --> Model Class Initialized
INFO - 2017-06-22 16:49:35 --> Helper loaded: form_helper
INFO - 2017-06-22 16:49:35 --> Helper loaded: url_helper
INFO - 2017-06-22 16:49:35 --> Model Class Initialized
INFO - 2017-06-22 16:49:35 --> Final output sent to browser
DEBUG - 2017-06-22 16:49:35 --> Total execution time: 0.0820
ERROR - 2017-06-22 16:49:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:49:36 --> Config Class Initialized
INFO - 2017-06-22 16:49:36 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:49:36 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:49:36 --> Utf8 Class Initialized
INFO - 2017-06-22 16:49:36 --> URI Class Initialized
INFO - 2017-06-22 16:49:36 --> Router Class Initialized
INFO - 2017-06-22 16:49:36 --> Output Class Initialized
INFO - 2017-06-22 16:49:36 --> Security Class Initialized
DEBUG - 2017-06-22 16:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:49:36 --> Input Class Initialized
INFO - 2017-06-22 16:49:36 --> Language Class Initialized
INFO - 2017-06-22 16:49:36 --> Loader Class Initialized
INFO - 2017-06-22 16:49:36 --> Controller Class Initialized
INFO - 2017-06-22 16:49:36 --> Database Driver Class Initialized
INFO - 2017-06-22 16:49:36 --> Model Class Initialized
INFO - 2017-06-22 16:49:36 --> Helper loaded: form_helper
INFO - 2017-06-22 16:49:36 --> Helper loaded: url_helper
INFO - 2017-06-22 16:49:36 --> Model Class Initialized
INFO - 2017-06-22 16:49:36 --> Final output sent to browser
DEBUG - 2017-06-22 16:49:36 --> Total execution time: 0.0930
ERROR - 2017-06-22 16:50:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:50:29 --> Config Class Initialized
INFO - 2017-06-22 16:50:29 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:50:29 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:50:29 --> Utf8 Class Initialized
INFO - 2017-06-22 16:50:29 --> URI Class Initialized
DEBUG - 2017-06-22 16:50:29 --> No URI present. Default controller set.
INFO - 2017-06-22 16:50:29 --> Router Class Initialized
INFO - 2017-06-22 16:50:29 --> Output Class Initialized
INFO - 2017-06-22 16:50:29 --> Security Class Initialized
DEBUG - 2017-06-22 16:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:50:29 --> Input Class Initialized
INFO - 2017-06-22 16:50:29 --> Language Class Initialized
INFO - 2017-06-22 16:50:29 --> Loader Class Initialized
INFO - 2017-06-22 16:50:29 --> Controller Class Initialized
INFO - 2017-06-22 16:50:29 --> Database Driver Class Initialized
INFO - 2017-06-22 16:50:29 --> Model Class Initialized
INFO - 2017-06-22 16:50:29 --> Helper loaded: form_helper
INFO - 2017-06-22 16:50:29 --> Helper loaded: url_helper
INFO - 2017-06-22 16:50:29 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-06-22 16:50:29 --> Final output sent to browser
DEBUG - 2017-06-22 16:50:29 --> Total execution time: 0.0670
ERROR - 2017-06-22 16:50:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:50:31 --> Config Class Initialized
INFO - 2017-06-22 16:50:31 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:50:31 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:50:31 --> Utf8 Class Initialized
INFO - 2017-06-22 16:50:31 --> URI Class Initialized
INFO - 2017-06-22 16:50:31 --> Router Class Initialized
INFO - 2017-06-22 16:50:31 --> Output Class Initialized
INFO - 2017-06-22 16:50:31 --> Security Class Initialized
DEBUG - 2017-06-22 16:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:50:31 --> Input Class Initialized
INFO - 2017-06-22 16:50:31 --> Language Class Initialized
INFO - 2017-06-22 16:50:31 --> Loader Class Initialized
INFO - 2017-06-22 16:50:31 --> Controller Class Initialized
INFO - 2017-06-22 16:50:31 --> Database Driver Class Initialized
INFO - 2017-06-22 16:50:31 --> Model Class Initialized
INFO - 2017-06-22 16:50:31 --> Helper loaded: form_helper
INFO - 2017-06-22 16:50:31 --> Helper loaded: url_helper
INFO - 2017-06-22 16:50:31 --> Model Class Initialized
ERROR - 2017-06-22 16:50:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:50:31 --> Config Class Initialized
INFO - 2017-06-22 16:50:31 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:50:31 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:50:31 --> Utf8 Class Initialized
INFO - 2017-06-22 16:50:31 --> URI Class Initialized
INFO - 2017-06-22 16:50:31 --> Router Class Initialized
INFO - 2017-06-22 16:50:31 --> Output Class Initialized
INFO - 2017-06-22 16:50:31 --> Security Class Initialized
DEBUG - 2017-06-22 16:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:50:31 --> Input Class Initialized
INFO - 2017-06-22 16:50:31 --> Language Class Initialized
INFO - 2017-06-22 16:50:31 --> Loader Class Initialized
INFO - 2017-06-22 16:50:31 --> Controller Class Initialized
INFO - 2017-06-22 16:50:31 --> Database Driver Class Initialized
INFO - 2017-06-22 16:50:31 --> Model Class Initialized
INFO - 2017-06-22 16:50:31 --> Helper loaded: form_helper
INFO - 2017-06-22 16:50:31 --> Helper loaded: url_helper
INFO - 2017-06-22 16:50:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 16:50:31 --> Model Class Initialized
INFO - 2017-06-22 16:50:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-22 16:50:31 --> Final output sent to browser
DEBUG - 2017-06-22 16:50:31 --> Total execution time: 0.0990
ERROR - 2017-06-22 16:50:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:50:36 --> Config Class Initialized
INFO - 2017-06-22 16:50:36 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:50:36 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:50:36 --> Utf8 Class Initialized
INFO - 2017-06-22 16:50:36 --> URI Class Initialized
INFO - 2017-06-22 16:50:36 --> Router Class Initialized
INFO - 2017-06-22 16:50:36 --> Output Class Initialized
INFO - 2017-06-22 16:50:36 --> Security Class Initialized
DEBUG - 2017-06-22 16:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:50:36 --> Input Class Initialized
INFO - 2017-06-22 16:50:36 --> Language Class Initialized
INFO - 2017-06-22 16:50:36 --> Loader Class Initialized
INFO - 2017-06-22 16:50:36 --> Controller Class Initialized
INFO - 2017-06-22 16:50:36 --> Database Driver Class Initialized
INFO - 2017-06-22 16:50:36 --> Model Class Initialized
INFO - 2017-06-22 16:50:36 --> Helper loaded: form_helper
INFO - 2017-06-22 16:50:36 --> Helper loaded: url_helper
INFO - 2017-06-22 16:50:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 16:50:36 --> Model Class Initialized
INFO - 2017-06-22 16:50:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 16:50:36 --> Final output sent to browser
DEBUG - 2017-06-22 16:50:36 --> Total execution time: 0.0790
ERROR - 2017-06-22 16:50:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:50:48 --> Config Class Initialized
INFO - 2017-06-22 16:50:48 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:50:48 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:50:48 --> Utf8 Class Initialized
INFO - 2017-06-22 16:50:48 --> URI Class Initialized
INFO - 2017-06-22 16:50:48 --> Router Class Initialized
INFO - 2017-06-22 16:50:48 --> Output Class Initialized
INFO - 2017-06-22 16:50:48 --> Security Class Initialized
DEBUG - 2017-06-22 16:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:50:48 --> Input Class Initialized
INFO - 2017-06-22 16:50:48 --> Language Class Initialized
INFO - 2017-06-22 16:50:48 --> Loader Class Initialized
INFO - 2017-06-22 16:50:48 --> Controller Class Initialized
INFO - 2017-06-22 16:50:48 --> Database Driver Class Initialized
INFO - 2017-06-22 16:50:48 --> Model Class Initialized
INFO - 2017-06-22 16:50:48 --> Helper loaded: form_helper
INFO - 2017-06-22 16:50:48 --> Helper loaded: url_helper
INFO - 2017-06-22 16:50:48 --> Model Class Initialized
INFO - 2017-06-22 16:50:48 --> Final output sent to browser
DEBUG - 2017-06-22 16:50:48 --> Total execution time: 0.0420
ERROR - 2017-06-22 16:50:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:50:49 --> Config Class Initialized
INFO - 2017-06-22 16:50:49 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:50:49 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:50:49 --> Utf8 Class Initialized
INFO - 2017-06-22 16:50:49 --> URI Class Initialized
INFO - 2017-06-22 16:50:49 --> Router Class Initialized
INFO - 2017-06-22 16:50:49 --> Output Class Initialized
INFO - 2017-06-22 16:50:49 --> Security Class Initialized
DEBUG - 2017-06-22 16:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:50:49 --> Input Class Initialized
INFO - 2017-06-22 16:50:49 --> Language Class Initialized
INFO - 2017-06-22 16:50:49 --> Loader Class Initialized
INFO - 2017-06-22 16:50:49 --> Controller Class Initialized
INFO - 2017-06-22 16:50:49 --> Database Driver Class Initialized
INFO - 2017-06-22 16:50:49 --> Model Class Initialized
INFO - 2017-06-22 16:50:49 --> Helper loaded: form_helper
INFO - 2017-06-22 16:50:49 --> Helper loaded: url_helper
INFO - 2017-06-22 16:50:49 --> Model Class Initialized
INFO - 2017-06-22 16:50:49 --> Final output sent to browser
DEBUG - 2017-06-22 16:50:49 --> Total execution time: 0.0430
ERROR - 2017-06-22 16:51:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:51:29 --> Config Class Initialized
INFO - 2017-06-22 16:51:29 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:51:29 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:51:29 --> Utf8 Class Initialized
INFO - 2017-06-22 16:51:29 --> URI Class Initialized
INFO - 2017-06-22 16:51:29 --> Router Class Initialized
INFO - 2017-06-22 16:51:29 --> Output Class Initialized
INFO - 2017-06-22 16:51:29 --> Security Class Initialized
DEBUG - 2017-06-22 16:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:51:29 --> Input Class Initialized
INFO - 2017-06-22 16:51:29 --> Language Class Initialized
INFO - 2017-06-22 16:51:29 --> Loader Class Initialized
INFO - 2017-06-22 16:51:29 --> Controller Class Initialized
INFO - 2017-06-22 16:51:29 --> Database Driver Class Initialized
INFO - 2017-06-22 16:51:29 --> Model Class Initialized
INFO - 2017-06-22 16:51:29 --> Helper loaded: form_helper
INFO - 2017-06-22 16:51:29 --> Helper loaded: url_helper
INFO - 2017-06-22 16:51:29 --> Model Class Initialized
INFO - 2017-06-22 16:51:29 --> Final output sent to browser
DEBUG - 2017-06-22 16:51:29 --> Total execution time: 0.0870
ERROR - 2017-06-22 16:51:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:51:30 --> Config Class Initialized
INFO - 2017-06-22 16:51:30 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:51:30 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:51:30 --> Utf8 Class Initialized
INFO - 2017-06-22 16:51:30 --> URI Class Initialized
INFO - 2017-06-22 16:51:30 --> Router Class Initialized
INFO - 2017-06-22 16:51:30 --> Output Class Initialized
INFO - 2017-06-22 16:51:30 --> Security Class Initialized
DEBUG - 2017-06-22 16:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:51:30 --> Input Class Initialized
INFO - 2017-06-22 16:51:30 --> Language Class Initialized
INFO - 2017-06-22 16:51:30 --> Loader Class Initialized
INFO - 2017-06-22 16:51:30 --> Controller Class Initialized
INFO - 2017-06-22 16:51:30 --> Database Driver Class Initialized
INFO - 2017-06-22 16:51:30 --> Model Class Initialized
INFO - 2017-06-22 16:51:30 --> Helper loaded: form_helper
INFO - 2017-06-22 16:51:30 --> Helper loaded: url_helper
INFO - 2017-06-22 16:51:30 --> Model Class Initialized
INFO - 2017-06-22 16:51:30 --> Final output sent to browser
DEBUG - 2017-06-22 16:51:30 --> Total execution time: 0.0745
ERROR - 2017-06-22 16:53:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:53:12 --> Config Class Initialized
INFO - 2017-06-22 16:53:12 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:53:12 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:53:12 --> Utf8 Class Initialized
INFO - 2017-06-22 16:53:12 --> URI Class Initialized
INFO - 2017-06-22 16:53:12 --> Router Class Initialized
INFO - 2017-06-22 16:53:12 --> Output Class Initialized
INFO - 2017-06-22 16:53:12 --> Security Class Initialized
DEBUG - 2017-06-22 16:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:53:12 --> Input Class Initialized
INFO - 2017-06-22 16:53:12 --> Language Class Initialized
INFO - 2017-06-22 16:53:12 --> Loader Class Initialized
INFO - 2017-06-22 16:53:12 --> Controller Class Initialized
INFO - 2017-06-22 16:53:12 --> Database Driver Class Initialized
INFO - 2017-06-22 16:53:12 --> Model Class Initialized
INFO - 2017-06-22 16:53:12 --> Helper loaded: form_helper
INFO - 2017-06-22 16:53:12 --> Helper loaded: url_helper
INFO - 2017-06-22 16:53:12 --> Model Class Initialized
INFO - 2017-06-22 16:53:12 --> Final output sent to browser
DEBUG - 2017-06-22 16:53:12 --> Total execution time: 0.0875
ERROR - 2017-06-22 16:53:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:53:13 --> Config Class Initialized
INFO - 2017-06-22 16:53:13 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:53:13 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:53:13 --> Utf8 Class Initialized
INFO - 2017-06-22 16:53:13 --> URI Class Initialized
INFO - 2017-06-22 16:53:13 --> Router Class Initialized
INFO - 2017-06-22 16:53:13 --> Output Class Initialized
INFO - 2017-06-22 16:53:13 --> Security Class Initialized
DEBUG - 2017-06-22 16:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:53:13 --> Input Class Initialized
INFO - 2017-06-22 16:53:13 --> Language Class Initialized
INFO - 2017-06-22 16:53:13 --> Loader Class Initialized
INFO - 2017-06-22 16:53:13 --> Controller Class Initialized
INFO - 2017-06-22 16:53:13 --> Database Driver Class Initialized
INFO - 2017-06-22 16:53:13 --> Model Class Initialized
INFO - 2017-06-22 16:53:13 --> Helper loaded: form_helper
INFO - 2017-06-22 16:53:13 --> Helper loaded: url_helper
INFO - 2017-06-22 16:53:13 --> Model Class Initialized
INFO - 2017-06-22 16:53:13 --> Final output sent to browser
DEBUG - 2017-06-22 16:53:13 --> Total execution time: 0.0380
ERROR - 2017-06-22 16:53:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:53:48 --> Config Class Initialized
INFO - 2017-06-22 16:53:48 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:53:48 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:53:48 --> Utf8 Class Initialized
INFO - 2017-06-22 16:53:48 --> URI Class Initialized
INFO - 2017-06-22 16:53:48 --> Router Class Initialized
INFO - 2017-06-22 16:53:48 --> Output Class Initialized
INFO - 2017-06-22 16:53:48 --> Security Class Initialized
DEBUG - 2017-06-22 16:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:53:48 --> Input Class Initialized
INFO - 2017-06-22 16:53:48 --> Language Class Initialized
INFO - 2017-06-22 16:53:48 --> Loader Class Initialized
INFO - 2017-06-22 16:53:48 --> Controller Class Initialized
INFO - 2017-06-22 16:53:48 --> Database Driver Class Initialized
INFO - 2017-06-22 16:53:48 --> Model Class Initialized
INFO - 2017-06-22 16:53:48 --> Helper loaded: form_helper
INFO - 2017-06-22 16:53:48 --> Helper loaded: url_helper
INFO - 2017-06-22 16:53:48 --> Model Class Initialized
INFO - 2017-06-22 16:53:48 --> Final output sent to browser
DEBUG - 2017-06-22 16:53:48 --> Total execution time: 0.0540
ERROR - 2017-06-22 16:53:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:53:49 --> Config Class Initialized
INFO - 2017-06-22 16:53:49 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:53:49 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:53:49 --> Utf8 Class Initialized
INFO - 2017-06-22 16:53:49 --> URI Class Initialized
INFO - 2017-06-22 16:53:49 --> Router Class Initialized
INFO - 2017-06-22 16:53:49 --> Output Class Initialized
INFO - 2017-06-22 16:53:49 --> Security Class Initialized
DEBUG - 2017-06-22 16:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:53:49 --> Input Class Initialized
INFO - 2017-06-22 16:53:49 --> Language Class Initialized
INFO - 2017-06-22 16:53:49 --> Loader Class Initialized
INFO - 2017-06-22 16:53:49 --> Controller Class Initialized
INFO - 2017-06-22 16:53:49 --> Database Driver Class Initialized
INFO - 2017-06-22 16:53:49 --> Model Class Initialized
INFO - 2017-06-22 16:53:49 --> Helper loaded: form_helper
INFO - 2017-06-22 16:53:49 --> Helper loaded: url_helper
INFO - 2017-06-22 16:53:49 --> Model Class Initialized
INFO - 2017-06-22 16:53:49 --> Final output sent to browser
DEBUG - 2017-06-22 16:53:49 --> Total execution time: 0.0540
ERROR - 2017-06-22 16:55:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:55:03 --> Config Class Initialized
INFO - 2017-06-22 16:55:03 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:55:03 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:55:03 --> Utf8 Class Initialized
INFO - 2017-06-22 16:55:03 --> URI Class Initialized
INFO - 2017-06-22 16:55:03 --> Router Class Initialized
INFO - 2017-06-22 16:55:03 --> Output Class Initialized
INFO - 2017-06-22 16:55:03 --> Security Class Initialized
DEBUG - 2017-06-22 16:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:55:03 --> Input Class Initialized
INFO - 2017-06-22 16:55:03 --> Language Class Initialized
INFO - 2017-06-22 16:55:03 --> Loader Class Initialized
INFO - 2017-06-22 16:55:03 --> Controller Class Initialized
INFO - 2017-06-22 16:55:03 --> Database Driver Class Initialized
INFO - 2017-06-22 16:55:03 --> Model Class Initialized
INFO - 2017-06-22 16:55:03 --> Helper loaded: form_helper
INFO - 2017-06-22 16:55:03 --> Helper loaded: url_helper
INFO - 2017-06-22 16:55:03 --> Model Class Initialized
INFO - 2017-06-22 16:55:03 --> Final output sent to browser
DEBUG - 2017-06-22 16:55:03 --> Total execution time: 0.0640
ERROR - 2017-06-22 16:55:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:55:04 --> Config Class Initialized
INFO - 2017-06-22 16:55:04 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:55:04 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:55:04 --> Utf8 Class Initialized
INFO - 2017-06-22 16:55:04 --> URI Class Initialized
INFO - 2017-06-22 16:55:04 --> Router Class Initialized
INFO - 2017-06-22 16:55:04 --> Output Class Initialized
INFO - 2017-06-22 16:55:04 --> Security Class Initialized
DEBUG - 2017-06-22 16:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:55:04 --> Input Class Initialized
INFO - 2017-06-22 16:55:04 --> Language Class Initialized
INFO - 2017-06-22 16:55:04 --> Loader Class Initialized
INFO - 2017-06-22 16:55:04 --> Controller Class Initialized
INFO - 2017-06-22 16:55:04 --> Database Driver Class Initialized
INFO - 2017-06-22 16:55:04 --> Model Class Initialized
INFO - 2017-06-22 16:55:04 --> Helper loaded: form_helper
INFO - 2017-06-22 16:55:04 --> Helper loaded: url_helper
INFO - 2017-06-22 16:55:04 --> Model Class Initialized
INFO - 2017-06-22 16:55:04 --> Final output sent to browser
DEBUG - 2017-06-22 16:55:04 --> Total execution time: 0.0480
ERROR - 2017-06-22 16:55:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:55:26 --> Config Class Initialized
INFO - 2017-06-22 16:55:26 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:55:26 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:55:26 --> Utf8 Class Initialized
INFO - 2017-06-22 16:55:26 --> URI Class Initialized
INFO - 2017-06-22 16:55:26 --> Router Class Initialized
INFO - 2017-06-22 16:55:26 --> Output Class Initialized
INFO - 2017-06-22 16:55:26 --> Security Class Initialized
DEBUG - 2017-06-22 16:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:55:26 --> Input Class Initialized
INFO - 2017-06-22 16:55:26 --> Language Class Initialized
INFO - 2017-06-22 16:55:26 --> Loader Class Initialized
INFO - 2017-06-22 16:55:26 --> Controller Class Initialized
INFO - 2017-06-22 16:55:26 --> Database Driver Class Initialized
INFO - 2017-06-22 16:55:26 --> Model Class Initialized
INFO - 2017-06-22 16:55:26 --> Helper loaded: form_helper
INFO - 2017-06-22 16:55:26 --> Helper loaded: url_helper
INFO - 2017-06-22 16:55:26 --> Model Class Initialized
INFO - 2017-06-22 16:55:26 --> Final output sent to browser
DEBUG - 2017-06-22 16:55:26 --> Total execution time: 0.0530
ERROR - 2017-06-22 16:55:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:55:55 --> Config Class Initialized
INFO - 2017-06-22 16:55:55 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:55:55 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:55:55 --> Utf8 Class Initialized
INFO - 2017-06-22 16:55:55 --> URI Class Initialized
INFO - 2017-06-22 16:55:55 --> Router Class Initialized
INFO - 2017-06-22 16:55:55 --> Output Class Initialized
INFO - 2017-06-22 16:55:55 --> Security Class Initialized
DEBUG - 2017-06-22 16:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:55:56 --> Input Class Initialized
INFO - 2017-06-22 16:55:56 --> Language Class Initialized
INFO - 2017-06-22 16:55:56 --> Loader Class Initialized
INFO - 2017-06-22 16:55:56 --> Controller Class Initialized
INFO - 2017-06-22 16:55:56 --> Database Driver Class Initialized
INFO - 2017-06-22 16:55:56 --> Model Class Initialized
INFO - 2017-06-22 16:55:56 --> Helper loaded: form_helper
INFO - 2017-06-22 16:55:56 --> Helper loaded: url_helper
INFO - 2017-06-22 16:55:56 --> Model Class Initialized
INFO - 2017-06-22 16:55:56 --> Final output sent to browser
DEBUG - 2017-06-22 16:55:56 --> Total execution time: 0.0490
ERROR - 2017-06-22 16:56:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:56:23 --> Config Class Initialized
INFO - 2017-06-22 16:56:23 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:56:23 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:56:23 --> Utf8 Class Initialized
INFO - 2017-06-22 16:56:23 --> URI Class Initialized
INFO - 2017-06-22 16:56:23 --> Router Class Initialized
INFO - 2017-06-22 16:56:23 --> Output Class Initialized
INFO - 2017-06-22 16:56:23 --> Security Class Initialized
DEBUG - 2017-06-22 16:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:56:23 --> Input Class Initialized
INFO - 2017-06-22 16:56:23 --> Language Class Initialized
INFO - 2017-06-22 16:56:23 --> Loader Class Initialized
INFO - 2017-06-22 16:56:23 --> Controller Class Initialized
INFO - 2017-06-22 16:56:23 --> Database Driver Class Initialized
INFO - 2017-06-22 16:56:23 --> Model Class Initialized
INFO - 2017-06-22 16:56:23 --> Helper loaded: form_helper
INFO - 2017-06-22 16:56:23 --> Helper loaded: url_helper
INFO - 2017-06-22 16:56:23 --> Model Class Initialized
INFO - 2017-06-22 16:56:23 --> Final output sent to browser
DEBUG - 2017-06-22 16:56:23 --> Total execution time: 0.0560
ERROR - 2017-06-22 16:56:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:56:24 --> Config Class Initialized
INFO - 2017-06-22 16:56:24 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:56:24 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:56:24 --> Utf8 Class Initialized
INFO - 2017-06-22 16:56:24 --> URI Class Initialized
INFO - 2017-06-22 16:56:24 --> Router Class Initialized
INFO - 2017-06-22 16:56:24 --> Output Class Initialized
INFO - 2017-06-22 16:56:24 --> Security Class Initialized
DEBUG - 2017-06-22 16:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:56:24 --> Input Class Initialized
INFO - 2017-06-22 16:56:24 --> Language Class Initialized
INFO - 2017-06-22 16:56:24 --> Loader Class Initialized
INFO - 2017-06-22 16:56:24 --> Controller Class Initialized
INFO - 2017-06-22 16:56:24 --> Database Driver Class Initialized
INFO - 2017-06-22 16:56:24 --> Model Class Initialized
INFO - 2017-06-22 16:56:24 --> Helper loaded: form_helper
INFO - 2017-06-22 16:56:24 --> Helper loaded: url_helper
INFO - 2017-06-22 16:56:24 --> Model Class Initialized
INFO - 2017-06-22 16:56:24 --> Final output sent to browser
DEBUG - 2017-06-22 16:56:24 --> Total execution time: 0.0560
ERROR - 2017-06-22 16:56:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:56:35 --> Config Class Initialized
INFO - 2017-06-22 16:56:35 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:56:35 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:56:35 --> Utf8 Class Initialized
INFO - 2017-06-22 16:56:35 --> URI Class Initialized
INFO - 2017-06-22 16:56:35 --> Router Class Initialized
INFO - 2017-06-22 16:56:35 --> Output Class Initialized
INFO - 2017-06-22 16:56:35 --> Security Class Initialized
DEBUG - 2017-06-22 16:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:56:35 --> Input Class Initialized
INFO - 2017-06-22 16:56:35 --> Language Class Initialized
INFO - 2017-06-22 16:56:35 --> Loader Class Initialized
INFO - 2017-06-22 16:56:35 --> Controller Class Initialized
INFO - 2017-06-22 16:56:35 --> Database Driver Class Initialized
INFO - 2017-06-22 16:56:35 --> Model Class Initialized
INFO - 2017-06-22 16:56:35 --> Helper loaded: form_helper
INFO - 2017-06-22 16:56:35 --> Helper loaded: url_helper
INFO - 2017-06-22 16:56:35 --> Model Class Initialized
INFO - 2017-06-22 16:56:35 --> Final output sent to browser
DEBUG - 2017-06-22 16:56:35 --> Total execution time: 0.0880
ERROR - 2017-06-22 16:56:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:56:37 --> Config Class Initialized
INFO - 2017-06-22 16:56:37 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:56:37 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:56:37 --> Utf8 Class Initialized
INFO - 2017-06-22 16:56:37 --> URI Class Initialized
INFO - 2017-06-22 16:56:37 --> Router Class Initialized
INFO - 2017-06-22 16:56:37 --> Output Class Initialized
INFO - 2017-06-22 16:56:37 --> Security Class Initialized
DEBUG - 2017-06-22 16:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:56:37 --> Input Class Initialized
INFO - 2017-06-22 16:56:38 --> Language Class Initialized
INFO - 2017-06-22 16:56:38 --> Loader Class Initialized
INFO - 2017-06-22 16:56:38 --> Controller Class Initialized
INFO - 2017-06-22 16:56:38 --> Database Driver Class Initialized
INFO - 2017-06-22 16:56:38 --> Model Class Initialized
INFO - 2017-06-22 16:56:38 --> Helper loaded: form_helper
INFO - 2017-06-22 16:56:38 --> Helper loaded: url_helper
INFO - 2017-06-22 16:56:38 --> Model Class Initialized
INFO - 2017-06-22 16:56:38 --> Final output sent to browser
DEBUG - 2017-06-22 16:56:38 --> Total execution time: 0.0920
ERROR - 2017-06-22 16:56:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:56:44 --> Config Class Initialized
INFO - 2017-06-22 16:56:44 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:56:44 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:56:44 --> Utf8 Class Initialized
INFO - 2017-06-22 16:56:44 --> URI Class Initialized
INFO - 2017-06-22 16:56:44 --> Router Class Initialized
INFO - 2017-06-22 16:56:44 --> Output Class Initialized
INFO - 2017-06-22 16:56:44 --> Security Class Initialized
DEBUG - 2017-06-22 16:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:56:44 --> Input Class Initialized
INFO - 2017-06-22 16:56:44 --> Language Class Initialized
INFO - 2017-06-22 16:56:44 --> Loader Class Initialized
INFO - 2017-06-22 16:56:44 --> Controller Class Initialized
INFO - 2017-06-22 16:56:44 --> Database Driver Class Initialized
INFO - 2017-06-22 16:56:44 --> Model Class Initialized
INFO - 2017-06-22 16:56:44 --> Helper loaded: form_helper
INFO - 2017-06-22 16:56:44 --> Helper loaded: url_helper
INFO - 2017-06-22 16:56:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 16:56:44 --> Model Class Initialized
INFO - 2017-06-22 16:56:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 16:56:44 --> Final output sent to browser
DEBUG - 2017-06-22 16:56:44 --> Total execution time: 0.1590
ERROR - 2017-06-22 16:56:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:56:46 --> Config Class Initialized
INFO - 2017-06-22 16:56:46 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:56:46 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:56:46 --> Utf8 Class Initialized
INFO - 2017-06-22 16:56:46 --> URI Class Initialized
INFO - 2017-06-22 16:56:46 --> Router Class Initialized
INFO - 2017-06-22 16:56:46 --> Output Class Initialized
INFO - 2017-06-22 16:56:46 --> Security Class Initialized
DEBUG - 2017-06-22 16:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:56:46 --> Input Class Initialized
INFO - 2017-06-22 16:56:46 --> Language Class Initialized
INFO - 2017-06-22 16:56:46 --> Loader Class Initialized
INFO - 2017-06-22 16:56:46 --> Controller Class Initialized
INFO - 2017-06-22 16:56:46 --> Database Driver Class Initialized
INFO - 2017-06-22 16:56:46 --> Model Class Initialized
INFO - 2017-06-22 16:56:46 --> Helper loaded: form_helper
INFO - 2017-06-22 16:56:46 --> Helper loaded: url_helper
INFO - 2017-06-22 16:56:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 16:56:46 --> Model Class Initialized
INFO - 2017-06-22 16:56:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 16:56:46 --> Final output sent to browser
DEBUG - 2017-06-22 16:56:46 --> Total execution time: 0.0990
ERROR - 2017-06-22 16:57:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:57:01 --> Config Class Initialized
INFO - 2017-06-22 16:57:01 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:57:01 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:57:01 --> Utf8 Class Initialized
INFO - 2017-06-22 16:57:01 --> URI Class Initialized
INFO - 2017-06-22 16:57:01 --> Router Class Initialized
INFO - 2017-06-22 16:57:01 --> Output Class Initialized
INFO - 2017-06-22 16:57:01 --> Security Class Initialized
DEBUG - 2017-06-22 16:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:57:01 --> Input Class Initialized
INFO - 2017-06-22 16:57:01 --> Language Class Initialized
INFO - 2017-06-22 16:57:01 --> Loader Class Initialized
INFO - 2017-06-22 16:57:01 --> Controller Class Initialized
INFO - 2017-06-22 16:57:01 --> Database Driver Class Initialized
INFO - 2017-06-22 16:57:01 --> Model Class Initialized
INFO - 2017-06-22 16:57:01 --> Helper loaded: form_helper
INFO - 2017-06-22 16:57:01 --> Helper loaded: url_helper
INFO - 2017-06-22 16:57:01 --> Upload Class Initialized
INFO - 2017-06-22 16:57:01 --> Final output sent to browser
DEBUG - 2017-06-22 16:57:01 --> Total execution time: 0.1430
ERROR - 2017-06-22 16:57:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:57:06 --> Config Class Initialized
INFO - 2017-06-22 16:57:06 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:57:06 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:57:06 --> Utf8 Class Initialized
INFO - 2017-06-22 16:57:06 --> URI Class Initialized
INFO - 2017-06-22 16:57:06 --> Router Class Initialized
INFO - 2017-06-22 16:57:06 --> Output Class Initialized
INFO - 2017-06-22 16:57:06 --> Security Class Initialized
DEBUG - 2017-06-22 16:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:57:06 --> Input Class Initialized
INFO - 2017-06-22 16:57:06 --> Language Class Initialized
INFO - 2017-06-22 16:57:06 --> Loader Class Initialized
INFO - 2017-06-22 16:57:06 --> Controller Class Initialized
INFO - 2017-06-22 16:57:06 --> Database Driver Class Initialized
INFO - 2017-06-22 16:57:06 --> Model Class Initialized
INFO - 2017-06-22 16:57:06 --> Helper loaded: form_helper
INFO - 2017-06-22 16:57:06 --> Helper loaded: url_helper
INFO - 2017-06-22 16:57:06 --> Model Class Initialized
INFO - 2017-06-22 16:57:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 16:57:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 16:57:06 --> Final output sent to browser
DEBUG - 2017-06-22 16:57:06 --> Total execution time: 0.1590
ERROR - 2017-06-22 16:57:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:57:23 --> Config Class Initialized
INFO - 2017-06-22 16:57:23 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:57:23 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:57:23 --> Utf8 Class Initialized
INFO - 2017-06-22 16:57:23 --> URI Class Initialized
INFO - 2017-06-22 16:57:23 --> Router Class Initialized
INFO - 2017-06-22 16:57:23 --> Output Class Initialized
INFO - 2017-06-22 16:57:23 --> Security Class Initialized
DEBUG - 2017-06-22 16:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:57:23 --> Input Class Initialized
INFO - 2017-06-22 16:57:23 --> Language Class Initialized
INFO - 2017-06-22 16:57:23 --> Loader Class Initialized
INFO - 2017-06-22 16:57:23 --> Controller Class Initialized
INFO - 2017-06-22 16:57:23 --> Database Driver Class Initialized
INFO - 2017-06-22 16:57:23 --> Model Class Initialized
INFO - 2017-06-22 16:57:23 --> Helper loaded: form_helper
INFO - 2017-06-22 16:57:23 --> Helper loaded: url_helper
INFO - 2017-06-22 16:57:23 --> Model Class Initialized
INFO - 2017-06-22 16:57:23 --> Final output sent to browser
DEBUG - 2017-06-22 16:57:23 --> Total execution time: 0.0580
ERROR - 2017-06-22 16:57:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:57:23 --> Config Class Initialized
INFO - 2017-06-22 16:57:23 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:57:23 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:57:23 --> Utf8 Class Initialized
INFO - 2017-06-22 16:57:23 --> URI Class Initialized
INFO - 2017-06-22 16:57:23 --> Router Class Initialized
INFO - 2017-06-22 16:57:23 --> Output Class Initialized
INFO - 2017-06-22 16:57:23 --> Security Class Initialized
DEBUG - 2017-06-22 16:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:57:23 --> Input Class Initialized
INFO - 2017-06-22 16:57:23 --> Language Class Initialized
INFO - 2017-06-22 16:57:23 --> Loader Class Initialized
INFO - 2017-06-22 16:57:23 --> Controller Class Initialized
INFO - 2017-06-22 16:57:23 --> Database Driver Class Initialized
INFO - 2017-06-22 16:57:23 --> Model Class Initialized
INFO - 2017-06-22 16:57:23 --> Helper loaded: form_helper
INFO - 2017-06-22 16:57:23 --> Helper loaded: url_helper
INFO - 2017-06-22 16:57:23 --> Model Class Initialized
INFO - 2017-06-22 16:57:23 --> Final output sent to browser
DEBUG - 2017-06-22 16:57:23 --> Total execution time: 0.0650
ERROR - 2017-06-22 16:57:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:57:49 --> Config Class Initialized
INFO - 2017-06-22 16:57:49 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:57:49 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:57:49 --> Utf8 Class Initialized
INFO - 2017-06-22 16:57:49 --> URI Class Initialized
INFO - 2017-06-22 16:57:49 --> Router Class Initialized
INFO - 2017-06-22 16:57:49 --> Output Class Initialized
INFO - 2017-06-22 16:57:49 --> Security Class Initialized
DEBUG - 2017-06-22 16:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:57:49 --> Input Class Initialized
INFO - 2017-06-22 16:57:49 --> Language Class Initialized
INFO - 2017-06-22 16:57:49 --> Loader Class Initialized
INFO - 2017-06-22 16:57:49 --> Controller Class Initialized
INFO - 2017-06-22 16:57:49 --> Database Driver Class Initialized
INFO - 2017-06-22 16:57:49 --> Model Class Initialized
INFO - 2017-06-22 16:57:49 --> Helper loaded: form_helper
INFO - 2017-06-22 16:57:49 --> Helper loaded: url_helper
INFO - 2017-06-22 16:57:49 --> Model Class Initialized
INFO - 2017-06-22 16:57:49 --> Final output sent to browser
DEBUG - 2017-06-22 16:57:49 --> Total execution time: 0.0470
ERROR - 2017-06-22 16:58:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:58:41 --> Config Class Initialized
INFO - 2017-06-22 16:58:41 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:58:41 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:58:41 --> Utf8 Class Initialized
INFO - 2017-06-22 16:58:41 --> URI Class Initialized
INFO - 2017-06-22 16:58:41 --> Router Class Initialized
INFO - 2017-06-22 16:58:41 --> Output Class Initialized
INFO - 2017-06-22 16:58:41 --> Security Class Initialized
DEBUG - 2017-06-22 16:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:58:41 --> Input Class Initialized
INFO - 2017-06-22 16:58:41 --> Language Class Initialized
INFO - 2017-06-22 16:58:41 --> Loader Class Initialized
INFO - 2017-06-22 16:58:41 --> Controller Class Initialized
INFO - 2017-06-22 16:58:41 --> Database Driver Class Initialized
INFO - 2017-06-22 16:58:41 --> Model Class Initialized
INFO - 2017-06-22 16:58:41 --> Helper loaded: form_helper
INFO - 2017-06-22 16:58:41 --> Helper loaded: url_helper
INFO - 2017-06-22 16:58:41 --> Model Class Initialized
INFO - 2017-06-22 16:58:41 --> Final output sent to browser
DEBUG - 2017-06-22 16:58:41 --> Total execution time: 0.0790
ERROR - 2017-06-22 16:58:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:58:42 --> Config Class Initialized
INFO - 2017-06-22 16:58:42 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:58:42 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:58:42 --> Utf8 Class Initialized
INFO - 2017-06-22 16:58:42 --> URI Class Initialized
INFO - 2017-06-22 16:58:42 --> Router Class Initialized
INFO - 2017-06-22 16:58:42 --> Output Class Initialized
INFO - 2017-06-22 16:58:42 --> Security Class Initialized
DEBUG - 2017-06-22 16:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:58:42 --> Input Class Initialized
INFO - 2017-06-22 16:58:42 --> Language Class Initialized
INFO - 2017-06-22 16:58:42 --> Loader Class Initialized
INFO - 2017-06-22 16:58:42 --> Controller Class Initialized
INFO - 2017-06-22 16:58:42 --> Database Driver Class Initialized
INFO - 2017-06-22 16:58:42 --> Model Class Initialized
INFO - 2017-06-22 16:58:42 --> Helper loaded: form_helper
INFO - 2017-06-22 16:58:42 --> Helper loaded: url_helper
INFO - 2017-06-22 16:58:42 --> Model Class Initialized
INFO - 2017-06-22 16:58:42 --> Final output sent to browser
DEBUG - 2017-06-22 16:58:42 --> Total execution time: 0.0730
ERROR - 2017-06-22 16:58:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:58:46 --> Config Class Initialized
INFO - 2017-06-22 16:58:46 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:58:46 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:58:46 --> Utf8 Class Initialized
INFO - 2017-06-22 16:58:46 --> URI Class Initialized
INFO - 2017-06-22 16:58:46 --> Router Class Initialized
INFO - 2017-06-22 16:58:46 --> Output Class Initialized
INFO - 2017-06-22 16:58:46 --> Security Class Initialized
DEBUG - 2017-06-22 16:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:58:46 --> Input Class Initialized
INFO - 2017-06-22 16:58:46 --> Language Class Initialized
INFO - 2017-06-22 16:58:46 --> Loader Class Initialized
INFO - 2017-06-22 16:58:46 --> Controller Class Initialized
INFO - 2017-06-22 16:58:46 --> Database Driver Class Initialized
INFO - 2017-06-22 16:58:46 --> Model Class Initialized
INFO - 2017-06-22 16:58:46 --> Helper loaded: form_helper
INFO - 2017-06-22 16:58:46 --> Helper loaded: url_helper
INFO - 2017-06-22 16:58:46 --> Model Class Initialized
INFO - 2017-06-22 16:58:46 --> Final output sent to browser
DEBUG - 2017-06-22 16:58:46 --> Total execution time: 0.0750
ERROR - 2017-06-22 16:59:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:59:14 --> Config Class Initialized
INFO - 2017-06-22 16:59:14 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:59:14 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:59:14 --> Utf8 Class Initialized
INFO - 2017-06-22 16:59:14 --> URI Class Initialized
INFO - 2017-06-22 16:59:14 --> Router Class Initialized
INFO - 2017-06-22 16:59:14 --> Output Class Initialized
INFO - 2017-06-22 16:59:14 --> Security Class Initialized
DEBUG - 2017-06-22 16:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:59:14 --> Input Class Initialized
INFO - 2017-06-22 16:59:14 --> Language Class Initialized
INFO - 2017-06-22 16:59:14 --> Loader Class Initialized
INFO - 2017-06-22 16:59:14 --> Controller Class Initialized
INFO - 2017-06-22 16:59:14 --> Database Driver Class Initialized
INFO - 2017-06-22 16:59:14 --> Model Class Initialized
INFO - 2017-06-22 16:59:14 --> Helper loaded: form_helper
INFO - 2017-06-22 16:59:14 --> Helper loaded: url_helper
INFO - 2017-06-22 16:59:14 --> Model Class Initialized
INFO - 2017-06-22 16:59:14 --> Final output sent to browser
DEBUG - 2017-06-22 16:59:14 --> Total execution time: 0.0590
ERROR - 2017-06-22 16:59:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 16:59:47 --> Config Class Initialized
INFO - 2017-06-22 16:59:47 --> Hooks Class Initialized
DEBUG - 2017-06-22 16:59:47 --> UTF-8 Support Enabled
INFO - 2017-06-22 16:59:47 --> Utf8 Class Initialized
INFO - 2017-06-22 16:59:47 --> URI Class Initialized
INFO - 2017-06-22 16:59:47 --> Router Class Initialized
INFO - 2017-06-22 16:59:47 --> Output Class Initialized
INFO - 2017-06-22 16:59:47 --> Security Class Initialized
DEBUG - 2017-06-22 16:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 16:59:47 --> Input Class Initialized
INFO - 2017-06-22 16:59:47 --> Language Class Initialized
INFO - 2017-06-22 16:59:47 --> Loader Class Initialized
INFO - 2017-06-22 16:59:47 --> Controller Class Initialized
INFO - 2017-06-22 16:59:47 --> Database Driver Class Initialized
INFO - 2017-06-22 16:59:47 --> Model Class Initialized
INFO - 2017-06-22 16:59:47 --> Helper loaded: form_helper
INFO - 2017-06-22 16:59:47 --> Helper loaded: url_helper
INFO - 2017-06-22 16:59:47 --> Model Class Initialized
INFO - 2017-06-22 16:59:47 --> Final output sent to browser
DEBUG - 2017-06-22 16:59:47 --> Total execution time: 0.0760
ERROR - 2017-06-22 17:00:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:00:09 --> Config Class Initialized
INFO - 2017-06-22 17:00:09 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:00:09 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:00:09 --> Utf8 Class Initialized
INFO - 2017-06-22 17:00:09 --> URI Class Initialized
INFO - 2017-06-22 17:00:09 --> Router Class Initialized
INFO - 2017-06-22 17:00:09 --> Output Class Initialized
INFO - 2017-06-22 17:00:09 --> Security Class Initialized
DEBUG - 2017-06-22 17:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:00:09 --> Input Class Initialized
INFO - 2017-06-22 17:00:09 --> Language Class Initialized
INFO - 2017-06-22 17:00:09 --> Loader Class Initialized
INFO - 2017-06-22 17:00:09 --> Controller Class Initialized
INFO - 2017-06-22 17:00:09 --> Database Driver Class Initialized
INFO - 2017-06-22 17:00:09 --> Model Class Initialized
INFO - 2017-06-22 17:00:09 --> Helper loaded: form_helper
INFO - 2017-06-22 17:00:09 --> Helper loaded: url_helper
INFO - 2017-06-22 17:00:09 --> Model Class Initialized
INFO - 2017-06-22 17:00:09 --> Final output sent to browser
DEBUG - 2017-06-22 17:00:09 --> Total execution time: 0.0500
ERROR - 2017-06-22 17:00:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:00:15 --> Config Class Initialized
INFO - 2017-06-22 17:00:15 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:00:15 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:00:15 --> Utf8 Class Initialized
INFO - 2017-06-22 17:00:15 --> URI Class Initialized
INFO - 2017-06-22 17:00:15 --> Router Class Initialized
INFO - 2017-06-22 17:00:15 --> Output Class Initialized
INFO - 2017-06-22 17:00:15 --> Security Class Initialized
DEBUG - 2017-06-22 17:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:00:15 --> Input Class Initialized
INFO - 2017-06-22 17:00:15 --> Language Class Initialized
INFO - 2017-06-22 17:00:15 --> Loader Class Initialized
INFO - 2017-06-22 17:00:15 --> Controller Class Initialized
INFO - 2017-06-22 17:00:15 --> Database Driver Class Initialized
INFO - 2017-06-22 17:00:15 --> Model Class Initialized
INFO - 2017-06-22 17:00:15 --> Helper loaded: form_helper
INFO - 2017-06-22 17:00:15 --> Helper loaded: url_helper
INFO - 2017-06-22 17:00:15 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 17:00:15 --> Model Class Initialized
INFO - 2017-06-22 17:00:15 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 17:00:15 --> Final output sent to browser
DEBUG - 2017-06-22 17:00:15 --> Total execution time: 0.0830
ERROR - 2017-06-22 17:00:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:00:19 --> Config Class Initialized
INFO - 2017-06-22 17:00:19 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:00:19 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:00:19 --> Utf8 Class Initialized
INFO - 2017-06-22 17:00:19 --> URI Class Initialized
INFO - 2017-06-22 17:00:19 --> Router Class Initialized
INFO - 2017-06-22 17:00:19 --> Output Class Initialized
INFO - 2017-06-22 17:00:19 --> Security Class Initialized
DEBUG - 2017-06-22 17:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:00:19 --> Input Class Initialized
INFO - 2017-06-22 17:00:19 --> Language Class Initialized
INFO - 2017-06-22 17:00:19 --> Loader Class Initialized
INFO - 2017-06-22 17:00:19 --> Controller Class Initialized
INFO - 2017-06-22 17:00:19 --> Database Driver Class Initialized
INFO - 2017-06-22 17:00:19 --> Model Class Initialized
INFO - 2017-06-22 17:00:19 --> Helper loaded: form_helper
INFO - 2017-06-22 17:00:19 --> Helper loaded: url_helper
INFO - 2017-06-22 17:00:19 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 17:00:19 --> Model Class Initialized
INFO - 2017-06-22 17:00:19 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 17:00:19 --> Final output sent to browser
DEBUG - 2017-06-22 17:00:19 --> Total execution time: 0.1790
ERROR - 2017-06-22 17:00:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:00:22 --> Config Class Initialized
INFO - 2017-06-22 17:00:22 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:00:22 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:00:22 --> Utf8 Class Initialized
INFO - 2017-06-22 17:00:22 --> URI Class Initialized
INFO - 2017-06-22 17:00:22 --> Router Class Initialized
INFO - 2017-06-22 17:00:22 --> Output Class Initialized
INFO - 2017-06-22 17:00:22 --> Security Class Initialized
DEBUG - 2017-06-22 17:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:00:22 --> Input Class Initialized
INFO - 2017-06-22 17:00:22 --> Language Class Initialized
INFO - 2017-06-22 17:00:22 --> Loader Class Initialized
INFO - 2017-06-22 17:00:22 --> Controller Class Initialized
INFO - 2017-06-22 17:00:22 --> Database Driver Class Initialized
INFO - 2017-06-22 17:00:23 --> Model Class Initialized
INFO - 2017-06-22 17:00:23 --> Helper loaded: form_helper
INFO - 2017-06-22 17:00:23 --> Helper loaded: url_helper
INFO - 2017-06-22 17:00:23 --> Model Class Initialized
INFO - 2017-06-22 17:00:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 17:00:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 17:00:23 --> Final output sent to browser
DEBUG - 2017-06-22 17:00:23 --> Total execution time: 0.1390
ERROR - 2017-06-22 17:00:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:00:47 --> Config Class Initialized
INFO - 2017-06-22 17:00:47 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:00:47 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:00:47 --> Utf8 Class Initialized
INFO - 2017-06-22 17:00:47 --> URI Class Initialized
INFO - 2017-06-22 17:00:47 --> Router Class Initialized
INFO - 2017-06-22 17:00:47 --> Output Class Initialized
INFO - 2017-06-22 17:00:47 --> Security Class Initialized
DEBUG - 2017-06-22 17:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:00:47 --> Input Class Initialized
INFO - 2017-06-22 17:00:47 --> Language Class Initialized
INFO - 2017-06-22 17:00:47 --> Loader Class Initialized
INFO - 2017-06-22 17:00:47 --> Controller Class Initialized
INFO - 2017-06-22 17:00:47 --> Database Driver Class Initialized
INFO - 2017-06-22 17:00:47 --> Model Class Initialized
INFO - 2017-06-22 17:00:47 --> Helper loaded: form_helper
INFO - 2017-06-22 17:00:47 --> Helper loaded: url_helper
INFO - 2017-06-22 17:00:47 --> Model Class Initialized
INFO - 2017-06-22 17:00:47 --> Final output sent to browser
DEBUG - 2017-06-22 17:00:47 --> Total execution time: 0.0690
ERROR - 2017-06-22 17:00:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:00:49 --> Config Class Initialized
INFO - 2017-06-22 17:00:49 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:00:49 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:00:49 --> Utf8 Class Initialized
INFO - 2017-06-22 17:00:49 --> URI Class Initialized
INFO - 2017-06-22 17:00:49 --> Router Class Initialized
INFO - 2017-06-22 17:00:49 --> Output Class Initialized
INFO - 2017-06-22 17:00:49 --> Security Class Initialized
DEBUG - 2017-06-22 17:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:00:49 --> Input Class Initialized
INFO - 2017-06-22 17:00:49 --> Language Class Initialized
INFO - 2017-06-22 17:00:49 --> Loader Class Initialized
INFO - 2017-06-22 17:00:49 --> Controller Class Initialized
INFO - 2017-06-22 17:00:49 --> Database Driver Class Initialized
INFO - 2017-06-22 17:00:49 --> Model Class Initialized
INFO - 2017-06-22 17:00:49 --> Helper loaded: form_helper
INFO - 2017-06-22 17:00:49 --> Helper loaded: url_helper
INFO - 2017-06-22 17:00:49 --> Model Class Initialized
INFO - 2017-06-22 17:00:49 --> Final output sent to browser
DEBUG - 2017-06-22 17:00:49 --> Total execution time: 0.0720
ERROR - 2017-06-22 17:00:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:00:52 --> Config Class Initialized
INFO - 2017-06-22 17:00:52 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:00:52 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:00:52 --> Utf8 Class Initialized
INFO - 2017-06-22 17:00:52 --> URI Class Initialized
INFO - 2017-06-22 17:00:52 --> Router Class Initialized
INFO - 2017-06-22 17:00:52 --> Output Class Initialized
INFO - 2017-06-22 17:00:52 --> Security Class Initialized
DEBUG - 2017-06-22 17:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:00:52 --> Input Class Initialized
INFO - 2017-06-22 17:00:52 --> Language Class Initialized
INFO - 2017-06-22 17:00:52 --> Loader Class Initialized
INFO - 2017-06-22 17:00:52 --> Controller Class Initialized
INFO - 2017-06-22 17:00:52 --> Database Driver Class Initialized
INFO - 2017-06-22 17:00:52 --> Model Class Initialized
INFO - 2017-06-22 17:00:52 --> Helper loaded: form_helper
INFO - 2017-06-22 17:00:52 --> Helper loaded: url_helper
INFO - 2017-06-22 17:00:52 --> Model Class Initialized
INFO - 2017-06-22 17:00:52 --> Final output sent to browser
DEBUG - 2017-06-22 17:00:52 --> Total execution time: 0.0870
ERROR - 2017-06-22 17:01:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:01:37 --> Config Class Initialized
INFO - 2017-06-22 17:01:37 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:01:37 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:01:37 --> Utf8 Class Initialized
INFO - 2017-06-22 17:01:37 --> URI Class Initialized
INFO - 2017-06-22 17:01:37 --> Router Class Initialized
INFO - 2017-06-22 17:01:37 --> Output Class Initialized
INFO - 2017-06-22 17:01:37 --> Security Class Initialized
DEBUG - 2017-06-22 17:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:01:37 --> Input Class Initialized
INFO - 2017-06-22 17:01:37 --> Language Class Initialized
INFO - 2017-06-22 17:01:37 --> Loader Class Initialized
INFO - 2017-06-22 17:01:37 --> Controller Class Initialized
INFO - 2017-06-22 17:01:37 --> Database Driver Class Initialized
INFO - 2017-06-22 17:01:37 --> Model Class Initialized
INFO - 2017-06-22 17:01:37 --> Helper loaded: form_helper
INFO - 2017-06-22 17:01:37 --> Helper loaded: url_helper
INFO - 2017-06-22 17:01:37 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 17:01:37 --> Model Class Initialized
INFO - 2017-06-22 17:01:37 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 17:01:37 --> Final output sent to browser
DEBUG - 2017-06-22 17:01:37 --> Total execution time: 0.0660
ERROR - 2017-06-22 17:01:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:01:38 --> Config Class Initialized
INFO - 2017-06-22 17:01:38 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:01:38 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:01:38 --> Utf8 Class Initialized
INFO - 2017-06-22 17:01:38 --> URI Class Initialized
INFO - 2017-06-22 17:01:38 --> Router Class Initialized
INFO - 2017-06-22 17:01:38 --> Output Class Initialized
INFO - 2017-06-22 17:01:39 --> Security Class Initialized
DEBUG - 2017-06-22 17:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:01:39 --> Input Class Initialized
INFO - 2017-06-22 17:01:39 --> Language Class Initialized
INFO - 2017-06-22 17:01:39 --> Loader Class Initialized
INFO - 2017-06-22 17:01:39 --> Controller Class Initialized
INFO - 2017-06-22 17:01:39 --> Database Driver Class Initialized
INFO - 2017-06-22 17:01:39 --> Model Class Initialized
INFO - 2017-06-22 17:01:39 --> Helper loaded: form_helper
INFO - 2017-06-22 17:01:39 --> Helper loaded: url_helper
INFO - 2017-06-22 17:01:39 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 17:01:39 --> Model Class Initialized
INFO - 2017-06-22 17:01:39 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 17:01:39 --> Final output sent to browser
DEBUG - 2017-06-22 17:01:39 --> Total execution time: 0.0860
ERROR - 2017-06-22 17:01:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:01:39 --> Config Class Initialized
INFO - 2017-06-22 17:01:39 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:01:39 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:01:39 --> Utf8 Class Initialized
INFO - 2017-06-22 17:01:39 --> URI Class Initialized
INFO - 2017-06-22 17:01:39 --> Router Class Initialized
INFO - 2017-06-22 17:01:39 --> Output Class Initialized
INFO - 2017-06-22 17:01:39 --> Security Class Initialized
DEBUG - 2017-06-22 17:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:01:39 --> Input Class Initialized
INFO - 2017-06-22 17:01:39 --> Language Class Initialized
INFO - 2017-06-22 17:01:39 --> Loader Class Initialized
INFO - 2017-06-22 17:01:39 --> Controller Class Initialized
INFO - 2017-06-22 17:01:39 --> Database Driver Class Initialized
INFO - 2017-06-22 17:01:39 --> Model Class Initialized
INFO - 2017-06-22 17:01:39 --> Helper loaded: form_helper
INFO - 2017-06-22 17:01:39 --> Helper loaded: url_helper
INFO - 2017-06-22 17:01:39 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 17:01:39 --> Model Class Initialized
INFO - 2017-06-22 17:01:39 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 17:01:39 --> Final output sent to browser
DEBUG - 2017-06-22 17:01:39 --> Total execution time: 0.1020
ERROR - 2017-06-22 17:01:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:01:41 --> Config Class Initialized
INFO - 2017-06-22 17:01:41 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:01:41 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:01:41 --> Utf8 Class Initialized
INFO - 2017-06-22 17:01:41 --> URI Class Initialized
INFO - 2017-06-22 17:01:41 --> Router Class Initialized
INFO - 2017-06-22 17:01:41 --> Output Class Initialized
INFO - 2017-06-22 17:01:41 --> Security Class Initialized
DEBUG - 2017-06-22 17:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:01:41 --> Input Class Initialized
INFO - 2017-06-22 17:01:41 --> Language Class Initialized
INFO - 2017-06-22 17:01:41 --> Loader Class Initialized
INFO - 2017-06-22 17:01:41 --> Controller Class Initialized
INFO - 2017-06-22 17:01:41 --> Database Driver Class Initialized
INFO - 2017-06-22 17:01:41 --> Model Class Initialized
INFO - 2017-06-22 17:01:41 --> Helper loaded: form_helper
INFO - 2017-06-22 17:01:41 --> Helper loaded: url_helper
INFO - 2017-06-22 17:01:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 17:01:41 --> Model Class Initialized
INFO - 2017-06-22 17:01:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 17:01:41 --> Final output sent to browser
DEBUG - 2017-06-22 17:01:41 --> Total execution time: 0.0730
ERROR - 2017-06-22 17:01:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:01:44 --> Config Class Initialized
INFO - 2017-06-22 17:01:44 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:01:44 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:01:44 --> Utf8 Class Initialized
INFO - 2017-06-22 17:01:44 --> URI Class Initialized
INFO - 2017-06-22 17:01:44 --> Router Class Initialized
INFO - 2017-06-22 17:01:44 --> Output Class Initialized
INFO - 2017-06-22 17:01:44 --> Security Class Initialized
DEBUG - 2017-06-22 17:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:01:44 --> Input Class Initialized
INFO - 2017-06-22 17:01:44 --> Language Class Initialized
INFO - 2017-06-22 17:01:44 --> Loader Class Initialized
INFO - 2017-06-22 17:01:44 --> Controller Class Initialized
INFO - 2017-06-22 17:01:44 --> Database Driver Class Initialized
INFO - 2017-06-22 17:01:44 --> Model Class Initialized
INFO - 2017-06-22 17:01:44 --> Helper loaded: form_helper
INFO - 2017-06-22 17:01:44 --> Helper loaded: url_helper
INFO - 2017-06-22 17:01:44 --> Model Class Initialized
INFO - 2017-06-22 17:01:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 17:01:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 17:01:44 --> Final output sent to browser
DEBUG - 2017-06-22 17:01:44 --> Total execution time: 0.3420
ERROR - 2017-06-22 17:01:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:01:48 --> Config Class Initialized
INFO - 2017-06-22 17:01:48 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:01:48 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:01:48 --> Utf8 Class Initialized
INFO - 2017-06-22 17:01:48 --> URI Class Initialized
INFO - 2017-06-22 17:01:48 --> Router Class Initialized
INFO - 2017-06-22 17:01:48 --> Output Class Initialized
INFO - 2017-06-22 17:01:48 --> Security Class Initialized
DEBUG - 2017-06-22 17:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:01:48 --> Input Class Initialized
INFO - 2017-06-22 17:01:48 --> Language Class Initialized
INFO - 2017-06-22 17:01:48 --> Loader Class Initialized
INFO - 2017-06-22 17:01:48 --> Controller Class Initialized
INFO - 2017-06-22 17:01:48 --> Database Driver Class Initialized
INFO - 2017-06-22 17:01:48 --> Model Class Initialized
INFO - 2017-06-22 17:01:48 --> Helper loaded: form_helper
INFO - 2017-06-22 17:01:48 --> Helper loaded: url_helper
INFO - 2017-06-22 17:01:48 --> Model Class Initialized
INFO - 2017-06-22 17:01:48 --> Final output sent to browser
DEBUG - 2017-06-22 17:01:48 --> Total execution time: 0.0620
ERROR - 2017-06-22 17:01:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:01:58 --> Config Class Initialized
INFO - 2017-06-22 17:01:58 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:01:58 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:01:58 --> Utf8 Class Initialized
INFO - 2017-06-22 17:01:58 --> URI Class Initialized
INFO - 2017-06-22 17:01:58 --> Router Class Initialized
INFO - 2017-06-22 17:01:58 --> Output Class Initialized
INFO - 2017-06-22 17:01:58 --> Security Class Initialized
DEBUG - 2017-06-22 17:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:01:58 --> Input Class Initialized
INFO - 2017-06-22 17:01:58 --> Language Class Initialized
INFO - 2017-06-22 17:01:58 --> Loader Class Initialized
INFO - 2017-06-22 17:01:58 --> Controller Class Initialized
INFO - 2017-06-22 17:01:58 --> Database Driver Class Initialized
INFO - 2017-06-22 17:01:58 --> Model Class Initialized
INFO - 2017-06-22 17:01:58 --> Helper loaded: form_helper
INFO - 2017-06-22 17:01:58 --> Helper loaded: url_helper
INFO - 2017-06-22 17:01:58 --> Model Class Initialized
INFO - 2017-06-22 17:01:58 --> Final output sent to browser
DEBUG - 2017-06-22 17:01:58 --> Total execution time: 0.0720
ERROR - 2017-06-22 17:03:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:03:37 --> Config Class Initialized
INFO - 2017-06-22 17:03:37 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:03:37 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:03:37 --> Utf8 Class Initialized
INFO - 2017-06-22 17:03:37 --> URI Class Initialized
INFO - 2017-06-22 17:03:37 --> Router Class Initialized
INFO - 2017-06-22 17:03:37 --> Output Class Initialized
INFO - 2017-06-22 17:03:37 --> Security Class Initialized
DEBUG - 2017-06-22 17:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:03:37 --> Input Class Initialized
INFO - 2017-06-22 17:03:37 --> Language Class Initialized
INFO - 2017-06-22 17:03:37 --> Loader Class Initialized
INFO - 2017-06-22 17:03:37 --> Controller Class Initialized
INFO - 2017-06-22 17:03:37 --> Database Driver Class Initialized
INFO - 2017-06-22 17:03:37 --> Model Class Initialized
INFO - 2017-06-22 17:03:37 --> Helper loaded: form_helper
INFO - 2017-06-22 17:03:37 --> Helper loaded: url_helper
INFO - 2017-06-22 17:03:37 --> Model Class Initialized
INFO - 2017-06-22 17:03:37 --> Final output sent to browser
DEBUG - 2017-06-22 17:03:37 --> Total execution time: 0.0965
ERROR - 2017-06-22 17:06:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:06:10 --> Config Class Initialized
INFO - 2017-06-22 17:06:10 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:06:10 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:06:10 --> Utf8 Class Initialized
INFO - 2017-06-22 17:06:10 --> URI Class Initialized
INFO - 2017-06-22 17:06:10 --> Router Class Initialized
INFO - 2017-06-22 17:06:10 --> Output Class Initialized
INFO - 2017-06-22 17:06:10 --> Security Class Initialized
DEBUG - 2017-06-22 17:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:06:10 --> Input Class Initialized
INFO - 2017-06-22 17:06:10 --> Language Class Initialized
INFO - 2017-06-22 17:06:10 --> Loader Class Initialized
INFO - 2017-06-22 17:06:10 --> Controller Class Initialized
INFO - 2017-06-22 17:06:10 --> Database Driver Class Initialized
INFO - 2017-06-22 17:06:10 --> Model Class Initialized
INFO - 2017-06-22 17:06:10 --> Helper loaded: form_helper
INFO - 2017-06-22 17:06:10 --> Helper loaded: url_helper
INFO - 2017-06-22 17:06:10 --> Model Class Initialized
INFO - 2017-06-22 17:06:10 --> Final output sent to browser
DEBUG - 2017-06-22 17:06:10 --> Total execution time: 0.0575
ERROR - 2017-06-22 17:06:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:06:11 --> Config Class Initialized
INFO - 2017-06-22 17:06:11 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:06:11 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:06:11 --> Utf8 Class Initialized
INFO - 2017-06-22 17:06:11 --> URI Class Initialized
INFO - 2017-06-22 17:06:11 --> Router Class Initialized
INFO - 2017-06-22 17:06:11 --> Output Class Initialized
INFO - 2017-06-22 17:06:11 --> Security Class Initialized
DEBUG - 2017-06-22 17:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:06:11 --> Input Class Initialized
INFO - 2017-06-22 17:06:11 --> Language Class Initialized
INFO - 2017-06-22 17:06:11 --> Loader Class Initialized
INFO - 2017-06-22 17:06:11 --> Controller Class Initialized
INFO - 2017-06-22 17:06:11 --> Database Driver Class Initialized
INFO - 2017-06-22 17:06:11 --> Model Class Initialized
INFO - 2017-06-22 17:06:11 --> Helper loaded: form_helper
INFO - 2017-06-22 17:06:11 --> Helper loaded: url_helper
INFO - 2017-06-22 17:06:11 --> Model Class Initialized
INFO - 2017-06-22 17:06:11 --> Final output sent to browser
DEBUG - 2017-06-22 17:06:11 --> Total execution time: 0.0600
ERROR - 2017-06-22 17:06:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:06:17 --> Config Class Initialized
INFO - 2017-06-22 17:06:17 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:06:17 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:06:17 --> Utf8 Class Initialized
INFO - 2017-06-22 17:06:17 --> URI Class Initialized
INFO - 2017-06-22 17:06:17 --> Router Class Initialized
INFO - 2017-06-22 17:06:17 --> Output Class Initialized
INFO - 2017-06-22 17:06:17 --> Security Class Initialized
DEBUG - 2017-06-22 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:06:17 --> Input Class Initialized
INFO - 2017-06-22 17:06:17 --> Language Class Initialized
INFO - 2017-06-22 17:06:17 --> Loader Class Initialized
INFO - 2017-06-22 17:06:17 --> Controller Class Initialized
INFO - 2017-06-22 17:06:17 --> Database Driver Class Initialized
INFO - 2017-06-22 17:06:17 --> Model Class Initialized
INFO - 2017-06-22 17:06:17 --> Helper loaded: form_helper
INFO - 2017-06-22 17:06:17 --> Helper loaded: url_helper
INFO - 2017-06-22 17:06:17 --> Model Class Initialized
INFO - 2017-06-22 17:06:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 17:06:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 17:06:17 --> Final output sent to browser
DEBUG - 2017-06-22 17:06:17 --> Total execution time: 0.1340
ERROR - 2017-06-22 17:06:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:06:22 --> Config Class Initialized
INFO - 2017-06-22 17:06:22 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:06:22 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:06:22 --> Utf8 Class Initialized
INFO - 2017-06-22 17:06:22 --> URI Class Initialized
INFO - 2017-06-22 17:06:22 --> Router Class Initialized
INFO - 2017-06-22 17:06:22 --> Output Class Initialized
INFO - 2017-06-22 17:06:22 --> Security Class Initialized
DEBUG - 2017-06-22 17:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:06:22 --> Input Class Initialized
INFO - 2017-06-22 17:06:22 --> Language Class Initialized
INFO - 2017-06-22 17:06:22 --> Loader Class Initialized
INFO - 2017-06-22 17:06:22 --> Controller Class Initialized
INFO - 2017-06-22 17:06:22 --> Database Driver Class Initialized
INFO - 2017-06-22 17:06:22 --> Model Class Initialized
INFO - 2017-06-22 17:06:22 --> Helper loaded: form_helper
INFO - 2017-06-22 17:06:22 --> Helper loaded: url_helper
INFO - 2017-06-22 17:06:22 --> Model Class Initialized
INFO - 2017-06-22 17:06:22 --> Final output sent to browser
DEBUG - 2017-06-22 17:06:22 --> Total execution time: 0.0550
ERROR - 2017-06-22 17:06:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:06:22 --> Config Class Initialized
INFO - 2017-06-22 17:06:22 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:06:22 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:06:22 --> Utf8 Class Initialized
INFO - 2017-06-22 17:06:22 --> URI Class Initialized
INFO - 2017-06-22 17:06:22 --> Router Class Initialized
INFO - 2017-06-22 17:06:22 --> Output Class Initialized
INFO - 2017-06-22 17:06:22 --> Security Class Initialized
DEBUG - 2017-06-22 17:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:06:22 --> Input Class Initialized
INFO - 2017-06-22 17:06:22 --> Language Class Initialized
INFO - 2017-06-22 17:06:22 --> Loader Class Initialized
INFO - 2017-06-22 17:06:22 --> Controller Class Initialized
INFO - 2017-06-22 17:06:22 --> Database Driver Class Initialized
INFO - 2017-06-22 17:06:22 --> Model Class Initialized
INFO - 2017-06-22 17:06:22 --> Helper loaded: form_helper
INFO - 2017-06-22 17:06:22 --> Helper loaded: url_helper
INFO - 2017-06-22 17:06:22 --> Model Class Initialized
INFO - 2017-06-22 17:06:22 --> Final output sent to browser
DEBUG - 2017-06-22 17:06:22 --> Total execution time: 0.0460
ERROR - 2017-06-22 17:06:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:06:25 --> Config Class Initialized
INFO - 2017-06-22 17:06:25 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:06:25 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:06:25 --> Utf8 Class Initialized
INFO - 2017-06-22 17:06:25 --> URI Class Initialized
INFO - 2017-06-22 17:06:25 --> Router Class Initialized
INFO - 2017-06-22 17:06:25 --> Output Class Initialized
INFO - 2017-06-22 17:06:25 --> Security Class Initialized
DEBUG - 2017-06-22 17:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:06:25 --> Input Class Initialized
INFO - 2017-06-22 17:06:25 --> Language Class Initialized
INFO - 2017-06-22 17:06:25 --> Loader Class Initialized
INFO - 2017-06-22 17:06:25 --> Controller Class Initialized
INFO - 2017-06-22 17:06:25 --> Database Driver Class Initialized
INFO - 2017-06-22 17:06:25 --> Model Class Initialized
INFO - 2017-06-22 17:06:25 --> Helper loaded: form_helper
INFO - 2017-06-22 17:06:25 --> Helper loaded: url_helper
INFO - 2017-06-22 17:06:25 --> Model Class Initialized
INFO - 2017-06-22 17:06:25 --> Final output sent to browser
DEBUG - 2017-06-22 17:06:25 --> Total execution time: 0.0470
ERROR - 2017-06-22 17:06:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:06:32 --> Config Class Initialized
INFO - 2017-06-22 17:06:32 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:06:32 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:06:32 --> Utf8 Class Initialized
INFO - 2017-06-22 17:06:32 --> URI Class Initialized
INFO - 2017-06-22 17:06:32 --> Router Class Initialized
INFO - 2017-06-22 17:06:32 --> Output Class Initialized
INFO - 2017-06-22 17:06:32 --> Security Class Initialized
DEBUG - 2017-06-22 17:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:06:32 --> Input Class Initialized
INFO - 2017-06-22 17:06:32 --> Language Class Initialized
INFO - 2017-06-22 17:06:32 --> Loader Class Initialized
INFO - 2017-06-22 17:06:32 --> Controller Class Initialized
INFO - 2017-06-22 17:06:32 --> Database Driver Class Initialized
INFO - 2017-06-22 17:06:32 --> Model Class Initialized
INFO - 2017-06-22 17:06:32 --> Helper loaded: form_helper
INFO - 2017-06-22 17:06:32 --> Helper loaded: url_helper
INFO - 2017-06-22 17:06:32 --> Model Class Initialized
INFO - 2017-06-22 17:06:32 --> Final output sent to browser
DEBUG - 2017-06-22 17:06:32 --> Total execution time: 0.0470
ERROR - 2017-06-22 17:07:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:07:20 --> Config Class Initialized
INFO - 2017-06-22 17:07:20 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:07:20 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:07:20 --> Utf8 Class Initialized
INFO - 2017-06-22 17:07:20 --> URI Class Initialized
INFO - 2017-06-22 17:07:20 --> Router Class Initialized
INFO - 2017-06-22 17:07:20 --> Output Class Initialized
INFO - 2017-06-22 17:07:20 --> Security Class Initialized
DEBUG - 2017-06-22 17:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:07:20 --> Input Class Initialized
INFO - 2017-06-22 17:07:20 --> Language Class Initialized
INFO - 2017-06-22 17:07:20 --> Loader Class Initialized
INFO - 2017-06-22 17:07:20 --> Controller Class Initialized
INFO - 2017-06-22 17:07:20 --> Database Driver Class Initialized
INFO - 2017-06-22 17:07:20 --> Model Class Initialized
INFO - 2017-06-22 17:07:20 --> Helper loaded: form_helper
INFO - 2017-06-22 17:07:20 --> Helper loaded: url_helper
INFO - 2017-06-22 17:07:20 --> Model Class Initialized
INFO - 2017-06-22 17:07:20 --> Final output sent to browser
DEBUG - 2017-06-22 17:07:20 --> Total execution time: 0.0580
ERROR - 2017-06-22 17:07:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:07:26 --> Config Class Initialized
INFO - 2017-06-22 17:07:26 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:07:26 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:07:26 --> Utf8 Class Initialized
INFO - 2017-06-22 17:07:26 --> URI Class Initialized
INFO - 2017-06-22 17:07:26 --> Router Class Initialized
INFO - 2017-06-22 17:07:26 --> Output Class Initialized
INFO - 2017-06-22 17:07:26 --> Security Class Initialized
DEBUG - 2017-06-22 17:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:07:26 --> Input Class Initialized
INFO - 2017-06-22 17:07:26 --> Language Class Initialized
INFO - 2017-06-22 17:07:26 --> Loader Class Initialized
INFO - 2017-06-22 17:07:26 --> Controller Class Initialized
INFO - 2017-06-22 17:07:26 --> Database Driver Class Initialized
INFO - 2017-06-22 17:07:26 --> Model Class Initialized
INFO - 2017-06-22 17:07:26 --> Helper loaded: form_helper
INFO - 2017-06-22 17:07:26 --> Helper loaded: url_helper
INFO - 2017-06-22 17:07:26 --> Model Class Initialized
INFO - 2017-06-22 17:07:26 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 17:07:26 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 17:07:26 --> Final output sent to browser
DEBUG - 2017-06-22 17:07:26 --> Total execution time: 0.2780
ERROR - 2017-06-22 17:07:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:07:32 --> Config Class Initialized
INFO - 2017-06-22 17:07:32 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:07:32 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:07:32 --> Utf8 Class Initialized
INFO - 2017-06-22 17:07:32 --> URI Class Initialized
INFO - 2017-06-22 17:07:32 --> Router Class Initialized
INFO - 2017-06-22 17:07:32 --> Output Class Initialized
INFO - 2017-06-22 17:07:32 --> Security Class Initialized
DEBUG - 2017-06-22 17:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:07:32 --> Input Class Initialized
INFO - 2017-06-22 17:07:32 --> Language Class Initialized
INFO - 2017-06-22 17:07:32 --> Loader Class Initialized
INFO - 2017-06-22 17:07:32 --> Controller Class Initialized
INFO - 2017-06-22 17:07:32 --> Database Driver Class Initialized
INFO - 2017-06-22 17:07:32 --> Model Class Initialized
INFO - 2017-06-22 17:07:32 --> Helper loaded: form_helper
INFO - 2017-06-22 17:07:32 --> Helper loaded: url_helper
INFO - 2017-06-22 17:07:32 --> Model Class Initialized
INFO - 2017-06-22 17:07:32 --> Final output sent to browser
DEBUG - 2017-06-22 17:07:32 --> Total execution time: 0.0970
ERROR - 2017-06-22 17:07:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:07:33 --> Config Class Initialized
INFO - 2017-06-22 17:07:33 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:07:33 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:07:33 --> Utf8 Class Initialized
INFO - 2017-06-22 17:07:33 --> URI Class Initialized
INFO - 2017-06-22 17:07:33 --> Router Class Initialized
INFO - 2017-06-22 17:07:33 --> Output Class Initialized
INFO - 2017-06-22 17:07:33 --> Security Class Initialized
DEBUG - 2017-06-22 17:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:07:33 --> Input Class Initialized
INFO - 2017-06-22 17:07:33 --> Language Class Initialized
INFO - 2017-06-22 17:07:33 --> Loader Class Initialized
INFO - 2017-06-22 17:07:33 --> Controller Class Initialized
INFO - 2017-06-22 17:07:33 --> Database Driver Class Initialized
INFO - 2017-06-22 17:07:33 --> Model Class Initialized
INFO - 2017-06-22 17:07:33 --> Helper loaded: form_helper
INFO - 2017-06-22 17:07:33 --> Helper loaded: url_helper
INFO - 2017-06-22 17:07:33 --> Model Class Initialized
INFO - 2017-06-22 17:07:33 --> Final output sent to browser
DEBUG - 2017-06-22 17:07:33 --> Total execution time: 0.0490
ERROR - 2017-06-22 17:07:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:07:35 --> Config Class Initialized
INFO - 2017-06-22 17:07:35 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:07:35 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:07:35 --> Utf8 Class Initialized
INFO - 2017-06-22 17:07:35 --> URI Class Initialized
INFO - 2017-06-22 17:07:35 --> Router Class Initialized
INFO - 2017-06-22 17:07:35 --> Output Class Initialized
INFO - 2017-06-22 17:07:35 --> Security Class Initialized
DEBUG - 2017-06-22 17:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:07:35 --> Input Class Initialized
INFO - 2017-06-22 17:07:35 --> Language Class Initialized
INFO - 2017-06-22 17:07:35 --> Loader Class Initialized
INFO - 2017-06-22 17:07:35 --> Controller Class Initialized
INFO - 2017-06-22 17:07:35 --> Database Driver Class Initialized
INFO - 2017-06-22 17:07:35 --> Model Class Initialized
INFO - 2017-06-22 17:07:35 --> Helper loaded: form_helper
INFO - 2017-06-22 17:07:35 --> Helper loaded: url_helper
INFO - 2017-06-22 17:07:35 --> Model Class Initialized
INFO - 2017-06-22 17:07:35 --> Final output sent to browser
DEBUG - 2017-06-22 17:07:35 --> Total execution time: 0.0760
ERROR - 2017-06-22 17:07:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:07:37 --> Config Class Initialized
INFO - 2017-06-22 17:07:37 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:07:37 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:07:37 --> Utf8 Class Initialized
INFO - 2017-06-22 17:07:37 --> URI Class Initialized
INFO - 2017-06-22 17:07:37 --> Router Class Initialized
INFO - 2017-06-22 17:07:37 --> Output Class Initialized
INFO - 2017-06-22 17:07:37 --> Security Class Initialized
DEBUG - 2017-06-22 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:07:37 --> Input Class Initialized
INFO - 2017-06-22 17:07:37 --> Language Class Initialized
INFO - 2017-06-22 17:07:37 --> Loader Class Initialized
INFO - 2017-06-22 17:07:37 --> Controller Class Initialized
INFO - 2017-06-22 17:07:37 --> Database Driver Class Initialized
INFO - 2017-06-22 17:07:37 --> Model Class Initialized
INFO - 2017-06-22 17:07:38 --> Helper loaded: form_helper
INFO - 2017-06-22 17:07:38 --> Helper loaded: url_helper
INFO - 2017-06-22 17:07:38 --> Model Class Initialized
INFO - 2017-06-22 17:07:38 --> Final output sent to browser
DEBUG - 2017-06-22 17:07:38 --> Total execution time: 0.0770
ERROR - 2017-06-22 17:41:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 17:41:21 --> Config Class Initialized
INFO - 2017-06-22 17:41:21 --> Hooks Class Initialized
DEBUG - 2017-06-22 17:41:21 --> UTF-8 Support Enabled
INFO - 2017-06-22 17:41:21 --> Utf8 Class Initialized
INFO - 2017-06-22 17:41:21 --> URI Class Initialized
INFO - 2017-06-22 17:41:21 --> Router Class Initialized
INFO - 2017-06-22 17:41:21 --> Output Class Initialized
INFO - 2017-06-22 17:41:21 --> Security Class Initialized
DEBUG - 2017-06-22 17:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 17:41:21 --> Input Class Initialized
INFO - 2017-06-22 17:41:21 --> Language Class Initialized
INFO - 2017-06-22 17:41:21 --> Loader Class Initialized
INFO - 2017-06-22 17:41:21 --> Controller Class Initialized
INFO - 2017-06-22 17:41:21 --> Database Driver Class Initialized
INFO - 2017-06-22 17:41:21 --> Model Class Initialized
INFO - 2017-06-22 17:41:21 --> Helper loaded: form_helper
INFO - 2017-06-22 17:41:21 --> Helper loaded: url_helper
INFO - 2017-06-22 17:41:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 17:41:21 --> Model Class Initialized
INFO - 2017-06-22 17:41:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-06-22 17:41:21 --> Final output sent to browser
DEBUG - 2017-06-22 17:41:21 --> Total execution time: 0.1270
ERROR - 2017-06-22 19:25:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:25:35 --> Config Class Initialized
INFO - 2017-06-22 19:25:35 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:25:35 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:25:35 --> Utf8 Class Initialized
INFO - 2017-06-22 19:25:35 --> URI Class Initialized
INFO - 2017-06-22 19:25:35 --> Router Class Initialized
INFO - 2017-06-22 19:25:35 --> Output Class Initialized
INFO - 2017-06-22 19:25:35 --> Security Class Initialized
DEBUG - 2017-06-22 19:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:25:35 --> Input Class Initialized
INFO - 2017-06-22 19:25:35 --> Language Class Initialized
INFO - 2017-06-22 19:25:35 --> Loader Class Initialized
INFO - 2017-06-22 19:25:35 --> Controller Class Initialized
INFO - 2017-06-22 19:25:35 --> Database Driver Class Initialized
INFO - 2017-06-22 19:25:35 --> Model Class Initialized
INFO - 2017-06-22 19:25:35 --> Helper loaded: form_helper
INFO - 2017-06-22 19:25:35 --> Helper loaded: url_helper
INFO - 2017-06-22 19:25:35 --> Model Class Initialized
INFO - 2017-06-22 19:25:35 --> Final output sent to browser
DEBUG - 2017-06-22 19:25:35 --> Total execution time: 0.0660
ERROR - 2017-06-22 19:25:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:25:36 --> Config Class Initialized
INFO - 2017-06-22 19:25:36 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:25:36 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:25:36 --> Utf8 Class Initialized
INFO - 2017-06-22 19:25:36 --> URI Class Initialized
INFO - 2017-06-22 19:25:36 --> Router Class Initialized
INFO - 2017-06-22 19:25:36 --> Output Class Initialized
INFO - 2017-06-22 19:25:36 --> Security Class Initialized
DEBUG - 2017-06-22 19:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:25:36 --> Input Class Initialized
INFO - 2017-06-22 19:25:36 --> Language Class Initialized
INFO - 2017-06-22 19:25:36 --> Loader Class Initialized
INFO - 2017-06-22 19:25:36 --> Controller Class Initialized
INFO - 2017-06-22 19:25:36 --> Database Driver Class Initialized
INFO - 2017-06-22 19:25:36 --> Model Class Initialized
INFO - 2017-06-22 19:25:36 --> Helper loaded: form_helper
INFO - 2017-06-22 19:25:36 --> Helper loaded: url_helper
INFO - 2017-06-22 19:25:36 --> Model Class Initialized
INFO - 2017-06-22 19:25:36 --> Final output sent to browser
DEBUG - 2017-06-22 19:25:36 --> Total execution time: 0.0450
ERROR - 2017-06-22 19:25:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:25:47 --> Config Class Initialized
INFO - 2017-06-22 19:25:47 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:25:47 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:25:47 --> Utf8 Class Initialized
INFO - 2017-06-22 19:25:47 --> URI Class Initialized
INFO - 2017-06-22 19:25:47 --> Router Class Initialized
INFO - 2017-06-22 19:25:47 --> Output Class Initialized
INFO - 2017-06-22 19:25:47 --> Security Class Initialized
DEBUG - 2017-06-22 19:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:25:47 --> Input Class Initialized
INFO - 2017-06-22 19:25:47 --> Language Class Initialized
INFO - 2017-06-22 19:25:47 --> Loader Class Initialized
INFO - 2017-06-22 19:25:47 --> Controller Class Initialized
INFO - 2017-06-22 19:25:47 --> Database Driver Class Initialized
INFO - 2017-06-22 19:25:47 --> Model Class Initialized
INFO - 2017-06-22 19:25:47 --> Helper loaded: form_helper
INFO - 2017-06-22 19:25:47 --> Helper loaded: url_helper
INFO - 2017-06-22 19:25:47 --> Model Class Initialized
INFO - 2017-06-22 19:25:47 --> Final output sent to browser
DEBUG - 2017-06-22 19:25:47 --> Total execution time: 0.0610
ERROR - 2017-06-22 19:25:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:25:50 --> Config Class Initialized
INFO - 2017-06-22 19:25:50 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:25:50 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:25:50 --> Utf8 Class Initialized
INFO - 2017-06-22 19:25:50 --> URI Class Initialized
INFO - 2017-06-22 19:25:50 --> Router Class Initialized
INFO - 2017-06-22 19:25:50 --> Output Class Initialized
INFO - 2017-06-22 19:25:50 --> Security Class Initialized
DEBUG - 2017-06-22 19:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:25:50 --> Input Class Initialized
INFO - 2017-06-22 19:25:50 --> Language Class Initialized
INFO - 2017-06-22 19:25:50 --> Loader Class Initialized
INFO - 2017-06-22 19:25:50 --> Controller Class Initialized
INFO - 2017-06-22 19:25:50 --> Database Driver Class Initialized
INFO - 2017-06-22 19:25:50 --> Model Class Initialized
INFO - 2017-06-22 19:25:50 --> Helper loaded: form_helper
INFO - 2017-06-22 19:25:50 --> Helper loaded: url_helper
INFO - 2017-06-22 19:25:50 --> Model Class Initialized
INFO - 2017-06-22 19:25:50 --> Final output sent to browser
DEBUG - 2017-06-22 19:25:50 --> Total execution time: 0.0490
ERROR - 2017-06-22 19:26:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:26:55 --> Config Class Initialized
INFO - 2017-06-22 19:26:55 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:26:55 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:26:55 --> Utf8 Class Initialized
INFO - 2017-06-22 19:26:55 --> URI Class Initialized
INFO - 2017-06-22 19:26:55 --> Router Class Initialized
INFO - 2017-06-22 19:26:55 --> Output Class Initialized
INFO - 2017-06-22 19:26:55 --> Security Class Initialized
DEBUG - 2017-06-22 19:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:26:55 --> Input Class Initialized
INFO - 2017-06-22 19:26:55 --> Language Class Initialized
INFO - 2017-06-22 19:26:55 --> Loader Class Initialized
INFO - 2017-06-22 19:26:55 --> Controller Class Initialized
INFO - 2017-06-22 19:26:55 --> Database Driver Class Initialized
INFO - 2017-06-22 19:26:55 --> Model Class Initialized
INFO - 2017-06-22 19:26:55 --> Helper loaded: form_helper
INFO - 2017-06-22 19:26:55 --> Helper loaded: url_helper
INFO - 2017-06-22 19:26:55 --> Model Class Initialized
INFO - 2017-06-22 19:26:55 --> Final output sent to browser
DEBUG - 2017-06-22 19:26:55 --> Total execution time: 0.0470
ERROR - 2017-06-22 19:27:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:27:34 --> Config Class Initialized
INFO - 2017-06-22 19:27:34 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:27:34 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:27:34 --> Utf8 Class Initialized
INFO - 2017-06-22 19:27:34 --> URI Class Initialized
INFO - 2017-06-22 19:27:34 --> Router Class Initialized
INFO - 2017-06-22 19:27:34 --> Output Class Initialized
INFO - 2017-06-22 19:27:34 --> Security Class Initialized
DEBUG - 2017-06-22 19:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:27:34 --> Input Class Initialized
INFO - 2017-06-22 19:27:34 --> Language Class Initialized
INFO - 2017-06-22 19:27:34 --> Loader Class Initialized
INFO - 2017-06-22 19:27:34 --> Controller Class Initialized
INFO - 2017-06-22 19:27:34 --> Database Driver Class Initialized
INFO - 2017-06-22 19:27:34 --> Model Class Initialized
INFO - 2017-06-22 19:27:34 --> Helper loaded: form_helper
INFO - 2017-06-22 19:27:34 --> Helper loaded: url_helper
INFO - 2017-06-22 19:27:34 --> Model Class Initialized
INFO - 2017-06-22 19:27:34 --> Final output sent to browser
DEBUG - 2017-06-22 19:27:34 --> Total execution time: 0.0480
ERROR - 2017-06-22 19:27:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:27:50 --> Config Class Initialized
INFO - 2017-06-22 19:27:50 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:27:50 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:27:50 --> Utf8 Class Initialized
INFO - 2017-06-22 19:27:50 --> URI Class Initialized
INFO - 2017-06-22 19:27:50 --> Router Class Initialized
INFO - 2017-06-22 19:27:50 --> Output Class Initialized
INFO - 2017-06-22 19:27:50 --> Security Class Initialized
DEBUG - 2017-06-22 19:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:27:50 --> Input Class Initialized
INFO - 2017-06-22 19:27:50 --> Language Class Initialized
INFO - 2017-06-22 19:27:50 --> Loader Class Initialized
INFO - 2017-06-22 19:27:50 --> Controller Class Initialized
INFO - 2017-06-22 19:27:50 --> Database Driver Class Initialized
INFO - 2017-06-22 19:27:50 --> Model Class Initialized
INFO - 2017-06-22 19:27:50 --> Helper loaded: form_helper
INFO - 2017-06-22 19:27:50 --> Helper loaded: url_helper
INFO - 2017-06-22 19:27:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 19:27:50 --> Model Class Initialized
INFO - 2017-06-22 19:27:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 19:27:50 --> Final output sent to browser
DEBUG - 2017-06-22 19:27:50 --> Total execution time: 0.0480
ERROR - 2017-06-22 19:27:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:27:53 --> Config Class Initialized
INFO - 2017-06-22 19:27:53 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:27:53 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:27:53 --> Utf8 Class Initialized
INFO - 2017-06-22 19:27:53 --> URI Class Initialized
INFO - 2017-06-22 19:27:53 --> Router Class Initialized
INFO - 2017-06-22 19:27:54 --> Output Class Initialized
INFO - 2017-06-22 19:27:54 --> Security Class Initialized
DEBUG - 2017-06-22 19:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:27:54 --> Input Class Initialized
INFO - 2017-06-22 19:27:54 --> Language Class Initialized
INFO - 2017-06-22 19:27:54 --> Loader Class Initialized
INFO - 2017-06-22 19:27:54 --> Controller Class Initialized
INFO - 2017-06-22 19:27:54 --> Database Driver Class Initialized
INFO - 2017-06-22 19:27:54 --> Model Class Initialized
INFO - 2017-06-22 19:27:54 --> Helper loaded: form_helper
INFO - 2017-06-22 19:27:54 --> Helper loaded: url_helper
INFO - 2017-06-22 19:27:54 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 19:27:54 --> Model Class Initialized
INFO - 2017-06-22 19:27:54 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 19:27:54 --> Final output sent to browser
DEBUG - 2017-06-22 19:27:54 --> Total execution time: 0.0845
ERROR - 2017-06-22 19:28:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:28:01 --> Config Class Initialized
INFO - 2017-06-22 19:28:01 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:28:01 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:28:01 --> Utf8 Class Initialized
INFO - 2017-06-22 19:28:01 --> URI Class Initialized
INFO - 2017-06-22 19:28:03 --> Router Class Initialized
INFO - 2017-06-22 19:28:03 --> Output Class Initialized
INFO - 2017-06-22 19:28:03 --> Security Class Initialized
DEBUG - 2017-06-22 19:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:28:03 --> Input Class Initialized
INFO - 2017-06-22 19:28:03 --> Language Class Initialized
INFO - 2017-06-22 19:28:03 --> Loader Class Initialized
INFO - 2017-06-22 19:28:03 --> Controller Class Initialized
INFO - 2017-06-22 19:28:03 --> Database Driver Class Initialized
INFO - 2017-06-22 19:28:03 --> Model Class Initialized
INFO - 2017-06-22 19:28:03 --> Helper loaded: form_helper
INFO - 2017-06-22 19:28:03 --> Helper loaded: url_helper
INFO - 2017-06-22 19:28:03 --> Model Class Initialized
INFO - 2017-06-22 19:28:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 19:28:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 19:28:03 --> Final output sent to browser
DEBUG - 2017-06-22 19:28:03 --> Total execution time: 1.9081
ERROR - 2017-06-22 19:28:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:28:17 --> Config Class Initialized
INFO - 2017-06-22 19:28:17 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:28:17 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:28:17 --> Utf8 Class Initialized
INFO - 2017-06-22 19:28:17 --> URI Class Initialized
INFO - 2017-06-22 19:28:17 --> Router Class Initialized
INFO - 2017-06-22 19:28:17 --> Output Class Initialized
INFO - 2017-06-22 19:28:17 --> Security Class Initialized
DEBUG - 2017-06-22 19:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:28:17 --> Input Class Initialized
INFO - 2017-06-22 19:28:17 --> Language Class Initialized
INFO - 2017-06-22 19:28:17 --> Loader Class Initialized
INFO - 2017-06-22 19:28:17 --> Controller Class Initialized
INFO - 2017-06-22 19:28:17 --> Database Driver Class Initialized
INFO - 2017-06-22 19:28:17 --> Model Class Initialized
INFO - 2017-06-22 19:28:17 --> Helper loaded: form_helper
INFO - 2017-06-22 19:28:17 --> Helper loaded: url_helper
INFO - 2017-06-22 19:28:17 --> Model Class Initialized
INFO - 2017-06-22 19:28:17 --> Final output sent to browser
DEBUG - 2017-06-22 19:28:17 --> Total execution time: 0.0550
ERROR - 2017-06-22 19:28:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:28:39 --> Config Class Initialized
INFO - 2017-06-22 19:28:39 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:28:39 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:28:39 --> Utf8 Class Initialized
INFO - 2017-06-22 19:28:39 --> URI Class Initialized
INFO - 2017-06-22 19:28:39 --> Router Class Initialized
INFO - 2017-06-22 19:28:39 --> Output Class Initialized
INFO - 2017-06-22 19:28:39 --> Security Class Initialized
DEBUG - 2017-06-22 19:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:28:39 --> Input Class Initialized
INFO - 2017-06-22 19:28:39 --> Language Class Initialized
INFO - 2017-06-22 19:28:39 --> Loader Class Initialized
INFO - 2017-06-22 19:28:39 --> Controller Class Initialized
INFO - 2017-06-22 19:28:39 --> Database Driver Class Initialized
INFO - 2017-06-22 19:28:39 --> Model Class Initialized
INFO - 2017-06-22 19:28:39 --> Helper loaded: form_helper
INFO - 2017-06-22 19:28:39 --> Helper loaded: url_helper
INFO - 2017-06-22 19:28:39 --> Model Class Initialized
INFO - 2017-06-22 19:28:39 --> Final output sent to browser
DEBUG - 2017-06-22 19:28:39 --> Total execution time: 0.0460
ERROR - 2017-06-22 19:28:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:28:45 --> Config Class Initialized
INFO - 2017-06-22 19:28:45 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:28:45 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:28:45 --> Utf8 Class Initialized
INFO - 2017-06-22 19:28:45 --> URI Class Initialized
INFO - 2017-06-22 19:28:45 --> Router Class Initialized
INFO - 2017-06-22 19:28:45 --> Output Class Initialized
INFO - 2017-06-22 19:28:45 --> Security Class Initialized
DEBUG - 2017-06-22 19:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:28:45 --> Input Class Initialized
INFO - 2017-06-22 19:28:45 --> Language Class Initialized
INFO - 2017-06-22 19:28:45 --> Loader Class Initialized
INFO - 2017-06-22 19:28:45 --> Controller Class Initialized
INFO - 2017-06-22 19:28:45 --> Database Driver Class Initialized
INFO - 2017-06-22 19:28:45 --> Model Class Initialized
INFO - 2017-06-22 19:28:45 --> Helper loaded: form_helper
INFO - 2017-06-22 19:28:45 --> Helper loaded: url_helper
INFO - 2017-06-22 19:28:45 --> Model Class Initialized
INFO - 2017-06-22 19:28:45 --> Final output sent to browser
DEBUG - 2017-06-22 19:28:45 --> Total execution time: 0.0480
ERROR - 2017-06-22 19:28:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:28:45 --> Config Class Initialized
INFO - 2017-06-22 19:28:45 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:28:45 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:28:45 --> Utf8 Class Initialized
INFO - 2017-06-22 19:28:45 --> URI Class Initialized
INFO - 2017-06-22 19:28:45 --> Router Class Initialized
INFO - 2017-06-22 19:28:45 --> Output Class Initialized
INFO - 2017-06-22 19:28:45 --> Security Class Initialized
DEBUG - 2017-06-22 19:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:28:45 --> Input Class Initialized
INFO - 2017-06-22 19:28:45 --> Language Class Initialized
INFO - 2017-06-22 19:28:45 --> Loader Class Initialized
INFO - 2017-06-22 19:28:45 --> Controller Class Initialized
INFO - 2017-06-22 19:28:45 --> Database Driver Class Initialized
INFO - 2017-06-22 19:28:45 --> Model Class Initialized
INFO - 2017-06-22 19:28:45 --> Helper loaded: form_helper
INFO - 2017-06-22 19:28:45 --> Helper loaded: url_helper
INFO - 2017-06-22 19:28:45 --> Model Class Initialized
INFO - 2017-06-22 19:28:45 --> Final output sent to browser
DEBUG - 2017-06-22 19:28:45 --> Total execution time: 0.0450
ERROR - 2017-06-22 19:30:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:30:09 --> Config Class Initialized
INFO - 2017-06-22 19:30:09 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:30:09 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:30:09 --> Utf8 Class Initialized
INFO - 2017-06-22 19:30:09 --> URI Class Initialized
INFO - 2017-06-22 19:30:09 --> Router Class Initialized
INFO - 2017-06-22 19:30:09 --> Output Class Initialized
INFO - 2017-06-22 19:30:09 --> Security Class Initialized
DEBUG - 2017-06-22 19:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:30:09 --> Input Class Initialized
INFO - 2017-06-22 19:30:09 --> Language Class Initialized
INFO - 2017-06-22 19:30:09 --> Loader Class Initialized
INFO - 2017-06-22 19:30:09 --> Controller Class Initialized
INFO - 2017-06-22 19:30:09 --> Database Driver Class Initialized
INFO - 2017-06-22 19:30:09 --> Model Class Initialized
INFO - 2017-06-22 19:30:09 --> Helper loaded: form_helper
INFO - 2017-06-22 19:30:09 --> Helper loaded: url_helper
INFO - 2017-06-22 19:30:09 --> Model Class Initialized
INFO - 2017-06-22 19:30:09 --> Final output sent to browser
DEBUG - 2017-06-22 19:30:09 --> Total execution time: 0.0580
ERROR - 2017-06-22 19:33:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:33:58 --> Config Class Initialized
INFO - 2017-06-22 19:33:58 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:33:58 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:33:58 --> Utf8 Class Initialized
INFO - 2017-06-22 19:33:58 --> URI Class Initialized
INFO - 2017-06-22 19:33:58 --> Router Class Initialized
INFO - 2017-06-22 19:33:58 --> Output Class Initialized
INFO - 2017-06-22 19:33:58 --> Security Class Initialized
DEBUG - 2017-06-22 19:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:33:58 --> Input Class Initialized
INFO - 2017-06-22 19:33:58 --> Language Class Initialized
INFO - 2017-06-22 19:33:58 --> Loader Class Initialized
INFO - 2017-06-22 19:33:58 --> Controller Class Initialized
INFO - 2017-06-22 19:33:58 --> Database Driver Class Initialized
INFO - 2017-06-22 19:33:58 --> Model Class Initialized
INFO - 2017-06-22 19:33:58 --> Helper loaded: form_helper
INFO - 2017-06-22 19:33:58 --> Helper loaded: url_helper
INFO - 2017-06-22 19:33:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 19:33:58 --> Model Class Initialized
INFO - 2017-06-22 19:33:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 19:33:58 --> Final output sent to browser
DEBUG - 2017-06-22 19:33:58 --> Total execution time: 0.0630
ERROR - 2017-06-22 19:34:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:34:00 --> Config Class Initialized
INFO - 2017-06-22 19:34:00 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:34:00 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:34:00 --> Utf8 Class Initialized
INFO - 2017-06-22 19:34:00 --> URI Class Initialized
INFO - 2017-06-22 19:34:00 --> Router Class Initialized
INFO - 2017-06-22 19:34:00 --> Output Class Initialized
INFO - 2017-06-22 19:34:00 --> Security Class Initialized
DEBUG - 2017-06-22 19:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:34:00 --> Input Class Initialized
INFO - 2017-06-22 19:34:00 --> Language Class Initialized
INFO - 2017-06-22 19:34:00 --> Loader Class Initialized
INFO - 2017-06-22 19:34:00 --> Controller Class Initialized
INFO - 2017-06-22 19:34:00 --> Database Driver Class Initialized
INFO - 2017-06-22 19:34:00 --> Model Class Initialized
INFO - 2017-06-22 19:34:00 --> Helper loaded: form_helper
INFO - 2017-06-22 19:34:00 --> Helper loaded: url_helper
INFO - 2017-06-22 19:34:00 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 19:34:00 --> Model Class Initialized
INFO - 2017-06-22 19:34:00 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 19:34:00 --> Final output sent to browser
DEBUG - 2017-06-22 19:34:00 --> Total execution time: 0.0480
ERROR - 2017-06-22 19:34:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:34:06 --> Config Class Initialized
INFO - 2017-06-22 19:34:06 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:34:06 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:34:06 --> Utf8 Class Initialized
INFO - 2017-06-22 19:34:06 --> URI Class Initialized
INFO - 2017-06-22 19:34:06 --> Router Class Initialized
INFO - 2017-06-22 19:34:06 --> Output Class Initialized
INFO - 2017-06-22 19:34:06 --> Security Class Initialized
DEBUG - 2017-06-22 19:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:34:06 --> Input Class Initialized
INFO - 2017-06-22 19:34:06 --> Language Class Initialized
INFO - 2017-06-22 19:34:06 --> Loader Class Initialized
INFO - 2017-06-22 19:34:06 --> Controller Class Initialized
INFO - 2017-06-22 19:34:06 --> Database Driver Class Initialized
INFO - 2017-06-22 19:34:06 --> Model Class Initialized
INFO - 2017-06-22 19:34:06 --> Helper loaded: form_helper
INFO - 2017-06-22 19:34:06 --> Helper loaded: url_helper
INFO - 2017-06-22 19:34:06 --> Model Class Initialized
INFO - 2017-06-22 19:34:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 19:34:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 19:34:06 --> Final output sent to browser
DEBUG - 2017-06-22 19:34:06 --> Total execution time: 0.0780
ERROR - 2017-06-22 19:34:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:34:07 --> Config Class Initialized
INFO - 2017-06-22 19:34:07 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:34:07 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:34:07 --> Utf8 Class Initialized
INFO - 2017-06-22 19:34:07 --> URI Class Initialized
INFO - 2017-06-22 19:34:07 --> Router Class Initialized
INFO - 2017-06-22 19:34:07 --> Output Class Initialized
INFO - 2017-06-22 19:34:07 --> Security Class Initialized
DEBUG - 2017-06-22 19:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:34:07 --> Input Class Initialized
INFO - 2017-06-22 19:34:07 --> Language Class Initialized
INFO - 2017-06-22 19:34:07 --> Loader Class Initialized
INFO - 2017-06-22 19:34:07 --> Controller Class Initialized
INFO - 2017-06-22 19:34:08 --> Database Driver Class Initialized
INFO - 2017-06-22 19:34:08 --> Model Class Initialized
INFO - 2017-06-22 19:34:08 --> Helper loaded: form_helper
INFO - 2017-06-22 19:34:08 --> Helper loaded: url_helper
INFO - 2017-06-22 19:34:08 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 19:34:08 --> Model Class Initialized
INFO - 2017-06-22 19:34:08 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 19:34:08 --> Final output sent to browser
DEBUG - 2017-06-22 19:34:08 --> Total execution time: 0.0730
ERROR - 2017-06-22 19:34:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:34:09 --> Config Class Initialized
INFO - 2017-06-22 19:34:09 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:34:09 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:34:09 --> Utf8 Class Initialized
INFO - 2017-06-22 19:34:09 --> URI Class Initialized
INFO - 2017-06-22 19:34:09 --> Router Class Initialized
INFO - 2017-06-22 19:34:09 --> Output Class Initialized
INFO - 2017-06-22 19:34:09 --> Security Class Initialized
DEBUG - 2017-06-22 19:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:34:09 --> Input Class Initialized
INFO - 2017-06-22 19:34:09 --> Language Class Initialized
INFO - 2017-06-22 19:34:09 --> Loader Class Initialized
INFO - 2017-06-22 19:34:09 --> Controller Class Initialized
INFO - 2017-06-22 19:34:09 --> Database Driver Class Initialized
INFO - 2017-06-22 19:34:09 --> Model Class Initialized
INFO - 2017-06-22 19:34:09 --> Helper loaded: form_helper
INFO - 2017-06-22 19:34:09 --> Helper loaded: url_helper
INFO - 2017-06-22 19:34:09 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 19:34:09 --> Model Class Initialized
INFO - 2017-06-22 19:34:09 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 19:34:09 --> Final output sent to browser
DEBUG - 2017-06-22 19:34:09 --> Total execution time: 0.0640
ERROR - 2017-06-22 19:40:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:40:00 --> Config Class Initialized
INFO - 2017-06-22 19:40:00 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:40:00 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:40:00 --> Utf8 Class Initialized
INFO - 2017-06-22 19:40:00 --> URI Class Initialized
INFO - 2017-06-22 19:40:00 --> Router Class Initialized
INFO - 2017-06-22 19:40:00 --> Output Class Initialized
INFO - 2017-06-22 19:40:00 --> Security Class Initialized
DEBUG - 2017-06-22 19:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:40:00 --> Input Class Initialized
INFO - 2017-06-22 19:40:00 --> Language Class Initialized
INFO - 2017-06-22 19:40:00 --> Loader Class Initialized
INFO - 2017-06-22 19:40:00 --> Controller Class Initialized
INFO - 2017-06-22 19:40:00 --> Database Driver Class Initialized
INFO - 2017-06-22 19:40:00 --> Model Class Initialized
INFO - 2017-06-22 19:40:00 --> Helper loaded: form_helper
INFO - 2017-06-22 19:40:00 --> Helper loaded: url_helper
INFO - 2017-06-22 19:40:00 --> Model Class Initialized
INFO - 2017-06-22 19:40:00 --> Final output sent to browser
DEBUG - 2017-06-22 19:40:00 --> Total execution time: 0.0510
ERROR - 2017-06-22 19:42:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:42:08 --> Config Class Initialized
INFO - 2017-06-22 19:42:08 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:42:08 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:42:08 --> Utf8 Class Initialized
INFO - 2017-06-22 19:42:08 --> URI Class Initialized
INFO - 2017-06-22 19:42:08 --> Router Class Initialized
INFO - 2017-06-22 19:42:08 --> Output Class Initialized
INFO - 2017-06-22 19:42:08 --> Security Class Initialized
DEBUG - 2017-06-22 19:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:42:08 --> Input Class Initialized
INFO - 2017-06-22 19:42:08 --> Language Class Initialized
INFO - 2017-06-22 19:42:08 --> Loader Class Initialized
INFO - 2017-06-22 19:42:08 --> Controller Class Initialized
INFO - 2017-06-22 19:42:08 --> Database Driver Class Initialized
INFO - 2017-06-22 19:42:08 --> Model Class Initialized
INFO - 2017-06-22 19:42:08 --> Helper loaded: form_helper
INFO - 2017-06-22 19:42:08 --> Helper loaded: url_helper
INFO - 2017-06-22 19:42:08 --> Model Class Initialized
INFO - 2017-06-22 19:42:08 --> Final output sent to browser
DEBUG - 2017-06-22 19:42:08 --> Total execution time: 0.1230
ERROR - 2017-06-22 19:42:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:42:09 --> Config Class Initialized
INFO - 2017-06-22 19:42:09 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:42:09 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:42:09 --> Utf8 Class Initialized
INFO - 2017-06-22 19:42:09 --> URI Class Initialized
INFO - 2017-06-22 19:42:09 --> Router Class Initialized
INFO - 2017-06-22 19:42:09 --> Output Class Initialized
INFO - 2017-06-22 19:42:09 --> Security Class Initialized
DEBUG - 2017-06-22 19:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:42:09 --> Input Class Initialized
INFO - 2017-06-22 19:42:09 --> Language Class Initialized
INFO - 2017-06-22 19:42:09 --> Loader Class Initialized
INFO - 2017-06-22 19:42:09 --> Controller Class Initialized
INFO - 2017-06-22 19:42:09 --> Database Driver Class Initialized
INFO - 2017-06-22 19:42:09 --> Model Class Initialized
INFO - 2017-06-22 19:42:09 --> Helper loaded: form_helper
INFO - 2017-06-22 19:42:09 --> Helper loaded: url_helper
INFO - 2017-06-22 19:42:09 --> Model Class Initialized
INFO - 2017-06-22 19:42:09 --> Final output sent to browser
DEBUG - 2017-06-22 19:42:09 --> Total execution time: 0.0670
ERROR - 2017-06-22 19:48:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:48:20 --> Config Class Initialized
INFO - 2017-06-22 19:48:20 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:48:20 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:48:20 --> Utf8 Class Initialized
INFO - 2017-06-22 19:48:20 --> URI Class Initialized
INFO - 2017-06-22 19:48:20 --> Router Class Initialized
INFO - 2017-06-22 19:48:20 --> Output Class Initialized
INFO - 2017-06-22 19:48:20 --> Security Class Initialized
DEBUG - 2017-06-22 19:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:48:20 --> Input Class Initialized
INFO - 2017-06-22 19:48:20 --> Language Class Initialized
INFO - 2017-06-22 19:48:20 --> Loader Class Initialized
INFO - 2017-06-22 19:48:20 --> Controller Class Initialized
INFO - 2017-06-22 19:48:20 --> Database Driver Class Initialized
INFO - 2017-06-22 19:48:20 --> Model Class Initialized
INFO - 2017-06-22 19:48:20 --> Helper loaded: form_helper
INFO - 2017-06-22 19:48:20 --> Helper loaded: url_helper
INFO - 2017-06-22 19:48:20 --> Model Class Initialized
INFO - 2017-06-22 19:48:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 19:48:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 19:48:20 --> Final output sent to browser
DEBUG - 2017-06-22 19:48:20 --> Total execution time: 0.0770
ERROR - 2017-06-22 19:48:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:48:23 --> Config Class Initialized
INFO - 2017-06-22 19:48:23 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:48:23 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:48:23 --> Utf8 Class Initialized
INFO - 2017-06-22 19:48:23 --> URI Class Initialized
INFO - 2017-06-22 19:48:23 --> Router Class Initialized
INFO - 2017-06-22 19:48:23 --> Output Class Initialized
INFO - 2017-06-22 19:48:23 --> Security Class Initialized
DEBUG - 2017-06-22 19:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:48:23 --> Input Class Initialized
INFO - 2017-06-22 19:48:23 --> Language Class Initialized
INFO - 2017-06-22 19:48:23 --> Loader Class Initialized
INFO - 2017-06-22 19:48:23 --> Controller Class Initialized
INFO - 2017-06-22 19:48:23 --> Database Driver Class Initialized
INFO - 2017-06-22 19:48:23 --> Model Class Initialized
INFO - 2017-06-22 19:48:23 --> Helper loaded: form_helper
INFO - 2017-06-22 19:48:23 --> Helper loaded: url_helper
INFO - 2017-06-22 19:48:23 --> Model Class Initialized
INFO - 2017-06-22 19:48:23 --> Final output sent to browser
DEBUG - 2017-06-22 19:48:23 --> Total execution time: 0.0470
ERROR - 2017-06-22 19:48:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:48:25 --> Config Class Initialized
INFO - 2017-06-22 19:48:25 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:48:25 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:48:25 --> Utf8 Class Initialized
INFO - 2017-06-22 19:48:25 --> URI Class Initialized
INFO - 2017-06-22 19:48:25 --> Router Class Initialized
INFO - 2017-06-22 19:48:25 --> Output Class Initialized
INFO - 2017-06-22 19:48:25 --> Security Class Initialized
DEBUG - 2017-06-22 19:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:48:25 --> Input Class Initialized
INFO - 2017-06-22 19:48:25 --> Language Class Initialized
INFO - 2017-06-22 19:48:25 --> Loader Class Initialized
INFO - 2017-06-22 19:48:25 --> Controller Class Initialized
INFO - 2017-06-22 19:48:25 --> Database Driver Class Initialized
INFO - 2017-06-22 19:48:25 --> Model Class Initialized
INFO - 2017-06-22 19:48:25 --> Helper loaded: form_helper
INFO - 2017-06-22 19:48:25 --> Helper loaded: url_helper
INFO - 2017-06-22 19:48:25 --> Model Class Initialized
INFO - 2017-06-22 19:48:25 --> Final output sent to browser
DEBUG - 2017-06-22 19:48:25 --> Total execution time: 0.0510
ERROR - 2017-06-22 19:48:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:48:28 --> Config Class Initialized
INFO - 2017-06-22 19:48:28 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:48:28 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:48:28 --> Utf8 Class Initialized
INFO - 2017-06-22 19:48:28 --> URI Class Initialized
INFO - 2017-06-22 19:48:28 --> Router Class Initialized
INFO - 2017-06-22 19:48:28 --> Output Class Initialized
INFO - 2017-06-22 19:48:28 --> Security Class Initialized
DEBUG - 2017-06-22 19:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:48:28 --> Input Class Initialized
INFO - 2017-06-22 19:48:28 --> Language Class Initialized
INFO - 2017-06-22 19:48:28 --> Loader Class Initialized
INFO - 2017-06-22 19:48:28 --> Controller Class Initialized
INFO - 2017-06-22 19:48:28 --> Database Driver Class Initialized
INFO - 2017-06-22 19:48:28 --> Model Class Initialized
INFO - 2017-06-22 19:48:28 --> Helper loaded: form_helper
INFO - 2017-06-22 19:48:28 --> Helper loaded: url_helper
INFO - 2017-06-22 19:48:28 --> Model Class Initialized
INFO - 2017-06-22 19:48:28 --> Final output sent to browser
DEBUG - 2017-06-22 19:48:28 --> Total execution time: 0.0470
ERROR - 2017-06-22 19:52:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:52:16 --> Config Class Initialized
INFO - 2017-06-22 19:52:16 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:52:16 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:52:16 --> Utf8 Class Initialized
INFO - 2017-06-22 19:52:16 --> URI Class Initialized
INFO - 2017-06-22 19:52:16 --> Router Class Initialized
INFO - 2017-06-22 19:52:16 --> Output Class Initialized
INFO - 2017-06-22 19:52:16 --> Security Class Initialized
DEBUG - 2017-06-22 19:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:52:16 --> Input Class Initialized
INFO - 2017-06-22 19:52:16 --> Language Class Initialized
INFO - 2017-06-22 19:52:16 --> Loader Class Initialized
INFO - 2017-06-22 19:52:16 --> Controller Class Initialized
INFO - 2017-06-22 19:52:16 --> Database Driver Class Initialized
INFO - 2017-06-22 19:52:16 --> Model Class Initialized
INFO - 2017-06-22 19:52:16 --> Helper loaded: form_helper
INFO - 2017-06-22 19:52:16 --> Helper loaded: url_helper
INFO - 2017-06-22 19:52:16 --> Model Class Initialized
INFO - 2017-06-22 19:52:16 --> Final output sent to browser
DEBUG - 2017-06-22 19:52:16 --> Total execution time: 0.0570
ERROR - 2017-06-22 19:52:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:52:18 --> Config Class Initialized
INFO - 2017-06-22 19:52:18 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:52:18 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:52:18 --> Utf8 Class Initialized
INFO - 2017-06-22 19:52:18 --> URI Class Initialized
INFO - 2017-06-22 19:52:18 --> Router Class Initialized
INFO - 2017-06-22 19:52:18 --> Output Class Initialized
INFO - 2017-06-22 19:52:18 --> Security Class Initialized
DEBUG - 2017-06-22 19:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:52:18 --> Input Class Initialized
INFO - 2017-06-22 19:52:18 --> Language Class Initialized
INFO - 2017-06-22 19:52:18 --> Loader Class Initialized
INFO - 2017-06-22 19:52:18 --> Controller Class Initialized
INFO - 2017-06-22 19:52:18 --> Database Driver Class Initialized
INFO - 2017-06-22 19:52:18 --> Model Class Initialized
INFO - 2017-06-22 19:52:18 --> Helper loaded: form_helper
INFO - 2017-06-22 19:52:18 --> Helper loaded: url_helper
INFO - 2017-06-22 19:52:18 --> Model Class Initialized
INFO - 2017-06-22 19:52:18 --> Final output sent to browser
DEBUG - 2017-06-22 19:52:18 --> Total execution time: 0.0865
ERROR - 2017-06-22 19:52:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:52:56 --> Config Class Initialized
INFO - 2017-06-22 19:52:56 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:52:56 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:52:56 --> Utf8 Class Initialized
INFO - 2017-06-22 19:52:56 --> URI Class Initialized
INFO - 2017-06-22 19:52:56 --> Router Class Initialized
INFO - 2017-06-22 19:52:56 --> Output Class Initialized
INFO - 2017-06-22 19:52:56 --> Security Class Initialized
DEBUG - 2017-06-22 19:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:52:56 --> Input Class Initialized
INFO - 2017-06-22 19:52:56 --> Language Class Initialized
INFO - 2017-06-22 19:52:56 --> Loader Class Initialized
INFO - 2017-06-22 19:52:56 --> Controller Class Initialized
INFO - 2017-06-22 19:52:56 --> Database Driver Class Initialized
INFO - 2017-06-22 19:52:56 --> Model Class Initialized
INFO - 2017-06-22 19:52:56 --> Helper loaded: form_helper
INFO - 2017-06-22 19:52:56 --> Helper loaded: url_helper
INFO - 2017-06-22 19:52:56 --> Model Class Initialized
INFO - 2017-06-22 19:52:56 --> Final output sent to browser
DEBUG - 2017-06-22 19:52:56 --> Total execution time: 0.0600
ERROR - 2017-06-22 19:52:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:52:57 --> Config Class Initialized
INFO - 2017-06-22 19:52:57 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:52:57 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:52:57 --> Utf8 Class Initialized
INFO - 2017-06-22 19:52:57 --> URI Class Initialized
INFO - 2017-06-22 19:52:57 --> Router Class Initialized
INFO - 2017-06-22 19:52:57 --> Output Class Initialized
INFO - 2017-06-22 19:52:57 --> Security Class Initialized
DEBUG - 2017-06-22 19:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:52:57 --> Input Class Initialized
INFO - 2017-06-22 19:52:57 --> Language Class Initialized
INFO - 2017-06-22 19:52:57 --> Loader Class Initialized
INFO - 2017-06-22 19:52:57 --> Controller Class Initialized
INFO - 2017-06-22 19:52:57 --> Database Driver Class Initialized
INFO - 2017-06-22 19:52:57 --> Model Class Initialized
INFO - 2017-06-22 19:52:57 --> Helper loaded: form_helper
INFO - 2017-06-22 19:52:57 --> Helper loaded: url_helper
INFO - 2017-06-22 19:52:57 --> Model Class Initialized
INFO - 2017-06-22 19:52:57 --> Final output sent to browser
DEBUG - 2017-06-22 19:52:57 --> Total execution time: 0.0550
ERROR - 2017-06-22 19:53:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:53:00 --> Config Class Initialized
INFO - 2017-06-22 19:53:00 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:53:00 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:53:00 --> Utf8 Class Initialized
INFO - 2017-06-22 19:53:00 --> URI Class Initialized
INFO - 2017-06-22 19:53:00 --> Router Class Initialized
INFO - 2017-06-22 19:53:00 --> Output Class Initialized
INFO - 2017-06-22 19:53:00 --> Security Class Initialized
DEBUG - 2017-06-22 19:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:53:00 --> Input Class Initialized
INFO - 2017-06-22 19:53:00 --> Language Class Initialized
INFO - 2017-06-22 19:53:00 --> Loader Class Initialized
INFO - 2017-06-22 19:53:00 --> Controller Class Initialized
INFO - 2017-06-22 19:53:00 --> Database Driver Class Initialized
INFO - 2017-06-22 19:53:00 --> Model Class Initialized
INFO - 2017-06-22 19:53:00 --> Helper loaded: form_helper
INFO - 2017-06-22 19:53:00 --> Helper loaded: url_helper
INFO - 2017-06-22 19:53:00 --> Model Class Initialized
INFO - 2017-06-22 19:53:00 --> Final output sent to browser
DEBUG - 2017-06-22 19:53:00 --> Total execution time: 0.0590
ERROR - 2017-06-22 19:55:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:55:19 --> Config Class Initialized
INFO - 2017-06-22 19:55:19 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:55:19 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:55:19 --> Utf8 Class Initialized
INFO - 2017-06-22 19:55:19 --> URI Class Initialized
INFO - 2017-06-22 19:55:19 --> Router Class Initialized
INFO - 2017-06-22 19:55:19 --> Output Class Initialized
INFO - 2017-06-22 19:55:19 --> Security Class Initialized
DEBUG - 2017-06-22 19:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:55:19 --> Input Class Initialized
INFO - 2017-06-22 19:55:19 --> Language Class Initialized
INFO - 2017-06-22 19:55:19 --> Loader Class Initialized
INFO - 2017-06-22 19:55:19 --> Controller Class Initialized
INFO - 2017-06-22 19:55:19 --> Database Driver Class Initialized
INFO - 2017-06-22 19:55:19 --> Model Class Initialized
INFO - 2017-06-22 19:55:19 --> Helper loaded: form_helper
INFO - 2017-06-22 19:55:19 --> Helper loaded: url_helper
INFO - 2017-06-22 19:55:19 --> Model Class Initialized
INFO - 2017-06-22 19:55:19 --> Final output sent to browser
DEBUG - 2017-06-22 19:55:19 --> Total execution time: 0.0580
ERROR - 2017-06-22 19:57:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:57:01 --> Config Class Initialized
INFO - 2017-06-22 19:57:01 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:57:01 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:57:01 --> Utf8 Class Initialized
INFO - 2017-06-22 19:57:01 --> URI Class Initialized
INFO - 2017-06-22 19:57:01 --> Router Class Initialized
INFO - 2017-06-22 19:57:01 --> Output Class Initialized
INFO - 2017-06-22 19:57:01 --> Security Class Initialized
DEBUG - 2017-06-22 19:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:57:01 --> Input Class Initialized
INFO - 2017-06-22 19:57:01 --> Language Class Initialized
INFO - 2017-06-22 19:57:01 --> Loader Class Initialized
INFO - 2017-06-22 19:57:01 --> Controller Class Initialized
INFO - 2017-06-22 19:57:01 --> Database Driver Class Initialized
INFO - 2017-06-22 19:57:01 --> Model Class Initialized
INFO - 2017-06-22 19:57:01 --> Helper loaded: form_helper
INFO - 2017-06-22 19:57:01 --> Helper loaded: url_helper
INFO - 2017-06-22 19:57:02 --> Model Class Initialized
INFO - 2017-06-22 19:57:02 --> Final output sent to browser
DEBUG - 2017-06-22 19:57:02 --> Total execution time: 0.0490
ERROR - 2017-06-22 19:57:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:57:47 --> Config Class Initialized
INFO - 2017-06-22 19:57:47 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:57:47 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:57:47 --> Utf8 Class Initialized
INFO - 2017-06-22 19:57:47 --> URI Class Initialized
INFO - 2017-06-22 19:57:47 --> Router Class Initialized
INFO - 2017-06-22 19:57:47 --> Output Class Initialized
INFO - 2017-06-22 19:57:47 --> Security Class Initialized
DEBUG - 2017-06-22 19:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:57:47 --> Input Class Initialized
INFO - 2017-06-22 19:57:47 --> Language Class Initialized
INFO - 2017-06-22 19:57:47 --> Loader Class Initialized
INFO - 2017-06-22 19:57:47 --> Controller Class Initialized
INFO - 2017-06-22 19:57:47 --> Database Driver Class Initialized
INFO - 2017-06-22 19:57:47 --> Model Class Initialized
INFO - 2017-06-22 19:57:47 --> Helper loaded: form_helper
INFO - 2017-06-22 19:57:47 --> Helper loaded: url_helper
INFO - 2017-06-22 19:57:47 --> Model Class Initialized
INFO - 2017-06-22 19:57:47 --> Final output sent to browser
DEBUG - 2017-06-22 19:57:47 --> Total execution time: 0.0515
ERROR - 2017-06-22 19:58:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:58:14 --> Config Class Initialized
INFO - 2017-06-22 19:58:14 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:58:14 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:58:14 --> Utf8 Class Initialized
INFO - 2017-06-22 19:58:14 --> URI Class Initialized
INFO - 2017-06-22 19:58:14 --> Router Class Initialized
INFO - 2017-06-22 19:58:14 --> Output Class Initialized
INFO - 2017-06-22 19:58:14 --> Security Class Initialized
DEBUG - 2017-06-22 19:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:58:14 --> Input Class Initialized
INFO - 2017-06-22 19:58:14 --> Language Class Initialized
INFO - 2017-06-22 19:58:14 --> Loader Class Initialized
INFO - 2017-06-22 19:58:14 --> Controller Class Initialized
INFO - 2017-06-22 19:58:14 --> Database Driver Class Initialized
INFO - 2017-06-22 19:58:14 --> Model Class Initialized
INFO - 2017-06-22 19:58:14 --> Helper loaded: form_helper
INFO - 2017-06-22 19:58:14 --> Helper loaded: url_helper
INFO - 2017-06-22 19:58:14 --> Model Class Initialized
INFO - 2017-06-22 19:58:14 --> Final output sent to browser
DEBUG - 2017-06-22 19:58:14 --> Total execution time: 0.0490
ERROR - 2017-06-22 19:58:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:58:45 --> Config Class Initialized
INFO - 2017-06-22 19:58:45 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:58:45 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:58:45 --> Utf8 Class Initialized
INFO - 2017-06-22 19:58:45 --> URI Class Initialized
INFO - 2017-06-22 19:58:45 --> Router Class Initialized
INFO - 2017-06-22 19:58:45 --> Output Class Initialized
INFO - 2017-06-22 19:58:45 --> Security Class Initialized
DEBUG - 2017-06-22 19:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:58:45 --> Input Class Initialized
INFO - 2017-06-22 19:58:45 --> Language Class Initialized
INFO - 2017-06-22 19:58:45 --> Loader Class Initialized
INFO - 2017-06-22 19:58:45 --> Controller Class Initialized
INFO - 2017-06-22 19:58:45 --> Database Driver Class Initialized
INFO - 2017-06-22 19:58:45 --> Model Class Initialized
INFO - 2017-06-22 19:58:45 --> Helper loaded: form_helper
INFO - 2017-06-22 19:58:45 --> Helper loaded: url_helper
INFO - 2017-06-22 19:58:45 --> Model Class Initialized
INFO - 2017-06-22 19:58:45 --> Final output sent to browser
DEBUG - 2017-06-22 19:58:45 --> Total execution time: 0.0570
ERROR - 2017-06-22 19:58:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:58:51 --> Config Class Initialized
INFO - 2017-06-22 19:58:51 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:58:51 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:58:51 --> Utf8 Class Initialized
INFO - 2017-06-22 19:58:51 --> URI Class Initialized
INFO - 2017-06-22 19:58:51 --> Router Class Initialized
INFO - 2017-06-22 19:58:51 --> Output Class Initialized
INFO - 2017-06-22 19:58:51 --> Security Class Initialized
DEBUG - 2017-06-22 19:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:58:51 --> Input Class Initialized
INFO - 2017-06-22 19:58:51 --> Language Class Initialized
INFO - 2017-06-22 19:58:51 --> Loader Class Initialized
INFO - 2017-06-22 19:58:51 --> Controller Class Initialized
INFO - 2017-06-22 19:58:51 --> Database Driver Class Initialized
INFO - 2017-06-22 19:58:51 --> Model Class Initialized
INFO - 2017-06-22 19:58:51 --> Helper loaded: form_helper
INFO - 2017-06-22 19:58:51 --> Helper loaded: url_helper
INFO - 2017-06-22 19:58:51 --> Model Class Initialized
INFO - 2017-06-22 19:58:51 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 19:58:51 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 19:58:51 --> Final output sent to browser
DEBUG - 2017-06-22 19:58:51 --> Total execution time: 0.0880
ERROR - 2017-06-22 19:58:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:58:57 --> Config Class Initialized
INFO - 2017-06-22 19:58:57 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:58:57 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:58:57 --> Utf8 Class Initialized
INFO - 2017-06-22 19:58:57 --> URI Class Initialized
INFO - 2017-06-22 19:58:57 --> Router Class Initialized
INFO - 2017-06-22 19:58:57 --> Output Class Initialized
INFO - 2017-06-22 19:58:57 --> Security Class Initialized
DEBUG - 2017-06-22 19:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:58:57 --> Input Class Initialized
INFO - 2017-06-22 19:58:57 --> Language Class Initialized
INFO - 2017-06-22 19:58:57 --> Loader Class Initialized
INFO - 2017-06-22 19:58:57 --> Controller Class Initialized
INFO - 2017-06-22 19:58:57 --> Database Driver Class Initialized
INFO - 2017-06-22 19:58:57 --> Model Class Initialized
INFO - 2017-06-22 19:58:57 --> Helper loaded: form_helper
INFO - 2017-06-22 19:58:57 --> Helper loaded: url_helper
INFO - 2017-06-22 19:58:57 --> Model Class Initialized
INFO - 2017-06-22 19:58:57 --> Final output sent to browser
DEBUG - 2017-06-22 19:58:57 --> Total execution time: 0.0470
ERROR - 2017-06-22 19:58:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:58:57 --> Config Class Initialized
INFO - 2017-06-22 19:58:57 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:58:57 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:58:57 --> Utf8 Class Initialized
INFO - 2017-06-22 19:58:57 --> URI Class Initialized
INFO - 2017-06-22 19:58:57 --> Router Class Initialized
INFO - 2017-06-22 19:58:57 --> Output Class Initialized
INFO - 2017-06-22 19:58:57 --> Security Class Initialized
DEBUG - 2017-06-22 19:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:58:57 --> Input Class Initialized
INFO - 2017-06-22 19:58:57 --> Language Class Initialized
INFO - 2017-06-22 19:58:57 --> Loader Class Initialized
INFO - 2017-06-22 19:58:57 --> Controller Class Initialized
INFO - 2017-06-22 19:58:57 --> Database Driver Class Initialized
INFO - 2017-06-22 19:58:57 --> Model Class Initialized
INFO - 2017-06-22 19:58:57 --> Helper loaded: form_helper
INFO - 2017-06-22 19:58:57 --> Helper loaded: url_helper
INFO - 2017-06-22 19:58:57 --> Model Class Initialized
INFO - 2017-06-22 19:58:57 --> Final output sent to browser
DEBUG - 2017-06-22 19:58:57 --> Total execution time: 0.0550
ERROR - 2017-06-22 19:59:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:59:16 --> Config Class Initialized
INFO - 2017-06-22 19:59:16 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:59:16 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:59:16 --> Utf8 Class Initialized
INFO - 2017-06-22 19:59:16 --> URI Class Initialized
INFO - 2017-06-22 19:59:16 --> Router Class Initialized
INFO - 2017-06-22 19:59:16 --> Output Class Initialized
INFO - 2017-06-22 19:59:16 --> Security Class Initialized
DEBUG - 2017-06-22 19:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:59:16 --> Input Class Initialized
INFO - 2017-06-22 19:59:16 --> Language Class Initialized
INFO - 2017-06-22 19:59:16 --> Loader Class Initialized
INFO - 2017-06-22 19:59:16 --> Controller Class Initialized
INFO - 2017-06-22 19:59:16 --> Database Driver Class Initialized
INFO - 2017-06-22 19:59:16 --> Model Class Initialized
INFO - 2017-06-22 19:59:16 --> Helper loaded: form_helper
INFO - 2017-06-22 19:59:16 --> Helper loaded: url_helper
INFO - 2017-06-22 19:59:16 --> Model Class Initialized
INFO - 2017-06-22 19:59:16 --> Final output sent to browser
DEBUG - 2017-06-22 19:59:16 --> Total execution time: 0.0480
ERROR - 2017-06-22 19:59:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:59:17 --> Config Class Initialized
INFO - 2017-06-22 19:59:17 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:59:17 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:59:17 --> Utf8 Class Initialized
INFO - 2017-06-22 19:59:17 --> URI Class Initialized
INFO - 2017-06-22 19:59:17 --> Router Class Initialized
INFO - 2017-06-22 19:59:17 --> Output Class Initialized
INFO - 2017-06-22 19:59:17 --> Security Class Initialized
DEBUG - 2017-06-22 19:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:59:17 --> Input Class Initialized
INFO - 2017-06-22 19:59:17 --> Language Class Initialized
INFO - 2017-06-22 19:59:17 --> Loader Class Initialized
INFO - 2017-06-22 19:59:17 --> Controller Class Initialized
INFO - 2017-06-22 19:59:17 --> Database Driver Class Initialized
INFO - 2017-06-22 19:59:17 --> Model Class Initialized
INFO - 2017-06-22 19:59:17 --> Helper loaded: form_helper
INFO - 2017-06-22 19:59:17 --> Helper loaded: url_helper
INFO - 2017-06-22 19:59:17 --> Model Class Initialized
INFO - 2017-06-22 19:59:17 --> Final output sent to browser
DEBUG - 2017-06-22 19:59:17 --> Total execution time: 0.0560
ERROR - 2017-06-22 19:59:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:59:20 --> Config Class Initialized
INFO - 2017-06-22 19:59:20 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:59:20 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:59:20 --> Utf8 Class Initialized
INFO - 2017-06-22 19:59:20 --> URI Class Initialized
INFO - 2017-06-22 19:59:20 --> Router Class Initialized
INFO - 2017-06-22 19:59:20 --> Output Class Initialized
INFO - 2017-06-22 19:59:20 --> Security Class Initialized
DEBUG - 2017-06-22 19:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:59:20 --> Input Class Initialized
INFO - 2017-06-22 19:59:20 --> Language Class Initialized
INFO - 2017-06-22 19:59:20 --> Loader Class Initialized
INFO - 2017-06-22 19:59:20 --> Controller Class Initialized
INFO - 2017-06-22 19:59:20 --> Database Driver Class Initialized
INFO - 2017-06-22 19:59:20 --> Model Class Initialized
INFO - 2017-06-22 19:59:20 --> Helper loaded: form_helper
INFO - 2017-06-22 19:59:20 --> Helper loaded: url_helper
INFO - 2017-06-22 19:59:20 --> Model Class Initialized
INFO - 2017-06-22 19:59:20 --> Final output sent to browser
DEBUG - 2017-06-22 19:59:20 --> Total execution time: 0.0460
ERROR - 2017-06-22 19:59:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:59:34 --> Config Class Initialized
INFO - 2017-06-22 19:59:34 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:59:34 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:59:34 --> Utf8 Class Initialized
INFO - 2017-06-22 19:59:34 --> URI Class Initialized
INFO - 2017-06-22 19:59:34 --> Router Class Initialized
INFO - 2017-06-22 19:59:34 --> Output Class Initialized
INFO - 2017-06-22 19:59:34 --> Security Class Initialized
DEBUG - 2017-06-22 19:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:59:34 --> Input Class Initialized
INFO - 2017-06-22 19:59:34 --> Language Class Initialized
INFO - 2017-06-22 19:59:34 --> Loader Class Initialized
INFO - 2017-06-22 19:59:34 --> Controller Class Initialized
INFO - 2017-06-22 19:59:34 --> Database Driver Class Initialized
INFO - 2017-06-22 19:59:34 --> Model Class Initialized
INFO - 2017-06-22 19:59:34 --> Helper loaded: form_helper
INFO - 2017-06-22 19:59:34 --> Helper loaded: url_helper
INFO - 2017-06-22 19:59:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 19:59:34 --> Model Class Initialized
INFO - 2017-06-22 19:59:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 19:59:34 --> Final output sent to browser
DEBUG - 2017-06-22 19:59:34 --> Total execution time: 0.0570
ERROR - 2017-06-22 19:59:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:59:36 --> Config Class Initialized
INFO - 2017-06-22 19:59:36 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:59:36 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:59:36 --> Utf8 Class Initialized
INFO - 2017-06-22 19:59:36 --> URI Class Initialized
INFO - 2017-06-22 19:59:36 --> Router Class Initialized
INFO - 2017-06-22 19:59:36 --> Output Class Initialized
INFO - 2017-06-22 19:59:36 --> Security Class Initialized
DEBUG - 2017-06-22 19:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:59:36 --> Input Class Initialized
INFO - 2017-06-22 19:59:36 --> Language Class Initialized
INFO - 2017-06-22 19:59:36 --> Loader Class Initialized
INFO - 2017-06-22 19:59:36 --> Controller Class Initialized
INFO - 2017-06-22 19:59:36 --> Database Driver Class Initialized
INFO - 2017-06-22 19:59:36 --> Model Class Initialized
INFO - 2017-06-22 19:59:36 --> Helper loaded: form_helper
INFO - 2017-06-22 19:59:36 --> Helper loaded: url_helper
INFO - 2017-06-22 19:59:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 19:59:36 --> Model Class Initialized
INFO - 2017-06-22 19:59:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 19:59:36 --> Final output sent to browser
DEBUG - 2017-06-22 19:59:36 --> Total execution time: 0.0610
ERROR - 2017-06-22 19:59:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:59:41 --> Config Class Initialized
INFO - 2017-06-22 19:59:41 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:59:41 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:59:41 --> Utf8 Class Initialized
INFO - 2017-06-22 19:59:41 --> URI Class Initialized
INFO - 2017-06-22 19:59:41 --> Router Class Initialized
INFO - 2017-06-22 19:59:41 --> Output Class Initialized
INFO - 2017-06-22 19:59:41 --> Security Class Initialized
DEBUG - 2017-06-22 19:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:59:41 --> Input Class Initialized
INFO - 2017-06-22 19:59:41 --> Language Class Initialized
INFO - 2017-06-22 19:59:41 --> Loader Class Initialized
INFO - 2017-06-22 19:59:41 --> Controller Class Initialized
INFO - 2017-06-22 19:59:41 --> Database Driver Class Initialized
INFO - 2017-06-22 19:59:41 --> Model Class Initialized
INFO - 2017-06-22 19:59:41 --> Helper loaded: form_helper
INFO - 2017-06-22 19:59:41 --> Helper loaded: url_helper
INFO - 2017-06-22 19:59:41 --> Model Class Initialized
INFO - 2017-06-22 19:59:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 19:59:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 19:59:41 --> Final output sent to browser
DEBUG - 2017-06-22 19:59:41 --> Total execution time: 0.2130
ERROR - 2017-06-22 19:59:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:59:47 --> Config Class Initialized
INFO - 2017-06-22 19:59:47 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:59:47 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:59:47 --> Utf8 Class Initialized
INFO - 2017-06-22 19:59:47 --> URI Class Initialized
INFO - 2017-06-22 19:59:47 --> Router Class Initialized
INFO - 2017-06-22 19:59:47 --> Output Class Initialized
INFO - 2017-06-22 19:59:47 --> Security Class Initialized
DEBUG - 2017-06-22 19:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:59:47 --> Input Class Initialized
INFO - 2017-06-22 19:59:47 --> Language Class Initialized
INFO - 2017-06-22 19:59:47 --> Loader Class Initialized
INFO - 2017-06-22 19:59:47 --> Controller Class Initialized
INFO - 2017-06-22 19:59:47 --> Database Driver Class Initialized
INFO - 2017-06-22 19:59:47 --> Model Class Initialized
INFO - 2017-06-22 19:59:47 --> Helper loaded: form_helper
INFO - 2017-06-22 19:59:47 --> Helper loaded: url_helper
INFO - 2017-06-22 19:59:47 --> Model Class Initialized
INFO - 2017-06-22 19:59:47 --> Final output sent to browser
DEBUG - 2017-06-22 19:59:47 --> Total execution time: 0.0570
ERROR - 2017-06-22 19:59:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:59:49 --> Config Class Initialized
INFO - 2017-06-22 19:59:49 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:59:49 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:59:49 --> Utf8 Class Initialized
INFO - 2017-06-22 19:59:49 --> URI Class Initialized
INFO - 2017-06-22 19:59:49 --> Router Class Initialized
INFO - 2017-06-22 19:59:49 --> Output Class Initialized
INFO - 2017-06-22 19:59:49 --> Security Class Initialized
DEBUG - 2017-06-22 19:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:59:49 --> Input Class Initialized
INFO - 2017-06-22 19:59:49 --> Language Class Initialized
INFO - 2017-06-22 19:59:49 --> Loader Class Initialized
INFO - 2017-06-22 19:59:49 --> Controller Class Initialized
INFO - 2017-06-22 19:59:49 --> Database Driver Class Initialized
INFO - 2017-06-22 19:59:49 --> Model Class Initialized
INFO - 2017-06-22 19:59:49 --> Helper loaded: form_helper
INFO - 2017-06-22 19:59:49 --> Helper loaded: url_helper
INFO - 2017-06-22 19:59:49 --> Model Class Initialized
INFO - 2017-06-22 19:59:49 --> Final output sent to browser
DEBUG - 2017-06-22 19:59:49 --> Total execution time: 0.0510
ERROR - 2017-06-22 19:59:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 19:59:52 --> Config Class Initialized
INFO - 2017-06-22 19:59:52 --> Hooks Class Initialized
DEBUG - 2017-06-22 19:59:52 --> UTF-8 Support Enabled
INFO - 2017-06-22 19:59:52 --> Utf8 Class Initialized
INFO - 2017-06-22 19:59:52 --> URI Class Initialized
INFO - 2017-06-22 19:59:52 --> Router Class Initialized
INFO - 2017-06-22 19:59:52 --> Output Class Initialized
INFO - 2017-06-22 19:59:52 --> Security Class Initialized
DEBUG - 2017-06-22 19:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 19:59:52 --> Input Class Initialized
INFO - 2017-06-22 19:59:52 --> Language Class Initialized
INFO - 2017-06-22 19:59:52 --> Loader Class Initialized
INFO - 2017-06-22 19:59:52 --> Controller Class Initialized
INFO - 2017-06-22 19:59:52 --> Database Driver Class Initialized
INFO - 2017-06-22 19:59:52 --> Model Class Initialized
INFO - 2017-06-22 19:59:52 --> Helper loaded: form_helper
INFO - 2017-06-22 19:59:52 --> Helper loaded: url_helper
INFO - 2017-06-22 19:59:52 --> Model Class Initialized
INFO - 2017-06-22 19:59:52 --> Final output sent to browser
DEBUG - 2017-06-22 19:59:52 --> Total execution time: 0.0600
ERROR - 2017-06-22 20:00:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:00:13 --> Config Class Initialized
INFO - 2017-06-22 20:00:13 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:00:13 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:00:13 --> Utf8 Class Initialized
INFO - 2017-06-22 20:00:13 --> URI Class Initialized
INFO - 2017-06-22 20:00:13 --> Router Class Initialized
INFO - 2017-06-22 20:00:13 --> Output Class Initialized
INFO - 2017-06-22 20:00:13 --> Security Class Initialized
DEBUG - 2017-06-22 20:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:00:13 --> Input Class Initialized
INFO - 2017-06-22 20:00:13 --> Language Class Initialized
INFO - 2017-06-22 20:00:13 --> Loader Class Initialized
INFO - 2017-06-22 20:00:13 --> Controller Class Initialized
INFO - 2017-06-22 20:00:13 --> Database Driver Class Initialized
INFO - 2017-06-22 20:00:13 --> Model Class Initialized
INFO - 2017-06-22 20:00:13 --> Helper loaded: form_helper
INFO - 2017-06-22 20:00:13 --> Helper loaded: url_helper
INFO - 2017-06-22 20:00:13 --> Model Class Initialized
INFO - 2017-06-22 20:00:13 --> Final output sent to browser
DEBUG - 2017-06-22 20:00:13 --> Total execution time: 0.0580
ERROR - 2017-06-22 20:00:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:00:53 --> Config Class Initialized
INFO - 2017-06-22 20:00:53 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:00:53 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:00:53 --> Utf8 Class Initialized
INFO - 2017-06-22 20:00:53 --> URI Class Initialized
INFO - 2017-06-22 20:00:53 --> Router Class Initialized
INFO - 2017-06-22 20:00:53 --> Output Class Initialized
INFO - 2017-06-22 20:00:53 --> Security Class Initialized
DEBUG - 2017-06-22 20:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:00:53 --> Input Class Initialized
INFO - 2017-06-22 20:00:53 --> Language Class Initialized
INFO - 2017-06-22 20:00:53 --> Loader Class Initialized
INFO - 2017-06-22 20:00:53 --> Controller Class Initialized
INFO - 2017-06-22 20:00:53 --> Database Driver Class Initialized
INFO - 2017-06-22 20:00:53 --> Model Class Initialized
INFO - 2017-06-22 20:00:53 --> Helper loaded: form_helper
INFO - 2017-06-22 20:00:53 --> Helper loaded: url_helper
INFO - 2017-06-22 20:00:53 --> Model Class Initialized
INFO - 2017-06-22 20:00:53 --> Final output sent to browser
DEBUG - 2017-06-22 20:00:53 --> Total execution time: 0.0660
ERROR - 2017-06-22 20:02:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:02:30 --> Config Class Initialized
INFO - 2017-06-22 20:02:30 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:02:30 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:02:30 --> Utf8 Class Initialized
INFO - 2017-06-22 20:02:30 --> URI Class Initialized
INFO - 2017-06-22 20:02:30 --> Router Class Initialized
INFO - 2017-06-22 20:02:30 --> Output Class Initialized
INFO - 2017-06-22 20:02:30 --> Security Class Initialized
DEBUG - 2017-06-22 20:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:02:30 --> Input Class Initialized
INFO - 2017-06-22 20:02:30 --> Language Class Initialized
INFO - 2017-06-22 20:02:30 --> Loader Class Initialized
INFO - 2017-06-22 20:02:30 --> Controller Class Initialized
INFO - 2017-06-22 20:02:30 --> Database Driver Class Initialized
INFO - 2017-06-22 20:02:30 --> Model Class Initialized
INFO - 2017-06-22 20:02:30 --> Helper loaded: form_helper
INFO - 2017-06-22 20:02:30 --> Helper loaded: url_helper
INFO - 2017-06-22 20:02:30 --> Model Class Initialized
INFO - 2017-06-22 20:02:30 --> Final output sent to browser
DEBUG - 2017-06-22 20:02:30 --> Total execution time: 0.0480
ERROR - 2017-06-22 20:04:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:04:02 --> Config Class Initialized
INFO - 2017-06-22 20:04:02 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:04:02 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:04:02 --> Utf8 Class Initialized
INFO - 2017-06-22 20:04:02 --> URI Class Initialized
INFO - 2017-06-22 20:04:02 --> Router Class Initialized
INFO - 2017-06-22 20:04:02 --> Output Class Initialized
INFO - 2017-06-22 20:04:02 --> Security Class Initialized
DEBUG - 2017-06-22 20:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:04:02 --> Input Class Initialized
INFO - 2017-06-22 20:04:02 --> Language Class Initialized
INFO - 2017-06-22 20:04:02 --> Loader Class Initialized
INFO - 2017-06-22 20:04:02 --> Controller Class Initialized
INFO - 2017-06-22 20:04:02 --> Database Driver Class Initialized
INFO - 2017-06-22 20:04:02 --> Model Class Initialized
INFO - 2017-06-22 20:04:02 --> Helper loaded: form_helper
INFO - 2017-06-22 20:04:02 --> Helper loaded: url_helper
INFO - 2017-06-22 20:04:02 --> Model Class Initialized
INFO - 2017-06-22 20:04:02 --> Final output sent to browser
DEBUG - 2017-06-22 20:04:02 --> Total execution time: 0.0475
ERROR - 2017-06-22 20:05:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:05:38 --> Config Class Initialized
INFO - 2017-06-22 20:05:38 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:05:38 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:05:38 --> Utf8 Class Initialized
INFO - 2017-06-22 20:05:38 --> URI Class Initialized
INFO - 2017-06-22 20:05:38 --> Router Class Initialized
INFO - 2017-06-22 20:05:38 --> Output Class Initialized
INFO - 2017-06-22 20:05:38 --> Security Class Initialized
DEBUG - 2017-06-22 20:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:05:38 --> Input Class Initialized
INFO - 2017-06-22 20:05:38 --> Language Class Initialized
INFO - 2017-06-22 20:05:38 --> Loader Class Initialized
INFO - 2017-06-22 20:05:38 --> Controller Class Initialized
INFO - 2017-06-22 20:05:38 --> Database Driver Class Initialized
INFO - 2017-06-22 20:05:38 --> Model Class Initialized
INFO - 2017-06-22 20:05:38 --> Helper loaded: form_helper
INFO - 2017-06-22 20:05:38 --> Helper loaded: url_helper
INFO - 2017-06-22 20:05:38 --> Model Class Initialized
INFO - 2017-06-22 20:05:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:05:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:05:38 --> Final output sent to browser
DEBUG - 2017-06-22 20:05:38 --> Total execution time: 0.0920
ERROR - 2017-06-22 20:05:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:05:40 --> Config Class Initialized
INFO - 2017-06-22 20:05:40 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:05:40 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:05:40 --> Utf8 Class Initialized
INFO - 2017-06-22 20:05:40 --> URI Class Initialized
INFO - 2017-06-22 20:05:40 --> Router Class Initialized
INFO - 2017-06-22 20:05:40 --> Output Class Initialized
INFO - 2017-06-22 20:05:40 --> Security Class Initialized
DEBUG - 2017-06-22 20:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:05:40 --> Input Class Initialized
INFO - 2017-06-22 20:05:40 --> Language Class Initialized
INFO - 2017-06-22 20:05:40 --> Loader Class Initialized
INFO - 2017-06-22 20:05:40 --> Controller Class Initialized
INFO - 2017-06-22 20:05:40 --> Database Driver Class Initialized
INFO - 2017-06-22 20:05:40 --> Model Class Initialized
INFO - 2017-06-22 20:05:40 --> Helper loaded: form_helper
INFO - 2017-06-22 20:05:40 --> Helper loaded: url_helper
INFO - 2017-06-22 20:05:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:05:40 --> Model Class Initialized
INFO - 2017-06-22 20:05:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 20:05:40 --> Final output sent to browser
DEBUG - 2017-06-22 20:05:40 --> Total execution time: 0.0550
ERROR - 2017-06-22 20:05:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:05:41 --> Config Class Initialized
INFO - 2017-06-22 20:05:41 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:05:41 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:05:41 --> Utf8 Class Initialized
INFO - 2017-06-22 20:05:41 --> URI Class Initialized
INFO - 2017-06-22 20:05:41 --> Router Class Initialized
INFO - 2017-06-22 20:05:41 --> Output Class Initialized
INFO - 2017-06-22 20:05:41 --> Security Class Initialized
DEBUG - 2017-06-22 20:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:05:41 --> Input Class Initialized
INFO - 2017-06-22 20:05:41 --> Language Class Initialized
INFO - 2017-06-22 20:05:41 --> Loader Class Initialized
INFO - 2017-06-22 20:05:41 --> Controller Class Initialized
INFO - 2017-06-22 20:05:41 --> Database Driver Class Initialized
INFO - 2017-06-22 20:05:41 --> Model Class Initialized
INFO - 2017-06-22 20:05:41 --> Helper loaded: form_helper
INFO - 2017-06-22 20:05:41 --> Helper loaded: url_helper
INFO - 2017-06-22 20:05:41 --> Model Class Initialized
INFO - 2017-06-22 20:05:41 --> Final output sent to browser
DEBUG - 2017-06-22 20:05:41 --> Total execution time: 0.0550
ERROR - 2017-06-22 20:05:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:05:42 --> Config Class Initialized
INFO - 2017-06-22 20:05:42 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:05:42 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:05:42 --> Utf8 Class Initialized
INFO - 2017-06-22 20:05:42 --> URI Class Initialized
INFO - 2017-06-22 20:05:42 --> Router Class Initialized
INFO - 2017-06-22 20:05:42 --> Output Class Initialized
INFO - 2017-06-22 20:05:42 --> Security Class Initialized
DEBUG - 2017-06-22 20:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:05:42 --> Input Class Initialized
INFO - 2017-06-22 20:05:42 --> Language Class Initialized
INFO - 2017-06-22 20:05:42 --> Loader Class Initialized
INFO - 2017-06-22 20:05:42 --> Controller Class Initialized
INFO - 2017-06-22 20:05:42 --> Database Driver Class Initialized
INFO - 2017-06-22 20:05:42 --> Model Class Initialized
INFO - 2017-06-22 20:05:42 --> Helper loaded: form_helper
INFO - 2017-06-22 20:05:42 --> Helper loaded: url_helper
INFO - 2017-06-22 20:05:42 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:05:42 --> Model Class Initialized
INFO - 2017-06-22 20:05:42 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:05:42 --> Final output sent to browser
DEBUG - 2017-06-22 20:05:42 --> Total execution time: 0.0535
ERROR - 2017-06-22 20:05:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:05:43 --> Config Class Initialized
INFO - 2017-06-22 20:05:43 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:05:43 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:05:43 --> Utf8 Class Initialized
INFO - 2017-06-22 20:05:43 --> URI Class Initialized
INFO - 2017-06-22 20:05:43 --> Router Class Initialized
INFO - 2017-06-22 20:05:43 --> Output Class Initialized
INFO - 2017-06-22 20:05:43 --> Security Class Initialized
DEBUG - 2017-06-22 20:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:05:43 --> Input Class Initialized
INFO - 2017-06-22 20:05:43 --> Language Class Initialized
INFO - 2017-06-22 20:05:43 --> Loader Class Initialized
INFO - 2017-06-22 20:05:43 --> Controller Class Initialized
INFO - 2017-06-22 20:05:43 --> Database Driver Class Initialized
INFO - 2017-06-22 20:05:43 --> Model Class Initialized
INFO - 2017-06-22 20:05:43 --> Helper loaded: form_helper
INFO - 2017-06-22 20:05:43 --> Helper loaded: url_helper
INFO - 2017-06-22 20:05:43 --> Model Class Initialized
INFO - 2017-06-22 20:05:43 --> Final output sent to browser
DEBUG - 2017-06-22 20:05:43 --> Total execution time: 0.1365
ERROR - 2017-06-22 20:05:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:05:44 --> Config Class Initialized
INFO - 2017-06-22 20:05:44 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:05:44 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:05:44 --> Utf8 Class Initialized
INFO - 2017-06-22 20:05:44 --> URI Class Initialized
INFO - 2017-06-22 20:05:44 --> Router Class Initialized
INFO - 2017-06-22 20:05:44 --> Output Class Initialized
INFO - 2017-06-22 20:05:44 --> Security Class Initialized
DEBUG - 2017-06-22 20:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:05:44 --> Input Class Initialized
INFO - 2017-06-22 20:05:44 --> Language Class Initialized
INFO - 2017-06-22 20:05:44 --> Loader Class Initialized
INFO - 2017-06-22 20:05:44 --> Controller Class Initialized
INFO - 2017-06-22 20:05:44 --> Database Driver Class Initialized
INFO - 2017-06-22 20:05:44 --> Model Class Initialized
INFO - 2017-06-22 20:05:44 --> Helper loaded: form_helper
INFO - 2017-06-22 20:05:44 --> Helper loaded: url_helper
INFO - 2017-06-22 20:05:44 --> Model Class Initialized
INFO - 2017-06-22 20:05:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:05:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:05:44 --> Final output sent to browser
DEBUG - 2017-06-22 20:05:44 --> Total execution time: 0.2840
ERROR - 2017-06-22 20:05:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:05:51 --> Config Class Initialized
INFO - 2017-06-22 20:05:51 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:05:51 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:05:51 --> Utf8 Class Initialized
INFO - 2017-06-22 20:05:51 --> URI Class Initialized
INFO - 2017-06-22 20:05:51 --> Router Class Initialized
INFO - 2017-06-22 20:05:51 --> Output Class Initialized
INFO - 2017-06-22 20:05:51 --> Security Class Initialized
DEBUG - 2017-06-22 20:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:05:51 --> Input Class Initialized
INFO - 2017-06-22 20:05:51 --> Language Class Initialized
INFO - 2017-06-22 20:05:51 --> Loader Class Initialized
INFO - 2017-06-22 20:05:51 --> Controller Class Initialized
INFO - 2017-06-22 20:05:51 --> Database Driver Class Initialized
INFO - 2017-06-22 20:05:51 --> Model Class Initialized
INFO - 2017-06-22 20:05:51 --> Helper loaded: form_helper
INFO - 2017-06-22 20:05:51 --> Helper loaded: url_helper
INFO - 2017-06-22 20:05:51 --> Model Class Initialized
INFO - 2017-06-22 20:05:51 --> Final output sent to browser
DEBUG - 2017-06-22 20:05:51 --> Total execution time: 0.0410
ERROR - 2017-06-22 20:05:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:05:51 --> Config Class Initialized
INFO - 2017-06-22 20:05:51 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:05:51 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:05:51 --> Utf8 Class Initialized
INFO - 2017-06-22 20:05:51 --> URI Class Initialized
INFO - 2017-06-22 20:05:51 --> Router Class Initialized
INFO - 2017-06-22 20:05:51 --> Output Class Initialized
INFO - 2017-06-22 20:05:51 --> Security Class Initialized
DEBUG - 2017-06-22 20:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:05:51 --> Input Class Initialized
INFO - 2017-06-22 20:05:51 --> Language Class Initialized
INFO - 2017-06-22 20:05:51 --> Loader Class Initialized
INFO - 2017-06-22 20:05:51 --> Controller Class Initialized
INFO - 2017-06-22 20:05:51 --> Database Driver Class Initialized
INFO - 2017-06-22 20:05:51 --> Model Class Initialized
INFO - 2017-06-22 20:05:51 --> Helper loaded: form_helper
INFO - 2017-06-22 20:05:51 --> Helper loaded: url_helper
INFO - 2017-06-22 20:05:51 --> Model Class Initialized
INFO - 2017-06-22 20:05:51 --> Final output sent to browser
DEBUG - 2017-06-22 20:05:51 --> Total execution time: 0.0480
ERROR - 2017-06-22 20:05:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:05:53 --> Config Class Initialized
INFO - 2017-06-22 20:05:53 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:05:53 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:05:53 --> Utf8 Class Initialized
INFO - 2017-06-22 20:05:53 --> URI Class Initialized
INFO - 2017-06-22 20:05:53 --> Router Class Initialized
INFO - 2017-06-22 20:05:53 --> Output Class Initialized
INFO - 2017-06-22 20:05:53 --> Security Class Initialized
DEBUG - 2017-06-22 20:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:05:53 --> Input Class Initialized
INFO - 2017-06-22 20:05:53 --> Language Class Initialized
INFO - 2017-06-22 20:05:53 --> Loader Class Initialized
INFO - 2017-06-22 20:05:53 --> Controller Class Initialized
INFO - 2017-06-22 20:05:53 --> Database Driver Class Initialized
INFO - 2017-06-22 20:05:53 --> Model Class Initialized
INFO - 2017-06-22 20:05:53 --> Helper loaded: form_helper
INFO - 2017-06-22 20:05:53 --> Helper loaded: url_helper
INFO - 2017-06-22 20:05:53 --> Model Class Initialized
INFO - 2017-06-22 20:05:53 --> Final output sent to browser
DEBUG - 2017-06-22 20:05:53 --> Total execution time: 0.0680
ERROR - 2017-06-22 20:05:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:05:56 --> Config Class Initialized
INFO - 2017-06-22 20:05:56 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:05:56 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:05:56 --> Utf8 Class Initialized
INFO - 2017-06-22 20:05:56 --> URI Class Initialized
INFO - 2017-06-22 20:05:56 --> Router Class Initialized
INFO - 2017-06-22 20:05:56 --> Output Class Initialized
INFO - 2017-06-22 20:05:56 --> Security Class Initialized
DEBUG - 2017-06-22 20:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:05:56 --> Input Class Initialized
INFO - 2017-06-22 20:05:56 --> Language Class Initialized
INFO - 2017-06-22 20:05:56 --> Loader Class Initialized
INFO - 2017-06-22 20:05:56 --> Controller Class Initialized
INFO - 2017-06-22 20:05:56 --> Database Driver Class Initialized
INFO - 2017-06-22 20:05:56 --> Model Class Initialized
INFO - 2017-06-22 20:05:56 --> Helper loaded: form_helper
INFO - 2017-06-22 20:05:56 --> Helper loaded: url_helper
INFO - 2017-06-22 20:05:56 --> Model Class Initialized
INFO - 2017-06-22 20:05:56 --> Final output sent to browser
DEBUG - 2017-06-22 20:05:56 --> Total execution time: 0.0630
ERROR - 2017-06-22 20:05:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:05:57 --> Config Class Initialized
INFO - 2017-06-22 20:05:57 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:05:57 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:05:57 --> Utf8 Class Initialized
INFO - 2017-06-22 20:05:57 --> URI Class Initialized
INFO - 2017-06-22 20:05:57 --> Router Class Initialized
INFO - 2017-06-22 20:05:57 --> Output Class Initialized
INFO - 2017-06-22 20:05:57 --> Security Class Initialized
DEBUG - 2017-06-22 20:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:05:57 --> Input Class Initialized
INFO - 2017-06-22 20:05:57 --> Language Class Initialized
INFO - 2017-06-22 20:05:57 --> Loader Class Initialized
INFO - 2017-06-22 20:05:57 --> Controller Class Initialized
INFO - 2017-06-22 20:05:57 --> Database Driver Class Initialized
INFO - 2017-06-22 20:05:57 --> Model Class Initialized
INFO - 2017-06-22 20:05:57 --> Helper loaded: form_helper
INFO - 2017-06-22 20:05:57 --> Helper loaded: url_helper
INFO - 2017-06-22 20:05:57 --> Model Class Initialized
INFO - 2017-06-22 20:05:57 --> Final output sent to browser
DEBUG - 2017-06-22 20:05:57 --> Total execution time: 0.0610
ERROR - 2017-06-22 20:05:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:05:59 --> Config Class Initialized
INFO - 2017-06-22 20:05:59 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:05:59 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:05:59 --> Utf8 Class Initialized
INFO - 2017-06-22 20:05:59 --> URI Class Initialized
INFO - 2017-06-22 20:05:59 --> Router Class Initialized
INFO - 2017-06-22 20:05:59 --> Output Class Initialized
INFO - 2017-06-22 20:05:59 --> Security Class Initialized
DEBUG - 2017-06-22 20:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:05:59 --> Input Class Initialized
INFO - 2017-06-22 20:05:59 --> Language Class Initialized
INFO - 2017-06-22 20:05:59 --> Loader Class Initialized
INFO - 2017-06-22 20:05:59 --> Controller Class Initialized
INFO - 2017-06-22 20:05:59 --> Database Driver Class Initialized
INFO - 2017-06-22 20:05:59 --> Model Class Initialized
INFO - 2017-06-22 20:05:59 --> Helper loaded: form_helper
INFO - 2017-06-22 20:05:59 --> Helper loaded: url_helper
INFO - 2017-06-22 20:05:59 --> Model Class Initialized
INFO - 2017-06-22 20:05:59 --> Final output sent to browser
DEBUG - 2017-06-22 20:05:59 --> Total execution time: 0.0500
ERROR - 2017-06-22 20:06:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:06:25 --> Config Class Initialized
INFO - 2017-06-22 20:06:25 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:06:25 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:06:25 --> Utf8 Class Initialized
INFO - 2017-06-22 20:06:25 --> URI Class Initialized
INFO - 2017-06-22 20:06:25 --> Router Class Initialized
INFO - 2017-06-22 20:06:25 --> Output Class Initialized
INFO - 2017-06-22 20:06:25 --> Security Class Initialized
DEBUG - 2017-06-22 20:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:06:25 --> Input Class Initialized
INFO - 2017-06-22 20:06:25 --> Language Class Initialized
INFO - 2017-06-22 20:06:25 --> Loader Class Initialized
INFO - 2017-06-22 20:06:25 --> Controller Class Initialized
INFO - 2017-06-22 20:06:25 --> Database Driver Class Initialized
INFO - 2017-06-22 20:06:25 --> Model Class Initialized
INFO - 2017-06-22 20:06:25 --> Helper loaded: form_helper
INFO - 2017-06-22 20:06:25 --> Helper loaded: url_helper
INFO - 2017-06-22 20:06:25 --> Model Class Initialized
INFO - 2017-06-22 20:06:25 --> Final output sent to browser
DEBUG - 2017-06-22 20:06:25 --> Total execution time: 0.0620
ERROR - 2017-06-22 20:06:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:06:43 --> Config Class Initialized
INFO - 2017-06-22 20:06:43 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:06:43 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:06:43 --> Utf8 Class Initialized
INFO - 2017-06-22 20:06:43 --> URI Class Initialized
INFO - 2017-06-22 20:06:43 --> Router Class Initialized
INFO - 2017-06-22 20:06:43 --> Output Class Initialized
INFO - 2017-06-22 20:06:43 --> Security Class Initialized
DEBUG - 2017-06-22 20:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:06:43 --> Input Class Initialized
INFO - 2017-06-22 20:06:43 --> Language Class Initialized
INFO - 2017-06-22 20:06:43 --> Loader Class Initialized
INFO - 2017-06-22 20:06:43 --> Controller Class Initialized
INFO - 2017-06-22 20:06:43 --> Database Driver Class Initialized
INFO - 2017-06-22 20:06:43 --> Model Class Initialized
INFO - 2017-06-22 20:06:43 --> Helper loaded: form_helper
INFO - 2017-06-22 20:06:43 --> Helper loaded: url_helper
INFO - 2017-06-22 20:06:43 --> Model Class Initialized
INFO - 2017-06-22 20:06:43 --> Final output sent to browser
DEBUG - 2017-06-22 20:06:43 --> Total execution time: 0.0580
ERROR - 2017-06-22 20:07:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:07:03 --> Config Class Initialized
INFO - 2017-06-22 20:07:03 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:07:03 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:07:03 --> Utf8 Class Initialized
INFO - 2017-06-22 20:07:03 --> URI Class Initialized
INFO - 2017-06-22 20:07:03 --> Router Class Initialized
INFO - 2017-06-22 20:07:03 --> Output Class Initialized
INFO - 2017-06-22 20:07:03 --> Security Class Initialized
DEBUG - 2017-06-22 20:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:07:03 --> Input Class Initialized
INFO - 2017-06-22 20:07:03 --> Language Class Initialized
INFO - 2017-06-22 20:07:03 --> Loader Class Initialized
INFO - 2017-06-22 20:07:03 --> Controller Class Initialized
INFO - 2017-06-22 20:07:03 --> Database Driver Class Initialized
INFO - 2017-06-22 20:07:03 --> Model Class Initialized
INFO - 2017-06-22 20:07:03 --> Helper loaded: form_helper
INFO - 2017-06-22 20:07:03 --> Helper loaded: url_helper
INFO - 2017-06-22 20:07:03 --> Model Class Initialized
INFO - 2017-06-22 20:07:03 --> Final output sent to browser
DEBUG - 2017-06-22 20:07:03 --> Total execution time: 0.0490
ERROR - 2017-06-22 20:07:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:07:20 --> Config Class Initialized
INFO - 2017-06-22 20:07:20 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:07:20 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:07:20 --> Utf8 Class Initialized
INFO - 2017-06-22 20:07:20 --> URI Class Initialized
INFO - 2017-06-22 20:07:20 --> Router Class Initialized
INFO - 2017-06-22 20:07:20 --> Output Class Initialized
INFO - 2017-06-22 20:07:20 --> Security Class Initialized
DEBUG - 2017-06-22 20:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:07:20 --> Input Class Initialized
INFO - 2017-06-22 20:07:20 --> Language Class Initialized
INFO - 2017-06-22 20:07:20 --> Loader Class Initialized
INFO - 2017-06-22 20:07:20 --> Controller Class Initialized
INFO - 2017-06-22 20:07:20 --> Database Driver Class Initialized
INFO - 2017-06-22 20:07:20 --> Model Class Initialized
INFO - 2017-06-22 20:07:20 --> Helper loaded: form_helper
INFO - 2017-06-22 20:07:20 --> Helper loaded: url_helper
INFO - 2017-06-22 20:07:20 --> Model Class Initialized
INFO - 2017-06-22 20:07:20 --> Final output sent to browser
DEBUG - 2017-06-22 20:07:20 --> Total execution time: 0.0520
ERROR - 2017-06-22 20:07:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:07:23 --> Config Class Initialized
INFO - 2017-06-22 20:07:23 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:07:23 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:07:23 --> Utf8 Class Initialized
INFO - 2017-06-22 20:07:23 --> URI Class Initialized
INFO - 2017-06-22 20:07:23 --> Router Class Initialized
INFO - 2017-06-22 20:07:23 --> Output Class Initialized
INFO - 2017-06-22 20:07:23 --> Security Class Initialized
DEBUG - 2017-06-22 20:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:07:23 --> Input Class Initialized
INFO - 2017-06-22 20:07:23 --> Language Class Initialized
INFO - 2017-06-22 20:07:23 --> Loader Class Initialized
INFO - 2017-06-22 20:07:23 --> Controller Class Initialized
INFO - 2017-06-22 20:07:23 --> Database Driver Class Initialized
INFO - 2017-06-22 20:07:23 --> Model Class Initialized
INFO - 2017-06-22 20:07:23 --> Helper loaded: form_helper
INFO - 2017-06-22 20:07:23 --> Helper loaded: url_helper
INFO - 2017-06-22 20:07:23 --> Model Class Initialized
INFO - 2017-06-22 20:07:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:07:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:07:23 --> Final output sent to browser
DEBUG - 2017-06-22 20:07:23 --> Total execution time: 0.1070
ERROR - 2017-06-22 20:07:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:07:25 --> Config Class Initialized
INFO - 2017-06-22 20:07:25 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:07:25 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:07:25 --> Utf8 Class Initialized
INFO - 2017-06-22 20:07:25 --> URI Class Initialized
INFO - 2017-06-22 20:07:25 --> Router Class Initialized
INFO - 2017-06-22 20:07:25 --> Output Class Initialized
INFO - 2017-06-22 20:07:25 --> Security Class Initialized
DEBUG - 2017-06-22 20:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:07:25 --> Input Class Initialized
INFO - 2017-06-22 20:07:25 --> Language Class Initialized
INFO - 2017-06-22 20:07:25 --> Loader Class Initialized
INFO - 2017-06-22 20:07:25 --> Controller Class Initialized
INFO - 2017-06-22 20:07:25 --> Database Driver Class Initialized
INFO - 2017-06-22 20:07:25 --> Model Class Initialized
INFO - 2017-06-22 20:07:25 --> Helper loaded: form_helper
INFO - 2017-06-22 20:07:25 --> Helper loaded: url_helper
INFO - 2017-06-22 20:07:25 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:07:25 --> Model Class Initialized
INFO - 2017-06-22 20:07:25 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 20:07:25 --> Final output sent to browser
DEBUG - 2017-06-22 20:07:25 --> Total execution time: 0.0580
ERROR - 2017-06-22 20:07:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:07:27 --> Config Class Initialized
INFO - 2017-06-22 20:07:27 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:07:27 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:07:27 --> Utf8 Class Initialized
INFO - 2017-06-22 20:07:27 --> URI Class Initialized
INFO - 2017-06-22 20:07:27 --> Router Class Initialized
INFO - 2017-06-22 20:07:27 --> Output Class Initialized
INFO - 2017-06-22 20:07:27 --> Security Class Initialized
DEBUG - 2017-06-22 20:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:07:27 --> Input Class Initialized
INFO - 2017-06-22 20:07:27 --> Language Class Initialized
INFO - 2017-06-22 20:07:27 --> Loader Class Initialized
INFO - 2017-06-22 20:07:27 --> Controller Class Initialized
INFO - 2017-06-22 20:07:27 --> Database Driver Class Initialized
INFO - 2017-06-22 20:07:27 --> Model Class Initialized
INFO - 2017-06-22 20:07:27 --> Helper loaded: form_helper
INFO - 2017-06-22 20:07:27 --> Helper loaded: url_helper
INFO - 2017-06-22 20:07:27 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:07:27 --> Model Class Initialized
INFO - 2017-06-22 20:07:27 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:07:27 --> Final output sent to browser
DEBUG - 2017-06-22 20:07:27 --> Total execution time: 0.0760
ERROR - 2017-06-22 20:07:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:07:29 --> Config Class Initialized
INFO - 2017-06-22 20:07:29 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:07:29 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:07:29 --> Utf8 Class Initialized
INFO - 2017-06-22 20:07:29 --> URI Class Initialized
INFO - 2017-06-22 20:07:29 --> Router Class Initialized
INFO - 2017-06-22 20:07:29 --> Output Class Initialized
INFO - 2017-06-22 20:07:29 --> Security Class Initialized
DEBUG - 2017-06-22 20:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:07:29 --> Input Class Initialized
INFO - 2017-06-22 20:07:29 --> Language Class Initialized
INFO - 2017-06-22 20:07:29 --> Loader Class Initialized
INFO - 2017-06-22 20:07:29 --> Controller Class Initialized
INFO - 2017-06-22 20:07:29 --> Database Driver Class Initialized
INFO - 2017-06-22 20:07:29 --> Model Class Initialized
INFO - 2017-06-22 20:07:29 --> Helper loaded: form_helper
INFO - 2017-06-22 20:07:29 --> Helper loaded: url_helper
INFO - 2017-06-22 20:07:29 --> Model Class Initialized
INFO - 2017-06-22 20:07:30 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:07:30 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:07:30 --> Final output sent to browser
DEBUG - 2017-06-22 20:07:30 --> Total execution time: 0.3780
ERROR - 2017-06-22 20:07:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:07:31 --> Config Class Initialized
INFO - 2017-06-22 20:07:31 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:07:31 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:07:31 --> Utf8 Class Initialized
INFO - 2017-06-22 20:07:31 --> URI Class Initialized
INFO - 2017-06-22 20:07:31 --> Router Class Initialized
INFO - 2017-06-22 20:07:31 --> Output Class Initialized
INFO - 2017-06-22 20:07:31 --> Security Class Initialized
DEBUG - 2017-06-22 20:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:07:31 --> Input Class Initialized
INFO - 2017-06-22 20:07:31 --> Language Class Initialized
INFO - 2017-06-22 20:07:31 --> Loader Class Initialized
INFO - 2017-06-22 20:07:31 --> Controller Class Initialized
INFO - 2017-06-22 20:07:31 --> Database Driver Class Initialized
INFO - 2017-06-22 20:07:31 --> Model Class Initialized
INFO - 2017-06-22 20:07:31 --> Helper loaded: form_helper
INFO - 2017-06-22 20:07:31 --> Helper loaded: url_helper
INFO - 2017-06-22 20:07:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:07:31 --> Model Class Initialized
INFO - 2017-06-22 20:07:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 20:07:31 --> Final output sent to browser
DEBUG - 2017-06-22 20:07:31 --> Total execution time: 0.2640
ERROR - 2017-06-22 20:07:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:07:33 --> Config Class Initialized
INFO - 2017-06-22 20:07:33 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:07:33 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:07:33 --> Utf8 Class Initialized
INFO - 2017-06-22 20:07:33 --> URI Class Initialized
INFO - 2017-06-22 20:07:33 --> Router Class Initialized
INFO - 2017-06-22 20:07:33 --> Output Class Initialized
INFO - 2017-06-22 20:07:33 --> Security Class Initialized
DEBUG - 2017-06-22 20:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:07:33 --> Input Class Initialized
INFO - 2017-06-22 20:07:33 --> Language Class Initialized
INFO - 2017-06-22 20:07:33 --> Loader Class Initialized
INFO - 2017-06-22 20:07:33 --> Controller Class Initialized
INFO - 2017-06-22 20:07:33 --> Database Driver Class Initialized
INFO - 2017-06-22 20:07:33 --> Model Class Initialized
INFO - 2017-06-22 20:07:33 --> Helper loaded: form_helper
INFO - 2017-06-22 20:07:33 --> Helper loaded: url_helper
INFO - 2017-06-22 20:07:33 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:07:33 --> Model Class Initialized
INFO - 2017-06-22 20:07:33 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:07:33 --> Final output sent to browser
DEBUG - 2017-06-22 20:07:33 --> Total execution time: 0.0880
ERROR - 2017-06-22 20:07:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:07:35 --> Config Class Initialized
INFO - 2017-06-22 20:07:35 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:07:35 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:07:35 --> Utf8 Class Initialized
INFO - 2017-06-22 20:07:35 --> URI Class Initialized
INFO - 2017-06-22 20:07:35 --> Router Class Initialized
INFO - 2017-06-22 20:07:35 --> Output Class Initialized
INFO - 2017-06-22 20:07:35 --> Security Class Initialized
DEBUG - 2017-06-22 20:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:07:35 --> Input Class Initialized
INFO - 2017-06-22 20:07:35 --> Language Class Initialized
INFO - 2017-06-22 20:07:35 --> Loader Class Initialized
INFO - 2017-06-22 20:07:35 --> Controller Class Initialized
INFO - 2017-06-22 20:07:35 --> Database Driver Class Initialized
INFO - 2017-06-22 20:07:35 --> Model Class Initialized
INFO - 2017-06-22 20:07:35 --> Helper loaded: form_helper
INFO - 2017-06-22 20:07:35 --> Helper loaded: url_helper
INFO - 2017-06-22 20:07:35 --> Model Class Initialized
INFO - 2017-06-22 20:07:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:07:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:07:36 --> Final output sent to browser
DEBUG - 2017-06-22 20:07:36 --> Total execution time: 0.4220
ERROR - 2017-06-22 20:07:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:07:43 --> Config Class Initialized
INFO - 2017-06-22 20:07:43 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:07:43 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:07:43 --> Utf8 Class Initialized
INFO - 2017-06-22 20:07:43 --> URI Class Initialized
INFO - 2017-06-22 20:07:43 --> Router Class Initialized
INFO - 2017-06-22 20:07:43 --> Output Class Initialized
INFO - 2017-06-22 20:07:43 --> Security Class Initialized
DEBUG - 2017-06-22 20:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:07:43 --> Input Class Initialized
INFO - 2017-06-22 20:07:43 --> Language Class Initialized
INFO - 2017-06-22 20:07:43 --> Loader Class Initialized
INFO - 2017-06-22 20:07:43 --> Controller Class Initialized
INFO - 2017-06-22 20:07:43 --> Database Driver Class Initialized
INFO - 2017-06-22 20:07:43 --> Model Class Initialized
INFO - 2017-06-22 20:07:43 --> Helper loaded: form_helper
INFO - 2017-06-22 20:07:43 --> Helper loaded: url_helper
INFO - 2017-06-22 20:07:43 --> Model Class Initialized
INFO - 2017-06-22 20:07:43 --> Final output sent to browser
DEBUG - 2017-06-22 20:07:43 --> Total execution time: 0.0660
ERROR - 2017-06-22 20:07:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:07:43 --> Config Class Initialized
INFO - 2017-06-22 20:07:43 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:07:43 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:07:43 --> Utf8 Class Initialized
INFO - 2017-06-22 20:07:43 --> URI Class Initialized
INFO - 2017-06-22 20:07:43 --> Router Class Initialized
INFO - 2017-06-22 20:07:43 --> Output Class Initialized
INFO - 2017-06-22 20:07:43 --> Security Class Initialized
DEBUG - 2017-06-22 20:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:07:43 --> Input Class Initialized
INFO - 2017-06-22 20:07:43 --> Language Class Initialized
INFO - 2017-06-22 20:07:43 --> Loader Class Initialized
INFO - 2017-06-22 20:07:43 --> Controller Class Initialized
INFO - 2017-06-22 20:07:43 --> Database Driver Class Initialized
INFO - 2017-06-22 20:07:43 --> Model Class Initialized
INFO - 2017-06-22 20:07:43 --> Helper loaded: form_helper
INFO - 2017-06-22 20:07:43 --> Helper loaded: url_helper
INFO - 2017-06-22 20:07:43 --> Model Class Initialized
INFO - 2017-06-22 20:07:43 --> Final output sent to browser
DEBUG - 2017-06-22 20:07:43 --> Total execution time: 0.0590
ERROR - 2017-06-22 20:07:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:07:45 --> Config Class Initialized
INFO - 2017-06-22 20:07:45 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:07:45 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:07:45 --> Utf8 Class Initialized
INFO - 2017-06-22 20:07:45 --> URI Class Initialized
INFO - 2017-06-22 20:07:45 --> Router Class Initialized
INFO - 2017-06-22 20:07:45 --> Output Class Initialized
INFO - 2017-06-22 20:07:45 --> Security Class Initialized
DEBUG - 2017-06-22 20:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:07:45 --> Input Class Initialized
INFO - 2017-06-22 20:07:45 --> Language Class Initialized
INFO - 2017-06-22 20:07:45 --> Loader Class Initialized
INFO - 2017-06-22 20:07:45 --> Controller Class Initialized
INFO - 2017-06-22 20:07:45 --> Database Driver Class Initialized
INFO - 2017-06-22 20:07:45 --> Model Class Initialized
INFO - 2017-06-22 20:07:45 --> Helper loaded: form_helper
INFO - 2017-06-22 20:07:45 --> Helper loaded: url_helper
INFO - 2017-06-22 20:07:45 --> Model Class Initialized
INFO - 2017-06-22 20:07:45 --> Final output sent to browser
DEBUG - 2017-06-22 20:07:45 --> Total execution time: 0.0570
ERROR - 2017-06-22 20:07:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:07:48 --> Config Class Initialized
INFO - 2017-06-22 20:07:48 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:07:48 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:07:48 --> Utf8 Class Initialized
INFO - 2017-06-22 20:07:48 --> URI Class Initialized
INFO - 2017-06-22 20:07:48 --> Router Class Initialized
INFO - 2017-06-22 20:07:48 --> Output Class Initialized
INFO - 2017-06-22 20:07:48 --> Security Class Initialized
DEBUG - 2017-06-22 20:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:07:48 --> Input Class Initialized
INFO - 2017-06-22 20:07:48 --> Language Class Initialized
INFO - 2017-06-22 20:07:48 --> Loader Class Initialized
INFO - 2017-06-22 20:07:48 --> Controller Class Initialized
INFO - 2017-06-22 20:07:48 --> Database Driver Class Initialized
INFO - 2017-06-22 20:07:48 --> Model Class Initialized
INFO - 2017-06-22 20:07:48 --> Helper loaded: form_helper
INFO - 2017-06-22 20:07:48 --> Helper loaded: url_helper
INFO - 2017-06-22 20:07:48 --> Model Class Initialized
INFO - 2017-06-22 20:07:48 --> Final output sent to browser
DEBUG - 2017-06-22 20:07:48 --> Total execution time: 0.3250
ERROR - 2017-06-22 20:07:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:07:49 --> Config Class Initialized
INFO - 2017-06-22 20:07:49 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:07:49 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:07:49 --> Utf8 Class Initialized
INFO - 2017-06-22 20:07:49 --> URI Class Initialized
INFO - 2017-06-22 20:07:49 --> Router Class Initialized
INFO - 2017-06-22 20:07:49 --> Output Class Initialized
INFO - 2017-06-22 20:07:49 --> Security Class Initialized
DEBUG - 2017-06-22 20:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:07:49 --> Input Class Initialized
INFO - 2017-06-22 20:07:49 --> Language Class Initialized
INFO - 2017-06-22 20:07:49 --> Loader Class Initialized
INFO - 2017-06-22 20:07:49 --> Controller Class Initialized
INFO - 2017-06-22 20:07:49 --> Database Driver Class Initialized
INFO - 2017-06-22 20:07:49 --> Model Class Initialized
INFO - 2017-06-22 20:07:49 --> Helper loaded: form_helper
INFO - 2017-06-22 20:07:49 --> Helper loaded: url_helper
INFO - 2017-06-22 20:07:49 --> Model Class Initialized
INFO - 2017-06-22 20:07:49 --> Final output sent to browser
DEBUG - 2017-06-22 20:07:49 --> Total execution time: 0.0480
ERROR - 2017-06-22 20:07:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:07:52 --> Config Class Initialized
INFO - 2017-06-22 20:07:52 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:07:52 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:07:52 --> Utf8 Class Initialized
INFO - 2017-06-22 20:07:52 --> URI Class Initialized
INFO - 2017-06-22 20:07:52 --> Router Class Initialized
INFO - 2017-06-22 20:07:52 --> Output Class Initialized
INFO - 2017-06-22 20:07:52 --> Security Class Initialized
DEBUG - 2017-06-22 20:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:07:52 --> Input Class Initialized
INFO - 2017-06-22 20:07:52 --> Language Class Initialized
INFO - 2017-06-22 20:07:52 --> Loader Class Initialized
INFO - 2017-06-22 20:07:52 --> Controller Class Initialized
INFO - 2017-06-22 20:07:52 --> Database Driver Class Initialized
INFO - 2017-06-22 20:07:52 --> Model Class Initialized
INFO - 2017-06-22 20:07:52 --> Helper loaded: form_helper
INFO - 2017-06-22 20:07:52 --> Helper loaded: url_helper
INFO - 2017-06-22 20:07:52 --> Model Class Initialized
INFO - 2017-06-22 20:07:52 --> Final output sent to browser
DEBUG - 2017-06-22 20:07:52 --> Total execution time: 0.0480
ERROR - 2017-06-22 20:08:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:08:11 --> Config Class Initialized
INFO - 2017-06-22 20:08:11 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:08:11 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:08:11 --> Utf8 Class Initialized
INFO - 2017-06-22 20:08:11 --> URI Class Initialized
INFO - 2017-06-22 20:08:11 --> Router Class Initialized
INFO - 2017-06-22 20:08:11 --> Output Class Initialized
INFO - 2017-06-22 20:08:11 --> Security Class Initialized
DEBUG - 2017-06-22 20:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:08:11 --> Input Class Initialized
INFO - 2017-06-22 20:08:11 --> Language Class Initialized
INFO - 2017-06-22 20:08:11 --> Loader Class Initialized
INFO - 2017-06-22 20:08:11 --> Controller Class Initialized
INFO - 2017-06-22 20:08:11 --> Database Driver Class Initialized
INFO - 2017-06-22 20:08:11 --> Model Class Initialized
INFO - 2017-06-22 20:08:11 --> Helper loaded: form_helper
INFO - 2017-06-22 20:08:11 --> Helper loaded: url_helper
INFO - 2017-06-22 20:08:11 --> Model Class Initialized
INFO - 2017-06-22 20:08:11 --> Final output sent to browser
DEBUG - 2017-06-22 20:08:11 --> Total execution time: 0.0580
ERROR - 2017-06-22 20:08:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:08:33 --> Config Class Initialized
INFO - 2017-06-22 20:08:33 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:08:33 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:08:33 --> Utf8 Class Initialized
INFO - 2017-06-22 20:08:33 --> URI Class Initialized
INFO - 2017-06-22 20:08:33 --> Router Class Initialized
INFO - 2017-06-22 20:08:33 --> Output Class Initialized
INFO - 2017-06-22 20:08:33 --> Security Class Initialized
DEBUG - 2017-06-22 20:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:08:33 --> Input Class Initialized
INFO - 2017-06-22 20:08:33 --> Language Class Initialized
INFO - 2017-06-22 20:08:33 --> Loader Class Initialized
INFO - 2017-06-22 20:08:33 --> Controller Class Initialized
INFO - 2017-06-22 20:08:33 --> Database Driver Class Initialized
INFO - 2017-06-22 20:08:33 --> Model Class Initialized
INFO - 2017-06-22 20:08:33 --> Helper loaded: form_helper
INFO - 2017-06-22 20:08:33 --> Helper loaded: url_helper
INFO - 2017-06-22 20:08:33 --> Model Class Initialized
INFO - 2017-06-22 20:08:33 --> Final output sent to browser
DEBUG - 2017-06-22 20:08:33 --> Total execution time: 0.0470
ERROR - 2017-06-22 20:09:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:09:32 --> Config Class Initialized
INFO - 2017-06-22 20:09:32 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:09:32 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:09:32 --> Utf8 Class Initialized
INFO - 2017-06-22 20:09:32 --> URI Class Initialized
INFO - 2017-06-22 20:09:32 --> Router Class Initialized
INFO - 2017-06-22 20:09:32 --> Output Class Initialized
INFO - 2017-06-22 20:09:32 --> Security Class Initialized
DEBUG - 2017-06-22 20:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:09:32 --> Input Class Initialized
INFO - 2017-06-22 20:09:32 --> Language Class Initialized
INFO - 2017-06-22 20:09:32 --> Loader Class Initialized
INFO - 2017-06-22 20:09:32 --> Controller Class Initialized
INFO - 2017-06-22 20:09:32 --> Database Driver Class Initialized
INFO - 2017-06-22 20:09:32 --> Model Class Initialized
INFO - 2017-06-22 20:09:32 --> Helper loaded: form_helper
INFO - 2017-06-22 20:09:32 --> Helper loaded: url_helper
INFO - 2017-06-22 20:09:32 --> Model Class Initialized
INFO - 2017-06-22 20:09:32 --> Final output sent to browser
DEBUG - 2017-06-22 20:09:32 --> Total execution time: 0.0560
ERROR - 2017-06-22 20:09:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:09:33 --> Config Class Initialized
INFO - 2017-06-22 20:09:33 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:09:33 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:09:33 --> Utf8 Class Initialized
INFO - 2017-06-22 20:09:33 --> URI Class Initialized
INFO - 2017-06-22 20:09:33 --> Router Class Initialized
INFO - 2017-06-22 20:09:33 --> Output Class Initialized
INFO - 2017-06-22 20:09:33 --> Security Class Initialized
DEBUG - 2017-06-22 20:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:09:33 --> Input Class Initialized
INFO - 2017-06-22 20:09:33 --> Language Class Initialized
INFO - 2017-06-22 20:09:33 --> Loader Class Initialized
INFO - 2017-06-22 20:09:33 --> Controller Class Initialized
INFO - 2017-06-22 20:09:33 --> Database Driver Class Initialized
INFO - 2017-06-22 20:09:33 --> Model Class Initialized
INFO - 2017-06-22 20:09:33 --> Helper loaded: form_helper
INFO - 2017-06-22 20:09:33 --> Helper loaded: url_helper
INFO - 2017-06-22 20:09:33 --> Model Class Initialized
INFO - 2017-06-22 20:09:33 --> Final output sent to browser
DEBUG - 2017-06-22 20:09:33 --> Total execution time: 0.0470
ERROR - 2017-06-22 20:09:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:09:52 --> Config Class Initialized
INFO - 2017-06-22 20:09:52 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:09:52 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:09:52 --> Utf8 Class Initialized
INFO - 2017-06-22 20:09:52 --> URI Class Initialized
INFO - 2017-06-22 20:09:52 --> Router Class Initialized
INFO - 2017-06-22 20:09:52 --> Output Class Initialized
INFO - 2017-06-22 20:09:52 --> Security Class Initialized
DEBUG - 2017-06-22 20:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:09:52 --> Input Class Initialized
INFO - 2017-06-22 20:09:52 --> Language Class Initialized
INFO - 2017-06-22 20:09:52 --> Loader Class Initialized
INFO - 2017-06-22 20:09:52 --> Controller Class Initialized
INFO - 2017-06-22 20:09:52 --> Database Driver Class Initialized
INFO - 2017-06-22 20:09:52 --> Model Class Initialized
INFO - 2017-06-22 20:09:52 --> Helper loaded: form_helper
INFO - 2017-06-22 20:09:52 --> Helper loaded: url_helper
INFO - 2017-06-22 20:09:52 --> Model Class Initialized
INFO - 2017-06-22 20:09:52 --> Final output sent to browser
DEBUG - 2017-06-22 20:09:52 --> Total execution time: 0.0600
ERROR - 2017-06-22 20:10:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:10:10 --> Config Class Initialized
INFO - 2017-06-22 20:10:10 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:10:10 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:10:10 --> Utf8 Class Initialized
INFO - 2017-06-22 20:10:10 --> URI Class Initialized
INFO - 2017-06-22 20:10:10 --> Router Class Initialized
INFO - 2017-06-22 20:10:10 --> Output Class Initialized
INFO - 2017-06-22 20:10:10 --> Security Class Initialized
DEBUG - 2017-06-22 20:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:10:10 --> Input Class Initialized
INFO - 2017-06-22 20:10:10 --> Language Class Initialized
INFO - 2017-06-22 20:10:10 --> Loader Class Initialized
INFO - 2017-06-22 20:10:10 --> Controller Class Initialized
INFO - 2017-06-22 20:10:10 --> Database Driver Class Initialized
INFO - 2017-06-22 20:10:10 --> Model Class Initialized
INFO - 2017-06-22 20:10:10 --> Helper loaded: form_helper
INFO - 2017-06-22 20:10:10 --> Helper loaded: url_helper
INFO - 2017-06-22 20:10:10 --> Model Class Initialized
INFO - 2017-06-22 20:10:10 --> Final output sent to browser
DEBUG - 2017-06-22 20:10:10 --> Total execution time: 0.0470
ERROR - 2017-06-22 20:10:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:10:25 --> Config Class Initialized
INFO - 2017-06-22 20:10:25 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:10:25 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:10:25 --> Utf8 Class Initialized
INFO - 2017-06-22 20:10:25 --> URI Class Initialized
INFO - 2017-06-22 20:10:25 --> Router Class Initialized
INFO - 2017-06-22 20:10:25 --> Output Class Initialized
INFO - 2017-06-22 20:10:25 --> Security Class Initialized
DEBUG - 2017-06-22 20:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:10:25 --> Input Class Initialized
INFO - 2017-06-22 20:10:25 --> Language Class Initialized
INFO - 2017-06-22 20:10:25 --> Loader Class Initialized
INFO - 2017-06-22 20:10:25 --> Controller Class Initialized
INFO - 2017-06-22 20:10:25 --> Database Driver Class Initialized
INFO - 2017-06-22 20:10:25 --> Model Class Initialized
INFO - 2017-06-22 20:10:25 --> Helper loaded: form_helper
INFO - 2017-06-22 20:10:25 --> Helper loaded: url_helper
INFO - 2017-06-22 20:10:25 --> Model Class Initialized
INFO - 2017-06-22 20:10:25 --> Final output sent to browser
DEBUG - 2017-06-22 20:10:25 --> Total execution time: 0.0460
ERROR - 2017-06-22 20:10:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:10:29 --> Config Class Initialized
INFO - 2017-06-22 20:10:29 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:10:29 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:10:29 --> Utf8 Class Initialized
INFO - 2017-06-22 20:10:29 --> URI Class Initialized
INFO - 2017-06-22 20:10:29 --> Router Class Initialized
INFO - 2017-06-22 20:10:29 --> Output Class Initialized
INFO - 2017-06-22 20:10:29 --> Security Class Initialized
DEBUG - 2017-06-22 20:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:10:29 --> Input Class Initialized
INFO - 2017-06-22 20:10:29 --> Language Class Initialized
INFO - 2017-06-22 20:10:29 --> Loader Class Initialized
INFO - 2017-06-22 20:10:29 --> Controller Class Initialized
INFO - 2017-06-22 20:10:29 --> Database Driver Class Initialized
INFO - 2017-06-22 20:10:29 --> Model Class Initialized
INFO - 2017-06-22 20:10:29 --> Helper loaded: form_helper
INFO - 2017-06-22 20:10:29 --> Helper loaded: url_helper
INFO - 2017-06-22 20:10:29 --> Model Class Initialized
INFO - 2017-06-22 20:10:29 --> Final output sent to browser
DEBUG - 2017-06-22 20:10:29 --> Total execution time: 0.0630
ERROR - 2017-06-22 20:10:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:10:30 --> Config Class Initialized
INFO - 2017-06-22 20:10:30 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:10:30 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:10:30 --> Utf8 Class Initialized
INFO - 2017-06-22 20:10:30 --> URI Class Initialized
INFO - 2017-06-22 20:10:30 --> Router Class Initialized
INFO - 2017-06-22 20:10:30 --> Output Class Initialized
INFO - 2017-06-22 20:10:30 --> Security Class Initialized
DEBUG - 2017-06-22 20:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:10:30 --> Input Class Initialized
INFO - 2017-06-22 20:10:30 --> Language Class Initialized
INFO - 2017-06-22 20:10:30 --> Loader Class Initialized
INFO - 2017-06-22 20:10:30 --> Controller Class Initialized
INFO - 2017-06-22 20:10:30 --> Database Driver Class Initialized
INFO - 2017-06-22 20:10:30 --> Model Class Initialized
INFO - 2017-06-22 20:10:30 --> Helper loaded: form_helper
INFO - 2017-06-22 20:10:30 --> Helper loaded: url_helper
INFO - 2017-06-22 20:10:30 --> Model Class Initialized
INFO - 2017-06-22 20:10:30 --> Final output sent to browser
DEBUG - 2017-06-22 20:10:30 --> Total execution time: 0.0450
ERROR - 2017-06-22 20:10:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:10:52 --> Config Class Initialized
INFO - 2017-06-22 20:10:52 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:10:52 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:10:52 --> Utf8 Class Initialized
INFO - 2017-06-22 20:10:52 --> URI Class Initialized
INFO - 2017-06-22 20:10:52 --> Router Class Initialized
INFO - 2017-06-22 20:10:52 --> Output Class Initialized
INFO - 2017-06-22 20:10:52 --> Security Class Initialized
DEBUG - 2017-06-22 20:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:10:52 --> Input Class Initialized
INFO - 2017-06-22 20:10:52 --> Language Class Initialized
INFO - 2017-06-22 20:10:52 --> Loader Class Initialized
INFO - 2017-06-22 20:10:52 --> Controller Class Initialized
INFO - 2017-06-22 20:10:52 --> Database Driver Class Initialized
INFO - 2017-06-22 20:10:52 --> Model Class Initialized
INFO - 2017-06-22 20:10:52 --> Helper loaded: form_helper
INFO - 2017-06-22 20:10:52 --> Helper loaded: url_helper
INFO - 2017-06-22 20:10:52 --> Model Class Initialized
INFO - 2017-06-22 20:10:52 --> Final output sent to browser
DEBUG - 2017-06-22 20:10:52 --> Total execution time: 0.0490
ERROR - 2017-06-22 20:10:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:10:53 --> Config Class Initialized
INFO - 2017-06-22 20:10:53 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:10:53 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:10:53 --> Utf8 Class Initialized
INFO - 2017-06-22 20:10:53 --> URI Class Initialized
INFO - 2017-06-22 20:10:53 --> Router Class Initialized
INFO - 2017-06-22 20:10:53 --> Output Class Initialized
INFO - 2017-06-22 20:10:53 --> Security Class Initialized
DEBUG - 2017-06-22 20:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:10:53 --> Input Class Initialized
INFO - 2017-06-22 20:10:53 --> Language Class Initialized
INFO - 2017-06-22 20:10:53 --> Loader Class Initialized
INFO - 2017-06-22 20:10:53 --> Controller Class Initialized
INFO - 2017-06-22 20:10:53 --> Database Driver Class Initialized
INFO - 2017-06-22 20:10:53 --> Model Class Initialized
INFO - 2017-06-22 20:10:53 --> Helper loaded: form_helper
INFO - 2017-06-22 20:10:53 --> Helper loaded: url_helper
INFO - 2017-06-22 20:10:53 --> Model Class Initialized
INFO - 2017-06-22 20:10:53 --> Final output sent to browser
DEBUG - 2017-06-22 20:10:53 --> Total execution time: 0.0570
ERROR - 2017-06-22 20:11:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:11:15 --> Config Class Initialized
INFO - 2017-06-22 20:11:15 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:11:15 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:11:15 --> Utf8 Class Initialized
INFO - 2017-06-22 20:11:15 --> URI Class Initialized
INFO - 2017-06-22 20:11:15 --> Router Class Initialized
INFO - 2017-06-22 20:11:15 --> Output Class Initialized
INFO - 2017-06-22 20:11:15 --> Security Class Initialized
DEBUG - 2017-06-22 20:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:11:15 --> Input Class Initialized
INFO - 2017-06-22 20:11:15 --> Language Class Initialized
INFO - 2017-06-22 20:11:15 --> Loader Class Initialized
INFO - 2017-06-22 20:11:15 --> Controller Class Initialized
INFO - 2017-06-22 20:11:15 --> Database Driver Class Initialized
INFO - 2017-06-22 20:11:15 --> Model Class Initialized
INFO - 2017-06-22 20:11:15 --> Helper loaded: form_helper
INFO - 2017-06-22 20:11:15 --> Helper loaded: url_helper
INFO - 2017-06-22 20:11:15 --> Model Class Initialized
INFO - 2017-06-22 20:11:15 --> Final output sent to browser
DEBUG - 2017-06-22 20:11:15 --> Total execution time: 0.0610
ERROR - 2017-06-22 20:11:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:11:28 --> Config Class Initialized
INFO - 2017-06-22 20:11:28 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:11:28 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:11:28 --> Utf8 Class Initialized
INFO - 2017-06-22 20:11:28 --> URI Class Initialized
INFO - 2017-06-22 20:11:28 --> Router Class Initialized
INFO - 2017-06-22 20:11:28 --> Output Class Initialized
INFO - 2017-06-22 20:11:28 --> Security Class Initialized
DEBUG - 2017-06-22 20:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:11:28 --> Input Class Initialized
INFO - 2017-06-22 20:11:28 --> Language Class Initialized
INFO - 2017-06-22 20:11:28 --> Loader Class Initialized
INFO - 2017-06-22 20:11:28 --> Controller Class Initialized
INFO - 2017-06-22 20:11:28 --> Database Driver Class Initialized
INFO - 2017-06-22 20:11:28 --> Model Class Initialized
INFO - 2017-06-22 20:11:28 --> Helper loaded: form_helper
INFO - 2017-06-22 20:11:28 --> Helper loaded: url_helper
INFO - 2017-06-22 20:11:28 --> Model Class Initialized
INFO - 2017-06-22 20:11:28 --> Final output sent to browser
DEBUG - 2017-06-22 20:11:28 --> Total execution time: 0.0570
ERROR - 2017-06-22 20:11:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:11:46 --> Config Class Initialized
INFO - 2017-06-22 20:11:46 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:11:46 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:11:46 --> Utf8 Class Initialized
INFO - 2017-06-22 20:11:46 --> URI Class Initialized
INFO - 2017-06-22 20:11:46 --> Router Class Initialized
INFO - 2017-06-22 20:11:46 --> Output Class Initialized
INFO - 2017-06-22 20:11:46 --> Security Class Initialized
DEBUG - 2017-06-22 20:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:11:46 --> Input Class Initialized
INFO - 2017-06-22 20:11:46 --> Language Class Initialized
INFO - 2017-06-22 20:11:46 --> Loader Class Initialized
INFO - 2017-06-22 20:11:46 --> Controller Class Initialized
INFO - 2017-06-22 20:11:46 --> Database Driver Class Initialized
INFO - 2017-06-22 20:11:46 --> Model Class Initialized
INFO - 2017-06-22 20:11:46 --> Helper loaded: form_helper
INFO - 2017-06-22 20:11:46 --> Helper loaded: url_helper
INFO - 2017-06-22 20:11:46 --> Model Class Initialized
INFO - 2017-06-22 20:11:46 --> Final output sent to browser
DEBUG - 2017-06-22 20:11:46 --> Total execution time: 0.0480
ERROR - 2017-06-22 20:12:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:12:03 --> Config Class Initialized
INFO - 2017-06-22 20:12:03 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:12:03 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:12:03 --> Utf8 Class Initialized
INFO - 2017-06-22 20:12:03 --> URI Class Initialized
INFO - 2017-06-22 20:12:03 --> Router Class Initialized
INFO - 2017-06-22 20:12:03 --> Output Class Initialized
INFO - 2017-06-22 20:12:03 --> Security Class Initialized
DEBUG - 2017-06-22 20:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:12:03 --> Input Class Initialized
INFO - 2017-06-22 20:12:03 --> Language Class Initialized
INFO - 2017-06-22 20:12:03 --> Loader Class Initialized
INFO - 2017-06-22 20:12:03 --> Controller Class Initialized
INFO - 2017-06-22 20:12:03 --> Database Driver Class Initialized
INFO - 2017-06-22 20:12:03 --> Model Class Initialized
INFO - 2017-06-22 20:12:03 --> Helper loaded: form_helper
INFO - 2017-06-22 20:12:03 --> Helper loaded: url_helper
INFO - 2017-06-22 20:12:03 --> Model Class Initialized
INFO - 2017-06-22 20:12:03 --> Final output sent to browser
DEBUG - 2017-06-22 20:12:03 --> Total execution time: 0.0490
ERROR - 2017-06-22 20:12:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:12:42 --> Config Class Initialized
INFO - 2017-06-22 20:12:42 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:12:42 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:12:42 --> Utf8 Class Initialized
INFO - 2017-06-22 20:12:42 --> URI Class Initialized
INFO - 2017-06-22 20:12:42 --> Router Class Initialized
INFO - 2017-06-22 20:12:42 --> Output Class Initialized
INFO - 2017-06-22 20:12:42 --> Security Class Initialized
DEBUG - 2017-06-22 20:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:12:42 --> Input Class Initialized
INFO - 2017-06-22 20:12:42 --> Language Class Initialized
INFO - 2017-06-22 20:12:42 --> Loader Class Initialized
INFO - 2017-06-22 20:12:42 --> Controller Class Initialized
INFO - 2017-06-22 20:12:42 --> Database Driver Class Initialized
INFO - 2017-06-22 20:12:42 --> Model Class Initialized
INFO - 2017-06-22 20:12:42 --> Helper loaded: form_helper
INFO - 2017-06-22 20:12:42 --> Helper loaded: url_helper
INFO - 2017-06-22 20:12:42 --> Model Class Initialized
INFO - 2017-06-22 20:12:42 --> Final output sent to browser
DEBUG - 2017-06-22 20:12:42 --> Total execution time: 0.0665
ERROR - 2017-06-22 20:12:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:12:43 --> Config Class Initialized
INFO - 2017-06-22 20:12:43 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:12:43 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:12:43 --> Utf8 Class Initialized
INFO - 2017-06-22 20:12:43 --> URI Class Initialized
INFO - 2017-06-22 20:12:43 --> Router Class Initialized
INFO - 2017-06-22 20:12:43 --> Output Class Initialized
INFO - 2017-06-22 20:12:43 --> Security Class Initialized
DEBUG - 2017-06-22 20:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:12:43 --> Input Class Initialized
INFO - 2017-06-22 20:12:43 --> Language Class Initialized
INFO - 2017-06-22 20:12:43 --> Loader Class Initialized
INFO - 2017-06-22 20:12:43 --> Controller Class Initialized
INFO - 2017-06-22 20:12:43 --> Database Driver Class Initialized
INFO - 2017-06-22 20:12:43 --> Model Class Initialized
INFO - 2017-06-22 20:12:43 --> Helper loaded: form_helper
INFO - 2017-06-22 20:12:43 --> Helper loaded: url_helper
INFO - 2017-06-22 20:12:43 --> Model Class Initialized
INFO - 2017-06-22 20:12:43 --> Final output sent to browser
DEBUG - 2017-06-22 20:12:43 --> Total execution time: 0.0450
ERROR - 2017-06-22 20:12:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:12:57 --> Config Class Initialized
INFO - 2017-06-22 20:12:57 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:12:57 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:12:57 --> Utf8 Class Initialized
INFO - 2017-06-22 20:12:57 --> URI Class Initialized
INFO - 2017-06-22 20:12:57 --> Router Class Initialized
INFO - 2017-06-22 20:12:57 --> Output Class Initialized
INFO - 2017-06-22 20:12:57 --> Security Class Initialized
DEBUG - 2017-06-22 20:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:12:57 --> Input Class Initialized
INFO - 2017-06-22 20:12:57 --> Language Class Initialized
INFO - 2017-06-22 20:12:57 --> Loader Class Initialized
INFO - 2017-06-22 20:12:57 --> Controller Class Initialized
INFO - 2017-06-22 20:12:57 --> Database Driver Class Initialized
INFO - 2017-06-22 20:12:57 --> Model Class Initialized
INFO - 2017-06-22 20:12:57 --> Helper loaded: form_helper
INFO - 2017-06-22 20:12:57 --> Helper loaded: url_helper
INFO - 2017-06-22 20:12:57 --> Model Class Initialized
INFO - 2017-06-22 20:12:57 --> Final output sent to browser
DEBUG - 2017-06-22 20:12:57 --> Total execution time: 0.0635
ERROR - 2017-06-22 20:13:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:13:39 --> Config Class Initialized
INFO - 2017-06-22 20:13:39 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:13:39 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:13:39 --> Utf8 Class Initialized
INFO - 2017-06-22 20:13:39 --> URI Class Initialized
INFO - 2017-06-22 20:13:39 --> Router Class Initialized
INFO - 2017-06-22 20:13:39 --> Output Class Initialized
INFO - 2017-06-22 20:13:39 --> Security Class Initialized
DEBUG - 2017-06-22 20:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:13:39 --> Input Class Initialized
INFO - 2017-06-22 20:13:39 --> Language Class Initialized
INFO - 2017-06-22 20:13:39 --> Loader Class Initialized
INFO - 2017-06-22 20:13:39 --> Controller Class Initialized
INFO - 2017-06-22 20:13:39 --> Database Driver Class Initialized
INFO - 2017-06-22 20:13:39 --> Model Class Initialized
INFO - 2017-06-22 20:13:39 --> Helper loaded: form_helper
INFO - 2017-06-22 20:13:39 --> Helper loaded: url_helper
INFO - 2017-06-22 20:13:39 --> Model Class Initialized
INFO - 2017-06-22 20:13:39 --> Final output sent to browser
DEBUG - 2017-06-22 20:13:39 --> Total execution time: 0.0570
ERROR - 2017-06-22 20:14:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:14:01 --> Config Class Initialized
INFO - 2017-06-22 20:14:01 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:14:01 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:14:01 --> Utf8 Class Initialized
INFO - 2017-06-22 20:14:01 --> URI Class Initialized
INFO - 2017-06-22 20:14:01 --> Router Class Initialized
INFO - 2017-06-22 20:14:01 --> Output Class Initialized
INFO - 2017-06-22 20:14:01 --> Security Class Initialized
DEBUG - 2017-06-22 20:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:14:01 --> Input Class Initialized
INFO - 2017-06-22 20:14:01 --> Language Class Initialized
INFO - 2017-06-22 20:14:01 --> Loader Class Initialized
INFO - 2017-06-22 20:14:01 --> Controller Class Initialized
INFO - 2017-06-22 20:14:01 --> Database Driver Class Initialized
INFO - 2017-06-22 20:14:01 --> Model Class Initialized
INFO - 2017-06-22 20:14:01 --> Helper loaded: form_helper
INFO - 2017-06-22 20:14:01 --> Helper loaded: url_helper
INFO - 2017-06-22 20:14:01 --> Model Class Initialized
INFO - 2017-06-22 20:14:01 --> Final output sent to browser
DEBUG - 2017-06-22 20:14:01 --> Total execution time: 0.0480
ERROR - 2017-06-22 20:14:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:14:14 --> Config Class Initialized
INFO - 2017-06-22 20:14:14 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:14:14 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:14:14 --> Utf8 Class Initialized
INFO - 2017-06-22 20:14:14 --> URI Class Initialized
INFO - 2017-06-22 20:14:14 --> Router Class Initialized
INFO - 2017-06-22 20:14:14 --> Output Class Initialized
INFO - 2017-06-22 20:14:14 --> Security Class Initialized
DEBUG - 2017-06-22 20:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:14:14 --> Input Class Initialized
INFO - 2017-06-22 20:14:14 --> Language Class Initialized
INFO - 2017-06-22 20:14:14 --> Loader Class Initialized
INFO - 2017-06-22 20:14:14 --> Controller Class Initialized
INFO - 2017-06-22 20:14:14 --> Database Driver Class Initialized
INFO - 2017-06-22 20:14:14 --> Model Class Initialized
INFO - 2017-06-22 20:14:14 --> Helper loaded: form_helper
INFO - 2017-06-22 20:14:14 --> Helper loaded: url_helper
INFO - 2017-06-22 20:14:14 --> Model Class Initialized
INFO - 2017-06-22 20:14:14 --> Final output sent to browser
DEBUG - 2017-06-22 20:14:14 --> Total execution time: 0.0490
ERROR - 2017-06-22 20:14:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:14:27 --> Config Class Initialized
INFO - 2017-06-22 20:14:27 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:14:27 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:14:27 --> Utf8 Class Initialized
INFO - 2017-06-22 20:14:27 --> URI Class Initialized
INFO - 2017-06-22 20:14:27 --> Router Class Initialized
INFO - 2017-06-22 20:14:27 --> Output Class Initialized
INFO - 2017-06-22 20:14:27 --> Security Class Initialized
DEBUG - 2017-06-22 20:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:14:27 --> Input Class Initialized
INFO - 2017-06-22 20:14:27 --> Language Class Initialized
INFO - 2017-06-22 20:14:27 --> Loader Class Initialized
INFO - 2017-06-22 20:14:27 --> Controller Class Initialized
INFO - 2017-06-22 20:14:27 --> Database Driver Class Initialized
INFO - 2017-06-22 20:14:27 --> Model Class Initialized
INFO - 2017-06-22 20:14:27 --> Helper loaded: form_helper
INFO - 2017-06-22 20:14:27 --> Helper loaded: url_helper
INFO - 2017-06-22 20:14:27 --> Model Class Initialized
INFO - 2017-06-22 20:14:27 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:14:27 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:14:27 --> Final output sent to browser
DEBUG - 2017-06-22 20:14:27 --> Total execution time: 0.1260
ERROR - 2017-06-22 20:14:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:14:29 --> Config Class Initialized
INFO - 2017-06-22 20:14:29 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:14:29 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:14:29 --> Utf8 Class Initialized
INFO - 2017-06-22 20:14:29 --> URI Class Initialized
INFO - 2017-06-22 20:14:29 --> Router Class Initialized
INFO - 2017-06-22 20:14:29 --> Output Class Initialized
INFO - 2017-06-22 20:14:29 --> Security Class Initialized
DEBUG - 2017-06-22 20:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:14:29 --> Input Class Initialized
INFO - 2017-06-22 20:14:29 --> Language Class Initialized
INFO - 2017-06-22 20:14:29 --> Loader Class Initialized
INFO - 2017-06-22 20:14:29 --> Controller Class Initialized
INFO - 2017-06-22 20:14:29 --> Database Driver Class Initialized
INFO - 2017-06-22 20:14:29 --> Model Class Initialized
INFO - 2017-06-22 20:14:29 --> Helper loaded: form_helper
INFO - 2017-06-22 20:14:29 --> Helper loaded: url_helper
INFO - 2017-06-22 20:14:29 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:14:29 --> Model Class Initialized
INFO - 2017-06-22 20:14:29 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 20:14:29 --> Final output sent to browser
DEBUG - 2017-06-22 20:14:29 --> Total execution time: 0.0650
ERROR - 2017-06-22 20:14:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:14:33 --> Config Class Initialized
INFO - 2017-06-22 20:14:33 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:14:33 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:14:33 --> Utf8 Class Initialized
INFO - 2017-06-22 20:14:33 --> URI Class Initialized
INFO - 2017-06-22 20:14:33 --> Router Class Initialized
INFO - 2017-06-22 20:14:33 --> Output Class Initialized
INFO - 2017-06-22 20:14:33 --> Security Class Initialized
DEBUG - 2017-06-22 20:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:14:33 --> Input Class Initialized
INFO - 2017-06-22 20:14:33 --> Language Class Initialized
INFO - 2017-06-22 20:14:33 --> Loader Class Initialized
INFO - 2017-06-22 20:14:33 --> Controller Class Initialized
INFO - 2017-06-22 20:14:33 --> Database Driver Class Initialized
INFO - 2017-06-22 20:14:33 --> Model Class Initialized
INFO - 2017-06-22 20:14:33 --> Helper loaded: form_helper
INFO - 2017-06-22 20:14:33 --> Helper loaded: url_helper
INFO - 2017-06-22 20:14:33 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:14:33 --> Model Class Initialized
INFO - 2017-06-22 20:14:33 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:14:33 --> Final output sent to browser
DEBUG - 2017-06-22 20:14:33 --> Total execution time: 0.0750
ERROR - 2017-06-22 20:14:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:14:35 --> Config Class Initialized
INFO - 2017-06-22 20:14:35 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:14:35 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:14:35 --> Utf8 Class Initialized
INFO - 2017-06-22 20:14:35 --> URI Class Initialized
INFO - 2017-06-22 20:14:35 --> Router Class Initialized
INFO - 2017-06-22 20:14:35 --> Output Class Initialized
INFO - 2017-06-22 20:14:35 --> Security Class Initialized
DEBUG - 2017-06-22 20:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:14:35 --> Input Class Initialized
INFO - 2017-06-22 20:14:35 --> Language Class Initialized
INFO - 2017-06-22 20:14:35 --> Loader Class Initialized
INFO - 2017-06-22 20:14:35 --> Controller Class Initialized
INFO - 2017-06-22 20:14:35 --> Database Driver Class Initialized
INFO - 2017-06-22 20:14:35 --> Model Class Initialized
INFO - 2017-06-22 20:14:35 --> Helper loaded: form_helper
INFO - 2017-06-22 20:14:35 --> Helper loaded: url_helper
INFO - 2017-06-22 20:14:35 --> Model Class Initialized
INFO - 2017-06-22 20:14:35 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:14:35 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:14:35 --> Final output sent to browser
DEBUG - 2017-06-22 20:14:35 --> Total execution time: 0.0980
ERROR - 2017-06-22 20:14:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:14:37 --> Config Class Initialized
INFO - 2017-06-22 20:14:37 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:14:37 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:14:37 --> Utf8 Class Initialized
INFO - 2017-06-22 20:14:37 --> URI Class Initialized
INFO - 2017-06-22 20:14:37 --> Router Class Initialized
INFO - 2017-06-22 20:14:37 --> Output Class Initialized
INFO - 2017-06-22 20:14:37 --> Security Class Initialized
DEBUG - 2017-06-22 20:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:14:37 --> Input Class Initialized
INFO - 2017-06-22 20:14:37 --> Language Class Initialized
INFO - 2017-06-22 20:14:37 --> Loader Class Initialized
INFO - 2017-06-22 20:14:37 --> Controller Class Initialized
INFO - 2017-06-22 20:14:37 --> Database Driver Class Initialized
INFO - 2017-06-22 20:14:37 --> Model Class Initialized
INFO - 2017-06-22 20:14:37 --> Helper loaded: form_helper
INFO - 2017-06-22 20:14:37 --> Helper loaded: url_helper
INFO - 2017-06-22 20:14:37 --> Model Class Initialized
INFO - 2017-06-22 20:14:37 --> Final output sent to browser
DEBUG - 2017-06-22 20:14:37 --> Total execution time: 0.0750
ERROR - 2017-06-22 20:14:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:14:37 --> Config Class Initialized
INFO - 2017-06-22 20:14:37 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:14:37 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:14:37 --> Utf8 Class Initialized
INFO - 2017-06-22 20:14:37 --> URI Class Initialized
INFO - 2017-06-22 20:14:37 --> Router Class Initialized
INFO - 2017-06-22 20:14:37 --> Output Class Initialized
INFO - 2017-06-22 20:14:37 --> Security Class Initialized
DEBUG - 2017-06-22 20:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:14:37 --> Input Class Initialized
INFO - 2017-06-22 20:14:37 --> Language Class Initialized
INFO - 2017-06-22 20:14:37 --> Loader Class Initialized
INFO - 2017-06-22 20:14:37 --> Controller Class Initialized
INFO - 2017-06-22 20:14:37 --> Database Driver Class Initialized
INFO - 2017-06-22 20:14:37 --> Model Class Initialized
INFO - 2017-06-22 20:14:37 --> Helper loaded: form_helper
INFO - 2017-06-22 20:14:37 --> Helper loaded: url_helper
INFO - 2017-06-22 20:14:37 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:14:37 --> Model Class Initialized
INFO - 2017-06-22 20:14:37 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 20:14:37 --> Final output sent to browser
DEBUG - 2017-06-22 20:14:37 --> Total execution time: 0.0490
ERROR - 2017-06-22 20:14:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:14:38 --> Config Class Initialized
INFO - 2017-06-22 20:14:38 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:14:38 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:14:38 --> Utf8 Class Initialized
INFO - 2017-06-22 20:14:38 --> URI Class Initialized
INFO - 2017-06-22 20:14:38 --> Router Class Initialized
INFO - 2017-06-22 20:14:38 --> Output Class Initialized
INFO - 2017-06-22 20:14:38 --> Security Class Initialized
DEBUG - 2017-06-22 20:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:14:38 --> Input Class Initialized
INFO - 2017-06-22 20:14:38 --> Language Class Initialized
INFO - 2017-06-22 20:14:38 --> Loader Class Initialized
INFO - 2017-06-22 20:14:38 --> Controller Class Initialized
INFO - 2017-06-22 20:14:38 --> Database Driver Class Initialized
INFO - 2017-06-22 20:14:38 --> Model Class Initialized
INFO - 2017-06-22 20:14:38 --> Helper loaded: form_helper
INFO - 2017-06-22 20:14:38 --> Helper loaded: url_helper
INFO - 2017-06-22 20:14:38 --> Model Class Initialized
INFO - 2017-06-22 20:14:38 --> Final output sent to browser
DEBUG - 2017-06-22 20:14:38 --> Total execution time: 0.0460
ERROR - 2017-06-22 20:14:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:14:39 --> Config Class Initialized
INFO - 2017-06-22 20:14:39 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:14:39 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:14:39 --> Utf8 Class Initialized
INFO - 2017-06-22 20:14:39 --> URI Class Initialized
INFO - 2017-06-22 20:14:39 --> Router Class Initialized
INFO - 2017-06-22 20:14:39 --> Output Class Initialized
INFO - 2017-06-22 20:14:39 --> Security Class Initialized
DEBUG - 2017-06-22 20:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:14:39 --> Input Class Initialized
INFO - 2017-06-22 20:14:39 --> Language Class Initialized
INFO - 2017-06-22 20:14:39 --> Loader Class Initialized
INFO - 2017-06-22 20:14:39 --> Controller Class Initialized
INFO - 2017-06-22 20:14:39 --> Database Driver Class Initialized
INFO - 2017-06-22 20:14:39 --> Model Class Initialized
INFO - 2017-06-22 20:14:39 --> Helper loaded: form_helper
INFO - 2017-06-22 20:14:39 --> Helper loaded: url_helper
INFO - 2017-06-22 20:14:39 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:14:39 --> Model Class Initialized
INFO - 2017-06-22 20:14:39 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:14:39 --> Final output sent to browser
DEBUG - 2017-06-22 20:14:39 --> Total execution time: 0.0680
ERROR - 2017-06-22 20:14:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:14:41 --> Config Class Initialized
INFO - 2017-06-22 20:14:41 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:14:41 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:14:41 --> Utf8 Class Initialized
INFO - 2017-06-22 20:14:41 --> URI Class Initialized
INFO - 2017-06-22 20:14:41 --> Router Class Initialized
INFO - 2017-06-22 20:14:41 --> Output Class Initialized
INFO - 2017-06-22 20:14:41 --> Security Class Initialized
DEBUG - 2017-06-22 20:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:14:41 --> Input Class Initialized
INFO - 2017-06-22 20:14:41 --> Language Class Initialized
INFO - 2017-06-22 20:14:41 --> Loader Class Initialized
INFO - 2017-06-22 20:14:41 --> Controller Class Initialized
INFO - 2017-06-22 20:14:41 --> Database Driver Class Initialized
INFO - 2017-06-22 20:14:41 --> Model Class Initialized
INFO - 2017-06-22 20:14:41 --> Helper loaded: form_helper
INFO - 2017-06-22 20:14:41 --> Helper loaded: url_helper
INFO - 2017-06-22 20:14:41 --> Model Class Initialized
INFO - 2017-06-22 20:14:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:14:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:14:41 --> Final output sent to browser
DEBUG - 2017-06-22 20:14:41 --> Total execution time: 0.0730
ERROR - 2017-06-22 20:14:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:14:46 --> Config Class Initialized
INFO - 2017-06-22 20:14:46 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:14:46 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:14:46 --> Utf8 Class Initialized
INFO - 2017-06-22 20:14:46 --> URI Class Initialized
INFO - 2017-06-22 20:14:46 --> Router Class Initialized
INFO - 2017-06-22 20:14:46 --> Output Class Initialized
INFO - 2017-06-22 20:14:46 --> Security Class Initialized
DEBUG - 2017-06-22 20:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:14:46 --> Input Class Initialized
INFO - 2017-06-22 20:14:46 --> Language Class Initialized
INFO - 2017-06-22 20:14:46 --> Loader Class Initialized
INFO - 2017-06-22 20:14:46 --> Controller Class Initialized
INFO - 2017-06-22 20:14:46 --> Database Driver Class Initialized
INFO - 2017-06-22 20:14:46 --> Model Class Initialized
INFO - 2017-06-22 20:14:46 --> Helper loaded: form_helper
INFO - 2017-06-22 20:14:46 --> Helper loaded: url_helper
INFO - 2017-06-22 20:14:46 --> Model Class Initialized
INFO - 2017-06-22 20:14:46 --> Final output sent to browser
DEBUG - 2017-06-22 20:14:46 --> Total execution time: 0.0460
ERROR - 2017-06-22 20:14:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:14:47 --> Config Class Initialized
INFO - 2017-06-22 20:14:47 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:14:47 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:14:47 --> Utf8 Class Initialized
INFO - 2017-06-22 20:14:47 --> URI Class Initialized
INFO - 2017-06-22 20:14:47 --> Router Class Initialized
INFO - 2017-06-22 20:14:47 --> Output Class Initialized
INFO - 2017-06-22 20:14:47 --> Security Class Initialized
DEBUG - 2017-06-22 20:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:14:47 --> Input Class Initialized
INFO - 2017-06-22 20:14:47 --> Language Class Initialized
INFO - 2017-06-22 20:14:47 --> Loader Class Initialized
INFO - 2017-06-22 20:14:47 --> Controller Class Initialized
INFO - 2017-06-22 20:14:47 --> Database Driver Class Initialized
INFO - 2017-06-22 20:14:47 --> Model Class Initialized
INFO - 2017-06-22 20:14:47 --> Helper loaded: form_helper
INFO - 2017-06-22 20:14:47 --> Helper loaded: url_helper
INFO - 2017-06-22 20:14:47 --> Model Class Initialized
INFO - 2017-06-22 20:14:47 --> Final output sent to browser
DEBUG - 2017-06-22 20:14:47 --> Total execution time: 0.0490
ERROR - 2017-06-22 20:14:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:14:48 --> Config Class Initialized
INFO - 2017-06-22 20:14:48 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:14:48 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:14:48 --> Utf8 Class Initialized
INFO - 2017-06-22 20:14:48 --> URI Class Initialized
INFO - 2017-06-22 20:14:48 --> Router Class Initialized
INFO - 2017-06-22 20:14:48 --> Output Class Initialized
INFO - 2017-06-22 20:14:48 --> Security Class Initialized
DEBUG - 2017-06-22 20:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:14:48 --> Input Class Initialized
INFO - 2017-06-22 20:14:48 --> Language Class Initialized
INFO - 2017-06-22 20:14:48 --> Loader Class Initialized
INFO - 2017-06-22 20:14:48 --> Controller Class Initialized
INFO - 2017-06-22 20:14:48 --> Database Driver Class Initialized
INFO - 2017-06-22 20:14:48 --> Model Class Initialized
INFO - 2017-06-22 20:14:48 --> Helper loaded: form_helper
INFO - 2017-06-22 20:14:48 --> Helper loaded: url_helper
INFO - 2017-06-22 20:14:48 --> Model Class Initialized
INFO - 2017-06-22 20:14:48 --> Final output sent to browser
DEBUG - 2017-06-22 20:14:48 --> Total execution time: 0.0510
ERROR - 2017-06-22 20:14:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:14:51 --> Config Class Initialized
INFO - 2017-06-22 20:14:51 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:14:51 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:14:51 --> Utf8 Class Initialized
INFO - 2017-06-22 20:14:51 --> URI Class Initialized
INFO - 2017-06-22 20:14:51 --> Router Class Initialized
INFO - 2017-06-22 20:14:51 --> Output Class Initialized
INFO - 2017-06-22 20:14:51 --> Security Class Initialized
DEBUG - 2017-06-22 20:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:14:51 --> Input Class Initialized
INFO - 2017-06-22 20:14:51 --> Language Class Initialized
INFO - 2017-06-22 20:14:51 --> Loader Class Initialized
INFO - 2017-06-22 20:14:51 --> Controller Class Initialized
INFO - 2017-06-22 20:14:51 --> Database Driver Class Initialized
INFO - 2017-06-22 20:14:51 --> Model Class Initialized
INFO - 2017-06-22 20:14:51 --> Helper loaded: form_helper
INFO - 2017-06-22 20:14:51 --> Helper loaded: url_helper
INFO - 2017-06-22 20:14:51 --> Model Class Initialized
INFO - 2017-06-22 20:14:51 --> Final output sent to browser
DEBUG - 2017-06-22 20:14:51 --> Total execution time: 0.0470
ERROR - 2017-06-22 20:14:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:14:52 --> Config Class Initialized
INFO - 2017-06-22 20:14:52 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:14:52 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:14:52 --> Utf8 Class Initialized
INFO - 2017-06-22 20:14:52 --> URI Class Initialized
INFO - 2017-06-22 20:14:52 --> Router Class Initialized
INFO - 2017-06-22 20:14:52 --> Output Class Initialized
INFO - 2017-06-22 20:14:52 --> Security Class Initialized
DEBUG - 2017-06-22 20:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:14:52 --> Input Class Initialized
INFO - 2017-06-22 20:14:52 --> Language Class Initialized
INFO - 2017-06-22 20:14:52 --> Loader Class Initialized
INFO - 2017-06-22 20:14:52 --> Controller Class Initialized
INFO - 2017-06-22 20:14:52 --> Database Driver Class Initialized
INFO - 2017-06-22 20:14:52 --> Model Class Initialized
INFO - 2017-06-22 20:14:52 --> Helper loaded: form_helper
INFO - 2017-06-22 20:14:52 --> Helper loaded: url_helper
INFO - 2017-06-22 20:14:52 --> Model Class Initialized
INFO - 2017-06-22 20:14:52 --> Final output sent to browser
DEBUG - 2017-06-22 20:14:52 --> Total execution time: 0.0560
ERROR - 2017-06-22 20:14:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:14:54 --> Config Class Initialized
INFO - 2017-06-22 20:14:54 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:14:54 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:14:54 --> Utf8 Class Initialized
INFO - 2017-06-22 20:14:54 --> URI Class Initialized
INFO - 2017-06-22 20:14:54 --> Router Class Initialized
INFO - 2017-06-22 20:14:54 --> Output Class Initialized
INFO - 2017-06-22 20:14:54 --> Security Class Initialized
DEBUG - 2017-06-22 20:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:14:54 --> Input Class Initialized
INFO - 2017-06-22 20:14:54 --> Language Class Initialized
INFO - 2017-06-22 20:14:54 --> Loader Class Initialized
INFO - 2017-06-22 20:14:54 --> Controller Class Initialized
INFO - 2017-06-22 20:14:54 --> Database Driver Class Initialized
INFO - 2017-06-22 20:14:54 --> Model Class Initialized
INFO - 2017-06-22 20:14:54 --> Helper loaded: form_helper
INFO - 2017-06-22 20:14:54 --> Helper loaded: url_helper
INFO - 2017-06-22 20:14:54 --> Model Class Initialized
INFO - 2017-06-22 20:14:54 --> Final output sent to browser
DEBUG - 2017-06-22 20:14:54 --> Total execution time: 0.0560
ERROR - 2017-06-22 20:15:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:15:29 --> Config Class Initialized
INFO - 2017-06-22 20:15:29 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:15:29 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:15:29 --> Utf8 Class Initialized
INFO - 2017-06-22 20:15:29 --> URI Class Initialized
INFO - 2017-06-22 20:15:29 --> Router Class Initialized
INFO - 2017-06-22 20:15:29 --> Output Class Initialized
INFO - 2017-06-22 20:15:29 --> Security Class Initialized
DEBUG - 2017-06-22 20:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:15:29 --> Input Class Initialized
INFO - 2017-06-22 20:15:29 --> Language Class Initialized
INFO - 2017-06-22 20:15:29 --> Loader Class Initialized
INFO - 2017-06-22 20:15:29 --> Controller Class Initialized
INFO - 2017-06-22 20:15:29 --> Database Driver Class Initialized
INFO - 2017-06-22 20:15:29 --> Model Class Initialized
INFO - 2017-06-22 20:15:29 --> Helper loaded: form_helper
INFO - 2017-06-22 20:15:29 --> Helper loaded: url_helper
INFO - 2017-06-22 20:15:29 --> Model Class Initialized
INFO - 2017-06-22 20:15:29 --> Final output sent to browser
DEBUG - 2017-06-22 20:15:29 --> Total execution time: 0.0560
ERROR - 2017-06-22 20:15:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:15:54 --> Config Class Initialized
INFO - 2017-06-22 20:15:54 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:15:54 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:15:54 --> Utf8 Class Initialized
INFO - 2017-06-22 20:15:54 --> URI Class Initialized
INFO - 2017-06-22 20:15:54 --> Router Class Initialized
INFO - 2017-06-22 20:15:54 --> Output Class Initialized
INFO - 2017-06-22 20:15:54 --> Security Class Initialized
DEBUG - 2017-06-22 20:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:15:54 --> Input Class Initialized
INFO - 2017-06-22 20:15:54 --> Language Class Initialized
INFO - 2017-06-22 20:15:54 --> Loader Class Initialized
INFO - 2017-06-22 20:15:54 --> Controller Class Initialized
INFO - 2017-06-22 20:15:54 --> Database Driver Class Initialized
INFO - 2017-06-22 20:15:54 --> Model Class Initialized
INFO - 2017-06-22 20:15:54 --> Helper loaded: form_helper
INFO - 2017-06-22 20:15:54 --> Helper loaded: url_helper
INFO - 2017-06-22 20:15:54 --> Model Class Initialized
INFO - 2017-06-22 20:15:54 --> Final output sent to browser
DEBUG - 2017-06-22 20:15:54 --> Total execution time: 0.0490
ERROR - 2017-06-22 20:16:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:16:15 --> Config Class Initialized
INFO - 2017-06-22 20:16:15 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:16:15 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:16:15 --> Utf8 Class Initialized
INFO - 2017-06-22 20:16:15 --> URI Class Initialized
INFO - 2017-06-22 20:16:15 --> Router Class Initialized
INFO - 2017-06-22 20:16:15 --> Output Class Initialized
INFO - 2017-06-22 20:16:15 --> Security Class Initialized
DEBUG - 2017-06-22 20:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:16:15 --> Input Class Initialized
INFO - 2017-06-22 20:16:15 --> Language Class Initialized
INFO - 2017-06-22 20:16:15 --> Loader Class Initialized
INFO - 2017-06-22 20:16:15 --> Controller Class Initialized
INFO - 2017-06-22 20:16:15 --> Database Driver Class Initialized
INFO - 2017-06-22 20:16:15 --> Model Class Initialized
INFO - 2017-06-22 20:16:15 --> Helper loaded: form_helper
INFO - 2017-06-22 20:16:15 --> Helper loaded: url_helper
INFO - 2017-06-22 20:16:15 --> Model Class Initialized
INFO - 2017-06-22 20:16:15 --> Final output sent to browser
DEBUG - 2017-06-22 20:16:15 --> Total execution time: 0.0440
ERROR - 2017-06-22 20:16:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:16:50 --> Config Class Initialized
INFO - 2017-06-22 20:16:50 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:16:50 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:16:50 --> Utf8 Class Initialized
INFO - 2017-06-22 20:16:50 --> URI Class Initialized
INFO - 2017-06-22 20:16:50 --> Router Class Initialized
INFO - 2017-06-22 20:16:50 --> Output Class Initialized
INFO - 2017-06-22 20:16:50 --> Security Class Initialized
DEBUG - 2017-06-22 20:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:16:50 --> Input Class Initialized
INFO - 2017-06-22 20:16:50 --> Language Class Initialized
INFO - 2017-06-22 20:16:50 --> Loader Class Initialized
INFO - 2017-06-22 20:16:50 --> Controller Class Initialized
INFO - 2017-06-22 20:16:50 --> Database Driver Class Initialized
INFO - 2017-06-22 20:16:50 --> Model Class Initialized
INFO - 2017-06-22 20:16:50 --> Helper loaded: form_helper
INFO - 2017-06-22 20:16:50 --> Helper loaded: url_helper
INFO - 2017-06-22 20:16:50 --> Model Class Initialized
INFO - 2017-06-22 20:16:50 --> Final output sent to browser
DEBUG - 2017-06-22 20:16:50 --> Total execution time: 0.0730
ERROR - 2017-06-22 20:17:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:17:21 --> Config Class Initialized
INFO - 2017-06-22 20:17:21 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:17:21 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:17:21 --> Utf8 Class Initialized
INFO - 2017-06-22 20:17:21 --> URI Class Initialized
INFO - 2017-06-22 20:17:21 --> Router Class Initialized
INFO - 2017-06-22 20:17:21 --> Output Class Initialized
INFO - 2017-06-22 20:17:21 --> Security Class Initialized
DEBUG - 2017-06-22 20:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:17:21 --> Input Class Initialized
INFO - 2017-06-22 20:17:21 --> Language Class Initialized
INFO - 2017-06-22 20:17:21 --> Loader Class Initialized
INFO - 2017-06-22 20:17:21 --> Controller Class Initialized
INFO - 2017-06-22 20:17:21 --> Database Driver Class Initialized
INFO - 2017-06-22 20:17:21 --> Model Class Initialized
INFO - 2017-06-22 20:17:21 --> Helper loaded: form_helper
INFO - 2017-06-22 20:17:21 --> Helper loaded: url_helper
INFO - 2017-06-22 20:17:21 --> Model Class Initialized
INFO - 2017-06-22 20:17:21 --> Final output sent to browser
DEBUG - 2017-06-22 20:17:21 --> Total execution time: 0.0555
ERROR - 2017-06-22 20:17:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:17:22 --> Config Class Initialized
INFO - 2017-06-22 20:17:22 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:17:22 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:17:22 --> Utf8 Class Initialized
INFO - 2017-06-22 20:17:22 --> URI Class Initialized
INFO - 2017-06-22 20:17:22 --> Router Class Initialized
INFO - 2017-06-22 20:17:22 --> Output Class Initialized
INFO - 2017-06-22 20:17:22 --> Security Class Initialized
DEBUG - 2017-06-22 20:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:17:22 --> Input Class Initialized
INFO - 2017-06-22 20:17:22 --> Language Class Initialized
INFO - 2017-06-22 20:17:22 --> Loader Class Initialized
INFO - 2017-06-22 20:17:22 --> Controller Class Initialized
INFO - 2017-06-22 20:17:22 --> Database Driver Class Initialized
INFO - 2017-06-22 20:17:22 --> Model Class Initialized
INFO - 2017-06-22 20:17:22 --> Helper loaded: form_helper
INFO - 2017-06-22 20:17:22 --> Helper loaded: url_helper
INFO - 2017-06-22 20:17:22 --> Model Class Initialized
INFO - 2017-06-22 20:17:22 --> Final output sent to browser
DEBUG - 2017-06-22 20:17:22 --> Total execution time: 0.0450
ERROR - 2017-06-22 20:17:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:17:24 --> Config Class Initialized
INFO - 2017-06-22 20:17:24 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:17:24 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:17:24 --> Utf8 Class Initialized
INFO - 2017-06-22 20:17:24 --> URI Class Initialized
INFO - 2017-06-22 20:17:24 --> Router Class Initialized
INFO - 2017-06-22 20:17:24 --> Output Class Initialized
INFO - 2017-06-22 20:17:24 --> Security Class Initialized
DEBUG - 2017-06-22 20:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:17:24 --> Input Class Initialized
INFO - 2017-06-22 20:17:24 --> Language Class Initialized
INFO - 2017-06-22 20:17:24 --> Loader Class Initialized
INFO - 2017-06-22 20:17:24 --> Controller Class Initialized
INFO - 2017-06-22 20:17:24 --> Database Driver Class Initialized
INFO - 2017-06-22 20:17:24 --> Model Class Initialized
INFO - 2017-06-22 20:17:24 --> Helper loaded: form_helper
INFO - 2017-06-22 20:17:24 --> Helper loaded: url_helper
INFO - 2017-06-22 20:17:24 --> Model Class Initialized
INFO - 2017-06-22 20:17:24 --> Final output sent to browser
DEBUG - 2017-06-22 20:17:24 --> Total execution time: 0.0620
ERROR - 2017-06-22 20:17:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:17:27 --> Config Class Initialized
INFO - 2017-06-22 20:17:27 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:17:27 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:17:27 --> Utf8 Class Initialized
INFO - 2017-06-22 20:17:27 --> URI Class Initialized
INFO - 2017-06-22 20:17:27 --> Router Class Initialized
INFO - 2017-06-22 20:17:27 --> Output Class Initialized
INFO - 2017-06-22 20:17:27 --> Security Class Initialized
DEBUG - 2017-06-22 20:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:17:27 --> Input Class Initialized
INFO - 2017-06-22 20:17:27 --> Language Class Initialized
INFO - 2017-06-22 20:17:27 --> Loader Class Initialized
INFO - 2017-06-22 20:17:27 --> Controller Class Initialized
INFO - 2017-06-22 20:17:27 --> Database Driver Class Initialized
INFO - 2017-06-22 20:17:27 --> Model Class Initialized
INFO - 2017-06-22 20:17:27 --> Helper loaded: form_helper
INFO - 2017-06-22 20:17:27 --> Helper loaded: url_helper
INFO - 2017-06-22 20:17:27 --> Model Class Initialized
INFO - 2017-06-22 20:17:27 --> Final output sent to browser
DEBUG - 2017-06-22 20:17:27 --> Total execution time: 0.0580
ERROR - 2017-06-22 20:17:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:17:52 --> Config Class Initialized
INFO - 2017-06-22 20:17:52 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:17:52 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:17:52 --> Utf8 Class Initialized
INFO - 2017-06-22 20:17:52 --> URI Class Initialized
INFO - 2017-06-22 20:17:52 --> Router Class Initialized
INFO - 2017-06-22 20:17:52 --> Output Class Initialized
INFO - 2017-06-22 20:17:52 --> Security Class Initialized
DEBUG - 2017-06-22 20:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:17:52 --> Input Class Initialized
INFO - 2017-06-22 20:17:52 --> Language Class Initialized
INFO - 2017-06-22 20:17:52 --> Loader Class Initialized
INFO - 2017-06-22 20:17:52 --> Controller Class Initialized
INFO - 2017-06-22 20:17:52 --> Database Driver Class Initialized
INFO - 2017-06-22 20:17:52 --> Model Class Initialized
INFO - 2017-06-22 20:17:52 --> Helper loaded: form_helper
INFO - 2017-06-22 20:17:52 --> Helper loaded: url_helper
INFO - 2017-06-22 20:17:52 --> Model Class Initialized
INFO - 2017-06-22 20:17:52 --> Final output sent to browser
DEBUG - 2017-06-22 20:17:52 --> Total execution time: 0.0620
ERROR - 2017-06-22 20:19:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:19:11 --> Config Class Initialized
INFO - 2017-06-22 20:19:11 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:19:11 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:19:11 --> Utf8 Class Initialized
INFO - 2017-06-22 20:19:11 --> URI Class Initialized
INFO - 2017-06-22 20:19:11 --> Router Class Initialized
INFO - 2017-06-22 20:19:11 --> Output Class Initialized
INFO - 2017-06-22 20:19:11 --> Security Class Initialized
DEBUG - 2017-06-22 20:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:19:11 --> Input Class Initialized
INFO - 2017-06-22 20:19:11 --> Language Class Initialized
INFO - 2017-06-22 20:19:11 --> Loader Class Initialized
INFO - 2017-06-22 20:19:11 --> Controller Class Initialized
INFO - 2017-06-22 20:19:11 --> Database Driver Class Initialized
INFO - 2017-06-22 20:19:11 --> Model Class Initialized
INFO - 2017-06-22 20:19:11 --> Helper loaded: form_helper
INFO - 2017-06-22 20:19:11 --> Helper loaded: url_helper
INFO - 2017-06-22 20:19:11 --> Model Class Initialized
INFO - 2017-06-22 20:19:11 --> Final output sent to browser
DEBUG - 2017-06-22 20:19:11 --> Total execution time: 0.0600
ERROR - 2017-06-22 20:20:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:20:27 --> Config Class Initialized
INFO - 2017-06-22 20:20:27 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:20:27 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:20:27 --> Utf8 Class Initialized
INFO - 2017-06-22 20:20:27 --> URI Class Initialized
INFO - 2017-06-22 20:20:27 --> Router Class Initialized
INFO - 2017-06-22 20:20:27 --> Output Class Initialized
INFO - 2017-06-22 20:20:27 --> Security Class Initialized
DEBUG - 2017-06-22 20:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:20:27 --> Input Class Initialized
INFO - 2017-06-22 20:20:27 --> Language Class Initialized
INFO - 2017-06-22 20:20:27 --> Loader Class Initialized
INFO - 2017-06-22 20:20:27 --> Controller Class Initialized
INFO - 2017-06-22 20:20:27 --> Database Driver Class Initialized
INFO - 2017-06-22 20:20:27 --> Model Class Initialized
INFO - 2017-06-22 20:20:27 --> Helper loaded: form_helper
INFO - 2017-06-22 20:20:27 --> Helper loaded: url_helper
INFO - 2017-06-22 20:20:27 --> Model Class Initialized
INFO - 2017-06-22 20:20:27 --> Final output sent to browser
DEBUG - 2017-06-22 20:20:27 --> Total execution time: 0.0540
ERROR - 2017-06-22 20:20:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:20:29 --> Config Class Initialized
INFO - 2017-06-22 20:20:29 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:20:29 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:20:29 --> Utf8 Class Initialized
INFO - 2017-06-22 20:20:29 --> URI Class Initialized
INFO - 2017-06-22 20:20:29 --> Router Class Initialized
INFO - 2017-06-22 20:20:29 --> Output Class Initialized
INFO - 2017-06-22 20:20:29 --> Security Class Initialized
DEBUG - 2017-06-22 20:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:20:29 --> Input Class Initialized
INFO - 2017-06-22 20:20:29 --> Language Class Initialized
INFO - 2017-06-22 20:20:29 --> Loader Class Initialized
INFO - 2017-06-22 20:20:29 --> Controller Class Initialized
INFO - 2017-06-22 20:20:29 --> Database Driver Class Initialized
INFO - 2017-06-22 20:20:29 --> Model Class Initialized
INFO - 2017-06-22 20:20:29 --> Helper loaded: form_helper
INFO - 2017-06-22 20:20:29 --> Helper loaded: url_helper
INFO - 2017-06-22 20:20:29 --> Model Class Initialized
INFO - 2017-06-22 20:20:29 --> Final output sent to browser
DEBUG - 2017-06-22 20:20:29 --> Total execution time: 0.0580
ERROR - 2017-06-22 20:20:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:20:32 --> Config Class Initialized
INFO - 2017-06-22 20:20:32 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:20:32 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:20:32 --> Utf8 Class Initialized
INFO - 2017-06-22 20:20:32 --> URI Class Initialized
INFO - 2017-06-22 20:20:32 --> Router Class Initialized
INFO - 2017-06-22 20:20:32 --> Output Class Initialized
INFO - 2017-06-22 20:20:32 --> Security Class Initialized
DEBUG - 2017-06-22 20:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:20:32 --> Input Class Initialized
INFO - 2017-06-22 20:20:32 --> Language Class Initialized
INFO - 2017-06-22 20:20:32 --> Loader Class Initialized
INFO - 2017-06-22 20:20:32 --> Controller Class Initialized
INFO - 2017-06-22 20:20:32 --> Database Driver Class Initialized
INFO - 2017-06-22 20:20:32 --> Model Class Initialized
INFO - 2017-06-22 20:20:32 --> Helper loaded: form_helper
INFO - 2017-06-22 20:20:32 --> Helper loaded: url_helper
INFO - 2017-06-22 20:20:32 --> Model Class Initialized
INFO - 2017-06-22 20:20:32 --> Final output sent to browser
DEBUG - 2017-06-22 20:20:32 --> Total execution time: 0.0750
ERROR - 2017-06-22 20:20:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:20:55 --> Config Class Initialized
INFO - 2017-06-22 20:20:55 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:20:55 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:20:55 --> Utf8 Class Initialized
INFO - 2017-06-22 20:20:55 --> URI Class Initialized
INFO - 2017-06-22 20:20:55 --> Router Class Initialized
INFO - 2017-06-22 20:20:55 --> Output Class Initialized
INFO - 2017-06-22 20:20:55 --> Security Class Initialized
DEBUG - 2017-06-22 20:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:20:55 --> Input Class Initialized
INFO - 2017-06-22 20:20:55 --> Language Class Initialized
INFO - 2017-06-22 20:20:55 --> Loader Class Initialized
INFO - 2017-06-22 20:20:55 --> Controller Class Initialized
INFO - 2017-06-22 20:20:55 --> Database Driver Class Initialized
INFO - 2017-06-22 20:20:55 --> Model Class Initialized
INFO - 2017-06-22 20:20:55 --> Helper loaded: form_helper
INFO - 2017-06-22 20:20:55 --> Helper loaded: url_helper
INFO - 2017-06-22 20:20:55 --> Model Class Initialized
INFO - 2017-06-22 20:20:55 --> Final output sent to browser
DEBUG - 2017-06-22 20:20:55 --> Total execution time: 0.0560
ERROR - 2017-06-22 20:21:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:21:14 --> Config Class Initialized
INFO - 2017-06-22 20:21:14 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:21:14 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:21:14 --> Utf8 Class Initialized
INFO - 2017-06-22 20:21:14 --> URI Class Initialized
INFO - 2017-06-22 20:21:14 --> Router Class Initialized
INFO - 2017-06-22 20:21:14 --> Output Class Initialized
INFO - 2017-06-22 20:21:14 --> Security Class Initialized
DEBUG - 2017-06-22 20:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:21:14 --> Input Class Initialized
INFO - 2017-06-22 20:21:14 --> Language Class Initialized
INFO - 2017-06-22 20:21:14 --> Loader Class Initialized
INFO - 2017-06-22 20:21:14 --> Controller Class Initialized
INFO - 2017-06-22 20:21:14 --> Database Driver Class Initialized
INFO - 2017-06-22 20:21:14 --> Model Class Initialized
INFO - 2017-06-22 20:21:14 --> Helper loaded: form_helper
INFO - 2017-06-22 20:21:14 --> Helper loaded: url_helper
INFO - 2017-06-22 20:21:14 --> Model Class Initialized
INFO - 2017-06-22 20:21:14 --> Final output sent to browser
DEBUG - 2017-06-22 20:21:14 --> Total execution time: 0.0570
ERROR - 2017-06-22 20:28:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:28:25 --> Config Class Initialized
INFO - 2017-06-22 20:28:25 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:28:25 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:28:25 --> Utf8 Class Initialized
INFO - 2017-06-22 20:28:25 --> URI Class Initialized
INFO - 2017-06-22 20:28:25 --> Router Class Initialized
INFO - 2017-06-22 20:28:25 --> Output Class Initialized
INFO - 2017-06-22 20:28:25 --> Security Class Initialized
DEBUG - 2017-06-22 20:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:28:25 --> Input Class Initialized
INFO - 2017-06-22 20:28:25 --> Language Class Initialized
INFO - 2017-06-22 20:28:25 --> Loader Class Initialized
INFO - 2017-06-22 20:28:25 --> Controller Class Initialized
INFO - 2017-06-22 20:28:25 --> Database Driver Class Initialized
INFO - 2017-06-22 20:28:25 --> Model Class Initialized
INFO - 2017-06-22 20:28:25 --> Helper loaded: form_helper
INFO - 2017-06-22 20:28:25 --> Helper loaded: url_helper
INFO - 2017-06-22 20:28:25 --> Model Class Initialized
INFO - 2017-06-22 20:28:25 --> Final output sent to browser
DEBUG - 2017-06-22 20:28:25 --> Total execution time: 0.0735
ERROR - 2017-06-22 20:34:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:34:26 --> Config Class Initialized
INFO - 2017-06-22 20:34:26 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:34:26 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:34:26 --> Utf8 Class Initialized
INFO - 2017-06-22 20:34:26 --> URI Class Initialized
INFO - 2017-06-22 20:34:26 --> Router Class Initialized
INFO - 2017-06-22 20:34:26 --> Output Class Initialized
INFO - 2017-06-22 20:34:26 --> Security Class Initialized
DEBUG - 2017-06-22 20:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:34:26 --> Input Class Initialized
INFO - 2017-06-22 20:34:26 --> Language Class Initialized
INFO - 2017-06-22 20:34:26 --> Loader Class Initialized
INFO - 2017-06-22 20:34:26 --> Controller Class Initialized
INFO - 2017-06-22 20:34:26 --> Database Driver Class Initialized
INFO - 2017-06-22 20:34:26 --> Model Class Initialized
INFO - 2017-06-22 20:34:26 --> Helper loaded: form_helper
INFO - 2017-06-22 20:34:26 --> Helper loaded: url_helper
INFO - 2017-06-22 20:34:26 --> Model Class Initialized
INFO - 2017-06-22 20:34:27 --> Final output sent to browser
DEBUG - 2017-06-22 20:34:27 --> Total execution time: 0.0770
ERROR - 2017-06-22 20:34:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:34:27 --> Config Class Initialized
INFO - 2017-06-22 20:34:27 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:34:27 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:34:27 --> Utf8 Class Initialized
INFO - 2017-06-22 20:34:27 --> URI Class Initialized
INFO - 2017-06-22 20:34:27 --> Router Class Initialized
INFO - 2017-06-22 20:34:27 --> Output Class Initialized
INFO - 2017-06-22 20:34:28 --> Security Class Initialized
DEBUG - 2017-06-22 20:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:34:28 --> Input Class Initialized
INFO - 2017-06-22 20:34:28 --> Language Class Initialized
INFO - 2017-06-22 20:34:28 --> Loader Class Initialized
INFO - 2017-06-22 20:34:28 --> Controller Class Initialized
INFO - 2017-06-22 20:34:28 --> Database Driver Class Initialized
INFO - 2017-06-22 20:34:28 --> Model Class Initialized
INFO - 2017-06-22 20:34:28 --> Helper loaded: form_helper
INFO - 2017-06-22 20:34:28 --> Helper loaded: url_helper
INFO - 2017-06-22 20:34:28 --> Model Class Initialized
INFO - 2017-06-22 20:34:28 --> Final output sent to browser
DEBUG - 2017-06-22 20:34:28 --> Total execution time: 0.0550
ERROR - 2017-06-22 20:34:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:34:37 --> Config Class Initialized
INFO - 2017-06-22 20:34:37 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:34:37 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:34:37 --> Utf8 Class Initialized
INFO - 2017-06-22 20:34:37 --> URI Class Initialized
INFO - 2017-06-22 20:34:37 --> Router Class Initialized
INFO - 2017-06-22 20:34:37 --> Output Class Initialized
INFO - 2017-06-22 20:34:37 --> Security Class Initialized
DEBUG - 2017-06-22 20:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:34:37 --> Input Class Initialized
INFO - 2017-06-22 20:34:37 --> Language Class Initialized
INFO - 2017-06-22 20:34:37 --> Loader Class Initialized
INFO - 2017-06-22 20:34:37 --> Controller Class Initialized
INFO - 2017-06-22 20:34:37 --> Database Driver Class Initialized
INFO - 2017-06-22 20:34:37 --> Model Class Initialized
INFO - 2017-06-22 20:34:37 --> Helper loaded: form_helper
INFO - 2017-06-22 20:34:37 --> Helper loaded: url_helper
INFO - 2017-06-22 20:34:37 --> Model Class Initialized
INFO - 2017-06-22 20:34:37 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:34:37 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:34:37 --> Final output sent to browser
DEBUG - 2017-06-22 20:34:37 --> Total execution time: 0.0850
ERROR - 2017-06-22 20:34:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:34:40 --> Config Class Initialized
INFO - 2017-06-22 20:34:40 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:34:40 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:34:40 --> Utf8 Class Initialized
INFO - 2017-06-22 20:34:40 --> URI Class Initialized
INFO - 2017-06-22 20:34:40 --> Router Class Initialized
INFO - 2017-06-22 20:34:40 --> Output Class Initialized
INFO - 2017-06-22 20:34:40 --> Security Class Initialized
DEBUG - 2017-06-22 20:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:34:40 --> Input Class Initialized
INFO - 2017-06-22 20:34:40 --> Language Class Initialized
INFO - 2017-06-22 20:34:40 --> Loader Class Initialized
INFO - 2017-06-22 20:34:40 --> Controller Class Initialized
INFO - 2017-06-22 20:34:40 --> Database Driver Class Initialized
INFO - 2017-06-22 20:34:40 --> Model Class Initialized
INFO - 2017-06-22 20:34:40 --> Helper loaded: form_helper
INFO - 2017-06-22 20:34:40 --> Helper loaded: url_helper
INFO - 2017-06-22 20:34:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:34:40 --> Model Class Initialized
INFO - 2017-06-22 20:34:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 20:34:40 --> Final output sent to browser
DEBUG - 2017-06-22 20:34:40 --> Total execution time: 0.0490
ERROR - 2017-06-22 20:34:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:34:42 --> Config Class Initialized
INFO - 2017-06-22 20:34:42 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:34:42 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:34:42 --> Utf8 Class Initialized
INFO - 2017-06-22 20:34:42 --> URI Class Initialized
INFO - 2017-06-22 20:34:42 --> Router Class Initialized
INFO - 2017-06-22 20:34:42 --> Output Class Initialized
INFO - 2017-06-22 20:34:42 --> Security Class Initialized
DEBUG - 2017-06-22 20:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:34:42 --> Input Class Initialized
INFO - 2017-06-22 20:34:42 --> Language Class Initialized
INFO - 2017-06-22 20:34:42 --> Loader Class Initialized
INFO - 2017-06-22 20:34:42 --> Controller Class Initialized
INFO - 2017-06-22 20:34:42 --> Database Driver Class Initialized
INFO - 2017-06-22 20:34:42 --> Model Class Initialized
INFO - 2017-06-22 20:34:42 --> Helper loaded: form_helper
INFO - 2017-06-22 20:34:42 --> Helper loaded: url_helper
INFO - 2017-06-22 20:34:42 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:34:42 --> Model Class Initialized
INFO - 2017-06-22 20:34:42 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:34:42 --> Final output sent to browser
DEBUG - 2017-06-22 20:34:42 --> Total execution time: 0.0510
ERROR - 2017-06-22 20:34:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:34:48 --> Config Class Initialized
INFO - 2017-06-22 20:34:48 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:34:48 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:34:48 --> Utf8 Class Initialized
INFO - 2017-06-22 20:34:48 --> URI Class Initialized
INFO - 2017-06-22 20:34:48 --> Router Class Initialized
INFO - 2017-06-22 20:34:48 --> Output Class Initialized
INFO - 2017-06-22 20:34:48 --> Security Class Initialized
DEBUG - 2017-06-22 20:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:34:48 --> Input Class Initialized
INFO - 2017-06-22 20:34:48 --> Language Class Initialized
INFO - 2017-06-22 20:34:48 --> Loader Class Initialized
INFO - 2017-06-22 20:34:48 --> Controller Class Initialized
INFO - 2017-06-22 20:34:48 --> Database Driver Class Initialized
INFO - 2017-06-22 20:34:48 --> Model Class Initialized
INFO - 2017-06-22 20:34:48 --> Helper loaded: form_helper
INFO - 2017-06-22 20:34:48 --> Helper loaded: url_helper
INFO - 2017-06-22 20:34:48 --> Model Class Initialized
INFO - 2017-06-22 20:34:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:34:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:34:48 --> Final output sent to browser
DEBUG - 2017-06-22 20:34:48 --> Total execution time: 0.2450
ERROR - 2017-06-22 20:34:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:34:50 --> Config Class Initialized
INFO - 2017-06-22 20:34:50 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:34:50 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:34:50 --> Utf8 Class Initialized
INFO - 2017-06-22 20:34:50 --> URI Class Initialized
INFO - 2017-06-22 20:34:50 --> Router Class Initialized
INFO - 2017-06-22 20:34:50 --> Output Class Initialized
INFO - 2017-06-22 20:34:50 --> Security Class Initialized
DEBUG - 2017-06-22 20:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:34:50 --> Input Class Initialized
INFO - 2017-06-22 20:34:50 --> Language Class Initialized
INFO - 2017-06-22 20:34:50 --> Loader Class Initialized
INFO - 2017-06-22 20:34:50 --> Controller Class Initialized
INFO - 2017-06-22 20:34:50 --> Database Driver Class Initialized
INFO - 2017-06-22 20:34:50 --> Model Class Initialized
INFO - 2017-06-22 20:34:50 --> Helper loaded: form_helper
INFO - 2017-06-22 20:34:50 --> Helper loaded: url_helper
INFO - 2017-06-22 20:34:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:34:50 --> Model Class Initialized
INFO - 2017-06-22 20:34:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 20:34:50 --> Final output sent to browser
DEBUG - 2017-06-22 20:34:50 --> Total execution time: 0.0710
ERROR - 2017-06-22 20:34:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:34:59 --> Config Class Initialized
INFO - 2017-06-22 20:34:59 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:34:59 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:34:59 --> Utf8 Class Initialized
INFO - 2017-06-22 20:34:59 --> URI Class Initialized
INFO - 2017-06-22 20:34:59 --> Router Class Initialized
INFO - 2017-06-22 20:34:59 --> Output Class Initialized
INFO - 2017-06-22 20:34:59 --> Security Class Initialized
DEBUG - 2017-06-22 20:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:34:59 --> Input Class Initialized
INFO - 2017-06-22 20:34:59 --> Language Class Initialized
INFO - 2017-06-22 20:34:59 --> Loader Class Initialized
INFO - 2017-06-22 20:34:59 --> Controller Class Initialized
INFO - 2017-06-22 20:35:00 --> Database Driver Class Initialized
INFO - 2017-06-22 20:35:00 --> Model Class Initialized
INFO - 2017-06-22 20:35:00 --> Helper loaded: form_helper
INFO - 2017-06-22 20:35:00 --> Helper loaded: url_helper
INFO - 2017-06-22 20:35:00 --> Model Class Initialized
INFO - 2017-06-22 20:35:00 --> Final output sent to browser
DEBUG - 2017-06-22 20:35:00 --> Total execution time: 0.0550
ERROR - 2017-06-22 20:35:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:35:00 --> Config Class Initialized
INFO - 2017-06-22 20:35:00 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:35:00 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:35:00 --> Utf8 Class Initialized
INFO - 2017-06-22 20:35:00 --> URI Class Initialized
INFO - 2017-06-22 20:35:00 --> Router Class Initialized
INFO - 2017-06-22 20:35:00 --> Output Class Initialized
INFO - 2017-06-22 20:35:00 --> Security Class Initialized
DEBUG - 2017-06-22 20:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:35:00 --> Input Class Initialized
INFO - 2017-06-22 20:35:00 --> Language Class Initialized
INFO - 2017-06-22 20:35:00 --> Loader Class Initialized
INFO - 2017-06-22 20:35:00 --> Controller Class Initialized
INFO - 2017-06-22 20:35:00 --> Database Driver Class Initialized
INFO - 2017-06-22 20:35:00 --> Model Class Initialized
INFO - 2017-06-22 20:35:00 --> Helper loaded: form_helper
INFO - 2017-06-22 20:35:00 --> Helper loaded: url_helper
INFO - 2017-06-22 20:35:00 --> Model Class Initialized
INFO - 2017-06-22 20:35:00 --> Final output sent to browser
DEBUG - 2017-06-22 20:35:00 --> Total execution time: 0.0460
ERROR - 2017-06-22 20:35:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:35:15 --> Config Class Initialized
INFO - 2017-06-22 20:35:15 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:35:15 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:35:15 --> Utf8 Class Initialized
INFO - 2017-06-22 20:35:15 --> URI Class Initialized
INFO - 2017-06-22 20:35:15 --> Router Class Initialized
INFO - 2017-06-22 20:35:15 --> Output Class Initialized
INFO - 2017-06-22 20:35:15 --> Security Class Initialized
DEBUG - 2017-06-22 20:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:35:15 --> Input Class Initialized
INFO - 2017-06-22 20:35:15 --> Language Class Initialized
INFO - 2017-06-22 20:35:15 --> Loader Class Initialized
INFO - 2017-06-22 20:35:15 --> Controller Class Initialized
INFO - 2017-06-22 20:35:15 --> Database Driver Class Initialized
INFO - 2017-06-22 20:35:15 --> Model Class Initialized
INFO - 2017-06-22 20:35:15 --> Helper loaded: form_helper
INFO - 2017-06-22 20:35:15 --> Helper loaded: url_helper
INFO - 2017-06-22 20:35:15 --> Model Class Initialized
INFO - 2017-06-22 20:35:15 --> Final output sent to browser
DEBUG - 2017-06-22 20:35:15 --> Total execution time: 0.0575
ERROR - 2017-06-22 20:35:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:35:16 --> Config Class Initialized
INFO - 2017-06-22 20:35:16 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:35:16 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:35:16 --> Utf8 Class Initialized
INFO - 2017-06-22 20:35:16 --> URI Class Initialized
INFO - 2017-06-22 20:35:16 --> Router Class Initialized
INFO - 2017-06-22 20:35:16 --> Output Class Initialized
INFO - 2017-06-22 20:35:16 --> Security Class Initialized
DEBUG - 2017-06-22 20:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:35:16 --> Input Class Initialized
INFO - 2017-06-22 20:35:16 --> Language Class Initialized
INFO - 2017-06-22 20:35:16 --> Loader Class Initialized
INFO - 2017-06-22 20:35:16 --> Controller Class Initialized
INFO - 2017-06-22 20:35:16 --> Database Driver Class Initialized
INFO - 2017-06-22 20:35:16 --> Model Class Initialized
INFO - 2017-06-22 20:35:16 --> Helper loaded: form_helper
INFO - 2017-06-22 20:35:16 --> Helper loaded: url_helper
INFO - 2017-06-22 20:35:16 --> Model Class Initialized
INFO - 2017-06-22 20:35:16 --> Final output sent to browser
DEBUG - 2017-06-22 20:35:16 --> Total execution time: 0.0470
ERROR - 2017-06-22 20:35:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:35:22 --> Config Class Initialized
INFO - 2017-06-22 20:35:22 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:35:22 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:35:22 --> Utf8 Class Initialized
INFO - 2017-06-22 20:35:22 --> URI Class Initialized
INFO - 2017-06-22 20:35:22 --> Router Class Initialized
INFO - 2017-06-22 20:35:22 --> Output Class Initialized
INFO - 2017-06-22 20:35:22 --> Security Class Initialized
DEBUG - 2017-06-22 20:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:35:22 --> Input Class Initialized
INFO - 2017-06-22 20:35:22 --> Language Class Initialized
INFO - 2017-06-22 20:35:22 --> Loader Class Initialized
INFO - 2017-06-22 20:35:22 --> Controller Class Initialized
INFO - 2017-06-22 20:35:22 --> Database Driver Class Initialized
INFO - 2017-06-22 20:35:22 --> Model Class Initialized
INFO - 2017-06-22 20:35:22 --> Helper loaded: form_helper
INFO - 2017-06-22 20:35:22 --> Helper loaded: url_helper
INFO - 2017-06-22 20:35:22 --> Model Class Initialized
INFO - 2017-06-22 20:35:22 --> Final output sent to browser
DEBUG - 2017-06-22 20:35:22 --> Total execution time: 0.0610
ERROR - 2017-06-22 20:35:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:35:25 --> Config Class Initialized
INFO - 2017-06-22 20:35:25 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:35:25 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:35:25 --> Utf8 Class Initialized
INFO - 2017-06-22 20:35:25 --> URI Class Initialized
INFO - 2017-06-22 20:35:25 --> Router Class Initialized
INFO - 2017-06-22 20:35:25 --> Output Class Initialized
INFO - 2017-06-22 20:35:25 --> Security Class Initialized
DEBUG - 2017-06-22 20:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:35:25 --> Input Class Initialized
INFO - 2017-06-22 20:35:25 --> Language Class Initialized
INFO - 2017-06-22 20:35:25 --> Loader Class Initialized
INFO - 2017-06-22 20:35:25 --> Controller Class Initialized
INFO - 2017-06-22 20:35:25 --> Database Driver Class Initialized
INFO - 2017-06-22 20:35:25 --> Model Class Initialized
INFO - 2017-06-22 20:35:25 --> Helper loaded: form_helper
INFO - 2017-06-22 20:35:25 --> Helper loaded: url_helper
INFO - 2017-06-22 20:35:25 --> Model Class Initialized
INFO - 2017-06-22 20:35:25 --> Final output sent to browser
DEBUG - 2017-06-22 20:35:25 --> Total execution time: 0.0560
ERROR - 2017-06-22 20:35:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:35:25 --> Config Class Initialized
INFO - 2017-06-22 20:35:25 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:35:25 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:35:26 --> Utf8 Class Initialized
INFO - 2017-06-22 20:35:26 --> URI Class Initialized
INFO - 2017-06-22 20:35:26 --> Router Class Initialized
INFO - 2017-06-22 20:35:26 --> Output Class Initialized
INFO - 2017-06-22 20:35:26 --> Security Class Initialized
DEBUG - 2017-06-22 20:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:35:26 --> Input Class Initialized
INFO - 2017-06-22 20:35:26 --> Language Class Initialized
INFO - 2017-06-22 20:35:26 --> Loader Class Initialized
INFO - 2017-06-22 20:35:26 --> Controller Class Initialized
INFO - 2017-06-22 20:35:26 --> Database Driver Class Initialized
INFO - 2017-06-22 20:35:26 --> Model Class Initialized
INFO - 2017-06-22 20:35:26 --> Helper loaded: form_helper
INFO - 2017-06-22 20:35:26 --> Helper loaded: url_helper
INFO - 2017-06-22 20:35:26 --> Model Class Initialized
INFO - 2017-06-22 20:35:26 --> Final output sent to browser
DEBUG - 2017-06-22 20:35:26 --> Total execution time: 0.0620
ERROR - 2017-06-22 20:35:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:35:28 --> Config Class Initialized
INFO - 2017-06-22 20:35:28 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:35:28 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:35:28 --> Utf8 Class Initialized
INFO - 2017-06-22 20:35:28 --> URI Class Initialized
INFO - 2017-06-22 20:35:28 --> Router Class Initialized
INFO - 2017-06-22 20:35:28 --> Output Class Initialized
INFO - 2017-06-22 20:35:28 --> Security Class Initialized
DEBUG - 2017-06-22 20:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:35:28 --> Input Class Initialized
INFO - 2017-06-22 20:35:28 --> Language Class Initialized
INFO - 2017-06-22 20:35:28 --> Loader Class Initialized
INFO - 2017-06-22 20:35:28 --> Controller Class Initialized
INFO - 2017-06-22 20:35:28 --> Database Driver Class Initialized
INFO - 2017-06-22 20:35:28 --> Model Class Initialized
INFO - 2017-06-22 20:35:28 --> Helper loaded: form_helper
INFO - 2017-06-22 20:35:28 --> Helper loaded: url_helper
INFO - 2017-06-22 20:35:28 --> Model Class Initialized
INFO - 2017-06-22 20:35:28 --> Final output sent to browser
DEBUG - 2017-06-22 20:35:28 --> Total execution time: 0.0570
ERROR - 2017-06-22 20:36:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:36:56 --> Config Class Initialized
INFO - 2017-06-22 20:36:56 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:36:56 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:36:56 --> Utf8 Class Initialized
INFO - 2017-06-22 20:36:56 --> URI Class Initialized
INFO - 2017-06-22 20:36:56 --> Router Class Initialized
INFO - 2017-06-22 20:36:56 --> Output Class Initialized
INFO - 2017-06-22 20:36:56 --> Security Class Initialized
DEBUG - 2017-06-22 20:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:36:56 --> Input Class Initialized
INFO - 2017-06-22 20:36:56 --> Language Class Initialized
INFO - 2017-06-22 20:36:56 --> Loader Class Initialized
INFO - 2017-06-22 20:36:56 --> Controller Class Initialized
INFO - 2017-06-22 20:36:56 --> Database Driver Class Initialized
INFO - 2017-06-22 20:36:56 --> Model Class Initialized
INFO - 2017-06-22 20:36:56 --> Helper loaded: form_helper
INFO - 2017-06-22 20:36:56 --> Helper loaded: url_helper
INFO - 2017-06-22 20:36:56 --> Model Class Initialized
INFO - 2017-06-22 20:36:56 --> Final output sent to browser
DEBUG - 2017-06-22 20:36:56 --> Total execution time: 0.0620
ERROR - 2017-06-22 20:36:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:36:57 --> Config Class Initialized
INFO - 2017-06-22 20:36:57 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:36:57 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:36:57 --> Utf8 Class Initialized
INFO - 2017-06-22 20:36:57 --> URI Class Initialized
INFO - 2017-06-22 20:36:57 --> Router Class Initialized
INFO - 2017-06-22 20:36:57 --> Output Class Initialized
INFO - 2017-06-22 20:36:57 --> Security Class Initialized
DEBUG - 2017-06-22 20:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:36:57 --> Input Class Initialized
INFO - 2017-06-22 20:36:57 --> Language Class Initialized
INFO - 2017-06-22 20:36:57 --> Loader Class Initialized
INFO - 2017-06-22 20:36:57 --> Controller Class Initialized
INFO - 2017-06-22 20:36:57 --> Database Driver Class Initialized
INFO - 2017-06-22 20:36:57 --> Model Class Initialized
INFO - 2017-06-22 20:36:57 --> Helper loaded: form_helper
INFO - 2017-06-22 20:36:57 --> Helper loaded: url_helper
INFO - 2017-06-22 20:36:57 --> Model Class Initialized
INFO - 2017-06-22 20:36:57 --> Final output sent to browser
DEBUG - 2017-06-22 20:36:57 --> Total execution time: 0.0420
ERROR - 2017-06-22 20:39:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:39:31 --> Config Class Initialized
INFO - 2017-06-22 20:39:31 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:39:31 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:39:31 --> Utf8 Class Initialized
INFO - 2017-06-22 20:39:31 --> URI Class Initialized
INFO - 2017-06-22 20:39:31 --> Router Class Initialized
INFO - 2017-06-22 20:39:31 --> Output Class Initialized
INFO - 2017-06-22 20:39:31 --> Security Class Initialized
DEBUG - 2017-06-22 20:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:39:31 --> Input Class Initialized
INFO - 2017-06-22 20:39:31 --> Language Class Initialized
INFO - 2017-06-22 20:39:31 --> Loader Class Initialized
INFO - 2017-06-22 20:39:31 --> Controller Class Initialized
INFO - 2017-06-22 20:39:31 --> Database Driver Class Initialized
INFO - 2017-06-22 20:39:31 --> Model Class Initialized
INFO - 2017-06-22 20:39:31 --> Helper loaded: form_helper
INFO - 2017-06-22 20:39:31 --> Helper loaded: url_helper
INFO - 2017-06-22 20:39:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:39:31 --> Model Class Initialized
INFO - 2017-06-22 20:39:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 20:39:31 --> Final output sent to browser
DEBUG - 2017-06-22 20:39:31 --> Total execution time: 0.0610
ERROR - 2017-06-22 20:39:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:39:33 --> Config Class Initialized
INFO - 2017-06-22 20:39:33 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:39:33 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:39:33 --> Utf8 Class Initialized
INFO - 2017-06-22 20:39:33 --> URI Class Initialized
INFO - 2017-06-22 20:39:33 --> Router Class Initialized
INFO - 2017-06-22 20:39:33 --> Output Class Initialized
INFO - 2017-06-22 20:39:33 --> Security Class Initialized
DEBUG - 2017-06-22 20:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:39:33 --> Input Class Initialized
INFO - 2017-06-22 20:39:33 --> Language Class Initialized
INFO - 2017-06-22 20:39:33 --> Loader Class Initialized
INFO - 2017-06-22 20:39:33 --> Controller Class Initialized
INFO - 2017-06-22 20:39:33 --> Database Driver Class Initialized
INFO - 2017-06-22 20:39:33 --> Model Class Initialized
INFO - 2017-06-22 20:39:33 --> Helper loaded: form_helper
INFO - 2017-06-22 20:39:33 --> Helper loaded: url_helper
INFO - 2017-06-22 20:39:33 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:39:33 --> Model Class Initialized
INFO - 2017-06-22 20:39:33 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:39:33 --> Final output sent to browser
DEBUG - 2017-06-22 20:39:33 --> Total execution time: 0.0510
ERROR - 2017-06-22 20:39:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:39:34 --> Config Class Initialized
INFO - 2017-06-22 20:39:34 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:39:34 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:39:34 --> Utf8 Class Initialized
INFO - 2017-06-22 20:39:34 --> URI Class Initialized
INFO - 2017-06-22 20:39:34 --> Router Class Initialized
INFO - 2017-06-22 20:39:34 --> Output Class Initialized
INFO - 2017-06-22 20:39:34 --> Security Class Initialized
DEBUG - 2017-06-22 20:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:39:34 --> Input Class Initialized
INFO - 2017-06-22 20:39:34 --> Language Class Initialized
INFO - 2017-06-22 20:39:34 --> Loader Class Initialized
INFO - 2017-06-22 20:39:34 --> Controller Class Initialized
INFO - 2017-06-22 20:39:34 --> Database Driver Class Initialized
INFO - 2017-06-22 20:39:34 --> Model Class Initialized
INFO - 2017-06-22 20:39:34 --> Helper loaded: form_helper
INFO - 2017-06-22 20:39:34 --> Helper loaded: url_helper
INFO - 2017-06-22 20:39:34 --> Model Class Initialized
INFO - 2017-06-22 20:39:34 --> Final output sent to browser
DEBUG - 2017-06-22 20:39:34 --> Total execution time: 0.1225
ERROR - 2017-06-22 20:39:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:39:35 --> Config Class Initialized
INFO - 2017-06-22 20:39:35 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:39:35 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:39:35 --> Utf8 Class Initialized
INFO - 2017-06-22 20:39:35 --> URI Class Initialized
INFO - 2017-06-22 20:39:35 --> Router Class Initialized
INFO - 2017-06-22 20:39:35 --> Output Class Initialized
INFO - 2017-06-22 20:39:35 --> Security Class Initialized
DEBUG - 2017-06-22 20:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:39:35 --> Input Class Initialized
INFO - 2017-06-22 20:39:35 --> Language Class Initialized
INFO - 2017-06-22 20:39:35 --> Loader Class Initialized
INFO - 2017-06-22 20:39:35 --> Controller Class Initialized
ERROR - 2017-06-22 20:39:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:39:35 --> Database Driver Class Initialized
INFO - 2017-06-22 20:39:35 --> Config Class Initialized
INFO - 2017-06-22 20:39:35 --> Hooks Class Initialized
INFO - 2017-06-22 20:39:35 --> Model Class Initialized
DEBUG - 2017-06-22 20:39:35 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:39:35 --> Helper loaded: form_helper
INFO - 2017-06-22 20:39:35 --> Utf8 Class Initialized
INFO - 2017-06-22 20:39:35 --> Helper loaded: url_helper
INFO - 2017-06-22 20:39:35 --> URI Class Initialized
INFO - 2017-06-22 20:39:35 --> Model Class Initialized
INFO - 2017-06-22 20:39:35 --> Router Class Initialized
INFO - 2017-06-22 20:39:35 --> Output Class Initialized
INFO - 2017-06-22 20:39:35 --> Security Class Initialized
DEBUG - 2017-06-22 20:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:39:35 --> Input Class Initialized
INFO - 2017-06-22 20:39:35 --> Language Class Initialized
INFO - 2017-06-22 20:39:35 --> Loader Class Initialized
INFO - 2017-06-22 20:39:35 --> Controller Class Initialized
INFO - 2017-06-22 20:39:35 --> Database Driver Class Initialized
INFO - 2017-06-22 20:39:35 --> Model Class Initialized
INFO - 2017-06-22 20:39:35 --> Helper loaded: form_helper
INFO - 2017-06-22 20:39:35 --> Helper loaded: url_helper
INFO - 2017-06-22 20:39:35 --> Model Class Initialized
INFO - 2017-06-22 20:39:35 --> Final output sent to browser
DEBUG - 2017-06-22 20:39:35 --> Total execution time: 0.0515
INFO - 2017-06-22 20:39:35 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:39:35 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:39:35 --> Final output sent to browser
DEBUG - 2017-06-22 20:39:35 --> Total execution time: 0.2180
ERROR - 2017-06-22 20:39:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:39:37 --> Config Class Initialized
INFO - 2017-06-22 20:39:37 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:39:37 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:39:37 --> Utf8 Class Initialized
INFO - 2017-06-22 20:39:37 --> URI Class Initialized
INFO - 2017-06-22 20:39:37 --> Router Class Initialized
INFO - 2017-06-22 20:39:37 --> Output Class Initialized
INFO - 2017-06-22 20:39:37 --> Security Class Initialized
DEBUG - 2017-06-22 20:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:39:37 --> Input Class Initialized
INFO - 2017-06-22 20:39:37 --> Language Class Initialized
INFO - 2017-06-22 20:39:38 --> Loader Class Initialized
INFO - 2017-06-22 20:39:38 --> Controller Class Initialized
INFO - 2017-06-22 20:39:38 --> Database Driver Class Initialized
INFO - 2017-06-22 20:39:38 --> Model Class Initialized
INFO - 2017-06-22 20:39:38 --> Helper loaded: form_helper
INFO - 2017-06-22 20:39:38 --> Helper loaded: url_helper
INFO - 2017-06-22 20:39:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:39:38 --> Model Class Initialized
INFO - 2017-06-22 20:39:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 20:39:38 --> Final output sent to browser
DEBUG - 2017-06-22 20:39:38 --> Total execution time: 0.0680
ERROR - 2017-06-22 20:39:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:39:39 --> Config Class Initialized
INFO - 2017-06-22 20:39:39 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:39:39 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:39:39 --> Utf8 Class Initialized
INFO - 2017-06-22 20:39:39 --> URI Class Initialized
INFO - 2017-06-22 20:39:39 --> Router Class Initialized
INFO - 2017-06-22 20:39:39 --> Output Class Initialized
INFO - 2017-06-22 20:39:39 --> Security Class Initialized
DEBUG - 2017-06-22 20:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:39:39 --> Input Class Initialized
INFO - 2017-06-22 20:39:39 --> Language Class Initialized
INFO - 2017-06-22 20:39:39 --> Loader Class Initialized
INFO - 2017-06-22 20:39:39 --> Controller Class Initialized
INFO - 2017-06-22 20:39:39 --> Database Driver Class Initialized
INFO - 2017-06-22 20:39:39 --> Model Class Initialized
INFO - 2017-06-22 20:39:39 --> Helper loaded: form_helper
INFO - 2017-06-22 20:39:39 --> Helper loaded: url_helper
INFO - 2017-06-22 20:39:39 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:39:39 --> Model Class Initialized
INFO - 2017-06-22 20:39:39 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:39:39 --> Final output sent to browser
DEBUG - 2017-06-22 20:39:39 --> Total execution time: 0.0700
ERROR - 2017-06-22 20:39:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:39:41 --> Config Class Initialized
INFO - 2017-06-22 20:39:41 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:39:41 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:39:41 --> Utf8 Class Initialized
INFO - 2017-06-22 20:39:41 --> URI Class Initialized
INFO - 2017-06-22 20:39:41 --> Router Class Initialized
INFO - 2017-06-22 20:39:41 --> Output Class Initialized
INFO - 2017-06-22 20:39:41 --> Security Class Initialized
DEBUG - 2017-06-22 20:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:39:41 --> Input Class Initialized
INFO - 2017-06-22 20:39:41 --> Language Class Initialized
INFO - 2017-06-22 20:39:41 --> Loader Class Initialized
INFO - 2017-06-22 20:39:41 --> Controller Class Initialized
INFO - 2017-06-22 20:39:41 --> Database Driver Class Initialized
INFO - 2017-06-22 20:39:41 --> Model Class Initialized
INFO - 2017-06-22 20:39:41 --> Helper loaded: form_helper
INFO - 2017-06-22 20:39:41 --> Helper loaded: url_helper
INFO - 2017-06-22 20:39:41 --> Model Class Initialized
INFO - 2017-06-22 20:39:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:39:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:39:41 --> Final output sent to browser
DEBUG - 2017-06-22 20:39:41 --> Total execution time: 0.1440
ERROR - 2017-06-22 20:39:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:39:46 --> Config Class Initialized
INFO - 2017-06-22 20:39:46 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:39:46 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:39:46 --> Utf8 Class Initialized
INFO - 2017-06-22 20:39:46 --> URI Class Initialized
INFO - 2017-06-22 20:39:46 --> Router Class Initialized
INFO - 2017-06-22 20:39:46 --> Output Class Initialized
INFO - 2017-06-22 20:39:46 --> Security Class Initialized
DEBUG - 2017-06-22 20:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:39:46 --> Input Class Initialized
INFO - 2017-06-22 20:39:46 --> Language Class Initialized
INFO - 2017-06-22 20:39:46 --> Loader Class Initialized
INFO - 2017-06-22 20:39:46 --> Controller Class Initialized
INFO - 2017-06-22 20:39:46 --> Database Driver Class Initialized
INFO - 2017-06-22 20:39:46 --> Model Class Initialized
INFO - 2017-06-22 20:39:46 --> Helper loaded: form_helper
INFO - 2017-06-22 20:39:46 --> Helper loaded: url_helper
INFO - 2017-06-22 20:39:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:39:46 --> Model Class Initialized
INFO - 2017-06-22 20:39:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 20:39:46 --> Final output sent to browser
DEBUG - 2017-06-22 20:39:46 --> Total execution time: 0.0570
ERROR - 2017-06-22 20:39:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:39:47 --> Config Class Initialized
INFO - 2017-06-22 20:39:47 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:39:47 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:39:47 --> Utf8 Class Initialized
INFO - 2017-06-22 20:39:47 --> URI Class Initialized
INFO - 2017-06-22 20:39:47 --> Router Class Initialized
INFO - 2017-06-22 20:39:47 --> Output Class Initialized
INFO - 2017-06-22 20:39:47 --> Security Class Initialized
DEBUG - 2017-06-22 20:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:39:47 --> Input Class Initialized
INFO - 2017-06-22 20:39:47 --> Language Class Initialized
INFO - 2017-06-22 20:39:47 --> Loader Class Initialized
INFO - 2017-06-22 20:39:47 --> Controller Class Initialized
INFO - 2017-06-22 20:39:47 --> Database Driver Class Initialized
INFO - 2017-06-22 20:39:47 --> Model Class Initialized
INFO - 2017-06-22 20:39:47 --> Helper loaded: form_helper
INFO - 2017-06-22 20:39:47 --> Helper loaded: url_helper
INFO - 2017-06-22 20:39:47 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:39:47 --> Model Class Initialized
INFO - 2017-06-22 20:39:47 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:39:47 --> Final output sent to browser
DEBUG - 2017-06-22 20:39:47 --> Total execution time: 0.0570
ERROR - 2017-06-22 20:39:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:39:52 --> Config Class Initialized
INFO - 2017-06-22 20:39:52 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:39:52 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:39:52 --> Utf8 Class Initialized
INFO - 2017-06-22 20:39:52 --> URI Class Initialized
INFO - 2017-06-22 20:39:52 --> Router Class Initialized
INFO - 2017-06-22 20:39:52 --> Output Class Initialized
INFO - 2017-06-22 20:39:52 --> Security Class Initialized
DEBUG - 2017-06-22 20:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:39:52 --> Input Class Initialized
INFO - 2017-06-22 20:39:52 --> Language Class Initialized
INFO - 2017-06-22 20:39:52 --> Loader Class Initialized
INFO - 2017-06-22 20:39:52 --> Controller Class Initialized
INFO - 2017-06-22 20:39:52 --> Database Driver Class Initialized
INFO - 2017-06-22 20:39:52 --> Model Class Initialized
INFO - 2017-06-22 20:39:52 --> Helper loaded: form_helper
INFO - 2017-06-22 20:39:52 --> Helper loaded: url_helper
INFO - 2017-06-22 20:39:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:39:52 --> Model Class Initialized
INFO - 2017-06-22 20:39:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 20:39:52 --> Final output sent to browser
DEBUG - 2017-06-22 20:39:52 --> Total execution time: 0.0640
ERROR - 2017-06-22 20:39:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:39:54 --> Config Class Initialized
INFO - 2017-06-22 20:39:54 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:39:54 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:39:54 --> Utf8 Class Initialized
INFO - 2017-06-22 20:39:54 --> URI Class Initialized
INFO - 2017-06-22 20:39:54 --> Router Class Initialized
INFO - 2017-06-22 20:39:54 --> Output Class Initialized
INFO - 2017-06-22 20:39:54 --> Security Class Initialized
DEBUG - 2017-06-22 20:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:39:54 --> Input Class Initialized
INFO - 2017-06-22 20:39:54 --> Language Class Initialized
INFO - 2017-06-22 20:39:54 --> Loader Class Initialized
INFO - 2017-06-22 20:39:54 --> Controller Class Initialized
INFO - 2017-06-22 20:39:54 --> Database Driver Class Initialized
INFO - 2017-06-22 20:39:54 --> Model Class Initialized
INFO - 2017-06-22 20:39:54 --> Helper loaded: form_helper
INFO - 2017-06-22 20:39:54 --> Helper loaded: url_helper
INFO - 2017-06-22 20:39:54 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:39:54 --> Model Class Initialized
INFO - 2017-06-22 20:39:54 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:39:54 --> Final output sent to browser
DEBUG - 2017-06-22 20:39:54 --> Total execution time: 0.0510
ERROR - 2017-06-22 20:40:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:40:03 --> Config Class Initialized
INFO - 2017-06-22 20:40:03 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:40:03 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:40:03 --> Utf8 Class Initialized
INFO - 2017-06-22 20:40:03 --> URI Class Initialized
INFO - 2017-06-22 20:40:03 --> Router Class Initialized
INFO - 2017-06-22 20:40:03 --> Output Class Initialized
INFO - 2017-06-22 20:40:03 --> Security Class Initialized
DEBUG - 2017-06-22 20:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:40:03 --> Input Class Initialized
INFO - 2017-06-22 20:40:03 --> Language Class Initialized
INFO - 2017-06-22 20:40:03 --> Loader Class Initialized
INFO - 2017-06-22 20:40:03 --> Controller Class Initialized
INFO - 2017-06-22 20:40:04 --> Database Driver Class Initialized
INFO - 2017-06-22 20:40:04 --> Model Class Initialized
INFO - 2017-06-22 20:40:04 --> Helper loaded: form_helper
INFO - 2017-06-22 20:40:04 --> Helper loaded: url_helper
INFO - 2017-06-22 20:40:04 --> Upload Class Initialized
INFO - 2017-06-22 20:40:04 --> Final output sent to browser
DEBUG - 2017-06-22 20:40:04 --> Total execution time: 0.1210
ERROR - 2017-06-22 20:40:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:40:07 --> Config Class Initialized
INFO - 2017-06-22 20:40:07 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:40:07 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:40:07 --> Utf8 Class Initialized
INFO - 2017-06-22 20:40:07 --> URI Class Initialized
INFO - 2017-06-22 20:40:07 --> Router Class Initialized
INFO - 2017-06-22 20:40:07 --> Output Class Initialized
INFO - 2017-06-22 20:40:07 --> Security Class Initialized
DEBUG - 2017-06-22 20:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:40:07 --> Input Class Initialized
INFO - 2017-06-22 20:40:07 --> Language Class Initialized
INFO - 2017-06-22 20:40:07 --> Loader Class Initialized
INFO - 2017-06-22 20:40:07 --> Controller Class Initialized
INFO - 2017-06-22 20:40:07 --> Database Driver Class Initialized
INFO - 2017-06-22 20:40:07 --> Model Class Initialized
INFO - 2017-06-22 20:40:07 --> Helper loaded: form_helper
INFO - 2017-06-22 20:40:07 --> Helper loaded: url_helper
INFO - 2017-06-22 20:40:07 --> Upload Class Initialized
INFO - 2017-06-22 20:40:07 --> Final output sent to browser
DEBUG - 2017-06-22 20:40:07 --> Total execution time: 0.0750
ERROR - 2017-06-22 20:40:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:40:09 --> Config Class Initialized
INFO - 2017-06-22 20:40:09 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:40:09 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:40:09 --> Utf8 Class Initialized
INFO - 2017-06-22 20:40:09 --> URI Class Initialized
INFO - 2017-06-22 20:40:09 --> Router Class Initialized
INFO - 2017-06-22 20:40:09 --> Output Class Initialized
INFO - 2017-06-22 20:40:09 --> Security Class Initialized
DEBUG - 2017-06-22 20:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:40:09 --> Input Class Initialized
INFO - 2017-06-22 20:40:09 --> Language Class Initialized
INFO - 2017-06-22 20:40:09 --> Loader Class Initialized
INFO - 2017-06-22 20:40:09 --> Controller Class Initialized
INFO - 2017-06-22 20:40:09 --> Database Driver Class Initialized
INFO - 2017-06-22 20:40:09 --> Model Class Initialized
INFO - 2017-06-22 20:40:09 --> Helper loaded: form_helper
INFO - 2017-06-22 20:40:09 --> Helper loaded: url_helper
INFO - 2017-06-22 20:40:09 --> Model Class Initialized
INFO - 2017-06-22 20:40:09 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:40:09 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:40:09 --> Final output sent to browser
DEBUG - 2017-06-22 20:40:09 --> Total execution time: 0.4310
ERROR - 2017-06-22 20:40:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:40:12 --> Config Class Initialized
INFO - 2017-06-22 20:40:12 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:40:12 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:40:12 --> Utf8 Class Initialized
INFO - 2017-06-22 20:40:12 --> URI Class Initialized
INFO - 2017-06-22 20:40:12 --> Router Class Initialized
INFO - 2017-06-22 20:40:12 --> Output Class Initialized
INFO - 2017-06-22 20:40:12 --> Security Class Initialized
DEBUG - 2017-06-22 20:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:40:12 --> Input Class Initialized
INFO - 2017-06-22 20:40:12 --> Language Class Initialized
INFO - 2017-06-22 20:40:12 --> Loader Class Initialized
INFO - 2017-06-22 20:40:12 --> Controller Class Initialized
INFO - 2017-06-22 20:40:12 --> Database Driver Class Initialized
INFO - 2017-06-22 20:40:12 --> Model Class Initialized
INFO - 2017-06-22 20:40:12 --> Helper loaded: form_helper
INFO - 2017-06-22 20:40:12 --> Helper loaded: url_helper
INFO - 2017-06-22 20:40:12 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:40:12 --> Model Class Initialized
INFO - 2017-06-22 20:40:12 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 20:40:12 --> Final output sent to browser
DEBUG - 2017-06-22 20:40:12 --> Total execution time: 0.0670
ERROR - 2017-06-22 20:40:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:40:20 --> Config Class Initialized
INFO - 2017-06-22 20:40:20 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:40:20 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:40:20 --> Utf8 Class Initialized
INFO - 2017-06-22 20:40:20 --> URI Class Initialized
INFO - 2017-06-22 20:40:20 --> Router Class Initialized
INFO - 2017-06-22 20:40:20 --> Output Class Initialized
INFO - 2017-06-22 20:40:20 --> Security Class Initialized
DEBUG - 2017-06-22 20:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:40:20 --> Input Class Initialized
INFO - 2017-06-22 20:40:20 --> Language Class Initialized
INFO - 2017-06-22 20:40:20 --> Loader Class Initialized
INFO - 2017-06-22 20:40:20 --> Controller Class Initialized
INFO - 2017-06-22 20:40:20 --> Database Driver Class Initialized
INFO - 2017-06-22 20:40:20 --> Model Class Initialized
INFO - 2017-06-22 20:40:20 --> Helper loaded: form_helper
INFO - 2017-06-22 20:40:20 --> Helper loaded: url_helper
INFO - 2017-06-22 20:40:20 --> Model Class Initialized
INFO - 2017-06-22 20:40:20 --> Final output sent to browser
DEBUG - 2017-06-22 20:40:20 --> Total execution time: 0.0500
ERROR - 2017-06-22 20:40:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:40:20 --> Config Class Initialized
INFO - 2017-06-22 20:40:20 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:40:20 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:40:20 --> Utf8 Class Initialized
INFO - 2017-06-22 20:40:20 --> URI Class Initialized
INFO - 2017-06-22 20:40:20 --> Router Class Initialized
INFO - 2017-06-22 20:40:20 --> Output Class Initialized
INFO - 2017-06-22 20:40:20 --> Security Class Initialized
DEBUG - 2017-06-22 20:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:40:20 --> Input Class Initialized
INFO - 2017-06-22 20:40:20 --> Language Class Initialized
INFO - 2017-06-22 20:40:20 --> Loader Class Initialized
INFO - 2017-06-22 20:40:20 --> Controller Class Initialized
INFO - 2017-06-22 20:40:20 --> Database Driver Class Initialized
INFO - 2017-06-22 20:40:20 --> Model Class Initialized
INFO - 2017-06-22 20:40:20 --> Helper loaded: form_helper
INFO - 2017-06-22 20:40:20 --> Helper loaded: url_helper
INFO - 2017-06-22 20:40:20 --> Model Class Initialized
INFO - 2017-06-22 20:40:20 --> Final output sent to browser
DEBUG - 2017-06-22 20:40:20 --> Total execution time: 0.0450
ERROR - 2017-06-22 20:40:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:40:23 --> Config Class Initialized
INFO - 2017-06-22 20:40:23 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:40:23 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:40:23 --> Utf8 Class Initialized
INFO - 2017-06-22 20:40:23 --> URI Class Initialized
INFO - 2017-06-22 20:40:23 --> Router Class Initialized
INFO - 2017-06-22 20:40:23 --> Output Class Initialized
INFO - 2017-06-22 20:40:23 --> Security Class Initialized
DEBUG - 2017-06-22 20:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:40:23 --> Input Class Initialized
INFO - 2017-06-22 20:40:23 --> Language Class Initialized
INFO - 2017-06-22 20:40:23 --> Loader Class Initialized
INFO - 2017-06-22 20:40:23 --> Controller Class Initialized
INFO - 2017-06-22 20:40:23 --> Database Driver Class Initialized
INFO - 2017-06-22 20:40:23 --> Model Class Initialized
INFO - 2017-06-22 20:40:23 --> Helper loaded: form_helper
INFO - 2017-06-22 20:40:23 --> Helper loaded: url_helper
INFO - 2017-06-22 20:40:23 --> Model Class Initialized
INFO - 2017-06-22 20:40:23 --> Final output sent to browser
DEBUG - 2017-06-22 20:40:23 --> Total execution time: 0.0505
ERROR - 2017-06-22 20:40:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:40:26 --> Config Class Initialized
INFO - 2017-06-22 20:40:26 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:40:26 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:40:26 --> Utf8 Class Initialized
INFO - 2017-06-22 20:40:26 --> URI Class Initialized
INFO - 2017-06-22 20:40:26 --> Router Class Initialized
INFO - 2017-06-22 20:40:26 --> Output Class Initialized
INFO - 2017-06-22 20:40:26 --> Security Class Initialized
DEBUG - 2017-06-22 20:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:40:26 --> Input Class Initialized
INFO - 2017-06-22 20:40:26 --> Language Class Initialized
INFO - 2017-06-22 20:40:26 --> Loader Class Initialized
INFO - 2017-06-22 20:40:26 --> Controller Class Initialized
INFO - 2017-06-22 20:40:26 --> Database Driver Class Initialized
INFO - 2017-06-22 20:40:26 --> Model Class Initialized
INFO - 2017-06-22 20:40:26 --> Helper loaded: form_helper
INFO - 2017-06-22 20:40:26 --> Helper loaded: url_helper
INFO - 2017-06-22 20:40:26 --> Model Class Initialized
INFO - 2017-06-22 20:40:26 --> Final output sent to browser
DEBUG - 2017-06-22 20:40:26 --> Total execution time: 0.0530
ERROR - 2017-06-22 20:40:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:40:27 --> Config Class Initialized
INFO - 2017-06-22 20:40:27 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:40:27 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:40:27 --> Utf8 Class Initialized
INFO - 2017-06-22 20:40:27 --> URI Class Initialized
INFO - 2017-06-22 20:40:27 --> Router Class Initialized
INFO - 2017-06-22 20:40:27 --> Output Class Initialized
INFO - 2017-06-22 20:40:27 --> Security Class Initialized
DEBUG - 2017-06-22 20:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:40:27 --> Input Class Initialized
INFO - 2017-06-22 20:40:27 --> Language Class Initialized
INFO - 2017-06-22 20:40:27 --> Loader Class Initialized
INFO - 2017-06-22 20:40:27 --> Controller Class Initialized
INFO - 2017-06-22 20:40:27 --> Database Driver Class Initialized
INFO - 2017-06-22 20:40:27 --> Model Class Initialized
INFO - 2017-06-22 20:40:27 --> Helper loaded: form_helper
INFO - 2017-06-22 20:40:27 --> Helper loaded: url_helper
INFO - 2017-06-22 20:40:27 --> Model Class Initialized
INFO - 2017-06-22 20:40:27 --> Final output sent to browser
DEBUG - 2017-06-22 20:40:27 --> Total execution time: 0.0590
ERROR - 2017-06-22 20:40:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:40:30 --> Config Class Initialized
INFO - 2017-06-22 20:40:30 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:40:30 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:40:30 --> Utf8 Class Initialized
INFO - 2017-06-22 20:40:30 --> URI Class Initialized
INFO - 2017-06-22 20:40:30 --> Router Class Initialized
INFO - 2017-06-22 20:40:30 --> Output Class Initialized
INFO - 2017-06-22 20:40:30 --> Security Class Initialized
DEBUG - 2017-06-22 20:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:40:30 --> Input Class Initialized
INFO - 2017-06-22 20:40:30 --> Language Class Initialized
INFO - 2017-06-22 20:40:30 --> Loader Class Initialized
INFO - 2017-06-22 20:40:30 --> Controller Class Initialized
INFO - 2017-06-22 20:40:30 --> Database Driver Class Initialized
INFO - 2017-06-22 20:40:30 --> Model Class Initialized
INFO - 2017-06-22 20:40:30 --> Helper loaded: form_helper
INFO - 2017-06-22 20:40:30 --> Helper loaded: url_helper
INFO - 2017-06-22 20:40:30 --> Model Class Initialized
INFO - 2017-06-22 20:40:30 --> Final output sent to browser
DEBUG - 2017-06-22 20:40:30 --> Total execution time: 0.0460
ERROR - 2017-06-22 20:40:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:40:53 --> Config Class Initialized
INFO - 2017-06-22 20:40:53 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:40:53 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:40:53 --> Utf8 Class Initialized
INFO - 2017-06-22 20:40:53 --> URI Class Initialized
INFO - 2017-06-22 20:40:53 --> Router Class Initialized
INFO - 2017-06-22 20:40:53 --> Output Class Initialized
INFO - 2017-06-22 20:40:53 --> Security Class Initialized
DEBUG - 2017-06-22 20:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:40:53 --> Input Class Initialized
INFO - 2017-06-22 20:40:53 --> Language Class Initialized
INFO - 2017-06-22 20:40:53 --> Loader Class Initialized
INFO - 2017-06-22 20:40:53 --> Controller Class Initialized
INFO - 2017-06-22 20:40:53 --> Database Driver Class Initialized
INFO - 2017-06-22 20:40:53 --> Model Class Initialized
INFO - 2017-06-22 20:40:53 --> Helper loaded: form_helper
INFO - 2017-06-22 20:40:53 --> Helper loaded: url_helper
INFO - 2017-06-22 20:40:53 --> Model Class Initialized
INFO - 2017-06-22 20:40:53 --> Final output sent to browser
DEBUG - 2017-06-22 20:40:53 --> Total execution time: 0.0650
ERROR - 2017-06-22 20:41:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:41:13 --> Config Class Initialized
INFO - 2017-06-22 20:41:13 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:41:13 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:41:13 --> Utf8 Class Initialized
INFO - 2017-06-22 20:41:13 --> URI Class Initialized
INFO - 2017-06-22 20:41:13 --> Router Class Initialized
INFO - 2017-06-22 20:41:13 --> Output Class Initialized
INFO - 2017-06-22 20:41:13 --> Security Class Initialized
DEBUG - 2017-06-22 20:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:41:13 --> Input Class Initialized
INFO - 2017-06-22 20:41:13 --> Language Class Initialized
INFO - 2017-06-22 20:41:13 --> Loader Class Initialized
INFO - 2017-06-22 20:41:13 --> Controller Class Initialized
INFO - 2017-06-22 20:41:13 --> Database Driver Class Initialized
INFO - 2017-06-22 20:41:13 --> Model Class Initialized
INFO - 2017-06-22 20:41:13 --> Helper loaded: form_helper
INFO - 2017-06-22 20:41:13 --> Helper loaded: url_helper
INFO - 2017-06-22 20:41:13 --> Model Class Initialized
INFO - 2017-06-22 20:41:13 --> Final output sent to browser
DEBUG - 2017-06-22 20:41:13 --> Total execution time: 0.0590
ERROR - 2017-06-22 20:43:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:43:32 --> Config Class Initialized
INFO - 2017-06-22 20:43:32 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:43:32 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:43:32 --> Utf8 Class Initialized
INFO - 2017-06-22 20:43:32 --> URI Class Initialized
INFO - 2017-06-22 20:43:32 --> Router Class Initialized
INFO - 2017-06-22 20:43:32 --> Output Class Initialized
INFO - 2017-06-22 20:43:32 --> Security Class Initialized
DEBUG - 2017-06-22 20:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:43:32 --> Input Class Initialized
INFO - 2017-06-22 20:43:32 --> Language Class Initialized
INFO - 2017-06-22 20:43:32 --> Loader Class Initialized
INFO - 2017-06-22 20:43:32 --> Controller Class Initialized
INFO - 2017-06-22 20:43:32 --> Database Driver Class Initialized
INFO - 2017-06-22 20:43:32 --> Model Class Initialized
INFO - 2017-06-22 20:43:32 --> Helper loaded: form_helper
INFO - 2017-06-22 20:43:32 --> Helper loaded: url_helper
INFO - 2017-06-22 20:43:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:43:32 --> Model Class Initialized
INFO - 2017-06-22 20:43:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:43:32 --> Final output sent to browser
DEBUG - 2017-06-22 20:43:32 --> Total execution time: 0.0500
ERROR - 2017-06-22 20:43:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:43:34 --> Config Class Initialized
INFO - 2017-06-22 20:43:34 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:43:34 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:43:34 --> Utf8 Class Initialized
INFO - 2017-06-22 20:43:34 --> URI Class Initialized
INFO - 2017-06-22 20:43:34 --> Router Class Initialized
INFO - 2017-06-22 20:43:34 --> Output Class Initialized
INFO - 2017-06-22 20:43:34 --> Security Class Initialized
DEBUG - 2017-06-22 20:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:43:34 --> Input Class Initialized
INFO - 2017-06-22 20:43:34 --> Language Class Initialized
INFO - 2017-06-22 20:43:34 --> Loader Class Initialized
INFO - 2017-06-22 20:43:35 --> Controller Class Initialized
INFO - 2017-06-22 20:43:35 --> Database Driver Class Initialized
INFO - 2017-06-22 20:43:35 --> Model Class Initialized
INFO - 2017-06-22 20:43:35 --> Helper loaded: form_helper
INFO - 2017-06-22 20:43:35 --> Helper loaded: url_helper
INFO - 2017-06-22 20:43:35 --> Model Class Initialized
INFO - 2017-06-22 20:43:35 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:43:35 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:43:35 --> Final output sent to browser
DEBUG - 2017-06-22 20:43:35 --> Total execution time: 0.2560
ERROR - 2017-06-22 20:43:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:43:36 --> Config Class Initialized
INFO - 2017-06-22 20:43:36 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:43:36 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:43:36 --> Utf8 Class Initialized
INFO - 2017-06-22 20:43:36 --> URI Class Initialized
INFO - 2017-06-22 20:43:36 --> Router Class Initialized
INFO - 2017-06-22 20:43:36 --> Output Class Initialized
INFO - 2017-06-22 20:43:36 --> Security Class Initialized
DEBUG - 2017-06-22 20:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:43:36 --> Input Class Initialized
INFO - 2017-06-22 20:43:36 --> Language Class Initialized
INFO - 2017-06-22 20:43:36 --> Loader Class Initialized
INFO - 2017-06-22 20:43:36 --> Controller Class Initialized
INFO - 2017-06-22 20:43:36 --> Database Driver Class Initialized
INFO - 2017-06-22 20:43:36 --> Model Class Initialized
INFO - 2017-06-22 20:43:36 --> Helper loaded: form_helper
INFO - 2017-06-22 20:43:36 --> Helper loaded: url_helper
INFO - 2017-06-22 20:43:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:43:36 --> Model Class Initialized
INFO - 2017-06-22 20:43:36 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 20:43:36 --> Final output sent to browser
DEBUG - 2017-06-22 20:43:36 --> Total execution time: 0.0515
ERROR - 2017-06-22 20:43:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:43:38 --> Config Class Initialized
INFO - 2017-06-22 20:43:38 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:43:38 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:43:38 --> Utf8 Class Initialized
INFO - 2017-06-22 20:43:38 --> URI Class Initialized
INFO - 2017-06-22 20:43:38 --> Router Class Initialized
INFO - 2017-06-22 20:43:38 --> Output Class Initialized
INFO - 2017-06-22 20:43:38 --> Security Class Initialized
DEBUG - 2017-06-22 20:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:43:38 --> Input Class Initialized
INFO - 2017-06-22 20:43:38 --> Language Class Initialized
INFO - 2017-06-22 20:43:38 --> Loader Class Initialized
INFO - 2017-06-22 20:43:38 --> Controller Class Initialized
INFO - 2017-06-22 20:43:38 --> Database Driver Class Initialized
INFO - 2017-06-22 20:43:38 --> Model Class Initialized
INFO - 2017-06-22 20:43:38 --> Helper loaded: form_helper
INFO - 2017-06-22 20:43:38 --> Helper loaded: url_helper
INFO - 2017-06-22 20:43:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:43:38 --> Model Class Initialized
INFO - 2017-06-22 20:43:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:43:38 --> Final output sent to browser
DEBUG - 2017-06-22 20:43:38 --> Total execution time: 0.0640
ERROR - 2017-06-22 20:43:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:43:40 --> Config Class Initialized
INFO - 2017-06-22 20:43:40 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:43:40 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:43:40 --> Utf8 Class Initialized
INFO - 2017-06-22 20:43:40 --> URI Class Initialized
INFO - 2017-06-22 20:43:40 --> Router Class Initialized
INFO - 2017-06-22 20:43:40 --> Output Class Initialized
INFO - 2017-06-22 20:43:40 --> Security Class Initialized
DEBUG - 2017-06-22 20:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:43:40 --> Input Class Initialized
INFO - 2017-06-22 20:43:40 --> Language Class Initialized
INFO - 2017-06-22 20:43:40 --> Loader Class Initialized
INFO - 2017-06-22 20:43:40 --> Controller Class Initialized
INFO - 2017-06-22 20:43:40 --> Database Driver Class Initialized
INFO - 2017-06-22 20:43:40 --> Model Class Initialized
INFO - 2017-06-22 20:43:40 --> Helper loaded: form_helper
INFO - 2017-06-22 20:43:40 --> Helper loaded: url_helper
INFO - 2017-06-22 20:43:40 --> Model Class Initialized
INFO - 2017-06-22 20:43:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:43:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:43:40 --> Final output sent to browser
DEBUG - 2017-06-22 20:43:40 --> Total execution time: 0.0960
ERROR - 2017-06-22 20:43:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:43:53 --> Config Class Initialized
INFO - 2017-06-22 20:43:53 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:43:53 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:43:53 --> Utf8 Class Initialized
INFO - 2017-06-22 20:43:53 --> URI Class Initialized
INFO - 2017-06-22 20:43:53 --> Router Class Initialized
INFO - 2017-06-22 20:43:53 --> Output Class Initialized
INFO - 2017-06-22 20:43:53 --> Security Class Initialized
DEBUG - 2017-06-22 20:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:43:53 --> Input Class Initialized
INFO - 2017-06-22 20:43:53 --> Language Class Initialized
INFO - 2017-06-22 20:43:53 --> Loader Class Initialized
INFO - 2017-06-22 20:43:53 --> Controller Class Initialized
INFO - 2017-06-22 20:43:53 --> Database Driver Class Initialized
INFO - 2017-06-22 20:43:53 --> Model Class Initialized
INFO - 2017-06-22 20:43:53 --> Helper loaded: form_helper
INFO - 2017-06-22 20:43:53 --> Helper loaded: url_helper
INFO - 2017-06-22 20:43:53 --> Model Class Initialized
INFO - 2017-06-22 20:43:53 --> Final output sent to browser
DEBUG - 2017-06-22 20:43:53 --> Total execution time: 0.0900
ERROR - 2017-06-22 20:43:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:43:54 --> Config Class Initialized
INFO - 2017-06-22 20:43:54 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:43:54 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:43:54 --> Utf8 Class Initialized
INFO - 2017-06-22 20:43:54 --> URI Class Initialized
INFO - 2017-06-22 20:43:54 --> Router Class Initialized
INFO - 2017-06-22 20:43:54 --> Output Class Initialized
INFO - 2017-06-22 20:43:54 --> Security Class Initialized
DEBUG - 2017-06-22 20:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:43:54 --> Input Class Initialized
INFO - 2017-06-22 20:43:54 --> Language Class Initialized
INFO - 2017-06-22 20:43:54 --> Loader Class Initialized
INFO - 2017-06-22 20:43:54 --> Controller Class Initialized
INFO - 2017-06-22 20:43:54 --> Database Driver Class Initialized
INFO - 2017-06-22 20:43:54 --> Model Class Initialized
INFO - 2017-06-22 20:43:54 --> Helper loaded: form_helper
INFO - 2017-06-22 20:43:54 --> Helper loaded: url_helper
INFO - 2017-06-22 20:43:54 --> Model Class Initialized
INFO - 2017-06-22 20:43:54 --> Final output sent to browser
DEBUG - 2017-06-22 20:43:54 --> Total execution time: 0.0560
ERROR - 2017-06-22 20:43:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:43:55 --> Config Class Initialized
INFO - 2017-06-22 20:43:55 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:43:55 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:43:55 --> Utf8 Class Initialized
INFO - 2017-06-22 20:43:55 --> URI Class Initialized
INFO - 2017-06-22 20:43:55 --> Router Class Initialized
INFO - 2017-06-22 20:43:55 --> Output Class Initialized
INFO - 2017-06-22 20:43:55 --> Security Class Initialized
DEBUG - 2017-06-22 20:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:43:55 --> Input Class Initialized
INFO - 2017-06-22 20:43:55 --> Language Class Initialized
INFO - 2017-06-22 20:43:55 --> Loader Class Initialized
INFO - 2017-06-22 20:43:55 --> Controller Class Initialized
INFO - 2017-06-22 20:43:55 --> Database Driver Class Initialized
INFO - 2017-06-22 20:43:55 --> Model Class Initialized
INFO - 2017-06-22 20:43:55 --> Helper loaded: form_helper
INFO - 2017-06-22 20:43:55 --> Helper loaded: url_helper
INFO - 2017-06-22 20:43:55 --> Model Class Initialized
INFO - 2017-06-22 20:43:55 --> Final output sent to browser
DEBUG - 2017-06-22 20:43:55 --> Total execution time: 0.0630
ERROR - 2017-06-22 20:43:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:43:58 --> Config Class Initialized
INFO - 2017-06-22 20:43:58 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:43:58 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:43:58 --> Utf8 Class Initialized
INFO - 2017-06-22 20:43:58 --> URI Class Initialized
INFO - 2017-06-22 20:43:58 --> Router Class Initialized
INFO - 2017-06-22 20:43:58 --> Output Class Initialized
INFO - 2017-06-22 20:43:58 --> Security Class Initialized
DEBUG - 2017-06-22 20:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:43:58 --> Input Class Initialized
INFO - 2017-06-22 20:43:58 --> Language Class Initialized
INFO - 2017-06-22 20:43:58 --> Loader Class Initialized
INFO - 2017-06-22 20:43:58 --> Controller Class Initialized
INFO - 2017-06-22 20:43:58 --> Database Driver Class Initialized
INFO - 2017-06-22 20:43:58 --> Model Class Initialized
INFO - 2017-06-22 20:43:58 --> Helper loaded: form_helper
INFO - 2017-06-22 20:43:58 --> Helper loaded: url_helper
INFO - 2017-06-22 20:43:58 --> Model Class Initialized
INFO - 2017-06-22 20:43:58 --> Final output sent to browser
DEBUG - 2017-06-22 20:43:58 --> Total execution time: 0.0550
ERROR - 2017-06-22 20:43:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:43:59 --> Config Class Initialized
INFO - 2017-06-22 20:43:59 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:43:59 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:43:59 --> Utf8 Class Initialized
INFO - 2017-06-22 20:43:59 --> URI Class Initialized
INFO - 2017-06-22 20:43:59 --> Router Class Initialized
INFO - 2017-06-22 20:43:59 --> Output Class Initialized
INFO - 2017-06-22 20:43:59 --> Security Class Initialized
DEBUG - 2017-06-22 20:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:43:59 --> Input Class Initialized
INFO - 2017-06-22 20:43:59 --> Language Class Initialized
INFO - 2017-06-22 20:43:59 --> Loader Class Initialized
INFO - 2017-06-22 20:43:59 --> Controller Class Initialized
INFO - 2017-06-22 20:43:59 --> Database Driver Class Initialized
INFO - 2017-06-22 20:43:59 --> Model Class Initialized
INFO - 2017-06-22 20:43:59 --> Helper loaded: form_helper
INFO - 2017-06-22 20:43:59 --> Helper loaded: url_helper
INFO - 2017-06-22 20:43:59 --> Model Class Initialized
INFO - 2017-06-22 20:43:59 --> Final output sent to browser
DEBUG - 2017-06-22 20:43:59 --> Total execution time: 0.0610
ERROR - 2017-06-22 20:44:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:44:04 --> Config Class Initialized
INFO - 2017-06-22 20:44:04 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:44:04 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:44:04 --> Utf8 Class Initialized
INFO - 2017-06-22 20:44:04 --> URI Class Initialized
INFO - 2017-06-22 20:44:04 --> Router Class Initialized
INFO - 2017-06-22 20:44:04 --> Output Class Initialized
INFO - 2017-06-22 20:44:04 --> Security Class Initialized
DEBUG - 2017-06-22 20:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:44:04 --> Input Class Initialized
INFO - 2017-06-22 20:44:04 --> Language Class Initialized
INFO - 2017-06-22 20:44:04 --> Loader Class Initialized
INFO - 2017-06-22 20:44:04 --> Controller Class Initialized
INFO - 2017-06-22 20:44:04 --> Database Driver Class Initialized
INFO - 2017-06-22 20:44:04 --> Model Class Initialized
INFO - 2017-06-22 20:44:04 --> Helper loaded: form_helper
INFO - 2017-06-22 20:44:04 --> Helper loaded: url_helper
INFO - 2017-06-22 20:44:04 --> Model Class Initialized
INFO - 2017-06-22 20:44:04 --> Final output sent to browser
DEBUG - 2017-06-22 20:44:04 --> Total execution time: 0.0560
ERROR - 2017-06-22 20:44:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:44:29 --> Config Class Initialized
INFO - 2017-06-22 20:44:29 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:44:29 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:44:29 --> Utf8 Class Initialized
INFO - 2017-06-22 20:44:29 --> URI Class Initialized
INFO - 2017-06-22 20:44:29 --> Router Class Initialized
INFO - 2017-06-22 20:44:29 --> Output Class Initialized
INFO - 2017-06-22 20:44:29 --> Security Class Initialized
DEBUG - 2017-06-22 20:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:44:29 --> Input Class Initialized
INFO - 2017-06-22 20:44:29 --> Language Class Initialized
INFO - 2017-06-22 20:44:29 --> Loader Class Initialized
INFO - 2017-06-22 20:44:29 --> Controller Class Initialized
INFO - 2017-06-22 20:44:29 --> Database Driver Class Initialized
INFO - 2017-06-22 20:44:29 --> Model Class Initialized
INFO - 2017-06-22 20:44:29 --> Helper loaded: form_helper
INFO - 2017-06-22 20:44:29 --> Helper loaded: url_helper
INFO - 2017-06-22 20:44:29 --> Model Class Initialized
INFO - 2017-06-22 20:44:29 --> Final output sent to browser
DEBUG - 2017-06-22 20:44:29 --> Total execution time: 0.0675
ERROR - 2017-06-22 20:44:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:44:49 --> Config Class Initialized
INFO - 2017-06-22 20:44:49 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:44:49 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:44:49 --> Utf8 Class Initialized
INFO - 2017-06-22 20:44:49 --> URI Class Initialized
INFO - 2017-06-22 20:44:49 --> Router Class Initialized
INFO - 2017-06-22 20:44:49 --> Output Class Initialized
INFO - 2017-06-22 20:44:49 --> Security Class Initialized
DEBUG - 2017-06-22 20:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:44:49 --> Input Class Initialized
INFO - 2017-06-22 20:44:49 --> Language Class Initialized
INFO - 2017-06-22 20:44:49 --> Loader Class Initialized
INFO - 2017-06-22 20:44:49 --> Controller Class Initialized
INFO - 2017-06-22 20:44:49 --> Database Driver Class Initialized
INFO - 2017-06-22 20:44:49 --> Model Class Initialized
INFO - 2017-06-22 20:44:49 --> Helper loaded: form_helper
INFO - 2017-06-22 20:44:49 --> Helper loaded: url_helper
INFO - 2017-06-22 20:44:49 --> Model Class Initialized
INFO - 2017-06-22 20:44:49 --> Final output sent to browser
DEBUG - 2017-06-22 20:44:49 --> Total execution time: 0.0620
ERROR - 2017-06-22 20:46:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:46:18 --> Config Class Initialized
INFO - 2017-06-22 20:46:18 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:46:18 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:46:18 --> Utf8 Class Initialized
INFO - 2017-06-22 20:46:18 --> URI Class Initialized
INFO - 2017-06-22 20:46:18 --> Router Class Initialized
INFO - 2017-06-22 20:46:18 --> Output Class Initialized
INFO - 2017-06-22 20:46:18 --> Security Class Initialized
DEBUG - 2017-06-22 20:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:46:18 --> Input Class Initialized
INFO - 2017-06-22 20:46:18 --> Language Class Initialized
INFO - 2017-06-22 20:46:18 --> Loader Class Initialized
INFO - 2017-06-22 20:46:18 --> Controller Class Initialized
INFO - 2017-06-22 20:46:18 --> Database Driver Class Initialized
INFO - 2017-06-22 20:46:18 --> Model Class Initialized
INFO - 2017-06-22 20:46:18 --> Helper loaded: form_helper
INFO - 2017-06-22 20:46:18 --> Helper loaded: url_helper
INFO - 2017-06-22 20:46:18 --> Model Class Initialized
INFO - 2017-06-22 20:46:18 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:46:18 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:46:18 --> Final output sent to browser
DEBUG - 2017-06-22 20:46:18 --> Total execution time: 0.0860
ERROR - 2017-06-22 20:46:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:46:20 --> Config Class Initialized
INFO - 2017-06-22 20:46:20 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:46:20 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:46:20 --> Utf8 Class Initialized
INFO - 2017-06-22 20:46:20 --> URI Class Initialized
INFO - 2017-06-22 20:46:20 --> Router Class Initialized
INFO - 2017-06-22 20:46:20 --> Output Class Initialized
INFO - 2017-06-22 20:46:20 --> Security Class Initialized
DEBUG - 2017-06-22 20:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:46:20 --> Input Class Initialized
INFO - 2017-06-22 20:46:20 --> Language Class Initialized
INFO - 2017-06-22 20:46:20 --> Loader Class Initialized
INFO - 2017-06-22 20:46:20 --> Controller Class Initialized
INFO - 2017-06-22 20:46:20 --> Database Driver Class Initialized
INFO - 2017-06-22 20:46:20 --> Model Class Initialized
INFO - 2017-06-22 20:46:20 --> Helper loaded: form_helper
INFO - 2017-06-22 20:46:20 --> Helper loaded: url_helper
INFO - 2017-06-22 20:46:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:46:20 --> Model Class Initialized
INFO - 2017-06-22 20:46:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 20:46:20 --> Final output sent to browser
DEBUG - 2017-06-22 20:46:20 --> Total execution time: 0.0770
ERROR - 2017-06-22 20:46:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:46:22 --> Config Class Initialized
INFO - 2017-06-22 20:46:22 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:46:22 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:46:22 --> Utf8 Class Initialized
INFO - 2017-06-22 20:46:22 --> URI Class Initialized
INFO - 2017-06-22 20:46:22 --> Router Class Initialized
INFO - 2017-06-22 20:46:22 --> Output Class Initialized
INFO - 2017-06-22 20:46:22 --> Security Class Initialized
DEBUG - 2017-06-22 20:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:46:22 --> Input Class Initialized
INFO - 2017-06-22 20:46:22 --> Language Class Initialized
INFO - 2017-06-22 20:46:22 --> Loader Class Initialized
INFO - 2017-06-22 20:46:22 --> Controller Class Initialized
INFO - 2017-06-22 20:46:22 --> Database Driver Class Initialized
INFO - 2017-06-22 20:46:22 --> Model Class Initialized
INFO - 2017-06-22 20:46:22 --> Helper loaded: form_helper
INFO - 2017-06-22 20:46:22 --> Helper loaded: url_helper
INFO - 2017-06-22 20:46:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:46:22 --> Model Class Initialized
INFO - 2017-06-22 20:46:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:46:22 --> Final output sent to browser
DEBUG - 2017-06-22 20:46:22 --> Total execution time: 0.0540
ERROR - 2017-06-22 20:46:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:46:24 --> Config Class Initialized
INFO - 2017-06-22 20:46:24 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:46:24 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:46:24 --> Utf8 Class Initialized
INFO - 2017-06-22 20:46:24 --> URI Class Initialized
INFO - 2017-06-22 20:46:24 --> Router Class Initialized
INFO - 2017-06-22 20:46:24 --> Output Class Initialized
INFO - 2017-06-22 20:46:24 --> Security Class Initialized
DEBUG - 2017-06-22 20:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:46:24 --> Input Class Initialized
INFO - 2017-06-22 20:46:24 --> Language Class Initialized
INFO - 2017-06-22 20:46:24 --> Loader Class Initialized
INFO - 2017-06-22 20:46:24 --> Controller Class Initialized
INFO - 2017-06-22 20:46:24 --> Database Driver Class Initialized
INFO - 2017-06-22 20:46:24 --> Model Class Initialized
INFO - 2017-06-22 20:46:24 --> Helper loaded: form_helper
INFO - 2017-06-22 20:46:24 --> Helper loaded: url_helper
INFO - 2017-06-22 20:46:24 --> Model Class Initialized
INFO - 2017-06-22 20:46:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:46:24 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:46:24 --> Final output sent to browser
DEBUG - 2017-06-22 20:46:24 --> Total execution time: 0.1050
ERROR - 2017-06-22 20:46:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:46:41 --> Config Class Initialized
INFO - 2017-06-22 20:46:41 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:46:41 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:46:41 --> Utf8 Class Initialized
INFO - 2017-06-22 20:46:41 --> URI Class Initialized
INFO - 2017-06-22 20:46:41 --> Router Class Initialized
INFO - 2017-06-22 20:46:41 --> Output Class Initialized
INFO - 2017-06-22 20:46:41 --> Security Class Initialized
DEBUG - 2017-06-22 20:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:46:41 --> Input Class Initialized
INFO - 2017-06-22 20:46:41 --> Language Class Initialized
INFO - 2017-06-22 20:46:41 --> Loader Class Initialized
INFO - 2017-06-22 20:46:41 --> Controller Class Initialized
INFO - 2017-06-22 20:46:41 --> Database Driver Class Initialized
INFO - 2017-06-22 20:46:42 --> Model Class Initialized
INFO - 2017-06-22 20:46:42 --> Helper loaded: form_helper
INFO - 2017-06-22 20:46:42 --> Helper loaded: url_helper
INFO - 2017-06-22 20:46:42 --> Model Class Initialized
INFO - 2017-06-22 20:46:42 --> Final output sent to browser
DEBUG - 2017-06-22 20:46:42 --> Total execution time: 0.0600
ERROR - 2017-06-22 20:46:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:46:43 --> Config Class Initialized
INFO - 2017-06-22 20:46:43 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:46:43 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:46:43 --> Utf8 Class Initialized
INFO - 2017-06-22 20:46:43 --> URI Class Initialized
INFO - 2017-06-22 20:46:43 --> Router Class Initialized
INFO - 2017-06-22 20:46:43 --> Output Class Initialized
INFO - 2017-06-22 20:46:43 --> Security Class Initialized
DEBUG - 2017-06-22 20:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:46:43 --> Input Class Initialized
INFO - 2017-06-22 20:46:43 --> Language Class Initialized
INFO - 2017-06-22 20:46:43 --> Loader Class Initialized
INFO - 2017-06-22 20:46:43 --> Controller Class Initialized
INFO - 2017-06-22 20:46:43 --> Database Driver Class Initialized
INFO - 2017-06-22 20:46:43 --> Model Class Initialized
INFO - 2017-06-22 20:46:43 --> Helper loaded: form_helper
INFO - 2017-06-22 20:46:43 --> Helper loaded: url_helper
INFO - 2017-06-22 20:46:43 --> Model Class Initialized
INFO - 2017-06-22 20:46:43 --> Final output sent to browser
DEBUG - 2017-06-22 20:46:43 --> Total execution time: 0.0460
ERROR - 2017-06-22 20:46:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:46:47 --> Config Class Initialized
INFO - 2017-06-22 20:46:47 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:46:47 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:46:47 --> Utf8 Class Initialized
INFO - 2017-06-22 20:46:47 --> URI Class Initialized
INFO - 2017-06-22 20:46:47 --> Router Class Initialized
INFO - 2017-06-22 20:46:47 --> Output Class Initialized
INFO - 2017-06-22 20:46:47 --> Security Class Initialized
DEBUG - 2017-06-22 20:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:46:47 --> Input Class Initialized
INFO - 2017-06-22 20:46:47 --> Language Class Initialized
INFO - 2017-06-22 20:46:47 --> Loader Class Initialized
INFO - 2017-06-22 20:46:47 --> Controller Class Initialized
INFO - 2017-06-22 20:46:47 --> Database Driver Class Initialized
INFO - 2017-06-22 20:46:47 --> Model Class Initialized
INFO - 2017-06-22 20:46:47 --> Helper loaded: form_helper
INFO - 2017-06-22 20:46:47 --> Helper loaded: url_helper
INFO - 2017-06-22 20:46:47 --> Model Class Initialized
INFO - 2017-06-22 20:46:47 --> Final output sent to browser
DEBUG - 2017-06-22 20:46:47 --> Total execution time: 0.0550
ERROR - 2017-06-22 20:46:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:46:47 --> Config Class Initialized
INFO - 2017-06-22 20:46:47 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:46:47 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:46:47 --> Utf8 Class Initialized
INFO - 2017-06-22 20:46:47 --> URI Class Initialized
INFO - 2017-06-22 20:46:47 --> Router Class Initialized
INFO - 2017-06-22 20:46:47 --> Output Class Initialized
INFO - 2017-06-22 20:46:47 --> Security Class Initialized
DEBUG - 2017-06-22 20:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:46:47 --> Input Class Initialized
INFO - 2017-06-22 20:46:47 --> Language Class Initialized
INFO - 2017-06-22 20:46:47 --> Loader Class Initialized
INFO - 2017-06-22 20:46:47 --> Controller Class Initialized
INFO - 2017-06-22 20:46:47 --> Database Driver Class Initialized
INFO - 2017-06-22 20:46:47 --> Model Class Initialized
INFO - 2017-06-22 20:46:47 --> Helper loaded: form_helper
INFO - 2017-06-22 20:46:47 --> Helper loaded: url_helper
INFO - 2017-06-22 20:46:47 --> Model Class Initialized
INFO - 2017-06-22 20:46:47 --> Final output sent to browser
DEBUG - 2017-06-22 20:46:47 --> Total execution time: 0.0590
ERROR - 2017-06-22 20:46:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:46:48 --> Config Class Initialized
INFO - 2017-06-22 20:46:48 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:46:48 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:46:48 --> Utf8 Class Initialized
INFO - 2017-06-22 20:46:48 --> URI Class Initialized
INFO - 2017-06-22 20:46:48 --> Router Class Initialized
INFO - 2017-06-22 20:46:48 --> Output Class Initialized
INFO - 2017-06-22 20:46:48 --> Security Class Initialized
DEBUG - 2017-06-22 20:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:46:48 --> Input Class Initialized
INFO - 2017-06-22 20:46:48 --> Language Class Initialized
INFO - 2017-06-22 20:46:48 --> Loader Class Initialized
INFO - 2017-06-22 20:46:48 --> Controller Class Initialized
INFO - 2017-06-22 20:46:49 --> Database Driver Class Initialized
INFO - 2017-06-22 20:46:49 --> Model Class Initialized
INFO - 2017-06-22 20:46:49 --> Helper loaded: form_helper
INFO - 2017-06-22 20:46:49 --> Helper loaded: url_helper
INFO - 2017-06-22 20:46:49 --> Model Class Initialized
INFO - 2017-06-22 20:46:49 --> Final output sent to browser
DEBUG - 2017-06-22 20:46:49 --> Total execution time: 0.0610
ERROR - 2017-06-22 20:46:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:46:52 --> Config Class Initialized
INFO - 2017-06-22 20:46:52 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:46:52 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:46:52 --> Utf8 Class Initialized
INFO - 2017-06-22 20:46:52 --> URI Class Initialized
INFO - 2017-06-22 20:46:52 --> Router Class Initialized
INFO - 2017-06-22 20:46:52 --> Output Class Initialized
INFO - 2017-06-22 20:46:52 --> Security Class Initialized
DEBUG - 2017-06-22 20:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:46:52 --> Input Class Initialized
INFO - 2017-06-22 20:46:52 --> Language Class Initialized
INFO - 2017-06-22 20:46:52 --> Loader Class Initialized
INFO - 2017-06-22 20:46:52 --> Controller Class Initialized
INFO - 2017-06-22 20:46:52 --> Database Driver Class Initialized
INFO - 2017-06-22 20:46:52 --> Model Class Initialized
INFO - 2017-06-22 20:46:52 --> Helper loaded: form_helper
INFO - 2017-06-22 20:46:52 --> Helper loaded: url_helper
INFO - 2017-06-22 20:46:52 --> Model Class Initialized
INFO - 2017-06-22 20:46:52 --> Final output sent to browser
DEBUG - 2017-06-22 20:46:52 --> Total execution time: 0.0580
ERROR - 2017-06-22 20:46:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:46:52 --> Config Class Initialized
INFO - 2017-06-22 20:46:52 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:46:52 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:46:52 --> Utf8 Class Initialized
INFO - 2017-06-22 20:46:52 --> URI Class Initialized
INFO - 2017-06-22 20:46:52 --> Router Class Initialized
INFO - 2017-06-22 20:46:52 --> Output Class Initialized
INFO - 2017-06-22 20:46:52 --> Security Class Initialized
DEBUG - 2017-06-22 20:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:46:52 --> Input Class Initialized
INFO - 2017-06-22 20:46:52 --> Language Class Initialized
INFO - 2017-06-22 20:46:52 --> Loader Class Initialized
INFO - 2017-06-22 20:46:52 --> Controller Class Initialized
INFO - 2017-06-22 20:46:52 --> Database Driver Class Initialized
INFO - 2017-06-22 20:46:52 --> Model Class Initialized
INFO - 2017-06-22 20:46:52 --> Helper loaded: form_helper
INFO - 2017-06-22 20:46:52 --> Helper loaded: url_helper
INFO - 2017-06-22 20:46:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:46:52 --> Model Class Initialized
INFO - 2017-06-22 20:46:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 20:46:52 --> Final output sent to browser
DEBUG - 2017-06-22 20:46:52 --> Total execution time: 0.0530
ERROR - 2017-06-22 20:46:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:46:55 --> Config Class Initialized
INFO - 2017-06-22 20:46:55 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:46:55 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:46:55 --> Utf8 Class Initialized
INFO - 2017-06-22 20:46:55 --> URI Class Initialized
INFO - 2017-06-22 20:46:55 --> Router Class Initialized
INFO - 2017-06-22 20:46:55 --> Output Class Initialized
INFO - 2017-06-22 20:46:55 --> Security Class Initialized
DEBUG - 2017-06-22 20:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:46:55 --> Input Class Initialized
INFO - 2017-06-22 20:46:55 --> Language Class Initialized
INFO - 2017-06-22 20:46:55 --> Loader Class Initialized
INFO - 2017-06-22 20:46:55 --> Controller Class Initialized
INFO - 2017-06-22 20:46:55 --> Database Driver Class Initialized
INFO - 2017-06-22 20:46:55 --> Model Class Initialized
INFO - 2017-06-22 20:46:55 --> Helper loaded: form_helper
INFO - 2017-06-22 20:46:55 --> Helper loaded: url_helper
INFO - 2017-06-22 20:46:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:46:55 --> Model Class Initialized
INFO - 2017-06-22 20:46:55 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:46:55 --> Final output sent to browser
DEBUG - 2017-06-22 20:46:55 --> Total execution time: 0.0510
ERROR - 2017-06-22 20:46:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:46:57 --> Config Class Initialized
INFO - 2017-06-22 20:46:57 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:46:57 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:46:57 --> Utf8 Class Initialized
INFO - 2017-06-22 20:46:57 --> URI Class Initialized
INFO - 2017-06-22 20:46:57 --> Router Class Initialized
INFO - 2017-06-22 20:46:57 --> Output Class Initialized
INFO - 2017-06-22 20:46:57 --> Security Class Initialized
DEBUG - 2017-06-22 20:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:46:57 --> Input Class Initialized
INFO - 2017-06-22 20:46:57 --> Language Class Initialized
INFO - 2017-06-22 20:46:57 --> Loader Class Initialized
INFO - 2017-06-22 20:46:57 --> Controller Class Initialized
INFO - 2017-06-22 20:46:57 --> Database Driver Class Initialized
INFO - 2017-06-22 20:46:57 --> Model Class Initialized
INFO - 2017-06-22 20:46:57 --> Helper loaded: form_helper
INFO - 2017-06-22 20:46:57 --> Helper loaded: url_helper
INFO - 2017-06-22 20:46:57 --> Model Class Initialized
INFO - 2017-06-22 20:46:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:46:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:46:57 --> Final output sent to browser
DEBUG - 2017-06-22 20:46:57 --> Total execution time: 0.3870
ERROR - 2017-06-22 20:47:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:47:29 --> Config Class Initialized
INFO - 2017-06-22 20:47:29 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:47:29 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:47:29 --> Utf8 Class Initialized
INFO - 2017-06-22 20:47:29 --> URI Class Initialized
INFO - 2017-06-22 20:47:29 --> Router Class Initialized
INFO - 2017-06-22 20:47:29 --> Output Class Initialized
INFO - 2017-06-22 20:47:29 --> Security Class Initialized
DEBUG - 2017-06-22 20:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:47:29 --> Input Class Initialized
INFO - 2017-06-22 20:47:29 --> Language Class Initialized
INFO - 2017-06-22 20:47:29 --> Loader Class Initialized
INFO - 2017-06-22 20:47:29 --> Controller Class Initialized
INFO - 2017-06-22 20:47:29 --> Database Driver Class Initialized
INFO - 2017-06-22 20:47:29 --> Model Class Initialized
INFO - 2017-06-22 20:47:29 --> Helper loaded: form_helper
INFO - 2017-06-22 20:47:29 --> Helper loaded: url_helper
INFO - 2017-06-22 20:47:29 --> Model Class Initialized
INFO - 2017-06-22 20:47:29 --> Final output sent to browser
DEBUG - 2017-06-22 20:47:29 --> Total execution time: 0.0560
ERROR - 2017-06-22 20:51:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:51:25 --> Config Class Initialized
INFO - 2017-06-22 20:51:25 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:51:25 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:51:25 --> Utf8 Class Initialized
INFO - 2017-06-22 20:51:25 --> URI Class Initialized
INFO - 2017-06-22 20:51:25 --> Router Class Initialized
INFO - 2017-06-22 20:51:25 --> Output Class Initialized
INFO - 2017-06-22 20:51:25 --> Security Class Initialized
DEBUG - 2017-06-22 20:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:51:25 --> Input Class Initialized
INFO - 2017-06-22 20:51:25 --> Language Class Initialized
INFO - 2017-06-22 20:51:25 --> Loader Class Initialized
INFO - 2017-06-22 20:51:25 --> Controller Class Initialized
INFO - 2017-06-22 20:51:25 --> Database Driver Class Initialized
INFO - 2017-06-22 20:51:25 --> Model Class Initialized
INFO - 2017-06-22 20:51:25 --> Helper loaded: form_helper
INFO - 2017-06-22 20:51:25 --> Helper loaded: url_helper
INFO - 2017-06-22 20:51:25 --> Model Class Initialized
INFO - 2017-06-22 20:51:25 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:51:25 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:51:25 --> Final output sent to browser
DEBUG - 2017-06-22 20:51:25 --> Total execution time: 0.1740
ERROR - 2017-06-22 20:51:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:51:28 --> Config Class Initialized
INFO - 2017-06-22 20:51:28 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:51:28 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:51:28 --> Utf8 Class Initialized
INFO - 2017-06-22 20:51:28 --> URI Class Initialized
INFO - 2017-06-22 20:51:28 --> Router Class Initialized
INFO - 2017-06-22 20:51:28 --> Output Class Initialized
INFO - 2017-06-22 20:51:28 --> Security Class Initialized
DEBUG - 2017-06-22 20:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:51:28 --> Input Class Initialized
INFO - 2017-06-22 20:51:28 --> Language Class Initialized
INFO - 2017-06-22 20:51:28 --> Loader Class Initialized
INFO - 2017-06-22 20:51:28 --> Controller Class Initialized
INFO - 2017-06-22 20:51:28 --> Database Driver Class Initialized
INFO - 2017-06-22 20:51:28 --> Model Class Initialized
INFO - 2017-06-22 20:51:28 --> Helper loaded: form_helper
INFO - 2017-06-22 20:51:28 --> Helper loaded: url_helper
INFO - 2017-06-22 20:51:28 --> Model Class Initialized
INFO - 2017-06-22 20:51:28 --> Final output sent to browser
DEBUG - 2017-06-22 20:51:28 --> Total execution time: 0.0500
ERROR - 2017-06-22 20:51:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:51:29 --> Config Class Initialized
INFO - 2017-06-22 20:51:29 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:51:29 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:51:29 --> Utf8 Class Initialized
INFO - 2017-06-22 20:51:29 --> URI Class Initialized
INFO - 2017-06-22 20:51:29 --> Router Class Initialized
INFO - 2017-06-22 20:51:29 --> Output Class Initialized
INFO - 2017-06-22 20:51:29 --> Security Class Initialized
DEBUG - 2017-06-22 20:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:51:29 --> Input Class Initialized
INFO - 2017-06-22 20:51:29 --> Language Class Initialized
INFO - 2017-06-22 20:51:29 --> Loader Class Initialized
INFO - 2017-06-22 20:51:29 --> Controller Class Initialized
INFO - 2017-06-22 20:51:29 --> Database Driver Class Initialized
INFO - 2017-06-22 20:51:29 --> Model Class Initialized
INFO - 2017-06-22 20:51:29 --> Helper loaded: form_helper
INFO - 2017-06-22 20:51:29 --> Helper loaded: url_helper
INFO - 2017-06-22 20:51:29 --> Model Class Initialized
INFO - 2017-06-22 20:51:29 --> Final output sent to browser
DEBUG - 2017-06-22 20:51:29 --> Total execution time: 0.0470
ERROR - 2017-06-22 20:51:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:51:30 --> Config Class Initialized
INFO - 2017-06-22 20:51:30 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:51:30 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:51:30 --> Utf8 Class Initialized
INFO - 2017-06-22 20:51:30 --> URI Class Initialized
INFO - 2017-06-22 20:51:30 --> Router Class Initialized
INFO - 2017-06-22 20:51:30 --> Output Class Initialized
INFO - 2017-06-22 20:51:30 --> Security Class Initialized
DEBUG - 2017-06-22 20:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:51:30 --> Input Class Initialized
INFO - 2017-06-22 20:51:30 --> Language Class Initialized
INFO - 2017-06-22 20:51:30 --> Loader Class Initialized
INFO - 2017-06-22 20:51:30 --> Controller Class Initialized
INFO - 2017-06-22 20:51:30 --> Database Driver Class Initialized
INFO - 2017-06-22 20:51:30 --> Model Class Initialized
INFO - 2017-06-22 20:51:30 --> Helper loaded: form_helper
INFO - 2017-06-22 20:51:30 --> Helper loaded: url_helper
INFO - 2017-06-22 20:51:30 --> Model Class Initialized
INFO - 2017-06-22 20:51:30 --> Final output sent to browser
DEBUG - 2017-06-22 20:51:30 --> Total execution time: 0.0520
ERROR - 2017-06-22 20:51:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:51:33 --> Config Class Initialized
INFO - 2017-06-22 20:51:33 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:51:33 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:51:33 --> Utf8 Class Initialized
INFO - 2017-06-22 20:51:33 --> URI Class Initialized
INFO - 2017-06-22 20:51:33 --> Router Class Initialized
INFO - 2017-06-22 20:51:33 --> Output Class Initialized
INFO - 2017-06-22 20:51:33 --> Security Class Initialized
DEBUG - 2017-06-22 20:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:51:33 --> Input Class Initialized
INFO - 2017-06-22 20:51:33 --> Language Class Initialized
INFO - 2017-06-22 20:51:33 --> Loader Class Initialized
INFO - 2017-06-22 20:51:33 --> Controller Class Initialized
INFO - 2017-06-22 20:51:33 --> Database Driver Class Initialized
INFO - 2017-06-22 20:51:33 --> Model Class Initialized
INFO - 2017-06-22 20:51:33 --> Helper loaded: form_helper
INFO - 2017-06-22 20:51:33 --> Helper loaded: url_helper
INFO - 2017-06-22 20:51:33 --> Model Class Initialized
INFO - 2017-06-22 20:51:33 --> Final output sent to browser
DEBUG - 2017-06-22 20:51:33 --> Total execution time: 0.0410
ERROR - 2017-06-22 20:52:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:52:00 --> Config Class Initialized
INFO - 2017-06-22 20:52:00 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:52:00 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:52:00 --> Utf8 Class Initialized
INFO - 2017-06-22 20:52:00 --> URI Class Initialized
INFO - 2017-06-22 20:52:00 --> Router Class Initialized
INFO - 2017-06-22 20:52:00 --> Output Class Initialized
INFO - 2017-06-22 20:52:00 --> Security Class Initialized
DEBUG - 2017-06-22 20:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:52:00 --> Input Class Initialized
INFO - 2017-06-22 20:52:00 --> Language Class Initialized
INFO - 2017-06-22 20:52:00 --> Loader Class Initialized
INFO - 2017-06-22 20:52:00 --> Controller Class Initialized
INFO - 2017-06-22 20:52:00 --> Database Driver Class Initialized
INFO - 2017-06-22 20:52:00 --> Model Class Initialized
INFO - 2017-06-22 20:52:01 --> Helper loaded: form_helper
INFO - 2017-06-22 20:52:01 --> Helper loaded: url_helper
INFO - 2017-06-22 20:52:01 --> Model Class Initialized
INFO - 2017-06-22 20:52:01 --> Final output sent to browser
DEBUG - 2017-06-22 20:52:01 --> Total execution time: 0.0850
ERROR - 2017-06-22 20:56:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:56:32 --> Config Class Initialized
INFO - 2017-06-22 20:56:32 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:56:32 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:56:32 --> Utf8 Class Initialized
INFO - 2017-06-22 20:56:32 --> URI Class Initialized
INFO - 2017-06-22 20:56:32 --> Router Class Initialized
INFO - 2017-06-22 20:56:32 --> Output Class Initialized
INFO - 2017-06-22 20:56:32 --> Security Class Initialized
DEBUG - 2017-06-22 20:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:56:32 --> Input Class Initialized
INFO - 2017-06-22 20:56:32 --> Language Class Initialized
INFO - 2017-06-22 20:56:32 --> Loader Class Initialized
INFO - 2017-06-22 20:56:32 --> Controller Class Initialized
INFO - 2017-06-22 20:56:32 --> Database Driver Class Initialized
INFO - 2017-06-22 20:56:32 --> Model Class Initialized
INFO - 2017-06-22 20:56:32 --> Helper loaded: form_helper
INFO - 2017-06-22 20:56:32 --> Helper loaded: url_helper
INFO - 2017-06-22 20:56:32 --> Model Class Initialized
INFO - 2017-06-22 20:56:32 --> Final output sent to browser
DEBUG - 2017-06-22 20:56:32 --> Total execution time: 0.0630
ERROR - 2017-06-22 20:56:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:56:33 --> Config Class Initialized
INFO - 2017-06-22 20:56:33 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:56:33 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:56:33 --> Utf8 Class Initialized
INFO - 2017-06-22 20:56:33 --> URI Class Initialized
INFO - 2017-06-22 20:56:33 --> Router Class Initialized
INFO - 2017-06-22 20:56:33 --> Output Class Initialized
INFO - 2017-06-22 20:56:33 --> Security Class Initialized
DEBUG - 2017-06-22 20:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:56:33 --> Input Class Initialized
INFO - 2017-06-22 20:56:33 --> Language Class Initialized
INFO - 2017-06-22 20:56:33 --> Loader Class Initialized
INFO - 2017-06-22 20:56:33 --> Controller Class Initialized
INFO - 2017-06-22 20:56:33 --> Database Driver Class Initialized
INFO - 2017-06-22 20:56:33 --> Model Class Initialized
INFO - 2017-06-22 20:56:33 --> Helper loaded: form_helper
INFO - 2017-06-22 20:56:33 --> Helper loaded: url_helper
INFO - 2017-06-22 20:56:33 --> Model Class Initialized
INFO - 2017-06-22 20:56:33 --> Final output sent to browser
DEBUG - 2017-06-22 20:56:33 --> Total execution time: 0.0430
ERROR - 2017-06-22 20:57:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:57:01 --> Config Class Initialized
INFO - 2017-06-22 20:57:01 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:57:01 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:57:01 --> Utf8 Class Initialized
INFO - 2017-06-22 20:57:01 --> URI Class Initialized
INFO - 2017-06-22 20:57:01 --> Router Class Initialized
INFO - 2017-06-22 20:57:01 --> Output Class Initialized
INFO - 2017-06-22 20:57:01 --> Security Class Initialized
DEBUG - 2017-06-22 20:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:57:01 --> Input Class Initialized
INFO - 2017-06-22 20:57:01 --> Language Class Initialized
INFO - 2017-06-22 20:57:01 --> Loader Class Initialized
INFO - 2017-06-22 20:57:01 --> Controller Class Initialized
INFO - 2017-06-22 20:57:01 --> Database Driver Class Initialized
INFO - 2017-06-22 20:57:01 --> Model Class Initialized
INFO - 2017-06-22 20:57:01 --> Helper loaded: form_helper
INFO - 2017-06-22 20:57:01 --> Helper loaded: url_helper
INFO - 2017-06-22 20:57:01 --> Model Class Initialized
INFO - 2017-06-22 20:57:01 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:57:01 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:57:01 --> Final output sent to browser
DEBUG - 2017-06-22 20:57:01 --> Total execution time: 0.0740
ERROR - 2017-06-22 20:57:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:57:04 --> Config Class Initialized
INFO - 2017-06-22 20:57:04 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:57:04 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:57:04 --> Utf8 Class Initialized
INFO - 2017-06-22 20:57:04 --> URI Class Initialized
INFO - 2017-06-22 20:57:04 --> Router Class Initialized
INFO - 2017-06-22 20:57:04 --> Output Class Initialized
INFO - 2017-06-22 20:57:04 --> Security Class Initialized
DEBUG - 2017-06-22 20:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:57:04 --> Input Class Initialized
INFO - 2017-06-22 20:57:04 --> Language Class Initialized
INFO - 2017-06-22 20:57:04 --> Loader Class Initialized
INFO - 2017-06-22 20:57:04 --> Controller Class Initialized
INFO - 2017-06-22 20:57:04 --> Database Driver Class Initialized
INFO - 2017-06-22 20:57:05 --> Model Class Initialized
INFO - 2017-06-22 20:57:05 --> Helper loaded: form_helper
INFO - 2017-06-22 20:57:05 --> Helper loaded: url_helper
INFO - 2017-06-22 20:57:05 --> Model Class Initialized
INFO - 2017-06-22 20:57:05 --> Final output sent to browser
DEBUG - 2017-06-22 20:57:05 --> Total execution time: 0.0590
ERROR - 2017-06-22 20:57:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:57:05 --> Config Class Initialized
INFO - 2017-06-22 20:57:05 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:57:05 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:57:05 --> Utf8 Class Initialized
INFO - 2017-06-22 20:57:05 --> URI Class Initialized
INFO - 2017-06-22 20:57:05 --> Router Class Initialized
INFO - 2017-06-22 20:57:05 --> Output Class Initialized
INFO - 2017-06-22 20:57:05 --> Security Class Initialized
DEBUG - 2017-06-22 20:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:57:05 --> Input Class Initialized
INFO - 2017-06-22 20:57:05 --> Language Class Initialized
INFO - 2017-06-22 20:57:05 --> Loader Class Initialized
INFO - 2017-06-22 20:57:05 --> Controller Class Initialized
INFO - 2017-06-22 20:57:05 --> Database Driver Class Initialized
INFO - 2017-06-22 20:57:05 --> Model Class Initialized
INFO - 2017-06-22 20:57:05 --> Helper loaded: form_helper
INFO - 2017-06-22 20:57:05 --> Helper loaded: url_helper
INFO - 2017-06-22 20:57:05 --> Model Class Initialized
INFO - 2017-06-22 20:57:05 --> Final output sent to browser
DEBUG - 2017-06-22 20:57:05 --> Total execution time: 0.0480
ERROR - 2017-06-22 20:57:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:57:06 --> Config Class Initialized
INFO - 2017-06-22 20:57:06 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:57:06 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:57:06 --> Utf8 Class Initialized
INFO - 2017-06-22 20:57:06 --> URI Class Initialized
INFO - 2017-06-22 20:57:06 --> Router Class Initialized
INFO - 2017-06-22 20:57:06 --> Output Class Initialized
INFO - 2017-06-22 20:57:06 --> Security Class Initialized
DEBUG - 2017-06-22 20:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:57:06 --> Input Class Initialized
INFO - 2017-06-22 20:57:06 --> Language Class Initialized
INFO - 2017-06-22 20:57:06 --> Loader Class Initialized
INFO - 2017-06-22 20:57:06 --> Controller Class Initialized
INFO - 2017-06-22 20:57:06 --> Database Driver Class Initialized
INFO - 2017-06-22 20:57:06 --> Model Class Initialized
INFO - 2017-06-22 20:57:06 --> Helper loaded: form_helper
INFO - 2017-06-22 20:57:06 --> Helper loaded: url_helper
INFO - 2017-06-22 20:57:06 --> Model Class Initialized
INFO - 2017-06-22 20:57:06 --> Final output sent to browser
DEBUG - 2017-06-22 20:57:06 --> Total execution time: 0.0640
ERROR - 2017-06-22 20:57:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:57:09 --> Config Class Initialized
INFO - 2017-06-22 20:57:09 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:57:09 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:57:09 --> Utf8 Class Initialized
INFO - 2017-06-22 20:57:09 --> URI Class Initialized
INFO - 2017-06-22 20:57:09 --> Router Class Initialized
INFO - 2017-06-22 20:57:09 --> Output Class Initialized
INFO - 2017-06-22 20:57:09 --> Security Class Initialized
DEBUG - 2017-06-22 20:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:57:09 --> Input Class Initialized
INFO - 2017-06-22 20:57:09 --> Language Class Initialized
INFO - 2017-06-22 20:57:09 --> Loader Class Initialized
INFO - 2017-06-22 20:57:09 --> Controller Class Initialized
INFO - 2017-06-22 20:57:09 --> Database Driver Class Initialized
INFO - 2017-06-22 20:57:09 --> Model Class Initialized
INFO - 2017-06-22 20:57:09 --> Helper loaded: form_helper
INFO - 2017-06-22 20:57:09 --> Helper loaded: url_helper
INFO - 2017-06-22 20:57:09 --> Model Class Initialized
INFO - 2017-06-22 20:57:09 --> Final output sent to browser
DEBUG - 2017-06-22 20:57:09 --> Total execution time: 0.0610
ERROR - 2017-06-22 20:57:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:57:38 --> Config Class Initialized
INFO - 2017-06-22 20:57:38 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:57:38 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:57:38 --> Utf8 Class Initialized
INFO - 2017-06-22 20:57:38 --> URI Class Initialized
INFO - 2017-06-22 20:57:38 --> Router Class Initialized
INFO - 2017-06-22 20:57:38 --> Output Class Initialized
INFO - 2017-06-22 20:57:38 --> Security Class Initialized
DEBUG - 2017-06-22 20:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:57:38 --> Input Class Initialized
INFO - 2017-06-22 20:57:38 --> Language Class Initialized
INFO - 2017-06-22 20:57:38 --> Loader Class Initialized
INFO - 2017-06-22 20:57:38 --> Controller Class Initialized
INFO - 2017-06-22 20:57:38 --> Database Driver Class Initialized
INFO - 2017-06-22 20:57:38 --> Model Class Initialized
INFO - 2017-06-22 20:57:38 --> Helper loaded: form_helper
INFO - 2017-06-22 20:57:38 --> Helper loaded: url_helper
INFO - 2017-06-22 20:57:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:57:38 --> Model Class Initialized
INFO - 2017-06-22 20:57:38 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 20:57:38 --> Final output sent to browser
DEBUG - 2017-06-22 20:57:38 --> Total execution time: 0.0600
ERROR - 2017-06-22 20:57:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:57:41 --> Config Class Initialized
INFO - 2017-06-22 20:57:41 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:57:41 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:57:41 --> Utf8 Class Initialized
INFO - 2017-06-22 20:57:41 --> URI Class Initialized
INFO - 2017-06-22 20:57:41 --> Router Class Initialized
INFO - 2017-06-22 20:57:41 --> Output Class Initialized
INFO - 2017-06-22 20:57:41 --> Security Class Initialized
DEBUG - 2017-06-22 20:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:57:41 --> Input Class Initialized
INFO - 2017-06-22 20:57:41 --> Language Class Initialized
INFO - 2017-06-22 20:57:41 --> Loader Class Initialized
INFO - 2017-06-22 20:57:41 --> Controller Class Initialized
INFO - 2017-06-22 20:57:41 --> Database Driver Class Initialized
INFO - 2017-06-22 20:57:41 --> Model Class Initialized
INFO - 2017-06-22 20:57:41 --> Helper loaded: form_helper
INFO - 2017-06-22 20:57:41 --> Helper loaded: url_helper
INFO - 2017-06-22 20:57:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:57:41 --> Model Class Initialized
INFO - 2017-06-22 20:57:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:57:41 --> Final output sent to browser
DEBUG - 2017-06-22 20:57:41 --> Total execution time: 0.0610
ERROR - 2017-06-22 20:57:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:57:44 --> Config Class Initialized
INFO - 2017-06-22 20:57:44 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:57:44 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:57:44 --> Utf8 Class Initialized
INFO - 2017-06-22 20:57:44 --> URI Class Initialized
INFO - 2017-06-22 20:57:44 --> Router Class Initialized
INFO - 2017-06-22 20:57:44 --> Output Class Initialized
INFO - 2017-06-22 20:57:44 --> Security Class Initialized
DEBUG - 2017-06-22 20:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:57:44 --> Input Class Initialized
INFO - 2017-06-22 20:57:44 --> Language Class Initialized
INFO - 2017-06-22 20:57:44 --> Loader Class Initialized
INFO - 2017-06-22 20:57:44 --> Controller Class Initialized
INFO - 2017-06-22 20:57:44 --> Database Driver Class Initialized
INFO - 2017-06-22 20:57:44 --> Model Class Initialized
INFO - 2017-06-22 20:57:44 --> Helper loaded: form_helper
INFO - 2017-06-22 20:57:44 --> Helper loaded: url_helper
INFO - 2017-06-22 20:57:44 --> Model Class Initialized
INFO - 2017-06-22 20:57:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:57:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:57:44 --> Final output sent to browser
DEBUG - 2017-06-22 20:57:44 --> Total execution time: 0.3380
ERROR - 2017-06-22 20:57:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:57:50 --> Config Class Initialized
INFO - 2017-06-22 20:57:50 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:57:50 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:57:50 --> Utf8 Class Initialized
INFO - 2017-06-22 20:57:50 --> URI Class Initialized
INFO - 2017-06-22 20:57:50 --> Router Class Initialized
INFO - 2017-06-22 20:57:50 --> Output Class Initialized
INFO - 2017-06-22 20:57:50 --> Security Class Initialized
DEBUG - 2017-06-22 20:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:57:50 --> Input Class Initialized
INFO - 2017-06-22 20:57:50 --> Language Class Initialized
INFO - 2017-06-22 20:57:50 --> Loader Class Initialized
INFO - 2017-06-22 20:57:50 --> Controller Class Initialized
INFO - 2017-06-22 20:57:50 --> Database Driver Class Initialized
INFO - 2017-06-22 20:57:50 --> Model Class Initialized
INFO - 2017-06-22 20:57:50 --> Helper loaded: form_helper
INFO - 2017-06-22 20:57:50 --> Helper loaded: url_helper
INFO - 2017-06-22 20:57:50 --> Model Class Initialized
INFO - 2017-06-22 20:57:50 --> Final output sent to browser
DEBUG - 2017-06-22 20:57:50 --> Total execution time: 0.1090
ERROR - 2017-06-22 20:57:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:57:51 --> Config Class Initialized
INFO - 2017-06-22 20:57:51 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:57:51 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:57:51 --> Utf8 Class Initialized
INFO - 2017-06-22 20:57:51 --> URI Class Initialized
INFO - 2017-06-22 20:57:51 --> Router Class Initialized
INFO - 2017-06-22 20:57:51 --> Output Class Initialized
INFO - 2017-06-22 20:57:51 --> Security Class Initialized
DEBUG - 2017-06-22 20:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:57:51 --> Input Class Initialized
INFO - 2017-06-22 20:57:51 --> Language Class Initialized
INFO - 2017-06-22 20:57:51 --> Loader Class Initialized
INFO - 2017-06-22 20:57:51 --> Controller Class Initialized
INFO - 2017-06-22 20:57:51 --> Database Driver Class Initialized
INFO - 2017-06-22 20:57:51 --> Model Class Initialized
INFO - 2017-06-22 20:57:51 --> Helper loaded: form_helper
INFO - 2017-06-22 20:57:51 --> Helper loaded: url_helper
INFO - 2017-06-22 20:57:51 --> Model Class Initialized
INFO - 2017-06-22 20:57:51 --> Final output sent to browser
DEBUG - 2017-06-22 20:57:51 --> Total execution time: 0.0560
ERROR - 2017-06-22 20:57:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:57:54 --> Config Class Initialized
INFO - 2017-06-22 20:57:54 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:57:54 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:57:54 --> Utf8 Class Initialized
INFO - 2017-06-22 20:57:54 --> URI Class Initialized
INFO - 2017-06-22 20:57:54 --> Router Class Initialized
INFO - 2017-06-22 20:57:54 --> Output Class Initialized
INFO - 2017-06-22 20:57:54 --> Security Class Initialized
DEBUG - 2017-06-22 20:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:57:54 --> Input Class Initialized
INFO - 2017-06-22 20:57:54 --> Language Class Initialized
INFO - 2017-06-22 20:57:54 --> Loader Class Initialized
INFO - 2017-06-22 20:57:54 --> Controller Class Initialized
INFO - 2017-06-22 20:57:54 --> Database Driver Class Initialized
INFO - 2017-06-22 20:57:54 --> Model Class Initialized
INFO - 2017-06-22 20:57:54 --> Helper loaded: form_helper
INFO - 2017-06-22 20:57:54 --> Helper loaded: url_helper
INFO - 2017-06-22 20:57:54 --> Model Class Initialized
INFO - 2017-06-22 20:57:54 --> Final output sent to browser
DEBUG - 2017-06-22 20:57:54 --> Total execution time: 0.0550
ERROR - 2017-06-22 20:58:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:58:09 --> Config Class Initialized
INFO - 2017-06-22 20:58:09 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:58:09 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:58:09 --> Utf8 Class Initialized
INFO - 2017-06-22 20:58:09 --> URI Class Initialized
INFO - 2017-06-22 20:58:09 --> Router Class Initialized
INFO - 2017-06-22 20:58:09 --> Output Class Initialized
INFO - 2017-06-22 20:58:09 --> Security Class Initialized
DEBUG - 2017-06-22 20:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:58:09 --> Input Class Initialized
INFO - 2017-06-22 20:58:09 --> Language Class Initialized
INFO - 2017-06-22 20:58:09 --> Loader Class Initialized
INFO - 2017-06-22 20:58:09 --> Controller Class Initialized
INFO - 2017-06-22 20:58:09 --> Database Driver Class Initialized
INFO - 2017-06-22 20:58:09 --> Model Class Initialized
INFO - 2017-06-22 20:58:09 --> Helper loaded: form_helper
INFO - 2017-06-22 20:58:09 --> Helper loaded: url_helper
INFO - 2017-06-22 20:58:09 --> Model Class Initialized
INFO - 2017-06-22 20:58:09 --> Final output sent to browser
DEBUG - 2017-06-22 20:58:09 --> Total execution time: 0.0570
ERROR - 2017-06-22 20:58:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:58:30 --> Config Class Initialized
INFO - 2017-06-22 20:58:30 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:58:30 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:58:30 --> Utf8 Class Initialized
INFO - 2017-06-22 20:58:30 --> URI Class Initialized
INFO - 2017-06-22 20:58:30 --> Router Class Initialized
INFO - 2017-06-22 20:58:30 --> Output Class Initialized
INFO - 2017-06-22 20:58:30 --> Security Class Initialized
DEBUG - 2017-06-22 20:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:58:30 --> Input Class Initialized
INFO - 2017-06-22 20:58:30 --> Language Class Initialized
INFO - 2017-06-22 20:58:30 --> Loader Class Initialized
INFO - 2017-06-22 20:58:30 --> Controller Class Initialized
INFO - 2017-06-22 20:58:30 --> Database Driver Class Initialized
INFO - 2017-06-22 20:58:30 --> Model Class Initialized
INFO - 2017-06-22 20:58:30 --> Helper loaded: form_helper
INFO - 2017-06-22 20:58:30 --> Helper loaded: url_helper
INFO - 2017-06-22 20:58:30 --> Model Class Initialized
INFO - 2017-06-22 20:58:30 --> Final output sent to browser
DEBUG - 2017-06-22 20:58:30 --> Total execution time: 0.0550
ERROR - 2017-06-22 20:58:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:58:38 --> Config Class Initialized
INFO - 2017-06-22 20:58:38 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:58:38 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:58:38 --> Utf8 Class Initialized
INFO - 2017-06-22 20:58:38 --> URI Class Initialized
INFO - 2017-06-22 20:58:38 --> Router Class Initialized
INFO - 2017-06-22 20:58:38 --> Output Class Initialized
INFO - 2017-06-22 20:58:38 --> Security Class Initialized
DEBUG - 2017-06-22 20:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:58:38 --> Input Class Initialized
INFO - 2017-06-22 20:58:38 --> Language Class Initialized
INFO - 2017-06-22 20:58:38 --> Loader Class Initialized
INFO - 2017-06-22 20:58:38 --> Controller Class Initialized
INFO - 2017-06-22 20:58:38 --> Database Driver Class Initialized
INFO - 2017-06-22 20:58:39 --> Model Class Initialized
INFO - 2017-06-22 20:58:39 --> Helper loaded: form_helper
INFO - 2017-06-22 20:58:39 --> Helper loaded: url_helper
INFO - 2017-06-22 20:58:39 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:58:39 --> Model Class Initialized
INFO - 2017-06-22 20:58:39 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 20:58:39 --> Final output sent to browser
DEBUG - 2017-06-22 20:58:39 --> Total execution time: 0.0470
ERROR - 2017-06-22 20:58:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:58:44 --> Config Class Initialized
INFO - 2017-06-22 20:58:44 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:58:44 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:58:44 --> Utf8 Class Initialized
INFO - 2017-06-22 20:58:44 --> URI Class Initialized
INFO - 2017-06-22 20:58:44 --> Router Class Initialized
INFO - 2017-06-22 20:58:44 --> Output Class Initialized
INFO - 2017-06-22 20:58:44 --> Security Class Initialized
DEBUG - 2017-06-22 20:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:58:44 --> Input Class Initialized
INFO - 2017-06-22 20:58:44 --> Language Class Initialized
INFO - 2017-06-22 20:58:44 --> Loader Class Initialized
INFO - 2017-06-22 20:58:44 --> Controller Class Initialized
INFO - 2017-06-22 20:58:44 --> Database Driver Class Initialized
INFO - 2017-06-22 20:58:44 --> Model Class Initialized
INFO - 2017-06-22 20:58:44 --> Helper loaded: form_helper
INFO - 2017-06-22 20:58:44 --> Helper loaded: url_helper
INFO - 2017-06-22 20:58:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:58:44 --> Model Class Initialized
INFO - 2017-06-22 20:58:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:58:44 --> Final output sent to browser
DEBUG - 2017-06-22 20:58:44 --> Total execution time: 0.0620
ERROR - 2017-06-22 20:58:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:58:54 --> Config Class Initialized
INFO - 2017-06-22 20:58:54 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:58:54 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:58:54 --> Utf8 Class Initialized
INFO - 2017-06-22 20:58:54 --> URI Class Initialized
INFO - 2017-06-22 20:58:54 --> Router Class Initialized
INFO - 2017-06-22 20:58:54 --> Output Class Initialized
INFO - 2017-06-22 20:58:54 --> Security Class Initialized
DEBUG - 2017-06-22 20:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:58:54 --> Input Class Initialized
INFO - 2017-06-22 20:58:54 --> Language Class Initialized
INFO - 2017-06-22 20:58:54 --> Loader Class Initialized
INFO - 2017-06-22 20:58:54 --> Controller Class Initialized
INFO - 2017-06-22 20:58:54 --> Database Driver Class Initialized
INFO - 2017-06-22 20:58:54 --> Model Class Initialized
INFO - 2017-06-22 20:58:54 --> Helper loaded: form_helper
INFO - 2017-06-22 20:58:54 --> Helper loaded: url_helper
INFO - 2017-06-22 20:58:54 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:58:54 --> Model Class Initialized
INFO - 2017-06-22 20:58:54 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-22 20:58:54 --> Final output sent to browser
DEBUG - 2017-06-22 20:58:54 --> Total execution time: 0.0890
ERROR - 2017-06-22 20:58:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:58:57 --> Config Class Initialized
INFO - 2017-06-22 20:58:57 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:58:57 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:58:57 --> Utf8 Class Initialized
INFO - 2017-06-22 20:58:57 --> URI Class Initialized
INFO - 2017-06-22 20:58:57 --> Router Class Initialized
INFO - 2017-06-22 20:58:57 --> Output Class Initialized
INFO - 2017-06-22 20:58:57 --> Security Class Initialized
DEBUG - 2017-06-22 20:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:58:57 --> Input Class Initialized
INFO - 2017-06-22 20:58:57 --> Language Class Initialized
INFO - 2017-06-22 20:58:57 --> Loader Class Initialized
INFO - 2017-06-22 20:58:57 --> Controller Class Initialized
INFO - 2017-06-22 20:58:57 --> Database Driver Class Initialized
INFO - 2017-06-22 20:58:57 --> Model Class Initialized
INFO - 2017-06-22 20:58:57 --> Helper loaded: form_helper
INFO - 2017-06-22 20:58:57 --> Helper loaded: url_helper
INFO - 2017-06-22 20:58:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:58:57 --> Model Class Initialized
INFO - 2017-06-22 20:58:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:58:57 --> Final output sent to browser
DEBUG - 2017-06-22 20:58:57 --> Total execution time: 0.0620
ERROR - 2017-06-22 20:59:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:59:05 --> Config Class Initialized
INFO - 2017-06-22 20:59:05 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:59:05 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:59:05 --> Utf8 Class Initialized
INFO - 2017-06-22 20:59:05 --> URI Class Initialized
INFO - 2017-06-22 20:59:05 --> Router Class Initialized
INFO - 2017-06-22 20:59:05 --> Output Class Initialized
INFO - 2017-06-22 20:59:05 --> Security Class Initialized
DEBUG - 2017-06-22 20:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:59:05 --> Input Class Initialized
INFO - 2017-06-22 20:59:05 --> Language Class Initialized
INFO - 2017-06-22 20:59:05 --> Loader Class Initialized
INFO - 2017-06-22 20:59:05 --> Controller Class Initialized
INFO - 2017-06-22 20:59:05 --> Database Driver Class Initialized
INFO - 2017-06-22 20:59:05 --> Model Class Initialized
INFO - 2017-06-22 20:59:05 --> Helper loaded: form_helper
INFO - 2017-06-22 20:59:05 --> Helper loaded: url_helper
INFO - 2017-06-22 20:59:05 --> Model Class Initialized
INFO - 2017-06-22 20:59:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-22 20:59:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-22 20:59:06 --> Final output sent to browser
DEBUG - 2017-06-22 20:59:06 --> Total execution time: 0.4720
ERROR - 2017-06-22 20:59:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:59:11 --> Config Class Initialized
INFO - 2017-06-22 20:59:11 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:59:11 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:59:11 --> Utf8 Class Initialized
INFO - 2017-06-22 20:59:11 --> URI Class Initialized
INFO - 2017-06-22 20:59:11 --> Router Class Initialized
INFO - 2017-06-22 20:59:11 --> Output Class Initialized
INFO - 2017-06-22 20:59:11 --> Security Class Initialized
DEBUG - 2017-06-22 20:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:59:11 --> Input Class Initialized
INFO - 2017-06-22 20:59:11 --> Language Class Initialized
INFO - 2017-06-22 20:59:11 --> Loader Class Initialized
INFO - 2017-06-22 20:59:11 --> Controller Class Initialized
INFO - 2017-06-22 20:59:11 --> Database Driver Class Initialized
INFO - 2017-06-22 20:59:11 --> Model Class Initialized
INFO - 2017-06-22 20:59:11 --> Helper loaded: form_helper
INFO - 2017-06-22 20:59:11 --> Helper loaded: url_helper
INFO - 2017-06-22 20:59:11 --> Model Class Initialized
INFO - 2017-06-22 20:59:11 --> Final output sent to browser
DEBUG - 2017-06-22 20:59:11 --> Total execution time: 0.0610
ERROR - 2017-06-22 20:59:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:59:13 --> Config Class Initialized
INFO - 2017-06-22 20:59:13 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:59:13 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:59:13 --> Utf8 Class Initialized
INFO - 2017-06-22 20:59:13 --> URI Class Initialized
INFO - 2017-06-22 20:59:13 --> Router Class Initialized
INFO - 2017-06-22 20:59:13 --> Output Class Initialized
INFO - 2017-06-22 20:59:13 --> Security Class Initialized
DEBUG - 2017-06-22 20:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:59:13 --> Input Class Initialized
INFO - 2017-06-22 20:59:13 --> Language Class Initialized
INFO - 2017-06-22 20:59:13 --> Loader Class Initialized
INFO - 2017-06-22 20:59:13 --> Controller Class Initialized
INFO - 2017-06-22 20:59:13 --> Database Driver Class Initialized
INFO - 2017-06-22 20:59:13 --> Model Class Initialized
INFO - 2017-06-22 20:59:13 --> Helper loaded: form_helper
INFO - 2017-06-22 20:59:13 --> Helper loaded: url_helper
INFO - 2017-06-22 20:59:13 --> Model Class Initialized
INFO - 2017-06-22 20:59:13 --> Final output sent to browser
DEBUG - 2017-06-22 20:59:13 --> Total execution time: 0.0540
ERROR - 2017-06-22 20:59:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:59:18 --> Config Class Initialized
INFO - 2017-06-22 20:59:18 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:59:18 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:59:18 --> Utf8 Class Initialized
INFO - 2017-06-22 20:59:18 --> URI Class Initialized
INFO - 2017-06-22 20:59:18 --> Router Class Initialized
INFO - 2017-06-22 20:59:18 --> Output Class Initialized
INFO - 2017-06-22 20:59:18 --> Security Class Initialized
DEBUG - 2017-06-22 20:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:59:18 --> Input Class Initialized
INFO - 2017-06-22 20:59:18 --> Language Class Initialized
INFO - 2017-06-22 20:59:18 --> Loader Class Initialized
INFO - 2017-06-22 20:59:18 --> Controller Class Initialized
INFO - 2017-06-22 20:59:18 --> Database Driver Class Initialized
INFO - 2017-06-22 20:59:18 --> Model Class Initialized
INFO - 2017-06-22 20:59:18 --> Helper loaded: form_helper
INFO - 2017-06-22 20:59:18 --> Helper loaded: url_helper
INFO - 2017-06-22 20:59:18 --> Model Class Initialized
INFO - 2017-06-22 20:59:18 --> Final output sent to browser
DEBUG - 2017-06-22 20:59:18 --> Total execution time: 0.0610
ERROR - 2017-06-22 20:59:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:59:34 --> Config Class Initialized
INFO - 2017-06-22 20:59:34 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:59:34 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:59:34 --> Utf8 Class Initialized
INFO - 2017-06-22 20:59:34 --> URI Class Initialized
INFO - 2017-06-22 20:59:34 --> Router Class Initialized
INFO - 2017-06-22 20:59:34 --> Output Class Initialized
INFO - 2017-06-22 20:59:34 --> Security Class Initialized
DEBUG - 2017-06-22 20:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:59:34 --> Input Class Initialized
INFO - 2017-06-22 20:59:34 --> Language Class Initialized
INFO - 2017-06-22 20:59:34 --> Loader Class Initialized
INFO - 2017-06-22 20:59:34 --> Controller Class Initialized
INFO - 2017-06-22 20:59:34 --> Database Driver Class Initialized
INFO - 2017-06-22 20:59:34 --> Model Class Initialized
INFO - 2017-06-22 20:59:34 --> Helper loaded: form_helper
INFO - 2017-06-22 20:59:34 --> Helper loaded: url_helper
INFO - 2017-06-22 20:59:34 --> Model Class Initialized
INFO - 2017-06-22 20:59:34 --> Final output sent to browser
DEBUG - 2017-06-22 20:59:34 --> Total execution time: 0.0600
ERROR - 2017-06-22 20:59:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 20:59:51 --> Config Class Initialized
INFO - 2017-06-22 20:59:51 --> Hooks Class Initialized
DEBUG - 2017-06-22 20:59:51 --> UTF-8 Support Enabled
INFO - 2017-06-22 20:59:51 --> Utf8 Class Initialized
INFO - 2017-06-22 20:59:51 --> URI Class Initialized
INFO - 2017-06-22 20:59:51 --> Router Class Initialized
INFO - 2017-06-22 20:59:51 --> Output Class Initialized
INFO - 2017-06-22 20:59:51 --> Security Class Initialized
DEBUG - 2017-06-22 20:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 20:59:51 --> Input Class Initialized
INFO - 2017-06-22 20:59:51 --> Language Class Initialized
INFO - 2017-06-22 20:59:51 --> Loader Class Initialized
INFO - 2017-06-22 20:59:51 --> Controller Class Initialized
INFO - 2017-06-22 20:59:51 --> Database Driver Class Initialized
INFO - 2017-06-22 20:59:51 --> Model Class Initialized
INFO - 2017-06-22 20:59:51 --> Helper loaded: form_helper
INFO - 2017-06-22 20:59:51 --> Helper loaded: url_helper
INFO - 2017-06-22 20:59:51 --> Model Class Initialized
INFO - 2017-06-22 20:59:51 --> Final output sent to browser
DEBUG - 2017-06-22 20:59:51 --> Total execution time: 0.0720
ERROR - 2017-06-22 21:13:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 21:13:14 --> Config Class Initialized
INFO - 2017-06-22 21:13:14 --> Hooks Class Initialized
DEBUG - 2017-06-22 21:13:14 --> UTF-8 Support Enabled
INFO - 2017-06-22 21:13:14 --> Utf8 Class Initialized
INFO - 2017-06-22 21:13:14 --> URI Class Initialized
INFO - 2017-06-22 21:13:14 --> Router Class Initialized
INFO - 2017-06-22 21:13:14 --> Output Class Initialized
INFO - 2017-06-22 21:13:14 --> Security Class Initialized
DEBUG - 2017-06-22 21:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 21:13:14 --> Input Class Initialized
INFO - 2017-06-22 21:13:14 --> Language Class Initialized
INFO - 2017-06-22 21:13:14 --> Loader Class Initialized
INFO - 2017-06-22 21:13:14 --> Controller Class Initialized
INFO - 2017-06-22 21:13:14 --> Database Driver Class Initialized
INFO - 2017-06-22 21:13:14 --> Model Class Initialized
INFO - 2017-06-22 21:13:14 --> Helper loaded: form_helper
INFO - 2017-06-22 21:13:14 --> Helper loaded: url_helper
INFO - 2017-06-22 21:13:14 --> Model Class Initialized
INFO - 2017-06-22 21:13:14 --> Final output sent to browser
DEBUG - 2017-06-22 21:13:14 --> Total execution time: 0.0480
ERROR - 2017-06-22 21:15:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 21:15:24 --> Config Class Initialized
INFO - 2017-06-22 21:15:24 --> Hooks Class Initialized
DEBUG - 2017-06-22 21:15:24 --> UTF-8 Support Enabled
INFO - 2017-06-22 21:15:24 --> Utf8 Class Initialized
INFO - 2017-06-22 21:15:24 --> URI Class Initialized
INFO - 2017-06-22 21:15:24 --> Router Class Initialized
INFO - 2017-06-22 21:15:24 --> Output Class Initialized
INFO - 2017-06-22 21:15:24 --> Security Class Initialized
DEBUG - 2017-06-22 21:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 21:15:24 --> Input Class Initialized
INFO - 2017-06-22 21:15:24 --> Language Class Initialized
INFO - 2017-06-22 21:15:24 --> Loader Class Initialized
INFO - 2017-06-22 21:15:24 --> Controller Class Initialized
INFO - 2017-06-22 21:15:24 --> Database Driver Class Initialized
INFO - 2017-06-22 21:15:24 --> Model Class Initialized
INFO - 2017-06-22 21:15:24 --> Helper loaded: form_helper
INFO - 2017-06-22 21:15:24 --> Helper loaded: url_helper
INFO - 2017-06-22 21:15:24 --> Model Class Initialized
INFO - 2017-06-22 21:15:24 --> Final output sent to browser
DEBUG - 2017-06-22 21:15:24 --> Total execution time: 0.0520
ERROR - 2017-06-22 21:16:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 21:16:20 --> Config Class Initialized
INFO - 2017-06-22 21:16:20 --> Hooks Class Initialized
DEBUG - 2017-06-22 21:16:20 --> UTF-8 Support Enabled
INFO - 2017-06-22 21:16:20 --> Utf8 Class Initialized
INFO - 2017-06-22 21:16:20 --> URI Class Initialized
INFO - 2017-06-22 21:16:20 --> Router Class Initialized
INFO - 2017-06-22 21:16:20 --> Output Class Initialized
INFO - 2017-06-22 21:16:20 --> Security Class Initialized
DEBUG - 2017-06-22 21:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 21:16:20 --> Input Class Initialized
INFO - 2017-06-22 21:16:20 --> Language Class Initialized
INFO - 2017-06-22 21:16:20 --> Loader Class Initialized
INFO - 2017-06-22 21:16:20 --> Controller Class Initialized
INFO - 2017-06-22 21:16:20 --> Database Driver Class Initialized
INFO - 2017-06-22 21:16:20 --> Model Class Initialized
INFO - 2017-06-22 21:16:20 --> Helper loaded: form_helper
INFO - 2017-06-22 21:16:20 --> Helper loaded: url_helper
INFO - 2017-06-22 21:16:20 --> Model Class Initialized
INFO - 2017-06-22 21:16:20 --> Final output sent to browser
DEBUG - 2017-06-22 21:16:20 --> Total execution time: 0.0500
ERROR - 2017-06-22 21:21:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 21:21:05 --> Config Class Initialized
INFO - 2017-06-22 21:21:05 --> Hooks Class Initialized
DEBUG - 2017-06-22 21:21:05 --> UTF-8 Support Enabled
INFO - 2017-06-22 21:21:05 --> Utf8 Class Initialized
INFO - 2017-06-22 21:21:05 --> URI Class Initialized
INFO - 2017-06-22 21:21:05 --> Router Class Initialized
INFO - 2017-06-22 21:21:05 --> Output Class Initialized
INFO - 2017-06-22 21:21:05 --> Security Class Initialized
DEBUG - 2017-06-22 21:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 21:21:05 --> Input Class Initialized
INFO - 2017-06-22 21:21:05 --> Language Class Initialized
INFO - 2017-06-22 21:21:05 --> Loader Class Initialized
INFO - 2017-06-22 21:21:05 --> Controller Class Initialized
INFO - 2017-06-22 21:21:05 --> Database Driver Class Initialized
INFO - 2017-06-22 21:21:05 --> Model Class Initialized
INFO - 2017-06-22 21:21:05 --> Helper loaded: form_helper
INFO - 2017-06-22 21:21:05 --> Helper loaded: url_helper
INFO - 2017-06-22 21:21:05 --> Model Class Initialized
INFO - 2017-06-22 21:21:05 --> Final output sent to browser
DEBUG - 2017-06-22 21:21:05 --> Total execution time: 0.0600
ERROR - 2017-06-22 21:21:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 21:21:06 --> Config Class Initialized
INFO - 2017-06-22 21:21:06 --> Hooks Class Initialized
DEBUG - 2017-06-22 21:21:06 --> UTF-8 Support Enabled
INFO - 2017-06-22 21:21:06 --> Utf8 Class Initialized
INFO - 2017-06-22 21:21:06 --> URI Class Initialized
INFO - 2017-06-22 21:21:06 --> Router Class Initialized
INFO - 2017-06-22 21:21:06 --> Output Class Initialized
INFO - 2017-06-22 21:21:06 --> Security Class Initialized
DEBUG - 2017-06-22 21:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 21:21:06 --> Input Class Initialized
INFO - 2017-06-22 21:21:06 --> Language Class Initialized
INFO - 2017-06-22 21:21:06 --> Loader Class Initialized
INFO - 2017-06-22 21:21:06 --> Controller Class Initialized
INFO - 2017-06-22 21:21:06 --> Database Driver Class Initialized
INFO - 2017-06-22 21:21:06 --> Model Class Initialized
INFO - 2017-06-22 21:21:06 --> Helper loaded: form_helper
INFO - 2017-06-22 21:21:06 --> Helper loaded: url_helper
INFO - 2017-06-22 21:21:06 --> Model Class Initialized
INFO - 2017-06-22 21:21:06 --> Final output sent to browser
DEBUG - 2017-06-22 21:21:06 --> Total execution time: 0.0560
ERROR - 2017-06-22 21:21:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-22 21:21:48 --> Config Class Initialized
INFO - 2017-06-22 21:21:48 --> Hooks Class Initialized
DEBUG - 2017-06-22 21:21:48 --> UTF-8 Support Enabled
INFO - 2017-06-22 21:21:48 --> Utf8 Class Initialized
INFO - 2017-06-22 21:21:48 --> URI Class Initialized
INFO - 2017-06-22 21:21:48 --> Router Class Initialized
INFO - 2017-06-22 21:21:48 --> Output Class Initialized
INFO - 2017-06-22 21:21:48 --> Security Class Initialized
DEBUG - 2017-06-22 21:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-22 21:21:48 --> Input Class Initialized
INFO - 2017-06-22 21:21:48 --> Language Class Initialized
INFO - 2017-06-22 21:21:48 --> Loader Class Initialized
INFO - 2017-06-22 21:21:48 --> Controller Class Initialized
INFO - 2017-06-22 21:21:48 --> Database Driver Class Initialized
INFO - 2017-06-22 21:21:48 --> Model Class Initialized
INFO - 2017-06-22 21:21:48 --> Helper loaded: form_helper
INFO - 2017-06-22 21:21:48 --> Helper loaded: url_helper
INFO - 2017-06-22 21:21:48 --> Model Class Initialized
INFO - 2017-06-22 21:21:48 --> Final output sent to browser
DEBUG - 2017-06-22 21:21:48 --> Total execution time: 0.0490
