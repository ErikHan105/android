<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-24 02:49:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 02:49:56 --> Config Class Initialized
INFO - 2017-07-24 02:49:56 --> Hooks Class Initialized
DEBUG - 2017-07-24 02:49:56 --> UTF-8 Support Enabled
INFO - 2017-07-24 02:49:56 --> Utf8 Class Initialized
INFO - 2017-07-24 02:49:56 --> URI Class Initialized
DEBUG - 2017-07-24 02:49:56 --> No URI present. Default controller set.
INFO - 2017-07-24 02:49:56 --> Router Class Initialized
INFO - 2017-07-24 02:49:56 --> Output Class Initialized
INFO - 2017-07-24 02:49:56 --> Security Class Initialized
DEBUG - 2017-07-24 02:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 02:49:56 --> Input Class Initialized
INFO - 2017-07-24 02:49:56 --> Language Class Initialized
INFO - 2017-07-24 02:49:56 --> Loader Class Initialized
INFO - 2017-07-24 02:49:56 --> Controller Class Initialized
INFO - 2017-07-24 02:49:56 --> Database Driver Class Initialized
INFO - 2017-07-24 02:49:56 --> Model Class Initialized
INFO - 2017-07-24 02:49:56 --> Helper loaded: form_helper
INFO - 2017-07-24 02:49:56 --> Helper loaded: url_helper
INFO - 2017-07-24 02:49:56 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-24 02:49:56 --> Final output sent to browser
DEBUG - 2017-07-24 02:49:56 --> Total execution time: 0.0520
ERROR - 2017-07-24 02:49:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 02:49:58 --> Config Class Initialized
INFO - 2017-07-24 02:49:58 --> Hooks Class Initialized
DEBUG - 2017-07-24 02:49:58 --> UTF-8 Support Enabled
INFO - 2017-07-24 02:49:58 --> Utf8 Class Initialized
INFO - 2017-07-24 02:49:58 --> URI Class Initialized
INFO - 2017-07-24 02:49:58 --> Router Class Initialized
INFO - 2017-07-24 02:49:58 --> Output Class Initialized
INFO - 2017-07-24 02:49:58 --> Security Class Initialized
DEBUG - 2017-07-24 02:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 02:49:58 --> Input Class Initialized
INFO - 2017-07-24 02:49:58 --> Language Class Initialized
INFO - 2017-07-24 02:49:58 --> Loader Class Initialized
INFO - 2017-07-24 02:49:58 --> Controller Class Initialized
INFO - 2017-07-24 02:49:58 --> Database Driver Class Initialized
INFO - 2017-07-24 02:49:58 --> Model Class Initialized
INFO - 2017-07-24 02:49:58 --> Helper loaded: form_helper
INFO - 2017-07-24 02:49:58 --> Helper loaded: url_helper
INFO - 2017-07-24 02:49:58 --> Model Class Initialized
ERROR - 2017-07-24 02:49:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 02:49:58 --> Config Class Initialized
INFO - 2017-07-24 02:49:58 --> Hooks Class Initialized
DEBUG - 2017-07-24 02:49:58 --> UTF-8 Support Enabled
INFO - 2017-07-24 02:49:58 --> Utf8 Class Initialized
INFO - 2017-07-24 02:49:58 --> URI Class Initialized
INFO - 2017-07-24 02:49:58 --> Router Class Initialized
INFO - 2017-07-24 02:49:58 --> Output Class Initialized
INFO - 2017-07-24 02:49:58 --> Security Class Initialized
DEBUG - 2017-07-24 02:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 02:49:58 --> Input Class Initialized
INFO - 2017-07-24 02:49:58 --> Language Class Initialized
INFO - 2017-07-24 02:49:58 --> Loader Class Initialized
INFO - 2017-07-24 02:49:58 --> Controller Class Initialized
INFO - 2017-07-24 02:49:58 --> Database Driver Class Initialized
INFO - 2017-07-24 02:49:58 --> Model Class Initialized
INFO - 2017-07-24 02:49:58 --> Helper loaded: form_helper
INFO - 2017-07-24 02:49:58 --> Helper loaded: url_helper
INFO - 2017-07-24 02:49:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-24 02:49:58 --> Model Class Initialized
INFO - 2017-07-24 02:49:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-24 02:49:58 --> Final output sent to browser
DEBUG - 2017-07-24 02:49:58 --> Total execution time: 0.0930
ERROR - 2017-07-24 02:50:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 02:50:03 --> Config Class Initialized
INFO - 2017-07-24 02:50:03 --> Hooks Class Initialized
DEBUG - 2017-07-24 02:50:03 --> UTF-8 Support Enabled
INFO - 2017-07-24 02:50:03 --> Utf8 Class Initialized
INFO - 2017-07-24 02:50:03 --> URI Class Initialized
INFO - 2017-07-24 02:50:03 --> Router Class Initialized
INFO - 2017-07-24 02:50:03 --> Output Class Initialized
INFO - 2017-07-24 02:50:03 --> Security Class Initialized
DEBUG - 2017-07-24 02:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 02:50:03 --> Input Class Initialized
INFO - 2017-07-24 02:50:03 --> Language Class Initialized
INFO - 2017-07-24 02:50:03 --> Loader Class Initialized
INFO - 2017-07-24 02:50:03 --> Controller Class Initialized
INFO - 2017-07-24 02:50:03 --> Database Driver Class Initialized
INFO - 2017-07-24 02:50:03 --> Model Class Initialized
INFO - 2017-07-24 02:50:03 --> Helper loaded: form_helper
INFO - 2017-07-24 02:50:03 --> Helper loaded: url_helper
INFO - 2017-07-24 02:50:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-24 02:50:03 --> Model Class Initialized
INFO - 2017-07-24 02:50:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-24 02:50:03 --> Final output sent to browser
DEBUG - 2017-07-24 02:50:03 --> Total execution time: 0.0630
ERROR - 2017-07-24 02:50:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 02:50:05 --> Config Class Initialized
INFO - 2017-07-24 02:50:05 --> Hooks Class Initialized
DEBUG - 2017-07-24 02:50:05 --> UTF-8 Support Enabled
INFO - 2017-07-24 02:50:05 --> Utf8 Class Initialized
INFO - 2017-07-24 02:50:05 --> URI Class Initialized
INFO - 2017-07-24 02:50:05 --> Router Class Initialized
INFO - 2017-07-24 02:50:05 --> Output Class Initialized
INFO - 2017-07-24 02:50:05 --> Security Class Initialized
DEBUG - 2017-07-24 02:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 02:50:05 --> Input Class Initialized
INFO - 2017-07-24 02:50:05 --> Language Class Initialized
INFO - 2017-07-24 02:50:05 --> Loader Class Initialized
INFO - 2017-07-24 02:50:05 --> Controller Class Initialized
INFO - 2017-07-24 02:50:05 --> Database Driver Class Initialized
INFO - 2017-07-24 02:50:05 --> Model Class Initialized
INFO - 2017-07-24 02:50:05 --> Helper loaded: form_helper
INFO - 2017-07-24 02:50:05 --> Helper loaded: url_helper
INFO - 2017-07-24 02:50:05 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-24 02:50:05 --> Model Class Initialized
INFO - 2017-07-24 02:50:05 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-24 02:50:05 --> Final output sent to browser
DEBUG - 2017-07-24 02:50:05 --> Total execution time: 0.0760
ERROR - 2017-07-24 04:09:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 04:09:12 --> Config Class Initialized
INFO - 2017-07-24 04:09:12 --> Hooks Class Initialized
DEBUG - 2017-07-24 04:09:12 --> UTF-8 Support Enabled
INFO - 2017-07-24 04:09:12 --> Utf8 Class Initialized
INFO - 2017-07-24 04:09:12 --> URI Class Initialized
DEBUG - 2017-07-24 04:09:12 --> No URI present. Default controller set.
INFO - 2017-07-24 04:09:12 --> Router Class Initialized
INFO - 2017-07-24 04:09:13 --> Output Class Initialized
INFO - 2017-07-24 04:09:13 --> Security Class Initialized
DEBUG - 2017-07-24 04:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 04:09:13 --> Input Class Initialized
INFO - 2017-07-24 04:09:13 --> Language Class Initialized
INFO - 2017-07-24 04:09:13 --> Loader Class Initialized
INFO - 2017-07-24 04:09:13 --> Controller Class Initialized
INFO - 2017-07-24 04:09:13 --> Database Driver Class Initialized
INFO - 2017-07-24 04:09:13 --> Model Class Initialized
INFO - 2017-07-24 04:09:13 --> Helper loaded: form_helper
INFO - 2017-07-24 04:09:13 --> Helper loaded: url_helper
INFO - 2017-07-24 04:09:13 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-24 04:09:13 --> Final output sent to browser
DEBUG - 2017-07-24 04:09:13 --> Total execution time: 0.4970
ERROR - 2017-07-24 05:36:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 05:36:28 --> Config Class Initialized
INFO - 2017-07-24 05:36:28 --> Hooks Class Initialized
DEBUG - 2017-07-24 05:36:28 --> UTF-8 Support Enabled
INFO - 2017-07-24 05:36:28 --> Utf8 Class Initialized
INFO - 2017-07-24 05:36:28 --> URI Class Initialized
INFO - 2017-07-24 05:36:28 --> Router Class Initialized
INFO - 2017-07-24 05:36:28 --> Output Class Initialized
INFO - 2017-07-24 05:36:28 --> Security Class Initialized
DEBUG - 2017-07-24 05:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 05:36:28 --> Input Class Initialized
INFO - 2017-07-24 05:36:28 --> Language Class Initialized
INFO - 2017-07-24 05:36:28 --> Loader Class Initialized
INFO - 2017-07-24 05:36:28 --> Controller Class Initialized
INFO - 2017-07-24 05:36:28 --> Database Driver Class Initialized
INFO - 2017-07-24 05:36:28 --> Model Class Initialized
INFO - 2017-07-24 05:36:28 --> Helper loaded: form_helper
INFO - 2017-07-24 05:36:28 --> Helper loaded: url_helper
INFO - 2017-07-24 05:36:28 --> Model Class Initialized
ERROR - 2017-07-24 05:36:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 05:36:28 --> Config Class Initialized
INFO - 2017-07-24 05:36:28 --> Hooks Class Initialized
DEBUG - 2017-07-24 05:36:28 --> UTF-8 Support Enabled
INFO - 2017-07-24 05:36:28 --> Utf8 Class Initialized
INFO - 2017-07-24 05:36:28 --> URI Class Initialized
INFO - 2017-07-24 05:36:28 --> Router Class Initialized
INFO - 2017-07-24 05:36:29 --> Output Class Initialized
INFO - 2017-07-24 05:36:29 --> Security Class Initialized
DEBUG - 2017-07-24 05:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 05:36:29 --> Input Class Initialized
INFO - 2017-07-24 05:36:29 --> Language Class Initialized
INFO - 2017-07-24 05:36:29 --> Loader Class Initialized
INFO - 2017-07-24 05:36:29 --> Controller Class Initialized
INFO - 2017-07-24 05:36:29 --> Database Driver Class Initialized
INFO - 2017-07-24 05:36:29 --> Model Class Initialized
INFO - 2017-07-24 05:36:29 --> Helper loaded: form_helper
INFO - 2017-07-24 05:36:29 --> Helper loaded: url_helper
INFO - 2017-07-24 05:36:29 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-24 05:36:29 --> Model Class Initialized
INFO - 2017-07-24 05:36:29 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-24 05:36:29 --> Final output sent to browser
DEBUG - 2017-07-24 05:36:29 --> Total execution time: 0.2180
ERROR - 2017-07-24 08:17:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 08:17:44 --> Config Class Initialized
INFO - 2017-07-24 08:17:44 --> Hooks Class Initialized
DEBUG - 2017-07-24 08:17:44 --> UTF-8 Support Enabled
INFO - 2017-07-24 08:17:44 --> Utf8 Class Initialized
INFO - 2017-07-24 08:17:44 --> URI Class Initialized
INFO - 2017-07-24 08:17:44 --> Router Class Initialized
INFO - 2017-07-24 08:17:44 --> Output Class Initialized
INFO - 2017-07-24 08:17:44 --> Security Class Initialized
DEBUG - 2017-07-24 08:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 08:17:44 --> Input Class Initialized
INFO - 2017-07-24 08:17:44 --> Language Class Initialized
INFO - 2017-07-24 08:17:44 --> Loader Class Initialized
INFO - 2017-07-24 08:17:44 --> Controller Class Initialized
INFO - 2017-07-24 08:17:44 --> Database Driver Class Initialized
INFO - 2017-07-24 08:17:44 --> Model Class Initialized
INFO - 2017-07-24 08:17:44 --> Helper loaded: form_helper
INFO - 2017-07-24 08:17:44 --> Helper loaded: url_helper
INFO - 2017-07-24 08:17:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-24 08:17:44 --> Model Class Initialized
INFO - 2017-07-24 08:17:44 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-24 08:17:44 --> Final output sent to browser
DEBUG - 2017-07-24 08:17:44 --> Total execution time: 0.1280
ERROR - 2017-07-24 08:17:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 08:17:47 --> Config Class Initialized
INFO - 2017-07-24 08:17:47 --> Hooks Class Initialized
DEBUG - 2017-07-24 08:17:47 --> UTF-8 Support Enabled
INFO - 2017-07-24 08:17:47 --> Utf8 Class Initialized
INFO - 2017-07-24 08:17:47 --> URI Class Initialized
INFO - 2017-07-24 08:17:47 --> Router Class Initialized
INFO - 2017-07-24 08:17:47 --> Output Class Initialized
INFO - 2017-07-24 08:17:47 --> Security Class Initialized
DEBUG - 2017-07-24 08:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 08:17:47 --> Input Class Initialized
INFO - 2017-07-24 08:17:47 --> Language Class Initialized
INFO - 2017-07-24 08:17:47 --> Loader Class Initialized
INFO - 2017-07-24 08:17:47 --> Controller Class Initialized
INFO - 2017-07-24 08:17:47 --> Database Driver Class Initialized
INFO - 2017-07-24 08:17:47 --> Model Class Initialized
INFO - 2017-07-24 08:17:47 --> Helper loaded: form_helper
INFO - 2017-07-24 08:17:47 --> Helper loaded: url_helper
INFO - 2017-07-24 08:17:47 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-24 08:17:47 --> Model Class Initialized
INFO - 2017-07-24 08:17:47 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-24 08:17:47 --> Final output sent to browser
DEBUG - 2017-07-24 08:17:47 --> Total execution time: 0.2760
ERROR - 2017-07-24 10:33:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 10:33:56 --> Config Class Initialized
INFO - 2017-07-24 10:33:56 --> Hooks Class Initialized
DEBUG - 2017-07-24 10:33:56 --> UTF-8 Support Enabled
INFO - 2017-07-24 10:33:56 --> Utf8 Class Initialized
INFO - 2017-07-24 10:33:56 --> URI Class Initialized
DEBUG - 2017-07-24 10:33:56 --> No URI present. Default controller set.
INFO - 2017-07-24 10:33:56 --> Router Class Initialized
INFO - 2017-07-24 10:33:56 --> Output Class Initialized
INFO - 2017-07-24 10:33:56 --> Security Class Initialized
DEBUG - 2017-07-24 10:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 10:33:56 --> Input Class Initialized
INFO - 2017-07-24 10:33:56 --> Language Class Initialized
INFO - 2017-07-24 10:33:56 --> Loader Class Initialized
INFO - 2017-07-24 10:33:56 --> Controller Class Initialized
INFO - 2017-07-24 10:33:56 --> Database Driver Class Initialized
INFO - 2017-07-24 10:33:56 --> Model Class Initialized
INFO - 2017-07-24 10:33:56 --> Helper loaded: form_helper
INFO - 2017-07-24 10:33:56 --> Helper loaded: url_helper
INFO - 2017-07-24 10:33:56 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-24 10:33:56 --> Final output sent to browser
DEBUG - 2017-07-24 10:33:56 --> Total execution time: 0.0350
ERROR - 2017-07-24 10:33:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 10:33:58 --> Config Class Initialized
INFO - 2017-07-24 10:33:58 --> Hooks Class Initialized
DEBUG - 2017-07-24 10:33:58 --> UTF-8 Support Enabled
INFO - 2017-07-24 10:33:58 --> Utf8 Class Initialized
INFO - 2017-07-24 10:33:58 --> URI Class Initialized
INFO - 2017-07-24 10:33:58 --> Router Class Initialized
INFO - 2017-07-24 10:33:58 --> Output Class Initialized
INFO - 2017-07-24 10:33:58 --> Security Class Initialized
DEBUG - 2017-07-24 10:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 10:33:58 --> Input Class Initialized
INFO - 2017-07-24 10:33:58 --> Language Class Initialized
INFO - 2017-07-24 10:33:58 --> Loader Class Initialized
INFO - 2017-07-24 10:33:58 --> Controller Class Initialized
INFO - 2017-07-24 10:33:58 --> Database Driver Class Initialized
INFO - 2017-07-24 10:33:58 --> Model Class Initialized
INFO - 2017-07-24 10:33:58 --> Helper loaded: form_helper
INFO - 2017-07-24 10:33:58 --> Helper loaded: url_helper
INFO - 2017-07-24 10:33:58 --> Model Class Initialized
ERROR - 2017-07-24 10:33:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 10:33:58 --> Config Class Initialized
INFO - 2017-07-24 10:33:58 --> Hooks Class Initialized
DEBUG - 2017-07-24 10:33:58 --> UTF-8 Support Enabled
INFO - 2017-07-24 10:33:58 --> Utf8 Class Initialized
INFO - 2017-07-24 10:33:58 --> URI Class Initialized
INFO - 2017-07-24 10:33:58 --> Router Class Initialized
INFO - 2017-07-24 10:33:58 --> Output Class Initialized
INFO - 2017-07-24 10:33:58 --> Security Class Initialized
DEBUG - 2017-07-24 10:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 10:33:58 --> Input Class Initialized
INFO - 2017-07-24 10:33:58 --> Language Class Initialized
INFO - 2017-07-24 10:33:58 --> Loader Class Initialized
INFO - 2017-07-24 10:33:58 --> Controller Class Initialized
INFO - 2017-07-24 10:33:58 --> Database Driver Class Initialized
INFO - 2017-07-24 10:33:58 --> Model Class Initialized
INFO - 2017-07-24 10:33:58 --> Helper loaded: form_helper
INFO - 2017-07-24 10:33:58 --> Helper loaded: url_helper
INFO - 2017-07-24 10:33:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-24 10:33:58 --> Model Class Initialized
INFO - 2017-07-24 10:33:58 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-24 10:33:58 --> Final output sent to browser
DEBUG - 2017-07-24 10:33:58 --> Total execution time: 0.0740
ERROR - 2017-07-24 10:34:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 10:34:00 --> Config Class Initialized
INFO - 2017-07-24 10:34:00 --> Hooks Class Initialized
DEBUG - 2017-07-24 10:34:00 --> UTF-8 Support Enabled
INFO - 2017-07-24 10:34:00 --> Utf8 Class Initialized
INFO - 2017-07-24 10:34:00 --> URI Class Initialized
INFO - 2017-07-24 10:34:00 --> Router Class Initialized
INFO - 2017-07-24 10:34:00 --> Output Class Initialized
INFO - 2017-07-24 10:34:00 --> Security Class Initialized
DEBUG - 2017-07-24 10:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 10:34:00 --> Input Class Initialized
INFO - 2017-07-24 10:34:00 --> Language Class Initialized
INFO - 2017-07-24 10:34:00 --> Loader Class Initialized
INFO - 2017-07-24 10:34:00 --> Controller Class Initialized
INFO - 2017-07-24 10:34:00 --> Database Driver Class Initialized
INFO - 2017-07-24 10:34:00 --> Model Class Initialized
INFO - 2017-07-24 10:34:00 --> Helper loaded: form_helper
INFO - 2017-07-24 10:34:00 --> Helper loaded: url_helper
INFO - 2017-07-24 10:34:00 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-24 10:34:00 --> Model Class Initialized
INFO - 2017-07-24 10:34:00 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-24 10:34:00 --> Final output sent to browser
DEBUG - 2017-07-24 10:34:00 --> Total execution time: 0.1320
ERROR - 2017-07-24 10:34:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 10:34:02 --> Config Class Initialized
INFO - 2017-07-24 10:34:02 --> Hooks Class Initialized
DEBUG - 2017-07-24 10:34:02 --> UTF-8 Support Enabled
INFO - 2017-07-24 10:34:02 --> Utf8 Class Initialized
INFO - 2017-07-24 10:34:02 --> URI Class Initialized
INFO - 2017-07-24 10:34:02 --> Router Class Initialized
INFO - 2017-07-24 10:34:02 --> Output Class Initialized
INFO - 2017-07-24 10:34:02 --> Security Class Initialized
DEBUG - 2017-07-24 10:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 10:34:02 --> Input Class Initialized
INFO - 2017-07-24 10:34:02 --> Language Class Initialized
INFO - 2017-07-24 10:34:02 --> Loader Class Initialized
INFO - 2017-07-24 10:34:02 --> Controller Class Initialized
INFO - 2017-07-24 10:34:02 --> Database Driver Class Initialized
INFO - 2017-07-24 10:34:02 --> Model Class Initialized
INFO - 2017-07-24 10:34:02 --> Helper loaded: form_helper
INFO - 2017-07-24 10:34:02 --> Helper loaded: url_helper
INFO - 2017-07-24 10:34:02 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-24 10:34:02 --> Model Class Initialized
INFO - 2017-07-24 10:34:02 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-24 10:34:02 --> Final output sent to browser
DEBUG - 2017-07-24 10:34:02 --> Total execution time: 0.0510
ERROR - 2017-07-24 16:05:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 16:05:15 --> Config Class Initialized
INFO - 2017-07-24 16:05:15 --> Hooks Class Initialized
DEBUG - 2017-07-24 16:05:15 --> UTF-8 Support Enabled
INFO - 2017-07-24 16:05:15 --> Utf8 Class Initialized
INFO - 2017-07-24 16:05:15 --> URI Class Initialized
INFO - 2017-07-24 16:05:15 --> Router Class Initialized
INFO - 2017-07-24 16:05:15 --> Output Class Initialized
INFO - 2017-07-24 16:05:15 --> Security Class Initialized
DEBUG - 2017-07-24 16:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 16:05:15 --> Input Class Initialized
INFO - 2017-07-24 16:05:15 --> Language Class Initialized
INFO - 2017-07-24 16:05:16 --> Loader Class Initialized
INFO - 2017-07-24 16:05:16 --> Controller Class Initialized
INFO - 2017-07-24 16:05:16 --> Database Driver Class Initialized
INFO - 2017-07-24 16:05:16 --> Model Class Initialized
INFO - 2017-07-24 16:05:16 --> Helper loaded: form_helper
INFO - 2017-07-24 16:05:16 --> Helper loaded: url_helper
INFO - 2017-07-24 16:05:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-24 16:05:16 --> Model Class Initialized
INFO - 2017-07-24 16:05:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-24 16:05:16 --> Final output sent to browser
DEBUG - 2017-07-24 16:05:16 --> Total execution time: 0.1170
ERROR - 2017-07-24 16:05:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 16:05:21 --> Config Class Initialized
INFO - 2017-07-24 16:05:21 --> Hooks Class Initialized
DEBUG - 2017-07-24 16:05:21 --> UTF-8 Support Enabled
INFO - 2017-07-24 16:05:21 --> Utf8 Class Initialized
INFO - 2017-07-24 16:05:21 --> URI Class Initialized
INFO - 2017-07-24 16:05:21 --> Router Class Initialized
INFO - 2017-07-24 16:05:21 --> Output Class Initialized
INFO - 2017-07-24 16:05:21 --> Security Class Initialized
DEBUG - 2017-07-24 16:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 16:05:21 --> Input Class Initialized
INFO - 2017-07-24 16:05:21 --> Language Class Initialized
INFO - 2017-07-24 16:05:21 --> Loader Class Initialized
INFO - 2017-07-24 16:05:21 --> Controller Class Initialized
INFO - 2017-07-24 16:05:21 --> Database Driver Class Initialized
INFO - 2017-07-24 16:05:21 --> Model Class Initialized
INFO - 2017-07-24 16:05:21 --> Helper loaded: form_helper
INFO - 2017-07-24 16:05:21 --> Helper loaded: url_helper
INFO - 2017-07-24 16:05:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-24 16:05:21 --> Model Class Initialized
INFO - 2017-07-24 16:05:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-24 16:05:21 --> Final output sent to browser
DEBUG - 2017-07-24 16:05:21 --> Total execution time: 0.1270
ERROR - 2017-07-24 16:05:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 16:05:36 --> Config Class Initialized
INFO - 2017-07-24 16:05:36 --> Hooks Class Initialized
DEBUG - 2017-07-24 16:05:36 --> UTF-8 Support Enabled
INFO - 2017-07-24 16:05:36 --> Utf8 Class Initialized
INFO - 2017-07-24 16:05:36 --> URI Class Initialized
INFO - 2017-07-24 16:05:36 --> Router Class Initialized
INFO - 2017-07-24 16:05:36 --> Output Class Initialized
INFO - 2017-07-24 16:05:36 --> Security Class Initialized
DEBUG - 2017-07-24 16:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 16:05:36 --> Input Class Initialized
INFO - 2017-07-24 16:05:36 --> Language Class Initialized
INFO - 2017-07-24 16:05:36 --> Loader Class Initialized
INFO - 2017-07-24 16:05:36 --> Controller Class Initialized
INFO - 2017-07-24 16:05:36 --> Database Driver Class Initialized
INFO - 2017-07-24 16:05:36 --> Model Class Initialized
INFO - 2017-07-24 16:05:36 --> Helper loaded: form_helper
INFO - 2017-07-24 16:05:36 --> Helper loaded: url_helper
INFO - 2017-07-24 16:05:36 --> Upload Class Initialized
INFO - 2017-07-24 16:05:36 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-07-24 16:05:36 --> The filetype you are attempting to upload is not allowed.
INFO - 2017-07-24 16:05:36 --> Final output sent to browser
DEBUG - 2017-07-24 16:05:36 --> Total execution time: 0.1160
ERROR - 2017-07-24 16:05:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 16:05:44 --> Config Class Initialized
INFO - 2017-07-24 16:05:44 --> Hooks Class Initialized
DEBUG - 2017-07-24 16:05:44 --> UTF-8 Support Enabled
INFO - 2017-07-24 16:05:44 --> Utf8 Class Initialized
INFO - 2017-07-24 16:05:44 --> URI Class Initialized
INFO - 2017-07-24 16:05:44 --> Router Class Initialized
INFO - 2017-07-24 16:05:44 --> Output Class Initialized
INFO - 2017-07-24 16:05:44 --> Security Class Initialized
DEBUG - 2017-07-24 16:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 16:05:44 --> Input Class Initialized
INFO - 2017-07-24 16:05:44 --> Language Class Initialized
INFO - 2017-07-24 16:05:44 --> Loader Class Initialized
INFO - 2017-07-24 16:05:44 --> Controller Class Initialized
INFO - 2017-07-24 16:05:44 --> Database Driver Class Initialized
INFO - 2017-07-24 16:05:44 --> Model Class Initialized
INFO - 2017-07-24 16:05:44 --> Helper loaded: form_helper
INFO - 2017-07-24 16:05:44 --> Helper loaded: url_helper
INFO - 2017-07-24 16:05:44 --> Upload Class Initialized
INFO - 2017-07-24 16:05:44 --> Final output sent to browser
DEBUG - 2017-07-24 16:05:44 --> Total execution time: 0.0570
ERROR - 2017-07-24 16:05:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 16:05:46 --> Config Class Initialized
INFO - 2017-07-24 16:05:46 --> Hooks Class Initialized
DEBUG - 2017-07-24 16:05:46 --> UTF-8 Support Enabled
INFO - 2017-07-24 16:05:46 --> Utf8 Class Initialized
INFO - 2017-07-24 16:05:46 --> URI Class Initialized
INFO - 2017-07-24 16:05:46 --> Router Class Initialized
INFO - 2017-07-24 16:05:46 --> Output Class Initialized
INFO - 2017-07-24 16:05:46 --> Security Class Initialized
DEBUG - 2017-07-24 16:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 16:05:46 --> Input Class Initialized
INFO - 2017-07-24 16:05:46 --> Language Class Initialized
INFO - 2017-07-24 16:05:46 --> Loader Class Initialized
INFO - 2017-07-24 16:05:46 --> Controller Class Initialized
INFO - 2017-07-24 16:05:46 --> Database Driver Class Initialized
INFO - 2017-07-24 16:05:47 --> Model Class Initialized
INFO - 2017-07-24 16:05:47 --> Helper loaded: form_helper
INFO - 2017-07-24 16:05:47 --> Helper loaded: url_helper
INFO - 2017-07-24 16:05:47 --> Model Class Initialized
INFO - 2017-07-24 16:05:47 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-24 16:05:47 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-24 16:05:47 --> Final output sent to browser
DEBUG - 2017-07-24 16:05:47 --> Total execution time: 0.1930
ERROR - 2017-07-24 16:05:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 16:05:48 --> Config Class Initialized
INFO - 2017-07-24 16:05:48 --> Hooks Class Initialized
DEBUG - 2017-07-24 16:05:48 --> UTF-8 Support Enabled
INFO - 2017-07-24 16:05:48 --> Utf8 Class Initialized
INFO - 2017-07-24 16:05:48 --> URI Class Initialized
INFO - 2017-07-24 16:05:48 --> Router Class Initialized
INFO - 2017-07-24 16:05:48 --> Output Class Initialized
INFO - 2017-07-24 16:05:48 --> Security Class Initialized
DEBUG - 2017-07-24 16:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 16:05:48 --> Input Class Initialized
INFO - 2017-07-24 16:05:48 --> Language Class Initialized
INFO - 2017-07-24 16:05:48 --> Loader Class Initialized
INFO - 2017-07-24 16:05:48 --> Controller Class Initialized
INFO - 2017-07-24 16:05:48 --> Database Driver Class Initialized
INFO - 2017-07-24 16:05:48 --> Model Class Initialized
INFO - 2017-07-24 16:05:48 --> Helper loaded: form_helper
INFO - 2017-07-24 16:05:48 --> Helper loaded: url_helper
INFO - 2017-07-24 16:05:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-24 16:05:48 --> Model Class Initialized
INFO - 2017-07-24 16:05:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-24 16:05:48 --> Final output sent to browser
DEBUG - 2017-07-24 16:05:48 --> Total execution time: 0.1170
ERROR - 2017-07-24 16:05:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 16:05:50 --> Config Class Initialized
INFO - 2017-07-24 16:05:50 --> Hooks Class Initialized
DEBUG - 2017-07-24 16:05:50 --> UTF-8 Support Enabled
INFO - 2017-07-24 16:05:50 --> Utf8 Class Initialized
INFO - 2017-07-24 16:05:50 --> URI Class Initialized
INFO - 2017-07-24 16:05:50 --> Router Class Initialized
INFO - 2017-07-24 16:05:50 --> Output Class Initialized
INFO - 2017-07-24 16:05:50 --> Security Class Initialized
DEBUG - 2017-07-24 16:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 16:05:50 --> Input Class Initialized
INFO - 2017-07-24 16:05:50 --> Language Class Initialized
INFO - 2017-07-24 16:05:50 --> Loader Class Initialized
INFO - 2017-07-24 16:05:50 --> Controller Class Initialized
INFO - 2017-07-24 16:05:50 --> Database Driver Class Initialized
INFO - 2017-07-24 16:05:50 --> Model Class Initialized
INFO - 2017-07-24 16:05:50 --> Helper loaded: form_helper
INFO - 2017-07-24 16:05:50 --> Helper loaded: url_helper
INFO - 2017-07-24 16:05:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-24 16:05:50 --> Model Class Initialized
INFO - 2017-07-24 16:05:50 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-07-24 16:05:50 --> Final output sent to browser
DEBUG - 2017-07-24 16:05:50 --> Total execution time: 0.1470
ERROR - 2017-07-24 16:05:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 16:05:52 --> Config Class Initialized
INFO - 2017-07-24 16:05:52 --> Hooks Class Initialized
DEBUG - 2017-07-24 16:05:52 --> UTF-8 Support Enabled
INFO - 2017-07-24 16:05:52 --> Utf8 Class Initialized
INFO - 2017-07-24 16:05:52 --> URI Class Initialized
INFO - 2017-07-24 16:05:52 --> Router Class Initialized
INFO - 2017-07-24 16:05:52 --> Output Class Initialized
INFO - 2017-07-24 16:05:52 --> Security Class Initialized
DEBUG - 2017-07-24 16:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 16:05:52 --> Input Class Initialized
INFO - 2017-07-24 16:05:52 --> Language Class Initialized
INFO - 2017-07-24 16:05:52 --> Loader Class Initialized
INFO - 2017-07-24 16:05:52 --> Controller Class Initialized
INFO - 2017-07-24 16:05:52 --> Database Driver Class Initialized
INFO - 2017-07-24 16:05:52 --> Model Class Initialized
INFO - 2017-07-24 16:05:52 --> Helper loaded: form_helper
INFO - 2017-07-24 16:05:52 --> Helper loaded: url_helper
INFO - 2017-07-24 16:05:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-24 16:05:52 --> Model Class Initialized
INFO - 2017-07-24 16:05:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-07-24 16:05:52 --> Final output sent to browser
DEBUG - 2017-07-24 16:05:52 --> Total execution time: 0.1090
ERROR - 2017-07-24 16:05:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 16:05:53 --> Config Class Initialized
INFO - 2017-07-24 16:05:53 --> Hooks Class Initialized
DEBUG - 2017-07-24 16:05:53 --> UTF-8 Support Enabled
INFO - 2017-07-24 16:05:53 --> Utf8 Class Initialized
INFO - 2017-07-24 16:05:53 --> URI Class Initialized
INFO - 2017-07-24 16:05:53 --> Router Class Initialized
INFO - 2017-07-24 16:05:53 --> Output Class Initialized
INFO - 2017-07-24 16:05:53 --> Security Class Initialized
DEBUG - 2017-07-24 16:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 16:05:53 --> Input Class Initialized
INFO - 2017-07-24 16:05:53 --> Language Class Initialized
INFO - 2017-07-24 16:05:53 --> Loader Class Initialized
INFO - 2017-07-24 16:05:53 --> Controller Class Initialized
INFO - 2017-07-24 16:05:53 --> Database Driver Class Initialized
INFO - 2017-07-24 16:05:53 --> Model Class Initialized
INFO - 2017-07-24 16:05:53 --> Helper loaded: form_helper
INFO - 2017-07-24 16:05:53 --> Helper loaded: url_helper
INFO - 2017-07-24 16:05:53 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-24 16:05:53 --> Model Class Initialized
INFO - 2017-07-24 16:05:53 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-07-24 16:05:53 --> Final output sent to browser
DEBUG - 2017-07-24 16:05:53 --> Total execution time: 0.1360
ERROR - 2017-07-24 16:05:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 16:05:56 --> Config Class Initialized
INFO - 2017-07-24 16:05:56 --> Hooks Class Initialized
DEBUG - 2017-07-24 16:05:56 --> UTF-8 Support Enabled
INFO - 2017-07-24 16:05:56 --> Utf8 Class Initialized
INFO - 2017-07-24 16:05:56 --> URI Class Initialized
INFO - 2017-07-24 16:05:56 --> Router Class Initialized
INFO - 2017-07-24 16:05:56 --> Output Class Initialized
INFO - 2017-07-24 16:05:56 --> Security Class Initialized
DEBUG - 2017-07-24 16:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 16:05:56 --> Input Class Initialized
INFO - 2017-07-24 16:05:56 --> Language Class Initialized
INFO - 2017-07-24 16:05:56 --> Loader Class Initialized
INFO - 2017-07-24 16:05:56 --> Controller Class Initialized
INFO - 2017-07-24 16:05:56 --> Database Driver Class Initialized
INFO - 2017-07-24 16:05:56 --> Model Class Initialized
INFO - 2017-07-24 16:05:56 --> Helper loaded: form_helper
INFO - 2017-07-24 16:05:56 --> Helper loaded: url_helper
INFO - 2017-07-24 16:05:56 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-24 16:05:56 --> Model Class Initialized
INFO - 2017-07-24 16:05:56 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-07-24 16:05:56 --> Final output sent to browser
DEBUG - 2017-07-24 16:05:56 --> Total execution time: 0.0730
ERROR - 2017-07-24 16:06:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 16:06:04 --> Config Class Initialized
INFO - 2017-07-24 16:06:04 --> Hooks Class Initialized
DEBUG - 2017-07-24 16:06:04 --> UTF-8 Support Enabled
INFO - 2017-07-24 16:06:04 --> Utf8 Class Initialized
INFO - 2017-07-24 16:06:04 --> URI Class Initialized
INFO - 2017-07-24 16:06:04 --> Router Class Initialized
INFO - 2017-07-24 16:06:04 --> Output Class Initialized
INFO - 2017-07-24 16:06:04 --> Security Class Initialized
DEBUG - 2017-07-24 16:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 16:06:04 --> Input Class Initialized
INFO - 2017-07-24 16:06:04 --> Language Class Initialized
INFO - 2017-07-24 16:06:04 --> Loader Class Initialized
INFO - 2017-07-24 16:06:04 --> Controller Class Initialized
INFO - 2017-07-24 16:06:04 --> Database Driver Class Initialized
INFO - 2017-07-24 16:06:04 --> Model Class Initialized
INFO - 2017-07-24 16:06:04 --> Helper loaded: form_helper
INFO - 2017-07-24 16:06:04 --> Helper loaded: url_helper
INFO - 2017-07-24 16:06:04 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-24 16:06:04 --> Model Class Initialized
INFO - 2017-07-24 16:06:04 --> File loaded: C:\xampp\htdocs\mystage\application\views\purchase.php
INFO - 2017-07-24 16:06:04 --> Final output sent to browser
DEBUG - 2017-07-24 16:06:04 --> Total execution time: 0.1600
ERROR - 2017-07-24 16:06:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-24 16:06:05 --> Config Class Initialized
INFO - 2017-07-24 16:06:05 --> Hooks Class Initialized
DEBUG - 2017-07-24 16:06:05 --> UTF-8 Support Enabled
INFO - 2017-07-24 16:06:05 --> Utf8 Class Initialized
INFO - 2017-07-24 16:06:05 --> URI Class Initialized
INFO - 2017-07-24 16:06:05 --> Router Class Initialized
INFO - 2017-07-24 16:06:05 --> Output Class Initialized
INFO - 2017-07-24 16:06:05 --> Security Class Initialized
DEBUG - 2017-07-24 16:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 16:06:05 --> Input Class Initialized
INFO - 2017-07-24 16:06:05 --> Language Class Initialized
INFO - 2017-07-24 16:06:05 --> Loader Class Initialized
INFO - 2017-07-24 16:06:05 --> Controller Class Initialized
INFO - 2017-07-24 16:06:05 --> Database Driver Class Initialized
INFO - 2017-07-24 16:06:05 --> Model Class Initialized
INFO - 2017-07-24 16:06:05 --> Helper loaded: form_helper
INFO - 2017-07-24 16:06:05 --> Helper loaded: url_helper
INFO - 2017-07-24 16:06:05 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-24 16:06:05 --> Model Class Initialized
INFO - 2017-07-24 16:06:05 --> File loaded: C:\xampp\htdocs\mystage\application\views\share.php
INFO - 2017-07-24 16:06:05 --> Final output sent to browser
DEBUG - 2017-07-24 16:06:05 --> Total execution time: 0.1680
