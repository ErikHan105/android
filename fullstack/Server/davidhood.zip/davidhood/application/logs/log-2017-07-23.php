<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-23 16:04:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:04:52 --> Config Class Initialized
INFO - 2017-07-23 16:04:52 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:04:52 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:04:52 --> Utf8 Class Initialized
INFO - 2017-07-23 16:04:52 --> URI Class Initialized
INFO - 2017-07-23 16:04:52 --> Router Class Initialized
INFO - 2017-07-23 16:04:52 --> Output Class Initialized
INFO - 2017-07-23 16:04:52 --> Security Class Initialized
DEBUG - 2017-07-23 16:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:04:52 --> Input Class Initialized
INFO - 2017-07-23 16:04:52 --> Language Class Initialized
INFO - 2017-07-23 16:04:52 --> Loader Class Initialized
INFO - 2017-07-23 16:04:52 --> Controller Class Initialized
INFO - 2017-07-23 16:04:52 --> Database Driver Class Initialized
INFO - 2017-07-23 16:04:52 --> Model Class Initialized
INFO - 2017-07-23 16:04:52 --> Helper loaded: form_helper
INFO - 2017-07-23 16:04:52 --> Helper loaded: url_helper
INFO - 2017-07-23 16:04:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-23 16:04:52 --> Model Class Initialized
INFO - 2017-07-23 16:04:52 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-23 16:04:52 --> Final output sent to browser
DEBUG - 2017-07-23 16:04:52 --> Total execution time: 0.1380
ERROR - 2017-07-23 16:12:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:12:32 --> Config Class Initialized
INFO - 2017-07-23 16:12:32 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:12:32 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:12:32 --> Utf8 Class Initialized
INFO - 2017-07-23 16:12:32 --> URI Class Initialized
INFO - 2017-07-23 16:12:32 --> Router Class Initialized
INFO - 2017-07-23 16:12:32 --> Output Class Initialized
INFO - 2017-07-23 16:12:32 --> Security Class Initialized
DEBUG - 2017-07-23 16:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:12:32 --> Input Class Initialized
INFO - 2017-07-23 16:12:32 --> Language Class Initialized
INFO - 2017-07-23 16:12:32 --> Loader Class Initialized
INFO - 2017-07-23 16:12:32 --> Controller Class Initialized
INFO - 2017-07-23 16:12:32 --> Database Driver Class Initialized
INFO - 2017-07-23 16:12:32 --> Model Class Initialized
INFO - 2017-07-23 16:12:32 --> Helper loaded: form_helper
INFO - 2017-07-23 16:12:32 --> Helper loaded: url_helper
INFO - 2017-07-23 16:12:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-23 16:12:32 --> Model Class Initialized
INFO - 2017-07-23 16:12:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-23 16:12:32 --> Final output sent to browser
DEBUG - 2017-07-23 16:12:32 --> Total execution time: 0.0930
ERROR - 2017-07-23 16:13:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:13:06 --> Config Class Initialized
INFO - 2017-07-23 16:13:06 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:13:06 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:13:06 --> Utf8 Class Initialized
INFO - 2017-07-23 16:13:06 --> URI Class Initialized
INFO - 2017-07-23 16:13:06 --> Router Class Initialized
INFO - 2017-07-23 16:13:06 --> Output Class Initialized
INFO - 2017-07-23 16:13:06 --> Security Class Initialized
DEBUG - 2017-07-23 16:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:13:06 --> Input Class Initialized
INFO - 2017-07-23 16:13:06 --> Language Class Initialized
INFO - 2017-07-23 16:13:06 --> Loader Class Initialized
INFO - 2017-07-23 16:13:06 --> Controller Class Initialized
INFO - 2017-07-23 16:13:06 --> Database Driver Class Initialized
INFO - 2017-07-23 16:13:06 --> Model Class Initialized
INFO - 2017-07-23 16:13:06 --> Helper loaded: form_helper
INFO - 2017-07-23 16:13:06 --> Helper loaded: url_helper
INFO - 2017-07-23 16:13:06 --> Upload Class Initialized
INFO - 2017-07-23 16:13:06 --> Final output sent to browser
DEBUG - 2017-07-23 16:13:06 --> Total execution time: 0.1330
ERROR - 2017-07-23 16:13:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:13:27 --> Config Class Initialized
INFO - 2017-07-23 16:13:27 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:13:27 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:13:27 --> Utf8 Class Initialized
INFO - 2017-07-23 16:13:27 --> URI Class Initialized
INFO - 2017-07-23 16:13:27 --> Router Class Initialized
INFO - 2017-07-23 16:13:27 --> Output Class Initialized
INFO - 2017-07-23 16:13:27 --> Security Class Initialized
DEBUG - 2017-07-23 16:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:13:27 --> Input Class Initialized
INFO - 2017-07-23 16:13:27 --> Language Class Initialized
INFO - 2017-07-23 16:13:27 --> Loader Class Initialized
INFO - 2017-07-23 16:13:27 --> Controller Class Initialized
INFO - 2017-07-23 16:13:27 --> Database Driver Class Initialized
INFO - 2017-07-23 16:13:27 --> Model Class Initialized
INFO - 2017-07-23 16:13:27 --> Helper loaded: form_helper
INFO - 2017-07-23 16:13:27 --> Helper loaded: url_helper
INFO - 2017-07-23 16:13:27 --> Upload Class Initialized
INFO - 2017-07-23 16:13:28 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-07-23 16:13:28 --> The filetype you are attempting to upload is not allowed.
INFO - 2017-07-23 16:13:28 --> Final output sent to browser
DEBUG - 2017-07-23 16:13:28 --> Total execution time: 0.0550
ERROR - 2017-07-23 16:13:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:13:36 --> Config Class Initialized
INFO - 2017-07-23 16:13:36 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:13:36 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:13:36 --> Utf8 Class Initialized
INFO - 2017-07-23 16:13:36 --> URI Class Initialized
INFO - 2017-07-23 16:13:36 --> Router Class Initialized
INFO - 2017-07-23 16:13:36 --> Output Class Initialized
INFO - 2017-07-23 16:13:36 --> Security Class Initialized
DEBUG - 2017-07-23 16:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:13:36 --> Input Class Initialized
INFO - 2017-07-23 16:13:36 --> Language Class Initialized
INFO - 2017-07-23 16:13:36 --> Loader Class Initialized
INFO - 2017-07-23 16:13:36 --> Controller Class Initialized
INFO - 2017-07-23 16:13:36 --> Database Driver Class Initialized
INFO - 2017-07-23 16:13:36 --> Model Class Initialized
INFO - 2017-07-23 16:13:36 --> Helper loaded: form_helper
INFO - 2017-07-23 16:13:36 --> Helper loaded: url_helper
INFO - 2017-07-23 16:13:36 --> Upload Class Initialized
INFO - 2017-07-23 16:13:36 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-07-23 16:13:36 --> The filetype you are attempting to upload is not allowed.
INFO - 2017-07-23 16:13:36 --> Final output sent to browser
DEBUG - 2017-07-23 16:13:36 --> Total execution time: 0.0740
ERROR - 2017-07-23 16:13:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:13:45 --> Config Class Initialized
INFO - 2017-07-23 16:13:45 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:13:45 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:13:45 --> Utf8 Class Initialized
INFO - 2017-07-23 16:13:45 --> URI Class Initialized
INFO - 2017-07-23 16:13:45 --> Router Class Initialized
INFO - 2017-07-23 16:13:45 --> Output Class Initialized
INFO - 2017-07-23 16:13:45 --> Security Class Initialized
DEBUG - 2017-07-23 16:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:13:45 --> Input Class Initialized
INFO - 2017-07-23 16:13:45 --> Language Class Initialized
INFO - 2017-07-23 16:13:45 --> Loader Class Initialized
INFO - 2017-07-23 16:13:45 --> Controller Class Initialized
INFO - 2017-07-23 16:13:45 --> Database Driver Class Initialized
INFO - 2017-07-23 16:13:45 --> Model Class Initialized
INFO - 2017-07-23 16:13:45 --> Helper loaded: form_helper
INFO - 2017-07-23 16:13:45 --> Helper loaded: url_helper
INFO - 2017-07-23 16:13:45 --> Upload Class Initialized
INFO - 2017-07-23 16:13:45 --> Final output sent to browser
DEBUG - 2017-07-23 16:13:45 --> Total execution time: 0.0430
ERROR - 2017-07-23 16:13:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:13:55 --> Config Class Initialized
INFO - 2017-07-23 16:13:55 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:13:55 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:13:55 --> Utf8 Class Initialized
INFO - 2017-07-23 16:13:55 --> URI Class Initialized
INFO - 2017-07-23 16:13:55 --> Router Class Initialized
INFO - 2017-07-23 16:13:55 --> Output Class Initialized
INFO - 2017-07-23 16:13:55 --> Security Class Initialized
DEBUG - 2017-07-23 16:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:13:55 --> Input Class Initialized
INFO - 2017-07-23 16:13:55 --> Language Class Initialized
INFO - 2017-07-23 16:13:55 --> Loader Class Initialized
INFO - 2017-07-23 16:13:55 --> Controller Class Initialized
INFO - 2017-07-23 16:13:55 --> Database Driver Class Initialized
INFO - 2017-07-23 16:13:55 --> Model Class Initialized
INFO - 2017-07-23 16:13:55 --> Helper loaded: form_helper
INFO - 2017-07-23 16:13:55 --> Helper loaded: url_helper
INFO - 2017-07-23 16:13:55 --> Upload Class Initialized
INFO - 2017-07-23 16:13:55 --> Final output sent to browser
DEBUG - 2017-07-23 16:13:55 --> Total execution time: 0.0430
ERROR - 2017-07-23 16:14:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:14:00 --> Config Class Initialized
INFO - 2017-07-23 16:14:00 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:14:00 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:14:00 --> Utf8 Class Initialized
INFO - 2017-07-23 16:14:00 --> URI Class Initialized
INFO - 2017-07-23 16:14:00 --> Router Class Initialized
INFO - 2017-07-23 16:14:00 --> Output Class Initialized
INFO - 2017-07-23 16:14:00 --> Security Class Initialized
DEBUG - 2017-07-23 16:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:14:00 --> Input Class Initialized
INFO - 2017-07-23 16:14:00 --> Language Class Initialized
INFO - 2017-07-23 16:14:00 --> Loader Class Initialized
INFO - 2017-07-23 16:14:00 --> Controller Class Initialized
INFO - 2017-07-23 16:14:00 --> Database Driver Class Initialized
INFO - 2017-07-23 16:14:00 --> Model Class Initialized
INFO - 2017-07-23 16:14:00 --> Helper loaded: form_helper
INFO - 2017-07-23 16:14:00 --> Helper loaded: url_helper
INFO - 2017-07-23 16:14:00 --> Upload Class Initialized
INFO - 2017-07-23 16:14:00 --> Final output sent to browser
DEBUG - 2017-07-23 16:14:00 --> Total execution time: 0.0520
ERROR - 2017-07-23 16:14:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:14:17 --> Config Class Initialized
INFO - 2017-07-23 16:14:17 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:14:17 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:14:17 --> Utf8 Class Initialized
INFO - 2017-07-23 16:14:17 --> URI Class Initialized
INFO - 2017-07-23 16:14:17 --> Router Class Initialized
INFO - 2017-07-23 16:14:17 --> Output Class Initialized
INFO - 2017-07-23 16:14:17 --> Security Class Initialized
DEBUG - 2017-07-23 16:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:14:17 --> Input Class Initialized
INFO - 2017-07-23 16:14:17 --> Language Class Initialized
INFO - 2017-07-23 16:14:17 --> Loader Class Initialized
INFO - 2017-07-23 16:14:17 --> Controller Class Initialized
INFO - 2017-07-23 16:14:17 --> Database Driver Class Initialized
INFO - 2017-07-23 16:14:17 --> Model Class Initialized
INFO - 2017-07-23 16:14:17 --> Helper loaded: form_helper
INFO - 2017-07-23 16:14:17 --> Helper loaded: url_helper
INFO - 2017-07-23 16:14:17 --> Upload Class Initialized
INFO - 2017-07-23 16:14:17 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-07-23 16:14:17 --> The filetype you are attempting to upload is not allowed.
INFO - 2017-07-23 16:14:17 --> Final output sent to browser
DEBUG - 2017-07-23 16:14:17 --> Total execution time: 0.0420
ERROR - 2017-07-23 16:14:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:14:21 --> Config Class Initialized
INFO - 2017-07-23 16:14:21 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:14:21 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:14:21 --> Utf8 Class Initialized
INFO - 2017-07-23 16:14:21 --> URI Class Initialized
INFO - 2017-07-23 16:14:21 --> Router Class Initialized
INFO - 2017-07-23 16:14:21 --> Output Class Initialized
INFO - 2017-07-23 16:14:21 --> Security Class Initialized
DEBUG - 2017-07-23 16:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:14:21 --> Input Class Initialized
INFO - 2017-07-23 16:14:21 --> Language Class Initialized
INFO - 2017-07-23 16:14:21 --> Loader Class Initialized
INFO - 2017-07-23 16:14:21 --> Controller Class Initialized
INFO - 2017-07-23 16:14:21 --> Database Driver Class Initialized
INFO - 2017-07-23 16:14:21 --> Model Class Initialized
INFO - 2017-07-23 16:14:21 --> Helper loaded: form_helper
INFO - 2017-07-23 16:14:21 --> Helper loaded: url_helper
INFO - 2017-07-23 16:14:21 --> Upload Class Initialized
INFO - 2017-07-23 16:14:21 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-07-23 16:14:21 --> The filetype you are attempting to upload is not allowed.
INFO - 2017-07-23 16:14:21 --> Final output sent to browser
DEBUG - 2017-07-23 16:14:21 --> Total execution time: 0.0420
ERROR - 2017-07-23 16:14:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:14:27 --> Config Class Initialized
INFO - 2017-07-23 16:14:27 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:14:27 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:14:27 --> Utf8 Class Initialized
INFO - 2017-07-23 16:14:27 --> URI Class Initialized
INFO - 2017-07-23 16:14:27 --> Router Class Initialized
INFO - 2017-07-23 16:14:27 --> Output Class Initialized
INFO - 2017-07-23 16:14:27 --> Security Class Initialized
DEBUG - 2017-07-23 16:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:14:27 --> Input Class Initialized
INFO - 2017-07-23 16:14:27 --> Language Class Initialized
INFO - 2017-07-23 16:14:27 --> Loader Class Initialized
INFO - 2017-07-23 16:14:27 --> Controller Class Initialized
INFO - 2017-07-23 16:14:27 --> Database Driver Class Initialized
INFO - 2017-07-23 16:14:27 --> Model Class Initialized
INFO - 2017-07-23 16:14:27 --> Helper loaded: form_helper
INFO - 2017-07-23 16:14:27 --> Helper loaded: url_helper
INFO - 2017-07-23 16:14:27 --> Upload Class Initialized
INFO - 2017-07-23 16:14:27 --> Final output sent to browser
DEBUG - 2017-07-23 16:14:27 --> Total execution time: 0.0520
ERROR - 2017-07-23 16:14:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:14:29 --> Config Class Initialized
INFO - 2017-07-23 16:14:29 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:14:29 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:14:29 --> Utf8 Class Initialized
INFO - 2017-07-23 16:14:29 --> URI Class Initialized
INFO - 2017-07-23 16:14:29 --> Router Class Initialized
INFO - 2017-07-23 16:14:29 --> Output Class Initialized
INFO - 2017-07-23 16:14:29 --> Security Class Initialized
DEBUG - 2017-07-23 16:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:14:29 --> Input Class Initialized
INFO - 2017-07-23 16:14:29 --> Language Class Initialized
INFO - 2017-07-23 16:14:29 --> Loader Class Initialized
INFO - 2017-07-23 16:14:29 --> Controller Class Initialized
INFO - 2017-07-23 16:14:29 --> Database Driver Class Initialized
INFO - 2017-07-23 16:14:29 --> Model Class Initialized
INFO - 2017-07-23 16:14:29 --> Helper loaded: form_helper
INFO - 2017-07-23 16:14:29 --> Helper loaded: url_helper
INFO - 2017-07-23 16:14:29 --> Model Class Initialized
INFO - 2017-07-23 16:14:29 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-23 16:14:29 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-23 16:14:29 --> Final output sent to browser
DEBUG - 2017-07-23 16:14:29 --> Total execution time: 0.1850
ERROR - 2017-07-23 16:14:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:14:37 --> Config Class Initialized
INFO - 2017-07-23 16:14:37 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:14:37 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:14:37 --> Utf8 Class Initialized
INFO - 2017-07-23 16:14:37 --> URI Class Initialized
INFO - 2017-07-23 16:14:37 --> Router Class Initialized
INFO - 2017-07-23 16:14:37 --> Output Class Initialized
INFO - 2017-07-23 16:14:37 --> Security Class Initialized
DEBUG - 2017-07-23 16:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:14:37 --> Input Class Initialized
INFO - 2017-07-23 16:14:37 --> Language Class Initialized
INFO - 2017-07-23 16:14:37 --> Loader Class Initialized
INFO - 2017-07-23 16:14:37 --> Controller Class Initialized
INFO - 2017-07-23 16:14:37 --> Database Driver Class Initialized
INFO - 2017-07-23 16:14:37 --> Model Class Initialized
INFO - 2017-07-23 16:14:37 --> Helper loaded: form_helper
INFO - 2017-07-23 16:14:37 --> Helper loaded: url_helper
INFO - 2017-07-23 16:14:37 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-23 16:14:37 --> Model Class Initialized
INFO - 2017-07-23 16:14:37 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-23 16:14:37 --> Final output sent to browser
DEBUG - 2017-07-23 16:14:37 --> Total execution time: 0.0630
ERROR - 2017-07-23 16:14:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:14:40 --> Config Class Initialized
INFO - 2017-07-23 16:14:40 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:14:40 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:14:40 --> Utf8 Class Initialized
INFO - 2017-07-23 16:14:40 --> URI Class Initialized
INFO - 2017-07-23 16:14:40 --> Router Class Initialized
INFO - 2017-07-23 16:14:40 --> Output Class Initialized
INFO - 2017-07-23 16:14:40 --> Security Class Initialized
DEBUG - 2017-07-23 16:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:14:40 --> Input Class Initialized
INFO - 2017-07-23 16:14:40 --> Language Class Initialized
INFO - 2017-07-23 16:14:40 --> Loader Class Initialized
INFO - 2017-07-23 16:14:40 --> Controller Class Initialized
INFO - 2017-07-23 16:14:40 --> Database Driver Class Initialized
INFO - 2017-07-23 16:14:40 --> Model Class Initialized
INFO - 2017-07-23 16:14:40 --> Helper loaded: form_helper
INFO - 2017-07-23 16:14:40 --> Helper loaded: url_helper
INFO - 2017-07-23 16:14:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-23 16:14:40 --> Model Class Initialized
INFO - 2017-07-23 16:14:40 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-23 16:14:40 --> Final output sent to browser
DEBUG - 2017-07-23 16:14:40 --> Total execution time: 0.1200
ERROR - 2017-07-23 16:16:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:16:18 --> Config Class Initialized
INFO - 2017-07-23 16:16:18 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:16:18 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:16:18 --> Utf8 Class Initialized
INFO - 2017-07-23 16:16:18 --> URI Class Initialized
INFO - 2017-07-23 16:16:18 --> Router Class Initialized
INFO - 2017-07-23 16:16:18 --> Output Class Initialized
INFO - 2017-07-23 16:16:18 --> Security Class Initialized
DEBUG - 2017-07-23 16:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:16:18 --> Input Class Initialized
INFO - 2017-07-23 16:16:18 --> Language Class Initialized
INFO - 2017-07-23 16:16:18 --> Loader Class Initialized
INFO - 2017-07-23 16:16:18 --> Controller Class Initialized
INFO - 2017-07-23 16:16:18 --> Database Driver Class Initialized
INFO - 2017-07-23 16:16:18 --> Model Class Initialized
INFO - 2017-07-23 16:16:18 --> Helper loaded: form_helper
INFO - 2017-07-23 16:16:18 --> Helper loaded: url_helper
INFO - 2017-07-23 16:16:18 --> Upload Class Initialized
INFO - 2017-07-23 16:16:18 --> Final output sent to browser
DEBUG - 2017-07-23 16:16:18 --> Total execution time: 0.0560
ERROR - 2017-07-23 16:16:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:16:21 --> Config Class Initialized
INFO - 2017-07-23 16:16:21 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:16:21 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:16:21 --> Utf8 Class Initialized
INFO - 2017-07-23 16:16:21 --> URI Class Initialized
INFO - 2017-07-23 16:16:21 --> Router Class Initialized
INFO - 2017-07-23 16:16:21 --> Output Class Initialized
INFO - 2017-07-23 16:16:21 --> Security Class Initialized
DEBUG - 2017-07-23 16:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:16:21 --> Input Class Initialized
INFO - 2017-07-23 16:16:21 --> Language Class Initialized
INFO - 2017-07-23 16:16:21 --> Loader Class Initialized
INFO - 2017-07-23 16:16:21 --> Controller Class Initialized
INFO - 2017-07-23 16:16:21 --> Database Driver Class Initialized
INFO - 2017-07-23 16:16:21 --> Model Class Initialized
INFO - 2017-07-23 16:16:21 --> Helper loaded: form_helper
INFO - 2017-07-23 16:16:21 --> Helper loaded: url_helper
INFO - 2017-07-23 16:16:21 --> Upload Class Initialized
INFO - 2017-07-23 16:16:21 --> Final output sent to browser
DEBUG - 2017-07-23 16:16:21 --> Total execution time: 0.0530
ERROR - 2017-07-23 16:16:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:16:31 --> Config Class Initialized
INFO - 2017-07-23 16:16:31 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:16:31 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:16:31 --> Utf8 Class Initialized
INFO - 2017-07-23 16:16:31 --> URI Class Initialized
INFO - 2017-07-23 16:16:31 --> Router Class Initialized
INFO - 2017-07-23 16:16:31 --> Output Class Initialized
INFO - 2017-07-23 16:16:31 --> Security Class Initialized
DEBUG - 2017-07-23 16:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:16:31 --> Input Class Initialized
INFO - 2017-07-23 16:16:31 --> Language Class Initialized
INFO - 2017-07-23 16:16:31 --> Loader Class Initialized
INFO - 2017-07-23 16:16:31 --> Controller Class Initialized
INFO - 2017-07-23 16:16:31 --> Database Driver Class Initialized
INFO - 2017-07-23 16:16:31 --> Model Class Initialized
INFO - 2017-07-23 16:16:31 --> Helper loaded: form_helper
INFO - 2017-07-23 16:16:31 --> Helper loaded: url_helper
INFO - 2017-07-23 16:16:31 --> Model Class Initialized
INFO - 2017-07-23 16:16:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-23 16:16:31 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-23 16:16:31 --> Final output sent to browser
DEBUG - 2017-07-23 16:16:31 --> Total execution time: 0.1420
ERROR - 2017-07-23 16:30:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:30:29 --> Config Class Initialized
INFO - 2017-07-23 16:30:29 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:30:29 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:30:29 --> Utf8 Class Initialized
INFO - 2017-07-23 16:30:29 --> URI Class Initialized
INFO - 2017-07-23 16:30:29 --> Router Class Initialized
INFO - 2017-07-23 16:30:29 --> Output Class Initialized
INFO - 2017-07-23 16:30:29 --> Security Class Initialized
DEBUG - 2017-07-23 16:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:30:29 --> Input Class Initialized
INFO - 2017-07-23 16:30:29 --> Language Class Initialized
INFO - 2017-07-23 16:30:29 --> Loader Class Initialized
INFO - 2017-07-23 16:30:29 --> Controller Class Initialized
INFO - 2017-07-23 16:30:29 --> Database Driver Class Initialized
INFO - 2017-07-23 16:30:29 --> Model Class Initialized
INFO - 2017-07-23 16:30:29 --> Helper loaded: form_helper
INFO - 2017-07-23 16:30:29 --> Helper loaded: url_helper
INFO - 2017-07-23 16:30:29 --> Upload Class Initialized
INFO - 2017-07-23 16:30:29 --> Final output sent to browser
DEBUG - 2017-07-23 16:30:29 --> Total execution time: 0.0650
ERROR - 2017-07-23 16:30:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:30:34 --> Config Class Initialized
INFO - 2017-07-23 16:30:34 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:30:34 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:30:34 --> Utf8 Class Initialized
INFO - 2017-07-23 16:30:34 --> URI Class Initialized
INFO - 2017-07-23 16:30:34 --> Router Class Initialized
INFO - 2017-07-23 16:30:34 --> Output Class Initialized
INFO - 2017-07-23 16:30:34 --> Security Class Initialized
DEBUG - 2017-07-23 16:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:30:34 --> Input Class Initialized
INFO - 2017-07-23 16:30:34 --> Language Class Initialized
INFO - 2017-07-23 16:30:34 --> Loader Class Initialized
INFO - 2017-07-23 16:30:34 --> Controller Class Initialized
INFO - 2017-07-23 16:30:34 --> Database Driver Class Initialized
INFO - 2017-07-23 16:30:34 --> Model Class Initialized
INFO - 2017-07-23 16:30:34 --> Helper loaded: form_helper
INFO - 2017-07-23 16:30:34 --> Helper loaded: url_helper
INFO - 2017-07-23 16:30:34 --> Model Class Initialized
INFO - 2017-07-23 16:30:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-23 16:30:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-23 16:30:34 --> Final output sent to browser
DEBUG - 2017-07-23 16:30:34 --> Total execution time: 0.2200
ERROR - 2017-07-23 16:32:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:32:12 --> Config Class Initialized
INFO - 2017-07-23 16:32:12 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:32:12 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:32:12 --> Utf8 Class Initialized
INFO - 2017-07-23 16:32:12 --> URI Class Initialized
INFO - 2017-07-23 16:32:12 --> Router Class Initialized
INFO - 2017-07-23 16:32:12 --> Output Class Initialized
INFO - 2017-07-23 16:32:12 --> Security Class Initialized
DEBUG - 2017-07-23 16:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:32:12 --> Input Class Initialized
INFO - 2017-07-23 16:32:12 --> Language Class Initialized
INFO - 2017-07-23 16:32:12 --> Loader Class Initialized
INFO - 2017-07-23 16:32:12 --> Controller Class Initialized
INFO - 2017-07-23 16:32:12 --> Database Driver Class Initialized
INFO - 2017-07-23 16:32:12 --> Model Class Initialized
INFO - 2017-07-23 16:32:12 --> Helper loaded: form_helper
INFO - 2017-07-23 16:32:12 --> Helper loaded: url_helper
INFO - 2017-07-23 16:32:12 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-23 16:32:12 --> Model Class Initialized
INFO - 2017-07-23 16:32:12 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-23 16:32:12 --> Final output sent to browser
DEBUG - 2017-07-23 16:32:12 --> Total execution time: 0.1050
ERROR - 2017-07-23 16:57:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 16:57:11 --> Config Class Initialized
INFO - 2017-07-23 16:57:11 --> Hooks Class Initialized
DEBUG - 2017-07-23 16:57:11 --> UTF-8 Support Enabled
INFO - 2017-07-23 16:57:11 --> Utf8 Class Initialized
INFO - 2017-07-23 16:57:11 --> URI Class Initialized
INFO - 2017-07-23 16:57:11 --> Router Class Initialized
INFO - 2017-07-23 16:57:11 --> Output Class Initialized
INFO - 2017-07-23 16:57:11 --> Security Class Initialized
DEBUG - 2017-07-23 16:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 16:57:11 --> Input Class Initialized
INFO - 2017-07-23 16:57:11 --> Language Class Initialized
INFO - 2017-07-23 16:57:11 --> Loader Class Initialized
INFO - 2017-07-23 16:57:11 --> Controller Class Initialized
INFO - 2017-07-23 16:57:11 --> Database Driver Class Initialized
INFO - 2017-07-23 16:57:11 --> Model Class Initialized
INFO - 2017-07-23 16:57:11 --> Helper loaded: form_helper
INFO - 2017-07-23 16:57:11 --> Helper loaded: url_helper
INFO - 2017-07-23 16:57:11 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-23 16:57:11 --> Model Class Initialized
INFO - 2017-07-23 16:57:11 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-23 16:57:11 --> Final output sent to browser
DEBUG - 2017-07-23 16:57:11 --> Total execution time: 0.0810
ERROR - 2017-07-23 17:06:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 17:06:40 --> Config Class Initialized
INFO - 2017-07-23 17:06:40 --> Hooks Class Initialized
DEBUG - 2017-07-23 17:06:40 --> UTF-8 Support Enabled
INFO - 2017-07-23 17:06:40 --> Utf8 Class Initialized
INFO - 2017-07-23 17:06:40 --> URI Class Initialized
INFO - 2017-07-23 17:06:40 --> Router Class Initialized
INFO - 2017-07-23 17:06:40 --> Output Class Initialized
INFO - 2017-07-23 17:06:40 --> Security Class Initialized
DEBUG - 2017-07-23 17:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 17:06:40 --> Input Class Initialized
INFO - 2017-07-23 17:06:40 --> Language Class Initialized
INFO - 2017-07-23 17:06:40 --> Loader Class Initialized
INFO - 2017-07-23 17:06:40 --> Controller Class Initialized
INFO - 2017-07-23 17:06:40 --> Database Driver Class Initialized
INFO - 2017-07-23 17:06:40 --> Model Class Initialized
INFO - 2017-07-23 17:06:40 --> Helper loaded: form_helper
INFO - 2017-07-23 17:06:40 --> Helper loaded: url_helper
INFO - 2017-07-23 17:06:40 --> Upload Class Initialized
INFO - 2017-07-23 17:06:40 --> Final output sent to browser
DEBUG - 2017-07-23 17:06:40 --> Total execution time: 0.0540
ERROR - 2017-07-23 17:06:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 17:06:46 --> Config Class Initialized
INFO - 2017-07-23 17:06:46 --> Hooks Class Initialized
DEBUG - 2017-07-23 17:06:46 --> UTF-8 Support Enabled
INFO - 2017-07-23 17:06:46 --> Utf8 Class Initialized
INFO - 2017-07-23 17:06:46 --> URI Class Initialized
INFO - 2017-07-23 17:06:46 --> Router Class Initialized
INFO - 2017-07-23 17:06:46 --> Output Class Initialized
INFO - 2017-07-23 17:06:46 --> Security Class Initialized
DEBUG - 2017-07-23 17:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 17:06:46 --> Input Class Initialized
INFO - 2017-07-23 17:06:46 --> Language Class Initialized
INFO - 2017-07-23 17:06:46 --> Loader Class Initialized
INFO - 2017-07-23 17:06:46 --> Controller Class Initialized
INFO - 2017-07-23 17:06:46 --> Database Driver Class Initialized
INFO - 2017-07-23 17:06:46 --> Model Class Initialized
INFO - 2017-07-23 17:06:46 --> Helper loaded: form_helper
INFO - 2017-07-23 17:06:46 --> Helper loaded: url_helper
INFO - 2017-07-23 17:06:46 --> Model Class Initialized
INFO - 2017-07-23 17:06:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-23 17:06:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-23 17:06:46 --> Final output sent to browser
DEBUG - 2017-07-23 17:06:46 --> Total execution time: 0.1380
ERROR - 2017-07-23 17:44:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 17:44:07 --> Config Class Initialized
INFO - 2017-07-23 17:44:07 --> Hooks Class Initialized
DEBUG - 2017-07-23 17:44:07 --> UTF-8 Support Enabled
INFO - 2017-07-23 17:44:07 --> Utf8 Class Initialized
INFO - 2017-07-23 17:44:07 --> URI Class Initialized
INFO - 2017-07-23 17:44:07 --> Router Class Initialized
INFO - 2017-07-23 17:44:07 --> Output Class Initialized
INFO - 2017-07-23 17:44:07 --> Security Class Initialized
DEBUG - 2017-07-23 17:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 17:44:07 --> Input Class Initialized
INFO - 2017-07-23 17:44:07 --> Language Class Initialized
INFO - 2017-07-23 17:44:07 --> Loader Class Initialized
INFO - 2017-07-23 17:44:07 --> Controller Class Initialized
INFO - 2017-07-23 17:44:07 --> Database Driver Class Initialized
INFO - 2017-07-23 17:44:07 --> Model Class Initialized
INFO - 2017-07-23 17:44:07 --> Helper loaded: form_helper
INFO - 2017-07-23 17:44:07 --> Helper loaded: url_helper
INFO - 2017-07-23 17:44:07 --> Upload Class Initialized
INFO - 2017-07-23 17:44:07 --> Final output sent to browser
DEBUG - 2017-07-23 17:44:07 --> Total execution time: 0.0570
ERROR - 2017-07-23 17:44:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 17:44:20 --> Config Class Initialized
INFO - 2017-07-23 17:44:20 --> Hooks Class Initialized
DEBUG - 2017-07-23 17:44:20 --> UTF-8 Support Enabled
INFO - 2017-07-23 17:44:20 --> Utf8 Class Initialized
INFO - 2017-07-23 17:44:20 --> URI Class Initialized
INFO - 2017-07-23 17:44:20 --> Router Class Initialized
INFO - 2017-07-23 17:44:20 --> Output Class Initialized
INFO - 2017-07-23 17:44:20 --> Security Class Initialized
DEBUG - 2017-07-23 17:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 17:44:20 --> Input Class Initialized
INFO - 2017-07-23 17:44:20 --> Language Class Initialized
INFO - 2017-07-23 17:44:20 --> Loader Class Initialized
INFO - 2017-07-23 17:44:20 --> Controller Class Initialized
INFO - 2017-07-23 17:44:20 --> Database Driver Class Initialized
INFO - 2017-07-23 17:44:20 --> Model Class Initialized
INFO - 2017-07-23 17:44:20 --> Helper loaded: form_helper
INFO - 2017-07-23 17:44:20 --> Helper loaded: url_helper
INFO - 2017-07-23 17:44:20 --> Upload Class Initialized
INFO - 2017-07-23 17:44:20 --> Final output sent to browser
DEBUG - 2017-07-23 17:44:20 --> Total execution time: 0.0540
ERROR - 2017-07-23 17:44:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 17:44:23 --> Config Class Initialized
INFO - 2017-07-23 17:44:23 --> Hooks Class Initialized
DEBUG - 2017-07-23 17:44:23 --> UTF-8 Support Enabled
INFO - 2017-07-23 17:44:23 --> Utf8 Class Initialized
INFO - 2017-07-23 17:44:23 --> URI Class Initialized
INFO - 2017-07-23 17:44:23 --> Router Class Initialized
INFO - 2017-07-23 17:44:23 --> Output Class Initialized
INFO - 2017-07-23 17:44:23 --> Security Class Initialized
DEBUG - 2017-07-23 17:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 17:44:23 --> Input Class Initialized
INFO - 2017-07-23 17:44:23 --> Language Class Initialized
INFO - 2017-07-23 17:44:23 --> Loader Class Initialized
INFO - 2017-07-23 17:44:23 --> Controller Class Initialized
INFO - 2017-07-23 17:44:23 --> Database Driver Class Initialized
INFO - 2017-07-23 17:44:23 --> Model Class Initialized
INFO - 2017-07-23 17:44:23 --> Helper loaded: form_helper
INFO - 2017-07-23 17:44:23 --> Helper loaded: url_helper
INFO - 2017-07-23 17:44:23 --> Upload Class Initialized
INFO - 2017-07-23 17:44:23 --> Final output sent to browser
DEBUG - 2017-07-23 17:44:23 --> Total execution time: 0.0750
ERROR - 2017-07-23 17:44:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 17:44:26 --> Config Class Initialized
INFO - 2017-07-23 17:44:26 --> Hooks Class Initialized
DEBUG - 2017-07-23 17:44:26 --> UTF-8 Support Enabled
INFO - 2017-07-23 17:44:26 --> Utf8 Class Initialized
INFO - 2017-07-23 17:44:26 --> URI Class Initialized
INFO - 2017-07-23 17:44:26 --> Router Class Initialized
INFO - 2017-07-23 17:44:26 --> Output Class Initialized
INFO - 2017-07-23 17:44:26 --> Security Class Initialized
DEBUG - 2017-07-23 17:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 17:44:26 --> Input Class Initialized
INFO - 2017-07-23 17:44:26 --> Language Class Initialized
INFO - 2017-07-23 17:44:26 --> Loader Class Initialized
INFO - 2017-07-23 17:44:26 --> Controller Class Initialized
INFO - 2017-07-23 17:44:26 --> Database Driver Class Initialized
INFO - 2017-07-23 17:44:26 --> Model Class Initialized
INFO - 2017-07-23 17:44:26 --> Helper loaded: form_helper
INFO - 2017-07-23 17:44:26 --> Helper loaded: url_helper
INFO - 2017-07-23 17:44:26 --> Upload Class Initialized
INFO - 2017-07-23 17:44:26 --> Final output sent to browser
DEBUG - 2017-07-23 17:44:26 --> Total execution time: 0.0590
ERROR - 2017-07-23 17:44:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-23 17:44:28 --> Config Class Initialized
INFO - 2017-07-23 17:44:28 --> Hooks Class Initialized
DEBUG - 2017-07-23 17:44:28 --> UTF-8 Support Enabled
INFO - 2017-07-23 17:44:28 --> Utf8 Class Initialized
INFO - 2017-07-23 17:44:28 --> URI Class Initialized
INFO - 2017-07-23 17:44:28 --> Router Class Initialized
INFO - 2017-07-23 17:44:28 --> Output Class Initialized
INFO - 2017-07-23 17:44:28 --> Security Class Initialized
DEBUG - 2017-07-23 17:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-23 17:44:28 --> Input Class Initialized
INFO - 2017-07-23 17:44:28 --> Language Class Initialized
INFO - 2017-07-23 17:44:28 --> Loader Class Initialized
INFO - 2017-07-23 17:44:28 --> Controller Class Initialized
INFO - 2017-07-23 17:44:28 --> Database Driver Class Initialized
INFO - 2017-07-23 17:44:28 --> Model Class Initialized
INFO - 2017-07-23 17:44:28 --> Helper loaded: form_helper
INFO - 2017-07-23 17:44:28 --> Helper loaded: url_helper
INFO - 2017-07-23 17:44:28 --> Model Class Initialized
INFO - 2017-07-23 17:44:28 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-23 17:44:28 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-07-23 17:44:28 --> Final output sent to browser
DEBUG - 2017-07-23 17:44:28 --> Total execution time: 0.1820
