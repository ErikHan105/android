<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-29 03:46:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 03:46:03 --> Config Class Initialized
INFO - 2017-06-29 03:46:03 --> Hooks Class Initialized
DEBUG - 2017-06-29 03:46:03 --> UTF-8 Support Enabled
INFO - 2017-06-29 03:46:03 --> Utf8 Class Initialized
INFO - 2017-06-29 03:46:03 --> URI Class Initialized
INFO - 2017-06-29 03:46:03 --> Router Class Initialized
INFO - 2017-06-29 03:46:03 --> Output Class Initialized
INFO - 2017-06-29 03:46:03 --> Security Class Initialized
DEBUG - 2017-06-29 03:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 03:46:03 --> Input Class Initialized
INFO - 2017-06-29 03:46:03 --> Language Class Initialized
INFO - 2017-06-29 03:46:03 --> Loader Class Initialized
INFO - 2017-06-29 03:46:03 --> Controller Class Initialized
INFO - 2017-06-29 03:46:03 --> Database Driver Class Initialized
INFO - 2017-06-29 03:46:03 --> Model Class Initialized
INFO - 2017-06-29 03:46:03 --> Helper loaded: form_helper
INFO - 2017-06-29 03:46:03 --> Helper loaded: url_helper
INFO - 2017-06-29 03:46:03 --> Model Class Initialized
INFO - 2017-06-29 03:46:03 --> Final output sent to browser
DEBUG - 2017-06-29 03:46:03 --> Total execution time: 0.0500
ERROR - 2017-06-29 03:51:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 03:51:17 --> Config Class Initialized
INFO - 2017-06-29 03:51:17 --> Hooks Class Initialized
DEBUG - 2017-06-29 03:51:17 --> UTF-8 Support Enabled
INFO - 2017-06-29 03:51:17 --> Utf8 Class Initialized
INFO - 2017-06-29 03:51:17 --> URI Class Initialized
INFO - 2017-06-29 03:51:17 --> Router Class Initialized
INFO - 2017-06-29 03:51:17 --> Output Class Initialized
INFO - 2017-06-29 03:51:17 --> Security Class Initialized
DEBUG - 2017-06-29 03:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 03:51:17 --> Input Class Initialized
INFO - 2017-06-29 03:51:17 --> Language Class Initialized
INFO - 2017-06-29 03:51:17 --> Loader Class Initialized
INFO - 2017-06-29 03:51:17 --> Controller Class Initialized
INFO - 2017-06-29 03:51:17 --> Database Driver Class Initialized
INFO - 2017-06-29 03:51:17 --> Model Class Initialized
INFO - 2017-06-29 03:51:17 --> Helper loaded: form_helper
INFO - 2017-06-29 03:51:17 --> Helper loaded: url_helper
INFO - 2017-06-29 03:51:17 --> Model Class Initialized
INFO - 2017-06-29 03:51:17 --> Final output sent to browser
DEBUG - 2017-06-29 03:51:17 --> Total execution time: 0.0610
ERROR - 2017-06-29 04:01:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 04:01:33 --> Config Class Initialized
INFO - 2017-06-29 04:01:33 --> Hooks Class Initialized
DEBUG - 2017-06-29 04:01:33 --> UTF-8 Support Enabled
INFO - 2017-06-29 04:01:33 --> Utf8 Class Initialized
INFO - 2017-06-29 04:01:33 --> URI Class Initialized
INFO - 2017-06-29 04:01:33 --> Router Class Initialized
INFO - 2017-06-29 04:01:33 --> Output Class Initialized
INFO - 2017-06-29 04:01:33 --> Security Class Initialized
DEBUG - 2017-06-29 04:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 04:01:33 --> Input Class Initialized
INFO - 2017-06-29 04:01:33 --> Language Class Initialized
INFO - 2017-06-29 04:01:33 --> Loader Class Initialized
INFO - 2017-06-29 04:01:33 --> Controller Class Initialized
INFO - 2017-06-29 04:01:33 --> Database Driver Class Initialized
INFO - 2017-06-29 04:01:33 --> Model Class Initialized
INFO - 2017-06-29 04:01:33 --> Helper loaded: form_helper
INFO - 2017-06-29 04:01:33 --> Helper loaded: url_helper
INFO - 2017-06-29 04:01:33 --> Model Class Initialized
INFO - 2017-06-29 04:01:33 --> Final output sent to browser
DEBUG - 2017-06-29 04:01:33 --> Total execution time: 0.0420
ERROR - 2017-06-29 04:01:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 04:01:34 --> Config Class Initialized
INFO - 2017-06-29 04:01:34 --> Hooks Class Initialized
DEBUG - 2017-06-29 04:01:34 --> UTF-8 Support Enabled
INFO - 2017-06-29 04:01:34 --> Utf8 Class Initialized
INFO - 2017-06-29 04:01:34 --> URI Class Initialized
INFO - 2017-06-29 04:01:34 --> Router Class Initialized
INFO - 2017-06-29 04:01:34 --> Output Class Initialized
INFO - 2017-06-29 04:01:34 --> Security Class Initialized
DEBUG - 2017-06-29 04:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 04:01:34 --> Input Class Initialized
INFO - 2017-06-29 04:01:34 --> Language Class Initialized
INFO - 2017-06-29 04:01:34 --> Loader Class Initialized
INFO - 2017-06-29 04:01:34 --> Controller Class Initialized
INFO - 2017-06-29 04:01:34 --> Database Driver Class Initialized
INFO - 2017-06-29 04:01:34 --> Model Class Initialized
INFO - 2017-06-29 04:01:34 --> Helper loaded: form_helper
INFO - 2017-06-29 04:01:34 --> Helper loaded: url_helper
INFO - 2017-06-29 04:01:34 --> Model Class Initialized
INFO - 2017-06-29 04:01:34 --> Final output sent to browser
DEBUG - 2017-06-29 04:01:34 --> Total execution time: 0.0380
ERROR - 2017-06-29 04:01:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 04:01:38 --> Config Class Initialized
INFO - 2017-06-29 04:01:38 --> Hooks Class Initialized
DEBUG - 2017-06-29 04:01:38 --> UTF-8 Support Enabled
INFO - 2017-06-29 04:01:38 --> Utf8 Class Initialized
INFO - 2017-06-29 04:01:38 --> URI Class Initialized
INFO - 2017-06-29 04:01:38 --> Router Class Initialized
INFO - 2017-06-29 04:01:38 --> Output Class Initialized
INFO - 2017-06-29 04:01:38 --> Security Class Initialized
DEBUG - 2017-06-29 04:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 04:01:38 --> Input Class Initialized
INFO - 2017-06-29 04:01:38 --> Language Class Initialized
INFO - 2017-06-29 04:01:38 --> Loader Class Initialized
INFO - 2017-06-29 04:01:38 --> Controller Class Initialized
INFO - 2017-06-29 04:01:38 --> Database Driver Class Initialized
INFO - 2017-06-29 04:01:38 --> Model Class Initialized
INFO - 2017-06-29 04:01:38 --> Helper loaded: form_helper
INFO - 2017-06-29 04:01:38 --> Helper loaded: url_helper
INFO - 2017-06-29 04:01:38 --> Model Class Initialized
INFO - 2017-06-29 04:01:38 --> Final output sent to browser
DEBUG - 2017-06-29 04:01:38 --> Total execution time: 0.0430
ERROR - 2017-06-29 04:01:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 04:01:45 --> Config Class Initialized
INFO - 2017-06-29 04:01:45 --> Hooks Class Initialized
DEBUG - 2017-06-29 04:01:45 --> UTF-8 Support Enabled
INFO - 2017-06-29 04:01:45 --> Utf8 Class Initialized
INFO - 2017-06-29 04:01:45 --> URI Class Initialized
INFO - 2017-06-29 04:01:45 --> Router Class Initialized
INFO - 2017-06-29 04:01:45 --> Output Class Initialized
INFO - 2017-06-29 04:01:46 --> Security Class Initialized
DEBUG - 2017-06-29 04:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 04:01:46 --> Input Class Initialized
INFO - 2017-06-29 04:01:46 --> Language Class Initialized
INFO - 2017-06-29 04:01:46 --> Loader Class Initialized
INFO - 2017-06-29 04:01:46 --> Controller Class Initialized
INFO - 2017-06-29 04:01:46 --> Database Driver Class Initialized
INFO - 2017-06-29 04:01:46 --> Model Class Initialized
INFO - 2017-06-29 04:01:46 --> Helper loaded: form_helper
INFO - 2017-06-29 04:01:46 --> Helper loaded: url_helper
INFO - 2017-06-29 04:01:46 --> Model Class Initialized
INFO - 2017-06-29 04:01:46 --> Final output sent to browser
DEBUG - 2017-06-29 04:01:46 --> Total execution time: 0.0340
ERROR - 2017-06-29 04:02:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 04:02:00 --> Config Class Initialized
INFO - 2017-06-29 04:02:00 --> Hooks Class Initialized
DEBUG - 2017-06-29 04:02:00 --> UTF-8 Support Enabled
INFO - 2017-06-29 04:02:00 --> Utf8 Class Initialized
INFO - 2017-06-29 04:02:00 --> URI Class Initialized
INFO - 2017-06-29 04:02:00 --> Router Class Initialized
INFO - 2017-06-29 04:02:00 --> Output Class Initialized
INFO - 2017-06-29 04:02:00 --> Security Class Initialized
DEBUG - 2017-06-29 04:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 04:02:00 --> Input Class Initialized
INFO - 2017-06-29 04:02:00 --> Language Class Initialized
INFO - 2017-06-29 04:02:00 --> Loader Class Initialized
INFO - 2017-06-29 04:02:00 --> Controller Class Initialized
INFO - 2017-06-29 04:02:00 --> Database Driver Class Initialized
INFO - 2017-06-29 04:02:00 --> Model Class Initialized
INFO - 2017-06-29 04:02:00 --> Helper loaded: form_helper
INFO - 2017-06-29 04:02:00 --> Helper loaded: url_helper
INFO - 2017-06-29 04:02:00 --> Model Class Initialized
INFO - 2017-06-29 04:02:00 --> Final output sent to browser
DEBUG - 2017-06-29 04:02:00 --> Total execution time: 0.0570
ERROR - 2017-06-29 04:02:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 04:02:15 --> Config Class Initialized
INFO - 2017-06-29 04:02:15 --> Hooks Class Initialized
DEBUG - 2017-06-29 04:02:15 --> UTF-8 Support Enabled
INFO - 2017-06-29 04:02:15 --> Utf8 Class Initialized
INFO - 2017-06-29 04:02:15 --> URI Class Initialized
INFO - 2017-06-29 04:02:15 --> Router Class Initialized
INFO - 2017-06-29 04:02:15 --> Output Class Initialized
INFO - 2017-06-29 04:02:15 --> Security Class Initialized
DEBUG - 2017-06-29 04:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 04:02:15 --> Input Class Initialized
INFO - 2017-06-29 04:02:15 --> Language Class Initialized
INFO - 2017-06-29 04:02:15 --> Loader Class Initialized
INFO - 2017-06-29 04:02:15 --> Controller Class Initialized
INFO - 2017-06-29 04:02:15 --> Database Driver Class Initialized
INFO - 2017-06-29 04:02:15 --> Model Class Initialized
INFO - 2017-06-29 04:02:15 --> Helper loaded: form_helper
INFO - 2017-06-29 04:02:15 --> Helper loaded: url_helper
INFO - 2017-06-29 04:02:15 --> Model Class Initialized
INFO - 2017-06-29 04:02:15 --> Final output sent to browser
DEBUG - 2017-06-29 04:02:15 --> Total execution time: 0.0610
ERROR - 2017-06-29 04:02:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 04:02:30 --> Config Class Initialized
INFO - 2017-06-29 04:02:30 --> Hooks Class Initialized
DEBUG - 2017-06-29 04:02:30 --> UTF-8 Support Enabled
INFO - 2017-06-29 04:02:30 --> Utf8 Class Initialized
INFO - 2017-06-29 04:02:30 --> URI Class Initialized
INFO - 2017-06-29 04:02:30 --> Router Class Initialized
INFO - 2017-06-29 04:02:30 --> Output Class Initialized
INFO - 2017-06-29 04:02:30 --> Security Class Initialized
DEBUG - 2017-06-29 04:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 04:02:30 --> Input Class Initialized
INFO - 2017-06-29 04:02:30 --> Language Class Initialized
INFO - 2017-06-29 04:02:30 --> Loader Class Initialized
INFO - 2017-06-29 04:02:30 --> Controller Class Initialized
INFO - 2017-06-29 04:02:30 --> Database Driver Class Initialized
INFO - 2017-06-29 04:02:30 --> Model Class Initialized
INFO - 2017-06-29 04:02:30 --> Helper loaded: form_helper
INFO - 2017-06-29 04:02:30 --> Helper loaded: url_helper
INFO - 2017-06-29 04:02:30 --> Model Class Initialized
INFO - 2017-06-29 04:02:30 --> Final output sent to browser
DEBUG - 2017-06-29 04:02:30 --> Total execution time: 0.0540
ERROR - 2017-06-29 04:02:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 04:02:54 --> Config Class Initialized
INFO - 2017-06-29 04:02:54 --> Hooks Class Initialized
DEBUG - 2017-06-29 04:02:54 --> UTF-8 Support Enabled
INFO - 2017-06-29 04:02:54 --> Utf8 Class Initialized
INFO - 2017-06-29 04:02:54 --> URI Class Initialized
INFO - 2017-06-29 04:02:54 --> Router Class Initialized
INFO - 2017-06-29 04:02:54 --> Output Class Initialized
INFO - 2017-06-29 04:02:54 --> Security Class Initialized
DEBUG - 2017-06-29 04:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 04:02:54 --> Input Class Initialized
INFO - 2017-06-29 04:02:54 --> Language Class Initialized
INFO - 2017-06-29 04:02:54 --> Loader Class Initialized
INFO - 2017-06-29 04:02:54 --> Controller Class Initialized
INFO - 2017-06-29 04:02:54 --> Database Driver Class Initialized
INFO - 2017-06-29 04:02:54 --> Model Class Initialized
INFO - 2017-06-29 04:02:54 --> Helper loaded: form_helper
INFO - 2017-06-29 04:02:54 --> Helper loaded: url_helper
INFO - 2017-06-29 04:02:54 --> Model Class Initialized
INFO - 2017-06-29 04:02:54 --> Final output sent to browser
DEBUG - 2017-06-29 04:02:54 --> Total execution time: 0.0420
ERROR - 2017-06-29 04:12:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 04:12:55 --> Config Class Initialized
INFO - 2017-06-29 04:12:55 --> Hooks Class Initialized
DEBUG - 2017-06-29 04:12:55 --> UTF-8 Support Enabled
INFO - 2017-06-29 04:12:55 --> Utf8 Class Initialized
INFO - 2017-06-29 04:12:55 --> URI Class Initialized
INFO - 2017-06-29 04:12:55 --> Router Class Initialized
INFO - 2017-06-29 04:12:55 --> Output Class Initialized
INFO - 2017-06-29 04:12:55 --> Security Class Initialized
DEBUG - 2017-06-29 04:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 04:12:55 --> Input Class Initialized
INFO - 2017-06-29 04:12:55 --> Language Class Initialized
INFO - 2017-06-29 04:12:55 --> Loader Class Initialized
INFO - 2017-06-29 04:12:55 --> Controller Class Initialized
INFO - 2017-06-29 04:12:55 --> Database Driver Class Initialized
INFO - 2017-06-29 04:12:55 --> Model Class Initialized
INFO - 2017-06-29 04:12:55 --> Helper loaded: form_helper
INFO - 2017-06-29 04:12:55 --> Helper loaded: url_helper
INFO - 2017-06-29 04:12:55 --> Model Class Initialized
INFO - 2017-06-29 04:12:55 --> Final output sent to browser
DEBUG - 2017-06-29 04:12:55 --> Total execution time: 0.0840
ERROR - 2017-06-29 04:13:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 04:13:31 --> Config Class Initialized
INFO - 2017-06-29 04:13:31 --> Hooks Class Initialized
DEBUG - 2017-06-29 04:13:31 --> UTF-8 Support Enabled
INFO - 2017-06-29 04:13:31 --> Utf8 Class Initialized
INFO - 2017-06-29 04:13:31 --> URI Class Initialized
INFO - 2017-06-29 04:13:31 --> Router Class Initialized
INFO - 2017-06-29 04:13:31 --> Output Class Initialized
INFO - 2017-06-29 04:13:31 --> Security Class Initialized
DEBUG - 2017-06-29 04:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 04:13:31 --> Input Class Initialized
INFO - 2017-06-29 04:13:31 --> Language Class Initialized
INFO - 2017-06-29 04:13:31 --> Loader Class Initialized
INFO - 2017-06-29 04:13:31 --> Controller Class Initialized
INFO - 2017-06-29 04:13:31 --> Database Driver Class Initialized
INFO - 2017-06-29 04:13:31 --> Model Class Initialized
INFO - 2017-06-29 04:13:31 --> Helper loaded: form_helper
INFO - 2017-06-29 04:13:31 --> Helper loaded: url_helper
INFO - 2017-06-29 04:13:31 --> Model Class Initialized
INFO - 2017-06-29 04:13:31 --> Final output sent to browser
DEBUG - 2017-06-29 04:13:31 --> Total execution time: 0.0400
ERROR - 2017-06-29 04:13:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 04:13:48 --> Config Class Initialized
INFO - 2017-06-29 04:13:48 --> Hooks Class Initialized
DEBUG - 2017-06-29 04:13:48 --> UTF-8 Support Enabled
INFO - 2017-06-29 04:13:48 --> Utf8 Class Initialized
INFO - 2017-06-29 04:13:48 --> URI Class Initialized
INFO - 2017-06-29 04:13:48 --> Router Class Initialized
INFO - 2017-06-29 04:13:48 --> Output Class Initialized
INFO - 2017-06-29 04:13:48 --> Security Class Initialized
DEBUG - 2017-06-29 04:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 04:13:48 --> Input Class Initialized
INFO - 2017-06-29 04:13:48 --> Language Class Initialized
INFO - 2017-06-29 04:13:48 --> Loader Class Initialized
INFO - 2017-06-29 04:13:48 --> Controller Class Initialized
INFO - 2017-06-29 04:13:48 --> Database Driver Class Initialized
INFO - 2017-06-29 04:13:48 --> Model Class Initialized
INFO - 2017-06-29 04:13:48 --> Helper loaded: form_helper
INFO - 2017-06-29 04:13:48 --> Helper loaded: url_helper
INFO - 2017-06-29 04:13:48 --> Model Class Initialized
INFO - 2017-06-29 04:13:48 --> Final output sent to browser
DEBUG - 2017-06-29 04:13:48 --> Total execution time: 0.0560
ERROR - 2017-06-29 04:14:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 04:14:59 --> Config Class Initialized
INFO - 2017-06-29 04:14:59 --> Hooks Class Initialized
DEBUG - 2017-06-29 04:14:59 --> UTF-8 Support Enabled
INFO - 2017-06-29 04:14:59 --> Utf8 Class Initialized
INFO - 2017-06-29 04:14:59 --> URI Class Initialized
INFO - 2017-06-29 04:14:59 --> Router Class Initialized
INFO - 2017-06-29 04:14:59 --> Output Class Initialized
INFO - 2017-06-29 04:14:59 --> Security Class Initialized
DEBUG - 2017-06-29 04:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 04:14:59 --> Input Class Initialized
INFO - 2017-06-29 04:14:59 --> Language Class Initialized
INFO - 2017-06-29 04:14:59 --> Loader Class Initialized
INFO - 2017-06-29 04:14:59 --> Controller Class Initialized
INFO - 2017-06-29 04:14:59 --> Database Driver Class Initialized
INFO - 2017-06-29 04:14:59 --> Model Class Initialized
INFO - 2017-06-29 04:14:59 --> Helper loaded: form_helper
INFO - 2017-06-29 04:14:59 --> Helper loaded: url_helper
INFO - 2017-06-29 04:14:59 --> Model Class Initialized
INFO - 2017-06-29 04:14:59 --> Final output sent to browser
DEBUG - 2017-06-29 04:14:59 --> Total execution time: 0.0420
ERROR - 2017-06-29 04:15:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 04:15:05 --> Config Class Initialized
INFO - 2017-06-29 04:15:05 --> Hooks Class Initialized
DEBUG - 2017-06-29 04:15:05 --> UTF-8 Support Enabled
INFO - 2017-06-29 04:15:05 --> Utf8 Class Initialized
INFO - 2017-06-29 04:15:05 --> URI Class Initialized
INFO - 2017-06-29 04:15:05 --> Router Class Initialized
INFO - 2017-06-29 04:15:05 --> Output Class Initialized
INFO - 2017-06-29 04:15:05 --> Security Class Initialized
DEBUG - 2017-06-29 04:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 04:15:05 --> Input Class Initialized
INFO - 2017-06-29 04:15:05 --> Language Class Initialized
INFO - 2017-06-29 04:15:05 --> Loader Class Initialized
INFO - 2017-06-29 04:15:05 --> Controller Class Initialized
INFO - 2017-06-29 04:15:05 --> Database Driver Class Initialized
INFO - 2017-06-29 04:15:05 --> Model Class Initialized
INFO - 2017-06-29 04:15:05 --> Helper loaded: form_helper
INFO - 2017-06-29 04:15:05 --> Helper loaded: url_helper
INFO - 2017-06-29 04:15:05 --> Model Class Initialized
INFO - 2017-06-29 04:15:05 --> Final output sent to browser
DEBUG - 2017-06-29 04:15:05 --> Total execution time: 0.0770
ERROR - 2017-06-29 08:38:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 08:38:39 --> Config Class Initialized
INFO - 2017-06-29 08:38:39 --> Hooks Class Initialized
DEBUG - 2017-06-29 08:38:39 --> UTF-8 Support Enabled
INFO - 2017-06-29 08:38:39 --> Utf8 Class Initialized
INFO - 2017-06-29 08:38:39 --> URI Class Initialized
INFO - 2017-06-29 08:38:39 --> Router Class Initialized
INFO - 2017-06-29 08:38:39 --> Output Class Initialized
INFO - 2017-06-29 08:38:39 --> Security Class Initialized
DEBUG - 2017-06-29 08:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 08:38:39 --> Input Class Initialized
INFO - 2017-06-29 08:38:39 --> Language Class Initialized
INFO - 2017-06-29 08:38:39 --> Loader Class Initialized
INFO - 2017-06-29 08:38:39 --> Controller Class Initialized
INFO - 2017-06-29 08:38:39 --> Database Driver Class Initialized
INFO - 2017-06-29 08:38:39 --> Model Class Initialized
INFO - 2017-06-29 08:38:39 --> Helper loaded: form_helper
INFO - 2017-06-29 08:38:39 --> Helper loaded: url_helper
INFO - 2017-06-29 08:38:39 --> Model Class Initialized
INFO - 2017-06-29 08:38:39 --> Final output sent to browser
DEBUG - 2017-06-29 08:38:39 --> Total execution time: 0.0980
ERROR - 2017-06-29 08:38:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 08:38:42 --> Config Class Initialized
INFO - 2017-06-29 08:38:42 --> Hooks Class Initialized
DEBUG - 2017-06-29 08:38:42 --> UTF-8 Support Enabled
INFO - 2017-06-29 08:38:42 --> Utf8 Class Initialized
INFO - 2017-06-29 08:38:42 --> URI Class Initialized
INFO - 2017-06-29 08:38:42 --> Router Class Initialized
INFO - 2017-06-29 08:38:42 --> Output Class Initialized
INFO - 2017-06-29 08:38:42 --> Security Class Initialized
DEBUG - 2017-06-29 08:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 08:38:42 --> Input Class Initialized
INFO - 2017-06-29 08:38:42 --> Language Class Initialized
INFO - 2017-06-29 08:38:42 --> Loader Class Initialized
INFO - 2017-06-29 08:38:42 --> Controller Class Initialized
INFO - 2017-06-29 08:38:42 --> Database Driver Class Initialized
INFO - 2017-06-29 08:38:42 --> Model Class Initialized
INFO - 2017-06-29 08:38:42 --> Helper loaded: form_helper
INFO - 2017-06-29 08:38:42 --> Helper loaded: url_helper
INFO - 2017-06-29 08:38:42 --> Model Class Initialized
INFO - 2017-06-29 08:38:42 --> Final output sent to browser
DEBUG - 2017-06-29 08:38:42 --> Total execution time: 0.0480
ERROR - 2017-06-29 08:38:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 08:38:50 --> Config Class Initialized
INFO - 2017-06-29 08:38:50 --> Hooks Class Initialized
DEBUG - 2017-06-29 08:38:50 --> UTF-8 Support Enabled
INFO - 2017-06-29 08:38:50 --> Utf8 Class Initialized
INFO - 2017-06-29 08:38:50 --> URI Class Initialized
INFO - 2017-06-29 08:38:50 --> Router Class Initialized
INFO - 2017-06-29 08:38:50 --> Output Class Initialized
INFO - 2017-06-29 08:38:50 --> Security Class Initialized
DEBUG - 2017-06-29 08:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 08:38:50 --> Input Class Initialized
INFO - 2017-06-29 08:38:50 --> Language Class Initialized
INFO - 2017-06-29 08:38:50 --> Loader Class Initialized
INFO - 2017-06-29 08:38:50 --> Controller Class Initialized
INFO - 2017-06-29 08:38:50 --> Database Driver Class Initialized
INFO - 2017-06-29 08:38:50 --> Model Class Initialized
INFO - 2017-06-29 08:38:50 --> Helper loaded: form_helper
INFO - 2017-06-29 08:38:50 --> Helper loaded: url_helper
INFO - 2017-06-29 08:38:50 --> Model Class Initialized
INFO - 2017-06-29 08:38:50 --> Final output sent to browser
DEBUG - 2017-06-29 08:38:50 --> Total execution time: 0.0450
ERROR - 2017-06-29 08:39:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 08:39:00 --> Config Class Initialized
INFO - 2017-06-29 08:39:00 --> Hooks Class Initialized
DEBUG - 2017-06-29 08:39:00 --> UTF-8 Support Enabled
INFO - 2017-06-29 08:39:00 --> Utf8 Class Initialized
INFO - 2017-06-29 08:39:00 --> URI Class Initialized
INFO - 2017-06-29 08:39:00 --> Router Class Initialized
INFO - 2017-06-29 08:39:00 --> Output Class Initialized
INFO - 2017-06-29 08:39:00 --> Security Class Initialized
DEBUG - 2017-06-29 08:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 08:39:00 --> Input Class Initialized
INFO - 2017-06-29 08:39:00 --> Language Class Initialized
INFO - 2017-06-29 08:39:00 --> Loader Class Initialized
INFO - 2017-06-29 08:39:00 --> Controller Class Initialized
INFO - 2017-06-29 08:39:00 --> Database Driver Class Initialized
INFO - 2017-06-29 08:39:00 --> Model Class Initialized
INFO - 2017-06-29 08:39:00 --> Helper loaded: form_helper
INFO - 2017-06-29 08:39:00 --> Helper loaded: url_helper
INFO - 2017-06-29 08:39:00 --> Model Class Initialized
INFO - 2017-06-29 08:39:00 --> Final output sent to browser
DEBUG - 2017-06-29 08:39:00 --> Total execution time: 0.0560
ERROR - 2017-06-29 08:48:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 08:48:49 --> Config Class Initialized
INFO - 2017-06-29 08:48:49 --> Hooks Class Initialized
DEBUG - 2017-06-29 08:48:49 --> UTF-8 Support Enabled
INFO - 2017-06-29 08:48:49 --> Utf8 Class Initialized
INFO - 2017-06-29 08:48:49 --> URI Class Initialized
INFO - 2017-06-29 08:48:49 --> Router Class Initialized
INFO - 2017-06-29 08:48:49 --> Output Class Initialized
INFO - 2017-06-29 08:48:49 --> Security Class Initialized
DEBUG - 2017-06-29 08:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 08:48:49 --> Input Class Initialized
INFO - 2017-06-29 08:48:49 --> Language Class Initialized
INFO - 2017-06-29 08:48:49 --> Loader Class Initialized
INFO - 2017-06-29 08:48:49 --> Controller Class Initialized
INFO - 2017-06-29 08:48:49 --> Database Driver Class Initialized
INFO - 2017-06-29 08:48:49 --> Model Class Initialized
INFO - 2017-06-29 08:48:49 --> Helper loaded: form_helper
INFO - 2017-06-29 08:48:49 --> Helper loaded: url_helper
INFO - 2017-06-29 08:48:49 --> Model Class Initialized
INFO - 2017-06-29 08:48:49 --> Final output sent to browser
DEBUG - 2017-06-29 08:48:49 --> Total execution time: 0.1120
ERROR - 2017-06-29 08:49:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 08:49:24 --> Config Class Initialized
INFO - 2017-06-29 08:49:24 --> Hooks Class Initialized
DEBUG - 2017-06-29 08:49:24 --> UTF-8 Support Enabled
INFO - 2017-06-29 08:49:24 --> Utf8 Class Initialized
INFO - 2017-06-29 08:49:24 --> URI Class Initialized
INFO - 2017-06-29 08:49:24 --> Router Class Initialized
INFO - 2017-06-29 08:49:24 --> Output Class Initialized
INFO - 2017-06-29 08:49:24 --> Security Class Initialized
DEBUG - 2017-06-29 08:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 08:49:24 --> Input Class Initialized
INFO - 2017-06-29 08:49:24 --> Language Class Initialized
INFO - 2017-06-29 08:49:24 --> Loader Class Initialized
INFO - 2017-06-29 08:49:24 --> Controller Class Initialized
INFO - 2017-06-29 08:49:24 --> Database Driver Class Initialized
INFO - 2017-06-29 08:49:24 --> Model Class Initialized
INFO - 2017-06-29 08:49:24 --> Helper loaded: form_helper
INFO - 2017-06-29 08:49:24 --> Helper loaded: url_helper
INFO - 2017-06-29 08:49:24 --> Model Class Initialized
INFO - 2017-06-29 08:49:24 --> Final output sent to browser
DEBUG - 2017-06-29 08:49:24 --> Total execution time: 0.1180
ERROR - 2017-06-29 08:49:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 08:49:45 --> Config Class Initialized
INFO - 2017-06-29 08:49:45 --> Hooks Class Initialized
DEBUG - 2017-06-29 08:49:45 --> UTF-8 Support Enabled
INFO - 2017-06-29 08:49:45 --> Utf8 Class Initialized
INFO - 2017-06-29 08:49:45 --> URI Class Initialized
INFO - 2017-06-29 08:49:45 --> Router Class Initialized
INFO - 2017-06-29 08:49:45 --> Output Class Initialized
INFO - 2017-06-29 08:49:45 --> Security Class Initialized
DEBUG - 2017-06-29 08:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 08:49:45 --> Input Class Initialized
INFO - 2017-06-29 08:49:45 --> Language Class Initialized
INFO - 2017-06-29 08:49:45 --> Loader Class Initialized
INFO - 2017-06-29 08:49:45 --> Controller Class Initialized
INFO - 2017-06-29 08:49:45 --> Database Driver Class Initialized
INFO - 2017-06-29 08:49:45 --> Model Class Initialized
INFO - 2017-06-29 08:49:45 --> Helper loaded: form_helper
INFO - 2017-06-29 08:49:45 --> Helper loaded: url_helper
INFO - 2017-06-29 08:49:45 --> Model Class Initialized
INFO - 2017-06-29 08:49:45 --> Final output sent to browser
DEBUG - 2017-06-29 08:49:45 --> Total execution time: 0.1110
ERROR - 2017-06-29 08:49:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 08:49:49 --> Config Class Initialized
INFO - 2017-06-29 08:49:49 --> Hooks Class Initialized
DEBUG - 2017-06-29 08:49:49 --> UTF-8 Support Enabled
INFO - 2017-06-29 08:49:50 --> Utf8 Class Initialized
INFO - 2017-06-29 08:49:50 --> URI Class Initialized
INFO - 2017-06-29 08:49:50 --> Router Class Initialized
INFO - 2017-06-29 08:49:50 --> Output Class Initialized
INFO - 2017-06-29 08:49:50 --> Security Class Initialized
DEBUG - 2017-06-29 08:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 08:49:50 --> Input Class Initialized
INFO - 2017-06-29 08:49:50 --> Language Class Initialized
INFO - 2017-06-29 08:49:50 --> Loader Class Initialized
INFO - 2017-06-29 08:49:50 --> Controller Class Initialized
INFO - 2017-06-29 08:49:50 --> Database Driver Class Initialized
INFO - 2017-06-29 08:49:50 --> Model Class Initialized
INFO - 2017-06-29 08:49:50 --> Helper loaded: form_helper
INFO - 2017-06-29 08:49:50 --> Helper loaded: url_helper
INFO - 2017-06-29 08:49:50 --> Model Class Initialized
INFO - 2017-06-29 08:49:50 --> Final output sent to browser
DEBUG - 2017-06-29 08:49:50 --> Total execution time: 0.1240
ERROR - 2017-06-29 08:51:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 08:51:20 --> Config Class Initialized
INFO - 2017-06-29 08:51:20 --> Hooks Class Initialized
DEBUG - 2017-06-29 08:51:20 --> UTF-8 Support Enabled
INFO - 2017-06-29 08:51:20 --> Utf8 Class Initialized
INFO - 2017-06-29 08:51:20 --> URI Class Initialized
INFO - 2017-06-29 08:51:20 --> Router Class Initialized
INFO - 2017-06-29 08:51:20 --> Output Class Initialized
INFO - 2017-06-29 08:51:20 --> Security Class Initialized
DEBUG - 2017-06-29 08:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 08:51:20 --> Input Class Initialized
INFO - 2017-06-29 08:51:20 --> Language Class Initialized
INFO - 2017-06-29 08:51:20 --> Loader Class Initialized
INFO - 2017-06-29 08:51:20 --> Controller Class Initialized
INFO - 2017-06-29 08:51:20 --> Database Driver Class Initialized
INFO - 2017-06-29 08:51:20 --> Model Class Initialized
INFO - 2017-06-29 08:51:20 --> Helper loaded: form_helper
INFO - 2017-06-29 08:51:20 --> Helper loaded: url_helper
INFO - 2017-06-29 08:51:20 --> Model Class Initialized
INFO - 2017-06-29 08:51:20 --> Final output sent to browser
DEBUG - 2017-06-29 08:51:20 --> Total execution time: 0.0580
ERROR - 2017-06-29 08:53:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 08:53:04 --> Config Class Initialized
INFO - 2017-06-29 08:53:04 --> Hooks Class Initialized
DEBUG - 2017-06-29 08:53:04 --> UTF-8 Support Enabled
INFO - 2017-06-29 08:53:04 --> Utf8 Class Initialized
INFO - 2017-06-29 08:53:04 --> URI Class Initialized
INFO - 2017-06-29 08:53:04 --> Router Class Initialized
INFO - 2017-06-29 08:53:04 --> Output Class Initialized
INFO - 2017-06-29 08:53:04 --> Security Class Initialized
DEBUG - 2017-06-29 08:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 08:53:04 --> Input Class Initialized
INFO - 2017-06-29 08:53:04 --> Language Class Initialized
INFO - 2017-06-29 08:53:04 --> Loader Class Initialized
INFO - 2017-06-29 08:53:04 --> Controller Class Initialized
INFO - 2017-06-29 08:53:04 --> Database Driver Class Initialized
INFO - 2017-06-29 08:53:04 --> Model Class Initialized
INFO - 2017-06-29 08:53:04 --> Helper loaded: form_helper
INFO - 2017-06-29 08:53:04 --> Helper loaded: url_helper
INFO - 2017-06-29 08:53:04 --> Model Class Initialized
INFO - 2017-06-29 08:53:04 --> Final output sent to browser
DEBUG - 2017-06-29 08:53:04 --> Total execution time: 0.1250
ERROR - 2017-06-29 08:53:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 08:53:27 --> Config Class Initialized
INFO - 2017-06-29 08:53:27 --> Hooks Class Initialized
DEBUG - 2017-06-29 08:53:27 --> UTF-8 Support Enabled
INFO - 2017-06-29 08:53:27 --> Utf8 Class Initialized
INFO - 2017-06-29 08:53:27 --> URI Class Initialized
INFO - 2017-06-29 08:53:27 --> Router Class Initialized
INFO - 2017-06-29 08:53:27 --> Output Class Initialized
INFO - 2017-06-29 08:53:27 --> Security Class Initialized
DEBUG - 2017-06-29 08:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 08:53:27 --> Input Class Initialized
INFO - 2017-06-29 08:53:27 --> Language Class Initialized
INFO - 2017-06-29 08:53:27 --> Loader Class Initialized
INFO - 2017-06-29 08:53:27 --> Controller Class Initialized
INFO - 2017-06-29 08:53:27 --> Database Driver Class Initialized
INFO - 2017-06-29 08:53:27 --> Model Class Initialized
INFO - 2017-06-29 08:53:27 --> Helper loaded: form_helper
INFO - 2017-06-29 08:53:27 --> Helper loaded: url_helper
INFO - 2017-06-29 08:53:27 --> Model Class Initialized
INFO - 2017-06-29 08:53:27 --> Final output sent to browser
DEBUG - 2017-06-29 08:53:27 --> Total execution time: 0.0970
ERROR - 2017-06-29 08:53:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 08:53:28 --> Config Class Initialized
INFO - 2017-06-29 08:53:28 --> Hooks Class Initialized
DEBUG - 2017-06-29 08:53:28 --> UTF-8 Support Enabled
INFO - 2017-06-29 08:53:28 --> Utf8 Class Initialized
INFO - 2017-06-29 08:53:28 --> URI Class Initialized
INFO - 2017-06-29 08:53:28 --> Router Class Initialized
INFO - 2017-06-29 08:53:28 --> Output Class Initialized
INFO - 2017-06-29 08:53:28 --> Security Class Initialized
DEBUG - 2017-06-29 08:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 08:53:28 --> Input Class Initialized
INFO - 2017-06-29 08:53:28 --> Language Class Initialized
INFO - 2017-06-29 08:53:28 --> Loader Class Initialized
INFO - 2017-06-29 08:53:28 --> Controller Class Initialized
INFO - 2017-06-29 08:53:28 --> Database Driver Class Initialized
INFO - 2017-06-29 08:53:28 --> Model Class Initialized
INFO - 2017-06-29 08:53:28 --> Helper loaded: form_helper
INFO - 2017-06-29 08:53:28 --> Helper loaded: url_helper
INFO - 2017-06-29 08:53:28 --> Model Class Initialized
INFO - 2017-06-29 08:53:28 --> Final output sent to browser
DEBUG - 2017-06-29 08:53:28 --> Total execution time: 0.1220
ERROR - 2017-06-29 08:53:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 08:53:35 --> Config Class Initialized
INFO - 2017-06-29 08:53:35 --> Hooks Class Initialized
DEBUG - 2017-06-29 08:53:35 --> UTF-8 Support Enabled
INFO - 2017-06-29 08:53:35 --> Utf8 Class Initialized
INFO - 2017-06-29 08:53:35 --> URI Class Initialized
INFO - 2017-06-29 08:53:35 --> Router Class Initialized
INFO - 2017-06-29 08:53:35 --> Output Class Initialized
INFO - 2017-06-29 08:53:35 --> Security Class Initialized
DEBUG - 2017-06-29 08:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 08:53:35 --> Input Class Initialized
INFO - 2017-06-29 08:53:35 --> Language Class Initialized
INFO - 2017-06-29 08:53:35 --> Loader Class Initialized
INFO - 2017-06-29 08:53:35 --> Controller Class Initialized
INFO - 2017-06-29 08:53:35 --> Database Driver Class Initialized
INFO - 2017-06-29 08:53:35 --> Model Class Initialized
INFO - 2017-06-29 08:53:35 --> Helper loaded: form_helper
INFO - 2017-06-29 08:53:35 --> Helper loaded: url_helper
INFO - 2017-06-29 08:53:35 --> Model Class Initialized
INFO - 2017-06-29 08:53:35 --> Final output sent to browser
DEBUG - 2017-06-29 08:53:35 --> Total execution time: 0.1110
ERROR - 2017-06-29 08:56:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 08:56:58 --> Config Class Initialized
INFO - 2017-06-29 08:56:58 --> Hooks Class Initialized
DEBUG - 2017-06-29 08:56:58 --> UTF-8 Support Enabled
INFO - 2017-06-29 08:56:58 --> Utf8 Class Initialized
INFO - 2017-06-29 08:56:58 --> URI Class Initialized
INFO - 2017-06-29 08:56:58 --> Router Class Initialized
INFO - 2017-06-29 08:56:58 --> Output Class Initialized
INFO - 2017-06-29 08:56:58 --> Security Class Initialized
DEBUG - 2017-06-29 08:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 08:56:58 --> Input Class Initialized
INFO - 2017-06-29 08:56:58 --> Language Class Initialized
INFO - 2017-06-29 08:56:58 --> Loader Class Initialized
INFO - 2017-06-29 08:56:58 --> Controller Class Initialized
INFO - 2017-06-29 08:56:58 --> Database Driver Class Initialized
INFO - 2017-06-29 08:56:58 --> Model Class Initialized
INFO - 2017-06-29 08:56:58 --> Helper loaded: form_helper
INFO - 2017-06-29 08:56:58 --> Helper loaded: url_helper
INFO - 2017-06-29 08:56:58 --> Model Class Initialized
INFO - 2017-06-29 08:56:58 --> Final output sent to browser
DEBUG - 2017-06-29 08:56:58 --> Total execution time: 0.3490
ERROR - 2017-06-29 08:57:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 08:57:38 --> Config Class Initialized
INFO - 2017-06-29 08:57:38 --> Hooks Class Initialized
DEBUG - 2017-06-29 08:57:38 --> UTF-8 Support Enabled
INFO - 2017-06-29 08:57:38 --> Utf8 Class Initialized
INFO - 2017-06-29 08:57:38 --> URI Class Initialized
INFO - 2017-06-29 08:57:38 --> Router Class Initialized
INFO - 2017-06-29 08:57:38 --> Output Class Initialized
INFO - 2017-06-29 08:57:38 --> Security Class Initialized
DEBUG - 2017-06-29 08:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 08:57:38 --> Input Class Initialized
INFO - 2017-06-29 08:57:38 --> Language Class Initialized
INFO - 2017-06-29 08:57:38 --> Loader Class Initialized
INFO - 2017-06-29 08:57:38 --> Controller Class Initialized
INFO - 2017-06-29 08:57:38 --> Database Driver Class Initialized
INFO - 2017-06-29 08:57:38 --> Model Class Initialized
INFO - 2017-06-29 08:57:38 --> Helper loaded: form_helper
INFO - 2017-06-29 08:57:38 --> Helper loaded: url_helper
INFO - 2017-06-29 08:57:38 --> Model Class Initialized
INFO - 2017-06-29 08:57:38 --> Final output sent to browser
DEBUG - 2017-06-29 08:57:38 --> Total execution time: 0.0760
ERROR - 2017-06-29 08:57:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 08:57:39 --> Config Class Initialized
INFO - 2017-06-29 08:57:39 --> Hooks Class Initialized
DEBUG - 2017-06-29 08:57:39 --> UTF-8 Support Enabled
INFO - 2017-06-29 08:57:39 --> Utf8 Class Initialized
INFO - 2017-06-29 08:57:39 --> URI Class Initialized
INFO - 2017-06-29 08:57:39 --> Router Class Initialized
INFO - 2017-06-29 08:57:39 --> Output Class Initialized
INFO - 2017-06-29 08:57:39 --> Security Class Initialized
DEBUG - 2017-06-29 08:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 08:57:39 --> Input Class Initialized
INFO - 2017-06-29 08:57:39 --> Language Class Initialized
INFO - 2017-06-29 08:57:39 --> Loader Class Initialized
INFO - 2017-06-29 08:57:39 --> Controller Class Initialized
INFO - 2017-06-29 08:57:39 --> Database Driver Class Initialized
INFO - 2017-06-29 08:57:39 --> Model Class Initialized
INFO - 2017-06-29 08:57:39 --> Helper loaded: form_helper
INFO - 2017-06-29 08:57:39 --> Helper loaded: url_helper
INFO - 2017-06-29 08:57:39 --> Model Class Initialized
INFO - 2017-06-29 08:57:39 --> Final output sent to browser
DEBUG - 2017-06-29 08:57:39 --> Total execution time: 0.0490
ERROR - 2017-06-29 08:59:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 08:59:30 --> Config Class Initialized
INFO - 2017-06-29 08:59:30 --> Hooks Class Initialized
DEBUG - 2017-06-29 08:59:30 --> UTF-8 Support Enabled
INFO - 2017-06-29 08:59:30 --> Utf8 Class Initialized
INFO - 2017-06-29 08:59:30 --> URI Class Initialized
INFO - 2017-06-29 08:59:30 --> Router Class Initialized
INFO - 2017-06-29 08:59:30 --> Output Class Initialized
INFO - 2017-06-29 08:59:30 --> Security Class Initialized
DEBUG - 2017-06-29 08:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 08:59:30 --> Input Class Initialized
INFO - 2017-06-29 08:59:30 --> Language Class Initialized
INFO - 2017-06-29 08:59:30 --> Loader Class Initialized
INFO - 2017-06-29 08:59:30 --> Controller Class Initialized
INFO - 2017-06-29 08:59:30 --> Database Driver Class Initialized
INFO - 2017-06-29 08:59:30 --> Model Class Initialized
INFO - 2017-06-29 08:59:30 --> Helper loaded: form_helper
INFO - 2017-06-29 08:59:30 --> Helper loaded: url_helper
INFO - 2017-06-29 08:59:30 --> Model Class Initialized
INFO - 2017-06-29 08:59:30 --> Final output sent to browser
DEBUG - 2017-06-29 08:59:30 --> Total execution time: 0.1080
ERROR - 2017-06-29 08:59:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 08:59:33 --> Config Class Initialized
INFO - 2017-06-29 08:59:33 --> Hooks Class Initialized
DEBUG - 2017-06-29 08:59:33 --> UTF-8 Support Enabled
INFO - 2017-06-29 08:59:33 --> Utf8 Class Initialized
INFO - 2017-06-29 08:59:33 --> URI Class Initialized
INFO - 2017-06-29 08:59:33 --> Router Class Initialized
INFO - 2017-06-29 08:59:33 --> Output Class Initialized
INFO - 2017-06-29 08:59:33 --> Security Class Initialized
DEBUG - 2017-06-29 08:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 08:59:33 --> Input Class Initialized
INFO - 2017-06-29 08:59:33 --> Language Class Initialized
INFO - 2017-06-29 08:59:33 --> Loader Class Initialized
INFO - 2017-06-29 08:59:33 --> Controller Class Initialized
INFO - 2017-06-29 08:59:33 --> Database Driver Class Initialized
INFO - 2017-06-29 08:59:33 --> Model Class Initialized
INFO - 2017-06-29 08:59:33 --> Helper loaded: form_helper
INFO - 2017-06-29 08:59:33 --> Helper loaded: url_helper
INFO - 2017-06-29 08:59:33 --> Model Class Initialized
INFO - 2017-06-29 08:59:33 --> Final output sent to browser
DEBUG - 2017-06-29 08:59:33 --> Total execution time: 0.1360
ERROR - 2017-06-29 09:00:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 09:00:15 --> Config Class Initialized
INFO - 2017-06-29 09:00:15 --> Hooks Class Initialized
DEBUG - 2017-06-29 09:00:15 --> UTF-8 Support Enabled
INFO - 2017-06-29 09:00:15 --> Utf8 Class Initialized
INFO - 2017-06-29 09:00:15 --> URI Class Initialized
INFO - 2017-06-29 09:00:15 --> Router Class Initialized
INFO - 2017-06-29 09:00:15 --> Output Class Initialized
INFO - 2017-06-29 09:00:15 --> Security Class Initialized
DEBUG - 2017-06-29 09:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 09:00:15 --> Input Class Initialized
INFO - 2017-06-29 09:00:15 --> Language Class Initialized
INFO - 2017-06-29 09:00:15 --> Loader Class Initialized
INFO - 2017-06-29 09:00:15 --> Controller Class Initialized
INFO - 2017-06-29 09:00:15 --> Database Driver Class Initialized
INFO - 2017-06-29 09:00:15 --> Model Class Initialized
INFO - 2017-06-29 09:00:15 --> Helper loaded: form_helper
INFO - 2017-06-29 09:00:15 --> Helper loaded: url_helper
INFO - 2017-06-29 09:00:15 --> Model Class Initialized
INFO - 2017-06-29 09:00:15 --> Final output sent to browser
DEBUG - 2017-06-29 09:00:15 --> Total execution time: 0.4510
ERROR - 2017-06-29 09:00:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 09:00:17 --> Config Class Initialized
INFO - 2017-06-29 09:00:17 --> Hooks Class Initialized
DEBUG - 2017-06-29 09:00:17 --> UTF-8 Support Enabled
INFO - 2017-06-29 09:00:17 --> Utf8 Class Initialized
INFO - 2017-06-29 09:00:17 --> URI Class Initialized
INFO - 2017-06-29 09:00:17 --> Router Class Initialized
INFO - 2017-06-29 09:00:17 --> Output Class Initialized
INFO - 2017-06-29 09:00:17 --> Security Class Initialized
DEBUG - 2017-06-29 09:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 09:00:17 --> Input Class Initialized
INFO - 2017-06-29 09:00:17 --> Language Class Initialized
INFO - 2017-06-29 09:00:17 --> Loader Class Initialized
INFO - 2017-06-29 09:00:17 --> Controller Class Initialized
INFO - 2017-06-29 09:00:17 --> Database Driver Class Initialized
INFO - 2017-06-29 09:00:17 --> Model Class Initialized
INFO - 2017-06-29 09:00:17 --> Helper loaded: form_helper
INFO - 2017-06-29 09:00:17 --> Helper loaded: url_helper
INFO - 2017-06-29 09:00:17 --> Model Class Initialized
INFO - 2017-06-29 09:00:17 --> Final output sent to browser
DEBUG - 2017-06-29 09:00:17 --> Total execution time: 0.1020
ERROR - 2017-06-29 09:02:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 09:02:23 --> Config Class Initialized
INFO - 2017-06-29 09:02:23 --> Hooks Class Initialized
DEBUG - 2017-06-29 09:02:23 --> UTF-8 Support Enabled
INFO - 2017-06-29 09:02:23 --> Utf8 Class Initialized
INFO - 2017-06-29 09:02:23 --> URI Class Initialized
INFO - 2017-06-29 09:02:23 --> Router Class Initialized
INFO - 2017-06-29 09:02:23 --> Output Class Initialized
INFO - 2017-06-29 09:02:23 --> Security Class Initialized
DEBUG - 2017-06-29 09:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 09:02:23 --> Input Class Initialized
INFO - 2017-06-29 09:02:23 --> Language Class Initialized
INFO - 2017-06-29 09:02:23 --> Loader Class Initialized
INFO - 2017-06-29 09:02:23 --> Controller Class Initialized
INFO - 2017-06-29 09:02:23 --> Database Driver Class Initialized
INFO - 2017-06-29 09:02:23 --> Model Class Initialized
INFO - 2017-06-29 09:02:23 --> Helper loaded: form_helper
INFO - 2017-06-29 09:02:23 --> Helper loaded: url_helper
INFO - 2017-06-29 09:02:23 --> Model Class Initialized
INFO - 2017-06-29 09:02:23 --> Final output sent to browser
DEBUG - 2017-06-29 09:02:23 --> Total execution time: 0.0570
ERROR - 2017-06-29 09:03:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 09:03:21 --> Config Class Initialized
INFO - 2017-06-29 09:03:21 --> Hooks Class Initialized
DEBUG - 2017-06-29 09:03:21 --> UTF-8 Support Enabled
INFO - 2017-06-29 09:03:21 --> Utf8 Class Initialized
INFO - 2017-06-29 09:03:21 --> URI Class Initialized
INFO - 2017-06-29 09:03:21 --> Router Class Initialized
INFO - 2017-06-29 09:03:21 --> Output Class Initialized
INFO - 2017-06-29 09:03:21 --> Security Class Initialized
DEBUG - 2017-06-29 09:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 09:03:21 --> Input Class Initialized
INFO - 2017-06-29 09:03:21 --> Language Class Initialized
INFO - 2017-06-29 09:03:21 --> Loader Class Initialized
INFO - 2017-06-29 09:03:21 --> Controller Class Initialized
INFO - 2017-06-29 09:03:21 --> Database Driver Class Initialized
INFO - 2017-06-29 09:03:21 --> Model Class Initialized
INFO - 2017-06-29 09:03:21 --> Helper loaded: form_helper
INFO - 2017-06-29 09:03:21 --> Helper loaded: url_helper
INFO - 2017-06-29 09:03:21 --> Model Class Initialized
INFO - 2017-06-29 09:03:21 --> Final output sent to browser
DEBUG - 2017-06-29 09:03:21 --> Total execution time: 0.0580
ERROR - 2017-06-29 09:04:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 09:04:02 --> Config Class Initialized
INFO - 2017-06-29 09:04:02 --> Hooks Class Initialized
DEBUG - 2017-06-29 09:04:02 --> UTF-8 Support Enabled
INFO - 2017-06-29 09:04:02 --> Utf8 Class Initialized
INFO - 2017-06-29 09:04:02 --> URI Class Initialized
INFO - 2017-06-29 09:04:02 --> Router Class Initialized
INFO - 2017-06-29 09:04:02 --> Output Class Initialized
INFO - 2017-06-29 09:04:02 --> Security Class Initialized
DEBUG - 2017-06-29 09:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 09:04:02 --> Input Class Initialized
INFO - 2017-06-29 09:04:02 --> Language Class Initialized
INFO - 2017-06-29 09:04:02 --> Loader Class Initialized
INFO - 2017-06-29 09:04:02 --> Controller Class Initialized
INFO - 2017-06-29 09:04:02 --> Database Driver Class Initialized
INFO - 2017-06-29 09:04:02 --> Model Class Initialized
INFO - 2017-06-29 09:04:02 --> Helper loaded: form_helper
INFO - 2017-06-29 09:04:02 --> Helper loaded: url_helper
INFO - 2017-06-29 09:04:02 --> Model Class Initialized
INFO - 2017-06-29 09:04:02 --> Final output sent to browser
DEBUG - 2017-06-29 09:04:02 --> Total execution time: 0.0480
ERROR - 2017-06-29 09:05:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 09:05:02 --> Config Class Initialized
INFO - 2017-06-29 09:05:02 --> Hooks Class Initialized
DEBUG - 2017-06-29 09:05:02 --> UTF-8 Support Enabled
INFO - 2017-06-29 09:05:02 --> Utf8 Class Initialized
INFO - 2017-06-29 09:05:02 --> URI Class Initialized
INFO - 2017-06-29 09:05:03 --> Router Class Initialized
INFO - 2017-06-29 09:05:03 --> Output Class Initialized
INFO - 2017-06-29 09:05:03 --> Security Class Initialized
DEBUG - 2017-06-29 09:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 09:05:03 --> Input Class Initialized
INFO - 2017-06-29 09:05:03 --> Language Class Initialized
INFO - 2017-06-29 09:05:03 --> Loader Class Initialized
INFO - 2017-06-29 09:05:03 --> Controller Class Initialized
INFO - 2017-06-29 09:05:03 --> Database Driver Class Initialized
INFO - 2017-06-29 09:05:03 --> Model Class Initialized
INFO - 2017-06-29 09:05:03 --> Helper loaded: form_helper
INFO - 2017-06-29 09:05:03 --> Helper loaded: url_helper
INFO - 2017-06-29 09:05:03 --> Model Class Initialized
INFO - 2017-06-29 09:05:03 --> Final output sent to browser
DEBUG - 2017-06-29 09:05:03 --> Total execution time: 0.0490
ERROR - 2017-06-29 09:06:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 09:06:13 --> Config Class Initialized
INFO - 2017-06-29 09:06:13 --> Hooks Class Initialized
DEBUG - 2017-06-29 09:06:13 --> UTF-8 Support Enabled
INFO - 2017-06-29 09:06:13 --> Utf8 Class Initialized
INFO - 2017-06-29 09:06:13 --> URI Class Initialized
INFO - 2017-06-29 09:06:13 --> Router Class Initialized
INFO - 2017-06-29 09:06:13 --> Output Class Initialized
INFO - 2017-06-29 09:06:13 --> Security Class Initialized
DEBUG - 2017-06-29 09:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 09:06:13 --> Input Class Initialized
INFO - 2017-06-29 09:06:13 --> Language Class Initialized
INFO - 2017-06-29 09:06:13 --> Loader Class Initialized
INFO - 2017-06-29 09:06:13 --> Controller Class Initialized
INFO - 2017-06-29 09:06:13 --> Database Driver Class Initialized
INFO - 2017-06-29 09:06:13 --> Model Class Initialized
INFO - 2017-06-29 09:06:13 --> Helper loaded: form_helper
INFO - 2017-06-29 09:06:13 --> Helper loaded: url_helper
INFO - 2017-06-29 09:06:13 --> Model Class Initialized
INFO - 2017-06-29 09:06:13 --> Final output sent to browser
DEBUG - 2017-06-29 09:06:13 --> Total execution time: 0.0490
ERROR - 2017-06-29 09:07:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 09:07:02 --> Config Class Initialized
INFO - 2017-06-29 09:07:02 --> Hooks Class Initialized
DEBUG - 2017-06-29 09:07:02 --> UTF-8 Support Enabled
INFO - 2017-06-29 09:07:02 --> Utf8 Class Initialized
INFO - 2017-06-29 09:07:02 --> URI Class Initialized
INFO - 2017-06-29 09:07:02 --> Router Class Initialized
INFO - 2017-06-29 09:07:02 --> Output Class Initialized
INFO - 2017-06-29 09:07:02 --> Security Class Initialized
DEBUG - 2017-06-29 09:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 09:07:02 --> Input Class Initialized
INFO - 2017-06-29 09:07:02 --> Language Class Initialized
INFO - 2017-06-29 09:07:02 --> Loader Class Initialized
INFO - 2017-06-29 09:07:02 --> Controller Class Initialized
INFO - 2017-06-29 09:07:02 --> Database Driver Class Initialized
INFO - 2017-06-29 09:07:02 --> Model Class Initialized
INFO - 2017-06-29 09:07:02 --> Helper loaded: form_helper
INFO - 2017-06-29 09:07:02 --> Helper loaded: url_helper
INFO - 2017-06-29 09:07:02 --> Model Class Initialized
INFO - 2017-06-29 09:07:02 --> Final output sent to browser
DEBUG - 2017-06-29 09:07:02 --> Total execution time: 0.0480
ERROR - 2017-06-29 09:09:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 09:09:14 --> Config Class Initialized
INFO - 2017-06-29 09:09:14 --> Hooks Class Initialized
DEBUG - 2017-06-29 09:09:14 --> UTF-8 Support Enabled
INFO - 2017-06-29 09:09:14 --> Utf8 Class Initialized
INFO - 2017-06-29 09:09:14 --> URI Class Initialized
INFO - 2017-06-29 09:09:14 --> Router Class Initialized
INFO - 2017-06-29 09:09:14 --> Output Class Initialized
INFO - 2017-06-29 09:09:14 --> Security Class Initialized
DEBUG - 2017-06-29 09:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 09:09:14 --> Input Class Initialized
INFO - 2017-06-29 09:09:14 --> Language Class Initialized
INFO - 2017-06-29 09:09:14 --> Loader Class Initialized
INFO - 2017-06-29 09:09:14 --> Controller Class Initialized
INFO - 2017-06-29 09:09:14 --> Database Driver Class Initialized
INFO - 2017-06-29 09:09:14 --> Model Class Initialized
INFO - 2017-06-29 09:09:14 --> Helper loaded: form_helper
INFO - 2017-06-29 09:09:14 --> Helper loaded: url_helper
INFO - 2017-06-29 09:09:14 --> Model Class Initialized
INFO - 2017-06-29 09:09:14 --> Final output sent to browser
DEBUG - 2017-06-29 09:09:14 --> Total execution time: 0.0640
ERROR - 2017-06-29 09:10:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 09:10:13 --> Config Class Initialized
INFO - 2017-06-29 09:10:13 --> Hooks Class Initialized
DEBUG - 2017-06-29 09:10:13 --> UTF-8 Support Enabled
INFO - 2017-06-29 09:10:13 --> Utf8 Class Initialized
INFO - 2017-06-29 09:10:13 --> URI Class Initialized
INFO - 2017-06-29 09:10:13 --> Router Class Initialized
INFO - 2017-06-29 09:10:13 --> Output Class Initialized
INFO - 2017-06-29 09:10:13 --> Security Class Initialized
DEBUG - 2017-06-29 09:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 09:10:13 --> Input Class Initialized
INFO - 2017-06-29 09:10:13 --> Language Class Initialized
INFO - 2017-06-29 09:10:13 --> Loader Class Initialized
INFO - 2017-06-29 09:10:13 --> Controller Class Initialized
INFO - 2017-06-29 09:10:13 --> Database Driver Class Initialized
INFO - 2017-06-29 09:10:13 --> Model Class Initialized
INFO - 2017-06-29 09:10:13 --> Helper loaded: form_helper
INFO - 2017-06-29 09:10:13 --> Helper loaded: url_helper
INFO - 2017-06-29 09:10:13 --> Model Class Initialized
INFO - 2017-06-29 09:10:13 --> Final output sent to browser
DEBUG - 2017-06-29 09:10:13 --> Total execution time: 0.0650
ERROR - 2017-06-29 09:11:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 09:11:07 --> Config Class Initialized
INFO - 2017-06-29 09:11:07 --> Hooks Class Initialized
DEBUG - 2017-06-29 09:11:07 --> UTF-8 Support Enabled
INFO - 2017-06-29 09:11:07 --> Utf8 Class Initialized
INFO - 2017-06-29 09:11:07 --> URI Class Initialized
INFO - 2017-06-29 09:11:07 --> Router Class Initialized
INFO - 2017-06-29 09:11:07 --> Output Class Initialized
INFO - 2017-06-29 09:11:07 --> Security Class Initialized
DEBUG - 2017-06-29 09:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 09:11:07 --> Input Class Initialized
INFO - 2017-06-29 09:11:07 --> Language Class Initialized
INFO - 2017-06-29 09:11:07 --> Loader Class Initialized
INFO - 2017-06-29 09:11:07 --> Controller Class Initialized
INFO - 2017-06-29 09:11:07 --> Database Driver Class Initialized
INFO - 2017-06-29 09:11:07 --> Model Class Initialized
INFO - 2017-06-29 09:11:07 --> Helper loaded: form_helper
INFO - 2017-06-29 09:11:07 --> Helper loaded: url_helper
INFO - 2017-06-29 09:11:07 --> Model Class Initialized
INFO - 2017-06-29 09:11:07 --> Final output sent to browser
DEBUG - 2017-06-29 09:11:07 --> Total execution time: 0.0840
ERROR - 2017-06-29 09:13:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 09:13:22 --> Config Class Initialized
INFO - 2017-06-29 09:13:22 --> Hooks Class Initialized
DEBUG - 2017-06-29 09:13:22 --> UTF-8 Support Enabled
INFO - 2017-06-29 09:13:22 --> Utf8 Class Initialized
INFO - 2017-06-29 09:13:22 --> URI Class Initialized
INFO - 2017-06-29 09:13:22 --> Router Class Initialized
INFO - 2017-06-29 09:13:22 --> Output Class Initialized
INFO - 2017-06-29 09:13:22 --> Security Class Initialized
DEBUG - 2017-06-29 09:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 09:13:22 --> Input Class Initialized
INFO - 2017-06-29 09:13:22 --> Language Class Initialized
INFO - 2017-06-29 09:13:22 --> Loader Class Initialized
INFO - 2017-06-29 09:13:22 --> Controller Class Initialized
INFO - 2017-06-29 09:13:22 --> Database Driver Class Initialized
INFO - 2017-06-29 09:13:22 --> Model Class Initialized
INFO - 2017-06-29 09:13:22 --> Helper loaded: form_helper
INFO - 2017-06-29 09:13:22 --> Helper loaded: url_helper
INFO - 2017-06-29 09:13:22 --> Model Class Initialized
INFO - 2017-06-29 09:13:22 --> Final output sent to browser
DEBUG - 2017-06-29 09:13:22 --> Total execution time: 0.0710
ERROR - 2017-06-29 09:15:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 09:15:59 --> Config Class Initialized
INFO - 2017-06-29 09:15:59 --> Hooks Class Initialized
DEBUG - 2017-06-29 09:15:59 --> UTF-8 Support Enabled
INFO - 2017-06-29 09:15:59 --> Utf8 Class Initialized
INFO - 2017-06-29 09:15:59 --> URI Class Initialized
INFO - 2017-06-29 09:15:59 --> Router Class Initialized
INFO - 2017-06-29 09:15:59 --> Output Class Initialized
INFO - 2017-06-29 09:15:59 --> Security Class Initialized
DEBUG - 2017-06-29 09:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 09:15:59 --> Input Class Initialized
INFO - 2017-06-29 09:15:59 --> Language Class Initialized
INFO - 2017-06-29 09:15:59 --> Loader Class Initialized
INFO - 2017-06-29 09:15:59 --> Controller Class Initialized
INFO - 2017-06-29 09:15:59 --> Database Driver Class Initialized
INFO - 2017-06-29 09:15:59 --> Model Class Initialized
INFO - 2017-06-29 09:15:59 --> Helper loaded: form_helper
INFO - 2017-06-29 09:15:59 --> Helper loaded: url_helper
INFO - 2017-06-29 09:15:59 --> Model Class Initialized
INFO - 2017-06-29 09:15:59 --> Final output sent to browser
DEBUG - 2017-06-29 09:15:59 --> Total execution time: 0.0630
ERROR - 2017-06-29 09:16:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 09:16:53 --> Config Class Initialized
INFO - 2017-06-29 09:16:53 --> Hooks Class Initialized
DEBUG - 2017-06-29 09:16:53 --> UTF-8 Support Enabled
INFO - 2017-06-29 09:16:53 --> Utf8 Class Initialized
INFO - 2017-06-29 09:16:53 --> URI Class Initialized
INFO - 2017-06-29 09:16:53 --> Router Class Initialized
INFO - 2017-06-29 09:16:53 --> Output Class Initialized
INFO - 2017-06-29 09:16:53 --> Security Class Initialized
DEBUG - 2017-06-29 09:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 09:16:53 --> Input Class Initialized
INFO - 2017-06-29 09:16:53 --> Language Class Initialized
INFO - 2017-06-29 09:16:53 --> Loader Class Initialized
INFO - 2017-06-29 09:16:53 --> Controller Class Initialized
INFO - 2017-06-29 09:16:53 --> Database Driver Class Initialized
INFO - 2017-06-29 09:16:53 --> Model Class Initialized
INFO - 2017-06-29 09:16:53 --> Helper loaded: form_helper
INFO - 2017-06-29 09:16:53 --> Helper loaded: url_helper
INFO - 2017-06-29 09:16:53 --> Model Class Initialized
INFO - 2017-06-29 09:16:53 --> Final output sent to browser
DEBUG - 2017-06-29 09:16:53 --> Total execution time: 0.0730
ERROR - 2017-06-29 09:18:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 09:18:29 --> Config Class Initialized
INFO - 2017-06-29 09:18:29 --> Hooks Class Initialized
DEBUG - 2017-06-29 09:18:29 --> UTF-8 Support Enabled
INFO - 2017-06-29 09:18:29 --> Utf8 Class Initialized
INFO - 2017-06-29 09:18:29 --> URI Class Initialized
INFO - 2017-06-29 09:18:29 --> Router Class Initialized
INFO - 2017-06-29 09:18:29 --> Output Class Initialized
INFO - 2017-06-29 09:18:29 --> Security Class Initialized
DEBUG - 2017-06-29 09:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 09:18:29 --> Input Class Initialized
INFO - 2017-06-29 09:18:29 --> Language Class Initialized
INFO - 2017-06-29 09:18:29 --> Loader Class Initialized
INFO - 2017-06-29 09:18:29 --> Controller Class Initialized
INFO - 2017-06-29 09:18:29 --> Database Driver Class Initialized
INFO - 2017-06-29 09:18:29 --> Model Class Initialized
INFO - 2017-06-29 09:18:29 --> Helper loaded: form_helper
INFO - 2017-06-29 09:18:29 --> Helper loaded: url_helper
INFO - 2017-06-29 09:18:29 --> Model Class Initialized
INFO - 2017-06-29 09:18:29 --> Final output sent to browser
DEBUG - 2017-06-29 09:18:29 --> Total execution time: 0.0750
ERROR - 2017-06-29 09:24:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 09:24:14 --> Config Class Initialized
INFO - 2017-06-29 09:24:14 --> Hooks Class Initialized
DEBUG - 2017-06-29 09:24:14 --> UTF-8 Support Enabled
INFO - 2017-06-29 09:24:14 --> Utf8 Class Initialized
INFO - 2017-06-29 09:24:14 --> URI Class Initialized
INFO - 2017-06-29 09:24:14 --> Router Class Initialized
INFO - 2017-06-29 09:24:14 --> Output Class Initialized
INFO - 2017-06-29 09:24:14 --> Security Class Initialized
DEBUG - 2017-06-29 09:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 09:24:14 --> Input Class Initialized
INFO - 2017-06-29 09:24:14 --> Language Class Initialized
INFO - 2017-06-29 09:24:14 --> Loader Class Initialized
INFO - 2017-06-29 09:24:14 --> Controller Class Initialized
INFO - 2017-06-29 09:24:14 --> Database Driver Class Initialized
INFO - 2017-06-29 09:24:14 --> Model Class Initialized
INFO - 2017-06-29 09:24:14 --> Helper loaded: form_helper
INFO - 2017-06-29 09:24:14 --> Helper loaded: url_helper
INFO - 2017-06-29 09:24:14 --> Model Class Initialized
INFO - 2017-06-29 09:24:14 --> Final output sent to browser
DEBUG - 2017-06-29 09:24:14 --> Total execution time: 0.1840
ERROR - 2017-06-29 09:24:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 09:24:44 --> Config Class Initialized
INFO - 2017-06-29 09:24:44 --> Hooks Class Initialized
DEBUG - 2017-06-29 09:24:44 --> UTF-8 Support Enabled
INFO - 2017-06-29 09:24:44 --> Utf8 Class Initialized
INFO - 2017-06-29 09:24:44 --> URI Class Initialized
INFO - 2017-06-29 09:24:44 --> Router Class Initialized
INFO - 2017-06-29 09:24:44 --> Output Class Initialized
INFO - 2017-06-29 09:24:44 --> Security Class Initialized
DEBUG - 2017-06-29 09:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 09:24:44 --> Input Class Initialized
INFO - 2017-06-29 09:24:44 --> Language Class Initialized
INFO - 2017-06-29 09:24:44 --> Loader Class Initialized
INFO - 2017-06-29 09:24:44 --> Controller Class Initialized
INFO - 2017-06-29 09:24:44 --> Database Driver Class Initialized
INFO - 2017-06-29 09:24:44 --> Model Class Initialized
INFO - 2017-06-29 09:24:44 --> Helper loaded: form_helper
INFO - 2017-06-29 09:24:44 --> Helper loaded: url_helper
INFO - 2017-06-29 09:24:44 --> Model Class Initialized
INFO - 2017-06-29 09:24:44 --> Final output sent to browser
DEBUG - 2017-06-29 09:24:44 --> Total execution time: 0.1200
ERROR - 2017-06-29 09:24:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 09:24:52 --> Config Class Initialized
INFO - 2017-06-29 09:24:52 --> Hooks Class Initialized
DEBUG - 2017-06-29 09:24:52 --> UTF-8 Support Enabled
INFO - 2017-06-29 09:24:52 --> Utf8 Class Initialized
INFO - 2017-06-29 09:24:52 --> URI Class Initialized
INFO - 2017-06-29 09:24:52 --> Router Class Initialized
INFO - 2017-06-29 09:24:52 --> Output Class Initialized
INFO - 2017-06-29 09:24:52 --> Security Class Initialized
DEBUG - 2017-06-29 09:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 09:24:52 --> Input Class Initialized
INFO - 2017-06-29 09:24:52 --> Language Class Initialized
INFO - 2017-06-29 09:24:52 --> Loader Class Initialized
INFO - 2017-06-29 09:24:52 --> Controller Class Initialized
INFO - 2017-06-29 09:24:52 --> Database Driver Class Initialized
INFO - 2017-06-29 09:24:52 --> Model Class Initialized
INFO - 2017-06-29 09:24:52 --> Helper loaded: form_helper
INFO - 2017-06-29 09:24:52 --> Helper loaded: url_helper
INFO - 2017-06-29 09:24:52 --> Model Class Initialized
INFO - 2017-06-29 09:24:52 --> Final output sent to browser
DEBUG - 2017-06-29 09:24:52 --> Total execution time: 0.0800
ERROR - 2017-06-29 09:24:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 09:24:54 --> Config Class Initialized
INFO - 2017-06-29 09:24:54 --> Hooks Class Initialized
DEBUG - 2017-06-29 09:24:54 --> UTF-8 Support Enabled
INFO - 2017-06-29 09:24:54 --> Utf8 Class Initialized
INFO - 2017-06-29 09:24:54 --> URI Class Initialized
INFO - 2017-06-29 09:24:54 --> Router Class Initialized
INFO - 2017-06-29 09:24:54 --> Output Class Initialized
INFO - 2017-06-29 09:24:54 --> Security Class Initialized
DEBUG - 2017-06-29 09:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 09:24:54 --> Input Class Initialized
INFO - 2017-06-29 09:24:54 --> Language Class Initialized
INFO - 2017-06-29 09:24:54 --> Loader Class Initialized
INFO - 2017-06-29 09:24:54 --> Controller Class Initialized
INFO - 2017-06-29 09:24:54 --> Database Driver Class Initialized
INFO - 2017-06-29 09:24:54 --> Model Class Initialized
INFO - 2017-06-29 09:24:54 --> Helper loaded: form_helper
INFO - 2017-06-29 09:24:54 --> Helper loaded: url_helper
INFO - 2017-06-29 09:24:54 --> Model Class Initialized
INFO - 2017-06-29 09:24:54 --> Final output sent to browser
DEBUG - 2017-06-29 09:24:54 --> Total execution time: 0.1470
ERROR - 2017-06-29 12:53:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 12:53:00 --> Config Class Initialized
INFO - 2017-06-29 12:53:00 --> Hooks Class Initialized
DEBUG - 2017-06-29 12:53:00 --> UTF-8 Support Enabled
INFO - 2017-06-29 12:53:00 --> Utf8 Class Initialized
INFO - 2017-06-29 12:53:00 --> URI Class Initialized
INFO - 2017-06-29 12:53:00 --> Router Class Initialized
INFO - 2017-06-29 12:53:00 --> Output Class Initialized
INFO - 2017-06-29 12:53:00 --> Security Class Initialized
DEBUG - 2017-06-29 12:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 12:53:00 --> Input Class Initialized
INFO - 2017-06-29 12:53:00 --> Language Class Initialized
INFO - 2017-06-29 12:53:00 --> Loader Class Initialized
INFO - 2017-06-29 12:53:00 --> Controller Class Initialized
INFO - 2017-06-29 12:53:00 --> Database Driver Class Initialized
INFO - 2017-06-29 12:53:00 --> Model Class Initialized
INFO - 2017-06-29 12:53:00 --> Helper loaded: form_helper
INFO - 2017-06-29 12:53:00 --> Helper loaded: url_helper
INFO - 2017-06-29 12:53:00 --> Model Class Initialized
INFO - 2017-06-29 12:53:00 --> Final output sent to browser
DEBUG - 2017-06-29 12:53:00 --> Total execution time: 0.0670
ERROR - 2017-06-29 12:53:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 12:53:10 --> Config Class Initialized
INFO - 2017-06-29 12:53:10 --> Hooks Class Initialized
DEBUG - 2017-06-29 12:53:10 --> UTF-8 Support Enabled
INFO - 2017-06-29 12:53:10 --> Utf8 Class Initialized
INFO - 2017-06-29 12:53:10 --> URI Class Initialized
INFO - 2017-06-29 12:53:10 --> Router Class Initialized
INFO - 2017-06-29 12:53:10 --> Output Class Initialized
INFO - 2017-06-29 12:53:10 --> Security Class Initialized
DEBUG - 2017-06-29 12:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 12:53:10 --> Input Class Initialized
INFO - 2017-06-29 12:53:10 --> Language Class Initialized
INFO - 2017-06-29 12:53:10 --> Loader Class Initialized
INFO - 2017-06-29 12:53:10 --> Controller Class Initialized
INFO - 2017-06-29 12:53:10 --> Database Driver Class Initialized
INFO - 2017-06-29 12:53:10 --> Model Class Initialized
INFO - 2017-06-29 12:53:10 --> Helper loaded: form_helper
INFO - 2017-06-29 12:53:10 --> Helper loaded: url_helper
INFO - 2017-06-29 12:53:10 --> Model Class Initialized
INFO - 2017-06-29 12:53:10 --> Final output sent to browser
DEBUG - 2017-06-29 12:53:10 --> Total execution time: 0.0500
ERROR - 2017-06-29 12:53:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 12:53:13 --> Config Class Initialized
INFO - 2017-06-29 12:53:13 --> Hooks Class Initialized
DEBUG - 2017-06-29 12:53:13 --> UTF-8 Support Enabled
INFO - 2017-06-29 12:53:13 --> Utf8 Class Initialized
INFO - 2017-06-29 12:53:13 --> URI Class Initialized
INFO - 2017-06-29 12:53:13 --> Router Class Initialized
INFO - 2017-06-29 12:53:13 --> Output Class Initialized
INFO - 2017-06-29 12:53:13 --> Security Class Initialized
DEBUG - 2017-06-29 12:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 12:53:13 --> Input Class Initialized
INFO - 2017-06-29 12:53:13 --> Language Class Initialized
INFO - 2017-06-29 12:53:13 --> Loader Class Initialized
INFO - 2017-06-29 12:53:13 --> Controller Class Initialized
INFO - 2017-06-29 12:53:13 --> Database Driver Class Initialized
INFO - 2017-06-29 12:53:13 --> Model Class Initialized
INFO - 2017-06-29 12:53:13 --> Helper loaded: form_helper
INFO - 2017-06-29 12:53:13 --> Helper loaded: url_helper
INFO - 2017-06-29 12:53:13 --> Model Class Initialized
INFO - 2017-06-29 12:53:13 --> Final output sent to browser
DEBUG - 2017-06-29 12:53:13 --> Total execution time: 0.0590
ERROR - 2017-06-29 12:53:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 12:53:16 --> Config Class Initialized
INFO - 2017-06-29 12:53:16 --> Hooks Class Initialized
DEBUG - 2017-06-29 12:53:16 --> UTF-8 Support Enabled
INFO - 2017-06-29 12:53:16 --> Utf8 Class Initialized
INFO - 2017-06-29 12:53:16 --> URI Class Initialized
INFO - 2017-06-29 12:53:16 --> Router Class Initialized
INFO - 2017-06-29 12:53:16 --> Output Class Initialized
INFO - 2017-06-29 12:53:16 --> Security Class Initialized
DEBUG - 2017-06-29 12:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 12:53:16 --> Input Class Initialized
INFO - 2017-06-29 12:53:16 --> Language Class Initialized
INFO - 2017-06-29 12:53:16 --> Loader Class Initialized
INFO - 2017-06-29 12:53:16 --> Controller Class Initialized
INFO - 2017-06-29 12:53:16 --> Database Driver Class Initialized
INFO - 2017-06-29 12:53:16 --> Model Class Initialized
INFO - 2017-06-29 12:53:16 --> Helper loaded: form_helper
INFO - 2017-06-29 12:53:16 --> Helper loaded: url_helper
INFO - 2017-06-29 12:53:16 --> Model Class Initialized
INFO - 2017-06-29 12:53:16 --> Final output sent to browser
DEBUG - 2017-06-29 12:53:16 --> Total execution time: 0.0600
ERROR - 2017-06-29 12:53:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 12:53:21 --> Config Class Initialized
INFO - 2017-06-29 12:53:21 --> Hooks Class Initialized
DEBUG - 2017-06-29 12:53:21 --> UTF-8 Support Enabled
INFO - 2017-06-29 12:53:21 --> Utf8 Class Initialized
INFO - 2017-06-29 12:53:21 --> URI Class Initialized
INFO - 2017-06-29 12:53:21 --> Router Class Initialized
INFO - 2017-06-29 12:53:21 --> Output Class Initialized
INFO - 2017-06-29 12:53:21 --> Security Class Initialized
DEBUG - 2017-06-29 12:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 12:53:21 --> Input Class Initialized
INFO - 2017-06-29 12:53:21 --> Language Class Initialized
INFO - 2017-06-29 12:53:21 --> Loader Class Initialized
INFO - 2017-06-29 12:53:21 --> Controller Class Initialized
INFO - 2017-06-29 12:53:21 --> Database Driver Class Initialized
INFO - 2017-06-29 12:53:21 --> Model Class Initialized
INFO - 2017-06-29 12:53:21 --> Helper loaded: form_helper
INFO - 2017-06-29 12:53:21 --> Helper loaded: url_helper
INFO - 2017-06-29 12:53:21 --> Model Class Initialized
INFO - 2017-06-29 12:53:21 --> Final output sent to browser
DEBUG - 2017-06-29 12:53:21 --> Total execution time: 0.0620
ERROR - 2017-06-29 12:55:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 12:55:56 --> Config Class Initialized
INFO - 2017-06-29 12:55:56 --> Hooks Class Initialized
DEBUG - 2017-06-29 12:55:56 --> UTF-8 Support Enabled
INFO - 2017-06-29 12:55:56 --> Utf8 Class Initialized
INFO - 2017-06-29 12:55:56 --> URI Class Initialized
INFO - 2017-06-29 12:55:56 --> Router Class Initialized
INFO - 2017-06-29 12:55:56 --> Output Class Initialized
INFO - 2017-06-29 12:55:56 --> Security Class Initialized
DEBUG - 2017-06-29 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 12:55:56 --> Input Class Initialized
INFO - 2017-06-29 12:55:56 --> Language Class Initialized
INFO - 2017-06-29 12:55:56 --> Loader Class Initialized
INFO - 2017-06-29 12:55:56 --> Controller Class Initialized
INFO - 2017-06-29 12:55:56 --> Database Driver Class Initialized
INFO - 2017-06-29 12:55:56 --> Model Class Initialized
INFO - 2017-06-29 12:55:56 --> Helper loaded: form_helper
INFO - 2017-06-29 12:55:56 --> Helper loaded: url_helper
INFO - 2017-06-29 12:55:56 --> Model Class Initialized
INFO - 2017-06-29 12:55:56 --> Final output sent to browser
DEBUG - 2017-06-29 12:55:56 --> Total execution time: 0.0510
ERROR - 2017-06-29 12:56:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 12:56:25 --> Config Class Initialized
INFO - 2017-06-29 12:56:25 --> Hooks Class Initialized
DEBUG - 2017-06-29 12:56:25 --> UTF-8 Support Enabled
INFO - 2017-06-29 12:56:25 --> Utf8 Class Initialized
INFO - 2017-06-29 12:56:25 --> URI Class Initialized
INFO - 2017-06-29 12:56:25 --> Router Class Initialized
INFO - 2017-06-29 12:56:25 --> Output Class Initialized
INFO - 2017-06-29 12:56:25 --> Security Class Initialized
DEBUG - 2017-06-29 12:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 12:56:25 --> Input Class Initialized
INFO - 2017-06-29 12:56:25 --> Language Class Initialized
INFO - 2017-06-29 12:56:25 --> Loader Class Initialized
INFO - 2017-06-29 12:56:25 --> Controller Class Initialized
INFO - 2017-06-29 12:56:25 --> Database Driver Class Initialized
INFO - 2017-06-29 12:56:25 --> Model Class Initialized
INFO - 2017-06-29 12:56:25 --> Helper loaded: form_helper
INFO - 2017-06-29 12:56:25 --> Helper loaded: url_helper
INFO - 2017-06-29 12:56:25 --> Model Class Initialized
INFO - 2017-06-29 12:56:25 --> Final output sent to browser
DEBUG - 2017-06-29 12:56:25 --> Total execution time: 0.0680
ERROR - 2017-06-29 12:58:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 12:58:19 --> Config Class Initialized
INFO - 2017-06-29 12:58:19 --> Hooks Class Initialized
DEBUG - 2017-06-29 12:58:19 --> UTF-8 Support Enabled
INFO - 2017-06-29 12:58:19 --> Utf8 Class Initialized
INFO - 2017-06-29 12:58:19 --> URI Class Initialized
INFO - 2017-06-29 12:58:19 --> Router Class Initialized
INFO - 2017-06-29 12:58:19 --> Output Class Initialized
INFO - 2017-06-29 12:58:19 --> Security Class Initialized
DEBUG - 2017-06-29 12:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 12:58:19 --> Input Class Initialized
INFO - 2017-06-29 12:58:19 --> Language Class Initialized
INFO - 2017-06-29 12:58:19 --> Loader Class Initialized
INFO - 2017-06-29 12:58:19 --> Controller Class Initialized
INFO - 2017-06-29 12:58:19 --> Database Driver Class Initialized
INFO - 2017-06-29 12:58:19 --> Model Class Initialized
INFO - 2017-06-29 12:58:19 --> Helper loaded: form_helper
INFO - 2017-06-29 12:58:19 --> Helper loaded: url_helper
INFO - 2017-06-29 12:58:19 --> Model Class Initialized
INFO - 2017-06-29 12:58:19 --> Final output sent to browser
DEBUG - 2017-06-29 12:58:19 --> Total execution time: 0.0640
ERROR - 2017-06-29 12:58:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 12:58:23 --> Config Class Initialized
INFO - 2017-06-29 12:58:23 --> Hooks Class Initialized
DEBUG - 2017-06-29 12:58:23 --> UTF-8 Support Enabled
INFO - 2017-06-29 12:58:23 --> Utf8 Class Initialized
INFO - 2017-06-29 12:58:23 --> URI Class Initialized
INFO - 2017-06-29 12:58:23 --> Router Class Initialized
INFO - 2017-06-29 12:58:23 --> Output Class Initialized
INFO - 2017-06-29 12:58:23 --> Security Class Initialized
DEBUG - 2017-06-29 12:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 12:58:23 --> Input Class Initialized
INFO - 2017-06-29 12:58:23 --> Language Class Initialized
INFO - 2017-06-29 12:58:23 --> Loader Class Initialized
INFO - 2017-06-29 12:58:23 --> Controller Class Initialized
INFO - 2017-06-29 12:58:23 --> Database Driver Class Initialized
INFO - 2017-06-29 12:58:23 --> Model Class Initialized
INFO - 2017-06-29 12:58:23 --> Helper loaded: form_helper
INFO - 2017-06-29 12:58:23 --> Helper loaded: url_helper
INFO - 2017-06-29 12:58:23 --> Model Class Initialized
INFO - 2017-06-29 12:58:23 --> Final output sent to browser
DEBUG - 2017-06-29 12:58:23 --> Total execution time: 0.0630
ERROR - 2017-06-29 16:13:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 16:13:04 --> Config Class Initialized
INFO - 2017-06-29 16:13:04 --> Hooks Class Initialized
DEBUG - 2017-06-29 16:13:04 --> UTF-8 Support Enabled
INFO - 2017-06-29 16:13:04 --> Utf8 Class Initialized
INFO - 2017-06-29 16:13:04 --> URI Class Initialized
DEBUG - 2017-06-29 16:13:04 --> No URI present. Default controller set.
INFO - 2017-06-29 16:13:04 --> Router Class Initialized
INFO - 2017-06-29 16:13:04 --> Output Class Initialized
INFO - 2017-06-29 16:13:04 --> Security Class Initialized
DEBUG - 2017-06-29 16:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 16:13:04 --> Input Class Initialized
INFO - 2017-06-29 16:13:04 --> Language Class Initialized
INFO - 2017-06-29 16:13:04 --> Loader Class Initialized
INFO - 2017-06-29 16:13:04 --> Controller Class Initialized
INFO - 2017-06-29 16:13:04 --> Database Driver Class Initialized
INFO - 2017-06-29 16:13:04 --> Model Class Initialized
INFO - 2017-06-29 16:13:04 --> Helper loaded: form_helper
INFO - 2017-06-29 16:13:04 --> Helper loaded: url_helper
INFO - 2017-06-29 16:13:04 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-06-29 16:13:04 --> Final output sent to browser
DEBUG - 2017-06-29 16:13:04 --> Total execution time: 0.0800
ERROR - 2017-06-29 16:13:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 16:13:06 --> Config Class Initialized
INFO - 2017-06-29 16:13:06 --> Hooks Class Initialized
DEBUG - 2017-06-29 16:13:06 --> UTF-8 Support Enabled
INFO - 2017-06-29 16:13:06 --> Utf8 Class Initialized
INFO - 2017-06-29 16:13:06 --> URI Class Initialized
INFO - 2017-06-29 16:13:06 --> Router Class Initialized
INFO - 2017-06-29 16:13:06 --> Output Class Initialized
INFO - 2017-06-29 16:13:06 --> Security Class Initialized
DEBUG - 2017-06-29 16:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 16:13:06 --> Input Class Initialized
INFO - 2017-06-29 16:13:06 --> Language Class Initialized
INFO - 2017-06-29 16:13:06 --> Loader Class Initialized
INFO - 2017-06-29 16:13:06 --> Controller Class Initialized
INFO - 2017-06-29 16:13:06 --> Database Driver Class Initialized
INFO - 2017-06-29 16:13:06 --> Model Class Initialized
INFO - 2017-06-29 16:13:06 --> Helper loaded: form_helper
INFO - 2017-06-29 16:13:06 --> Helper loaded: url_helper
INFO - 2017-06-29 16:13:06 --> Model Class Initialized
ERROR - 2017-06-29 16:13:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 16:13:06 --> Config Class Initialized
INFO - 2017-06-29 16:13:06 --> Hooks Class Initialized
DEBUG - 2017-06-29 16:13:06 --> UTF-8 Support Enabled
INFO - 2017-06-29 16:13:06 --> Utf8 Class Initialized
INFO - 2017-06-29 16:13:06 --> URI Class Initialized
INFO - 2017-06-29 16:13:06 --> Router Class Initialized
INFO - 2017-06-29 16:13:06 --> Output Class Initialized
INFO - 2017-06-29 16:13:06 --> Security Class Initialized
DEBUG - 2017-06-29 16:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 16:13:06 --> Input Class Initialized
INFO - 2017-06-29 16:13:06 --> Language Class Initialized
INFO - 2017-06-29 16:13:06 --> Loader Class Initialized
INFO - 2017-06-29 16:13:06 --> Controller Class Initialized
INFO - 2017-06-29 16:13:06 --> Database Driver Class Initialized
INFO - 2017-06-29 16:13:06 --> Model Class Initialized
INFO - 2017-06-29 16:13:06 --> Helper loaded: form_helper
INFO - 2017-06-29 16:13:06 --> Helper loaded: url_helper
INFO - 2017-06-29 16:13:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-29 16:13:06 --> Model Class Initialized
INFO - 2017-06-29 16:13:06 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-29 16:13:06 --> Final output sent to browser
DEBUG - 2017-06-29 16:13:06 --> Total execution time: 0.0690
ERROR - 2017-06-29 16:13:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 16:13:17 --> Config Class Initialized
INFO - 2017-06-29 16:13:17 --> Hooks Class Initialized
DEBUG - 2017-06-29 16:13:17 --> UTF-8 Support Enabled
INFO - 2017-06-29 16:13:17 --> Utf8 Class Initialized
INFO - 2017-06-29 16:13:17 --> URI Class Initialized
INFO - 2017-06-29 16:13:17 --> Router Class Initialized
INFO - 2017-06-29 16:13:17 --> Output Class Initialized
INFO - 2017-06-29 16:13:17 --> Security Class Initialized
DEBUG - 2017-06-29 16:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 16:13:17 --> Input Class Initialized
INFO - 2017-06-29 16:13:17 --> Language Class Initialized
INFO - 2017-06-29 16:13:17 --> Loader Class Initialized
INFO - 2017-06-29 16:13:17 --> Controller Class Initialized
INFO - 2017-06-29 16:13:17 --> Database Driver Class Initialized
INFO - 2017-06-29 16:13:17 --> Model Class Initialized
INFO - 2017-06-29 16:13:17 --> Helper loaded: form_helper
INFO - 2017-06-29 16:13:17 --> Helper loaded: url_helper
INFO - 2017-06-29 16:13:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-29 16:13:17 --> Model Class Initialized
INFO - 2017-06-29 16:13:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\users.php
INFO - 2017-06-29 16:13:17 --> Final output sent to browser
DEBUG - 2017-06-29 16:13:17 --> Total execution time: 0.0760
ERROR - 2017-06-29 16:13:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 16:13:20 --> Config Class Initialized
INFO - 2017-06-29 16:13:20 --> Hooks Class Initialized
DEBUG - 2017-06-29 16:13:20 --> UTF-8 Support Enabled
INFO - 2017-06-29 16:13:20 --> Utf8 Class Initialized
INFO - 2017-06-29 16:13:20 --> URI Class Initialized
INFO - 2017-06-29 16:13:20 --> Router Class Initialized
INFO - 2017-06-29 16:13:20 --> Output Class Initialized
INFO - 2017-06-29 16:13:20 --> Security Class Initialized
DEBUG - 2017-06-29 16:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 16:13:20 --> Input Class Initialized
INFO - 2017-06-29 16:13:20 --> Language Class Initialized
INFO - 2017-06-29 16:13:20 --> Loader Class Initialized
INFO - 2017-06-29 16:13:20 --> Controller Class Initialized
INFO - 2017-06-29 16:13:20 --> Database Driver Class Initialized
INFO - 2017-06-29 16:13:20 --> Model Class Initialized
INFO - 2017-06-29 16:13:20 --> Helper loaded: form_helper
INFO - 2017-06-29 16:13:20 --> Helper loaded: url_helper
INFO - 2017-06-29 16:13:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-29 16:13:20 --> Model Class Initialized
INFO - 2017-06-29 16:13:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-06-29 16:13:20 --> Final output sent to browser
DEBUG - 2017-06-29 16:13:20 --> Total execution time: 0.1290
ERROR - 2017-06-29 16:13:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 16:13:21 --> Config Class Initialized
INFO - 2017-06-29 16:13:21 --> Hooks Class Initialized
DEBUG - 2017-06-29 16:13:21 --> UTF-8 Support Enabled
INFO - 2017-06-29 16:13:21 --> Utf8 Class Initialized
INFO - 2017-06-29 16:13:21 --> URI Class Initialized
INFO - 2017-06-29 16:13:21 --> Router Class Initialized
INFO - 2017-06-29 16:13:21 --> Output Class Initialized
INFO - 2017-06-29 16:13:21 --> Security Class Initialized
DEBUG - 2017-06-29 16:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 16:13:21 --> Input Class Initialized
INFO - 2017-06-29 16:13:21 --> Language Class Initialized
INFO - 2017-06-29 16:13:21 --> Loader Class Initialized
INFO - 2017-06-29 16:13:21 --> Controller Class Initialized
INFO - 2017-06-29 16:13:21 --> Database Driver Class Initialized
INFO - 2017-06-29 16:13:21 --> Model Class Initialized
INFO - 2017-06-29 16:13:21 --> Helper loaded: form_helper
INFO - 2017-06-29 16:13:21 --> Helper loaded: url_helper
INFO - 2017-06-29 16:13:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-29 16:13:21 --> Model Class Initialized
INFO - 2017-06-29 16:13:21 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-06-29 16:13:21 --> Final output sent to browser
DEBUG - 2017-06-29 16:13:21 --> Total execution time: 0.0970
ERROR - 2017-06-29 16:13:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-29 16:13:23 --> Config Class Initialized
INFO - 2017-06-29 16:13:23 --> Hooks Class Initialized
DEBUG - 2017-06-29 16:13:23 --> UTF-8 Support Enabled
INFO - 2017-06-29 16:13:23 --> Utf8 Class Initialized
INFO - 2017-06-29 16:13:23 --> URI Class Initialized
INFO - 2017-06-29 16:13:23 --> Router Class Initialized
INFO - 2017-06-29 16:13:23 --> Output Class Initialized
INFO - 2017-06-29 16:13:23 --> Security Class Initialized
DEBUG - 2017-06-29 16:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-29 16:13:23 --> Input Class Initialized
INFO - 2017-06-29 16:13:23 --> Language Class Initialized
INFO - 2017-06-29 16:13:23 --> Loader Class Initialized
INFO - 2017-06-29 16:13:23 --> Controller Class Initialized
INFO - 2017-06-29 16:13:23 --> Database Driver Class Initialized
INFO - 2017-06-29 16:13:23 --> Model Class Initialized
INFO - 2017-06-29 16:13:23 --> Helper loaded: form_helper
INFO - 2017-06-29 16:13:23 --> Helper loaded: url_helper
INFO - 2017-06-29 16:13:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-29 16:13:23 --> Model Class Initialized
INFO - 2017-06-29 16:13:23 --> File loaded: C:\xampp\htdocs\mystage\application\views\tempos.php
INFO - 2017-06-29 16:13:23 --> Final output sent to browser
DEBUG - 2017-06-29 16:13:23 --> Total execution time: 0.1460
