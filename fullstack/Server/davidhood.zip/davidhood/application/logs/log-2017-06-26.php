<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-26 16:17:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 16:17:57 --> Config Class Initialized
INFO - 2017-06-26 16:17:57 --> Hooks Class Initialized
DEBUG - 2017-06-26 16:17:57 --> UTF-8 Support Enabled
INFO - 2017-06-26 16:17:57 --> Utf8 Class Initialized
INFO - 2017-06-26 16:17:57 --> URI Class Initialized
INFO - 2017-06-26 16:17:57 --> Router Class Initialized
INFO - 2017-06-26 16:17:57 --> Output Class Initialized
INFO - 2017-06-26 16:17:57 --> Security Class Initialized
DEBUG - 2017-06-26 16:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 16:17:57 --> Input Class Initialized
INFO - 2017-06-26 16:17:57 --> Language Class Initialized
INFO - 2017-06-26 16:17:57 --> Loader Class Initialized
INFO - 2017-06-26 16:17:57 --> Controller Class Initialized
INFO - 2017-06-26 16:17:57 --> Database Driver Class Initialized
INFO - 2017-06-26 16:17:57 --> Model Class Initialized
INFO - 2017-06-26 16:17:57 --> Helper loaded: form_helper
INFO - 2017-06-26 16:17:57 --> Helper loaded: url_helper
ERROR - 2017-06-26 16:17:58 --> Severity: Parsing Error --> syntax error, unexpected ',', expecting variable (T_VARIABLE) C:\xampp\htdocs\mystage\application\models\Mobile_model.php 38
ERROR - 2017-06-26 16:18:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 16:18:17 --> Config Class Initialized
INFO - 2017-06-26 16:18:17 --> Hooks Class Initialized
DEBUG - 2017-06-26 16:18:17 --> UTF-8 Support Enabled
INFO - 2017-06-26 16:18:17 --> Utf8 Class Initialized
INFO - 2017-06-26 16:18:17 --> URI Class Initialized
DEBUG - 2017-06-26 16:18:17 --> No URI present. Default controller set.
INFO - 2017-06-26 16:18:17 --> Router Class Initialized
INFO - 2017-06-26 16:18:17 --> Output Class Initialized
INFO - 2017-06-26 16:18:17 --> Security Class Initialized
DEBUG - 2017-06-26 16:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 16:18:17 --> Input Class Initialized
INFO - 2017-06-26 16:18:17 --> Language Class Initialized
INFO - 2017-06-26 16:18:17 --> Loader Class Initialized
INFO - 2017-06-26 16:18:17 --> Controller Class Initialized
INFO - 2017-06-26 16:18:17 --> Database Driver Class Initialized
INFO - 2017-06-26 16:18:17 --> Model Class Initialized
INFO - 2017-06-26 16:18:17 --> Helper loaded: form_helper
INFO - 2017-06-26 16:18:17 --> Helper loaded: url_helper
INFO - 2017-06-26 16:18:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-06-26 16:18:17 --> Final output sent to browser
DEBUG - 2017-06-26 16:18:17 --> Total execution time: 0.1380
ERROR - 2017-06-26 16:18:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 16:18:19 --> Config Class Initialized
INFO - 2017-06-26 16:18:19 --> Hooks Class Initialized
DEBUG - 2017-06-26 16:18:19 --> UTF-8 Support Enabled
INFO - 2017-06-26 16:18:19 --> Utf8 Class Initialized
INFO - 2017-06-26 16:18:19 --> URI Class Initialized
INFO - 2017-06-26 16:18:19 --> Router Class Initialized
INFO - 2017-06-26 16:18:19 --> Output Class Initialized
INFO - 2017-06-26 16:18:19 --> Security Class Initialized
DEBUG - 2017-06-26 16:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 16:18:19 --> Input Class Initialized
INFO - 2017-06-26 16:18:19 --> Language Class Initialized
INFO - 2017-06-26 16:18:19 --> Loader Class Initialized
INFO - 2017-06-26 16:18:19 --> Controller Class Initialized
INFO - 2017-06-26 16:18:19 --> Database Driver Class Initialized
INFO - 2017-06-26 16:18:19 --> Model Class Initialized
INFO - 2017-06-26 16:18:19 --> Helper loaded: form_helper
INFO - 2017-06-26 16:18:19 --> Helper loaded: url_helper
INFO - 2017-06-26 16:18:19 --> Model Class Initialized
ERROR - 2017-06-26 16:18:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 16:18:20 --> Config Class Initialized
INFO - 2017-06-26 16:18:20 --> Hooks Class Initialized
DEBUG - 2017-06-26 16:18:20 --> UTF-8 Support Enabled
INFO - 2017-06-26 16:18:20 --> Utf8 Class Initialized
INFO - 2017-06-26 16:18:20 --> URI Class Initialized
INFO - 2017-06-26 16:18:20 --> Router Class Initialized
INFO - 2017-06-26 16:18:20 --> Output Class Initialized
INFO - 2017-06-26 16:18:20 --> Security Class Initialized
DEBUG - 2017-06-26 16:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 16:18:20 --> Input Class Initialized
INFO - 2017-06-26 16:18:20 --> Language Class Initialized
INFO - 2017-06-26 16:18:20 --> Loader Class Initialized
INFO - 2017-06-26 16:18:20 --> Controller Class Initialized
INFO - 2017-06-26 16:18:20 --> Database Driver Class Initialized
INFO - 2017-06-26 16:18:20 --> Model Class Initialized
INFO - 2017-06-26 16:18:20 --> Helper loaded: form_helper
INFO - 2017-06-26 16:18:20 --> Helper loaded: url_helper
INFO - 2017-06-26 16:18:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-06-26 16:18:20 --> Model Class Initialized
INFO - 2017-06-26 16:18:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-06-26 16:18:20 --> Final output sent to browser
DEBUG - 2017-06-26 16:18:20 --> Total execution time: 0.0590
ERROR - 2017-06-26 16:18:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 16:18:40 --> Config Class Initialized
INFO - 2017-06-26 16:18:40 --> Hooks Class Initialized
DEBUG - 2017-06-26 16:18:40 --> UTF-8 Support Enabled
INFO - 2017-06-26 16:18:40 --> Utf8 Class Initialized
INFO - 2017-06-26 16:18:40 --> URI Class Initialized
INFO - 2017-06-26 16:18:40 --> Router Class Initialized
INFO - 2017-06-26 16:18:40 --> Output Class Initialized
INFO - 2017-06-26 16:18:40 --> Security Class Initialized
DEBUG - 2017-06-26 16:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 16:18:40 --> Input Class Initialized
INFO - 2017-06-26 16:18:40 --> Language Class Initialized
INFO - 2017-06-26 16:18:40 --> Loader Class Initialized
INFO - 2017-06-26 16:18:40 --> Controller Class Initialized
INFO - 2017-06-26 16:18:40 --> Database Driver Class Initialized
INFO - 2017-06-26 16:18:40 --> Model Class Initialized
INFO - 2017-06-26 16:18:40 --> Helper loaded: form_helper
INFO - 2017-06-26 16:18:40 --> Helper loaded: url_helper
ERROR - 2017-06-26 16:18:40 --> Severity: Parsing Error --> syntax error, unexpected ',', expecting variable (T_VARIABLE) C:\xampp\htdocs\mystage\application\models\Mobile_model.php 38
ERROR - 2017-06-26 16:19:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 16:19:03 --> Config Class Initialized
INFO - 2017-06-26 16:19:03 --> Hooks Class Initialized
DEBUG - 2017-06-26 16:19:03 --> UTF-8 Support Enabled
INFO - 2017-06-26 16:19:03 --> Utf8 Class Initialized
INFO - 2017-06-26 16:19:03 --> URI Class Initialized
INFO - 2017-06-26 16:19:03 --> Router Class Initialized
INFO - 2017-06-26 16:19:03 --> Output Class Initialized
INFO - 2017-06-26 16:19:03 --> Security Class Initialized
DEBUG - 2017-06-26 16:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 16:19:03 --> Input Class Initialized
INFO - 2017-06-26 16:19:03 --> Language Class Initialized
INFO - 2017-06-26 16:19:03 --> Loader Class Initialized
INFO - 2017-06-26 16:19:03 --> Controller Class Initialized
INFO - 2017-06-26 16:19:03 --> Database Driver Class Initialized
INFO - 2017-06-26 16:19:03 --> Model Class Initialized
INFO - 2017-06-26 16:19:03 --> Helper loaded: form_helper
INFO - 2017-06-26 16:19:03 --> Helper loaded: url_helper
INFO - 2017-06-26 16:19:03 --> Model Class Initialized
INFO - 2017-06-26 16:19:03 --> Final output sent to browser
DEBUG - 2017-06-26 16:19:03 --> Total execution time: 0.0510
ERROR - 2017-06-26 16:19:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 16:19:06 --> Config Class Initialized
INFO - 2017-06-26 16:19:06 --> Hooks Class Initialized
DEBUG - 2017-06-26 16:19:06 --> UTF-8 Support Enabled
INFO - 2017-06-26 16:19:06 --> Utf8 Class Initialized
INFO - 2017-06-26 16:19:06 --> URI Class Initialized
INFO - 2017-06-26 16:19:06 --> Router Class Initialized
INFO - 2017-06-26 16:19:06 --> Output Class Initialized
INFO - 2017-06-26 16:19:06 --> Security Class Initialized
DEBUG - 2017-06-26 16:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 16:19:06 --> Input Class Initialized
INFO - 2017-06-26 16:19:06 --> Language Class Initialized
INFO - 2017-06-26 16:19:06 --> Loader Class Initialized
INFO - 2017-06-26 16:19:06 --> Controller Class Initialized
INFO - 2017-06-26 16:19:06 --> Database Driver Class Initialized
INFO - 2017-06-26 16:19:06 --> Model Class Initialized
INFO - 2017-06-26 16:19:06 --> Helper loaded: form_helper
INFO - 2017-06-26 16:19:06 --> Helper loaded: url_helper
INFO - 2017-06-26 16:19:06 --> Model Class Initialized
INFO - 2017-06-26 16:19:06 --> Final output sent to browser
DEBUG - 2017-06-26 16:19:06 --> Total execution time: 0.0490
ERROR - 2017-06-26 16:19:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 16:19:07 --> Config Class Initialized
INFO - 2017-06-26 16:19:07 --> Hooks Class Initialized
DEBUG - 2017-06-26 16:19:07 --> UTF-8 Support Enabled
INFO - 2017-06-26 16:19:07 --> Utf8 Class Initialized
INFO - 2017-06-26 16:19:07 --> URI Class Initialized
INFO - 2017-06-26 16:19:07 --> Router Class Initialized
INFO - 2017-06-26 16:19:07 --> Output Class Initialized
INFO - 2017-06-26 16:19:07 --> Security Class Initialized
DEBUG - 2017-06-26 16:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 16:19:07 --> Input Class Initialized
INFO - 2017-06-26 16:19:07 --> Language Class Initialized
INFO - 2017-06-26 16:19:07 --> Loader Class Initialized
INFO - 2017-06-26 16:19:07 --> Controller Class Initialized
INFO - 2017-06-26 16:19:07 --> Database Driver Class Initialized
INFO - 2017-06-26 16:19:07 --> Model Class Initialized
INFO - 2017-06-26 16:19:07 --> Helper loaded: form_helper
INFO - 2017-06-26 16:19:07 --> Helper loaded: url_helper
INFO - 2017-06-26 16:19:07 --> Model Class Initialized
INFO - 2017-06-26 16:19:07 --> Final output sent to browser
DEBUG - 2017-06-26 16:19:07 --> Total execution time: 0.0500
ERROR - 2017-06-26 16:19:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 16:19:16 --> Config Class Initialized
INFO - 2017-06-26 16:19:16 --> Hooks Class Initialized
DEBUG - 2017-06-26 16:19:16 --> UTF-8 Support Enabled
INFO - 2017-06-26 16:19:16 --> Utf8 Class Initialized
INFO - 2017-06-26 16:19:16 --> URI Class Initialized
INFO - 2017-06-26 16:19:16 --> Router Class Initialized
INFO - 2017-06-26 16:19:16 --> Output Class Initialized
INFO - 2017-06-26 16:19:16 --> Security Class Initialized
DEBUG - 2017-06-26 16:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 16:19:16 --> Input Class Initialized
INFO - 2017-06-26 16:19:16 --> Language Class Initialized
INFO - 2017-06-26 16:19:16 --> Loader Class Initialized
INFO - 2017-06-26 16:19:16 --> Controller Class Initialized
INFO - 2017-06-26 16:19:16 --> Database Driver Class Initialized
INFO - 2017-06-26 16:19:16 --> Model Class Initialized
INFO - 2017-06-26 16:19:16 --> Helper loaded: form_helper
INFO - 2017-06-26 16:19:16 --> Helper loaded: url_helper
INFO - 2017-06-26 16:19:16 --> Model Class Initialized
INFO - 2017-06-26 16:19:16 --> Final output sent to browser
DEBUG - 2017-06-26 16:19:16 --> Total execution time: 0.0400
ERROR - 2017-06-26 16:45:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 16:45:18 --> Config Class Initialized
INFO - 2017-06-26 16:45:18 --> Hooks Class Initialized
DEBUG - 2017-06-26 16:45:18 --> UTF-8 Support Enabled
INFO - 2017-06-26 16:45:18 --> Utf8 Class Initialized
INFO - 2017-06-26 16:45:18 --> URI Class Initialized
INFO - 2017-06-26 16:45:18 --> Router Class Initialized
INFO - 2017-06-26 16:45:18 --> Output Class Initialized
INFO - 2017-06-26 16:45:18 --> Security Class Initialized
DEBUG - 2017-06-26 16:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 16:45:18 --> Input Class Initialized
INFO - 2017-06-26 16:45:18 --> Language Class Initialized
INFO - 2017-06-26 16:45:18 --> Loader Class Initialized
INFO - 2017-06-26 16:45:18 --> Controller Class Initialized
INFO - 2017-06-26 16:45:18 --> Database Driver Class Initialized
INFO - 2017-06-26 16:45:18 --> Model Class Initialized
INFO - 2017-06-26 16:45:18 --> Helper loaded: form_helper
INFO - 2017-06-26 16:45:18 --> Helper loaded: url_helper
INFO - 2017-06-26 16:45:18 --> Model Class Initialized
INFO - 2017-06-26 16:45:18 --> Final output sent to browser
DEBUG - 2017-06-26 16:45:18 --> Total execution time: 0.0520
ERROR - 2017-06-26 16:45:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 16:45:19 --> Config Class Initialized
INFO - 2017-06-26 16:45:19 --> Hooks Class Initialized
DEBUG - 2017-06-26 16:45:19 --> UTF-8 Support Enabled
INFO - 2017-06-26 16:45:19 --> Utf8 Class Initialized
INFO - 2017-06-26 16:45:19 --> URI Class Initialized
INFO - 2017-06-26 16:45:19 --> Router Class Initialized
INFO - 2017-06-26 16:45:19 --> Output Class Initialized
INFO - 2017-06-26 16:45:19 --> Security Class Initialized
DEBUG - 2017-06-26 16:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 16:45:19 --> Input Class Initialized
INFO - 2017-06-26 16:45:19 --> Language Class Initialized
INFO - 2017-06-26 16:45:19 --> Loader Class Initialized
INFO - 2017-06-26 16:45:19 --> Controller Class Initialized
INFO - 2017-06-26 16:45:19 --> Database Driver Class Initialized
INFO - 2017-06-26 16:45:19 --> Model Class Initialized
INFO - 2017-06-26 16:45:19 --> Helper loaded: form_helper
INFO - 2017-06-26 16:45:19 --> Helper loaded: url_helper
INFO - 2017-06-26 16:45:19 --> Model Class Initialized
INFO - 2017-06-26 16:45:19 --> Final output sent to browser
DEBUG - 2017-06-26 16:45:19 --> Total execution time: 0.0510
ERROR - 2017-06-26 16:59:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 16:59:05 --> Config Class Initialized
INFO - 2017-06-26 16:59:05 --> Hooks Class Initialized
DEBUG - 2017-06-26 16:59:05 --> UTF-8 Support Enabled
INFO - 2017-06-26 16:59:05 --> Utf8 Class Initialized
INFO - 2017-06-26 16:59:05 --> URI Class Initialized
INFO - 2017-06-26 16:59:05 --> Router Class Initialized
INFO - 2017-06-26 16:59:05 --> Output Class Initialized
INFO - 2017-06-26 16:59:05 --> Security Class Initialized
DEBUG - 2017-06-26 16:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 16:59:05 --> Input Class Initialized
INFO - 2017-06-26 16:59:05 --> Language Class Initialized
INFO - 2017-06-26 16:59:05 --> Loader Class Initialized
INFO - 2017-06-26 16:59:05 --> Controller Class Initialized
INFO - 2017-06-26 16:59:05 --> Database Driver Class Initialized
INFO - 2017-06-26 16:59:05 --> Model Class Initialized
INFO - 2017-06-26 16:59:05 --> Helper loaded: form_helper
INFO - 2017-06-26 16:59:05 --> Helper loaded: url_helper
INFO - 2017-06-26 16:59:05 --> Model Class Initialized
INFO - 2017-06-26 16:59:05 --> Final output sent to browser
DEBUG - 2017-06-26 16:59:05 --> Total execution time: 0.0500
ERROR - 2017-06-26 16:59:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 16:59:06 --> Config Class Initialized
INFO - 2017-06-26 16:59:06 --> Hooks Class Initialized
DEBUG - 2017-06-26 16:59:06 --> UTF-8 Support Enabled
INFO - 2017-06-26 16:59:06 --> Utf8 Class Initialized
INFO - 2017-06-26 16:59:06 --> URI Class Initialized
INFO - 2017-06-26 16:59:06 --> Router Class Initialized
INFO - 2017-06-26 16:59:06 --> Output Class Initialized
INFO - 2017-06-26 16:59:06 --> Security Class Initialized
DEBUG - 2017-06-26 16:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 16:59:06 --> Input Class Initialized
INFO - 2017-06-26 16:59:06 --> Language Class Initialized
INFO - 2017-06-26 16:59:06 --> Loader Class Initialized
INFO - 2017-06-26 16:59:06 --> Controller Class Initialized
INFO - 2017-06-26 16:59:06 --> Database Driver Class Initialized
INFO - 2017-06-26 16:59:06 --> Model Class Initialized
INFO - 2017-06-26 16:59:06 --> Helper loaded: form_helper
INFO - 2017-06-26 16:59:06 --> Helper loaded: url_helper
INFO - 2017-06-26 16:59:06 --> Model Class Initialized
INFO - 2017-06-26 16:59:06 --> Final output sent to browser
DEBUG - 2017-06-26 16:59:06 --> Total execution time: 0.0910
ERROR - 2017-06-26 17:55:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 17:55:43 --> Config Class Initialized
INFO - 2017-06-26 17:55:43 --> Hooks Class Initialized
DEBUG - 2017-06-26 17:55:43 --> UTF-8 Support Enabled
INFO - 2017-06-26 17:55:43 --> Utf8 Class Initialized
INFO - 2017-06-26 17:55:43 --> URI Class Initialized
INFO - 2017-06-26 17:55:43 --> Router Class Initialized
INFO - 2017-06-26 17:55:43 --> Output Class Initialized
INFO - 2017-06-26 17:55:43 --> Security Class Initialized
DEBUG - 2017-06-26 17:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 17:55:43 --> Input Class Initialized
INFO - 2017-06-26 17:55:43 --> Language Class Initialized
INFO - 2017-06-26 17:55:43 --> Loader Class Initialized
INFO - 2017-06-26 17:55:43 --> Controller Class Initialized
INFO - 2017-06-26 17:55:44 --> Database Driver Class Initialized
INFO - 2017-06-26 17:55:44 --> Model Class Initialized
INFO - 2017-06-26 17:55:44 --> Helper loaded: form_helper
INFO - 2017-06-26 17:55:44 --> Helper loaded: url_helper
INFO - 2017-06-26 17:55:44 --> Model Class Initialized
INFO - 2017-06-26 17:55:44 --> Final output sent to browser
DEBUG - 2017-06-26 17:55:44 --> Total execution time: 0.1020
ERROR - 2017-06-26 17:55:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 17:55:44 --> Config Class Initialized
INFO - 2017-06-26 17:55:44 --> Hooks Class Initialized
DEBUG - 2017-06-26 17:55:44 --> UTF-8 Support Enabled
INFO - 2017-06-26 17:55:44 --> Utf8 Class Initialized
INFO - 2017-06-26 17:55:44 --> URI Class Initialized
INFO - 2017-06-26 17:55:44 --> Router Class Initialized
INFO - 2017-06-26 17:55:44 --> Output Class Initialized
INFO - 2017-06-26 17:55:44 --> Security Class Initialized
DEBUG - 2017-06-26 17:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 17:55:44 --> Input Class Initialized
INFO - 2017-06-26 17:55:44 --> Language Class Initialized
INFO - 2017-06-26 17:55:44 --> Loader Class Initialized
INFO - 2017-06-26 17:55:44 --> Controller Class Initialized
INFO - 2017-06-26 17:55:44 --> Database Driver Class Initialized
INFO - 2017-06-26 17:55:44 --> Model Class Initialized
INFO - 2017-06-26 17:55:44 --> Helper loaded: form_helper
INFO - 2017-06-26 17:55:44 --> Helper loaded: url_helper
INFO - 2017-06-26 17:55:44 --> Model Class Initialized
INFO - 2017-06-26 17:55:44 --> Final output sent to browser
DEBUG - 2017-06-26 17:55:44 --> Total execution time: 0.0420
ERROR - 2017-06-26 18:05:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:05:15 --> Config Class Initialized
INFO - 2017-06-26 18:05:15 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:05:15 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:05:15 --> Utf8 Class Initialized
INFO - 2017-06-26 18:05:15 --> URI Class Initialized
INFO - 2017-06-26 18:05:15 --> Router Class Initialized
INFO - 2017-06-26 18:05:15 --> Output Class Initialized
INFO - 2017-06-26 18:05:15 --> Security Class Initialized
DEBUG - 2017-06-26 18:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:05:15 --> Input Class Initialized
INFO - 2017-06-26 18:05:15 --> Language Class Initialized
INFO - 2017-06-26 18:05:15 --> Loader Class Initialized
INFO - 2017-06-26 18:05:15 --> Controller Class Initialized
INFO - 2017-06-26 18:05:15 --> Database Driver Class Initialized
INFO - 2017-06-26 18:05:15 --> Model Class Initialized
INFO - 2017-06-26 18:05:15 --> Helper loaded: form_helper
INFO - 2017-06-26 18:05:15 --> Helper loaded: url_helper
INFO - 2017-06-26 18:05:15 --> Model Class Initialized
ERROR - 2017-06-26 18:05:15 --> Severity: Notice --> Undefined index: token C:\xampp\htdocs\mystage\application\controllers\Mobile.php 27
ERROR - 2017-06-26 18:05:15 --> Query error: Column 'token' cannot be null - Invalid query: INSERT INTO `tbl_login` (`user_id`, `token`) VALUES ('15', NULL)
INFO - 2017-06-26 18:05:15 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-06-26 18:05:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:05:28 --> Config Class Initialized
INFO - 2017-06-26 18:05:28 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:05:28 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:05:28 --> Utf8 Class Initialized
INFO - 2017-06-26 18:05:28 --> URI Class Initialized
INFO - 2017-06-26 18:05:28 --> Router Class Initialized
INFO - 2017-06-26 18:05:28 --> Output Class Initialized
INFO - 2017-06-26 18:05:28 --> Security Class Initialized
DEBUG - 2017-06-26 18:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:05:28 --> Input Class Initialized
INFO - 2017-06-26 18:05:28 --> Language Class Initialized
INFO - 2017-06-26 18:05:28 --> Loader Class Initialized
INFO - 2017-06-26 18:05:28 --> Controller Class Initialized
INFO - 2017-06-26 18:05:28 --> Database Driver Class Initialized
INFO - 2017-06-26 18:05:28 --> Model Class Initialized
INFO - 2017-06-26 18:05:28 --> Helper loaded: form_helper
INFO - 2017-06-26 18:05:28 --> Helper loaded: url_helper
INFO - 2017-06-26 18:05:28 --> Model Class Initialized
INFO - 2017-06-26 18:05:28 --> Final output sent to browser
DEBUG - 2017-06-26 18:05:28 --> Total execution time: 0.1110
ERROR - 2017-06-26 18:05:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:05:33 --> Config Class Initialized
INFO - 2017-06-26 18:05:33 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:05:33 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:05:33 --> Utf8 Class Initialized
INFO - 2017-06-26 18:05:33 --> URI Class Initialized
INFO - 2017-06-26 18:05:33 --> Router Class Initialized
INFO - 2017-06-26 18:05:33 --> Output Class Initialized
INFO - 2017-06-26 18:05:33 --> Security Class Initialized
DEBUG - 2017-06-26 18:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:05:33 --> Input Class Initialized
INFO - 2017-06-26 18:05:33 --> Language Class Initialized
INFO - 2017-06-26 18:05:33 --> Loader Class Initialized
INFO - 2017-06-26 18:05:33 --> Controller Class Initialized
INFO - 2017-06-26 18:05:33 --> Database Driver Class Initialized
INFO - 2017-06-26 18:05:33 --> Model Class Initialized
INFO - 2017-06-26 18:05:33 --> Helper loaded: form_helper
INFO - 2017-06-26 18:05:33 --> Helper loaded: url_helper
INFO - 2017-06-26 18:05:33 --> Model Class Initialized
INFO - 2017-06-26 18:05:33 --> Final output sent to browser
DEBUG - 2017-06-26 18:05:33 --> Total execution time: 0.0780
ERROR - 2017-06-26 18:08:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:08:38 --> Config Class Initialized
INFO - 2017-06-26 18:08:38 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:08:38 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:08:38 --> Utf8 Class Initialized
INFO - 2017-06-26 18:08:38 --> URI Class Initialized
INFO - 2017-06-26 18:08:38 --> Router Class Initialized
INFO - 2017-06-26 18:08:38 --> Output Class Initialized
INFO - 2017-06-26 18:08:38 --> Security Class Initialized
DEBUG - 2017-06-26 18:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:08:38 --> Input Class Initialized
INFO - 2017-06-26 18:08:38 --> Language Class Initialized
INFO - 2017-06-26 18:08:38 --> Loader Class Initialized
INFO - 2017-06-26 18:08:38 --> Controller Class Initialized
INFO - 2017-06-26 18:08:38 --> Database Driver Class Initialized
INFO - 2017-06-26 18:08:38 --> Model Class Initialized
INFO - 2017-06-26 18:08:38 --> Helper loaded: form_helper
INFO - 2017-06-26 18:08:38 --> Helper loaded: url_helper
INFO - 2017-06-26 18:08:38 --> Model Class Initialized
INFO - 2017-06-26 18:08:38 --> Final output sent to browser
DEBUG - 2017-06-26 18:08:38 --> Total execution time: 0.0590
ERROR - 2017-06-26 18:08:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:08:50 --> Config Class Initialized
INFO - 2017-06-26 18:08:50 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:08:50 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:08:50 --> Utf8 Class Initialized
INFO - 2017-06-26 18:08:50 --> URI Class Initialized
INFO - 2017-06-26 18:08:50 --> Router Class Initialized
INFO - 2017-06-26 18:08:50 --> Output Class Initialized
INFO - 2017-06-26 18:08:50 --> Security Class Initialized
DEBUG - 2017-06-26 18:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:08:50 --> Input Class Initialized
INFO - 2017-06-26 18:08:50 --> Language Class Initialized
INFO - 2017-06-26 18:08:50 --> Loader Class Initialized
INFO - 2017-06-26 18:08:50 --> Controller Class Initialized
INFO - 2017-06-26 18:08:50 --> Database Driver Class Initialized
INFO - 2017-06-26 18:08:50 --> Model Class Initialized
INFO - 2017-06-26 18:08:50 --> Helper loaded: form_helper
INFO - 2017-06-26 18:08:50 --> Helper loaded: url_helper
INFO - 2017-06-26 18:08:50 --> Model Class Initialized
INFO - 2017-06-26 18:08:51 --> Final output sent to browser
DEBUG - 2017-06-26 18:08:51 --> Total execution time: 0.1070
ERROR - 2017-06-26 18:08:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:08:58 --> Config Class Initialized
INFO - 2017-06-26 18:08:58 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:08:58 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:08:58 --> Utf8 Class Initialized
INFO - 2017-06-26 18:08:58 --> URI Class Initialized
INFO - 2017-06-26 18:08:58 --> Router Class Initialized
INFO - 2017-06-26 18:08:58 --> Output Class Initialized
INFO - 2017-06-26 18:08:58 --> Security Class Initialized
DEBUG - 2017-06-26 18:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:08:58 --> Input Class Initialized
INFO - 2017-06-26 18:08:58 --> Language Class Initialized
INFO - 2017-06-26 18:08:58 --> Loader Class Initialized
INFO - 2017-06-26 18:08:58 --> Controller Class Initialized
INFO - 2017-06-26 18:08:58 --> Database Driver Class Initialized
INFO - 2017-06-26 18:08:58 --> Model Class Initialized
INFO - 2017-06-26 18:08:58 --> Helper loaded: form_helper
INFO - 2017-06-26 18:08:58 --> Helper loaded: url_helper
INFO - 2017-06-26 18:08:58 --> Model Class Initialized
INFO - 2017-06-26 18:08:58 --> Final output sent to browser
DEBUG - 2017-06-26 18:08:58 --> Total execution time: 0.0660
ERROR - 2017-06-26 18:09:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:09:00 --> Config Class Initialized
INFO - 2017-06-26 18:09:00 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:09:00 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:09:00 --> Utf8 Class Initialized
INFO - 2017-06-26 18:09:00 --> URI Class Initialized
INFO - 2017-06-26 18:09:00 --> Router Class Initialized
INFO - 2017-06-26 18:09:00 --> Output Class Initialized
INFO - 2017-06-26 18:09:00 --> Security Class Initialized
DEBUG - 2017-06-26 18:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:09:00 --> Input Class Initialized
INFO - 2017-06-26 18:09:00 --> Language Class Initialized
INFO - 2017-06-26 18:09:00 --> Loader Class Initialized
INFO - 2017-06-26 18:09:00 --> Controller Class Initialized
INFO - 2017-06-26 18:09:00 --> Database Driver Class Initialized
INFO - 2017-06-26 18:09:01 --> Model Class Initialized
INFO - 2017-06-26 18:09:01 --> Helper loaded: form_helper
INFO - 2017-06-26 18:09:01 --> Helper loaded: url_helper
INFO - 2017-06-26 18:09:01 --> Model Class Initialized
INFO - 2017-06-26 18:09:01 --> Final output sent to browser
DEBUG - 2017-06-26 18:09:01 --> Total execution time: 0.0940
ERROR - 2017-06-26 18:10:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:10:46 --> Config Class Initialized
INFO - 2017-06-26 18:10:46 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:10:46 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:10:46 --> Utf8 Class Initialized
INFO - 2017-06-26 18:10:46 --> URI Class Initialized
INFO - 2017-06-26 18:10:46 --> Router Class Initialized
INFO - 2017-06-26 18:10:46 --> Output Class Initialized
INFO - 2017-06-26 18:10:46 --> Security Class Initialized
DEBUG - 2017-06-26 18:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:10:46 --> Input Class Initialized
INFO - 2017-06-26 18:10:46 --> Language Class Initialized
INFO - 2017-06-26 18:10:46 --> Loader Class Initialized
INFO - 2017-06-26 18:10:46 --> Controller Class Initialized
INFO - 2017-06-26 18:10:46 --> Database Driver Class Initialized
INFO - 2017-06-26 18:10:46 --> Model Class Initialized
INFO - 2017-06-26 18:10:46 --> Helper loaded: form_helper
INFO - 2017-06-26 18:10:46 --> Helper loaded: url_helper
INFO - 2017-06-26 18:10:46 --> Model Class Initialized
INFO - 2017-06-26 18:10:46 --> Final output sent to browser
DEBUG - 2017-06-26 18:10:46 --> Total execution time: 0.0780
ERROR - 2017-06-26 18:12:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:12:07 --> Config Class Initialized
INFO - 2017-06-26 18:12:07 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:12:07 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:12:07 --> Utf8 Class Initialized
INFO - 2017-06-26 18:12:07 --> URI Class Initialized
INFO - 2017-06-26 18:12:07 --> Router Class Initialized
INFO - 2017-06-26 18:12:07 --> Output Class Initialized
INFO - 2017-06-26 18:12:07 --> Security Class Initialized
DEBUG - 2017-06-26 18:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:12:07 --> Input Class Initialized
INFO - 2017-06-26 18:12:07 --> Language Class Initialized
INFO - 2017-06-26 18:12:07 --> Loader Class Initialized
INFO - 2017-06-26 18:12:07 --> Controller Class Initialized
INFO - 2017-06-26 18:12:07 --> Database Driver Class Initialized
INFO - 2017-06-26 18:12:07 --> Model Class Initialized
INFO - 2017-06-26 18:12:07 --> Helper loaded: form_helper
INFO - 2017-06-26 18:12:07 --> Helper loaded: url_helper
INFO - 2017-06-26 18:12:07 --> Model Class Initialized
INFO - 2017-06-26 18:12:07 --> Final output sent to browser
DEBUG - 2017-06-26 18:12:07 --> Total execution time: 0.0720
ERROR - 2017-06-26 18:12:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:12:12 --> Config Class Initialized
INFO - 2017-06-26 18:12:12 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:12:12 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:12:12 --> Utf8 Class Initialized
INFO - 2017-06-26 18:12:12 --> URI Class Initialized
INFO - 2017-06-26 18:12:12 --> Router Class Initialized
INFO - 2017-06-26 18:12:12 --> Output Class Initialized
INFO - 2017-06-26 18:12:12 --> Security Class Initialized
DEBUG - 2017-06-26 18:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:12:12 --> Input Class Initialized
INFO - 2017-06-26 18:12:12 --> Language Class Initialized
INFO - 2017-06-26 18:12:12 --> Loader Class Initialized
INFO - 2017-06-26 18:12:12 --> Controller Class Initialized
INFO - 2017-06-26 18:12:12 --> Database Driver Class Initialized
INFO - 2017-06-26 18:12:12 --> Model Class Initialized
INFO - 2017-06-26 18:12:12 --> Helper loaded: form_helper
INFO - 2017-06-26 18:12:12 --> Helper loaded: url_helper
INFO - 2017-06-26 18:12:12 --> Model Class Initialized
INFO - 2017-06-26 18:12:12 --> Final output sent to browser
DEBUG - 2017-06-26 18:12:12 --> Total execution time: 0.0960
ERROR - 2017-06-26 18:12:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:12:15 --> Config Class Initialized
INFO - 2017-06-26 18:12:15 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:12:15 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:12:15 --> Utf8 Class Initialized
INFO - 2017-06-26 18:12:15 --> URI Class Initialized
INFO - 2017-06-26 18:12:15 --> Router Class Initialized
INFO - 2017-06-26 18:12:15 --> Output Class Initialized
INFO - 2017-06-26 18:12:15 --> Security Class Initialized
DEBUG - 2017-06-26 18:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:12:15 --> Input Class Initialized
INFO - 2017-06-26 18:12:15 --> Language Class Initialized
INFO - 2017-06-26 18:12:15 --> Loader Class Initialized
INFO - 2017-06-26 18:12:15 --> Controller Class Initialized
INFO - 2017-06-26 18:12:15 --> Database Driver Class Initialized
INFO - 2017-06-26 18:12:15 --> Model Class Initialized
INFO - 2017-06-26 18:12:15 --> Helper loaded: form_helper
INFO - 2017-06-26 18:12:15 --> Helper loaded: url_helper
INFO - 2017-06-26 18:12:15 --> Model Class Initialized
INFO - 2017-06-26 18:12:15 --> Final output sent to browser
DEBUG - 2017-06-26 18:12:15 --> Total execution time: 0.0510
ERROR - 2017-06-26 18:12:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:12:54 --> Config Class Initialized
INFO - 2017-06-26 18:12:54 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:12:54 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:12:54 --> Utf8 Class Initialized
INFO - 2017-06-26 18:12:54 --> URI Class Initialized
INFO - 2017-06-26 18:12:54 --> Router Class Initialized
INFO - 2017-06-26 18:12:54 --> Output Class Initialized
INFO - 2017-06-26 18:12:54 --> Security Class Initialized
DEBUG - 2017-06-26 18:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:12:54 --> Input Class Initialized
INFO - 2017-06-26 18:12:54 --> Language Class Initialized
INFO - 2017-06-26 18:12:54 --> Loader Class Initialized
INFO - 2017-06-26 18:12:54 --> Controller Class Initialized
INFO - 2017-06-26 18:12:54 --> Database Driver Class Initialized
INFO - 2017-06-26 18:12:54 --> Model Class Initialized
INFO - 2017-06-26 18:12:54 --> Helper loaded: form_helper
INFO - 2017-06-26 18:12:54 --> Helper loaded: url_helper
INFO - 2017-06-26 18:12:54 --> Model Class Initialized
INFO - 2017-06-26 18:12:54 --> Final output sent to browser
DEBUG - 2017-06-26 18:12:54 --> Total execution time: 0.0540
ERROR - 2017-06-26 18:12:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:12:55 --> Config Class Initialized
INFO - 2017-06-26 18:12:55 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:12:55 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:12:55 --> Utf8 Class Initialized
INFO - 2017-06-26 18:12:55 --> URI Class Initialized
INFO - 2017-06-26 18:12:55 --> Router Class Initialized
INFO - 2017-06-26 18:12:56 --> Output Class Initialized
INFO - 2017-06-26 18:12:56 --> Security Class Initialized
DEBUG - 2017-06-26 18:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:12:56 --> Input Class Initialized
INFO - 2017-06-26 18:12:56 --> Language Class Initialized
INFO - 2017-06-26 18:12:56 --> Loader Class Initialized
INFO - 2017-06-26 18:12:56 --> Controller Class Initialized
INFO - 2017-06-26 18:12:56 --> Database Driver Class Initialized
INFO - 2017-06-26 18:12:56 --> Model Class Initialized
INFO - 2017-06-26 18:12:56 --> Helper loaded: form_helper
INFO - 2017-06-26 18:12:56 --> Helper loaded: url_helper
INFO - 2017-06-26 18:12:56 --> Model Class Initialized
INFO - 2017-06-26 18:12:56 --> Final output sent to browser
DEBUG - 2017-06-26 18:12:56 --> Total execution time: 0.0590
ERROR - 2017-06-26 18:16:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:16:14 --> Config Class Initialized
INFO - 2017-06-26 18:16:14 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:16:14 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:16:14 --> Utf8 Class Initialized
INFO - 2017-06-26 18:16:14 --> URI Class Initialized
INFO - 2017-06-26 18:16:14 --> Router Class Initialized
INFO - 2017-06-26 18:16:14 --> Output Class Initialized
INFO - 2017-06-26 18:16:14 --> Security Class Initialized
DEBUG - 2017-06-26 18:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:16:14 --> Input Class Initialized
INFO - 2017-06-26 18:16:14 --> Language Class Initialized
INFO - 2017-06-26 18:16:14 --> Loader Class Initialized
INFO - 2017-06-26 18:16:14 --> Controller Class Initialized
INFO - 2017-06-26 18:16:14 --> Database Driver Class Initialized
INFO - 2017-06-26 18:16:14 --> Model Class Initialized
INFO - 2017-06-26 18:16:14 --> Helper loaded: form_helper
INFO - 2017-06-26 18:16:14 --> Helper loaded: url_helper
INFO - 2017-06-26 18:16:14 --> Model Class Initialized
INFO - 2017-06-26 18:16:14 --> Final output sent to browser
DEBUG - 2017-06-26 18:16:14 --> Total execution time: 0.0680
ERROR - 2017-06-26 18:16:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:16:15 --> Config Class Initialized
INFO - 2017-06-26 18:16:15 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:16:15 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:16:15 --> Utf8 Class Initialized
INFO - 2017-06-26 18:16:15 --> URI Class Initialized
INFO - 2017-06-26 18:16:15 --> Router Class Initialized
INFO - 2017-06-26 18:16:15 --> Output Class Initialized
INFO - 2017-06-26 18:16:15 --> Security Class Initialized
DEBUG - 2017-06-26 18:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:16:15 --> Input Class Initialized
INFO - 2017-06-26 18:16:15 --> Language Class Initialized
INFO - 2017-06-26 18:16:15 --> Loader Class Initialized
INFO - 2017-06-26 18:16:15 --> Controller Class Initialized
INFO - 2017-06-26 18:16:15 --> Database Driver Class Initialized
INFO - 2017-06-26 18:16:15 --> Model Class Initialized
INFO - 2017-06-26 18:16:15 --> Helper loaded: form_helper
INFO - 2017-06-26 18:16:15 --> Helper loaded: url_helper
INFO - 2017-06-26 18:16:15 --> Model Class Initialized
INFO - 2017-06-26 18:16:15 --> Final output sent to browser
DEBUG - 2017-06-26 18:16:15 --> Total execution time: 0.0470
ERROR - 2017-06-26 18:16:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:16:24 --> Config Class Initialized
INFO - 2017-06-26 18:16:24 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:16:24 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:16:24 --> Utf8 Class Initialized
INFO - 2017-06-26 18:16:24 --> URI Class Initialized
INFO - 2017-06-26 18:16:24 --> Router Class Initialized
INFO - 2017-06-26 18:16:24 --> Output Class Initialized
INFO - 2017-06-26 18:16:24 --> Security Class Initialized
DEBUG - 2017-06-26 18:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:16:24 --> Input Class Initialized
INFO - 2017-06-26 18:16:24 --> Language Class Initialized
INFO - 2017-06-26 18:16:24 --> Loader Class Initialized
INFO - 2017-06-26 18:16:24 --> Controller Class Initialized
INFO - 2017-06-26 18:16:24 --> Database Driver Class Initialized
INFO - 2017-06-26 18:16:24 --> Model Class Initialized
INFO - 2017-06-26 18:16:24 --> Helper loaded: form_helper
INFO - 2017-06-26 18:16:24 --> Helper loaded: url_helper
INFO - 2017-06-26 18:16:24 --> Model Class Initialized
ERROR - 2017-06-26 18:16:24 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\mystage\application\models\Mobile_model.php 55
INFO - 2017-06-26 18:16:24 --> Final output sent to browser
DEBUG - 2017-06-26 18:16:24 --> Total execution time: 0.0550
ERROR - 2017-06-26 18:17:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:17:21 --> Config Class Initialized
INFO - 2017-06-26 18:17:21 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:17:21 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:17:21 --> Utf8 Class Initialized
INFO - 2017-06-26 18:17:21 --> URI Class Initialized
INFO - 2017-06-26 18:17:21 --> Router Class Initialized
INFO - 2017-06-26 18:17:21 --> Output Class Initialized
INFO - 2017-06-26 18:17:21 --> Security Class Initialized
DEBUG - 2017-06-26 18:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:17:21 --> Input Class Initialized
INFO - 2017-06-26 18:17:21 --> Language Class Initialized
INFO - 2017-06-26 18:17:21 --> Loader Class Initialized
INFO - 2017-06-26 18:17:21 --> Controller Class Initialized
INFO - 2017-06-26 18:17:21 --> Database Driver Class Initialized
INFO - 2017-06-26 18:17:21 --> Model Class Initialized
INFO - 2017-06-26 18:17:21 --> Helper loaded: form_helper
INFO - 2017-06-26 18:17:21 --> Helper loaded: url_helper
INFO - 2017-06-26 18:17:21 --> Model Class Initialized
ERROR - 2017-06-26 18:17:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\mystage\application\models\Mobile_model.php 55
INFO - 2017-06-26 18:17:21 --> Final output sent to browser
DEBUG - 2017-06-26 18:17:21 --> Total execution time: 0.1040
ERROR - 2017-06-26 18:17:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:17:47 --> Config Class Initialized
INFO - 2017-06-26 18:17:47 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:17:47 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:17:47 --> Utf8 Class Initialized
INFO - 2017-06-26 18:17:47 --> URI Class Initialized
INFO - 2017-06-26 18:17:47 --> Router Class Initialized
INFO - 2017-06-26 18:17:47 --> Output Class Initialized
INFO - 2017-06-26 18:17:47 --> Security Class Initialized
DEBUG - 2017-06-26 18:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:17:47 --> Input Class Initialized
INFO - 2017-06-26 18:17:47 --> Language Class Initialized
INFO - 2017-06-26 18:17:47 --> Loader Class Initialized
INFO - 2017-06-26 18:17:47 --> Controller Class Initialized
INFO - 2017-06-26 18:17:47 --> Database Driver Class Initialized
INFO - 2017-06-26 18:17:47 --> Model Class Initialized
INFO - 2017-06-26 18:17:47 --> Helper loaded: form_helper
INFO - 2017-06-26 18:17:47 --> Helper loaded: url_helper
INFO - 2017-06-26 18:17:47 --> Model Class Initialized
INFO - 2017-06-26 18:17:47 --> Final output sent to browser
DEBUG - 2017-06-26 18:17:47 --> Total execution time: 0.0870
ERROR - 2017-06-26 18:18:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:18:16 --> Config Class Initialized
INFO - 2017-06-26 18:18:16 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:18:16 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:18:16 --> Utf8 Class Initialized
INFO - 2017-06-26 18:18:16 --> URI Class Initialized
INFO - 2017-06-26 18:18:16 --> Router Class Initialized
INFO - 2017-06-26 18:18:16 --> Output Class Initialized
INFO - 2017-06-26 18:18:16 --> Security Class Initialized
DEBUG - 2017-06-26 18:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:18:16 --> Input Class Initialized
INFO - 2017-06-26 18:18:16 --> Language Class Initialized
INFO - 2017-06-26 18:18:16 --> Loader Class Initialized
INFO - 2017-06-26 18:18:16 --> Controller Class Initialized
INFO - 2017-06-26 18:18:16 --> Database Driver Class Initialized
INFO - 2017-06-26 18:18:16 --> Model Class Initialized
INFO - 2017-06-26 18:18:16 --> Helper loaded: form_helper
INFO - 2017-06-26 18:18:16 --> Helper loaded: url_helper
INFO - 2017-06-26 18:18:16 --> Model Class Initialized
INFO - 2017-06-26 18:18:16 --> Final output sent to browser
DEBUG - 2017-06-26 18:18:16 --> Total execution time: 0.0560
ERROR - 2017-06-26 18:18:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:18:48 --> Config Class Initialized
INFO - 2017-06-26 18:18:48 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:18:48 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:18:48 --> Utf8 Class Initialized
INFO - 2017-06-26 18:18:48 --> URI Class Initialized
INFO - 2017-06-26 18:18:48 --> Router Class Initialized
INFO - 2017-06-26 18:18:48 --> Output Class Initialized
INFO - 2017-06-26 18:18:48 --> Security Class Initialized
DEBUG - 2017-06-26 18:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:18:48 --> Input Class Initialized
INFO - 2017-06-26 18:18:48 --> Language Class Initialized
INFO - 2017-06-26 18:18:48 --> Loader Class Initialized
INFO - 2017-06-26 18:18:48 --> Controller Class Initialized
INFO - 2017-06-26 18:18:48 --> Database Driver Class Initialized
INFO - 2017-06-26 18:18:48 --> Model Class Initialized
INFO - 2017-06-26 18:18:48 --> Helper loaded: form_helper
INFO - 2017-06-26 18:18:48 --> Helper loaded: url_helper
INFO - 2017-06-26 18:18:48 --> Model Class Initialized
INFO - 2017-06-26 18:18:48 --> Final output sent to browser
DEBUG - 2017-06-26 18:18:48 --> Total execution time: 0.1060
ERROR - 2017-06-26 18:18:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:18:48 --> Config Class Initialized
INFO - 2017-06-26 18:18:48 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:18:48 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:18:48 --> Utf8 Class Initialized
INFO - 2017-06-26 18:18:48 --> URI Class Initialized
INFO - 2017-06-26 18:18:48 --> Router Class Initialized
INFO - 2017-06-26 18:18:48 --> Output Class Initialized
INFO - 2017-06-26 18:18:48 --> Security Class Initialized
DEBUG - 2017-06-26 18:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:18:48 --> Input Class Initialized
INFO - 2017-06-26 18:18:48 --> Language Class Initialized
INFO - 2017-06-26 18:18:48 --> Loader Class Initialized
INFO - 2017-06-26 18:18:48 --> Controller Class Initialized
INFO - 2017-06-26 18:18:48 --> Database Driver Class Initialized
INFO - 2017-06-26 18:18:48 --> Model Class Initialized
INFO - 2017-06-26 18:18:48 --> Helper loaded: form_helper
INFO - 2017-06-26 18:18:48 --> Helper loaded: url_helper
INFO - 2017-06-26 18:18:48 --> Model Class Initialized
INFO - 2017-06-26 18:18:48 --> Final output sent to browser
DEBUG - 2017-06-26 18:18:48 --> Total execution time: 0.0510
ERROR - 2017-06-26 18:19:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:19:06 --> Config Class Initialized
INFO - 2017-06-26 18:19:06 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:19:06 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:19:06 --> Utf8 Class Initialized
INFO - 2017-06-26 18:19:06 --> URI Class Initialized
INFO - 2017-06-26 18:19:06 --> Router Class Initialized
INFO - 2017-06-26 18:19:06 --> Output Class Initialized
INFO - 2017-06-26 18:19:06 --> Security Class Initialized
DEBUG - 2017-06-26 18:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:19:06 --> Input Class Initialized
INFO - 2017-06-26 18:19:06 --> Language Class Initialized
INFO - 2017-06-26 18:19:06 --> Loader Class Initialized
INFO - 2017-06-26 18:19:06 --> Controller Class Initialized
INFO - 2017-06-26 18:19:06 --> Database Driver Class Initialized
INFO - 2017-06-26 18:19:06 --> Model Class Initialized
INFO - 2017-06-26 18:19:06 --> Helper loaded: form_helper
INFO - 2017-06-26 18:19:06 --> Helper loaded: url_helper
INFO - 2017-06-26 18:19:06 --> Model Class Initialized
INFO - 2017-06-26 18:19:06 --> Final output sent to browser
DEBUG - 2017-06-26 18:19:06 --> Total execution time: 0.1020
ERROR - 2017-06-26 18:19:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:19:15 --> Config Class Initialized
INFO - 2017-06-26 18:19:15 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:19:15 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:19:15 --> Utf8 Class Initialized
INFO - 2017-06-26 18:19:15 --> URI Class Initialized
INFO - 2017-06-26 18:19:15 --> Router Class Initialized
INFO - 2017-06-26 18:19:15 --> Output Class Initialized
INFO - 2017-06-26 18:19:15 --> Security Class Initialized
DEBUG - 2017-06-26 18:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:19:15 --> Input Class Initialized
INFO - 2017-06-26 18:19:15 --> Language Class Initialized
INFO - 2017-06-26 18:19:15 --> Loader Class Initialized
INFO - 2017-06-26 18:19:15 --> Controller Class Initialized
INFO - 2017-06-26 18:19:15 --> Database Driver Class Initialized
INFO - 2017-06-26 18:19:15 --> Model Class Initialized
INFO - 2017-06-26 18:19:15 --> Helper loaded: form_helper
INFO - 2017-06-26 18:19:15 --> Helper loaded: url_helper
INFO - 2017-06-26 18:19:15 --> Model Class Initialized
INFO - 2017-06-26 18:19:15 --> Final output sent to browser
DEBUG - 2017-06-26 18:19:15 --> Total execution time: 0.0970
ERROR - 2017-06-26 18:19:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-26 18:19:15 --> Config Class Initialized
INFO - 2017-06-26 18:19:15 --> Hooks Class Initialized
DEBUG - 2017-06-26 18:19:15 --> UTF-8 Support Enabled
INFO - 2017-06-26 18:19:15 --> Utf8 Class Initialized
INFO - 2017-06-26 18:19:15 --> URI Class Initialized
INFO - 2017-06-26 18:19:15 --> Router Class Initialized
INFO - 2017-06-26 18:19:15 --> Output Class Initialized
INFO - 2017-06-26 18:19:15 --> Security Class Initialized
DEBUG - 2017-06-26 18:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-26 18:19:15 --> Input Class Initialized
INFO - 2017-06-26 18:19:15 --> Language Class Initialized
INFO - 2017-06-26 18:19:15 --> Loader Class Initialized
INFO - 2017-06-26 18:19:15 --> Controller Class Initialized
INFO - 2017-06-26 18:19:15 --> Database Driver Class Initialized
INFO - 2017-06-26 18:19:15 --> Model Class Initialized
INFO - 2017-06-26 18:19:15 --> Helper loaded: form_helper
INFO - 2017-06-26 18:19:15 --> Helper loaded: url_helper
INFO - 2017-06-26 18:19:16 --> Model Class Initialized
INFO - 2017-06-26 18:19:16 --> Final output sent to browser
DEBUG - 2017-06-26 18:19:16 --> Total execution time: 0.1490
