<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-23 17:41:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-23 17:41:24 --> Config Class Initialized
INFO - 2017-08-23 17:41:24 --> Hooks Class Initialized
DEBUG - 2017-08-23 17:41:24 --> UTF-8 Support Enabled
INFO - 2017-08-23 17:41:24 --> Utf8 Class Initialized
INFO - 2017-08-23 17:41:24 --> URI Class Initialized
DEBUG - 2017-08-23 17:41:24 --> No URI present. Default controller set.
INFO - 2017-08-23 17:41:24 --> Router Class Initialized
INFO - 2017-08-23 17:41:24 --> Output Class Initialized
INFO - 2017-08-23 17:41:24 --> Security Class Initialized
DEBUG - 2017-08-23 17:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-23 17:41:24 --> Input Class Initialized
INFO - 2017-08-23 17:41:24 --> Language Class Initialized
INFO - 2017-08-23 17:41:24 --> Loader Class Initialized
INFO - 2017-08-23 17:41:24 --> Controller Class Initialized
INFO - 2017-08-23 17:41:24 --> Database Driver Class Initialized
INFO - 2017-08-23 17:41:25 --> Model Class Initialized
INFO - 2017-08-23 17:41:25 --> Helper loaded: form_helper
INFO - 2017-08-23 17:41:25 --> Helper loaded: url_helper
INFO - 2017-08-23 17:41:25 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-08-23 17:41:25 --> Final output sent to browser
DEBUG - 2017-08-23 17:41:25 --> Total execution time: 0.9831
ERROR - 2017-08-23 17:41:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-23 17:41:46 --> Config Class Initialized
INFO - 2017-08-23 17:41:46 --> Hooks Class Initialized
DEBUG - 2017-08-23 17:41:46 --> UTF-8 Support Enabled
INFO - 2017-08-23 17:41:46 --> Utf8 Class Initialized
INFO - 2017-08-23 17:41:46 --> URI Class Initialized
INFO - 2017-08-23 17:41:46 --> Router Class Initialized
INFO - 2017-08-23 17:41:46 --> Output Class Initialized
INFO - 2017-08-23 17:41:46 --> Security Class Initialized
DEBUG - 2017-08-23 17:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-23 17:41:46 --> Input Class Initialized
INFO - 2017-08-23 17:41:46 --> Language Class Initialized
INFO - 2017-08-23 17:41:46 --> Loader Class Initialized
INFO - 2017-08-23 17:41:46 --> Controller Class Initialized
INFO - 2017-08-23 17:41:46 --> Database Driver Class Initialized
INFO - 2017-08-23 17:41:46 --> Model Class Initialized
INFO - 2017-08-23 17:41:46 --> Helper loaded: form_helper
INFO - 2017-08-23 17:41:46 --> Helper loaded: url_helper
INFO - 2017-08-23 17:41:46 --> Model Class Initialized
ERROR - 2017-08-23 17:41:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-23 17:41:46 --> Config Class Initialized
INFO - 2017-08-23 17:41:46 --> Hooks Class Initialized
DEBUG - 2017-08-23 17:41:46 --> UTF-8 Support Enabled
INFO - 2017-08-23 17:41:46 --> Utf8 Class Initialized
INFO - 2017-08-23 17:41:46 --> URI Class Initialized
INFO - 2017-08-23 17:41:46 --> Router Class Initialized
INFO - 2017-08-23 17:41:46 --> Output Class Initialized
INFO - 2017-08-23 17:41:46 --> Security Class Initialized
DEBUG - 2017-08-23 17:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-23 17:41:46 --> Input Class Initialized
INFO - 2017-08-23 17:41:46 --> Language Class Initialized
INFO - 2017-08-23 17:41:46 --> Loader Class Initialized
INFO - 2017-08-23 17:41:46 --> Controller Class Initialized
INFO - 2017-08-23 17:41:46 --> Database Driver Class Initialized
INFO - 2017-08-23 17:41:46 --> Model Class Initialized
INFO - 2017-08-23 17:41:46 --> Helper loaded: form_helper
INFO - 2017-08-23 17:41:46 --> Helper loaded: url_helper
INFO - 2017-08-23 17:41:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-23 17:41:46 --> Model Class Initialized
INFO - 2017-08-23 17:41:46 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-08-23 17:41:46 --> Final output sent to browser
DEBUG - 2017-08-23 17:41:46 --> Total execution time: 0.1140
ERROR - 2017-08-23 17:41:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-23 17:41:48 --> Config Class Initialized
INFO - 2017-08-23 17:41:48 --> Hooks Class Initialized
DEBUG - 2017-08-23 17:41:48 --> UTF-8 Support Enabled
INFO - 2017-08-23 17:41:48 --> Utf8 Class Initialized
INFO - 2017-08-23 17:41:48 --> URI Class Initialized
INFO - 2017-08-23 17:41:48 --> Router Class Initialized
INFO - 2017-08-23 17:41:48 --> Output Class Initialized
INFO - 2017-08-23 17:41:48 --> Security Class Initialized
DEBUG - 2017-08-23 17:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-23 17:41:48 --> Input Class Initialized
INFO - 2017-08-23 17:41:48 --> Language Class Initialized
INFO - 2017-08-23 17:41:48 --> Loader Class Initialized
INFO - 2017-08-23 17:41:48 --> Controller Class Initialized
INFO - 2017-08-23 17:41:48 --> Database Driver Class Initialized
INFO - 2017-08-23 17:41:48 --> Model Class Initialized
INFO - 2017-08-23 17:41:48 --> Helper loaded: form_helper
INFO - 2017-08-23 17:41:48 --> Helper loaded: url_helper
INFO - 2017-08-23 17:41:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-23 17:41:48 --> Model Class Initialized
INFO - 2017-08-23 17:41:48 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-08-23 17:41:48 --> Final output sent to browser
DEBUG - 2017-08-23 17:41:48 --> Total execution time: 0.1010
