<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-19 00:22:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 00:22:47 --> Config Class Initialized
INFO - 2017-07-19 00:22:47 --> Hooks Class Initialized
DEBUG - 2017-07-19 00:22:47 --> UTF-8 Support Enabled
INFO - 2017-07-19 00:22:47 --> Utf8 Class Initialized
INFO - 2017-07-19 00:22:47 --> URI Class Initialized
INFO - 2017-07-19 00:22:47 --> Router Class Initialized
INFO - 2017-07-19 00:22:47 --> Output Class Initialized
INFO - 2017-07-19 00:22:47 --> Security Class Initialized
DEBUG - 2017-07-19 00:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 00:22:47 --> Input Class Initialized
INFO - 2017-07-19 00:22:47 --> Language Class Initialized
INFO - 2017-07-19 00:22:47 --> Loader Class Initialized
INFO - 2017-07-19 00:22:47 --> Controller Class Initialized
INFO - 2017-07-19 00:22:47 --> Database Driver Class Initialized
INFO - 2017-07-19 00:22:47 --> Model Class Initialized
INFO - 2017-07-19 00:22:47 --> Helper loaded: form_helper
INFO - 2017-07-19 00:22:47 --> Helper loaded: url_helper
INFO - 2017-07-19 00:22:47 --> Model Class Initialized
INFO - 2017-07-19 00:22:47 --> Final output sent to browser
DEBUG - 2017-07-19 00:22:47 --> Total execution time: 0.0853
ERROR - 2017-07-19 00:22:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 00:22:48 --> Config Class Initialized
INFO - 2017-07-19 00:22:48 --> Hooks Class Initialized
DEBUG - 2017-07-19 00:22:48 --> UTF-8 Support Enabled
INFO - 2017-07-19 00:22:48 --> Utf8 Class Initialized
INFO - 2017-07-19 00:22:48 --> URI Class Initialized
INFO - 2017-07-19 00:22:48 --> Router Class Initialized
INFO - 2017-07-19 00:22:48 --> Output Class Initialized
INFO - 2017-07-19 00:22:48 --> Security Class Initialized
DEBUG - 2017-07-19 00:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 00:22:48 --> Input Class Initialized
INFO - 2017-07-19 00:22:48 --> Language Class Initialized
INFO - 2017-07-19 00:22:48 --> Loader Class Initialized
INFO - 2017-07-19 00:22:48 --> Controller Class Initialized
INFO - 2017-07-19 00:22:48 --> Database Driver Class Initialized
INFO - 2017-07-19 00:22:48 --> Model Class Initialized
INFO - 2017-07-19 00:22:48 --> Helper loaded: form_helper
INFO - 2017-07-19 00:22:48 --> Helper loaded: url_helper
INFO - 2017-07-19 00:22:48 --> Model Class Initialized
INFO - 2017-07-19 00:22:48 --> Final output sent to browser
DEBUG - 2017-07-19 00:22:48 --> Total execution time: 0.0537
ERROR - 2017-07-19 02:27:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:27:11 --> Config Class Initialized
INFO - 2017-07-19 02:27:11 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:27:11 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:27:11 --> Utf8 Class Initialized
INFO - 2017-07-19 02:27:11 --> URI Class Initialized
INFO - 2017-07-19 02:27:11 --> Router Class Initialized
INFO - 2017-07-19 02:27:11 --> Output Class Initialized
INFO - 2017-07-19 02:27:11 --> Security Class Initialized
DEBUG - 2017-07-19 02:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:27:11 --> Input Class Initialized
INFO - 2017-07-19 02:27:11 --> Language Class Initialized
INFO - 2017-07-19 02:27:11 --> Loader Class Initialized
INFO - 2017-07-19 02:27:11 --> Controller Class Initialized
INFO - 2017-07-19 02:27:11 --> Database Driver Class Initialized
INFO - 2017-07-19 02:27:11 --> Model Class Initialized
INFO - 2017-07-19 02:27:11 --> Helper loaded: form_helper
INFO - 2017-07-19 02:27:11 --> Helper loaded: url_helper
INFO - 2017-07-19 02:27:11 --> Model Class Initialized
INFO - 2017-07-19 02:27:11 --> Final output sent to browser
DEBUG - 2017-07-19 02:27:11 --> Total execution time: 0.0820
ERROR - 2017-07-19 02:27:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:27:12 --> Config Class Initialized
INFO - 2017-07-19 02:27:12 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:27:12 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:27:12 --> Utf8 Class Initialized
INFO - 2017-07-19 02:27:12 --> URI Class Initialized
INFO - 2017-07-19 02:27:12 --> Router Class Initialized
INFO - 2017-07-19 02:27:12 --> Output Class Initialized
INFO - 2017-07-19 02:27:12 --> Security Class Initialized
DEBUG - 2017-07-19 02:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:27:12 --> Input Class Initialized
INFO - 2017-07-19 02:27:12 --> Language Class Initialized
INFO - 2017-07-19 02:27:12 --> Loader Class Initialized
INFO - 2017-07-19 02:27:12 --> Controller Class Initialized
INFO - 2017-07-19 02:27:12 --> Database Driver Class Initialized
INFO - 2017-07-19 02:27:12 --> Model Class Initialized
INFO - 2017-07-19 02:27:12 --> Helper loaded: form_helper
INFO - 2017-07-19 02:27:12 --> Helper loaded: url_helper
INFO - 2017-07-19 02:27:12 --> Model Class Initialized
INFO - 2017-07-19 02:27:12 --> Final output sent to browser
DEBUG - 2017-07-19 02:27:12 --> Total execution time: 0.0480
ERROR - 2017-07-19 02:27:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:27:14 --> Config Class Initialized
INFO - 2017-07-19 02:27:14 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:27:14 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:27:14 --> Utf8 Class Initialized
INFO - 2017-07-19 02:27:14 --> URI Class Initialized
INFO - 2017-07-19 02:27:14 --> Router Class Initialized
INFO - 2017-07-19 02:27:14 --> Output Class Initialized
INFO - 2017-07-19 02:27:14 --> Security Class Initialized
DEBUG - 2017-07-19 02:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:27:14 --> Input Class Initialized
INFO - 2017-07-19 02:27:14 --> Language Class Initialized
INFO - 2017-07-19 02:27:14 --> Loader Class Initialized
INFO - 2017-07-19 02:27:14 --> Controller Class Initialized
INFO - 2017-07-19 02:27:14 --> Database Driver Class Initialized
INFO - 2017-07-19 02:27:14 --> Model Class Initialized
INFO - 2017-07-19 02:27:14 --> Helper loaded: form_helper
INFO - 2017-07-19 02:27:14 --> Helper loaded: url_helper
INFO - 2017-07-19 02:27:14 --> Model Class Initialized
INFO - 2017-07-19 02:27:14 --> Final output sent to browser
DEBUG - 2017-07-19 02:27:14 --> Total execution time: 0.1010
ERROR - 2017-07-19 02:28:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:28:09 --> Config Class Initialized
INFO - 2017-07-19 02:28:09 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:28:09 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:28:09 --> Utf8 Class Initialized
INFO - 2017-07-19 02:28:09 --> URI Class Initialized
INFO - 2017-07-19 02:28:09 --> Router Class Initialized
INFO - 2017-07-19 02:28:09 --> Output Class Initialized
INFO - 2017-07-19 02:28:09 --> Security Class Initialized
DEBUG - 2017-07-19 02:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:28:09 --> Input Class Initialized
INFO - 2017-07-19 02:28:09 --> Language Class Initialized
INFO - 2017-07-19 02:28:09 --> Loader Class Initialized
INFO - 2017-07-19 02:28:09 --> Controller Class Initialized
INFO - 2017-07-19 02:28:09 --> Database Driver Class Initialized
INFO - 2017-07-19 02:28:09 --> Model Class Initialized
INFO - 2017-07-19 02:28:09 --> Helper loaded: form_helper
INFO - 2017-07-19 02:28:09 --> Helper loaded: url_helper
INFO - 2017-07-19 02:28:09 --> Model Class Initialized
INFO - 2017-07-19 02:28:09 --> Final output sent to browser
DEBUG - 2017-07-19 02:28:09 --> Total execution time: 0.0970
ERROR - 2017-07-19 02:28:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:28:09 --> Config Class Initialized
INFO - 2017-07-19 02:28:09 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:28:09 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:28:09 --> Utf8 Class Initialized
INFO - 2017-07-19 02:28:09 --> URI Class Initialized
INFO - 2017-07-19 02:28:09 --> Router Class Initialized
INFO - 2017-07-19 02:28:09 --> Output Class Initialized
INFO - 2017-07-19 02:28:09 --> Security Class Initialized
DEBUG - 2017-07-19 02:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:28:09 --> Input Class Initialized
INFO - 2017-07-19 02:28:09 --> Language Class Initialized
INFO - 2017-07-19 02:28:09 --> Loader Class Initialized
INFO - 2017-07-19 02:28:09 --> Controller Class Initialized
INFO - 2017-07-19 02:28:09 --> Database Driver Class Initialized
INFO - 2017-07-19 02:28:09 --> Model Class Initialized
INFO - 2017-07-19 02:28:09 --> Helper loaded: form_helper
INFO - 2017-07-19 02:28:09 --> Helper loaded: url_helper
INFO - 2017-07-19 02:28:09 --> Model Class Initialized
INFO - 2017-07-19 02:28:09 --> Final output sent to browser
DEBUG - 2017-07-19 02:28:09 --> Total execution time: 0.0600
ERROR - 2017-07-19 02:28:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:28:30 --> Config Class Initialized
INFO - 2017-07-19 02:28:30 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:28:30 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:28:30 --> Utf8 Class Initialized
INFO - 2017-07-19 02:28:30 --> URI Class Initialized
INFO - 2017-07-19 02:28:30 --> Router Class Initialized
INFO - 2017-07-19 02:28:30 --> Output Class Initialized
INFO - 2017-07-19 02:28:30 --> Security Class Initialized
DEBUG - 2017-07-19 02:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:28:30 --> Input Class Initialized
INFO - 2017-07-19 02:28:30 --> Language Class Initialized
INFO - 2017-07-19 02:28:30 --> Loader Class Initialized
INFO - 2017-07-19 02:28:30 --> Controller Class Initialized
INFO - 2017-07-19 02:28:30 --> Database Driver Class Initialized
INFO - 2017-07-19 02:28:30 --> Model Class Initialized
INFO - 2017-07-19 02:28:30 --> Helper loaded: form_helper
INFO - 2017-07-19 02:28:30 --> Helper loaded: url_helper
INFO - 2017-07-19 02:28:30 --> Model Class Initialized
INFO - 2017-07-19 02:28:30 --> Final output sent to browser
DEBUG - 2017-07-19 02:28:30 --> Total execution time: 0.0580
ERROR - 2017-07-19 02:28:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:28:37 --> Config Class Initialized
INFO - 2017-07-19 02:28:37 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:28:37 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:28:37 --> Utf8 Class Initialized
INFO - 2017-07-19 02:28:37 --> URI Class Initialized
INFO - 2017-07-19 02:28:37 --> Router Class Initialized
INFO - 2017-07-19 02:28:37 --> Output Class Initialized
INFO - 2017-07-19 02:28:37 --> Security Class Initialized
DEBUG - 2017-07-19 02:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:28:37 --> Input Class Initialized
INFO - 2017-07-19 02:28:37 --> Language Class Initialized
INFO - 2017-07-19 02:28:37 --> Loader Class Initialized
INFO - 2017-07-19 02:28:37 --> Controller Class Initialized
INFO - 2017-07-19 02:28:37 --> Database Driver Class Initialized
INFO - 2017-07-19 02:28:37 --> Model Class Initialized
INFO - 2017-07-19 02:28:37 --> Helper loaded: form_helper
INFO - 2017-07-19 02:28:37 --> Helper loaded: url_helper
INFO - 2017-07-19 02:28:37 --> Model Class Initialized
INFO - 2017-07-19 02:28:37 --> Final output sent to browser
DEBUG - 2017-07-19 02:28:37 --> Total execution time: 0.0700
ERROR - 2017-07-19 02:29:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:29:24 --> Config Class Initialized
INFO - 2017-07-19 02:29:24 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:29:24 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:29:24 --> Utf8 Class Initialized
INFO - 2017-07-19 02:29:24 --> URI Class Initialized
INFO - 2017-07-19 02:29:24 --> Router Class Initialized
INFO - 2017-07-19 02:29:24 --> Output Class Initialized
INFO - 2017-07-19 02:29:24 --> Security Class Initialized
DEBUG - 2017-07-19 02:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:29:24 --> Input Class Initialized
INFO - 2017-07-19 02:29:24 --> Language Class Initialized
INFO - 2017-07-19 02:29:24 --> Loader Class Initialized
INFO - 2017-07-19 02:29:24 --> Controller Class Initialized
INFO - 2017-07-19 02:29:24 --> Database Driver Class Initialized
INFO - 2017-07-19 02:29:24 --> Model Class Initialized
INFO - 2017-07-19 02:29:24 --> Helper loaded: form_helper
INFO - 2017-07-19 02:29:24 --> Helper loaded: url_helper
INFO - 2017-07-19 02:29:24 --> Model Class Initialized
INFO - 2017-07-19 02:29:24 --> Final output sent to browser
DEBUG - 2017-07-19 02:29:24 --> Total execution time: 0.0640
ERROR - 2017-07-19 02:32:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:32:19 --> Config Class Initialized
INFO - 2017-07-19 02:32:19 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:32:19 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:32:19 --> Utf8 Class Initialized
INFO - 2017-07-19 02:32:19 --> URI Class Initialized
INFO - 2017-07-19 02:32:19 --> Router Class Initialized
INFO - 2017-07-19 02:32:19 --> Output Class Initialized
INFO - 2017-07-19 02:32:19 --> Security Class Initialized
DEBUG - 2017-07-19 02:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:32:19 --> Input Class Initialized
INFO - 2017-07-19 02:32:19 --> Language Class Initialized
INFO - 2017-07-19 02:32:19 --> Loader Class Initialized
INFO - 2017-07-19 02:32:19 --> Controller Class Initialized
INFO - 2017-07-19 02:32:19 --> Database Driver Class Initialized
INFO - 2017-07-19 02:32:19 --> Model Class Initialized
INFO - 2017-07-19 02:32:20 --> Helper loaded: form_helper
INFO - 2017-07-19 02:32:20 --> Helper loaded: url_helper
INFO - 2017-07-19 02:32:20 --> Model Class Initialized
INFO - 2017-07-19 02:32:20 --> Final output sent to browser
DEBUG - 2017-07-19 02:32:20 --> Total execution time: 0.1080
ERROR - 2017-07-19 02:32:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:32:21 --> Config Class Initialized
INFO - 2017-07-19 02:32:21 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:32:21 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:32:21 --> Utf8 Class Initialized
INFO - 2017-07-19 02:32:21 --> URI Class Initialized
INFO - 2017-07-19 02:32:21 --> Router Class Initialized
INFO - 2017-07-19 02:32:21 --> Output Class Initialized
INFO - 2017-07-19 02:32:21 --> Security Class Initialized
DEBUG - 2017-07-19 02:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:32:21 --> Input Class Initialized
INFO - 2017-07-19 02:32:21 --> Language Class Initialized
INFO - 2017-07-19 02:32:21 --> Loader Class Initialized
INFO - 2017-07-19 02:32:21 --> Controller Class Initialized
INFO - 2017-07-19 02:32:21 --> Database Driver Class Initialized
INFO - 2017-07-19 02:32:21 --> Model Class Initialized
INFO - 2017-07-19 02:32:21 --> Helper loaded: form_helper
INFO - 2017-07-19 02:32:21 --> Helper loaded: url_helper
INFO - 2017-07-19 02:32:21 --> Model Class Initialized
INFO - 2017-07-19 02:32:21 --> Final output sent to browser
DEBUG - 2017-07-19 02:32:21 --> Total execution time: 0.0610
ERROR - 2017-07-19 02:34:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:34:31 --> Config Class Initialized
INFO - 2017-07-19 02:34:31 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:34:31 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:34:31 --> Utf8 Class Initialized
INFO - 2017-07-19 02:34:31 --> URI Class Initialized
INFO - 2017-07-19 02:34:31 --> Router Class Initialized
INFO - 2017-07-19 02:34:31 --> Output Class Initialized
INFO - 2017-07-19 02:34:31 --> Security Class Initialized
DEBUG - 2017-07-19 02:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:34:31 --> Input Class Initialized
INFO - 2017-07-19 02:34:31 --> Language Class Initialized
INFO - 2017-07-19 02:34:31 --> Loader Class Initialized
INFO - 2017-07-19 02:34:31 --> Controller Class Initialized
INFO - 2017-07-19 02:34:31 --> Database Driver Class Initialized
INFO - 2017-07-19 02:34:31 --> Model Class Initialized
INFO - 2017-07-19 02:34:31 --> Helper loaded: form_helper
INFO - 2017-07-19 02:34:31 --> Helper loaded: url_helper
INFO - 2017-07-19 02:34:31 --> Model Class Initialized
INFO - 2017-07-19 02:34:31 --> Final output sent to browser
DEBUG - 2017-07-19 02:34:31 --> Total execution time: 0.0625
ERROR - 2017-07-19 02:46:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:46:21 --> Config Class Initialized
INFO - 2017-07-19 02:46:21 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:46:21 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:46:21 --> Utf8 Class Initialized
INFO - 2017-07-19 02:46:21 --> URI Class Initialized
INFO - 2017-07-19 02:46:21 --> Router Class Initialized
INFO - 2017-07-19 02:46:21 --> Output Class Initialized
INFO - 2017-07-19 02:46:21 --> Security Class Initialized
DEBUG - 2017-07-19 02:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:46:21 --> Input Class Initialized
INFO - 2017-07-19 02:46:21 --> Language Class Initialized
INFO - 2017-07-19 02:46:21 --> Loader Class Initialized
INFO - 2017-07-19 02:46:21 --> Controller Class Initialized
INFO - 2017-07-19 02:46:21 --> Database Driver Class Initialized
INFO - 2017-07-19 02:46:21 --> Model Class Initialized
INFO - 2017-07-19 02:46:21 --> Helper loaded: form_helper
INFO - 2017-07-19 02:46:21 --> Helper loaded: url_helper
INFO - 2017-07-19 02:46:21 --> Model Class Initialized
INFO - 2017-07-19 02:46:21 --> Final output sent to browser
DEBUG - 2017-07-19 02:46:21 --> Total execution time: 0.0800
ERROR - 2017-07-19 02:46:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:46:21 --> Config Class Initialized
INFO - 2017-07-19 02:46:21 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:46:21 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:46:21 --> Utf8 Class Initialized
INFO - 2017-07-19 02:46:21 --> URI Class Initialized
INFO - 2017-07-19 02:46:21 --> Router Class Initialized
INFO - 2017-07-19 02:46:21 --> Output Class Initialized
INFO - 2017-07-19 02:46:22 --> Security Class Initialized
DEBUG - 2017-07-19 02:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:46:22 --> Input Class Initialized
INFO - 2017-07-19 02:46:22 --> Language Class Initialized
INFO - 2017-07-19 02:46:22 --> Loader Class Initialized
INFO - 2017-07-19 02:46:22 --> Controller Class Initialized
INFO - 2017-07-19 02:46:22 --> Database Driver Class Initialized
INFO - 2017-07-19 02:46:22 --> Model Class Initialized
INFO - 2017-07-19 02:46:22 --> Helper loaded: form_helper
INFO - 2017-07-19 02:46:22 --> Helper loaded: url_helper
INFO - 2017-07-19 02:46:22 --> Model Class Initialized
INFO - 2017-07-19 02:46:22 --> Final output sent to browser
DEBUG - 2017-07-19 02:46:22 --> Total execution time: 0.0700
ERROR - 2017-07-19 02:46:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:46:23 --> Config Class Initialized
INFO - 2017-07-19 02:46:23 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:46:23 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:46:23 --> Utf8 Class Initialized
INFO - 2017-07-19 02:46:23 --> URI Class Initialized
INFO - 2017-07-19 02:46:23 --> Router Class Initialized
INFO - 2017-07-19 02:46:23 --> Output Class Initialized
INFO - 2017-07-19 02:46:23 --> Security Class Initialized
DEBUG - 2017-07-19 02:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:46:23 --> Input Class Initialized
INFO - 2017-07-19 02:46:23 --> Language Class Initialized
INFO - 2017-07-19 02:46:24 --> Loader Class Initialized
INFO - 2017-07-19 02:46:24 --> Controller Class Initialized
INFO - 2017-07-19 02:46:24 --> Database Driver Class Initialized
INFO - 2017-07-19 02:46:24 --> Model Class Initialized
INFO - 2017-07-19 02:46:24 --> Helper loaded: form_helper
INFO - 2017-07-19 02:46:24 --> Helper loaded: url_helper
INFO - 2017-07-19 02:46:24 --> Model Class Initialized
INFO - 2017-07-19 02:46:24 --> Final output sent to browser
DEBUG - 2017-07-19 02:46:24 --> Total execution time: 0.0538
ERROR - 2017-07-19 02:46:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:46:26 --> Config Class Initialized
INFO - 2017-07-19 02:46:26 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:46:26 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:46:26 --> Utf8 Class Initialized
INFO - 2017-07-19 02:46:26 --> URI Class Initialized
INFO - 2017-07-19 02:46:26 --> Router Class Initialized
INFO - 2017-07-19 02:46:26 --> Output Class Initialized
INFO - 2017-07-19 02:46:26 --> Security Class Initialized
DEBUG - 2017-07-19 02:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:46:26 --> Input Class Initialized
INFO - 2017-07-19 02:46:26 --> Language Class Initialized
INFO - 2017-07-19 02:46:26 --> Loader Class Initialized
INFO - 2017-07-19 02:46:26 --> Controller Class Initialized
INFO - 2017-07-19 02:46:26 --> Database Driver Class Initialized
INFO - 2017-07-19 02:46:26 --> Model Class Initialized
INFO - 2017-07-19 02:46:26 --> Helper loaded: form_helper
INFO - 2017-07-19 02:46:26 --> Helper loaded: url_helper
INFO - 2017-07-19 02:46:26 --> Model Class Initialized
INFO - 2017-07-19 02:46:26 --> Final output sent to browser
DEBUG - 2017-07-19 02:46:26 --> Total execution time: 0.0455
ERROR - 2017-07-19 02:51:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:51:42 --> Config Class Initialized
INFO - 2017-07-19 02:51:42 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:51:42 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:51:42 --> Utf8 Class Initialized
INFO - 2017-07-19 02:51:42 --> URI Class Initialized
INFO - 2017-07-19 02:51:42 --> Router Class Initialized
INFO - 2017-07-19 02:51:42 --> Output Class Initialized
INFO - 2017-07-19 02:51:42 --> Security Class Initialized
DEBUG - 2017-07-19 02:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:51:42 --> Input Class Initialized
INFO - 2017-07-19 02:51:42 --> Language Class Initialized
INFO - 2017-07-19 02:51:42 --> Loader Class Initialized
INFO - 2017-07-19 02:51:42 --> Controller Class Initialized
INFO - 2017-07-19 02:51:42 --> Database Driver Class Initialized
INFO - 2017-07-19 02:51:42 --> Model Class Initialized
INFO - 2017-07-19 02:51:42 --> Helper loaded: form_helper
INFO - 2017-07-19 02:51:42 --> Helper loaded: url_helper
INFO - 2017-07-19 02:51:42 --> Model Class Initialized
INFO - 2017-07-19 02:51:42 --> Final output sent to browser
DEBUG - 2017-07-19 02:51:42 --> Total execution time: 0.1030
ERROR - 2017-07-19 02:51:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:51:43 --> Config Class Initialized
INFO - 2017-07-19 02:51:43 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:51:43 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:51:43 --> Utf8 Class Initialized
INFO - 2017-07-19 02:51:43 --> URI Class Initialized
INFO - 2017-07-19 02:51:43 --> Router Class Initialized
INFO - 2017-07-19 02:51:43 --> Output Class Initialized
INFO - 2017-07-19 02:51:43 --> Security Class Initialized
DEBUG - 2017-07-19 02:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:51:43 --> Input Class Initialized
INFO - 2017-07-19 02:51:43 --> Language Class Initialized
INFO - 2017-07-19 02:51:43 --> Loader Class Initialized
INFO - 2017-07-19 02:51:43 --> Controller Class Initialized
INFO - 2017-07-19 02:51:43 --> Database Driver Class Initialized
INFO - 2017-07-19 02:51:43 --> Model Class Initialized
INFO - 2017-07-19 02:51:43 --> Helper loaded: form_helper
INFO - 2017-07-19 02:51:43 --> Helper loaded: url_helper
INFO - 2017-07-19 02:51:43 --> Model Class Initialized
INFO - 2017-07-19 02:51:43 --> Final output sent to browser
DEBUG - 2017-07-19 02:51:43 --> Total execution time: 0.0490
ERROR - 2017-07-19 02:53:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:53:00 --> Config Class Initialized
INFO - 2017-07-19 02:53:00 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:53:00 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:53:00 --> Utf8 Class Initialized
INFO - 2017-07-19 02:53:00 --> URI Class Initialized
INFO - 2017-07-19 02:53:00 --> Router Class Initialized
INFO - 2017-07-19 02:53:00 --> Output Class Initialized
INFO - 2017-07-19 02:53:00 --> Security Class Initialized
DEBUG - 2017-07-19 02:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:53:00 --> Input Class Initialized
INFO - 2017-07-19 02:53:00 --> Language Class Initialized
INFO - 2017-07-19 02:53:00 --> Loader Class Initialized
INFO - 2017-07-19 02:53:00 --> Controller Class Initialized
INFO - 2017-07-19 02:53:00 --> Database Driver Class Initialized
INFO - 2017-07-19 02:53:00 --> Model Class Initialized
INFO - 2017-07-19 02:53:00 --> Helper loaded: form_helper
INFO - 2017-07-19 02:53:00 --> Helper loaded: url_helper
INFO - 2017-07-19 02:53:00 --> Model Class Initialized
INFO - 2017-07-19 02:53:00 --> Final output sent to browser
DEBUG - 2017-07-19 02:53:00 --> Total execution time: 0.0890
ERROR - 2017-07-19 02:53:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:53:01 --> Config Class Initialized
INFO - 2017-07-19 02:53:01 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:53:01 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:53:01 --> Utf8 Class Initialized
INFO - 2017-07-19 02:53:01 --> URI Class Initialized
INFO - 2017-07-19 02:53:01 --> Router Class Initialized
INFO - 2017-07-19 02:53:01 --> Output Class Initialized
INFO - 2017-07-19 02:53:01 --> Security Class Initialized
DEBUG - 2017-07-19 02:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:53:01 --> Input Class Initialized
INFO - 2017-07-19 02:53:01 --> Language Class Initialized
INFO - 2017-07-19 02:53:01 --> Loader Class Initialized
INFO - 2017-07-19 02:53:01 --> Controller Class Initialized
INFO - 2017-07-19 02:53:01 --> Database Driver Class Initialized
INFO - 2017-07-19 02:53:01 --> Model Class Initialized
INFO - 2017-07-19 02:53:01 --> Helper loaded: form_helper
INFO - 2017-07-19 02:53:01 --> Helper loaded: url_helper
INFO - 2017-07-19 02:53:01 --> Model Class Initialized
INFO - 2017-07-19 02:53:01 --> Final output sent to browser
DEBUG - 2017-07-19 02:53:01 --> Total execution time: 0.0680
ERROR - 2017-07-19 02:53:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:53:29 --> Config Class Initialized
INFO - 2017-07-19 02:53:29 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:53:29 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:53:29 --> Utf8 Class Initialized
INFO - 2017-07-19 02:53:29 --> URI Class Initialized
INFO - 2017-07-19 02:53:29 --> Router Class Initialized
INFO - 2017-07-19 02:53:29 --> Output Class Initialized
INFO - 2017-07-19 02:53:29 --> Security Class Initialized
DEBUG - 2017-07-19 02:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:53:29 --> Input Class Initialized
INFO - 2017-07-19 02:53:29 --> Language Class Initialized
INFO - 2017-07-19 02:53:29 --> Loader Class Initialized
INFO - 2017-07-19 02:53:29 --> Controller Class Initialized
INFO - 2017-07-19 02:53:29 --> Database Driver Class Initialized
INFO - 2017-07-19 02:53:29 --> Model Class Initialized
INFO - 2017-07-19 02:53:29 --> Helper loaded: form_helper
INFO - 2017-07-19 02:53:29 --> Helper loaded: url_helper
INFO - 2017-07-19 02:53:29 --> Model Class Initialized
INFO - 2017-07-19 02:53:29 --> Final output sent to browser
DEBUG - 2017-07-19 02:53:29 --> Total execution time: 0.0440
ERROR - 2017-07-19 02:54:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:54:03 --> Config Class Initialized
INFO - 2017-07-19 02:54:03 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:54:03 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:54:03 --> Utf8 Class Initialized
INFO - 2017-07-19 02:54:04 --> URI Class Initialized
INFO - 2017-07-19 02:54:04 --> Router Class Initialized
INFO - 2017-07-19 02:54:04 --> Output Class Initialized
INFO - 2017-07-19 02:54:04 --> Security Class Initialized
DEBUG - 2017-07-19 02:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:54:04 --> Input Class Initialized
INFO - 2017-07-19 02:54:04 --> Language Class Initialized
INFO - 2017-07-19 02:54:04 --> Loader Class Initialized
INFO - 2017-07-19 02:54:04 --> Controller Class Initialized
INFO - 2017-07-19 02:54:04 --> Database Driver Class Initialized
INFO - 2017-07-19 02:54:04 --> Model Class Initialized
INFO - 2017-07-19 02:54:04 --> Helper loaded: form_helper
INFO - 2017-07-19 02:54:04 --> Helper loaded: url_helper
INFO - 2017-07-19 02:54:04 --> Model Class Initialized
INFO - 2017-07-19 02:54:04 --> Final output sent to browser
DEBUG - 2017-07-19 02:54:04 --> Total execution time: 0.0470
ERROR - 2017-07-19 02:54:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:54:13 --> Config Class Initialized
INFO - 2017-07-19 02:54:13 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:54:13 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:54:13 --> Utf8 Class Initialized
INFO - 2017-07-19 02:54:13 --> URI Class Initialized
INFO - 2017-07-19 02:54:13 --> Router Class Initialized
INFO - 2017-07-19 02:54:13 --> Output Class Initialized
INFO - 2017-07-19 02:54:13 --> Security Class Initialized
DEBUG - 2017-07-19 02:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:54:13 --> Input Class Initialized
INFO - 2017-07-19 02:54:13 --> Language Class Initialized
INFO - 2017-07-19 02:54:13 --> Loader Class Initialized
INFO - 2017-07-19 02:54:13 --> Controller Class Initialized
INFO - 2017-07-19 02:54:13 --> Database Driver Class Initialized
INFO - 2017-07-19 02:54:13 --> Model Class Initialized
INFO - 2017-07-19 02:54:13 --> Helper loaded: form_helper
INFO - 2017-07-19 02:54:13 --> Helper loaded: url_helper
INFO - 2017-07-19 02:54:13 --> Model Class Initialized
INFO - 2017-07-19 02:54:13 --> Final output sent to browser
DEBUG - 2017-07-19 02:54:13 --> Total execution time: 0.0800
ERROR - 2017-07-19 02:54:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:54:14 --> Config Class Initialized
INFO - 2017-07-19 02:54:14 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:54:14 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:54:14 --> Utf8 Class Initialized
INFO - 2017-07-19 02:54:14 --> URI Class Initialized
INFO - 2017-07-19 02:54:14 --> Router Class Initialized
INFO - 2017-07-19 02:54:14 --> Output Class Initialized
INFO - 2017-07-19 02:54:14 --> Security Class Initialized
DEBUG - 2017-07-19 02:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:54:14 --> Input Class Initialized
INFO - 2017-07-19 02:54:14 --> Language Class Initialized
INFO - 2017-07-19 02:54:14 --> Loader Class Initialized
INFO - 2017-07-19 02:54:14 --> Controller Class Initialized
INFO - 2017-07-19 02:54:14 --> Database Driver Class Initialized
INFO - 2017-07-19 02:54:14 --> Model Class Initialized
INFO - 2017-07-19 02:54:14 --> Helper loaded: form_helper
INFO - 2017-07-19 02:54:14 --> Helper loaded: url_helper
INFO - 2017-07-19 02:54:14 --> Model Class Initialized
INFO - 2017-07-19 02:54:14 --> Final output sent to browser
DEBUG - 2017-07-19 02:54:14 --> Total execution time: 0.0500
ERROR - 2017-07-19 02:55:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:55:50 --> Config Class Initialized
INFO - 2017-07-19 02:55:50 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:55:50 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:55:50 --> Utf8 Class Initialized
INFO - 2017-07-19 02:55:50 --> URI Class Initialized
INFO - 2017-07-19 02:55:50 --> Router Class Initialized
INFO - 2017-07-19 02:55:50 --> Output Class Initialized
INFO - 2017-07-19 02:55:50 --> Security Class Initialized
DEBUG - 2017-07-19 02:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:55:50 --> Input Class Initialized
INFO - 2017-07-19 02:55:50 --> Language Class Initialized
INFO - 2017-07-19 02:55:50 --> Loader Class Initialized
INFO - 2017-07-19 02:55:50 --> Controller Class Initialized
INFO - 2017-07-19 02:55:50 --> Database Driver Class Initialized
INFO - 2017-07-19 02:55:51 --> Model Class Initialized
INFO - 2017-07-19 02:55:51 --> Helper loaded: form_helper
INFO - 2017-07-19 02:55:51 --> Helper loaded: url_helper
INFO - 2017-07-19 02:55:51 --> Model Class Initialized
INFO - 2017-07-19 02:55:51 --> Final output sent to browser
DEBUG - 2017-07-19 02:55:51 --> Total execution time: 0.1100
ERROR - 2017-07-19 02:55:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:55:51 --> Config Class Initialized
INFO - 2017-07-19 02:55:51 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:55:51 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:55:51 --> Utf8 Class Initialized
INFO - 2017-07-19 02:55:51 --> URI Class Initialized
INFO - 2017-07-19 02:55:51 --> Router Class Initialized
INFO - 2017-07-19 02:55:51 --> Output Class Initialized
INFO - 2017-07-19 02:55:51 --> Security Class Initialized
DEBUG - 2017-07-19 02:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:55:52 --> Input Class Initialized
INFO - 2017-07-19 02:55:52 --> Language Class Initialized
INFO - 2017-07-19 02:55:52 --> Loader Class Initialized
INFO - 2017-07-19 02:55:52 --> Controller Class Initialized
INFO - 2017-07-19 02:55:52 --> Database Driver Class Initialized
INFO - 2017-07-19 02:55:52 --> Model Class Initialized
INFO - 2017-07-19 02:55:52 --> Helper loaded: form_helper
INFO - 2017-07-19 02:55:52 --> Helper loaded: url_helper
INFO - 2017-07-19 02:55:52 --> Model Class Initialized
INFO - 2017-07-19 02:55:52 --> Final output sent to browser
DEBUG - 2017-07-19 02:55:52 --> Total execution time: 0.0600
ERROR - 2017-07-19 02:56:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:56:48 --> Config Class Initialized
INFO - 2017-07-19 02:56:48 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:56:48 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:56:48 --> Utf8 Class Initialized
INFO - 2017-07-19 02:56:48 --> URI Class Initialized
INFO - 2017-07-19 02:56:48 --> Router Class Initialized
INFO - 2017-07-19 02:56:48 --> Output Class Initialized
INFO - 2017-07-19 02:56:48 --> Security Class Initialized
DEBUG - 2017-07-19 02:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:56:48 --> Input Class Initialized
INFO - 2017-07-19 02:56:48 --> Language Class Initialized
INFO - 2017-07-19 02:56:48 --> Loader Class Initialized
INFO - 2017-07-19 02:56:48 --> Controller Class Initialized
INFO - 2017-07-19 02:56:48 --> Database Driver Class Initialized
INFO - 2017-07-19 02:56:48 --> Model Class Initialized
INFO - 2017-07-19 02:56:48 --> Helper loaded: form_helper
INFO - 2017-07-19 02:56:48 --> Helper loaded: url_helper
INFO - 2017-07-19 02:56:48 --> Model Class Initialized
INFO - 2017-07-19 02:56:48 --> Final output sent to browser
DEBUG - 2017-07-19 02:56:48 --> Total execution time: 0.0588
ERROR - 2017-07-19 02:56:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:56:58 --> Config Class Initialized
INFO - 2017-07-19 02:56:58 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:56:58 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:56:58 --> Utf8 Class Initialized
INFO - 2017-07-19 02:56:58 --> URI Class Initialized
INFO - 2017-07-19 02:56:58 --> Router Class Initialized
INFO - 2017-07-19 02:56:58 --> Output Class Initialized
INFO - 2017-07-19 02:56:58 --> Security Class Initialized
DEBUG - 2017-07-19 02:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:56:58 --> Input Class Initialized
INFO - 2017-07-19 02:56:58 --> Language Class Initialized
INFO - 2017-07-19 02:56:58 --> Loader Class Initialized
INFO - 2017-07-19 02:56:58 --> Controller Class Initialized
INFO - 2017-07-19 02:56:58 --> Database Driver Class Initialized
INFO - 2017-07-19 02:56:58 --> Model Class Initialized
INFO - 2017-07-19 02:56:58 --> Helper loaded: form_helper
INFO - 2017-07-19 02:56:58 --> Helper loaded: url_helper
INFO - 2017-07-19 02:56:58 --> Model Class Initialized
INFO - 2017-07-19 02:56:58 --> Final output sent to browser
DEBUG - 2017-07-19 02:56:58 --> Total execution time: 0.0850
ERROR - 2017-07-19 02:56:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:56:59 --> Config Class Initialized
INFO - 2017-07-19 02:56:59 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:56:59 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:56:59 --> Utf8 Class Initialized
INFO - 2017-07-19 02:56:59 --> URI Class Initialized
INFO - 2017-07-19 02:56:59 --> Router Class Initialized
INFO - 2017-07-19 02:56:59 --> Output Class Initialized
INFO - 2017-07-19 02:56:59 --> Security Class Initialized
DEBUG - 2017-07-19 02:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:56:59 --> Input Class Initialized
INFO - 2017-07-19 02:56:59 --> Language Class Initialized
INFO - 2017-07-19 02:56:59 --> Loader Class Initialized
INFO - 2017-07-19 02:56:59 --> Controller Class Initialized
INFO - 2017-07-19 02:56:59 --> Database Driver Class Initialized
INFO - 2017-07-19 02:56:59 --> Model Class Initialized
INFO - 2017-07-19 02:56:59 --> Helper loaded: form_helper
INFO - 2017-07-19 02:56:59 --> Helper loaded: url_helper
INFO - 2017-07-19 02:56:59 --> Model Class Initialized
INFO - 2017-07-19 02:56:59 --> Final output sent to browser
DEBUG - 2017-07-19 02:56:59 --> Total execution time: 0.0450
ERROR - 2017-07-19 02:58:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:58:14 --> Config Class Initialized
INFO - 2017-07-19 02:58:14 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:58:14 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:58:14 --> Utf8 Class Initialized
INFO - 2017-07-19 02:58:14 --> URI Class Initialized
INFO - 2017-07-19 02:58:14 --> Router Class Initialized
INFO - 2017-07-19 02:58:14 --> Output Class Initialized
INFO - 2017-07-19 02:58:14 --> Security Class Initialized
DEBUG - 2017-07-19 02:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:58:14 --> Input Class Initialized
INFO - 2017-07-19 02:58:14 --> Language Class Initialized
INFO - 2017-07-19 02:58:14 --> Loader Class Initialized
INFO - 2017-07-19 02:58:14 --> Controller Class Initialized
INFO - 2017-07-19 02:58:14 --> Database Driver Class Initialized
INFO - 2017-07-19 02:58:14 --> Model Class Initialized
INFO - 2017-07-19 02:58:14 --> Helper loaded: form_helper
INFO - 2017-07-19 02:58:14 --> Helper loaded: url_helper
INFO - 2017-07-19 02:58:14 --> Model Class Initialized
INFO - 2017-07-19 02:58:14 --> Final output sent to browser
DEBUG - 2017-07-19 02:58:14 --> Total execution time: 0.0950
ERROR - 2017-07-19 02:58:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 02:58:15 --> Config Class Initialized
INFO - 2017-07-19 02:58:15 --> Hooks Class Initialized
DEBUG - 2017-07-19 02:58:15 --> UTF-8 Support Enabled
INFO - 2017-07-19 02:58:15 --> Utf8 Class Initialized
INFO - 2017-07-19 02:58:15 --> URI Class Initialized
INFO - 2017-07-19 02:58:15 --> Router Class Initialized
INFO - 2017-07-19 02:58:15 --> Output Class Initialized
INFO - 2017-07-19 02:58:15 --> Security Class Initialized
DEBUG - 2017-07-19 02:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 02:58:15 --> Input Class Initialized
INFO - 2017-07-19 02:58:15 --> Language Class Initialized
INFO - 2017-07-19 02:58:15 --> Loader Class Initialized
INFO - 2017-07-19 02:58:15 --> Controller Class Initialized
INFO - 2017-07-19 02:58:15 --> Database Driver Class Initialized
INFO - 2017-07-19 02:58:15 --> Model Class Initialized
INFO - 2017-07-19 02:58:15 --> Helper loaded: form_helper
INFO - 2017-07-19 02:58:15 --> Helper loaded: url_helper
INFO - 2017-07-19 02:58:15 --> Model Class Initialized
INFO - 2017-07-19 02:58:15 --> Final output sent to browser
DEBUG - 2017-07-19 02:58:15 --> Total execution time: 0.0650
ERROR - 2017-07-19 03:24:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 03:24:41 --> Config Class Initialized
INFO - 2017-07-19 03:24:41 --> Hooks Class Initialized
DEBUG - 2017-07-19 03:24:41 --> UTF-8 Support Enabled
INFO - 2017-07-19 03:24:41 --> Utf8 Class Initialized
INFO - 2017-07-19 03:24:41 --> URI Class Initialized
INFO - 2017-07-19 03:24:41 --> Router Class Initialized
INFO - 2017-07-19 03:24:41 --> Output Class Initialized
INFO - 2017-07-19 03:24:41 --> Security Class Initialized
DEBUG - 2017-07-19 03:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 03:24:41 --> Input Class Initialized
INFO - 2017-07-19 03:24:41 --> Language Class Initialized
INFO - 2017-07-19 03:24:41 --> Loader Class Initialized
INFO - 2017-07-19 03:24:41 --> Controller Class Initialized
INFO - 2017-07-19 03:24:41 --> Database Driver Class Initialized
INFO - 2017-07-19 03:24:41 --> Model Class Initialized
INFO - 2017-07-19 03:24:41 --> Helper loaded: form_helper
INFO - 2017-07-19 03:24:41 --> Helper loaded: url_helper
INFO - 2017-07-19 03:24:41 --> Model Class Initialized
INFO - 2017-07-19 03:24:41 --> Final output sent to browser
DEBUG - 2017-07-19 03:24:41 --> Total execution time: 0.0590
ERROR - 2017-07-19 03:26:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 03:26:53 --> Config Class Initialized
INFO - 2017-07-19 03:26:53 --> Hooks Class Initialized
DEBUG - 2017-07-19 03:26:53 --> UTF-8 Support Enabled
INFO - 2017-07-19 03:26:53 --> Utf8 Class Initialized
INFO - 2017-07-19 03:26:53 --> URI Class Initialized
INFO - 2017-07-19 03:26:53 --> Router Class Initialized
INFO - 2017-07-19 03:26:53 --> Output Class Initialized
INFO - 2017-07-19 03:26:53 --> Security Class Initialized
DEBUG - 2017-07-19 03:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 03:26:53 --> Input Class Initialized
INFO - 2017-07-19 03:26:53 --> Language Class Initialized
INFO - 2017-07-19 03:26:53 --> Loader Class Initialized
INFO - 2017-07-19 03:26:53 --> Controller Class Initialized
INFO - 2017-07-19 03:26:53 --> Database Driver Class Initialized
INFO - 2017-07-19 03:26:53 --> Model Class Initialized
INFO - 2017-07-19 03:26:53 --> Helper loaded: form_helper
INFO - 2017-07-19 03:26:53 --> Helper loaded: url_helper
INFO - 2017-07-19 03:26:53 --> Model Class Initialized
INFO - 2017-07-19 03:26:53 --> Final output sent to browser
DEBUG - 2017-07-19 03:26:53 --> Total execution time: 0.1050
ERROR - 2017-07-19 03:26:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 03:26:54 --> Config Class Initialized
INFO - 2017-07-19 03:26:54 --> Hooks Class Initialized
DEBUG - 2017-07-19 03:26:54 --> UTF-8 Support Enabled
INFO - 2017-07-19 03:26:54 --> Utf8 Class Initialized
INFO - 2017-07-19 03:26:54 --> URI Class Initialized
INFO - 2017-07-19 03:26:54 --> Router Class Initialized
INFO - 2017-07-19 03:26:54 --> Output Class Initialized
INFO - 2017-07-19 03:26:54 --> Security Class Initialized
DEBUG - 2017-07-19 03:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 03:26:54 --> Input Class Initialized
INFO - 2017-07-19 03:26:54 --> Language Class Initialized
INFO - 2017-07-19 03:26:54 --> Loader Class Initialized
INFO - 2017-07-19 03:26:54 --> Controller Class Initialized
INFO - 2017-07-19 03:26:54 --> Database Driver Class Initialized
INFO - 2017-07-19 03:26:54 --> Model Class Initialized
INFO - 2017-07-19 03:26:54 --> Helper loaded: form_helper
INFO - 2017-07-19 03:26:54 --> Helper loaded: url_helper
INFO - 2017-07-19 03:26:54 --> Model Class Initialized
INFO - 2017-07-19 03:26:54 --> Final output sent to browser
DEBUG - 2017-07-19 03:26:54 --> Total execution time: 0.0500
ERROR - 2017-07-19 03:28:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 03:28:19 --> Config Class Initialized
INFO - 2017-07-19 03:28:19 --> Hooks Class Initialized
DEBUG - 2017-07-19 03:28:19 --> UTF-8 Support Enabled
INFO - 2017-07-19 03:28:19 --> Utf8 Class Initialized
INFO - 2017-07-19 03:28:19 --> URI Class Initialized
INFO - 2017-07-19 03:28:19 --> Router Class Initialized
INFO - 2017-07-19 03:28:19 --> Output Class Initialized
INFO - 2017-07-19 03:28:19 --> Security Class Initialized
DEBUG - 2017-07-19 03:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 03:28:19 --> Input Class Initialized
INFO - 2017-07-19 03:28:19 --> Language Class Initialized
INFO - 2017-07-19 03:28:19 --> Loader Class Initialized
INFO - 2017-07-19 03:28:19 --> Controller Class Initialized
INFO - 2017-07-19 03:28:19 --> Database Driver Class Initialized
INFO - 2017-07-19 03:28:19 --> Model Class Initialized
INFO - 2017-07-19 03:28:19 --> Helper loaded: form_helper
INFO - 2017-07-19 03:28:19 --> Helper loaded: url_helper
INFO - 2017-07-19 03:28:19 --> Model Class Initialized
INFO - 2017-07-19 03:28:19 --> Final output sent to browser
DEBUG - 2017-07-19 03:28:19 --> Total execution time: 0.1000
ERROR - 2017-07-19 03:28:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 03:28:20 --> Config Class Initialized
INFO - 2017-07-19 03:28:20 --> Hooks Class Initialized
DEBUG - 2017-07-19 03:28:20 --> UTF-8 Support Enabled
INFO - 2017-07-19 03:28:20 --> Utf8 Class Initialized
INFO - 2017-07-19 03:28:20 --> URI Class Initialized
INFO - 2017-07-19 03:28:20 --> Router Class Initialized
INFO - 2017-07-19 03:28:20 --> Output Class Initialized
INFO - 2017-07-19 03:28:20 --> Security Class Initialized
DEBUG - 2017-07-19 03:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 03:28:20 --> Input Class Initialized
INFO - 2017-07-19 03:28:20 --> Language Class Initialized
INFO - 2017-07-19 03:28:20 --> Loader Class Initialized
INFO - 2017-07-19 03:28:20 --> Controller Class Initialized
INFO - 2017-07-19 03:28:20 --> Database Driver Class Initialized
INFO - 2017-07-19 03:28:20 --> Model Class Initialized
INFO - 2017-07-19 03:28:20 --> Helper loaded: form_helper
INFO - 2017-07-19 03:28:20 --> Helper loaded: url_helper
INFO - 2017-07-19 03:28:20 --> Model Class Initialized
INFO - 2017-07-19 03:28:20 --> Final output sent to browser
DEBUG - 2017-07-19 03:28:20 --> Total execution time: 0.0560
ERROR - 2017-07-19 03:35:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 03:35:05 --> Config Class Initialized
INFO - 2017-07-19 03:35:05 --> Hooks Class Initialized
DEBUG - 2017-07-19 03:35:05 --> UTF-8 Support Enabled
INFO - 2017-07-19 03:35:05 --> Utf8 Class Initialized
INFO - 2017-07-19 03:35:05 --> URI Class Initialized
INFO - 2017-07-19 03:35:05 --> Router Class Initialized
INFO - 2017-07-19 03:35:05 --> Output Class Initialized
INFO - 2017-07-19 03:35:05 --> Security Class Initialized
DEBUG - 2017-07-19 03:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 03:35:05 --> Input Class Initialized
INFO - 2017-07-19 03:35:05 --> Language Class Initialized
INFO - 2017-07-19 03:35:05 --> Loader Class Initialized
INFO - 2017-07-19 03:35:05 --> Controller Class Initialized
INFO - 2017-07-19 03:35:05 --> Database Driver Class Initialized
INFO - 2017-07-19 03:35:05 --> Model Class Initialized
INFO - 2017-07-19 03:35:05 --> Helper loaded: form_helper
INFO - 2017-07-19 03:35:05 --> Helper loaded: url_helper
INFO - 2017-07-19 03:35:05 --> Model Class Initialized
INFO - 2017-07-19 03:35:06 --> Final output sent to browser
DEBUG - 2017-07-19 03:35:06 --> Total execution time: 0.4450
ERROR - 2017-07-19 03:35:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 03:35:06 --> Config Class Initialized
INFO - 2017-07-19 03:35:06 --> Hooks Class Initialized
DEBUG - 2017-07-19 03:35:06 --> UTF-8 Support Enabled
INFO - 2017-07-19 03:35:06 --> Utf8 Class Initialized
INFO - 2017-07-19 03:35:06 --> URI Class Initialized
INFO - 2017-07-19 03:35:06 --> Router Class Initialized
INFO - 2017-07-19 03:35:06 --> Output Class Initialized
INFO - 2017-07-19 03:35:06 --> Security Class Initialized
DEBUG - 2017-07-19 03:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 03:35:06 --> Input Class Initialized
INFO - 2017-07-19 03:35:06 --> Language Class Initialized
INFO - 2017-07-19 03:35:06 --> Loader Class Initialized
INFO - 2017-07-19 03:35:06 --> Controller Class Initialized
INFO - 2017-07-19 03:35:06 --> Database Driver Class Initialized
INFO - 2017-07-19 03:35:06 --> Model Class Initialized
INFO - 2017-07-19 03:35:06 --> Helper loaded: form_helper
INFO - 2017-07-19 03:35:06 --> Helper loaded: url_helper
INFO - 2017-07-19 03:35:06 --> Model Class Initialized
INFO - 2017-07-19 03:35:06 --> Final output sent to browser
DEBUG - 2017-07-19 03:35:06 --> Total execution time: 0.0650
ERROR - 2017-07-19 03:38:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 03:38:11 --> Config Class Initialized
INFO - 2017-07-19 03:38:11 --> Hooks Class Initialized
DEBUG - 2017-07-19 03:38:11 --> UTF-8 Support Enabled
INFO - 2017-07-19 03:38:11 --> Utf8 Class Initialized
INFO - 2017-07-19 03:38:11 --> URI Class Initialized
INFO - 2017-07-19 03:38:11 --> Router Class Initialized
INFO - 2017-07-19 03:38:11 --> Output Class Initialized
INFO - 2017-07-19 03:38:11 --> Security Class Initialized
DEBUG - 2017-07-19 03:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 03:38:11 --> Input Class Initialized
INFO - 2017-07-19 03:38:11 --> Language Class Initialized
INFO - 2017-07-19 03:38:11 --> Loader Class Initialized
INFO - 2017-07-19 03:38:11 --> Controller Class Initialized
INFO - 2017-07-19 03:38:11 --> Database Driver Class Initialized
INFO - 2017-07-19 03:38:11 --> Model Class Initialized
INFO - 2017-07-19 03:38:11 --> Helper loaded: form_helper
INFO - 2017-07-19 03:38:11 --> Helper loaded: url_helper
INFO - 2017-07-19 03:38:11 --> Model Class Initialized
INFO - 2017-07-19 03:38:11 --> Final output sent to browser
DEBUG - 2017-07-19 03:38:11 --> Total execution time: 0.1300
ERROR - 2017-07-19 03:38:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 03:38:12 --> Config Class Initialized
INFO - 2017-07-19 03:38:12 --> Hooks Class Initialized
DEBUG - 2017-07-19 03:38:12 --> UTF-8 Support Enabled
INFO - 2017-07-19 03:38:12 --> Utf8 Class Initialized
INFO - 2017-07-19 03:38:12 --> URI Class Initialized
INFO - 2017-07-19 03:38:12 --> Router Class Initialized
INFO - 2017-07-19 03:38:12 --> Output Class Initialized
INFO - 2017-07-19 03:38:12 --> Security Class Initialized
DEBUG - 2017-07-19 03:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 03:38:12 --> Input Class Initialized
INFO - 2017-07-19 03:38:12 --> Language Class Initialized
INFO - 2017-07-19 03:38:12 --> Loader Class Initialized
INFO - 2017-07-19 03:38:12 --> Controller Class Initialized
INFO - 2017-07-19 03:38:12 --> Database Driver Class Initialized
INFO - 2017-07-19 03:38:12 --> Model Class Initialized
INFO - 2017-07-19 03:38:12 --> Helper loaded: form_helper
INFO - 2017-07-19 03:38:12 --> Helper loaded: url_helper
INFO - 2017-07-19 03:38:12 --> Model Class Initialized
INFO - 2017-07-19 03:38:12 --> Final output sent to browser
DEBUG - 2017-07-19 03:38:12 --> Total execution time: 0.0525
ERROR - 2017-07-19 03:38:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 03:38:43 --> Config Class Initialized
INFO - 2017-07-19 03:38:43 --> Hooks Class Initialized
DEBUG - 2017-07-19 03:38:43 --> UTF-8 Support Enabled
INFO - 2017-07-19 03:38:43 --> Utf8 Class Initialized
INFO - 2017-07-19 03:38:43 --> URI Class Initialized
INFO - 2017-07-19 03:38:43 --> Router Class Initialized
INFO - 2017-07-19 03:38:43 --> Output Class Initialized
INFO - 2017-07-19 03:38:43 --> Security Class Initialized
DEBUG - 2017-07-19 03:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 03:38:43 --> Input Class Initialized
INFO - 2017-07-19 03:38:43 --> Language Class Initialized
INFO - 2017-07-19 03:38:43 --> Loader Class Initialized
INFO - 2017-07-19 03:38:43 --> Controller Class Initialized
INFO - 2017-07-19 03:38:43 --> Database Driver Class Initialized
INFO - 2017-07-19 03:38:43 --> Model Class Initialized
INFO - 2017-07-19 03:38:43 --> Helper loaded: form_helper
INFO - 2017-07-19 03:38:43 --> Helper loaded: url_helper
INFO - 2017-07-19 03:38:43 --> Model Class Initialized
INFO - 2017-07-19 03:38:43 --> Final output sent to browser
DEBUG - 2017-07-19 03:38:43 --> Total execution time: 0.0775
ERROR - 2017-07-19 03:38:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 03:38:44 --> Config Class Initialized
INFO - 2017-07-19 03:38:44 --> Hooks Class Initialized
DEBUG - 2017-07-19 03:38:44 --> UTF-8 Support Enabled
INFO - 2017-07-19 03:38:44 --> Utf8 Class Initialized
INFO - 2017-07-19 03:38:44 --> URI Class Initialized
INFO - 2017-07-19 03:38:44 --> Router Class Initialized
INFO - 2017-07-19 03:38:44 --> Output Class Initialized
INFO - 2017-07-19 03:38:44 --> Security Class Initialized
DEBUG - 2017-07-19 03:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 03:38:44 --> Input Class Initialized
INFO - 2017-07-19 03:38:44 --> Language Class Initialized
INFO - 2017-07-19 03:38:44 --> Loader Class Initialized
INFO - 2017-07-19 03:38:44 --> Controller Class Initialized
INFO - 2017-07-19 03:38:44 --> Database Driver Class Initialized
INFO - 2017-07-19 03:38:44 --> Model Class Initialized
INFO - 2017-07-19 03:38:44 --> Helper loaded: form_helper
INFO - 2017-07-19 03:38:44 --> Helper loaded: url_helper
INFO - 2017-07-19 03:38:44 --> Model Class Initialized
INFO - 2017-07-19 03:38:44 --> Final output sent to browser
DEBUG - 2017-07-19 03:38:44 --> Total execution time: 0.0450
ERROR - 2017-07-19 03:39:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 03:39:18 --> Config Class Initialized
INFO - 2017-07-19 03:39:18 --> Hooks Class Initialized
DEBUG - 2017-07-19 03:39:18 --> UTF-8 Support Enabled
INFO - 2017-07-19 03:39:18 --> Utf8 Class Initialized
INFO - 2017-07-19 03:39:18 --> URI Class Initialized
INFO - 2017-07-19 03:39:18 --> Router Class Initialized
INFO - 2017-07-19 03:39:18 --> Output Class Initialized
INFO - 2017-07-19 03:39:18 --> Security Class Initialized
DEBUG - 2017-07-19 03:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 03:39:18 --> Input Class Initialized
INFO - 2017-07-19 03:39:18 --> Language Class Initialized
INFO - 2017-07-19 03:39:18 --> Loader Class Initialized
INFO - 2017-07-19 03:39:18 --> Controller Class Initialized
INFO - 2017-07-19 03:39:18 --> Database Driver Class Initialized
INFO - 2017-07-19 03:39:18 --> Model Class Initialized
INFO - 2017-07-19 03:39:18 --> Helper loaded: form_helper
INFO - 2017-07-19 03:39:18 --> Helper loaded: url_helper
INFO - 2017-07-19 03:39:18 --> Model Class Initialized
INFO - 2017-07-19 03:39:18 --> Final output sent to browser
DEBUG - 2017-07-19 03:39:18 --> Total execution time: 0.0975
ERROR - 2017-07-19 03:39:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 03:39:19 --> Config Class Initialized
INFO - 2017-07-19 03:39:19 --> Hooks Class Initialized
DEBUG - 2017-07-19 03:39:19 --> UTF-8 Support Enabled
INFO - 2017-07-19 03:39:19 --> Utf8 Class Initialized
INFO - 2017-07-19 03:39:19 --> URI Class Initialized
INFO - 2017-07-19 03:39:19 --> Router Class Initialized
INFO - 2017-07-19 03:39:19 --> Output Class Initialized
INFO - 2017-07-19 03:39:19 --> Security Class Initialized
DEBUG - 2017-07-19 03:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 03:39:19 --> Input Class Initialized
INFO - 2017-07-19 03:39:19 --> Language Class Initialized
INFO - 2017-07-19 03:39:19 --> Loader Class Initialized
INFO - 2017-07-19 03:39:19 --> Controller Class Initialized
INFO - 2017-07-19 03:39:19 --> Database Driver Class Initialized
INFO - 2017-07-19 03:39:19 --> Model Class Initialized
INFO - 2017-07-19 03:39:19 --> Helper loaded: form_helper
INFO - 2017-07-19 03:39:19 --> Helper loaded: url_helper
INFO - 2017-07-19 03:39:19 --> Model Class Initialized
INFO - 2017-07-19 03:39:19 --> Final output sent to browser
DEBUG - 2017-07-19 03:39:19 --> Total execution time: 0.0450
ERROR - 2017-07-19 03:40:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 03:40:17 --> Config Class Initialized
INFO - 2017-07-19 03:40:17 --> Hooks Class Initialized
DEBUG - 2017-07-19 03:40:17 --> UTF-8 Support Enabled
INFO - 2017-07-19 03:40:17 --> Utf8 Class Initialized
INFO - 2017-07-19 03:40:17 --> URI Class Initialized
INFO - 2017-07-19 03:40:17 --> Router Class Initialized
INFO - 2017-07-19 03:40:17 --> Output Class Initialized
INFO - 2017-07-19 03:40:17 --> Security Class Initialized
DEBUG - 2017-07-19 03:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 03:40:17 --> Input Class Initialized
INFO - 2017-07-19 03:40:17 --> Language Class Initialized
INFO - 2017-07-19 03:40:17 --> Loader Class Initialized
INFO - 2017-07-19 03:40:17 --> Controller Class Initialized
INFO - 2017-07-19 03:40:17 --> Database Driver Class Initialized
INFO - 2017-07-19 03:40:17 --> Model Class Initialized
INFO - 2017-07-19 03:40:17 --> Helper loaded: form_helper
INFO - 2017-07-19 03:40:17 --> Helper loaded: url_helper
INFO - 2017-07-19 03:40:17 --> Model Class Initialized
INFO - 2017-07-19 03:40:17 --> Final output sent to browser
DEBUG - 2017-07-19 03:40:17 --> Total execution time: 0.0688
ERROR - 2017-07-19 03:42:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 03:42:32 --> Config Class Initialized
INFO - 2017-07-19 03:42:32 --> Hooks Class Initialized
DEBUG - 2017-07-19 03:42:33 --> UTF-8 Support Enabled
INFO - 2017-07-19 03:42:33 --> Utf8 Class Initialized
INFO - 2017-07-19 03:42:33 --> URI Class Initialized
INFO - 2017-07-19 03:42:33 --> Router Class Initialized
INFO - 2017-07-19 03:42:33 --> Output Class Initialized
INFO - 2017-07-19 03:42:33 --> Security Class Initialized
DEBUG - 2017-07-19 03:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 03:42:33 --> Input Class Initialized
INFO - 2017-07-19 03:42:33 --> Language Class Initialized
INFO - 2017-07-19 03:42:33 --> Loader Class Initialized
INFO - 2017-07-19 03:42:33 --> Controller Class Initialized
INFO - 2017-07-19 03:42:33 --> Database Driver Class Initialized
INFO - 2017-07-19 03:42:33 --> Model Class Initialized
INFO - 2017-07-19 03:42:33 --> Helper loaded: form_helper
INFO - 2017-07-19 03:42:33 --> Helper loaded: url_helper
INFO - 2017-07-19 03:42:33 --> Model Class Initialized
INFO - 2017-07-19 03:42:33 --> Final output sent to browser
DEBUG - 2017-07-19 03:42:33 --> Total execution time: 0.1000
ERROR - 2017-07-19 03:42:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 03:42:34 --> Config Class Initialized
INFO - 2017-07-19 03:42:34 --> Hooks Class Initialized
DEBUG - 2017-07-19 03:42:34 --> UTF-8 Support Enabled
INFO - 2017-07-19 03:42:34 --> Utf8 Class Initialized
INFO - 2017-07-19 03:42:34 --> URI Class Initialized
INFO - 2017-07-19 03:42:34 --> Router Class Initialized
INFO - 2017-07-19 03:42:34 --> Output Class Initialized
INFO - 2017-07-19 03:42:34 --> Security Class Initialized
DEBUG - 2017-07-19 03:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 03:42:34 --> Input Class Initialized
INFO - 2017-07-19 03:42:34 --> Language Class Initialized
INFO - 2017-07-19 03:42:34 --> Loader Class Initialized
INFO - 2017-07-19 03:42:34 --> Controller Class Initialized
INFO - 2017-07-19 03:42:34 --> Database Driver Class Initialized
INFO - 2017-07-19 03:42:34 --> Model Class Initialized
INFO - 2017-07-19 03:42:34 --> Helper loaded: form_helper
INFO - 2017-07-19 03:42:34 --> Helper loaded: url_helper
INFO - 2017-07-19 03:42:34 --> Model Class Initialized
INFO - 2017-07-19 03:42:34 --> Final output sent to browser
DEBUG - 2017-07-19 03:42:34 --> Total execution time: 0.0500
ERROR - 2017-07-19 03:53:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 03:53:40 --> Config Class Initialized
INFO - 2017-07-19 03:53:40 --> Hooks Class Initialized
DEBUG - 2017-07-19 03:53:40 --> UTF-8 Support Enabled
INFO - 2017-07-19 03:53:40 --> Utf8 Class Initialized
INFO - 2017-07-19 03:53:40 --> URI Class Initialized
INFO - 2017-07-19 03:53:40 --> Router Class Initialized
INFO - 2017-07-19 03:53:40 --> Output Class Initialized
INFO - 2017-07-19 03:53:40 --> Security Class Initialized
DEBUG - 2017-07-19 03:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 03:53:40 --> Input Class Initialized
INFO - 2017-07-19 03:53:40 --> Language Class Initialized
INFO - 2017-07-19 03:53:40 --> Loader Class Initialized
INFO - 2017-07-19 03:53:40 --> Controller Class Initialized
INFO - 2017-07-19 03:53:40 --> Database Driver Class Initialized
INFO - 2017-07-19 03:53:40 --> Model Class Initialized
INFO - 2017-07-19 03:53:40 --> Helper loaded: form_helper
INFO - 2017-07-19 03:53:40 --> Helper loaded: url_helper
INFO - 2017-07-19 03:53:40 --> Model Class Initialized
INFO - 2017-07-19 03:53:40 --> Final output sent to browser
DEBUG - 2017-07-19 03:53:40 --> Total execution time: 0.0940
ERROR - 2017-07-19 03:53:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 03:53:41 --> Config Class Initialized
INFO - 2017-07-19 03:53:41 --> Hooks Class Initialized
DEBUG - 2017-07-19 03:53:41 --> UTF-8 Support Enabled
INFO - 2017-07-19 03:53:41 --> Utf8 Class Initialized
INFO - 2017-07-19 03:53:41 --> URI Class Initialized
INFO - 2017-07-19 03:53:41 --> Router Class Initialized
INFO - 2017-07-19 03:53:41 --> Output Class Initialized
INFO - 2017-07-19 03:53:41 --> Security Class Initialized
DEBUG - 2017-07-19 03:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 03:53:41 --> Input Class Initialized
INFO - 2017-07-19 03:53:41 --> Language Class Initialized
INFO - 2017-07-19 03:53:41 --> Loader Class Initialized
INFO - 2017-07-19 03:53:41 --> Controller Class Initialized
INFO - 2017-07-19 03:53:41 --> Database Driver Class Initialized
INFO - 2017-07-19 03:53:41 --> Model Class Initialized
INFO - 2017-07-19 03:53:41 --> Helper loaded: form_helper
INFO - 2017-07-19 03:53:41 --> Helper loaded: url_helper
INFO - 2017-07-19 03:53:41 --> Model Class Initialized
INFO - 2017-07-19 03:53:41 --> Final output sent to browser
DEBUG - 2017-07-19 03:53:41 --> Total execution time: 0.0600
ERROR - 2017-07-19 04:17:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 04:17:25 --> Config Class Initialized
INFO - 2017-07-19 04:17:25 --> Hooks Class Initialized
DEBUG - 2017-07-19 04:17:25 --> UTF-8 Support Enabled
INFO - 2017-07-19 04:17:25 --> Utf8 Class Initialized
INFO - 2017-07-19 04:17:25 --> URI Class Initialized
INFO - 2017-07-19 04:17:25 --> Router Class Initialized
INFO - 2017-07-19 04:17:25 --> Output Class Initialized
INFO - 2017-07-19 04:17:25 --> Security Class Initialized
DEBUG - 2017-07-19 04:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 04:17:25 --> Input Class Initialized
INFO - 2017-07-19 04:17:25 --> Language Class Initialized
INFO - 2017-07-19 04:17:25 --> Loader Class Initialized
INFO - 2017-07-19 04:17:25 --> Controller Class Initialized
INFO - 2017-07-19 04:17:25 --> Database Driver Class Initialized
INFO - 2017-07-19 04:17:25 --> Model Class Initialized
INFO - 2017-07-19 04:17:25 --> Helper loaded: form_helper
INFO - 2017-07-19 04:17:25 --> Helper loaded: url_helper
INFO - 2017-07-19 04:17:25 --> Model Class Initialized
INFO - 2017-07-19 04:17:25 --> Final output sent to browser
DEBUG - 2017-07-19 04:17:25 --> Total execution time: 0.1150
ERROR - 2017-07-19 04:17:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 04:17:26 --> Config Class Initialized
INFO - 2017-07-19 04:17:26 --> Hooks Class Initialized
DEBUG - 2017-07-19 04:17:26 --> UTF-8 Support Enabled
INFO - 2017-07-19 04:17:26 --> Utf8 Class Initialized
INFO - 2017-07-19 04:17:26 --> URI Class Initialized
INFO - 2017-07-19 04:17:26 --> Router Class Initialized
INFO - 2017-07-19 04:17:26 --> Output Class Initialized
INFO - 2017-07-19 04:17:26 --> Security Class Initialized
DEBUG - 2017-07-19 04:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 04:17:26 --> Input Class Initialized
INFO - 2017-07-19 04:17:26 --> Language Class Initialized
INFO - 2017-07-19 04:17:26 --> Loader Class Initialized
INFO - 2017-07-19 04:17:26 --> Controller Class Initialized
INFO - 2017-07-19 04:17:26 --> Database Driver Class Initialized
INFO - 2017-07-19 04:17:26 --> Model Class Initialized
INFO - 2017-07-19 04:17:26 --> Helper loaded: form_helper
INFO - 2017-07-19 04:17:26 --> Helper loaded: url_helper
INFO - 2017-07-19 04:17:26 --> Model Class Initialized
INFO - 2017-07-19 04:17:26 --> Final output sent to browser
DEBUG - 2017-07-19 04:17:26 --> Total execution time: 0.0575
ERROR - 2017-07-19 04:18:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 04:18:43 --> Config Class Initialized
INFO - 2017-07-19 04:18:43 --> Hooks Class Initialized
DEBUG - 2017-07-19 04:18:43 --> UTF-8 Support Enabled
INFO - 2017-07-19 04:18:43 --> Utf8 Class Initialized
INFO - 2017-07-19 04:18:43 --> URI Class Initialized
INFO - 2017-07-19 04:18:43 --> Router Class Initialized
INFO - 2017-07-19 04:18:43 --> Output Class Initialized
INFO - 2017-07-19 04:18:43 --> Security Class Initialized
DEBUG - 2017-07-19 04:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 04:18:43 --> Input Class Initialized
INFO - 2017-07-19 04:18:43 --> Language Class Initialized
INFO - 2017-07-19 04:18:43 --> Loader Class Initialized
INFO - 2017-07-19 04:18:43 --> Controller Class Initialized
INFO - 2017-07-19 04:18:43 --> Database Driver Class Initialized
INFO - 2017-07-19 04:18:43 --> Model Class Initialized
INFO - 2017-07-19 04:18:43 --> Helper loaded: form_helper
INFO - 2017-07-19 04:18:43 --> Helper loaded: url_helper
INFO - 2017-07-19 04:18:43 --> Model Class Initialized
INFO - 2017-07-19 04:18:43 --> Final output sent to browser
DEBUG - 2017-07-19 04:18:43 --> Total execution time: 0.0978
ERROR - 2017-07-19 04:18:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 04:18:53 --> Config Class Initialized
INFO - 2017-07-19 04:18:53 --> Hooks Class Initialized
DEBUG - 2017-07-19 04:18:53 --> UTF-8 Support Enabled
INFO - 2017-07-19 04:18:53 --> Utf8 Class Initialized
INFO - 2017-07-19 04:18:53 --> URI Class Initialized
INFO - 2017-07-19 04:18:53 --> Router Class Initialized
INFO - 2017-07-19 04:18:53 --> Output Class Initialized
INFO - 2017-07-19 04:18:53 --> Security Class Initialized
DEBUG - 2017-07-19 04:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 04:18:53 --> Input Class Initialized
INFO - 2017-07-19 04:18:53 --> Language Class Initialized
INFO - 2017-07-19 04:18:53 --> Loader Class Initialized
INFO - 2017-07-19 04:18:53 --> Controller Class Initialized
INFO - 2017-07-19 04:18:53 --> Database Driver Class Initialized
INFO - 2017-07-19 04:18:53 --> Model Class Initialized
INFO - 2017-07-19 04:18:53 --> Helper loaded: form_helper
INFO - 2017-07-19 04:18:53 --> Helper loaded: url_helper
INFO - 2017-07-19 04:18:53 --> Model Class Initialized
INFO - 2017-07-19 04:18:53 --> Final output sent to browser
DEBUG - 2017-07-19 04:18:53 --> Total execution time: 0.0790
ERROR - 2017-07-19 04:18:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 04:18:54 --> Config Class Initialized
INFO - 2017-07-19 04:18:54 --> Hooks Class Initialized
DEBUG - 2017-07-19 04:18:54 --> UTF-8 Support Enabled
INFO - 2017-07-19 04:18:54 --> Utf8 Class Initialized
INFO - 2017-07-19 04:18:54 --> URI Class Initialized
INFO - 2017-07-19 04:18:54 --> Router Class Initialized
INFO - 2017-07-19 04:18:54 --> Output Class Initialized
INFO - 2017-07-19 04:18:54 --> Security Class Initialized
DEBUG - 2017-07-19 04:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 04:18:54 --> Input Class Initialized
INFO - 2017-07-19 04:18:54 --> Language Class Initialized
INFO - 2017-07-19 04:18:54 --> Loader Class Initialized
INFO - 2017-07-19 04:18:54 --> Controller Class Initialized
INFO - 2017-07-19 04:18:54 --> Database Driver Class Initialized
INFO - 2017-07-19 04:18:54 --> Model Class Initialized
INFO - 2017-07-19 04:18:54 --> Helper loaded: form_helper
INFO - 2017-07-19 04:18:54 --> Helper loaded: url_helper
INFO - 2017-07-19 04:18:54 --> Model Class Initialized
INFO - 2017-07-19 04:18:54 --> Final output sent to browser
DEBUG - 2017-07-19 04:18:54 --> Total execution time: 0.0680
ERROR - 2017-07-19 17:34:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:34:04 --> Config Class Initialized
INFO - 2017-07-19 17:34:04 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:34:04 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:34:04 --> Utf8 Class Initialized
INFO - 2017-07-19 17:34:04 --> URI Class Initialized
INFO - 2017-07-19 17:34:04 --> Router Class Initialized
INFO - 2017-07-19 17:34:04 --> Output Class Initialized
INFO - 2017-07-19 17:34:04 --> Security Class Initialized
DEBUG - 2017-07-19 17:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:34:04 --> Input Class Initialized
INFO - 2017-07-19 17:34:04 --> Language Class Initialized
INFO - 2017-07-19 17:34:04 --> Loader Class Initialized
INFO - 2017-07-19 17:34:04 --> Controller Class Initialized
INFO - 2017-07-19 17:34:04 --> Database Driver Class Initialized
INFO - 2017-07-19 17:34:04 --> Model Class Initialized
INFO - 2017-07-19 17:34:04 --> Helper loaded: form_helper
INFO - 2017-07-19 17:34:04 --> Helper loaded: url_helper
INFO - 2017-07-19 17:34:04 --> Model Class Initialized
INFO - 2017-07-19 17:34:04 --> Final output sent to browser
DEBUG - 2017-07-19 17:34:04 --> Total execution time: 0.1150
ERROR - 2017-07-19 17:34:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:34:05 --> Config Class Initialized
INFO - 2017-07-19 17:34:05 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:34:05 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:34:05 --> Utf8 Class Initialized
INFO - 2017-07-19 17:34:05 --> URI Class Initialized
INFO - 2017-07-19 17:34:05 --> Router Class Initialized
INFO - 2017-07-19 17:34:05 --> Output Class Initialized
INFO - 2017-07-19 17:34:05 --> Security Class Initialized
DEBUG - 2017-07-19 17:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:34:05 --> Input Class Initialized
INFO - 2017-07-19 17:34:05 --> Language Class Initialized
INFO - 2017-07-19 17:34:05 --> Loader Class Initialized
INFO - 2017-07-19 17:34:05 --> Controller Class Initialized
INFO - 2017-07-19 17:34:05 --> Database Driver Class Initialized
INFO - 2017-07-19 17:34:05 --> Model Class Initialized
INFO - 2017-07-19 17:34:05 --> Helper loaded: form_helper
INFO - 2017-07-19 17:34:05 --> Helper loaded: url_helper
INFO - 2017-07-19 17:34:05 --> Model Class Initialized
INFO - 2017-07-19 17:34:05 --> Final output sent to browser
DEBUG - 2017-07-19 17:34:05 --> Total execution time: 0.0550
ERROR - 2017-07-19 17:34:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:34:57 --> Config Class Initialized
INFO - 2017-07-19 17:34:57 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:34:57 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:34:57 --> Utf8 Class Initialized
INFO - 2017-07-19 17:34:57 --> URI Class Initialized
INFO - 2017-07-19 17:34:57 --> Router Class Initialized
INFO - 2017-07-19 17:34:57 --> Output Class Initialized
INFO - 2017-07-19 17:34:57 --> Security Class Initialized
DEBUG - 2017-07-19 17:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:34:57 --> Input Class Initialized
INFO - 2017-07-19 17:34:57 --> Language Class Initialized
INFO - 2017-07-19 17:34:57 --> Loader Class Initialized
INFO - 2017-07-19 17:34:57 --> Controller Class Initialized
INFO - 2017-07-19 17:34:57 --> Database Driver Class Initialized
INFO - 2017-07-19 17:34:57 --> Model Class Initialized
INFO - 2017-07-19 17:34:57 --> Helper loaded: form_helper
INFO - 2017-07-19 17:34:57 --> Helper loaded: url_helper
INFO - 2017-07-19 17:34:57 --> Model Class Initialized
INFO - 2017-07-19 17:34:57 --> Final output sent to browser
DEBUG - 2017-07-19 17:34:57 --> Total execution time: 0.1050
ERROR - 2017-07-19 17:34:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:34:58 --> Config Class Initialized
INFO - 2017-07-19 17:34:58 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:34:58 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:34:58 --> Utf8 Class Initialized
INFO - 2017-07-19 17:34:58 --> URI Class Initialized
INFO - 2017-07-19 17:34:58 --> Router Class Initialized
INFO - 2017-07-19 17:34:58 --> Output Class Initialized
INFO - 2017-07-19 17:34:58 --> Security Class Initialized
DEBUG - 2017-07-19 17:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:34:58 --> Input Class Initialized
INFO - 2017-07-19 17:34:58 --> Language Class Initialized
INFO - 2017-07-19 17:34:58 --> Loader Class Initialized
INFO - 2017-07-19 17:34:58 --> Controller Class Initialized
INFO - 2017-07-19 17:34:58 --> Database Driver Class Initialized
INFO - 2017-07-19 17:34:58 --> Model Class Initialized
INFO - 2017-07-19 17:34:58 --> Helper loaded: form_helper
INFO - 2017-07-19 17:34:58 --> Helper loaded: url_helper
INFO - 2017-07-19 17:34:58 --> Model Class Initialized
INFO - 2017-07-19 17:34:58 --> Final output sent to browser
DEBUG - 2017-07-19 17:34:58 --> Total execution time: 0.0650
ERROR - 2017-07-19 17:36:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:36:06 --> Config Class Initialized
INFO - 2017-07-19 17:36:06 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:36:06 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:36:06 --> Utf8 Class Initialized
INFO - 2017-07-19 17:36:06 --> URI Class Initialized
INFO - 2017-07-19 17:36:06 --> Router Class Initialized
INFO - 2017-07-19 17:36:06 --> Output Class Initialized
INFO - 2017-07-19 17:36:06 --> Security Class Initialized
DEBUG - 2017-07-19 17:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:36:06 --> Input Class Initialized
INFO - 2017-07-19 17:36:06 --> Language Class Initialized
INFO - 2017-07-19 17:36:06 --> Loader Class Initialized
INFO - 2017-07-19 17:36:06 --> Controller Class Initialized
INFO - 2017-07-19 17:36:06 --> Database Driver Class Initialized
INFO - 2017-07-19 17:36:06 --> Model Class Initialized
INFO - 2017-07-19 17:36:06 --> Helper loaded: form_helper
INFO - 2017-07-19 17:36:06 --> Helper loaded: url_helper
INFO - 2017-07-19 17:36:06 --> Model Class Initialized
INFO - 2017-07-19 17:36:06 --> Final output sent to browser
DEBUG - 2017-07-19 17:36:06 --> Total execution time: 0.1100
ERROR - 2017-07-19 17:36:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:36:07 --> Config Class Initialized
INFO - 2017-07-19 17:36:07 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:36:07 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:36:07 --> Utf8 Class Initialized
INFO - 2017-07-19 17:36:07 --> URI Class Initialized
INFO - 2017-07-19 17:36:07 --> Router Class Initialized
INFO - 2017-07-19 17:36:07 --> Output Class Initialized
INFO - 2017-07-19 17:36:07 --> Security Class Initialized
DEBUG - 2017-07-19 17:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:36:07 --> Input Class Initialized
INFO - 2017-07-19 17:36:07 --> Language Class Initialized
INFO - 2017-07-19 17:36:07 --> Loader Class Initialized
INFO - 2017-07-19 17:36:07 --> Controller Class Initialized
INFO - 2017-07-19 17:36:07 --> Database Driver Class Initialized
INFO - 2017-07-19 17:36:07 --> Model Class Initialized
INFO - 2017-07-19 17:36:07 --> Helper loaded: form_helper
INFO - 2017-07-19 17:36:07 --> Helper loaded: url_helper
INFO - 2017-07-19 17:36:07 --> Model Class Initialized
INFO - 2017-07-19 17:36:07 --> Final output sent to browser
DEBUG - 2017-07-19 17:36:07 --> Total execution time: 0.0575
ERROR - 2017-07-19 17:36:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:36:52 --> Config Class Initialized
INFO - 2017-07-19 17:36:52 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:36:52 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:36:52 --> Utf8 Class Initialized
INFO - 2017-07-19 17:36:52 --> URI Class Initialized
INFO - 2017-07-19 17:36:52 --> Router Class Initialized
INFO - 2017-07-19 17:36:52 --> Output Class Initialized
INFO - 2017-07-19 17:36:52 --> Security Class Initialized
DEBUG - 2017-07-19 17:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:36:52 --> Input Class Initialized
INFO - 2017-07-19 17:36:52 --> Language Class Initialized
INFO - 2017-07-19 17:36:52 --> Loader Class Initialized
INFO - 2017-07-19 17:36:52 --> Controller Class Initialized
INFO - 2017-07-19 17:36:52 --> Database Driver Class Initialized
INFO - 2017-07-19 17:36:52 --> Model Class Initialized
INFO - 2017-07-19 17:36:52 --> Helper loaded: form_helper
INFO - 2017-07-19 17:36:52 --> Helper loaded: url_helper
INFO - 2017-07-19 17:36:52 --> Model Class Initialized
INFO - 2017-07-19 17:36:52 --> Final output sent to browser
DEBUG - 2017-07-19 17:36:52 --> Total execution time: 0.0975
ERROR - 2017-07-19 17:36:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:36:53 --> Config Class Initialized
INFO - 2017-07-19 17:36:53 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:36:53 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:36:53 --> Utf8 Class Initialized
INFO - 2017-07-19 17:36:53 --> URI Class Initialized
INFO - 2017-07-19 17:36:53 --> Router Class Initialized
INFO - 2017-07-19 17:36:53 --> Output Class Initialized
INFO - 2017-07-19 17:36:53 --> Security Class Initialized
DEBUG - 2017-07-19 17:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:36:53 --> Input Class Initialized
INFO - 2017-07-19 17:36:53 --> Language Class Initialized
INFO - 2017-07-19 17:36:53 --> Loader Class Initialized
INFO - 2017-07-19 17:36:53 --> Controller Class Initialized
INFO - 2017-07-19 17:36:53 --> Database Driver Class Initialized
INFO - 2017-07-19 17:36:53 --> Model Class Initialized
INFO - 2017-07-19 17:36:53 --> Helper loaded: form_helper
INFO - 2017-07-19 17:36:53 --> Helper loaded: url_helper
INFO - 2017-07-19 17:36:53 --> Model Class Initialized
INFO - 2017-07-19 17:36:53 --> Final output sent to browser
DEBUG - 2017-07-19 17:36:53 --> Total execution time: 0.0550
ERROR - 2017-07-19 17:37:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:37:08 --> Config Class Initialized
INFO - 2017-07-19 17:37:08 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:37:08 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:37:08 --> Utf8 Class Initialized
INFO - 2017-07-19 17:37:08 --> URI Class Initialized
INFO - 2017-07-19 17:37:08 --> Router Class Initialized
INFO - 2017-07-19 17:37:08 --> Output Class Initialized
INFO - 2017-07-19 17:37:08 --> Security Class Initialized
DEBUG - 2017-07-19 17:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:37:08 --> Input Class Initialized
INFO - 2017-07-19 17:37:08 --> Language Class Initialized
INFO - 2017-07-19 17:37:08 --> Loader Class Initialized
INFO - 2017-07-19 17:37:08 --> Controller Class Initialized
INFO - 2017-07-19 17:37:08 --> Database Driver Class Initialized
INFO - 2017-07-19 17:37:08 --> Model Class Initialized
INFO - 2017-07-19 17:37:08 --> Helper loaded: form_helper
INFO - 2017-07-19 17:37:08 --> Helper loaded: url_helper
INFO - 2017-07-19 17:37:08 --> Model Class Initialized
INFO - 2017-07-19 17:37:08 --> Final output sent to browser
DEBUG - 2017-07-19 17:37:08 --> Total execution time: 0.0550
ERROR - 2017-07-19 17:38:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:38:01 --> Config Class Initialized
INFO - 2017-07-19 17:38:01 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:38:01 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:38:01 --> Utf8 Class Initialized
INFO - 2017-07-19 17:38:01 --> URI Class Initialized
INFO - 2017-07-19 17:38:01 --> Router Class Initialized
INFO - 2017-07-19 17:38:01 --> Output Class Initialized
INFO - 2017-07-19 17:38:01 --> Security Class Initialized
DEBUG - 2017-07-19 17:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:38:01 --> Input Class Initialized
INFO - 2017-07-19 17:38:01 --> Language Class Initialized
INFO - 2017-07-19 17:38:01 --> Loader Class Initialized
INFO - 2017-07-19 17:38:01 --> Controller Class Initialized
INFO - 2017-07-19 17:38:01 --> Database Driver Class Initialized
INFO - 2017-07-19 17:38:01 --> Model Class Initialized
INFO - 2017-07-19 17:38:01 --> Helper loaded: form_helper
INFO - 2017-07-19 17:38:01 --> Helper loaded: url_helper
INFO - 2017-07-19 17:38:01 --> Model Class Initialized
INFO - 2017-07-19 17:38:01 --> Final output sent to browser
DEBUG - 2017-07-19 17:38:01 --> Total execution time: 0.0458
ERROR - 2017-07-19 17:38:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:38:14 --> Config Class Initialized
INFO - 2017-07-19 17:38:14 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:38:14 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:38:14 --> Utf8 Class Initialized
INFO - 2017-07-19 17:38:14 --> URI Class Initialized
INFO - 2017-07-19 17:38:14 --> Router Class Initialized
INFO - 2017-07-19 17:38:14 --> Output Class Initialized
INFO - 2017-07-19 17:38:14 --> Security Class Initialized
DEBUG - 2017-07-19 17:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:38:14 --> Input Class Initialized
INFO - 2017-07-19 17:38:14 --> Language Class Initialized
INFO - 2017-07-19 17:38:14 --> Loader Class Initialized
INFO - 2017-07-19 17:38:14 --> Controller Class Initialized
INFO - 2017-07-19 17:38:14 --> Database Driver Class Initialized
INFO - 2017-07-19 17:38:14 --> Model Class Initialized
INFO - 2017-07-19 17:38:14 --> Helper loaded: form_helper
INFO - 2017-07-19 17:38:14 --> Helper loaded: url_helper
INFO - 2017-07-19 17:38:14 --> Model Class Initialized
INFO - 2017-07-19 17:38:14 --> Final output sent to browser
DEBUG - 2017-07-19 17:38:14 --> Total execution time: 0.0940
ERROR - 2017-07-19 17:38:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:38:14 --> Config Class Initialized
INFO - 2017-07-19 17:38:14 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:38:14 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:38:14 --> Utf8 Class Initialized
INFO - 2017-07-19 17:38:14 --> URI Class Initialized
INFO - 2017-07-19 17:38:15 --> Router Class Initialized
INFO - 2017-07-19 17:38:15 --> Output Class Initialized
INFO - 2017-07-19 17:38:15 --> Security Class Initialized
DEBUG - 2017-07-19 17:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:38:15 --> Input Class Initialized
INFO - 2017-07-19 17:38:15 --> Language Class Initialized
INFO - 2017-07-19 17:38:15 --> Loader Class Initialized
INFO - 2017-07-19 17:38:15 --> Controller Class Initialized
INFO - 2017-07-19 17:38:15 --> Database Driver Class Initialized
INFO - 2017-07-19 17:38:15 --> Model Class Initialized
INFO - 2017-07-19 17:38:15 --> Helper loaded: form_helper
INFO - 2017-07-19 17:38:15 --> Helper loaded: url_helper
INFO - 2017-07-19 17:38:15 --> Model Class Initialized
INFO - 2017-07-19 17:38:15 --> Final output sent to browser
DEBUG - 2017-07-19 17:38:15 --> Total execution time: 0.0595
ERROR - 2017-07-19 17:40:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:40:12 --> Config Class Initialized
INFO - 2017-07-19 17:40:12 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:40:12 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:40:12 --> Utf8 Class Initialized
INFO - 2017-07-19 17:40:12 --> URI Class Initialized
INFO - 2017-07-19 17:40:12 --> Router Class Initialized
INFO - 2017-07-19 17:40:12 --> Output Class Initialized
INFO - 2017-07-19 17:40:12 --> Security Class Initialized
DEBUG - 2017-07-19 17:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:40:12 --> Input Class Initialized
INFO - 2017-07-19 17:40:12 --> Language Class Initialized
INFO - 2017-07-19 17:40:12 --> Loader Class Initialized
INFO - 2017-07-19 17:40:12 --> Controller Class Initialized
INFO - 2017-07-19 17:40:12 --> Database Driver Class Initialized
INFO - 2017-07-19 17:40:12 --> Model Class Initialized
INFO - 2017-07-19 17:40:12 --> Helper loaded: form_helper
INFO - 2017-07-19 17:40:12 --> Helper loaded: url_helper
INFO - 2017-07-19 17:40:12 --> Model Class Initialized
INFO - 2017-07-19 17:40:12 --> Final output sent to browser
DEBUG - 2017-07-19 17:40:12 --> Total execution time: 0.1100
ERROR - 2017-07-19 17:40:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:40:13 --> Config Class Initialized
INFO - 2017-07-19 17:40:13 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:40:13 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:40:13 --> Utf8 Class Initialized
INFO - 2017-07-19 17:40:13 --> URI Class Initialized
INFO - 2017-07-19 17:40:13 --> Router Class Initialized
INFO - 2017-07-19 17:40:13 --> Output Class Initialized
INFO - 2017-07-19 17:40:13 --> Security Class Initialized
DEBUG - 2017-07-19 17:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:40:13 --> Input Class Initialized
INFO - 2017-07-19 17:40:13 --> Language Class Initialized
INFO - 2017-07-19 17:40:13 --> Loader Class Initialized
INFO - 2017-07-19 17:40:13 --> Controller Class Initialized
INFO - 2017-07-19 17:40:13 --> Database Driver Class Initialized
INFO - 2017-07-19 17:40:13 --> Model Class Initialized
INFO - 2017-07-19 17:40:13 --> Helper loaded: form_helper
INFO - 2017-07-19 17:40:13 --> Helper loaded: url_helper
INFO - 2017-07-19 17:40:13 --> Model Class Initialized
INFO - 2017-07-19 17:40:13 --> Final output sent to browser
DEBUG - 2017-07-19 17:40:13 --> Total execution time: 0.0675
ERROR - 2017-07-19 17:43:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:43:51 --> Config Class Initialized
INFO - 2017-07-19 17:43:51 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:43:51 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:43:51 --> Utf8 Class Initialized
INFO - 2017-07-19 17:43:51 --> URI Class Initialized
INFO - 2017-07-19 17:43:51 --> Router Class Initialized
INFO - 2017-07-19 17:43:51 --> Output Class Initialized
INFO - 2017-07-19 17:43:51 --> Security Class Initialized
DEBUG - 2017-07-19 17:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:43:51 --> Input Class Initialized
INFO - 2017-07-19 17:43:51 --> Language Class Initialized
INFO - 2017-07-19 17:43:51 --> Loader Class Initialized
INFO - 2017-07-19 17:43:51 --> Controller Class Initialized
INFO - 2017-07-19 17:43:51 --> Database Driver Class Initialized
INFO - 2017-07-19 17:43:51 --> Model Class Initialized
INFO - 2017-07-19 17:43:51 --> Helper loaded: form_helper
INFO - 2017-07-19 17:43:51 --> Helper loaded: url_helper
INFO - 2017-07-19 17:43:51 --> Model Class Initialized
INFO - 2017-07-19 17:43:51 --> Final output sent to browser
DEBUG - 2017-07-19 17:43:51 --> Total execution time: 0.1095
ERROR - 2017-07-19 17:43:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:43:52 --> Config Class Initialized
INFO - 2017-07-19 17:43:52 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:43:52 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:43:52 --> Utf8 Class Initialized
INFO - 2017-07-19 17:43:52 --> URI Class Initialized
INFO - 2017-07-19 17:43:52 --> Router Class Initialized
INFO - 2017-07-19 17:43:52 --> Output Class Initialized
INFO - 2017-07-19 17:43:52 --> Security Class Initialized
DEBUG - 2017-07-19 17:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:43:52 --> Input Class Initialized
INFO - 2017-07-19 17:43:52 --> Language Class Initialized
INFO - 2017-07-19 17:43:52 --> Loader Class Initialized
INFO - 2017-07-19 17:43:52 --> Controller Class Initialized
INFO - 2017-07-19 17:43:52 --> Database Driver Class Initialized
INFO - 2017-07-19 17:43:52 --> Model Class Initialized
INFO - 2017-07-19 17:43:52 --> Helper loaded: form_helper
INFO - 2017-07-19 17:43:52 --> Helper loaded: url_helper
INFO - 2017-07-19 17:43:52 --> Model Class Initialized
INFO - 2017-07-19 17:43:52 --> Final output sent to browser
DEBUG - 2017-07-19 17:43:52 --> Total execution time: 0.0535
ERROR - 2017-07-19 17:43:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:43:59 --> Config Class Initialized
INFO - 2017-07-19 17:43:59 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:43:59 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:43:59 --> Utf8 Class Initialized
INFO - 2017-07-19 17:43:59 --> URI Class Initialized
INFO - 2017-07-19 17:43:59 --> Router Class Initialized
INFO - 2017-07-19 17:43:59 --> Output Class Initialized
INFO - 2017-07-19 17:43:59 --> Security Class Initialized
DEBUG - 2017-07-19 17:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:43:59 --> Input Class Initialized
INFO - 2017-07-19 17:43:59 --> Language Class Initialized
INFO - 2017-07-19 17:43:59 --> Loader Class Initialized
INFO - 2017-07-19 17:43:59 --> Controller Class Initialized
INFO - 2017-07-19 17:43:59 --> Database Driver Class Initialized
INFO - 2017-07-19 17:43:59 --> Model Class Initialized
INFO - 2017-07-19 17:43:59 --> Helper loaded: form_helper
INFO - 2017-07-19 17:43:59 --> Helper loaded: url_helper
INFO - 2017-07-19 17:43:59 --> Model Class Initialized
INFO - 2017-07-19 17:43:59 --> Final output sent to browser
DEBUG - 2017-07-19 17:43:59 --> Total execution time: 0.0555
ERROR - 2017-07-19 17:44:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:44:01 --> Config Class Initialized
INFO - 2017-07-19 17:44:01 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:44:01 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:44:01 --> Utf8 Class Initialized
INFO - 2017-07-19 17:44:01 --> URI Class Initialized
INFO - 2017-07-19 17:44:01 --> Router Class Initialized
INFO - 2017-07-19 17:44:01 --> Output Class Initialized
INFO - 2017-07-19 17:44:01 --> Security Class Initialized
DEBUG - 2017-07-19 17:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:44:01 --> Input Class Initialized
INFO - 2017-07-19 17:44:01 --> Language Class Initialized
INFO - 2017-07-19 17:44:01 --> Loader Class Initialized
INFO - 2017-07-19 17:44:01 --> Controller Class Initialized
INFO - 2017-07-19 17:44:01 --> Database Driver Class Initialized
INFO - 2017-07-19 17:44:01 --> Model Class Initialized
INFO - 2017-07-19 17:44:01 --> Helper loaded: form_helper
INFO - 2017-07-19 17:44:01 --> Helper loaded: url_helper
INFO - 2017-07-19 17:44:01 --> Model Class Initialized
INFO - 2017-07-19 17:44:01 --> Final output sent to browser
DEBUG - 2017-07-19 17:44:01 --> Total execution time: 0.0460
ERROR - 2017-07-19 17:49:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:49:07 --> Config Class Initialized
INFO - 2017-07-19 17:49:07 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:49:07 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:49:07 --> Utf8 Class Initialized
INFO - 2017-07-19 17:49:07 --> URI Class Initialized
INFO - 2017-07-19 17:49:07 --> Router Class Initialized
INFO - 2017-07-19 17:49:07 --> Output Class Initialized
INFO - 2017-07-19 17:49:07 --> Security Class Initialized
DEBUG - 2017-07-19 17:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:49:07 --> Input Class Initialized
INFO - 2017-07-19 17:49:07 --> Language Class Initialized
INFO - 2017-07-19 17:49:07 --> Loader Class Initialized
INFO - 2017-07-19 17:49:07 --> Controller Class Initialized
INFO - 2017-07-19 17:49:07 --> Database Driver Class Initialized
INFO - 2017-07-19 17:49:07 --> Model Class Initialized
INFO - 2017-07-19 17:49:07 --> Helper loaded: form_helper
INFO - 2017-07-19 17:49:07 --> Helper loaded: url_helper
INFO - 2017-07-19 17:49:07 --> Model Class Initialized
INFO - 2017-07-19 17:49:07 --> Final output sent to browser
DEBUG - 2017-07-19 17:49:07 --> Total execution time: 0.6470
ERROR - 2017-07-19 17:49:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:49:08 --> Config Class Initialized
INFO - 2017-07-19 17:49:08 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:49:08 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:49:08 --> Utf8 Class Initialized
INFO - 2017-07-19 17:49:08 --> URI Class Initialized
INFO - 2017-07-19 17:49:08 --> Router Class Initialized
INFO - 2017-07-19 17:49:08 --> Output Class Initialized
INFO - 2017-07-19 17:49:08 --> Security Class Initialized
DEBUG - 2017-07-19 17:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:49:08 --> Input Class Initialized
INFO - 2017-07-19 17:49:08 --> Language Class Initialized
INFO - 2017-07-19 17:49:08 --> Loader Class Initialized
INFO - 2017-07-19 17:49:08 --> Controller Class Initialized
INFO - 2017-07-19 17:49:08 --> Database Driver Class Initialized
INFO - 2017-07-19 17:49:08 --> Model Class Initialized
INFO - 2017-07-19 17:49:08 --> Helper loaded: form_helper
INFO - 2017-07-19 17:49:08 --> Helper loaded: url_helper
INFO - 2017-07-19 17:49:08 --> Model Class Initialized
INFO - 2017-07-19 17:49:08 --> Final output sent to browser
DEBUG - 2017-07-19 17:49:08 --> Total execution time: 0.0600
ERROR - 2017-07-19 17:50:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:50:03 --> Config Class Initialized
INFO - 2017-07-19 17:50:03 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:50:03 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:50:03 --> Utf8 Class Initialized
INFO - 2017-07-19 17:50:03 --> URI Class Initialized
INFO - 2017-07-19 17:50:03 --> Router Class Initialized
INFO - 2017-07-19 17:50:03 --> Output Class Initialized
INFO - 2017-07-19 17:50:03 --> Security Class Initialized
DEBUG - 2017-07-19 17:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:50:03 --> Input Class Initialized
INFO - 2017-07-19 17:50:03 --> Language Class Initialized
INFO - 2017-07-19 17:50:03 --> Loader Class Initialized
INFO - 2017-07-19 17:50:03 --> Controller Class Initialized
INFO - 2017-07-19 17:50:03 --> Database Driver Class Initialized
INFO - 2017-07-19 17:50:03 --> Model Class Initialized
INFO - 2017-07-19 17:50:03 --> Helper loaded: form_helper
INFO - 2017-07-19 17:50:03 --> Helper loaded: url_helper
INFO - 2017-07-19 17:50:03 --> Model Class Initialized
INFO - 2017-07-19 17:50:03 --> Final output sent to browser
DEBUG - 2017-07-19 17:50:03 --> Total execution time: 0.0650
ERROR - 2017-07-19 17:50:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:50:08 --> Config Class Initialized
INFO - 2017-07-19 17:50:08 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:50:08 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:50:08 --> Utf8 Class Initialized
INFO - 2017-07-19 17:50:08 --> URI Class Initialized
INFO - 2017-07-19 17:50:08 --> Router Class Initialized
INFO - 2017-07-19 17:50:08 --> Output Class Initialized
INFO - 2017-07-19 17:50:08 --> Security Class Initialized
DEBUG - 2017-07-19 17:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:50:08 --> Input Class Initialized
INFO - 2017-07-19 17:50:08 --> Language Class Initialized
INFO - 2017-07-19 17:50:08 --> Loader Class Initialized
INFO - 2017-07-19 17:50:08 --> Controller Class Initialized
INFO - 2017-07-19 17:50:08 --> Database Driver Class Initialized
INFO - 2017-07-19 17:50:08 --> Model Class Initialized
INFO - 2017-07-19 17:50:08 --> Helper loaded: form_helper
INFO - 2017-07-19 17:50:08 --> Helper loaded: url_helper
INFO - 2017-07-19 17:50:08 --> Model Class Initialized
INFO - 2017-07-19 17:50:08 --> Final output sent to browser
DEBUG - 2017-07-19 17:50:08 --> Total execution time: 0.0550
ERROR - 2017-07-19 17:50:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:50:14 --> Config Class Initialized
INFO - 2017-07-19 17:50:14 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:50:14 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:50:14 --> Utf8 Class Initialized
INFO - 2017-07-19 17:50:14 --> URI Class Initialized
INFO - 2017-07-19 17:50:14 --> Router Class Initialized
INFO - 2017-07-19 17:50:14 --> Output Class Initialized
INFO - 2017-07-19 17:50:14 --> Security Class Initialized
DEBUG - 2017-07-19 17:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:50:14 --> Input Class Initialized
INFO - 2017-07-19 17:50:14 --> Language Class Initialized
INFO - 2017-07-19 17:50:14 --> Loader Class Initialized
INFO - 2017-07-19 17:50:14 --> Controller Class Initialized
INFO - 2017-07-19 17:50:14 --> Database Driver Class Initialized
INFO - 2017-07-19 17:50:14 --> Model Class Initialized
INFO - 2017-07-19 17:50:14 --> Helper loaded: form_helper
INFO - 2017-07-19 17:50:14 --> Helper loaded: url_helper
INFO - 2017-07-19 17:50:14 --> Model Class Initialized
INFO - 2017-07-19 17:50:14 --> Final output sent to browser
DEBUG - 2017-07-19 17:50:14 --> Total execution time: 0.0463
ERROR - 2017-07-19 17:53:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:53:51 --> Config Class Initialized
INFO - 2017-07-19 17:53:51 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:53:51 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:53:51 --> Utf8 Class Initialized
INFO - 2017-07-19 17:53:51 --> URI Class Initialized
INFO - 2017-07-19 17:53:51 --> Router Class Initialized
INFO - 2017-07-19 17:53:51 --> Output Class Initialized
INFO - 2017-07-19 17:53:51 --> Security Class Initialized
DEBUG - 2017-07-19 17:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:53:51 --> Input Class Initialized
INFO - 2017-07-19 17:53:51 --> Language Class Initialized
INFO - 2017-07-19 17:53:51 --> Loader Class Initialized
INFO - 2017-07-19 17:53:51 --> Controller Class Initialized
INFO - 2017-07-19 17:53:51 --> Database Driver Class Initialized
INFO - 2017-07-19 17:53:51 --> Model Class Initialized
INFO - 2017-07-19 17:53:51 --> Helper loaded: form_helper
INFO - 2017-07-19 17:53:51 --> Helper loaded: url_helper
INFO - 2017-07-19 17:53:51 --> Model Class Initialized
INFO - 2017-07-19 17:53:51 --> Final output sent to browser
DEBUG - 2017-07-19 17:53:51 --> Total execution time: 0.0675
ERROR - 2017-07-19 17:54:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:54:18 --> Config Class Initialized
INFO - 2017-07-19 17:54:18 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:54:18 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:54:18 --> Utf8 Class Initialized
INFO - 2017-07-19 17:54:18 --> URI Class Initialized
INFO - 2017-07-19 17:54:18 --> Router Class Initialized
INFO - 2017-07-19 17:54:18 --> Output Class Initialized
INFO - 2017-07-19 17:54:18 --> Security Class Initialized
DEBUG - 2017-07-19 17:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:54:18 --> Input Class Initialized
INFO - 2017-07-19 17:54:18 --> Language Class Initialized
INFO - 2017-07-19 17:54:18 --> Loader Class Initialized
INFO - 2017-07-19 17:54:18 --> Controller Class Initialized
INFO - 2017-07-19 17:54:18 --> Database Driver Class Initialized
INFO - 2017-07-19 17:54:18 --> Model Class Initialized
INFO - 2017-07-19 17:54:18 --> Helper loaded: form_helper
INFO - 2017-07-19 17:54:18 --> Helper loaded: url_helper
INFO - 2017-07-19 17:54:18 --> Model Class Initialized
INFO - 2017-07-19 17:54:18 --> Final output sent to browser
DEBUG - 2017-07-19 17:54:18 --> Total execution time: 0.0588
ERROR - 2017-07-19 17:54:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:54:28 --> Config Class Initialized
INFO - 2017-07-19 17:54:28 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:54:28 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:54:28 --> Utf8 Class Initialized
INFO - 2017-07-19 17:54:28 --> URI Class Initialized
INFO - 2017-07-19 17:54:28 --> Router Class Initialized
INFO - 2017-07-19 17:54:28 --> Output Class Initialized
INFO - 2017-07-19 17:54:28 --> Security Class Initialized
DEBUG - 2017-07-19 17:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:54:28 --> Input Class Initialized
INFO - 2017-07-19 17:54:28 --> Language Class Initialized
INFO - 2017-07-19 17:54:28 --> Loader Class Initialized
INFO - 2017-07-19 17:54:28 --> Controller Class Initialized
INFO - 2017-07-19 17:54:28 --> Database Driver Class Initialized
INFO - 2017-07-19 17:54:28 --> Model Class Initialized
INFO - 2017-07-19 17:54:28 --> Helper loaded: form_helper
INFO - 2017-07-19 17:54:28 --> Helper loaded: url_helper
INFO - 2017-07-19 17:54:28 --> Model Class Initialized
INFO - 2017-07-19 17:54:28 --> Final output sent to browser
DEBUG - 2017-07-19 17:54:28 --> Total execution time: 0.1125
ERROR - 2017-07-19 17:55:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:55:05 --> Config Class Initialized
INFO - 2017-07-19 17:55:05 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:55:05 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:55:05 --> Utf8 Class Initialized
INFO - 2017-07-19 17:55:05 --> URI Class Initialized
INFO - 2017-07-19 17:55:05 --> Router Class Initialized
INFO - 2017-07-19 17:55:05 --> Output Class Initialized
INFO - 2017-07-19 17:55:05 --> Security Class Initialized
DEBUG - 2017-07-19 17:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:55:05 --> Input Class Initialized
INFO - 2017-07-19 17:55:05 --> Language Class Initialized
INFO - 2017-07-19 17:55:05 --> Loader Class Initialized
INFO - 2017-07-19 17:55:05 --> Controller Class Initialized
INFO - 2017-07-19 17:55:05 --> Database Driver Class Initialized
INFO - 2017-07-19 17:55:05 --> Model Class Initialized
INFO - 2017-07-19 17:55:05 --> Helper loaded: form_helper
INFO - 2017-07-19 17:55:05 --> Helper loaded: url_helper
INFO - 2017-07-19 17:55:05 --> Model Class Initialized
INFO - 2017-07-19 17:55:05 --> Final output sent to browser
DEBUG - 2017-07-19 17:55:05 --> Total execution time: 0.0985
ERROR - 2017-07-19 17:55:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 17:55:26 --> Config Class Initialized
INFO - 2017-07-19 17:55:26 --> Hooks Class Initialized
DEBUG - 2017-07-19 17:55:26 --> UTF-8 Support Enabled
INFO - 2017-07-19 17:55:26 --> Utf8 Class Initialized
INFO - 2017-07-19 17:55:26 --> URI Class Initialized
INFO - 2017-07-19 17:55:26 --> Router Class Initialized
INFO - 2017-07-19 17:55:26 --> Output Class Initialized
INFO - 2017-07-19 17:55:26 --> Security Class Initialized
DEBUG - 2017-07-19 17:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 17:55:26 --> Input Class Initialized
INFO - 2017-07-19 17:55:26 --> Language Class Initialized
INFO - 2017-07-19 17:55:26 --> Loader Class Initialized
INFO - 2017-07-19 17:55:26 --> Controller Class Initialized
INFO - 2017-07-19 17:55:26 --> Database Driver Class Initialized
INFO - 2017-07-19 17:55:26 --> Model Class Initialized
INFO - 2017-07-19 17:55:26 --> Helper loaded: form_helper
INFO - 2017-07-19 17:55:26 --> Helper loaded: url_helper
INFO - 2017-07-19 17:55:26 --> Model Class Initialized
INFO - 2017-07-19 17:55:26 --> Final output sent to browser
DEBUG - 2017-07-19 17:55:26 --> Total execution time: 0.0608
ERROR - 2017-07-19 18:10:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-19 18:10:29 --> Config Class Initialized
INFO - 2017-07-19 18:10:29 --> Hooks Class Initialized
DEBUG - 2017-07-19 18:10:29 --> UTF-8 Support Enabled
INFO - 2017-07-19 18:10:29 --> Utf8 Class Initialized
INFO - 2017-07-19 18:10:29 --> URI Class Initialized
INFO - 2017-07-19 18:10:29 --> Router Class Initialized
INFO - 2017-07-19 18:10:29 --> Output Class Initialized
INFO - 2017-07-19 18:10:29 --> Security Class Initialized
DEBUG - 2017-07-19 18:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-19 18:10:29 --> Input Class Initialized
INFO - 2017-07-19 18:10:29 --> Language Class Initialized
INFO - 2017-07-19 18:10:29 --> Loader Class Initialized
INFO - 2017-07-19 18:10:29 --> Controller Class Initialized
INFO - 2017-07-19 18:10:29 --> Database Driver Class Initialized
INFO - 2017-07-19 18:10:29 --> Model Class Initialized
INFO - 2017-07-19 18:10:29 --> Helper loaded: form_helper
INFO - 2017-07-19 18:10:29 --> Helper loaded: url_helper
INFO - 2017-07-19 18:10:29 --> Model Class Initialized
INFO - 2017-07-19 18:10:29 --> Final output sent to browser
DEBUG - 2017-07-19 18:10:29 --> Total execution time: 0.1038
