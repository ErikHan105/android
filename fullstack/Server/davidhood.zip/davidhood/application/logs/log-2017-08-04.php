<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-04 16:54:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-04 16:54:22 --> Config Class Initialized
INFO - 2017-08-04 16:54:22 --> Hooks Class Initialized
DEBUG - 2017-08-04 16:54:22 --> UTF-8 Support Enabled
INFO - 2017-08-04 16:54:22 --> Utf8 Class Initialized
INFO - 2017-08-04 16:54:22 --> URI Class Initialized
DEBUG - 2017-08-04 16:54:22 --> No URI present. Default controller set.
INFO - 2017-08-04 16:54:22 --> Router Class Initialized
INFO - 2017-08-04 16:54:22 --> Output Class Initialized
INFO - 2017-08-04 16:54:22 --> Security Class Initialized
DEBUG - 2017-08-04 16:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 16:54:22 --> Input Class Initialized
INFO - 2017-08-04 16:54:22 --> Language Class Initialized
INFO - 2017-08-04 16:54:22 --> Loader Class Initialized
INFO - 2017-08-04 16:54:22 --> Controller Class Initialized
INFO - 2017-08-04 16:54:22 --> Database Driver Class Initialized
INFO - 2017-08-04 16:54:22 --> Model Class Initialized
INFO - 2017-08-04 16:54:22 --> Helper loaded: form_helper
INFO - 2017-08-04 16:54:22 --> Helper loaded: url_helper
INFO - 2017-08-04 16:54:22 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-08-04 16:54:22 --> Final output sent to browser
DEBUG - 2017-08-04 16:54:22 --> Total execution time: 0.1380
ERROR - 2017-08-04 16:54:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-04 16:54:25 --> Config Class Initialized
INFO - 2017-08-04 16:54:25 --> Hooks Class Initialized
DEBUG - 2017-08-04 16:54:25 --> UTF-8 Support Enabled
INFO - 2017-08-04 16:54:25 --> Utf8 Class Initialized
INFO - 2017-08-04 16:54:25 --> URI Class Initialized
INFO - 2017-08-04 16:54:25 --> Router Class Initialized
INFO - 2017-08-04 16:54:25 --> Output Class Initialized
INFO - 2017-08-04 16:54:25 --> Security Class Initialized
DEBUG - 2017-08-04 16:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 16:54:25 --> Input Class Initialized
INFO - 2017-08-04 16:54:25 --> Language Class Initialized
INFO - 2017-08-04 16:54:25 --> Loader Class Initialized
INFO - 2017-08-04 16:54:25 --> Controller Class Initialized
INFO - 2017-08-04 16:54:25 --> Database Driver Class Initialized
INFO - 2017-08-04 16:54:25 --> Model Class Initialized
INFO - 2017-08-04 16:54:25 --> Helper loaded: form_helper
INFO - 2017-08-04 16:54:25 --> Helper loaded: url_helper
INFO - 2017-08-04 16:54:25 --> Model Class Initialized
ERROR - 2017-08-04 16:54:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-04 16:54:25 --> Config Class Initialized
INFO - 2017-08-04 16:54:25 --> Hooks Class Initialized
DEBUG - 2017-08-04 16:54:25 --> UTF-8 Support Enabled
INFO - 2017-08-04 16:54:25 --> Utf8 Class Initialized
INFO - 2017-08-04 16:54:25 --> URI Class Initialized
INFO - 2017-08-04 16:54:25 --> Router Class Initialized
INFO - 2017-08-04 16:54:25 --> Output Class Initialized
INFO - 2017-08-04 16:54:25 --> Security Class Initialized
DEBUG - 2017-08-04 16:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 16:54:25 --> Input Class Initialized
INFO - 2017-08-04 16:54:25 --> Language Class Initialized
INFO - 2017-08-04 16:54:25 --> Loader Class Initialized
INFO - 2017-08-04 16:54:25 --> Controller Class Initialized
INFO - 2017-08-04 16:54:25 --> Database Driver Class Initialized
INFO - 2017-08-04 16:54:25 --> Model Class Initialized
INFO - 2017-08-04 16:54:25 --> Helper loaded: form_helper
INFO - 2017-08-04 16:54:25 --> Helper loaded: url_helper
INFO - 2017-08-04 16:54:25 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-04 16:54:25 --> Model Class Initialized
INFO - 2017-08-04 16:54:25 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-08-04 16:54:25 --> Final output sent to browser
DEBUG - 2017-08-04 16:54:25 --> Total execution time: 0.1750
ERROR - 2017-08-04 16:54:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-04 16:54:30 --> Config Class Initialized
INFO - 2017-08-04 16:54:30 --> Hooks Class Initialized
DEBUG - 2017-08-04 16:54:30 --> UTF-8 Support Enabled
INFO - 2017-08-04 16:54:30 --> Utf8 Class Initialized
INFO - 2017-08-04 16:54:30 --> URI Class Initialized
INFO - 2017-08-04 16:54:30 --> Router Class Initialized
INFO - 2017-08-04 16:54:30 --> Output Class Initialized
INFO - 2017-08-04 16:54:30 --> Security Class Initialized
DEBUG - 2017-08-04 16:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 16:54:30 --> Input Class Initialized
INFO - 2017-08-04 16:54:30 --> Language Class Initialized
INFO - 2017-08-04 16:54:30 --> Loader Class Initialized
INFO - 2017-08-04 16:54:30 --> Controller Class Initialized
INFO - 2017-08-04 16:54:30 --> Database Driver Class Initialized
INFO - 2017-08-04 16:54:30 --> Model Class Initialized
INFO - 2017-08-04 16:54:30 --> Helper loaded: form_helper
INFO - 2017-08-04 16:54:30 --> Helper loaded: url_helper
INFO - 2017-08-04 16:54:30 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-04 16:54:30 --> Model Class Initialized
INFO - 2017-08-04 16:54:30 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-08-04 16:54:30 --> Final output sent to browser
DEBUG - 2017-08-04 16:54:30 --> Total execution time: 0.0800
ERROR - 2017-08-04 16:54:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-04 16:54:34 --> Config Class Initialized
INFO - 2017-08-04 16:54:34 --> Hooks Class Initialized
DEBUG - 2017-08-04 16:54:34 --> UTF-8 Support Enabled
INFO - 2017-08-04 16:54:34 --> Utf8 Class Initialized
INFO - 2017-08-04 16:54:34 --> URI Class Initialized
INFO - 2017-08-04 16:54:34 --> Router Class Initialized
INFO - 2017-08-04 16:54:34 --> Output Class Initialized
INFO - 2017-08-04 16:54:34 --> Security Class Initialized
DEBUG - 2017-08-04 16:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 16:54:34 --> Input Class Initialized
INFO - 2017-08-04 16:54:34 --> Language Class Initialized
INFO - 2017-08-04 16:54:34 --> Loader Class Initialized
INFO - 2017-08-04 16:54:34 --> Controller Class Initialized
INFO - 2017-08-04 16:54:34 --> Database Driver Class Initialized
INFO - 2017-08-04 16:54:34 --> Model Class Initialized
INFO - 2017-08-04 16:54:34 --> Helper loaded: form_helper
INFO - 2017-08-04 16:54:34 --> Helper loaded: url_helper
INFO - 2017-08-04 16:54:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-04 16:54:34 --> Model Class Initialized
INFO - 2017-08-04 16:54:34 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-08-04 16:54:34 --> Final output sent to browser
DEBUG - 2017-08-04 16:54:34 --> Total execution time: 0.1490
