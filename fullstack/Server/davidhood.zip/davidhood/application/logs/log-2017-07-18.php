<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-18 18:10:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-18 18:10:32 --> Config Class Initialized
INFO - 2017-07-18 18:10:32 --> Hooks Class Initialized
DEBUG - 2017-07-18 18:10:32 --> UTF-8 Support Enabled
INFO - 2017-07-18 18:10:32 --> Utf8 Class Initialized
INFO - 2017-07-18 18:10:32 --> URI Class Initialized
DEBUG - 2017-07-18 18:10:32 --> No URI present. Default controller set.
INFO - 2017-07-18 18:10:32 --> Router Class Initialized
INFO - 2017-07-18 18:10:32 --> Output Class Initialized
INFO - 2017-07-18 18:10:32 --> Security Class Initialized
DEBUG - 2017-07-18 18:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-18 18:10:32 --> Input Class Initialized
INFO - 2017-07-18 18:10:32 --> Language Class Initialized
INFO - 2017-07-18 18:10:32 --> Loader Class Initialized
INFO - 2017-07-18 18:10:32 --> Controller Class Initialized
INFO - 2017-07-18 18:10:32 --> Database Driver Class Initialized
INFO - 2017-07-18 18:10:32 --> Model Class Initialized
INFO - 2017-07-18 18:10:32 --> Helper loaded: form_helper
INFO - 2017-07-18 18:10:32 --> Helper loaded: url_helper
INFO - 2017-07-18 18:10:32 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-18 18:10:32 --> Final output sent to browser
DEBUG - 2017-07-18 18:10:32 --> Total execution time: 0.4070
ERROR - 2017-07-18 18:10:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-18 18:10:41 --> Config Class Initialized
INFO - 2017-07-18 18:10:41 --> Hooks Class Initialized
DEBUG - 2017-07-18 18:10:41 --> UTF-8 Support Enabled
INFO - 2017-07-18 18:10:41 --> Utf8 Class Initialized
INFO - 2017-07-18 18:10:41 --> URI Class Initialized
DEBUG - 2017-07-18 18:10:41 --> No URI present. Default controller set.
INFO - 2017-07-18 18:10:41 --> Router Class Initialized
INFO - 2017-07-18 18:10:41 --> Output Class Initialized
INFO - 2017-07-18 18:10:41 --> Security Class Initialized
DEBUG - 2017-07-18 18:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-18 18:10:41 --> Input Class Initialized
INFO - 2017-07-18 18:10:41 --> Language Class Initialized
INFO - 2017-07-18 18:10:41 --> Loader Class Initialized
INFO - 2017-07-18 18:10:41 --> Controller Class Initialized
INFO - 2017-07-18 18:10:41 --> Database Driver Class Initialized
INFO - 2017-07-18 18:10:41 --> Model Class Initialized
INFO - 2017-07-18 18:10:41 --> Helper loaded: form_helper
INFO - 2017-07-18 18:10:41 --> Helper loaded: url_helper
INFO - 2017-07-18 18:10:41 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-18 18:10:41 --> Final output sent to browser
DEBUG - 2017-07-18 18:10:41 --> Total execution time: 0.0310
ERROR - 2017-07-18 18:12:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-18 18:12:02 --> Config Class Initialized
INFO - 2017-07-18 18:12:02 --> Hooks Class Initialized
DEBUG - 2017-07-18 18:12:02 --> UTF-8 Support Enabled
INFO - 2017-07-18 18:12:02 --> Utf8 Class Initialized
INFO - 2017-07-18 18:12:02 --> URI Class Initialized
INFO - 2017-07-18 18:12:02 --> Router Class Initialized
INFO - 2017-07-18 18:12:02 --> Output Class Initialized
INFO - 2017-07-18 18:12:02 --> Security Class Initialized
DEBUG - 2017-07-18 18:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-18 18:12:02 --> Input Class Initialized
INFO - 2017-07-18 18:12:02 --> Language Class Initialized
INFO - 2017-07-18 18:12:02 --> Loader Class Initialized
INFO - 2017-07-18 18:12:02 --> Controller Class Initialized
INFO - 2017-07-18 18:12:02 --> Database Driver Class Initialized
INFO - 2017-07-18 18:12:02 --> Model Class Initialized
INFO - 2017-07-18 18:12:02 --> Helper loaded: form_helper
INFO - 2017-07-18 18:12:02 --> Helper loaded: url_helper
INFO - 2017-07-18 18:12:02 --> Model Class Initialized
ERROR - 2017-07-18 18:12:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-18 18:12:02 --> Config Class Initialized
INFO - 2017-07-18 18:12:02 --> Hooks Class Initialized
DEBUG - 2017-07-18 18:12:02 --> UTF-8 Support Enabled
INFO - 2017-07-18 18:12:02 --> Utf8 Class Initialized
INFO - 2017-07-18 18:12:02 --> URI Class Initialized
INFO - 2017-07-18 18:12:03 --> Router Class Initialized
INFO - 2017-07-18 18:12:03 --> Output Class Initialized
INFO - 2017-07-18 18:12:03 --> Security Class Initialized
DEBUG - 2017-07-18 18:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-18 18:12:03 --> Input Class Initialized
INFO - 2017-07-18 18:12:03 --> Language Class Initialized
INFO - 2017-07-18 18:12:03 --> Loader Class Initialized
INFO - 2017-07-18 18:12:03 --> Controller Class Initialized
INFO - 2017-07-18 18:12:03 --> Database Driver Class Initialized
INFO - 2017-07-18 18:12:03 --> Model Class Initialized
INFO - 2017-07-18 18:12:03 --> Helper loaded: form_helper
INFO - 2017-07-18 18:12:03 --> Helper loaded: url_helper
INFO - 2017-07-18 18:12:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-18 18:12:03 --> Model Class Initialized
INFO - 2017-07-18 18:12:03 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-18 18:12:03 --> Final output sent to browser
DEBUG - 2017-07-18 18:12:03 --> Total execution time: 0.5030
ERROR - 2017-07-18 18:12:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-18 18:12:10 --> Config Class Initialized
INFO - 2017-07-18 18:12:10 --> Hooks Class Initialized
DEBUG - 2017-07-18 18:12:10 --> UTF-8 Support Enabled
INFO - 2017-07-18 18:12:10 --> Utf8 Class Initialized
INFO - 2017-07-18 18:12:10 --> URI Class Initialized
INFO - 2017-07-18 18:12:10 --> Router Class Initialized
INFO - 2017-07-18 18:12:10 --> Output Class Initialized
INFO - 2017-07-18 18:12:10 --> Security Class Initialized
DEBUG - 2017-07-18 18:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-18 18:12:10 --> Input Class Initialized
INFO - 2017-07-18 18:12:10 --> Language Class Initialized
INFO - 2017-07-18 18:12:10 --> Loader Class Initialized
INFO - 2017-07-18 18:12:10 --> Controller Class Initialized
INFO - 2017-07-18 18:12:10 --> Database Driver Class Initialized
INFO - 2017-07-18 18:12:10 --> Model Class Initialized
INFO - 2017-07-18 18:12:10 --> Helper loaded: form_helper
INFO - 2017-07-18 18:12:10 --> Helper loaded: url_helper
INFO - 2017-07-18 18:12:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-18 18:12:10 --> Model Class Initialized
INFO - 2017-07-18 18:12:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\users.php
INFO - 2017-07-18 18:12:10 --> Final output sent to browser
DEBUG - 2017-07-18 18:12:10 --> Total execution time: 0.0700
ERROR - 2017-07-18 18:12:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-18 18:12:11 --> Config Class Initialized
INFO - 2017-07-18 18:12:11 --> Hooks Class Initialized
DEBUG - 2017-07-18 18:12:11 --> UTF-8 Support Enabled
INFO - 2017-07-18 18:12:11 --> Utf8 Class Initialized
INFO - 2017-07-18 18:12:11 --> URI Class Initialized
INFO - 2017-07-18 18:12:11 --> Router Class Initialized
INFO - 2017-07-18 18:12:11 --> Output Class Initialized
INFO - 2017-07-18 18:12:11 --> Security Class Initialized
DEBUG - 2017-07-18 18:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-18 18:12:11 --> Input Class Initialized
INFO - 2017-07-18 18:12:11 --> Language Class Initialized
INFO - 2017-07-18 18:12:11 --> Loader Class Initialized
INFO - 2017-07-18 18:12:11 --> Controller Class Initialized
INFO - 2017-07-18 18:12:11 --> Database Driver Class Initialized
INFO - 2017-07-18 18:12:12 --> Model Class Initialized
INFO - 2017-07-18 18:12:12 --> Helper loaded: form_helper
INFO - 2017-07-18 18:12:12 --> Helper loaded: url_helper
INFO - 2017-07-18 18:12:12 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-18 18:12:12 --> Model Class Initialized
INFO - 2017-07-18 18:12:12 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-07-18 18:12:12 --> Final output sent to browser
DEBUG - 2017-07-18 18:12:12 --> Total execution time: 0.0530
ERROR - 2017-07-18 18:19:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-18 18:19:08 --> Config Class Initialized
INFO - 2017-07-18 18:19:08 --> Hooks Class Initialized
DEBUG - 2017-07-18 18:19:08 --> UTF-8 Support Enabled
INFO - 2017-07-18 18:19:08 --> Utf8 Class Initialized
INFO - 2017-07-18 18:19:08 --> URI Class Initialized
DEBUG - 2017-07-18 18:19:08 --> No URI present. Default controller set.
INFO - 2017-07-18 18:19:08 --> Router Class Initialized
INFO - 2017-07-18 18:19:08 --> Output Class Initialized
INFO - 2017-07-18 18:19:08 --> Security Class Initialized
DEBUG - 2017-07-18 18:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-18 18:19:08 --> Input Class Initialized
INFO - 2017-07-18 18:19:08 --> Language Class Initialized
INFO - 2017-07-18 18:19:08 --> Loader Class Initialized
INFO - 2017-07-18 18:19:08 --> Controller Class Initialized
INFO - 2017-07-18 18:19:08 --> Database Driver Class Initialized
INFO - 2017-07-18 18:19:08 --> Model Class Initialized
INFO - 2017-07-18 18:19:08 --> Helper loaded: form_helper
INFO - 2017-07-18 18:19:08 --> Helper loaded: url_helper
INFO - 2017-07-18 18:19:08 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-07-18 18:19:08 --> Final output sent to browser
DEBUG - 2017-07-18 18:19:08 --> Total execution time: 0.0470
ERROR - 2017-07-18 18:19:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-18 18:19:10 --> Config Class Initialized
INFO - 2017-07-18 18:19:10 --> Hooks Class Initialized
DEBUG - 2017-07-18 18:19:10 --> UTF-8 Support Enabled
INFO - 2017-07-18 18:19:10 --> Utf8 Class Initialized
INFO - 2017-07-18 18:19:10 --> URI Class Initialized
INFO - 2017-07-18 18:19:10 --> Router Class Initialized
INFO - 2017-07-18 18:19:10 --> Output Class Initialized
INFO - 2017-07-18 18:19:10 --> Security Class Initialized
DEBUG - 2017-07-18 18:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-18 18:19:10 --> Input Class Initialized
INFO - 2017-07-18 18:19:10 --> Language Class Initialized
INFO - 2017-07-18 18:19:10 --> Loader Class Initialized
INFO - 2017-07-18 18:19:10 --> Controller Class Initialized
INFO - 2017-07-18 18:19:10 --> Database Driver Class Initialized
INFO - 2017-07-18 18:19:10 --> Model Class Initialized
INFO - 2017-07-18 18:19:10 --> Helper loaded: form_helper
INFO - 2017-07-18 18:19:10 --> Helper loaded: url_helper
INFO - 2017-07-18 18:19:10 --> Model Class Initialized
ERROR - 2017-07-18 18:19:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-18 18:19:10 --> Config Class Initialized
INFO - 2017-07-18 18:19:10 --> Hooks Class Initialized
DEBUG - 2017-07-18 18:19:10 --> UTF-8 Support Enabled
INFO - 2017-07-18 18:19:10 --> Utf8 Class Initialized
INFO - 2017-07-18 18:19:10 --> URI Class Initialized
INFO - 2017-07-18 18:19:10 --> Router Class Initialized
INFO - 2017-07-18 18:19:10 --> Output Class Initialized
INFO - 2017-07-18 18:19:10 --> Security Class Initialized
DEBUG - 2017-07-18 18:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-18 18:19:10 --> Input Class Initialized
INFO - 2017-07-18 18:19:10 --> Language Class Initialized
INFO - 2017-07-18 18:19:10 --> Loader Class Initialized
INFO - 2017-07-18 18:19:10 --> Controller Class Initialized
INFO - 2017-07-18 18:19:10 --> Database Driver Class Initialized
INFO - 2017-07-18 18:19:10 --> Model Class Initialized
INFO - 2017-07-18 18:19:10 --> Helper loaded: form_helper
INFO - 2017-07-18 18:19:10 --> Helper loaded: url_helper
INFO - 2017-07-18 18:19:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-07-18 18:19:10 --> Model Class Initialized
INFO - 2017-07-18 18:19:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-07-18 18:19:10 --> Final output sent to browser
DEBUG - 2017-07-18 18:19:10 --> Total execution time: 0.0570
ERROR - 2017-07-18 18:20:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-18 18:20:14 --> Config Class Initialized
INFO - 2017-07-18 18:20:14 --> Hooks Class Initialized
DEBUG - 2017-07-18 18:20:14 --> UTF-8 Support Enabled
INFO - 2017-07-18 18:20:14 --> Utf8 Class Initialized
INFO - 2017-07-18 18:20:14 --> URI Class Initialized
INFO - 2017-07-18 18:20:14 --> Router Class Initialized
INFO - 2017-07-18 18:20:14 --> Output Class Initialized
INFO - 2017-07-18 18:20:14 --> Security Class Initialized
DEBUG - 2017-07-18 18:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-18 18:20:14 --> Input Class Initialized
INFO - 2017-07-18 18:20:14 --> Language Class Initialized
INFO - 2017-07-18 18:20:14 --> Loader Class Initialized
INFO - 2017-07-18 18:20:14 --> Controller Class Initialized
INFO - 2017-07-18 18:20:14 --> Database Driver Class Initialized
INFO - 2017-07-18 18:20:14 --> Model Class Initialized
INFO - 2017-07-18 18:20:14 --> Helper loaded: form_helper
INFO - 2017-07-18 18:20:14 --> Helper loaded: url_helper
INFO - 2017-07-18 18:20:14 --> Model Class Initialized
ERROR - 2017-07-18 18:20:14 --> Severity: Notice --> Undefined index: device_id C:\xampp\htdocs\mystage\application\controllers\Mobile.php 27
ERROR - 2017-07-18 18:20:14 --> Query error: Column 'device_id' cannot be null - Invalid query: INSERT INTO `tbl_login` (`user_id`, `token`, `device_id`) VALUES ('15', 'TOKEN923487324ios', NULL)
INFO - 2017-07-18 18:20:14 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-07-18 18:20:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-18 18:20:20 --> Config Class Initialized
INFO - 2017-07-18 18:20:20 --> Hooks Class Initialized
DEBUG - 2017-07-18 18:20:20 --> UTF-8 Support Enabled
INFO - 2017-07-18 18:20:20 --> Utf8 Class Initialized
INFO - 2017-07-18 18:20:20 --> URI Class Initialized
INFO - 2017-07-18 18:20:20 --> Router Class Initialized
INFO - 2017-07-18 18:20:20 --> Output Class Initialized
INFO - 2017-07-18 18:20:20 --> Security Class Initialized
DEBUG - 2017-07-18 18:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-18 18:20:20 --> Input Class Initialized
INFO - 2017-07-18 18:20:20 --> Language Class Initialized
INFO - 2017-07-18 18:20:20 --> Loader Class Initialized
INFO - 2017-07-18 18:20:20 --> Controller Class Initialized
INFO - 2017-07-18 18:20:20 --> Database Driver Class Initialized
INFO - 2017-07-18 18:20:20 --> Model Class Initialized
INFO - 2017-07-18 18:20:20 --> Helper loaded: form_helper
INFO - 2017-07-18 18:20:20 --> Helper loaded: url_helper
INFO - 2017-07-18 18:20:20 --> Model Class Initialized
ERROR - 2017-07-18 18:20:20 --> Severity: Notice --> Undefined index: device_id C:\xampp\htdocs\mystage\application\controllers\Mobile.php 27
ERROR - 2017-07-18 18:20:20 --> Query error: Column 'device_id' cannot be null - Invalid query: INSERT INTO `tbl_login` (`user_id`, `token`, `device_id`) VALUES ('15', 'TOKEN923487324ios', NULL)
INFO - 2017-07-18 18:20:20 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-07-18 18:21:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-07-18 18:21:55 --> Config Class Initialized
INFO - 2017-07-18 18:21:55 --> Hooks Class Initialized
DEBUG - 2017-07-18 18:21:55 --> UTF-8 Support Enabled
INFO - 2017-07-18 18:21:55 --> Utf8 Class Initialized
INFO - 2017-07-18 18:21:55 --> URI Class Initialized
INFO - 2017-07-18 18:21:55 --> Router Class Initialized
INFO - 2017-07-18 18:21:55 --> Output Class Initialized
INFO - 2017-07-18 18:21:55 --> Security Class Initialized
DEBUG - 2017-07-18 18:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-18 18:21:55 --> Input Class Initialized
INFO - 2017-07-18 18:21:55 --> Language Class Initialized
INFO - 2017-07-18 18:21:55 --> Loader Class Initialized
INFO - 2017-07-18 18:21:55 --> Controller Class Initialized
INFO - 2017-07-18 18:21:55 --> Database Driver Class Initialized
INFO - 2017-07-18 18:21:55 --> Model Class Initialized
INFO - 2017-07-18 18:21:55 --> Helper loaded: form_helper
INFO - 2017-07-18 18:21:55 --> Helper loaded: url_helper
INFO - 2017-07-18 18:21:55 --> Model Class Initialized
ERROR - 2017-07-18 18:21:55 --> Severity: Notice --> Undefined index: device_id C:\xampp\htdocs\mystage\application\controllers\Mobile.php 27
ERROR - 2017-07-18 18:21:55 --> Query error: Column 'device_id' cannot be null - Invalid query: INSERT INTO `tbl_login` (`user_id`, `token`, `device_id`) VALUES ('15', 'TOKEN923487324ios', NULL)
INFO - 2017-07-18 18:21:55 --> Language file loaded: language/english/db_lang.php
