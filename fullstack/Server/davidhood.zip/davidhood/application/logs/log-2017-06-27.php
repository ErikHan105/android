<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-27 03:33:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 03:33:58 --> Config Class Initialized
INFO - 2017-06-27 03:33:58 --> Hooks Class Initialized
DEBUG - 2017-06-27 03:33:58 --> UTF-8 Support Enabled
INFO - 2017-06-27 03:33:58 --> Utf8 Class Initialized
INFO - 2017-06-27 03:33:58 --> URI Class Initialized
INFO - 2017-06-27 03:33:58 --> Router Class Initialized
INFO - 2017-06-27 03:33:58 --> Output Class Initialized
INFO - 2017-06-27 03:33:58 --> Security Class Initialized
DEBUG - 2017-06-27 03:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 03:33:58 --> Input Class Initialized
INFO - 2017-06-27 03:33:58 --> Language Class Initialized
INFO - 2017-06-27 03:33:58 --> Loader Class Initialized
INFO - 2017-06-27 03:33:58 --> Controller Class Initialized
INFO - 2017-06-27 03:33:58 --> Database Driver Class Initialized
INFO - 2017-06-27 03:33:58 --> Model Class Initialized
INFO - 2017-06-27 03:33:58 --> Helper loaded: form_helper
INFO - 2017-06-27 03:33:58 --> Helper loaded: url_helper
INFO - 2017-06-27 03:33:58 --> Model Class Initialized
INFO - 2017-06-27 03:33:58 --> Final output sent to browser
DEBUG - 2017-06-27 03:33:58 --> Total execution time: 0.0400
ERROR - 2017-06-27 03:33:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 03:33:58 --> Config Class Initialized
INFO - 2017-06-27 03:33:58 --> Hooks Class Initialized
DEBUG - 2017-06-27 03:33:58 --> UTF-8 Support Enabled
INFO - 2017-06-27 03:33:58 --> Utf8 Class Initialized
INFO - 2017-06-27 03:33:58 --> URI Class Initialized
INFO - 2017-06-27 03:33:58 --> Router Class Initialized
INFO - 2017-06-27 03:33:58 --> Output Class Initialized
INFO - 2017-06-27 03:33:58 --> Security Class Initialized
DEBUG - 2017-06-27 03:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 03:33:58 --> Input Class Initialized
INFO - 2017-06-27 03:33:58 --> Language Class Initialized
INFO - 2017-06-27 03:33:58 --> Loader Class Initialized
INFO - 2017-06-27 03:33:58 --> Controller Class Initialized
INFO - 2017-06-27 03:33:58 --> Database Driver Class Initialized
INFO - 2017-06-27 03:33:58 --> Model Class Initialized
INFO - 2017-06-27 03:33:58 --> Helper loaded: form_helper
INFO - 2017-06-27 03:33:58 --> Helper loaded: url_helper
INFO - 2017-06-27 03:33:58 --> Model Class Initialized
INFO - 2017-06-27 03:33:58 --> Final output sent to browser
DEBUG - 2017-06-27 03:33:58 --> Total execution time: 0.0340
ERROR - 2017-06-27 03:38:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 03:38:58 --> Config Class Initialized
INFO - 2017-06-27 03:38:58 --> Hooks Class Initialized
DEBUG - 2017-06-27 03:38:58 --> UTF-8 Support Enabled
INFO - 2017-06-27 03:38:58 --> Utf8 Class Initialized
INFO - 2017-06-27 03:38:58 --> URI Class Initialized
INFO - 2017-06-27 03:38:58 --> Router Class Initialized
INFO - 2017-06-27 03:38:58 --> Output Class Initialized
INFO - 2017-06-27 03:38:58 --> Security Class Initialized
DEBUG - 2017-06-27 03:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 03:38:58 --> Input Class Initialized
INFO - 2017-06-27 03:38:58 --> Language Class Initialized
INFO - 2017-06-27 03:38:58 --> Loader Class Initialized
INFO - 2017-06-27 03:38:58 --> Controller Class Initialized
INFO - 2017-06-27 03:38:58 --> Database Driver Class Initialized
INFO - 2017-06-27 03:38:58 --> Model Class Initialized
INFO - 2017-06-27 03:38:58 --> Helper loaded: form_helper
INFO - 2017-06-27 03:38:58 --> Helper loaded: url_helper
INFO - 2017-06-27 03:38:58 --> Model Class Initialized
INFO - 2017-06-27 03:38:58 --> Final output sent to browser
DEBUG - 2017-06-27 03:38:58 --> Total execution time: 0.0550
ERROR - 2017-06-27 03:38:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 03:38:59 --> Config Class Initialized
INFO - 2017-06-27 03:38:59 --> Hooks Class Initialized
DEBUG - 2017-06-27 03:38:59 --> UTF-8 Support Enabled
INFO - 2017-06-27 03:38:59 --> Utf8 Class Initialized
INFO - 2017-06-27 03:38:59 --> URI Class Initialized
INFO - 2017-06-27 03:38:59 --> Router Class Initialized
INFO - 2017-06-27 03:38:59 --> Output Class Initialized
INFO - 2017-06-27 03:38:59 --> Security Class Initialized
DEBUG - 2017-06-27 03:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 03:38:59 --> Input Class Initialized
INFO - 2017-06-27 03:38:59 --> Language Class Initialized
INFO - 2017-06-27 03:38:59 --> Loader Class Initialized
INFO - 2017-06-27 03:38:59 --> Controller Class Initialized
INFO - 2017-06-27 03:38:59 --> Database Driver Class Initialized
INFO - 2017-06-27 03:38:59 --> Model Class Initialized
INFO - 2017-06-27 03:38:59 --> Helper loaded: form_helper
INFO - 2017-06-27 03:38:59 --> Helper loaded: url_helper
INFO - 2017-06-27 03:38:59 --> Model Class Initialized
INFO - 2017-06-27 03:38:59 --> Final output sent to browser
DEBUG - 2017-06-27 03:38:59 --> Total execution time: 0.0450
ERROR - 2017-06-27 03:39:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 03:39:16 --> Config Class Initialized
INFO - 2017-06-27 03:39:16 --> Hooks Class Initialized
DEBUG - 2017-06-27 03:39:16 --> UTF-8 Support Enabled
INFO - 2017-06-27 03:39:16 --> Utf8 Class Initialized
INFO - 2017-06-27 03:39:16 --> URI Class Initialized
INFO - 2017-06-27 03:39:16 --> Router Class Initialized
INFO - 2017-06-27 03:39:16 --> Output Class Initialized
INFO - 2017-06-27 03:39:16 --> Security Class Initialized
DEBUG - 2017-06-27 03:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 03:39:16 --> Input Class Initialized
INFO - 2017-06-27 03:39:16 --> Language Class Initialized
INFO - 2017-06-27 03:39:16 --> Loader Class Initialized
INFO - 2017-06-27 03:39:16 --> Controller Class Initialized
INFO - 2017-06-27 03:39:16 --> Database Driver Class Initialized
INFO - 2017-06-27 03:39:16 --> Model Class Initialized
INFO - 2017-06-27 03:39:16 --> Helper loaded: form_helper
INFO - 2017-06-27 03:39:16 --> Helper loaded: url_helper
INFO - 2017-06-27 03:39:16 --> Model Class Initialized
INFO - 2017-06-27 03:39:16 --> Final output sent to browser
DEBUG - 2017-06-27 03:39:16 --> Total execution time: 0.1570
ERROR - 2017-06-27 03:39:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 03:39:33 --> Config Class Initialized
INFO - 2017-06-27 03:39:33 --> Hooks Class Initialized
DEBUG - 2017-06-27 03:39:33 --> UTF-8 Support Enabled
INFO - 2017-06-27 03:39:33 --> Utf8 Class Initialized
INFO - 2017-06-27 03:39:33 --> URI Class Initialized
INFO - 2017-06-27 03:39:33 --> Router Class Initialized
INFO - 2017-06-27 03:39:33 --> Output Class Initialized
INFO - 2017-06-27 03:39:33 --> Security Class Initialized
DEBUG - 2017-06-27 03:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 03:39:33 --> Input Class Initialized
INFO - 2017-06-27 03:39:33 --> Language Class Initialized
INFO - 2017-06-27 03:39:33 --> Loader Class Initialized
INFO - 2017-06-27 03:39:33 --> Controller Class Initialized
INFO - 2017-06-27 03:39:33 --> Database Driver Class Initialized
INFO - 2017-06-27 03:39:33 --> Model Class Initialized
INFO - 2017-06-27 03:39:33 --> Helper loaded: form_helper
INFO - 2017-06-27 03:39:33 --> Helper loaded: url_helper
INFO - 2017-06-27 03:39:33 --> Model Class Initialized
INFO - 2017-06-27 03:39:33 --> Final output sent to browser
DEBUG - 2017-06-27 03:39:33 --> Total execution time: 0.0750
ERROR - 2017-06-27 03:40:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 03:40:56 --> Config Class Initialized
INFO - 2017-06-27 03:40:56 --> Hooks Class Initialized
DEBUG - 2017-06-27 03:40:56 --> UTF-8 Support Enabled
INFO - 2017-06-27 03:40:56 --> Utf8 Class Initialized
INFO - 2017-06-27 03:40:56 --> URI Class Initialized
INFO - 2017-06-27 03:40:56 --> Router Class Initialized
INFO - 2017-06-27 03:40:56 --> Output Class Initialized
INFO - 2017-06-27 03:40:56 --> Security Class Initialized
DEBUG - 2017-06-27 03:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 03:40:56 --> Input Class Initialized
INFO - 2017-06-27 03:40:56 --> Language Class Initialized
INFO - 2017-06-27 03:40:56 --> Loader Class Initialized
INFO - 2017-06-27 03:40:56 --> Controller Class Initialized
INFO - 2017-06-27 03:40:56 --> Database Driver Class Initialized
INFO - 2017-06-27 03:40:56 --> Model Class Initialized
INFO - 2017-06-27 03:40:56 --> Helper loaded: form_helper
INFO - 2017-06-27 03:40:56 --> Helper loaded: url_helper
INFO - 2017-06-27 03:40:56 --> Model Class Initialized
INFO - 2017-06-27 03:40:56 --> Final output sent to browser
DEBUG - 2017-06-27 03:40:56 --> Total execution time: 0.0370
ERROR - 2017-06-27 03:46:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 03:46:47 --> Config Class Initialized
INFO - 2017-06-27 03:46:47 --> Hooks Class Initialized
DEBUG - 2017-06-27 03:46:47 --> UTF-8 Support Enabled
INFO - 2017-06-27 03:46:47 --> Utf8 Class Initialized
INFO - 2017-06-27 03:46:47 --> URI Class Initialized
INFO - 2017-06-27 03:46:47 --> Router Class Initialized
INFO - 2017-06-27 03:46:47 --> Output Class Initialized
INFO - 2017-06-27 03:46:47 --> Security Class Initialized
DEBUG - 2017-06-27 03:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 03:46:47 --> Input Class Initialized
INFO - 2017-06-27 03:46:47 --> Language Class Initialized
INFO - 2017-06-27 03:46:47 --> Loader Class Initialized
INFO - 2017-06-27 03:46:47 --> Controller Class Initialized
INFO - 2017-06-27 03:46:47 --> Database Driver Class Initialized
INFO - 2017-06-27 03:46:47 --> Model Class Initialized
INFO - 2017-06-27 03:46:47 --> Helper loaded: form_helper
INFO - 2017-06-27 03:46:47 --> Helper loaded: url_helper
INFO - 2017-06-27 03:46:47 --> Model Class Initialized
INFO - 2017-06-27 03:46:47 --> Final output sent to browser
DEBUG - 2017-06-27 03:46:47 --> Total execution time: 0.0770
ERROR - 2017-06-27 03:50:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 03:50:20 --> Config Class Initialized
INFO - 2017-06-27 03:50:20 --> Hooks Class Initialized
DEBUG - 2017-06-27 03:50:20 --> UTF-8 Support Enabled
INFO - 2017-06-27 03:50:20 --> Utf8 Class Initialized
INFO - 2017-06-27 03:50:20 --> URI Class Initialized
INFO - 2017-06-27 03:50:20 --> Router Class Initialized
INFO - 2017-06-27 03:50:20 --> Output Class Initialized
INFO - 2017-06-27 03:50:20 --> Security Class Initialized
DEBUG - 2017-06-27 03:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 03:50:20 --> Input Class Initialized
INFO - 2017-06-27 03:50:20 --> Language Class Initialized
INFO - 2017-06-27 03:50:20 --> Loader Class Initialized
INFO - 2017-06-27 03:50:20 --> Controller Class Initialized
INFO - 2017-06-27 03:50:20 --> Database Driver Class Initialized
INFO - 2017-06-27 03:50:20 --> Model Class Initialized
INFO - 2017-06-27 03:50:20 --> Helper loaded: form_helper
INFO - 2017-06-27 03:50:20 --> Helper loaded: url_helper
INFO - 2017-06-27 03:50:20 --> Model Class Initialized
INFO - 2017-06-27 03:50:20 --> Final output sent to browser
DEBUG - 2017-06-27 03:50:20 --> Total execution time: 0.0530
ERROR - 2017-06-27 03:58:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 03:58:08 --> Config Class Initialized
INFO - 2017-06-27 03:58:08 --> Hooks Class Initialized
DEBUG - 2017-06-27 03:58:08 --> UTF-8 Support Enabled
INFO - 2017-06-27 03:58:08 --> Utf8 Class Initialized
INFO - 2017-06-27 03:58:08 --> URI Class Initialized
INFO - 2017-06-27 03:58:08 --> Router Class Initialized
INFO - 2017-06-27 03:58:08 --> Output Class Initialized
INFO - 2017-06-27 03:58:08 --> Security Class Initialized
DEBUG - 2017-06-27 03:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 03:58:08 --> Input Class Initialized
INFO - 2017-06-27 03:58:08 --> Language Class Initialized
INFO - 2017-06-27 03:58:08 --> Loader Class Initialized
INFO - 2017-06-27 03:58:08 --> Controller Class Initialized
INFO - 2017-06-27 03:58:08 --> Database Driver Class Initialized
INFO - 2017-06-27 03:58:08 --> Model Class Initialized
INFO - 2017-06-27 03:58:08 --> Helper loaded: form_helper
INFO - 2017-06-27 03:58:08 --> Helper loaded: url_helper
INFO - 2017-06-27 03:58:08 --> Model Class Initialized
INFO - 2017-06-27 03:58:08 --> Final output sent to browser
DEBUG - 2017-06-27 03:58:08 --> Total execution time: 0.0480
ERROR - 2017-06-27 04:00:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 04:00:41 --> Config Class Initialized
INFO - 2017-06-27 04:00:41 --> Hooks Class Initialized
DEBUG - 2017-06-27 04:00:41 --> UTF-8 Support Enabled
INFO - 2017-06-27 04:00:41 --> Utf8 Class Initialized
INFO - 2017-06-27 04:00:41 --> URI Class Initialized
INFO - 2017-06-27 04:00:41 --> Router Class Initialized
INFO - 2017-06-27 04:00:41 --> Output Class Initialized
INFO - 2017-06-27 04:00:41 --> Security Class Initialized
DEBUG - 2017-06-27 04:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 04:00:41 --> Input Class Initialized
INFO - 2017-06-27 04:00:41 --> Language Class Initialized
INFO - 2017-06-27 04:00:41 --> Loader Class Initialized
INFO - 2017-06-27 04:00:41 --> Controller Class Initialized
INFO - 2017-06-27 04:00:41 --> Database Driver Class Initialized
INFO - 2017-06-27 04:00:41 --> Model Class Initialized
INFO - 2017-06-27 04:00:41 --> Helper loaded: form_helper
INFO - 2017-06-27 04:00:41 --> Helper loaded: url_helper
INFO - 2017-06-27 04:00:41 --> Model Class Initialized
INFO - 2017-06-27 04:00:41 --> Final output sent to browser
DEBUG - 2017-06-27 04:00:41 --> Total execution time: 0.0460
ERROR - 2017-06-27 06:20:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 06:20:17 --> Config Class Initialized
INFO - 2017-06-27 06:20:17 --> Hooks Class Initialized
DEBUG - 2017-06-27 06:20:17 --> UTF-8 Support Enabled
INFO - 2017-06-27 06:20:17 --> Utf8 Class Initialized
INFO - 2017-06-27 06:20:17 --> URI Class Initialized
INFO - 2017-06-27 06:20:17 --> Router Class Initialized
INFO - 2017-06-27 06:20:17 --> Output Class Initialized
INFO - 2017-06-27 06:20:17 --> Security Class Initialized
DEBUG - 2017-06-27 06:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 06:20:17 --> Input Class Initialized
INFO - 2017-06-27 06:20:17 --> Language Class Initialized
INFO - 2017-06-27 06:20:17 --> Loader Class Initialized
INFO - 2017-06-27 06:20:17 --> Controller Class Initialized
INFO - 2017-06-27 06:20:17 --> Database Driver Class Initialized
INFO - 2017-06-27 06:20:17 --> Model Class Initialized
INFO - 2017-06-27 06:20:17 --> Helper loaded: form_helper
INFO - 2017-06-27 06:20:17 --> Helper loaded: url_helper
INFO - 2017-06-27 06:20:17 --> Model Class Initialized
INFO - 2017-06-27 06:20:17 --> Final output sent to browser
DEBUG - 2017-06-27 06:20:17 --> Total execution time: 0.1020
ERROR - 2017-06-27 06:20:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 06:20:19 --> Config Class Initialized
INFO - 2017-06-27 06:20:19 --> Hooks Class Initialized
DEBUG - 2017-06-27 06:20:19 --> UTF-8 Support Enabled
INFO - 2017-06-27 06:20:19 --> Utf8 Class Initialized
INFO - 2017-06-27 06:20:19 --> URI Class Initialized
INFO - 2017-06-27 06:20:19 --> Router Class Initialized
INFO - 2017-06-27 06:20:19 --> Output Class Initialized
INFO - 2017-06-27 06:20:19 --> Security Class Initialized
DEBUG - 2017-06-27 06:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 06:20:19 --> Input Class Initialized
INFO - 2017-06-27 06:20:19 --> Language Class Initialized
INFO - 2017-06-27 06:20:19 --> Loader Class Initialized
INFO - 2017-06-27 06:20:19 --> Controller Class Initialized
INFO - 2017-06-27 06:20:19 --> Database Driver Class Initialized
INFO - 2017-06-27 06:20:19 --> Model Class Initialized
INFO - 2017-06-27 06:20:19 --> Helper loaded: form_helper
INFO - 2017-06-27 06:20:19 --> Helper loaded: url_helper
INFO - 2017-06-27 06:20:19 --> Model Class Initialized
INFO - 2017-06-27 06:20:19 --> Final output sent to browser
DEBUG - 2017-06-27 06:20:19 --> Total execution time: 0.0880
ERROR - 2017-06-27 06:20:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 06:20:45 --> Config Class Initialized
INFO - 2017-06-27 06:20:45 --> Hooks Class Initialized
DEBUG - 2017-06-27 06:20:45 --> UTF-8 Support Enabled
INFO - 2017-06-27 06:20:45 --> Utf8 Class Initialized
INFO - 2017-06-27 06:20:45 --> URI Class Initialized
INFO - 2017-06-27 06:20:45 --> Router Class Initialized
INFO - 2017-06-27 06:20:45 --> Output Class Initialized
INFO - 2017-06-27 06:20:45 --> Security Class Initialized
DEBUG - 2017-06-27 06:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 06:20:45 --> Input Class Initialized
INFO - 2017-06-27 06:20:45 --> Language Class Initialized
INFO - 2017-06-27 06:20:45 --> Loader Class Initialized
INFO - 2017-06-27 06:20:45 --> Controller Class Initialized
INFO - 2017-06-27 06:20:45 --> Database Driver Class Initialized
INFO - 2017-06-27 06:20:45 --> Model Class Initialized
INFO - 2017-06-27 06:20:45 --> Helper loaded: form_helper
INFO - 2017-06-27 06:20:45 --> Helper loaded: url_helper
INFO - 2017-06-27 06:20:45 --> Model Class Initialized
INFO - 2017-06-27 06:20:45 --> Final output sent to browser
DEBUG - 2017-06-27 06:20:45 --> Total execution time: 0.1060
ERROR - 2017-06-27 06:20:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 06:20:46 --> Config Class Initialized
INFO - 2017-06-27 06:20:46 --> Hooks Class Initialized
DEBUG - 2017-06-27 06:20:46 --> UTF-8 Support Enabled
INFO - 2017-06-27 06:20:46 --> Utf8 Class Initialized
INFO - 2017-06-27 06:20:46 --> URI Class Initialized
INFO - 2017-06-27 06:20:46 --> Router Class Initialized
INFO - 2017-06-27 06:20:46 --> Output Class Initialized
INFO - 2017-06-27 06:20:46 --> Security Class Initialized
DEBUG - 2017-06-27 06:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 06:20:46 --> Input Class Initialized
INFO - 2017-06-27 06:20:46 --> Language Class Initialized
INFO - 2017-06-27 06:20:46 --> Loader Class Initialized
INFO - 2017-06-27 06:20:46 --> Controller Class Initialized
INFO - 2017-06-27 06:20:46 --> Database Driver Class Initialized
INFO - 2017-06-27 06:20:46 --> Model Class Initialized
INFO - 2017-06-27 06:20:46 --> Helper loaded: form_helper
INFO - 2017-06-27 06:20:46 --> Helper loaded: url_helper
INFO - 2017-06-27 06:20:46 --> Model Class Initialized
INFO - 2017-06-27 06:20:46 --> Final output sent to browser
DEBUG - 2017-06-27 06:20:46 --> Total execution time: 0.0530
ERROR - 2017-06-27 06:32:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 06:32:18 --> Config Class Initialized
INFO - 2017-06-27 06:32:18 --> Hooks Class Initialized
DEBUG - 2017-06-27 06:32:18 --> UTF-8 Support Enabled
INFO - 2017-06-27 06:32:18 --> Utf8 Class Initialized
INFO - 2017-06-27 06:32:18 --> URI Class Initialized
INFO - 2017-06-27 06:32:18 --> Router Class Initialized
INFO - 2017-06-27 06:32:18 --> Output Class Initialized
INFO - 2017-06-27 06:32:18 --> Security Class Initialized
DEBUG - 2017-06-27 06:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 06:32:18 --> Input Class Initialized
INFO - 2017-06-27 06:32:18 --> Language Class Initialized
INFO - 2017-06-27 06:32:18 --> Loader Class Initialized
INFO - 2017-06-27 06:32:18 --> Controller Class Initialized
INFO - 2017-06-27 06:32:18 --> Database Driver Class Initialized
INFO - 2017-06-27 06:32:18 --> Model Class Initialized
INFO - 2017-06-27 06:32:18 --> Helper loaded: form_helper
INFO - 2017-06-27 06:32:18 --> Helper loaded: url_helper
INFO - 2017-06-27 06:32:18 --> Model Class Initialized
INFO - 2017-06-27 06:32:18 --> Final output sent to browser
DEBUG - 2017-06-27 06:32:18 --> Total execution time: 0.0510
ERROR - 2017-06-27 06:35:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 06:35:34 --> Config Class Initialized
INFO - 2017-06-27 06:35:34 --> Hooks Class Initialized
DEBUG - 2017-06-27 06:35:34 --> UTF-8 Support Enabled
INFO - 2017-06-27 06:35:34 --> Utf8 Class Initialized
INFO - 2017-06-27 06:35:34 --> URI Class Initialized
INFO - 2017-06-27 06:35:34 --> Router Class Initialized
INFO - 2017-06-27 06:35:34 --> Output Class Initialized
INFO - 2017-06-27 06:35:34 --> Security Class Initialized
DEBUG - 2017-06-27 06:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 06:35:34 --> Input Class Initialized
INFO - 2017-06-27 06:35:34 --> Language Class Initialized
INFO - 2017-06-27 06:35:34 --> Loader Class Initialized
INFO - 2017-06-27 06:35:34 --> Controller Class Initialized
INFO - 2017-06-27 06:35:34 --> Database Driver Class Initialized
INFO - 2017-06-27 06:35:34 --> Model Class Initialized
INFO - 2017-06-27 06:35:34 --> Helper loaded: form_helper
INFO - 2017-06-27 06:35:34 --> Helper loaded: url_helper
INFO - 2017-06-27 06:35:34 --> Model Class Initialized
INFO - 2017-06-27 06:35:34 --> Final output sent to browser
DEBUG - 2017-06-27 06:35:34 --> Total execution time: 0.0580
ERROR - 2017-06-27 06:36:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 06:36:16 --> Config Class Initialized
INFO - 2017-06-27 06:36:16 --> Hooks Class Initialized
DEBUG - 2017-06-27 06:36:16 --> UTF-8 Support Enabled
INFO - 2017-06-27 06:36:16 --> Utf8 Class Initialized
INFO - 2017-06-27 06:36:16 --> URI Class Initialized
INFO - 2017-06-27 06:36:16 --> Router Class Initialized
INFO - 2017-06-27 06:36:16 --> Output Class Initialized
INFO - 2017-06-27 06:36:16 --> Security Class Initialized
DEBUG - 2017-06-27 06:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 06:36:16 --> Input Class Initialized
INFO - 2017-06-27 06:36:16 --> Language Class Initialized
INFO - 2017-06-27 06:36:16 --> Loader Class Initialized
INFO - 2017-06-27 06:36:16 --> Controller Class Initialized
INFO - 2017-06-27 06:36:16 --> Database Driver Class Initialized
INFO - 2017-06-27 06:36:16 --> Model Class Initialized
INFO - 2017-06-27 06:36:16 --> Helper loaded: form_helper
INFO - 2017-06-27 06:36:16 --> Helper loaded: url_helper
INFO - 2017-06-27 06:36:16 --> Model Class Initialized
INFO - 2017-06-27 06:36:16 --> Final output sent to browser
DEBUG - 2017-06-27 06:36:16 --> Total execution time: 0.0530
ERROR - 2017-06-27 06:37:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 06:37:02 --> Config Class Initialized
INFO - 2017-06-27 06:37:02 --> Hooks Class Initialized
DEBUG - 2017-06-27 06:37:02 --> UTF-8 Support Enabled
INFO - 2017-06-27 06:37:02 --> Utf8 Class Initialized
INFO - 2017-06-27 06:37:02 --> URI Class Initialized
INFO - 2017-06-27 06:37:02 --> Router Class Initialized
INFO - 2017-06-27 06:37:02 --> Output Class Initialized
INFO - 2017-06-27 06:37:02 --> Security Class Initialized
DEBUG - 2017-06-27 06:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 06:37:02 --> Input Class Initialized
INFO - 2017-06-27 06:37:02 --> Language Class Initialized
INFO - 2017-06-27 06:37:02 --> Loader Class Initialized
INFO - 2017-06-27 06:37:02 --> Controller Class Initialized
INFO - 2017-06-27 06:37:02 --> Database Driver Class Initialized
INFO - 2017-06-27 06:37:02 --> Model Class Initialized
INFO - 2017-06-27 06:37:02 --> Helper loaded: form_helper
INFO - 2017-06-27 06:37:02 --> Helper loaded: url_helper
INFO - 2017-06-27 06:37:02 --> Model Class Initialized
INFO - 2017-06-27 06:37:02 --> Final output sent to browser
DEBUG - 2017-06-27 06:37:02 --> Total execution time: 0.0520
ERROR - 2017-06-27 06:43:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 06:43:12 --> Config Class Initialized
INFO - 2017-06-27 06:43:12 --> Hooks Class Initialized
DEBUG - 2017-06-27 06:43:12 --> UTF-8 Support Enabled
INFO - 2017-06-27 06:43:12 --> Utf8 Class Initialized
INFO - 2017-06-27 06:43:12 --> URI Class Initialized
INFO - 2017-06-27 06:43:12 --> Router Class Initialized
INFO - 2017-06-27 06:43:12 --> Output Class Initialized
INFO - 2017-06-27 06:43:12 --> Security Class Initialized
DEBUG - 2017-06-27 06:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 06:43:12 --> Input Class Initialized
INFO - 2017-06-27 06:43:12 --> Language Class Initialized
INFO - 2017-06-27 06:43:12 --> Loader Class Initialized
INFO - 2017-06-27 06:43:12 --> Controller Class Initialized
INFO - 2017-06-27 06:43:12 --> Database Driver Class Initialized
INFO - 2017-06-27 06:43:12 --> Model Class Initialized
INFO - 2017-06-27 06:43:12 --> Helper loaded: form_helper
INFO - 2017-06-27 06:43:12 --> Helper loaded: url_helper
INFO - 2017-06-27 06:43:12 --> Model Class Initialized
INFO - 2017-06-27 06:43:12 --> Final output sent to browser
DEBUG - 2017-06-27 06:43:12 --> Total execution time: 0.0620
ERROR - 2017-06-27 06:45:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 06:45:03 --> Config Class Initialized
INFO - 2017-06-27 06:45:03 --> Hooks Class Initialized
DEBUG - 2017-06-27 06:45:03 --> UTF-8 Support Enabled
INFO - 2017-06-27 06:45:03 --> Utf8 Class Initialized
INFO - 2017-06-27 06:45:03 --> URI Class Initialized
INFO - 2017-06-27 06:45:03 --> Router Class Initialized
INFO - 2017-06-27 06:45:03 --> Output Class Initialized
INFO - 2017-06-27 06:45:03 --> Security Class Initialized
DEBUG - 2017-06-27 06:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 06:45:03 --> Input Class Initialized
INFO - 2017-06-27 06:45:03 --> Language Class Initialized
INFO - 2017-06-27 06:45:03 --> Loader Class Initialized
INFO - 2017-06-27 06:45:03 --> Controller Class Initialized
INFO - 2017-06-27 06:45:03 --> Database Driver Class Initialized
INFO - 2017-06-27 06:45:04 --> Model Class Initialized
INFO - 2017-06-27 06:45:04 --> Helper loaded: form_helper
INFO - 2017-06-27 06:45:04 --> Helper loaded: url_helper
INFO - 2017-06-27 06:45:04 --> Model Class Initialized
INFO - 2017-06-27 06:45:04 --> Final output sent to browser
DEBUG - 2017-06-27 06:45:04 --> Total execution time: 0.0660
ERROR - 2017-06-27 06:49:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 06:49:12 --> Config Class Initialized
INFO - 2017-06-27 06:49:12 --> Hooks Class Initialized
DEBUG - 2017-06-27 06:49:12 --> UTF-8 Support Enabled
INFO - 2017-06-27 06:49:12 --> Utf8 Class Initialized
INFO - 2017-06-27 06:49:12 --> URI Class Initialized
INFO - 2017-06-27 06:49:12 --> Router Class Initialized
INFO - 2017-06-27 06:49:12 --> Output Class Initialized
INFO - 2017-06-27 06:49:12 --> Security Class Initialized
DEBUG - 2017-06-27 06:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 06:49:12 --> Input Class Initialized
INFO - 2017-06-27 06:49:12 --> Language Class Initialized
INFO - 2017-06-27 06:49:12 --> Loader Class Initialized
INFO - 2017-06-27 06:49:12 --> Controller Class Initialized
INFO - 2017-06-27 06:49:12 --> Database Driver Class Initialized
INFO - 2017-06-27 06:49:12 --> Model Class Initialized
INFO - 2017-06-27 06:49:12 --> Helper loaded: form_helper
INFO - 2017-06-27 06:49:12 --> Helper loaded: url_helper
INFO - 2017-06-27 06:49:12 --> Model Class Initialized
INFO - 2017-06-27 06:49:12 --> Final output sent to browser
DEBUG - 2017-06-27 06:49:12 --> Total execution time: 0.0600
ERROR - 2017-06-27 06:50:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 06:50:40 --> Config Class Initialized
INFO - 2017-06-27 06:50:40 --> Hooks Class Initialized
DEBUG - 2017-06-27 06:50:40 --> UTF-8 Support Enabled
INFO - 2017-06-27 06:50:40 --> Utf8 Class Initialized
INFO - 2017-06-27 06:50:40 --> URI Class Initialized
INFO - 2017-06-27 06:50:40 --> Router Class Initialized
INFO - 2017-06-27 06:50:40 --> Output Class Initialized
INFO - 2017-06-27 06:50:40 --> Security Class Initialized
DEBUG - 2017-06-27 06:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 06:50:40 --> Input Class Initialized
INFO - 2017-06-27 06:50:40 --> Language Class Initialized
INFO - 2017-06-27 06:50:40 --> Loader Class Initialized
INFO - 2017-06-27 06:50:40 --> Controller Class Initialized
INFO - 2017-06-27 06:50:40 --> Database Driver Class Initialized
INFO - 2017-06-27 06:50:40 --> Model Class Initialized
INFO - 2017-06-27 06:50:40 --> Helper loaded: form_helper
INFO - 2017-06-27 06:50:40 --> Helper loaded: url_helper
INFO - 2017-06-27 06:50:40 --> Model Class Initialized
INFO - 2017-06-27 06:50:40 --> Final output sent to browser
DEBUG - 2017-06-27 06:50:40 --> Total execution time: 0.0570
ERROR - 2017-06-27 06:52:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 06:52:04 --> Config Class Initialized
INFO - 2017-06-27 06:52:04 --> Hooks Class Initialized
DEBUG - 2017-06-27 06:52:04 --> UTF-8 Support Enabled
INFO - 2017-06-27 06:52:04 --> Utf8 Class Initialized
INFO - 2017-06-27 06:52:04 --> URI Class Initialized
INFO - 2017-06-27 06:52:04 --> Router Class Initialized
INFO - 2017-06-27 06:52:04 --> Output Class Initialized
INFO - 2017-06-27 06:52:04 --> Security Class Initialized
DEBUG - 2017-06-27 06:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 06:52:04 --> Input Class Initialized
INFO - 2017-06-27 06:52:04 --> Language Class Initialized
INFO - 2017-06-27 06:52:04 --> Loader Class Initialized
INFO - 2017-06-27 06:52:04 --> Controller Class Initialized
INFO - 2017-06-27 06:52:04 --> Database Driver Class Initialized
INFO - 2017-06-27 06:52:04 --> Model Class Initialized
INFO - 2017-06-27 06:52:04 --> Helper loaded: form_helper
INFO - 2017-06-27 06:52:04 --> Helper loaded: url_helper
INFO - 2017-06-27 06:52:04 --> Model Class Initialized
INFO - 2017-06-27 06:52:04 --> Final output sent to browser
DEBUG - 2017-06-27 06:52:04 --> Total execution time: 0.0680
ERROR - 2017-06-27 06:53:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 06:53:54 --> Config Class Initialized
INFO - 2017-06-27 06:53:54 --> Hooks Class Initialized
DEBUG - 2017-06-27 06:53:54 --> UTF-8 Support Enabled
INFO - 2017-06-27 06:53:54 --> Utf8 Class Initialized
INFO - 2017-06-27 06:53:54 --> URI Class Initialized
INFO - 2017-06-27 06:53:54 --> Router Class Initialized
INFO - 2017-06-27 06:53:54 --> Output Class Initialized
INFO - 2017-06-27 06:53:54 --> Security Class Initialized
DEBUG - 2017-06-27 06:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 06:53:54 --> Input Class Initialized
INFO - 2017-06-27 06:53:54 --> Language Class Initialized
INFO - 2017-06-27 06:53:54 --> Loader Class Initialized
INFO - 2017-06-27 06:53:54 --> Controller Class Initialized
INFO - 2017-06-27 06:53:54 --> Database Driver Class Initialized
INFO - 2017-06-27 06:53:54 --> Model Class Initialized
INFO - 2017-06-27 06:53:54 --> Helper loaded: form_helper
INFO - 2017-06-27 06:53:54 --> Helper loaded: url_helper
INFO - 2017-06-27 06:53:54 --> Model Class Initialized
INFO - 2017-06-27 06:53:54 --> Final output sent to browser
DEBUG - 2017-06-27 06:53:54 --> Total execution time: 0.0710
ERROR - 2017-06-27 06:58:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 06:58:23 --> Config Class Initialized
INFO - 2017-06-27 06:58:23 --> Hooks Class Initialized
DEBUG - 2017-06-27 06:58:23 --> UTF-8 Support Enabled
INFO - 2017-06-27 06:58:23 --> Utf8 Class Initialized
INFO - 2017-06-27 06:58:23 --> URI Class Initialized
INFO - 2017-06-27 06:58:23 --> Router Class Initialized
INFO - 2017-06-27 06:58:23 --> Output Class Initialized
INFO - 2017-06-27 06:58:23 --> Security Class Initialized
DEBUG - 2017-06-27 06:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 06:58:23 --> Input Class Initialized
INFO - 2017-06-27 06:58:23 --> Language Class Initialized
INFO - 2017-06-27 06:58:23 --> Loader Class Initialized
INFO - 2017-06-27 06:58:23 --> Controller Class Initialized
INFO - 2017-06-27 06:58:23 --> Database Driver Class Initialized
INFO - 2017-06-27 06:58:23 --> Model Class Initialized
INFO - 2017-06-27 06:58:23 --> Helper loaded: form_helper
INFO - 2017-06-27 06:58:23 --> Helper loaded: url_helper
INFO - 2017-06-27 06:58:23 --> Model Class Initialized
INFO - 2017-06-27 06:58:23 --> Final output sent to browser
DEBUG - 2017-06-27 06:58:23 --> Total execution time: 0.0500
ERROR - 2017-06-27 07:00:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 07:00:15 --> Config Class Initialized
INFO - 2017-06-27 07:00:15 --> Hooks Class Initialized
DEBUG - 2017-06-27 07:00:15 --> UTF-8 Support Enabled
INFO - 2017-06-27 07:00:15 --> Utf8 Class Initialized
INFO - 2017-06-27 07:00:15 --> URI Class Initialized
INFO - 2017-06-27 07:00:15 --> Router Class Initialized
INFO - 2017-06-27 07:00:15 --> Output Class Initialized
INFO - 2017-06-27 07:00:15 --> Security Class Initialized
DEBUG - 2017-06-27 07:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 07:00:15 --> Input Class Initialized
INFO - 2017-06-27 07:00:15 --> Language Class Initialized
INFO - 2017-06-27 07:00:15 --> Loader Class Initialized
INFO - 2017-06-27 07:00:15 --> Controller Class Initialized
INFO - 2017-06-27 07:00:15 --> Database Driver Class Initialized
INFO - 2017-06-27 07:00:15 --> Model Class Initialized
INFO - 2017-06-27 07:00:15 --> Helper loaded: form_helper
INFO - 2017-06-27 07:00:15 --> Helper loaded: url_helper
INFO - 2017-06-27 07:00:15 --> Model Class Initialized
INFO - 2017-06-27 07:00:15 --> Final output sent to browser
DEBUG - 2017-06-27 07:00:15 --> Total execution time: 0.0620
ERROR - 2017-06-27 07:01:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 07:01:19 --> Config Class Initialized
INFO - 2017-06-27 07:01:19 --> Hooks Class Initialized
DEBUG - 2017-06-27 07:01:19 --> UTF-8 Support Enabled
INFO - 2017-06-27 07:01:19 --> Utf8 Class Initialized
INFO - 2017-06-27 07:01:19 --> URI Class Initialized
INFO - 2017-06-27 07:01:20 --> Router Class Initialized
INFO - 2017-06-27 07:01:20 --> Output Class Initialized
INFO - 2017-06-27 07:01:20 --> Security Class Initialized
DEBUG - 2017-06-27 07:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 07:01:20 --> Input Class Initialized
INFO - 2017-06-27 07:01:20 --> Language Class Initialized
INFO - 2017-06-27 07:01:20 --> Loader Class Initialized
INFO - 2017-06-27 07:01:20 --> Controller Class Initialized
INFO - 2017-06-27 07:01:20 --> Database Driver Class Initialized
INFO - 2017-06-27 07:01:20 --> Model Class Initialized
INFO - 2017-06-27 07:01:20 --> Helper loaded: form_helper
INFO - 2017-06-27 07:01:20 --> Helper loaded: url_helper
INFO - 2017-06-27 07:01:20 --> Model Class Initialized
INFO - 2017-06-27 07:01:20 --> Final output sent to browser
DEBUG - 2017-06-27 07:01:20 --> Total execution time: 0.0490
ERROR - 2017-06-27 07:01:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 07:01:57 --> Config Class Initialized
INFO - 2017-06-27 07:01:57 --> Hooks Class Initialized
DEBUG - 2017-06-27 07:01:57 --> UTF-8 Support Enabled
INFO - 2017-06-27 07:01:57 --> Utf8 Class Initialized
INFO - 2017-06-27 07:01:57 --> URI Class Initialized
INFO - 2017-06-27 07:01:57 --> Router Class Initialized
INFO - 2017-06-27 07:01:57 --> Output Class Initialized
INFO - 2017-06-27 07:01:57 --> Security Class Initialized
DEBUG - 2017-06-27 07:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 07:01:57 --> Input Class Initialized
INFO - 2017-06-27 07:01:57 --> Language Class Initialized
INFO - 2017-06-27 07:01:57 --> Loader Class Initialized
INFO - 2017-06-27 07:01:57 --> Controller Class Initialized
INFO - 2017-06-27 07:01:57 --> Database Driver Class Initialized
INFO - 2017-06-27 07:01:57 --> Model Class Initialized
INFO - 2017-06-27 07:01:57 --> Helper loaded: form_helper
INFO - 2017-06-27 07:01:57 --> Helper loaded: url_helper
INFO - 2017-06-27 07:01:57 --> Model Class Initialized
INFO - 2017-06-27 07:01:57 --> Final output sent to browser
DEBUG - 2017-06-27 07:01:57 --> Total execution time: 0.0520
ERROR - 2017-06-27 07:02:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 07:02:35 --> Config Class Initialized
INFO - 2017-06-27 07:02:35 --> Hooks Class Initialized
DEBUG - 2017-06-27 07:02:35 --> UTF-8 Support Enabled
INFO - 2017-06-27 07:02:35 --> Utf8 Class Initialized
INFO - 2017-06-27 07:02:35 --> URI Class Initialized
INFO - 2017-06-27 07:02:35 --> Router Class Initialized
INFO - 2017-06-27 07:02:35 --> Output Class Initialized
INFO - 2017-06-27 07:02:35 --> Security Class Initialized
DEBUG - 2017-06-27 07:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 07:02:35 --> Input Class Initialized
INFO - 2017-06-27 07:02:35 --> Language Class Initialized
INFO - 2017-06-27 07:02:35 --> Loader Class Initialized
INFO - 2017-06-27 07:02:35 --> Controller Class Initialized
INFO - 2017-06-27 07:02:35 --> Database Driver Class Initialized
INFO - 2017-06-27 07:02:35 --> Model Class Initialized
INFO - 2017-06-27 07:02:35 --> Helper loaded: form_helper
INFO - 2017-06-27 07:02:35 --> Helper loaded: url_helper
INFO - 2017-06-27 07:02:35 --> Model Class Initialized
INFO - 2017-06-27 07:02:35 --> Final output sent to browser
DEBUG - 2017-06-27 07:02:35 --> Total execution time: 0.0510
ERROR - 2017-06-27 07:03:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 07:03:28 --> Config Class Initialized
INFO - 2017-06-27 07:03:28 --> Hooks Class Initialized
DEBUG - 2017-06-27 07:03:28 --> UTF-8 Support Enabled
INFO - 2017-06-27 07:03:28 --> Utf8 Class Initialized
INFO - 2017-06-27 07:03:28 --> URI Class Initialized
INFO - 2017-06-27 07:03:28 --> Router Class Initialized
INFO - 2017-06-27 07:03:28 --> Output Class Initialized
INFO - 2017-06-27 07:03:28 --> Security Class Initialized
DEBUG - 2017-06-27 07:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 07:03:28 --> Input Class Initialized
INFO - 2017-06-27 07:03:28 --> Language Class Initialized
INFO - 2017-06-27 07:03:28 --> Loader Class Initialized
INFO - 2017-06-27 07:03:28 --> Controller Class Initialized
INFO - 2017-06-27 07:03:28 --> Database Driver Class Initialized
INFO - 2017-06-27 07:03:28 --> Model Class Initialized
INFO - 2017-06-27 07:03:28 --> Helper loaded: form_helper
INFO - 2017-06-27 07:03:28 --> Helper loaded: url_helper
INFO - 2017-06-27 07:03:28 --> Model Class Initialized
INFO - 2017-06-27 07:03:28 --> Final output sent to browser
DEBUG - 2017-06-27 07:03:28 --> Total execution time: 0.0510
ERROR - 2017-06-27 07:04:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 07:04:48 --> Config Class Initialized
INFO - 2017-06-27 07:04:48 --> Hooks Class Initialized
DEBUG - 2017-06-27 07:04:48 --> UTF-8 Support Enabled
INFO - 2017-06-27 07:04:48 --> Utf8 Class Initialized
INFO - 2017-06-27 07:04:48 --> URI Class Initialized
INFO - 2017-06-27 07:04:48 --> Router Class Initialized
INFO - 2017-06-27 07:04:48 --> Output Class Initialized
INFO - 2017-06-27 07:04:48 --> Security Class Initialized
DEBUG - 2017-06-27 07:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 07:04:48 --> Input Class Initialized
INFO - 2017-06-27 07:04:48 --> Language Class Initialized
INFO - 2017-06-27 07:04:48 --> Loader Class Initialized
INFO - 2017-06-27 07:04:48 --> Controller Class Initialized
INFO - 2017-06-27 07:04:48 --> Database Driver Class Initialized
INFO - 2017-06-27 07:04:48 --> Model Class Initialized
INFO - 2017-06-27 07:04:48 --> Helper loaded: form_helper
INFO - 2017-06-27 07:04:48 --> Helper loaded: url_helper
INFO - 2017-06-27 07:04:48 --> Model Class Initialized
INFO - 2017-06-27 07:04:48 --> Final output sent to browser
DEBUG - 2017-06-27 07:04:48 --> Total execution time: 0.0550
ERROR - 2017-06-27 07:05:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 07:05:39 --> Config Class Initialized
INFO - 2017-06-27 07:05:39 --> Hooks Class Initialized
DEBUG - 2017-06-27 07:05:39 --> UTF-8 Support Enabled
INFO - 2017-06-27 07:05:39 --> Utf8 Class Initialized
INFO - 2017-06-27 07:05:39 --> URI Class Initialized
INFO - 2017-06-27 07:05:39 --> Router Class Initialized
INFO - 2017-06-27 07:05:39 --> Output Class Initialized
INFO - 2017-06-27 07:05:39 --> Security Class Initialized
DEBUG - 2017-06-27 07:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 07:05:39 --> Input Class Initialized
INFO - 2017-06-27 07:05:39 --> Language Class Initialized
INFO - 2017-06-27 07:05:39 --> Loader Class Initialized
INFO - 2017-06-27 07:05:39 --> Controller Class Initialized
INFO - 2017-06-27 07:05:39 --> Database Driver Class Initialized
INFO - 2017-06-27 07:05:39 --> Model Class Initialized
INFO - 2017-06-27 07:05:39 --> Helper loaded: form_helper
INFO - 2017-06-27 07:05:39 --> Helper loaded: url_helper
INFO - 2017-06-27 07:05:39 --> Model Class Initialized
INFO - 2017-06-27 07:05:39 --> Final output sent to browser
DEBUG - 2017-06-27 07:05:39 --> Total execution time: 0.0580
ERROR - 2017-06-27 07:06:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 07:06:16 --> Config Class Initialized
INFO - 2017-06-27 07:06:16 --> Hooks Class Initialized
DEBUG - 2017-06-27 07:06:16 --> UTF-8 Support Enabled
INFO - 2017-06-27 07:06:16 --> Utf8 Class Initialized
INFO - 2017-06-27 07:06:16 --> URI Class Initialized
INFO - 2017-06-27 07:06:16 --> Router Class Initialized
INFO - 2017-06-27 07:06:16 --> Output Class Initialized
INFO - 2017-06-27 07:06:16 --> Security Class Initialized
DEBUG - 2017-06-27 07:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 07:06:16 --> Input Class Initialized
INFO - 2017-06-27 07:06:16 --> Language Class Initialized
INFO - 2017-06-27 07:06:16 --> Loader Class Initialized
INFO - 2017-06-27 07:06:16 --> Controller Class Initialized
INFO - 2017-06-27 07:06:16 --> Database Driver Class Initialized
INFO - 2017-06-27 07:06:16 --> Model Class Initialized
INFO - 2017-06-27 07:06:16 --> Helper loaded: form_helper
INFO - 2017-06-27 07:06:16 --> Helper loaded: url_helper
INFO - 2017-06-27 07:06:16 --> Model Class Initialized
INFO - 2017-06-27 07:06:16 --> Final output sent to browser
DEBUG - 2017-06-27 07:06:16 --> Total execution time: 0.0640
ERROR - 2017-06-27 07:07:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 07:07:18 --> Config Class Initialized
INFO - 2017-06-27 07:07:18 --> Hooks Class Initialized
DEBUG - 2017-06-27 07:07:18 --> UTF-8 Support Enabled
INFO - 2017-06-27 07:07:18 --> Utf8 Class Initialized
INFO - 2017-06-27 07:07:18 --> URI Class Initialized
INFO - 2017-06-27 07:07:18 --> Router Class Initialized
INFO - 2017-06-27 07:07:18 --> Output Class Initialized
INFO - 2017-06-27 07:07:18 --> Security Class Initialized
DEBUG - 2017-06-27 07:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 07:07:18 --> Input Class Initialized
INFO - 2017-06-27 07:07:18 --> Language Class Initialized
INFO - 2017-06-27 07:07:18 --> Loader Class Initialized
INFO - 2017-06-27 07:07:18 --> Controller Class Initialized
INFO - 2017-06-27 07:07:18 --> Database Driver Class Initialized
INFO - 2017-06-27 07:07:18 --> Model Class Initialized
INFO - 2017-06-27 07:07:18 --> Helper loaded: form_helper
INFO - 2017-06-27 07:07:18 --> Helper loaded: url_helper
INFO - 2017-06-27 07:07:18 --> Model Class Initialized
INFO - 2017-06-27 07:07:18 --> Final output sent to browser
DEBUG - 2017-06-27 07:07:18 --> Total execution time: 0.0510
ERROR - 2017-06-27 07:08:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 07:08:33 --> Config Class Initialized
INFO - 2017-06-27 07:08:33 --> Hooks Class Initialized
DEBUG - 2017-06-27 07:08:33 --> UTF-8 Support Enabled
INFO - 2017-06-27 07:08:33 --> Utf8 Class Initialized
INFO - 2017-06-27 07:08:33 --> URI Class Initialized
INFO - 2017-06-27 07:08:33 --> Router Class Initialized
INFO - 2017-06-27 07:08:33 --> Output Class Initialized
INFO - 2017-06-27 07:08:33 --> Security Class Initialized
DEBUG - 2017-06-27 07:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 07:08:33 --> Input Class Initialized
INFO - 2017-06-27 07:08:33 --> Language Class Initialized
INFO - 2017-06-27 07:08:33 --> Loader Class Initialized
INFO - 2017-06-27 07:08:33 --> Controller Class Initialized
INFO - 2017-06-27 07:08:33 --> Database Driver Class Initialized
INFO - 2017-06-27 07:08:33 --> Model Class Initialized
INFO - 2017-06-27 07:08:33 --> Helper loaded: form_helper
INFO - 2017-06-27 07:08:33 --> Helper loaded: url_helper
INFO - 2017-06-27 07:08:33 --> Model Class Initialized
INFO - 2017-06-27 07:08:33 --> Final output sent to browser
DEBUG - 2017-06-27 07:08:33 --> Total execution time: 0.0580
ERROR - 2017-06-27 07:09:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 07:09:41 --> Config Class Initialized
INFO - 2017-06-27 07:09:41 --> Hooks Class Initialized
DEBUG - 2017-06-27 07:09:41 --> UTF-8 Support Enabled
INFO - 2017-06-27 07:09:41 --> Utf8 Class Initialized
INFO - 2017-06-27 07:09:41 --> URI Class Initialized
INFO - 2017-06-27 07:09:41 --> Router Class Initialized
INFO - 2017-06-27 07:09:41 --> Output Class Initialized
INFO - 2017-06-27 07:09:41 --> Security Class Initialized
DEBUG - 2017-06-27 07:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 07:09:41 --> Input Class Initialized
INFO - 2017-06-27 07:09:41 --> Language Class Initialized
INFO - 2017-06-27 07:09:41 --> Loader Class Initialized
INFO - 2017-06-27 07:09:41 --> Controller Class Initialized
INFO - 2017-06-27 07:09:41 --> Database Driver Class Initialized
INFO - 2017-06-27 07:09:41 --> Model Class Initialized
INFO - 2017-06-27 07:09:41 --> Helper loaded: form_helper
INFO - 2017-06-27 07:09:41 --> Helper loaded: url_helper
INFO - 2017-06-27 07:09:41 --> Model Class Initialized
INFO - 2017-06-27 07:09:41 --> Final output sent to browser
DEBUG - 2017-06-27 07:09:41 --> Total execution time: 0.0510
ERROR - 2017-06-27 07:10:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 07:10:36 --> Config Class Initialized
INFO - 2017-06-27 07:10:36 --> Hooks Class Initialized
DEBUG - 2017-06-27 07:10:36 --> UTF-8 Support Enabled
INFO - 2017-06-27 07:10:36 --> Utf8 Class Initialized
INFO - 2017-06-27 07:10:36 --> URI Class Initialized
INFO - 2017-06-27 07:10:36 --> Router Class Initialized
INFO - 2017-06-27 07:10:36 --> Output Class Initialized
INFO - 2017-06-27 07:10:36 --> Security Class Initialized
DEBUG - 2017-06-27 07:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 07:10:36 --> Input Class Initialized
INFO - 2017-06-27 07:10:36 --> Language Class Initialized
INFO - 2017-06-27 07:10:36 --> Loader Class Initialized
INFO - 2017-06-27 07:10:36 --> Controller Class Initialized
INFO - 2017-06-27 07:10:36 --> Database Driver Class Initialized
INFO - 2017-06-27 07:10:36 --> Model Class Initialized
INFO - 2017-06-27 07:10:36 --> Helper loaded: form_helper
INFO - 2017-06-27 07:10:36 --> Helper loaded: url_helper
INFO - 2017-06-27 07:10:36 --> Model Class Initialized
INFO - 2017-06-27 07:10:36 --> Final output sent to browser
DEBUG - 2017-06-27 07:10:36 --> Total execution time: 0.0640
ERROR - 2017-06-27 07:11:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 07:11:46 --> Config Class Initialized
INFO - 2017-06-27 07:11:46 --> Hooks Class Initialized
DEBUG - 2017-06-27 07:11:46 --> UTF-8 Support Enabled
INFO - 2017-06-27 07:11:46 --> Utf8 Class Initialized
INFO - 2017-06-27 07:11:46 --> URI Class Initialized
INFO - 2017-06-27 07:11:46 --> Router Class Initialized
INFO - 2017-06-27 07:11:46 --> Output Class Initialized
INFO - 2017-06-27 07:11:46 --> Security Class Initialized
DEBUG - 2017-06-27 07:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 07:11:46 --> Input Class Initialized
INFO - 2017-06-27 07:11:46 --> Language Class Initialized
INFO - 2017-06-27 07:11:46 --> Loader Class Initialized
INFO - 2017-06-27 07:11:46 --> Controller Class Initialized
INFO - 2017-06-27 07:11:46 --> Database Driver Class Initialized
INFO - 2017-06-27 07:11:46 --> Model Class Initialized
INFO - 2017-06-27 07:11:46 --> Helper loaded: form_helper
INFO - 2017-06-27 07:11:47 --> Helper loaded: url_helper
INFO - 2017-06-27 07:11:47 --> Model Class Initialized
INFO - 2017-06-27 07:11:47 --> Final output sent to browser
DEBUG - 2017-06-27 07:11:47 --> Total execution time: 0.0630
ERROR - 2017-06-27 07:13:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 07:13:36 --> Config Class Initialized
INFO - 2017-06-27 07:13:36 --> Hooks Class Initialized
DEBUG - 2017-06-27 07:13:36 --> UTF-8 Support Enabled
INFO - 2017-06-27 07:13:36 --> Utf8 Class Initialized
INFO - 2017-06-27 07:13:36 --> URI Class Initialized
INFO - 2017-06-27 07:13:36 --> Router Class Initialized
INFO - 2017-06-27 07:13:36 --> Output Class Initialized
INFO - 2017-06-27 07:13:36 --> Security Class Initialized
DEBUG - 2017-06-27 07:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 07:13:36 --> Input Class Initialized
INFO - 2017-06-27 07:13:36 --> Language Class Initialized
INFO - 2017-06-27 07:13:36 --> Loader Class Initialized
INFO - 2017-06-27 07:13:36 --> Controller Class Initialized
INFO - 2017-06-27 07:13:36 --> Database Driver Class Initialized
INFO - 2017-06-27 07:13:36 --> Model Class Initialized
INFO - 2017-06-27 07:13:36 --> Helper loaded: form_helper
INFO - 2017-06-27 07:13:36 --> Helper loaded: url_helper
INFO - 2017-06-27 07:13:36 --> Model Class Initialized
INFO - 2017-06-27 07:13:36 --> Final output sent to browser
DEBUG - 2017-06-27 07:13:36 --> Total execution time: 0.0570
ERROR - 2017-06-27 07:14:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 07:14:55 --> Config Class Initialized
INFO - 2017-06-27 07:14:55 --> Hooks Class Initialized
DEBUG - 2017-06-27 07:14:55 --> UTF-8 Support Enabled
INFO - 2017-06-27 07:14:55 --> Utf8 Class Initialized
INFO - 2017-06-27 07:14:55 --> URI Class Initialized
INFO - 2017-06-27 07:14:55 --> Router Class Initialized
INFO - 2017-06-27 07:14:55 --> Output Class Initialized
INFO - 2017-06-27 07:14:55 --> Security Class Initialized
DEBUG - 2017-06-27 07:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 07:14:55 --> Input Class Initialized
INFO - 2017-06-27 07:14:55 --> Language Class Initialized
INFO - 2017-06-27 07:14:55 --> Loader Class Initialized
INFO - 2017-06-27 07:14:55 --> Controller Class Initialized
INFO - 2017-06-27 07:14:55 --> Database Driver Class Initialized
INFO - 2017-06-27 07:14:55 --> Model Class Initialized
INFO - 2017-06-27 07:14:55 --> Helper loaded: form_helper
INFO - 2017-06-27 07:14:55 --> Helper loaded: url_helper
INFO - 2017-06-27 07:14:55 --> Model Class Initialized
INFO - 2017-06-27 07:14:55 --> Final output sent to browser
DEBUG - 2017-06-27 07:14:55 --> Total execution time: 0.0650
ERROR - 2017-06-27 07:53:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 07:53:57 --> Config Class Initialized
INFO - 2017-06-27 07:53:57 --> Hooks Class Initialized
DEBUG - 2017-06-27 07:53:57 --> UTF-8 Support Enabled
INFO - 2017-06-27 07:53:57 --> Utf8 Class Initialized
INFO - 2017-06-27 07:53:57 --> URI Class Initialized
INFO - 2017-06-27 07:53:57 --> Router Class Initialized
INFO - 2017-06-27 07:53:57 --> Output Class Initialized
INFO - 2017-06-27 07:53:57 --> Security Class Initialized
DEBUG - 2017-06-27 07:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 07:53:57 --> Input Class Initialized
INFO - 2017-06-27 07:53:57 --> Language Class Initialized
INFO - 2017-06-27 07:53:57 --> Loader Class Initialized
INFO - 2017-06-27 07:53:57 --> Controller Class Initialized
INFO - 2017-06-27 07:53:57 --> Database Driver Class Initialized
INFO - 2017-06-27 07:53:57 --> Model Class Initialized
INFO - 2017-06-27 07:53:57 --> Helper loaded: form_helper
INFO - 2017-06-27 07:53:57 --> Helper loaded: url_helper
INFO - 2017-06-27 07:53:57 --> Model Class Initialized
INFO - 2017-06-27 07:53:57 --> Final output sent to browser
DEBUG - 2017-06-27 07:53:57 --> Total execution time: 0.0550
ERROR - 2017-06-27 08:04:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 08:04:58 --> Config Class Initialized
INFO - 2017-06-27 08:04:58 --> Hooks Class Initialized
DEBUG - 2017-06-27 08:04:58 --> UTF-8 Support Enabled
INFO - 2017-06-27 08:04:58 --> Utf8 Class Initialized
INFO - 2017-06-27 08:04:58 --> URI Class Initialized
INFO - 2017-06-27 08:04:58 --> Router Class Initialized
INFO - 2017-06-27 08:04:58 --> Output Class Initialized
INFO - 2017-06-27 08:04:58 --> Security Class Initialized
DEBUG - 2017-06-27 08:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 08:04:58 --> Input Class Initialized
INFO - 2017-06-27 08:04:58 --> Language Class Initialized
INFO - 2017-06-27 08:04:58 --> Loader Class Initialized
INFO - 2017-06-27 08:04:58 --> Controller Class Initialized
INFO - 2017-06-27 08:04:58 --> Database Driver Class Initialized
INFO - 2017-06-27 08:04:58 --> Model Class Initialized
INFO - 2017-06-27 08:04:58 --> Helper loaded: form_helper
INFO - 2017-06-27 08:04:58 --> Helper loaded: url_helper
INFO - 2017-06-27 08:04:58 --> Model Class Initialized
INFO - 2017-06-27 08:04:58 --> Final output sent to browser
DEBUG - 2017-06-27 08:04:58 --> Total execution time: 0.0520
ERROR - 2017-06-27 08:07:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 08:07:03 --> Config Class Initialized
INFO - 2017-06-27 08:07:03 --> Hooks Class Initialized
DEBUG - 2017-06-27 08:07:03 --> UTF-8 Support Enabled
INFO - 2017-06-27 08:07:03 --> Utf8 Class Initialized
INFO - 2017-06-27 08:07:03 --> URI Class Initialized
INFO - 2017-06-27 08:07:03 --> Router Class Initialized
INFO - 2017-06-27 08:07:03 --> Output Class Initialized
INFO - 2017-06-27 08:07:03 --> Security Class Initialized
DEBUG - 2017-06-27 08:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 08:07:03 --> Input Class Initialized
INFO - 2017-06-27 08:07:03 --> Language Class Initialized
INFO - 2017-06-27 08:07:03 --> Loader Class Initialized
INFO - 2017-06-27 08:07:03 --> Controller Class Initialized
INFO - 2017-06-27 08:07:03 --> Database Driver Class Initialized
INFO - 2017-06-27 08:07:03 --> Model Class Initialized
INFO - 2017-06-27 08:07:03 --> Helper loaded: form_helper
INFO - 2017-06-27 08:07:03 --> Helper loaded: url_helper
INFO - 2017-06-27 08:07:03 --> Model Class Initialized
INFO - 2017-06-27 08:07:03 --> Final output sent to browser
DEBUG - 2017-06-27 08:07:03 --> Total execution time: 0.0720
ERROR - 2017-06-27 08:30:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 08:30:18 --> Config Class Initialized
INFO - 2017-06-27 08:30:18 --> Hooks Class Initialized
DEBUG - 2017-06-27 08:30:18 --> UTF-8 Support Enabled
INFO - 2017-06-27 08:30:18 --> Utf8 Class Initialized
INFO - 2017-06-27 08:30:18 --> URI Class Initialized
INFO - 2017-06-27 08:30:18 --> Router Class Initialized
INFO - 2017-06-27 08:30:18 --> Output Class Initialized
INFO - 2017-06-27 08:30:18 --> Security Class Initialized
DEBUG - 2017-06-27 08:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 08:30:18 --> Input Class Initialized
INFO - 2017-06-27 08:30:18 --> Language Class Initialized
INFO - 2017-06-27 08:30:18 --> Loader Class Initialized
INFO - 2017-06-27 08:30:18 --> Controller Class Initialized
INFO - 2017-06-27 08:30:18 --> Database Driver Class Initialized
INFO - 2017-06-27 08:30:18 --> Model Class Initialized
INFO - 2017-06-27 08:30:18 --> Helper loaded: form_helper
INFO - 2017-06-27 08:30:18 --> Helper loaded: url_helper
INFO - 2017-06-27 08:30:18 --> Model Class Initialized
INFO - 2017-06-27 08:30:18 --> Final output sent to browser
DEBUG - 2017-06-27 08:30:18 --> Total execution time: 0.0520
ERROR - 2017-06-27 08:30:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 08:30:33 --> Config Class Initialized
INFO - 2017-06-27 08:30:33 --> Hooks Class Initialized
DEBUG - 2017-06-27 08:30:33 --> UTF-8 Support Enabled
INFO - 2017-06-27 08:30:33 --> Utf8 Class Initialized
INFO - 2017-06-27 08:30:33 --> URI Class Initialized
INFO - 2017-06-27 08:30:33 --> Router Class Initialized
INFO - 2017-06-27 08:30:33 --> Output Class Initialized
INFO - 2017-06-27 08:30:33 --> Security Class Initialized
DEBUG - 2017-06-27 08:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 08:30:33 --> Input Class Initialized
INFO - 2017-06-27 08:30:33 --> Language Class Initialized
INFO - 2017-06-27 08:30:33 --> Loader Class Initialized
INFO - 2017-06-27 08:30:33 --> Controller Class Initialized
INFO - 2017-06-27 08:30:33 --> Database Driver Class Initialized
INFO - 2017-06-27 08:30:33 --> Model Class Initialized
INFO - 2017-06-27 08:30:33 --> Helper loaded: form_helper
INFO - 2017-06-27 08:30:33 --> Helper loaded: url_helper
INFO - 2017-06-27 08:30:33 --> Model Class Initialized
INFO - 2017-06-27 08:30:33 --> Final output sent to browser
DEBUG - 2017-06-27 08:30:33 --> Total execution time: 0.1430
ERROR - 2017-06-27 08:30:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 08:30:34 --> Config Class Initialized
INFO - 2017-06-27 08:30:34 --> Hooks Class Initialized
DEBUG - 2017-06-27 08:30:34 --> UTF-8 Support Enabled
INFO - 2017-06-27 08:30:34 --> Utf8 Class Initialized
INFO - 2017-06-27 08:30:34 --> URI Class Initialized
INFO - 2017-06-27 08:30:34 --> Router Class Initialized
INFO - 2017-06-27 08:30:34 --> Output Class Initialized
INFO - 2017-06-27 08:30:34 --> Security Class Initialized
DEBUG - 2017-06-27 08:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 08:30:34 --> Input Class Initialized
INFO - 2017-06-27 08:30:34 --> Language Class Initialized
INFO - 2017-06-27 08:30:34 --> Loader Class Initialized
INFO - 2017-06-27 08:30:34 --> Controller Class Initialized
INFO - 2017-06-27 08:30:34 --> Database Driver Class Initialized
INFO - 2017-06-27 08:30:34 --> Model Class Initialized
INFO - 2017-06-27 08:30:34 --> Helper loaded: form_helper
INFO - 2017-06-27 08:30:34 --> Helper loaded: url_helper
INFO - 2017-06-27 08:30:34 --> Model Class Initialized
INFO - 2017-06-27 08:30:34 --> Final output sent to browser
DEBUG - 2017-06-27 08:30:34 --> Total execution time: 0.0870
ERROR - 2017-06-27 09:22:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 09:22:52 --> Config Class Initialized
INFO - 2017-06-27 09:22:52 --> Hooks Class Initialized
DEBUG - 2017-06-27 09:22:52 --> UTF-8 Support Enabled
INFO - 2017-06-27 09:22:52 --> Utf8 Class Initialized
INFO - 2017-06-27 09:22:52 --> URI Class Initialized
INFO - 2017-06-27 09:22:52 --> Router Class Initialized
INFO - 2017-06-27 09:22:52 --> Output Class Initialized
INFO - 2017-06-27 09:22:52 --> Security Class Initialized
DEBUG - 2017-06-27 09:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 09:22:52 --> Input Class Initialized
INFO - 2017-06-27 09:22:52 --> Language Class Initialized
INFO - 2017-06-27 09:22:52 --> Loader Class Initialized
INFO - 2017-06-27 09:22:52 --> Controller Class Initialized
INFO - 2017-06-27 09:22:52 --> Database Driver Class Initialized
INFO - 2017-06-27 09:22:52 --> Model Class Initialized
INFO - 2017-06-27 09:22:53 --> Helper loaded: form_helper
INFO - 2017-06-27 09:22:53 --> Helper loaded: url_helper
INFO - 2017-06-27 09:22:53 --> Model Class Initialized
INFO - 2017-06-27 09:22:53 --> Final output sent to browser
DEBUG - 2017-06-27 09:22:53 --> Total execution time: 0.6200
ERROR - 2017-06-27 09:25:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 09:25:07 --> Config Class Initialized
INFO - 2017-06-27 09:25:07 --> Hooks Class Initialized
DEBUG - 2017-06-27 09:25:07 --> UTF-8 Support Enabled
INFO - 2017-06-27 09:25:07 --> Utf8 Class Initialized
INFO - 2017-06-27 09:25:07 --> URI Class Initialized
INFO - 2017-06-27 09:25:07 --> Router Class Initialized
INFO - 2017-06-27 09:25:07 --> Output Class Initialized
INFO - 2017-06-27 09:25:07 --> Security Class Initialized
DEBUG - 2017-06-27 09:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 09:25:07 --> Input Class Initialized
INFO - 2017-06-27 09:25:07 --> Language Class Initialized
INFO - 2017-06-27 09:25:07 --> Loader Class Initialized
INFO - 2017-06-27 09:25:07 --> Controller Class Initialized
INFO - 2017-06-27 09:25:07 --> Database Driver Class Initialized
INFO - 2017-06-27 09:25:07 --> Model Class Initialized
INFO - 2017-06-27 09:25:07 --> Helper loaded: form_helper
INFO - 2017-06-27 09:25:07 --> Helper loaded: url_helper
INFO - 2017-06-27 09:25:07 --> Model Class Initialized
INFO - 2017-06-27 09:25:07 --> Final output sent to browser
DEBUG - 2017-06-27 09:25:07 --> Total execution time: 0.0590
ERROR - 2017-06-27 09:28:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 09:28:37 --> Config Class Initialized
INFO - 2017-06-27 09:28:37 --> Hooks Class Initialized
DEBUG - 2017-06-27 09:28:37 --> UTF-8 Support Enabled
INFO - 2017-06-27 09:28:37 --> Utf8 Class Initialized
INFO - 2017-06-27 09:28:37 --> URI Class Initialized
INFO - 2017-06-27 09:28:37 --> Router Class Initialized
INFO - 2017-06-27 09:28:37 --> Output Class Initialized
INFO - 2017-06-27 09:28:37 --> Security Class Initialized
DEBUG - 2017-06-27 09:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 09:28:37 --> Input Class Initialized
INFO - 2017-06-27 09:28:37 --> Language Class Initialized
INFO - 2017-06-27 09:28:37 --> Loader Class Initialized
INFO - 2017-06-27 09:28:37 --> Controller Class Initialized
INFO - 2017-06-27 09:28:37 --> Database Driver Class Initialized
INFO - 2017-06-27 09:28:37 --> Model Class Initialized
INFO - 2017-06-27 09:28:37 --> Helper loaded: form_helper
INFO - 2017-06-27 09:28:37 --> Helper loaded: url_helper
INFO - 2017-06-27 09:28:37 --> Model Class Initialized
INFO - 2017-06-27 09:28:37 --> Final output sent to browser
DEBUG - 2017-06-27 09:28:37 --> Total execution time: 0.0640
ERROR - 2017-06-27 09:32:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 09:32:59 --> Config Class Initialized
INFO - 2017-06-27 09:32:59 --> Hooks Class Initialized
DEBUG - 2017-06-27 09:32:59 --> UTF-8 Support Enabled
INFO - 2017-06-27 09:32:59 --> Utf8 Class Initialized
INFO - 2017-06-27 09:32:59 --> URI Class Initialized
INFO - 2017-06-27 09:32:59 --> Router Class Initialized
INFO - 2017-06-27 09:32:59 --> Output Class Initialized
INFO - 2017-06-27 09:32:59 --> Security Class Initialized
DEBUG - 2017-06-27 09:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 09:32:59 --> Input Class Initialized
INFO - 2017-06-27 09:32:59 --> Language Class Initialized
INFO - 2017-06-27 09:32:59 --> Loader Class Initialized
INFO - 2017-06-27 09:32:59 --> Controller Class Initialized
INFO - 2017-06-27 09:32:59 --> Database Driver Class Initialized
INFO - 2017-06-27 09:32:59 --> Model Class Initialized
INFO - 2017-06-27 09:32:59 --> Helper loaded: form_helper
INFO - 2017-06-27 09:32:59 --> Helper loaded: url_helper
INFO - 2017-06-27 09:32:59 --> Model Class Initialized
INFO - 2017-06-27 09:32:59 --> Final output sent to browser
DEBUG - 2017-06-27 09:32:59 --> Total execution time: 0.0630
ERROR - 2017-06-27 09:37:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 09:37:41 --> Config Class Initialized
INFO - 2017-06-27 09:37:41 --> Hooks Class Initialized
DEBUG - 2017-06-27 09:37:41 --> UTF-8 Support Enabled
INFO - 2017-06-27 09:37:41 --> Utf8 Class Initialized
INFO - 2017-06-27 09:37:41 --> URI Class Initialized
INFO - 2017-06-27 09:37:41 --> Router Class Initialized
INFO - 2017-06-27 09:37:41 --> Output Class Initialized
INFO - 2017-06-27 09:37:41 --> Security Class Initialized
DEBUG - 2017-06-27 09:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 09:37:41 --> Input Class Initialized
INFO - 2017-06-27 09:37:41 --> Language Class Initialized
INFO - 2017-06-27 09:37:41 --> Loader Class Initialized
INFO - 2017-06-27 09:37:41 --> Controller Class Initialized
INFO - 2017-06-27 09:37:41 --> Database Driver Class Initialized
INFO - 2017-06-27 09:37:42 --> Model Class Initialized
INFO - 2017-06-27 09:37:42 --> Helper loaded: form_helper
INFO - 2017-06-27 09:37:42 --> Helper loaded: url_helper
INFO - 2017-06-27 09:37:42 --> Model Class Initialized
INFO - 2017-06-27 09:37:42 --> Final output sent to browser
DEBUG - 2017-06-27 09:37:42 --> Total execution time: 0.0690
ERROR - 2017-06-27 09:39:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 09:39:05 --> Config Class Initialized
INFO - 2017-06-27 09:39:05 --> Hooks Class Initialized
DEBUG - 2017-06-27 09:39:05 --> UTF-8 Support Enabled
INFO - 2017-06-27 09:39:05 --> Utf8 Class Initialized
INFO - 2017-06-27 09:39:05 --> URI Class Initialized
INFO - 2017-06-27 09:39:05 --> Router Class Initialized
INFO - 2017-06-27 09:39:05 --> Output Class Initialized
INFO - 2017-06-27 09:39:05 --> Security Class Initialized
DEBUG - 2017-06-27 09:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 09:39:05 --> Input Class Initialized
INFO - 2017-06-27 09:39:05 --> Language Class Initialized
INFO - 2017-06-27 09:39:05 --> Loader Class Initialized
INFO - 2017-06-27 09:39:05 --> Controller Class Initialized
INFO - 2017-06-27 09:39:05 --> Database Driver Class Initialized
INFO - 2017-06-27 09:39:05 --> Model Class Initialized
INFO - 2017-06-27 09:39:05 --> Helper loaded: form_helper
INFO - 2017-06-27 09:39:05 --> Helper loaded: url_helper
INFO - 2017-06-27 09:39:05 --> Model Class Initialized
INFO - 2017-06-27 09:39:05 --> Final output sent to browser
DEBUG - 2017-06-27 09:39:05 --> Total execution time: 0.0560
ERROR - 2017-06-27 13:29:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 13:29:08 --> Config Class Initialized
INFO - 2017-06-27 13:29:08 --> Hooks Class Initialized
DEBUG - 2017-06-27 13:29:08 --> UTF-8 Support Enabled
INFO - 2017-06-27 13:29:08 --> Utf8 Class Initialized
INFO - 2017-06-27 13:29:08 --> URI Class Initialized
INFO - 2017-06-27 13:29:08 --> Router Class Initialized
INFO - 2017-06-27 13:29:08 --> Output Class Initialized
INFO - 2017-06-27 13:29:08 --> Security Class Initialized
DEBUG - 2017-06-27 13:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 13:29:08 --> Input Class Initialized
INFO - 2017-06-27 13:29:08 --> Language Class Initialized
INFO - 2017-06-27 13:29:08 --> Loader Class Initialized
INFO - 2017-06-27 13:29:08 --> Controller Class Initialized
INFO - 2017-06-27 13:29:08 --> Database Driver Class Initialized
INFO - 2017-06-27 13:29:08 --> Model Class Initialized
INFO - 2017-06-27 13:29:08 --> Helper loaded: form_helper
INFO - 2017-06-27 13:29:08 --> Helper loaded: url_helper
INFO - 2017-06-27 13:29:08 --> Model Class Initialized
INFO - 2017-06-27 13:29:08 --> Final output sent to browser
DEBUG - 2017-06-27 13:29:08 --> Total execution time: 0.0490
ERROR - 2017-06-27 13:48:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 13:48:00 --> Config Class Initialized
INFO - 2017-06-27 13:48:00 --> Hooks Class Initialized
DEBUG - 2017-06-27 13:48:00 --> UTF-8 Support Enabled
INFO - 2017-06-27 13:48:00 --> Utf8 Class Initialized
INFO - 2017-06-27 13:48:00 --> URI Class Initialized
INFO - 2017-06-27 13:48:00 --> Router Class Initialized
INFO - 2017-06-27 13:48:00 --> Output Class Initialized
INFO - 2017-06-27 13:48:00 --> Security Class Initialized
DEBUG - 2017-06-27 13:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 13:48:00 --> Input Class Initialized
INFO - 2017-06-27 13:48:00 --> Language Class Initialized
INFO - 2017-06-27 13:48:00 --> Loader Class Initialized
INFO - 2017-06-27 13:48:00 --> Controller Class Initialized
INFO - 2017-06-27 13:48:00 --> Database Driver Class Initialized
INFO - 2017-06-27 13:48:00 --> Model Class Initialized
INFO - 2017-06-27 13:48:00 --> Helper loaded: form_helper
INFO - 2017-06-27 13:48:00 --> Helper loaded: url_helper
INFO - 2017-06-27 13:48:00 --> Model Class Initialized
INFO - 2017-06-27 13:48:00 --> Final output sent to browser
DEBUG - 2017-06-27 13:48:00 --> Total execution time: 0.0530
ERROR - 2017-06-27 16:23:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 16:23:55 --> Config Class Initialized
INFO - 2017-06-27 16:23:55 --> Hooks Class Initialized
DEBUG - 2017-06-27 16:23:55 --> UTF-8 Support Enabled
INFO - 2017-06-27 16:23:55 --> Utf8 Class Initialized
INFO - 2017-06-27 16:23:55 --> URI Class Initialized
INFO - 2017-06-27 16:23:55 --> Router Class Initialized
INFO - 2017-06-27 16:23:55 --> Output Class Initialized
INFO - 2017-06-27 16:23:55 --> Security Class Initialized
DEBUG - 2017-06-27 16:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 16:23:55 --> Input Class Initialized
INFO - 2017-06-27 16:23:55 --> Language Class Initialized
INFO - 2017-06-27 16:23:55 --> Loader Class Initialized
INFO - 2017-06-27 16:23:55 --> Controller Class Initialized
INFO - 2017-06-27 16:23:55 --> Database Driver Class Initialized
INFO - 2017-06-27 16:23:55 --> Model Class Initialized
INFO - 2017-06-27 16:23:55 --> Helper loaded: form_helper
INFO - 2017-06-27 16:23:55 --> Helper loaded: url_helper
INFO - 2017-06-27 16:23:55 --> Model Class Initialized
INFO - 2017-06-27 16:23:55 --> Final output sent to browser
DEBUG - 2017-06-27 16:23:55 --> Total execution time: 0.0560
ERROR - 2017-06-27 16:24:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 16:24:22 --> Config Class Initialized
INFO - 2017-06-27 16:24:22 --> Hooks Class Initialized
DEBUG - 2017-06-27 16:24:22 --> UTF-8 Support Enabled
INFO - 2017-06-27 16:24:22 --> Utf8 Class Initialized
INFO - 2017-06-27 16:24:22 --> URI Class Initialized
INFO - 2017-06-27 16:24:22 --> Router Class Initialized
INFO - 2017-06-27 16:24:22 --> Output Class Initialized
INFO - 2017-06-27 16:24:22 --> Security Class Initialized
DEBUG - 2017-06-27 16:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 16:24:22 --> Input Class Initialized
INFO - 2017-06-27 16:24:22 --> Language Class Initialized
INFO - 2017-06-27 16:24:22 --> Loader Class Initialized
INFO - 2017-06-27 16:24:22 --> Controller Class Initialized
INFO - 2017-06-27 16:24:22 --> Database Driver Class Initialized
INFO - 2017-06-27 16:24:22 --> Model Class Initialized
INFO - 2017-06-27 16:24:22 --> Helper loaded: form_helper
INFO - 2017-06-27 16:24:22 --> Helper loaded: url_helper
INFO - 2017-06-27 16:24:22 --> Model Class Initialized
INFO - 2017-06-27 16:24:22 --> Final output sent to browser
DEBUG - 2017-06-27 16:24:22 --> Total execution time: 0.0490
ERROR - 2017-06-27 16:24:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-06-27 16:24:24 --> Config Class Initialized
INFO - 2017-06-27 16:24:24 --> Hooks Class Initialized
DEBUG - 2017-06-27 16:24:24 --> UTF-8 Support Enabled
INFO - 2017-06-27 16:24:24 --> Utf8 Class Initialized
INFO - 2017-06-27 16:24:24 --> URI Class Initialized
INFO - 2017-06-27 16:24:24 --> Router Class Initialized
INFO - 2017-06-27 16:24:24 --> Output Class Initialized
INFO - 2017-06-27 16:24:24 --> Security Class Initialized
DEBUG - 2017-06-27 16:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-27 16:24:24 --> Input Class Initialized
INFO - 2017-06-27 16:24:24 --> Language Class Initialized
INFO - 2017-06-27 16:24:24 --> Loader Class Initialized
INFO - 2017-06-27 16:24:24 --> Controller Class Initialized
INFO - 2017-06-27 16:24:24 --> Database Driver Class Initialized
INFO - 2017-06-27 16:24:24 --> Model Class Initialized
INFO - 2017-06-27 16:24:24 --> Helper loaded: form_helper
INFO - 2017-06-27 16:24:24 --> Helper loaded: url_helper
INFO - 2017-06-27 16:24:24 --> Model Class Initialized
INFO - 2017-06-27 16:24:24 --> Final output sent to browser
DEBUG - 2017-06-27 16:24:24 --> Total execution time: 0.1060
