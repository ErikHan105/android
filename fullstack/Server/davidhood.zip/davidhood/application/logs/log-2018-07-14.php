<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-14 07:03:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 07:03:58 --> Config Class Initialized
INFO - 2018-07-14 07:03:58 --> Hooks Class Initialized
DEBUG - 2018-07-14 07:03:58 --> UTF-8 Support Enabled
INFO - 2018-07-14 07:03:58 --> Utf8 Class Initialized
INFO - 2018-07-14 07:03:58 --> URI Class Initialized
DEBUG - 2018-07-14 07:03:58 --> No URI present. Default controller set.
INFO - 2018-07-14 07:03:58 --> Router Class Initialized
INFO - 2018-07-14 07:03:58 --> Output Class Initialized
INFO - 2018-07-14 07:03:58 --> Security Class Initialized
DEBUG - 2018-07-14 07:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 07:03:58 --> Input Class Initialized
INFO - 2018-07-14 07:03:58 --> Language Class Initialized
INFO - 2018-07-14 07:03:58 --> Loader Class Initialized
INFO - 2018-07-14 07:03:58 --> Controller Class Initialized
INFO - 2018-07-14 07:03:58 --> Database Driver Class Initialized
INFO - 2018-07-14 07:03:58 --> Model Class Initialized
INFO - 2018-07-14 07:03:58 --> Helper loaded: url_helper
DEBUG - 2018-07-14 07:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 07:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 07:03:58 --> Model Class Initialized
INFO - 2018-07-14 07:03:58 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-14 07:03:58 --> Final output sent to browser
DEBUG - 2018-07-14 07:03:58 --> Total execution time: 0.1429
ERROR - 2018-07-14 07:08:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 07:08:33 --> Config Class Initialized
INFO - 2018-07-14 07:08:33 --> Hooks Class Initialized
DEBUG - 2018-07-14 07:08:33 --> UTF-8 Support Enabled
INFO - 2018-07-14 07:08:33 --> Utf8 Class Initialized
INFO - 2018-07-14 07:08:33 --> URI Class Initialized
DEBUG - 2018-07-14 07:08:33 --> No URI present. Default controller set.
INFO - 2018-07-14 07:08:33 --> Router Class Initialized
INFO - 2018-07-14 07:08:33 --> Output Class Initialized
INFO - 2018-07-14 07:08:33 --> Security Class Initialized
DEBUG - 2018-07-14 07:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 07:08:33 --> Input Class Initialized
INFO - 2018-07-14 07:08:33 --> Language Class Initialized
INFO - 2018-07-14 07:08:33 --> Loader Class Initialized
INFO - 2018-07-14 07:08:33 --> Controller Class Initialized
INFO - 2018-07-14 07:08:33 --> Database Driver Class Initialized
INFO - 2018-07-14 07:08:33 --> Model Class Initialized
INFO - 2018-07-14 07:08:33 --> Helper loaded: url_helper
DEBUG - 2018-07-14 07:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 07:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 07:08:33 --> Model Class Initialized
INFO - 2018-07-14 07:08:33 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-14 07:08:33 --> Final output sent to browser
DEBUG - 2018-07-14 07:08:33 --> Total execution time: 0.0342
ERROR - 2018-07-14 07:09:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 07:09:06 --> Config Class Initialized
INFO - 2018-07-14 07:09:06 --> Hooks Class Initialized
DEBUG - 2018-07-14 07:09:06 --> UTF-8 Support Enabled
INFO - 2018-07-14 07:09:06 --> Utf8 Class Initialized
INFO - 2018-07-14 07:09:06 --> URI Class Initialized
DEBUG - 2018-07-14 07:09:06 --> No URI present. Default controller set.
INFO - 2018-07-14 07:09:06 --> Router Class Initialized
INFO - 2018-07-14 07:09:06 --> Output Class Initialized
INFO - 2018-07-14 07:09:06 --> Security Class Initialized
DEBUG - 2018-07-14 07:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 07:09:06 --> Input Class Initialized
INFO - 2018-07-14 07:09:06 --> Language Class Initialized
INFO - 2018-07-14 07:09:06 --> Loader Class Initialized
INFO - 2018-07-14 07:09:06 --> Controller Class Initialized
INFO - 2018-07-14 07:09:06 --> Database Driver Class Initialized
INFO - 2018-07-14 07:09:06 --> Model Class Initialized
INFO - 2018-07-14 07:09:06 --> Helper loaded: url_helper
DEBUG - 2018-07-14 07:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 07:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 07:09:06 --> Model Class Initialized
INFO - 2018-07-14 07:09:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-14 07:09:06 --> Final output sent to browser
DEBUG - 2018-07-14 07:09:06 --> Total execution time: 0.0359
ERROR - 2018-07-14 07:09:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 07:09:51 --> Config Class Initialized
INFO - 2018-07-14 07:09:51 --> Hooks Class Initialized
DEBUG - 2018-07-14 07:09:51 --> UTF-8 Support Enabled
INFO - 2018-07-14 07:09:51 --> Utf8 Class Initialized
INFO - 2018-07-14 07:09:51 --> URI Class Initialized
DEBUG - 2018-07-14 07:09:51 --> No URI present. Default controller set.
INFO - 2018-07-14 07:09:51 --> Router Class Initialized
INFO - 2018-07-14 07:09:51 --> Output Class Initialized
INFO - 2018-07-14 07:09:51 --> Security Class Initialized
DEBUG - 2018-07-14 07:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 07:09:51 --> Input Class Initialized
INFO - 2018-07-14 07:09:51 --> Language Class Initialized
INFO - 2018-07-14 07:09:51 --> Loader Class Initialized
INFO - 2018-07-14 07:09:51 --> Controller Class Initialized
INFO - 2018-07-14 07:09:51 --> Database Driver Class Initialized
INFO - 2018-07-14 07:09:51 --> Model Class Initialized
INFO - 2018-07-14 07:09:51 --> Helper loaded: url_helper
DEBUG - 2018-07-14 07:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 07:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 07:09:51 --> Model Class Initialized
INFO - 2018-07-14 07:09:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-14 07:09:51 --> Final output sent to browser
DEBUG - 2018-07-14 07:09:51 --> Total execution time: 0.0333
ERROR - 2018-07-14 07:10:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 07:10:19 --> Config Class Initialized
INFO - 2018-07-14 07:10:19 --> Hooks Class Initialized
DEBUG - 2018-07-14 07:10:19 --> UTF-8 Support Enabled
INFO - 2018-07-14 07:10:19 --> Utf8 Class Initialized
INFO - 2018-07-14 07:10:19 --> URI Class Initialized
DEBUG - 2018-07-14 07:10:19 --> No URI present. Default controller set.
INFO - 2018-07-14 07:10:19 --> Router Class Initialized
INFO - 2018-07-14 07:10:19 --> Output Class Initialized
INFO - 2018-07-14 07:10:19 --> Security Class Initialized
DEBUG - 2018-07-14 07:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 07:10:19 --> Input Class Initialized
INFO - 2018-07-14 07:10:19 --> Language Class Initialized
INFO - 2018-07-14 07:10:19 --> Loader Class Initialized
INFO - 2018-07-14 07:10:19 --> Controller Class Initialized
INFO - 2018-07-14 07:10:19 --> Database Driver Class Initialized
INFO - 2018-07-14 07:10:19 --> Model Class Initialized
INFO - 2018-07-14 07:10:19 --> Helper loaded: url_helper
DEBUG - 2018-07-14 07:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 07:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 07:10:19 --> Model Class Initialized
INFO - 2018-07-14 07:10:19 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-14 07:10:19 --> Final output sent to browser
DEBUG - 2018-07-14 07:10:19 --> Total execution time: 0.0388
ERROR - 2018-07-14 07:10:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 07:10:34 --> Config Class Initialized
INFO - 2018-07-14 07:10:34 --> Hooks Class Initialized
DEBUG - 2018-07-14 07:10:34 --> UTF-8 Support Enabled
INFO - 2018-07-14 07:10:34 --> Utf8 Class Initialized
INFO - 2018-07-14 07:10:34 --> URI Class Initialized
DEBUG - 2018-07-14 07:10:34 --> No URI present. Default controller set.
INFO - 2018-07-14 07:10:34 --> Router Class Initialized
INFO - 2018-07-14 07:10:34 --> Output Class Initialized
INFO - 2018-07-14 07:10:34 --> Security Class Initialized
DEBUG - 2018-07-14 07:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 07:10:34 --> Input Class Initialized
INFO - 2018-07-14 07:10:34 --> Language Class Initialized
INFO - 2018-07-14 07:10:34 --> Loader Class Initialized
INFO - 2018-07-14 07:10:34 --> Controller Class Initialized
INFO - 2018-07-14 07:10:34 --> Database Driver Class Initialized
INFO - 2018-07-14 07:10:34 --> Model Class Initialized
INFO - 2018-07-14 07:10:34 --> Helper loaded: url_helper
DEBUG - 2018-07-14 07:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 07:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 07:10:34 --> Model Class Initialized
INFO - 2018-07-14 07:10:34 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-14 07:10:34 --> Final output sent to browser
DEBUG - 2018-07-14 07:10:34 --> Total execution time: 0.0489
ERROR - 2018-07-14 07:10:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 07:10:39 --> Config Class Initialized
INFO - 2018-07-14 07:10:39 --> Hooks Class Initialized
DEBUG - 2018-07-14 07:10:39 --> UTF-8 Support Enabled
INFO - 2018-07-14 07:10:39 --> Utf8 Class Initialized
INFO - 2018-07-14 07:10:39 --> URI Class Initialized
INFO - 2018-07-14 07:10:39 --> Router Class Initialized
INFO - 2018-07-14 07:10:39 --> Output Class Initialized
INFO - 2018-07-14 07:10:39 --> Security Class Initialized
DEBUG - 2018-07-14 07:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 07:10:39 --> Input Class Initialized
INFO - 2018-07-14 07:10:39 --> Language Class Initialized
INFO - 2018-07-14 07:10:39 --> Loader Class Initialized
INFO - 2018-07-14 07:10:39 --> Controller Class Initialized
INFO - 2018-07-14 07:10:39 --> Database Driver Class Initialized
INFO - 2018-07-14 07:10:39 --> Model Class Initialized
INFO - 2018-07-14 07:10:39 --> Helper loaded: url_helper
DEBUG - 2018-07-14 07:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 07:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 07:10:39 --> Model Class Initialized
ERROR - 2018-07-14 07:10:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 07:10:39 --> Config Class Initialized
INFO - 2018-07-14 07:10:39 --> Hooks Class Initialized
DEBUG - 2018-07-14 07:10:39 --> UTF-8 Support Enabled
INFO - 2018-07-14 07:10:39 --> Utf8 Class Initialized
INFO - 2018-07-14 07:10:39 --> URI Class Initialized
INFO - 2018-07-14 07:10:39 --> Router Class Initialized
INFO - 2018-07-14 07:10:39 --> Output Class Initialized
INFO - 2018-07-14 07:10:39 --> Security Class Initialized
DEBUG - 2018-07-14 07:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 07:10:39 --> Input Class Initialized
INFO - 2018-07-14 07:10:39 --> Language Class Initialized
INFO - 2018-07-14 07:10:40 --> Loader Class Initialized
INFO - 2018-07-14 07:10:40 --> Controller Class Initialized
INFO - 2018-07-14 07:10:40 --> Database Driver Class Initialized
INFO - 2018-07-14 07:10:40 --> Model Class Initialized
INFO - 2018-07-14 07:10:40 --> Helper loaded: url_helper
DEBUG - 2018-07-14 07:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 07:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 07:10:40 --> Model Class Initialized
INFO - 2018-07-14 07:10:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 07:10:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 07:10:40 --> Final output sent to browser
DEBUG - 2018-07-14 07:10:40 --> Total execution time: 0.2314
ERROR - 2018-07-14 07:11:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 07:11:50 --> Config Class Initialized
INFO - 2018-07-14 07:11:50 --> Hooks Class Initialized
DEBUG - 2018-07-14 07:11:50 --> UTF-8 Support Enabled
INFO - 2018-07-14 07:11:50 --> Utf8 Class Initialized
INFO - 2018-07-14 07:11:50 --> URI Class Initialized
INFO - 2018-07-14 07:11:50 --> Router Class Initialized
INFO - 2018-07-14 07:11:50 --> Output Class Initialized
INFO - 2018-07-14 07:11:50 --> Security Class Initialized
DEBUG - 2018-07-14 07:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 07:11:50 --> Input Class Initialized
INFO - 2018-07-14 07:11:50 --> Language Class Initialized
INFO - 2018-07-14 07:11:50 --> Loader Class Initialized
INFO - 2018-07-14 07:11:50 --> Controller Class Initialized
INFO - 2018-07-14 07:11:50 --> Database Driver Class Initialized
INFO - 2018-07-14 07:11:50 --> Model Class Initialized
INFO - 2018-07-14 07:11:50 --> Helper loaded: url_helper
DEBUG - 2018-07-14 07:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 07:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 07:11:50 --> Model Class Initialized
INFO - 2018-07-14 07:11:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 07:11:50 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 07:11:50 --> Final output sent to browser
DEBUG - 2018-07-14 07:11:50 --> Total execution time: 0.0811
ERROR - 2018-07-14 07:11:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 07:11:51 --> Config Class Initialized
INFO - 2018-07-14 07:11:51 --> Hooks Class Initialized
DEBUG - 2018-07-14 07:11:51 --> UTF-8 Support Enabled
INFO - 2018-07-14 07:11:51 --> Utf8 Class Initialized
INFO - 2018-07-14 07:11:51 --> URI Class Initialized
INFO - 2018-07-14 07:11:51 --> Router Class Initialized
INFO - 2018-07-14 07:11:51 --> Output Class Initialized
INFO - 2018-07-14 07:11:51 --> Security Class Initialized
DEBUG - 2018-07-14 07:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 07:11:51 --> Input Class Initialized
INFO - 2018-07-14 07:11:51 --> Language Class Initialized
INFO - 2018-07-14 07:11:51 --> Loader Class Initialized
INFO - 2018-07-14 07:11:51 --> Controller Class Initialized
INFO - 2018-07-14 07:11:51 --> Database Driver Class Initialized
INFO - 2018-07-14 07:11:51 --> Model Class Initialized
INFO - 2018-07-14 07:11:51 --> Helper loaded: url_helper
DEBUG - 2018-07-14 07:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 07:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 07:11:51 --> Model Class Initialized
INFO - 2018-07-14 07:11:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 07:11:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-14 07:11:51 --> Final output sent to browser
DEBUG - 2018-07-14 07:11:51 --> Total execution time: 0.1097
ERROR - 2018-07-14 07:11:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 07:11:54 --> Config Class Initialized
INFO - 2018-07-14 07:11:54 --> Hooks Class Initialized
DEBUG - 2018-07-14 07:11:54 --> UTF-8 Support Enabled
INFO - 2018-07-14 07:11:54 --> Utf8 Class Initialized
INFO - 2018-07-14 07:11:54 --> URI Class Initialized
INFO - 2018-07-14 07:11:54 --> Router Class Initialized
INFO - 2018-07-14 07:11:54 --> Output Class Initialized
INFO - 2018-07-14 07:11:54 --> Security Class Initialized
DEBUG - 2018-07-14 07:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 07:11:54 --> Input Class Initialized
INFO - 2018-07-14 07:11:54 --> Language Class Initialized
INFO - 2018-07-14 07:11:54 --> Loader Class Initialized
INFO - 2018-07-14 07:11:54 --> Controller Class Initialized
INFO - 2018-07-14 07:11:54 --> Database Driver Class Initialized
INFO - 2018-07-14 07:11:54 --> Model Class Initialized
INFO - 2018-07-14 07:11:54 --> Helper loaded: url_helper
DEBUG - 2018-07-14 07:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 07:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 07:11:54 --> Model Class Initialized
INFO - 2018-07-14 07:11:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 07:11:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 07:11:54 --> Final output sent to browser
DEBUG - 2018-07-14 07:11:54 --> Total execution time: 0.0350
ERROR - 2018-07-14 07:11:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 07:11:55 --> Config Class Initialized
INFO - 2018-07-14 07:11:55 --> Hooks Class Initialized
DEBUG - 2018-07-14 07:11:55 --> UTF-8 Support Enabled
INFO - 2018-07-14 07:11:55 --> Utf8 Class Initialized
INFO - 2018-07-14 07:11:55 --> URI Class Initialized
INFO - 2018-07-14 07:11:55 --> Router Class Initialized
INFO - 2018-07-14 07:11:55 --> Output Class Initialized
INFO - 2018-07-14 07:11:55 --> Security Class Initialized
DEBUG - 2018-07-14 07:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 07:11:55 --> Input Class Initialized
INFO - 2018-07-14 07:11:55 --> Language Class Initialized
INFO - 2018-07-14 07:11:55 --> Loader Class Initialized
INFO - 2018-07-14 07:11:55 --> Controller Class Initialized
INFO - 2018-07-14 07:11:55 --> Database Driver Class Initialized
INFO - 2018-07-14 07:11:55 --> Model Class Initialized
INFO - 2018-07-14 07:11:55 --> Helper loaded: url_helper
DEBUG - 2018-07-14 07:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 07:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 07:11:55 --> Model Class Initialized
INFO - 2018-07-14 07:11:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 07:11:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 07:11:55 --> Final output sent to browser
DEBUG - 2018-07-14 07:11:55 --> Total execution time: 0.0379
ERROR - 2018-07-14 07:11:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 07:11:56 --> Config Class Initialized
INFO - 2018-07-14 07:11:56 --> Hooks Class Initialized
DEBUG - 2018-07-14 07:11:56 --> UTF-8 Support Enabled
INFO - 2018-07-14 07:11:56 --> Utf8 Class Initialized
INFO - 2018-07-14 07:11:56 --> URI Class Initialized
INFO - 2018-07-14 07:11:56 --> Router Class Initialized
INFO - 2018-07-14 07:11:56 --> Output Class Initialized
INFO - 2018-07-14 07:11:56 --> Security Class Initialized
DEBUG - 2018-07-14 07:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 07:11:56 --> Input Class Initialized
INFO - 2018-07-14 07:11:56 --> Language Class Initialized
INFO - 2018-07-14 07:11:56 --> Loader Class Initialized
INFO - 2018-07-14 07:11:56 --> Controller Class Initialized
INFO - 2018-07-14 07:11:56 --> Database Driver Class Initialized
INFO - 2018-07-14 07:11:56 --> Model Class Initialized
INFO - 2018-07-14 07:11:56 --> Helper loaded: url_helper
DEBUG - 2018-07-14 07:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 07:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 07:11:56 --> Model Class Initialized
INFO - 2018-07-14 07:11:56 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 07:11:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\purchase.php
INFO - 2018-07-14 07:11:57 --> Final output sent to browser
DEBUG - 2018-07-14 07:11:57 --> Total execution time: 0.0360
ERROR - 2018-07-14 07:40:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 07:40:53 --> Config Class Initialized
INFO - 2018-07-14 07:40:53 --> Hooks Class Initialized
DEBUG - 2018-07-14 07:40:53 --> UTF-8 Support Enabled
INFO - 2018-07-14 07:40:53 --> Utf8 Class Initialized
INFO - 2018-07-14 07:40:53 --> URI Class Initialized
INFO - 2018-07-14 07:40:53 --> Router Class Initialized
INFO - 2018-07-14 07:40:53 --> Output Class Initialized
INFO - 2018-07-14 07:40:53 --> Security Class Initialized
DEBUG - 2018-07-14 07:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 07:40:53 --> Input Class Initialized
INFO - 2018-07-14 07:40:53 --> Language Class Initialized
INFO - 2018-07-14 07:40:53 --> Loader Class Initialized
INFO - 2018-07-14 07:40:53 --> Controller Class Initialized
INFO - 2018-07-14 07:40:53 --> Database Driver Class Initialized
INFO - 2018-07-14 07:40:53 --> Model Class Initialized
INFO - 2018-07-14 07:40:53 --> Helper loaded: url_helper
INFO - 2018-07-14 07:40:53 --> Model Class Initialized
INFO - 2018-07-14 07:40:53 --> Final output sent to browser
DEBUG - 2018-07-14 07:40:53 --> Total execution time: 0.0534
ERROR - 2018-07-14 08:31:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 08:31:46 --> Config Class Initialized
INFO - 2018-07-14 08:31:46 --> Hooks Class Initialized
DEBUG - 2018-07-14 08:31:46 --> UTF-8 Support Enabled
INFO - 2018-07-14 08:31:46 --> Utf8 Class Initialized
INFO - 2018-07-14 08:31:46 --> URI Class Initialized
INFO - 2018-07-14 08:31:46 --> Router Class Initialized
INFO - 2018-07-14 08:31:46 --> Output Class Initialized
INFO - 2018-07-14 08:31:46 --> Security Class Initialized
DEBUG - 2018-07-14 08:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 08:31:46 --> Input Class Initialized
INFO - 2018-07-14 08:31:46 --> Language Class Initialized
INFO - 2018-07-14 08:31:46 --> Loader Class Initialized
INFO - 2018-07-14 08:31:46 --> Controller Class Initialized
INFO - 2018-07-14 08:31:46 --> Database Driver Class Initialized
INFO - 2018-07-14 08:31:46 --> Model Class Initialized
INFO - 2018-07-14 08:31:46 --> Helper loaded: url_helper
INFO - 2018-07-14 08:31:46 --> Model Class Initialized
INFO - 2018-07-14 08:31:46 --> Final output sent to browser
DEBUG - 2018-07-14 08:31:46 --> Total execution time: 0.0647
ERROR - 2018-07-14 08:34:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 08:34:04 --> Config Class Initialized
INFO - 2018-07-14 08:34:04 --> Hooks Class Initialized
DEBUG - 2018-07-14 08:34:04 --> UTF-8 Support Enabled
INFO - 2018-07-14 08:34:04 --> Utf8 Class Initialized
INFO - 2018-07-14 08:34:04 --> URI Class Initialized
INFO - 2018-07-14 08:34:04 --> Router Class Initialized
INFO - 2018-07-14 08:34:04 --> Output Class Initialized
INFO - 2018-07-14 08:34:04 --> Security Class Initialized
DEBUG - 2018-07-14 08:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 08:34:04 --> Input Class Initialized
INFO - 2018-07-14 08:34:04 --> Language Class Initialized
INFO - 2018-07-14 08:34:04 --> Loader Class Initialized
INFO - 2018-07-14 08:34:04 --> Controller Class Initialized
INFO - 2018-07-14 08:34:04 --> Database Driver Class Initialized
INFO - 2018-07-14 08:34:04 --> Model Class Initialized
INFO - 2018-07-14 08:34:04 --> Helper loaded: url_helper
INFO - 2018-07-14 08:34:04 --> Model Class Initialized
INFO - 2018-07-14 08:34:04 --> Final output sent to browser
DEBUG - 2018-07-14 08:34:05 --> Total execution time: 0.0484
ERROR - 2018-07-14 08:47:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 08:47:40 --> Config Class Initialized
INFO - 2018-07-14 08:47:40 --> Hooks Class Initialized
DEBUG - 2018-07-14 08:47:40 --> UTF-8 Support Enabled
INFO - 2018-07-14 08:47:40 --> Utf8 Class Initialized
INFO - 2018-07-14 08:47:40 --> URI Class Initialized
INFO - 2018-07-14 08:47:40 --> Router Class Initialized
INFO - 2018-07-14 08:47:40 --> Output Class Initialized
INFO - 2018-07-14 08:47:40 --> Security Class Initialized
DEBUG - 2018-07-14 08:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 08:47:40 --> Input Class Initialized
INFO - 2018-07-14 08:47:40 --> Language Class Initialized
INFO - 2018-07-14 08:47:40 --> Loader Class Initialized
INFO - 2018-07-14 08:47:40 --> Controller Class Initialized
INFO - 2018-07-14 08:47:40 --> Database Driver Class Initialized
INFO - 2018-07-14 08:47:40 --> Model Class Initialized
INFO - 2018-07-14 08:47:40 --> Helper loaded: url_helper
INFO - 2018-07-14 08:47:40 --> Model Class Initialized
INFO - 2018-07-14 08:47:40 --> Final output sent to browser
DEBUG - 2018-07-14 08:47:40 --> Total execution time: 0.0497
ERROR - 2018-07-14 08:48:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 08:48:39 --> Config Class Initialized
INFO - 2018-07-14 08:48:39 --> Hooks Class Initialized
DEBUG - 2018-07-14 08:48:39 --> UTF-8 Support Enabled
INFO - 2018-07-14 08:48:39 --> Utf8 Class Initialized
INFO - 2018-07-14 08:48:39 --> URI Class Initialized
INFO - 2018-07-14 08:48:39 --> Router Class Initialized
INFO - 2018-07-14 08:48:39 --> Output Class Initialized
INFO - 2018-07-14 08:48:39 --> Security Class Initialized
DEBUG - 2018-07-14 08:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 08:48:39 --> Input Class Initialized
INFO - 2018-07-14 08:48:39 --> Language Class Initialized
INFO - 2018-07-14 08:48:39 --> Loader Class Initialized
INFO - 2018-07-14 08:48:39 --> Controller Class Initialized
INFO - 2018-07-14 08:48:39 --> Database Driver Class Initialized
INFO - 2018-07-14 08:48:39 --> Model Class Initialized
INFO - 2018-07-14 08:48:39 --> Helper loaded: url_helper
INFO - 2018-07-14 08:48:39 --> Model Class Initialized
INFO - 2018-07-14 08:48:39 --> Final output sent to browser
DEBUG - 2018-07-14 08:48:39 --> Total execution time: 0.0535
ERROR - 2018-07-14 08:49:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 08:49:32 --> Config Class Initialized
INFO - 2018-07-14 08:49:32 --> Hooks Class Initialized
DEBUG - 2018-07-14 08:49:32 --> UTF-8 Support Enabled
INFO - 2018-07-14 08:49:32 --> Utf8 Class Initialized
INFO - 2018-07-14 08:49:32 --> URI Class Initialized
INFO - 2018-07-14 08:49:32 --> Router Class Initialized
INFO - 2018-07-14 08:49:32 --> Output Class Initialized
INFO - 2018-07-14 08:49:32 --> Security Class Initialized
DEBUG - 2018-07-14 08:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 08:49:32 --> Input Class Initialized
INFO - 2018-07-14 08:49:32 --> Language Class Initialized
INFO - 2018-07-14 08:49:32 --> Loader Class Initialized
INFO - 2018-07-14 08:49:32 --> Controller Class Initialized
INFO - 2018-07-14 08:49:32 --> Database Driver Class Initialized
INFO - 2018-07-14 08:49:32 --> Model Class Initialized
INFO - 2018-07-14 08:49:32 --> Helper loaded: url_helper
INFO - 2018-07-14 08:49:32 --> Model Class Initialized
INFO - 2018-07-14 08:49:32 --> Final output sent to browser
DEBUG - 2018-07-14 08:49:32 --> Total execution time: 0.0542
ERROR - 2018-07-14 08:54:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 08:54:46 --> Config Class Initialized
INFO - 2018-07-14 08:54:46 --> Hooks Class Initialized
DEBUG - 2018-07-14 08:54:46 --> UTF-8 Support Enabled
INFO - 2018-07-14 08:54:46 --> Utf8 Class Initialized
INFO - 2018-07-14 08:54:46 --> URI Class Initialized
INFO - 2018-07-14 08:54:46 --> Router Class Initialized
INFO - 2018-07-14 08:54:46 --> Output Class Initialized
INFO - 2018-07-14 08:54:46 --> Security Class Initialized
DEBUG - 2018-07-14 08:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 08:54:46 --> Input Class Initialized
INFO - 2018-07-14 08:54:46 --> Language Class Initialized
INFO - 2018-07-14 08:54:46 --> Loader Class Initialized
INFO - 2018-07-14 08:54:46 --> Controller Class Initialized
INFO - 2018-07-14 08:54:46 --> Database Driver Class Initialized
INFO - 2018-07-14 08:54:46 --> Model Class Initialized
INFO - 2018-07-14 08:54:46 --> Helper loaded: url_helper
INFO - 2018-07-14 08:54:46 --> Model Class Initialized
INFO - 2018-07-14 08:54:46 --> Final output sent to browser
DEBUG - 2018-07-14 08:54:46 --> Total execution time: 0.0492
ERROR - 2018-07-14 09:05:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 09:05:59 --> Config Class Initialized
INFO - 2018-07-14 09:05:59 --> Hooks Class Initialized
DEBUG - 2018-07-14 09:05:59 --> UTF-8 Support Enabled
INFO - 2018-07-14 09:05:59 --> Utf8 Class Initialized
INFO - 2018-07-14 09:05:59 --> URI Class Initialized
INFO - 2018-07-14 09:05:59 --> Router Class Initialized
INFO - 2018-07-14 09:05:59 --> Output Class Initialized
INFO - 2018-07-14 09:05:59 --> Security Class Initialized
DEBUG - 2018-07-14 09:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 09:05:59 --> Input Class Initialized
INFO - 2018-07-14 09:05:59 --> Language Class Initialized
INFO - 2018-07-14 09:05:59 --> Loader Class Initialized
INFO - 2018-07-14 09:05:59 --> Controller Class Initialized
INFO - 2018-07-14 09:05:59 --> Database Driver Class Initialized
INFO - 2018-07-14 09:05:59 --> Model Class Initialized
INFO - 2018-07-14 09:05:59 --> Helper loaded: url_helper
INFO - 2018-07-14 09:05:59 --> Model Class Initialized
INFO - 2018-07-14 09:05:59 --> Final output sent to browser
DEBUG - 2018-07-14 09:05:59 --> Total execution time: 0.0759
ERROR - 2018-07-14 09:07:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 09:07:35 --> Config Class Initialized
INFO - 2018-07-14 09:07:35 --> Hooks Class Initialized
DEBUG - 2018-07-14 09:07:35 --> UTF-8 Support Enabled
INFO - 2018-07-14 09:07:35 --> Utf8 Class Initialized
INFO - 2018-07-14 09:07:35 --> URI Class Initialized
INFO - 2018-07-14 09:07:35 --> Router Class Initialized
INFO - 2018-07-14 09:07:35 --> Output Class Initialized
INFO - 2018-07-14 09:07:35 --> Security Class Initialized
DEBUG - 2018-07-14 09:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 09:07:35 --> Input Class Initialized
INFO - 2018-07-14 09:07:35 --> Language Class Initialized
INFO - 2018-07-14 09:07:35 --> Loader Class Initialized
INFO - 2018-07-14 09:07:35 --> Controller Class Initialized
INFO - 2018-07-14 09:07:35 --> Database Driver Class Initialized
INFO - 2018-07-14 09:07:35 --> Model Class Initialized
INFO - 2018-07-14 09:07:35 --> Helper loaded: url_helper
INFO - 2018-07-14 09:07:35 --> Model Class Initialized
INFO - 2018-07-14 09:07:35 --> Final output sent to browser
DEBUG - 2018-07-14 09:07:35 --> Total execution time: 0.0737
ERROR - 2018-07-14 09:07:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 09:07:45 --> Config Class Initialized
INFO - 2018-07-14 09:07:45 --> Hooks Class Initialized
DEBUG - 2018-07-14 09:07:45 --> UTF-8 Support Enabled
INFO - 2018-07-14 09:07:45 --> Utf8 Class Initialized
INFO - 2018-07-14 09:07:45 --> URI Class Initialized
INFO - 2018-07-14 09:07:45 --> Router Class Initialized
INFO - 2018-07-14 09:07:45 --> Output Class Initialized
INFO - 2018-07-14 09:07:45 --> Security Class Initialized
DEBUG - 2018-07-14 09:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 09:07:45 --> Input Class Initialized
INFO - 2018-07-14 09:07:45 --> Language Class Initialized
INFO - 2018-07-14 09:07:45 --> Loader Class Initialized
INFO - 2018-07-14 09:07:45 --> Controller Class Initialized
INFO - 2018-07-14 09:07:45 --> Database Driver Class Initialized
INFO - 2018-07-14 09:07:45 --> Model Class Initialized
INFO - 2018-07-14 09:07:45 --> Helper loaded: url_helper
INFO - 2018-07-14 09:07:45 --> Model Class Initialized
INFO - 2018-07-14 09:07:45 --> Final output sent to browser
DEBUG - 2018-07-14 09:07:45 --> Total execution time: 0.1048
ERROR - 2018-07-14 09:07:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 09:07:56 --> Config Class Initialized
INFO - 2018-07-14 09:07:56 --> Hooks Class Initialized
DEBUG - 2018-07-14 09:07:56 --> UTF-8 Support Enabled
INFO - 2018-07-14 09:07:56 --> Utf8 Class Initialized
INFO - 2018-07-14 09:07:56 --> URI Class Initialized
INFO - 2018-07-14 09:07:56 --> Router Class Initialized
INFO - 2018-07-14 09:07:56 --> Output Class Initialized
INFO - 2018-07-14 09:07:56 --> Security Class Initialized
DEBUG - 2018-07-14 09:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 09:07:56 --> Input Class Initialized
INFO - 2018-07-14 09:07:56 --> Language Class Initialized
INFO - 2018-07-14 09:07:56 --> Loader Class Initialized
INFO - 2018-07-14 09:07:56 --> Controller Class Initialized
INFO - 2018-07-14 09:07:56 --> Database Driver Class Initialized
INFO - 2018-07-14 09:07:56 --> Model Class Initialized
INFO - 2018-07-14 09:07:56 --> Helper loaded: url_helper
INFO - 2018-07-14 09:07:56 --> Model Class Initialized
INFO - 2018-07-14 09:07:56 --> Final output sent to browser
DEBUG - 2018-07-14 09:07:56 --> Total execution time: 0.0734
ERROR - 2018-07-14 11:52:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 11:52:30 --> Config Class Initialized
INFO - 2018-07-14 11:52:30 --> Hooks Class Initialized
DEBUG - 2018-07-14 11:52:30 --> UTF-8 Support Enabled
INFO - 2018-07-14 11:52:30 --> Utf8 Class Initialized
INFO - 2018-07-14 11:52:31 --> URI Class Initialized
INFO - 2018-07-14 11:52:31 --> Router Class Initialized
INFO - 2018-07-14 11:52:31 --> Output Class Initialized
INFO - 2018-07-14 11:52:31 --> Security Class Initialized
DEBUG - 2018-07-14 11:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 11:52:31 --> Input Class Initialized
INFO - 2018-07-14 11:52:31 --> Language Class Initialized
INFO - 2018-07-14 11:52:31 --> Loader Class Initialized
INFO - 2018-07-14 11:52:31 --> Controller Class Initialized
INFO - 2018-07-14 11:52:31 --> Database Driver Class Initialized
INFO - 2018-07-14 11:52:31 --> Model Class Initialized
INFO - 2018-07-14 11:52:31 --> Helper loaded: url_helper
INFO - 2018-07-14 11:52:31 --> Model Class Initialized
INFO - 2018-07-14 11:52:31 --> Final output sent to browser
DEBUG - 2018-07-14 11:52:31 --> Total execution time: 0.0770
ERROR - 2018-07-14 11:58:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 11:58:26 --> Config Class Initialized
INFO - 2018-07-14 11:58:26 --> Hooks Class Initialized
DEBUG - 2018-07-14 11:58:26 --> UTF-8 Support Enabled
INFO - 2018-07-14 11:58:26 --> Utf8 Class Initialized
INFO - 2018-07-14 11:58:26 --> URI Class Initialized
INFO - 2018-07-14 11:58:26 --> Router Class Initialized
INFO - 2018-07-14 11:58:26 --> Output Class Initialized
INFO - 2018-07-14 11:58:26 --> Security Class Initialized
DEBUG - 2018-07-14 11:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 11:58:26 --> Input Class Initialized
INFO - 2018-07-14 11:58:26 --> Language Class Initialized
INFO - 2018-07-14 11:58:26 --> Loader Class Initialized
INFO - 2018-07-14 11:58:26 --> Controller Class Initialized
INFO - 2018-07-14 11:58:26 --> Database Driver Class Initialized
INFO - 2018-07-14 11:58:26 --> Model Class Initialized
INFO - 2018-07-14 11:58:26 --> Helper loaded: url_helper
INFO - 2018-07-14 11:58:26 --> Model Class Initialized
INFO - 2018-07-14 11:58:26 --> Final output sent to browser
DEBUG - 2018-07-14 11:58:26 --> Total execution time: 0.0408
ERROR - 2018-07-14 11:58:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 11:58:33 --> Config Class Initialized
INFO - 2018-07-14 11:58:33 --> Hooks Class Initialized
DEBUG - 2018-07-14 11:58:33 --> UTF-8 Support Enabled
INFO - 2018-07-14 11:58:33 --> Utf8 Class Initialized
INFO - 2018-07-14 11:58:33 --> URI Class Initialized
INFO - 2018-07-14 11:58:33 --> Router Class Initialized
INFO - 2018-07-14 11:58:33 --> Output Class Initialized
INFO - 2018-07-14 11:58:33 --> Security Class Initialized
DEBUG - 2018-07-14 11:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 11:58:33 --> Input Class Initialized
INFO - 2018-07-14 11:58:33 --> Language Class Initialized
INFO - 2018-07-14 11:58:33 --> Loader Class Initialized
INFO - 2018-07-14 11:58:33 --> Controller Class Initialized
INFO - 2018-07-14 11:58:33 --> Database Driver Class Initialized
INFO - 2018-07-14 11:58:33 --> Model Class Initialized
INFO - 2018-07-14 11:58:33 --> Helper loaded: url_helper
INFO - 2018-07-14 11:58:33 --> Model Class Initialized
INFO - 2018-07-14 11:58:33 --> Final output sent to browser
DEBUG - 2018-07-14 11:58:33 --> Total execution time: 0.0625
ERROR - 2018-07-14 12:00:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 12:00:12 --> Config Class Initialized
INFO - 2018-07-14 12:00:12 --> Hooks Class Initialized
DEBUG - 2018-07-14 12:00:12 --> UTF-8 Support Enabled
INFO - 2018-07-14 12:00:12 --> Utf8 Class Initialized
INFO - 2018-07-14 12:00:12 --> URI Class Initialized
INFO - 2018-07-14 12:00:12 --> Router Class Initialized
INFO - 2018-07-14 12:00:12 --> Output Class Initialized
INFO - 2018-07-14 12:00:12 --> Security Class Initialized
DEBUG - 2018-07-14 12:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 12:00:12 --> Input Class Initialized
INFO - 2018-07-14 12:00:12 --> Language Class Initialized
INFO - 2018-07-14 12:00:12 --> Loader Class Initialized
INFO - 2018-07-14 12:00:12 --> Controller Class Initialized
INFO - 2018-07-14 12:00:12 --> Database Driver Class Initialized
INFO - 2018-07-14 12:00:12 --> Model Class Initialized
INFO - 2018-07-14 12:00:12 --> Helper loaded: url_helper
INFO - 2018-07-14 12:00:12 --> Model Class Initialized
INFO - 2018-07-14 12:00:12 --> Final output sent to browser
DEBUG - 2018-07-14 12:00:12 --> Total execution time: 0.0815
ERROR - 2018-07-14 12:00:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 12:00:28 --> Config Class Initialized
INFO - 2018-07-14 12:00:28 --> Hooks Class Initialized
DEBUG - 2018-07-14 12:00:28 --> UTF-8 Support Enabled
INFO - 2018-07-14 12:00:28 --> Utf8 Class Initialized
INFO - 2018-07-14 12:00:28 --> URI Class Initialized
INFO - 2018-07-14 12:00:28 --> Router Class Initialized
INFO - 2018-07-14 12:00:28 --> Output Class Initialized
INFO - 2018-07-14 12:00:28 --> Security Class Initialized
DEBUG - 2018-07-14 12:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 12:00:28 --> Input Class Initialized
INFO - 2018-07-14 12:00:28 --> Language Class Initialized
INFO - 2018-07-14 12:00:28 --> Loader Class Initialized
INFO - 2018-07-14 12:00:28 --> Controller Class Initialized
INFO - 2018-07-14 12:00:28 --> Database Driver Class Initialized
INFO - 2018-07-14 12:00:28 --> Model Class Initialized
INFO - 2018-07-14 12:00:28 --> Helper loaded: url_helper
INFO - 2018-07-14 12:00:28 --> Model Class Initialized
INFO - 2018-07-14 12:00:28 --> Final output sent to browser
DEBUG - 2018-07-14 12:00:28 --> Total execution time: 0.0523
ERROR - 2018-07-14 13:56:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 13:56:42 --> Config Class Initialized
INFO - 2018-07-14 13:56:42 --> Hooks Class Initialized
DEBUG - 2018-07-14 13:56:42 --> UTF-8 Support Enabled
INFO - 2018-07-14 13:56:42 --> Utf8 Class Initialized
INFO - 2018-07-14 13:56:42 --> URI Class Initialized
INFO - 2018-07-14 13:56:42 --> Router Class Initialized
INFO - 2018-07-14 13:56:42 --> Output Class Initialized
INFO - 2018-07-14 13:56:42 --> Security Class Initialized
DEBUG - 2018-07-14 13:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 13:56:42 --> Input Class Initialized
INFO - 2018-07-14 13:56:42 --> Language Class Initialized
INFO - 2018-07-14 13:56:42 --> Loader Class Initialized
INFO - 2018-07-14 13:56:42 --> Controller Class Initialized
INFO - 2018-07-14 13:56:42 --> Database Driver Class Initialized
INFO - 2018-07-14 13:56:42 --> Model Class Initialized
INFO - 2018-07-14 13:56:42 --> Helper loaded: url_helper
INFO - 2018-07-14 13:56:42 --> Model Class Initialized
INFO - 2018-07-14 13:56:42 --> Final output sent to browser
DEBUG - 2018-07-14 13:56:42 --> Total execution time: 0.0423
ERROR - 2018-07-14 13:58:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 13:58:25 --> Config Class Initialized
INFO - 2018-07-14 13:58:25 --> Hooks Class Initialized
DEBUG - 2018-07-14 13:58:25 --> UTF-8 Support Enabled
INFO - 2018-07-14 13:58:25 --> Utf8 Class Initialized
INFO - 2018-07-14 13:58:25 --> URI Class Initialized
INFO - 2018-07-14 13:58:25 --> Router Class Initialized
INFO - 2018-07-14 13:58:25 --> Output Class Initialized
INFO - 2018-07-14 13:58:25 --> Security Class Initialized
DEBUG - 2018-07-14 13:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 13:58:25 --> Input Class Initialized
INFO - 2018-07-14 13:58:25 --> Language Class Initialized
INFO - 2018-07-14 13:58:25 --> Loader Class Initialized
INFO - 2018-07-14 13:58:25 --> Controller Class Initialized
INFO - 2018-07-14 13:58:25 --> Database Driver Class Initialized
INFO - 2018-07-14 13:58:25 --> Model Class Initialized
INFO - 2018-07-14 13:58:25 --> Helper loaded: url_helper
INFO - 2018-07-14 13:58:25 --> Model Class Initialized
INFO - 2018-07-14 13:58:25 --> Final output sent to browser
DEBUG - 2018-07-14 13:58:25 --> Total execution time: 0.0414
ERROR - 2018-07-14 14:05:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 14:05:13 --> Config Class Initialized
INFO - 2018-07-14 14:05:13 --> Hooks Class Initialized
DEBUG - 2018-07-14 14:05:13 --> UTF-8 Support Enabled
INFO - 2018-07-14 14:05:13 --> Utf8 Class Initialized
INFO - 2018-07-14 14:05:13 --> URI Class Initialized
INFO - 2018-07-14 14:05:13 --> Router Class Initialized
INFO - 2018-07-14 14:05:13 --> Output Class Initialized
INFO - 2018-07-14 14:05:13 --> Security Class Initialized
DEBUG - 2018-07-14 14:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 14:05:13 --> Input Class Initialized
INFO - 2018-07-14 14:05:13 --> Language Class Initialized
INFO - 2018-07-14 14:05:13 --> Loader Class Initialized
INFO - 2018-07-14 14:05:13 --> Controller Class Initialized
INFO - 2018-07-14 14:05:13 --> Database Driver Class Initialized
INFO - 2018-07-14 14:05:13 --> Model Class Initialized
INFO - 2018-07-14 14:05:13 --> Helper loaded: url_helper
INFO - 2018-07-14 14:05:13 --> Model Class Initialized
INFO - 2018-07-14 14:05:13 --> Final output sent to browser
DEBUG - 2018-07-14 14:05:13 --> Total execution time: 0.0373
ERROR - 2018-07-14 14:32:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 14:32:19 --> Config Class Initialized
INFO - 2018-07-14 14:32:19 --> Hooks Class Initialized
DEBUG - 2018-07-14 14:32:19 --> UTF-8 Support Enabled
INFO - 2018-07-14 14:32:19 --> Utf8 Class Initialized
INFO - 2018-07-14 14:32:19 --> URI Class Initialized
INFO - 2018-07-14 14:32:19 --> Router Class Initialized
INFO - 2018-07-14 14:32:19 --> Output Class Initialized
INFO - 2018-07-14 14:32:19 --> Security Class Initialized
DEBUG - 2018-07-14 14:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 14:32:19 --> Input Class Initialized
INFO - 2018-07-14 14:32:19 --> Language Class Initialized
INFO - 2018-07-14 14:32:19 --> Loader Class Initialized
INFO - 2018-07-14 14:32:19 --> Controller Class Initialized
INFO - 2018-07-14 14:32:19 --> Database Driver Class Initialized
INFO - 2018-07-14 14:32:19 --> Model Class Initialized
INFO - 2018-07-14 14:32:19 --> Helper loaded: url_helper
INFO - 2018-07-14 14:32:19 --> Model Class Initialized
INFO - 2018-07-14 14:32:19 --> Final output sent to browser
DEBUG - 2018-07-14 14:32:19 --> Total execution time: 0.0401
ERROR - 2018-07-14 14:41:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 14:41:46 --> Config Class Initialized
INFO - 2018-07-14 14:41:46 --> Hooks Class Initialized
DEBUG - 2018-07-14 14:41:46 --> UTF-8 Support Enabled
INFO - 2018-07-14 14:41:46 --> Utf8 Class Initialized
INFO - 2018-07-14 14:41:46 --> URI Class Initialized
INFO - 2018-07-14 14:41:46 --> Router Class Initialized
INFO - 2018-07-14 14:41:46 --> Output Class Initialized
INFO - 2018-07-14 14:41:46 --> Security Class Initialized
DEBUG - 2018-07-14 14:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 14:41:46 --> Input Class Initialized
INFO - 2018-07-14 14:41:46 --> Language Class Initialized
INFO - 2018-07-14 14:41:46 --> Loader Class Initialized
INFO - 2018-07-14 14:41:46 --> Controller Class Initialized
INFO - 2018-07-14 14:41:46 --> Database Driver Class Initialized
INFO - 2018-07-14 14:41:46 --> Model Class Initialized
INFO - 2018-07-14 14:41:46 --> Helper loaded: url_helper
INFO - 2018-07-14 14:41:46 --> Model Class Initialized
INFO - 2018-07-14 14:41:46 --> Final output sent to browser
DEBUG - 2018-07-14 14:41:46 --> Total execution time: 0.0414
ERROR - 2018-07-14 14:42:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 14:42:49 --> Config Class Initialized
INFO - 2018-07-14 14:42:49 --> Hooks Class Initialized
DEBUG - 2018-07-14 14:42:49 --> UTF-8 Support Enabled
INFO - 2018-07-14 14:42:49 --> Utf8 Class Initialized
INFO - 2018-07-14 14:42:49 --> URI Class Initialized
INFO - 2018-07-14 14:42:49 --> Router Class Initialized
INFO - 2018-07-14 14:42:49 --> Output Class Initialized
INFO - 2018-07-14 14:42:49 --> Security Class Initialized
DEBUG - 2018-07-14 14:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 14:42:49 --> Input Class Initialized
INFO - 2018-07-14 14:42:49 --> Language Class Initialized
INFO - 2018-07-14 14:42:49 --> Loader Class Initialized
INFO - 2018-07-14 14:42:49 --> Controller Class Initialized
INFO - 2018-07-14 14:42:49 --> Database Driver Class Initialized
INFO - 2018-07-14 14:42:49 --> Model Class Initialized
INFO - 2018-07-14 14:42:49 --> Helper loaded: url_helper
INFO - 2018-07-14 14:42:49 --> Model Class Initialized
INFO - 2018-07-14 14:42:49 --> Final output sent to browser
DEBUG - 2018-07-14 14:42:49 --> Total execution time: 0.0375
ERROR - 2018-07-14 14:43:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 14:43:03 --> Config Class Initialized
INFO - 2018-07-14 14:43:03 --> Hooks Class Initialized
DEBUG - 2018-07-14 14:43:03 --> UTF-8 Support Enabled
INFO - 2018-07-14 14:43:03 --> Utf8 Class Initialized
INFO - 2018-07-14 14:43:03 --> URI Class Initialized
INFO - 2018-07-14 14:43:03 --> Router Class Initialized
INFO - 2018-07-14 14:43:03 --> Output Class Initialized
INFO - 2018-07-14 14:43:03 --> Security Class Initialized
DEBUG - 2018-07-14 14:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 14:43:03 --> Input Class Initialized
INFO - 2018-07-14 14:43:03 --> Language Class Initialized
INFO - 2018-07-14 14:43:03 --> Loader Class Initialized
INFO - 2018-07-14 14:43:03 --> Controller Class Initialized
INFO - 2018-07-14 14:43:03 --> Database Driver Class Initialized
INFO - 2018-07-14 14:43:03 --> Model Class Initialized
INFO - 2018-07-14 14:43:03 --> Helper loaded: url_helper
INFO - 2018-07-14 14:43:03 --> Model Class Initialized
INFO - 2018-07-14 14:43:03 --> Final output sent to browser
DEBUG - 2018-07-14 14:43:03 --> Total execution time: 0.0404
ERROR - 2018-07-14 14:43:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 14:43:58 --> Config Class Initialized
INFO - 2018-07-14 14:43:58 --> Hooks Class Initialized
DEBUG - 2018-07-14 14:43:58 --> UTF-8 Support Enabled
INFO - 2018-07-14 14:43:58 --> Utf8 Class Initialized
INFO - 2018-07-14 14:43:58 --> URI Class Initialized
INFO - 2018-07-14 14:43:58 --> Router Class Initialized
INFO - 2018-07-14 14:43:58 --> Output Class Initialized
INFO - 2018-07-14 14:43:58 --> Security Class Initialized
DEBUG - 2018-07-14 14:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 14:43:58 --> Input Class Initialized
INFO - 2018-07-14 14:43:58 --> Language Class Initialized
INFO - 2018-07-14 14:43:58 --> Loader Class Initialized
INFO - 2018-07-14 14:43:58 --> Controller Class Initialized
INFO - 2018-07-14 14:43:58 --> Database Driver Class Initialized
INFO - 2018-07-14 14:43:58 --> Model Class Initialized
INFO - 2018-07-14 14:43:58 --> Helper loaded: url_helper
INFO - 2018-07-14 14:43:58 --> Model Class Initialized
INFO - 2018-07-14 14:43:58 --> Final output sent to browser
DEBUG - 2018-07-14 14:43:58 --> Total execution time: 0.0449
ERROR - 2018-07-14 14:44:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 14:44:04 --> Config Class Initialized
INFO - 2018-07-14 14:44:04 --> Hooks Class Initialized
DEBUG - 2018-07-14 14:44:04 --> UTF-8 Support Enabled
INFO - 2018-07-14 14:44:04 --> Utf8 Class Initialized
INFO - 2018-07-14 14:44:04 --> URI Class Initialized
INFO - 2018-07-14 14:44:04 --> Router Class Initialized
INFO - 2018-07-14 14:44:04 --> Output Class Initialized
INFO - 2018-07-14 14:44:04 --> Security Class Initialized
DEBUG - 2018-07-14 14:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 14:44:04 --> Input Class Initialized
INFO - 2018-07-14 14:44:04 --> Language Class Initialized
INFO - 2018-07-14 14:44:04 --> Loader Class Initialized
INFO - 2018-07-14 14:44:04 --> Controller Class Initialized
INFO - 2018-07-14 14:44:04 --> Database Driver Class Initialized
INFO - 2018-07-14 14:44:04 --> Model Class Initialized
INFO - 2018-07-14 14:44:04 --> Helper loaded: url_helper
INFO - 2018-07-14 14:44:04 --> Model Class Initialized
INFO - 2018-07-14 14:44:04 --> Final output sent to browser
DEBUG - 2018-07-14 14:44:04 --> Total execution time: 0.0405
ERROR - 2018-07-14 14:44:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 14:44:29 --> Config Class Initialized
INFO - 2018-07-14 14:44:29 --> Hooks Class Initialized
DEBUG - 2018-07-14 14:44:29 --> UTF-8 Support Enabled
INFO - 2018-07-14 14:44:29 --> Utf8 Class Initialized
INFO - 2018-07-14 14:44:29 --> URI Class Initialized
INFO - 2018-07-14 14:44:29 --> Router Class Initialized
INFO - 2018-07-14 14:44:29 --> Output Class Initialized
INFO - 2018-07-14 14:44:29 --> Security Class Initialized
DEBUG - 2018-07-14 14:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 14:44:29 --> Input Class Initialized
INFO - 2018-07-14 14:44:29 --> Language Class Initialized
INFO - 2018-07-14 14:44:29 --> Loader Class Initialized
INFO - 2018-07-14 14:44:29 --> Controller Class Initialized
INFO - 2018-07-14 14:44:29 --> Database Driver Class Initialized
INFO - 2018-07-14 14:44:29 --> Model Class Initialized
INFO - 2018-07-14 14:44:29 --> Helper loaded: url_helper
INFO - 2018-07-14 14:44:29 --> Model Class Initialized
INFO - 2018-07-14 14:44:29 --> Final output sent to browser
DEBUG - 2018-07-14 14:44:29 --> Total execution time: 0.0448
ERROR - 2018-07-14 14:45:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 14:45:41 --> Config Class Initialized
INFO - 2018-07-14 14:45:41 --> Hooks Class Initialized
DEBUG - 2018-07-14 14:45:41 --> UTF-8 Support Enabled
INFO - 2018-07-14 14:45:41 --> Utf8 Class Initialized
INFO - 2018-07-14 14:45:41 --> URI Class Initialized
INFO - 2018-07-14 14:45:41 --> Router Class Initialized
INFO - 2018-07-14 14:45:41 --> Output Class Initialized
INFO - 2018-07-14 14:45:41 --> Security Class Initialized
DEBUG - 2018-07-14 14:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 14:45:41 --> Input Class Initialized
INFO - 2018-07-14 14:45:41 --> Language Class Initialized
INFO - 2018-07-14 14:45:41 --> Loader Class Initialized
INFO - 2018-07-14 14:45:41 --> Controller Class Initialized
INFO - 2018-07-14 14:45:41 --> Database Driver Class Initialized
INFO - 2018-07-14 14:45:41 --> Model Class Initialized
INFO - 2018-07-14 14:45:41 --> Helper loaded: url_helper
INFO - 2018-07-14 14:45:41 --> Model Class Initialized
INFO - 2018-07-14 14:45:41 --> Final output sent to browser
DEBUG - 2018-07-14 14:45:41 --> Total execution time: 0.0381
ERROR - 2018-07-14 14:46:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 14:46:13 --> Config Class Initialized
INFO - 2018-07-14 14:46:13 --> Hooks Class Initialized
DEBUG - 2018-07-14 14:46:13 --> UTF-8 Support Enabled
INFO - 2018-07-14 14:46:13 --> Utf8 Class Initialized
INFO - 2018-07-14 14:46:13 --> URI Class Initialized
INFO - 2018-07-14 14:46:13 --> Router Class Initialized
INFO - 2018-07-14 14:46:13 --> Output Class Initialized
INFO - 2018-07-14 14:46:13 --> Security Class Initialized
DEBUG - 2018-07-14 14:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 14:46:13 --> Input Class Initialized
INFO - 2018-07-14 14:46:13 --> Language Class Initialized
INFO - 2018-07-14 14:46:13 --> Loader Class Initialized
INFO - 2018-07-14 14:46:13 --> Controller Class Initialized
INFO - 2018-07-14 14:46:13 --> Database Driver Class Initialized
INFO - 2018-07-14 14:46:13 --> Model Class Initialized
INFO - 2018-07-14 14:46:13 --> Helper loaded: url_helper
INFO - 2018-07-14 14:46:13 --> Model Class Initialized
INFO - 2018-07-14 14:46:13 --> Final output sent to browser
DEBUG - 2018-07-14 14:46:13 --> Total execution time: 0.0401
ERROR - 2018-07-14 14:47:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 14:47:40 --> Config Class Initialized
INFO - 2018-07-14 14:47:40 --> Hooks Class Initialized
DEBUG - 2018-07-14 14:47:40 --> UTF-8 Support Enabled
INFO - 2018-07-14 14:47:40 --> Utf8 Class Initialized
INFO - 2018-07-14 14:47:40 --> URI Class Initialized
INFO - 2018-07-14 14:47:40 --> Router Class Initialized
INFO - 2018-07-14 14:47:40 --> Output Class Initialized
INFO - 2018-07-14 14:47:40 --> Security Class Initialized
DEBUG - 2018-07-14 14:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 14:47:40 --> Input Class Initialized
INFO - 2018-07-14 14:47:40 --> Language Class Initialized
INFO - 2018-07-14 14:47:40 --> Loader Class Initialized
INFO - 2018-07-14 14:47:40 --> Controller Class Initialized
INFO - 2018-07-14 14:47:40 --> Database Driver Class Initialized
INFO - 2018-07-14 14:47:40 --> Model Class Initialized
INFO - 2018-07-14 14:47:40 --> Helper loaded: url_helper
DEBUG - 2018-07-14 14:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 14:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 14:47:40 --> Model Class Initialized
ERROR - 2018-07-14 14:47:40 --> Severity: Notice --> Undefined index: Davidhood C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-07-14 14:47:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 14:47:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 14:47:40 --> Final output sent to browser
DEBUG - 2018-07-14 14:47:40 --> Total execution time: 0.0978
ERROR - 2018-07-14 14:47:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 14:47:41 --> Config Class Initialized
INFO - 2018-07-14 14:47:41 --> Hooks Class Initialized
DEBUG - 2018-07-14 14:47:41 --> UTF-8 Support Enabled
INFO - 2018-07-14 14:47:41 --> Utf8 Class Initialized
INFO - 2018-07-14 14:47:41 --> URI Class Initialized
DEBUG - 2018-07-14 14:47:41 --> No URI present. Default controller set.
INFO - 2018-07-14 14:47:41 --> Router Class Initialized
INFO - 2018-07-14 14:47:41 --> Output Class Initialized
INFO - 2018-07-14 14:47:41 --> Security Class Initialized
DEBUG - 2018-07-14 14:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 14:47:41 --> Input Class Initialized
INFO - 2018-07-14 14:47:41 --> Language Class Initialized
INFO - 2018-07-14 14:47:41 --> Loader Class Initialized
INFO - 2018-07-14 14:47:41 --> Controller Class Initialized
INFO - 2018-07-14 14:47:41 --> Database Driver Class Initialized
INFO - 2018-07-14 14:47:41 --> Model Class Initialized
INFO - 2018-07-14 14:47:41 --> Helper loaded: url_helper
DEBUG - 2018-07-14 14:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 14:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 14:47:41 --> Model Class Initialized
INFO - 2018-07-14 14:47:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-14 14:47:41 --> Final output sent to browser
DEBUG - 2018-07-14 14:47:41 --> Total execution time: 0.0622
ERROR - 2018-07-14 14:47:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 14:47:42 --> Config Class Initialized
INFO - 2018-07-14 14:47:42 --> Hooks Class Initialized
DEBUG - 2018-07-14 14:47:42 --> UTF-8 Support Enabled
INFO - 2018-07-14 14:47:42 --> Utf8 Class Initialized
INFO - 2018-07-14 14:47:42 --> URI Class Initialized
INFO - 2018-07-14 14:47:42 --> Router Class Initialized
INFO - 2018-07-14 14:47:42 --> Output Class Initialized
INFO - 2018-07-14 14:47:42 --> Security Class Initialized
DEBUG - 2018-07-14 14:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 14:47:42 --> Input Class Initialized
INFO - 2018-07-14 14:47:42 --> Language Class Initialized
INFO - 2018-07-14 14:47:42 --> Loader Class Initialized
INFO - 2018-07-14 14:47:42 --> Controller Class Initialized
INFO - 2018-07-14 14:47:42 --> Database Driver Class Initialized
INFO - 2018-07-14 14:47:42 --> Model Class Initialized
INFO - 2018-07-14 14:47:42 --> Helper loaded: url_helper
DEBUG - 2018-07-14 14:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 14:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 14:47:42 --> Model Class Initialized
ERROR - 2018-07-14 14:47:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 14:47:42 --> Config Class Initialized
INFO - 2018-07-14 14:47:42 --> Hooks Class Initialized
DEBUG - 2018-07-14 14:47:42 --> UTF-8 Support Enabled
INFO - 2018-07-14 14:47:42 --> Utf8 Class Initialized
INFO - 2018-07-14 14:47:42 --> URI Class Initialized
INFO - 2018-07-14 14:47:42 --> Router Class Initialized
INFO - 2018-07-14 14:47:42 --> Output Class Initialized
INFO - 2018-07-14 14:47:42 --> Security Class Initialized
DEBUG - 2018-07-14 14:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 14:47:42 --> Input Class Initialized
INFO - 2018-07-14 14:47:42 --> Language Class Initialized
INFO - 2018-07-14 14:47:42 --> Loader Class Initialized
INFO - 2018-07-14 14:47:42 --> Controller Class Initialized
INFO - 2018-07-14 14:47:42 --> Database Driver Class Initialized
INFO - 2018-07-14 14:47:42 --> Model Class Initialized
INFO - 2018-07-14 14:47:42 --> Helper loaded: url_helper
DEBUG - 2018-07-14 14:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 14:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 14:47:42 --> Model Class Initialized
INFO - 2018-07-14 14:47:42 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 14:47:42 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 14:47:42 --> Final output sent to browser
DEBUG - 2018-07-14 14:47:42 --> Total execution time: 0.0468
ERROR - 2018-07-14 14:47:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 14:47:47 --> Config Class Initialized
INFO - 2018-07-14 14:47:47 --> Hooks Class Initialized
DEBUG - 2018-07-14 14:47:47 --> UTF-8 Support Enabled
INFO - 2018-07-14 14:47:47 --> Utf8 Class Initialized
INFO - 2018-07-14 14:47:47 --> URI Class Initialized
INFO - 2018-07-14 14:47:47 --> Router Class Initialized
INFO - 2018-07-14 14:47:47 --> Output Class Initialized
INFO - 2018-07-14 14:47:47 --> Security Class Initialized
DEBUG - 2018-07-14 14:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 14:47:47 --> Input Class Initialized
INFO - 2018-07-14 14:47:47 --> Language Class Initialized
INFO - 2018-07-14 14:47:47 --> Loader Class Initialized
INFO - 2018-07-14 14:47:47 --> Controller Class Initialized
INFO - 2018-07-14 14:47:47 --> Database Driver Class Initialized
INFO - 2018-07-14 14:47:47 --> Model Class Initialized
INFO - 2018-07-14 14:47:47 --> Helper loaded: url_helper
DEBUG - 2018-07-14 14:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 14:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 14:47:47 --> Model Class Initialized
INFO - 2018-07-14 14:47:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 14:47:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 14:47:47 --> Final output sent to browser
DEBUG - 2018-07-14 14:47:47 --> Total execution time: 0.0579
ERROR - 2018-07-14 14:47:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 14:47:57 --> Config Class Initialized
INFO - 2018-07-14 14:47:57 --> Hooks Class Initialized
DEBUG - 2018-07-14 14:47:57 --> UTF-8 Support Enabled
INFO - 2018-07-14 14:47:57 --> Utf8 Class Initialized
INFO - 2018-07-14 14:47:57 --> URI Class Initialized
DEBUG - 2018-07-14 14:47:57 --> No URI present. Default controller set.
INFO - 2018-07-14 14:47:57 --> Router Class Initialized
INFO - 2018-07-14 14:47:57 --> Output Class Initialized
INFO - 2018-07-14 14:47:57 --> Security Class Initialized
DEBUG - 2018-07-14 14:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 14:47:57 --> Input Class Initialized
INFO - 2018-07-14 14:47:57 --> Language Class Initialized
INFO - 2018-07-14 14:47:57 --> Loader Class Initialized
INFO - 2018-07-14 14:47:57 --> Controller Class Initialized
INFO - 2018-07-14 14:47:57 --> Database Driver Class Initialized
INFO - 2018-07-14 14:47:57 --> Model Class Initialized
INFO - 2018-07-14 14:47:57 --> Helper loaded: url_helper
DEBUG - 2018-07-14 14:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 14:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 14:47:57 --> Model Class Initialized
INFO - 2018-07-14 14:47:57 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-14 14:47:57 --> Final output sent to browser
DEBUG - 2018-07-14 14:47:57 --> Total execution time: 0.0530
ERROR - 2018-07-14 14:48:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 14:48:42 --> Config Class Initialized
INFO - 2018-07-14 14:48:42 --> Hooks Class Initialized
DEBUG - 2018-07-14 14:48:42 --> UTF-8 Support Enabled
INFO - 2018-07-14 14:48:42 --> Utf8 Class Initialized
INFO - 2018-07-14 14:48:42 --> URI Class Initialized
INFO - 2018-07-14 14:48:42 --> Router Class Initialized
INFO - 2018-07-14 14:48:42 --> Output Class Initialized
INFO - 2018-07-14 14:48:42 --> Security Class Initialized
DEBUG - 2018-07-14 14:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 14:48:42 --> Input Class Initialized
INFO - 2018-07-14 14:48:42 --> Language Class Initialized
INFO - 2018-07-14 14:48:42 --> Loader Class Initialized
INFO - 2018-07-14 14:48:42 --> Controller Class Initialized
INFO - 2018-07-14 14:48:42 --> Database Driver Class Initialized
INFO - 2018-07-14 14:48:42 --> Model Class Initialized
INFO - 2018-07-14 14:48:42 --> Helper loaded: url_helper
INFO - 2018-07-14 14:48:42 --> Model Class Initialized
INFO - 2018-07-14 14:48:42 --> Final output sent to browser
DEBUG - 2018-07-14 14:48:42 --> Total execution time: 0.0468
ERROR - 2018-07-14 16:57:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 16:57:19 --> Config Class Initialized
INFO - 2018-07-14 16:57:19 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:57:19 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:57:19 --> Utf8 Class Initialized
INFO - 2018-07-14 16:57:19 --> URI Class Initialized
INFO - 2018-07-14 16:57:19 --> Router Class Initialized
INFO - 2018-07-14 16:57:19 --> Output Class Initialized
INFO - 2018-07-14 16:57:19 --> Security Class Initialized
DEBUG - 2018-07-14 16:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:57:19 --> Input Class Initialized
INFO - 2018-07-14 16:57:19 --> Language Class Initialized
INFO - 2018-07-14 16:57:19 --> Loader Class Initialized
INFO - 2018-07-14 16:57:19 --> Controller Class Initialized
INFO - 2018-07-14 16:57:19 --> Database Driver Class Initialized
INFO - 2018-07-14 16:57:19 --> Model Class Initialized
INFO - 2018-07-14 16:57:19 --> Helper loaded: url_helper
DEBUG - 2018-07-14 16:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:57:19 --> Model Class Initialized
ERROR - 2018-07-14 16:57:19 --> Severity: Notice --> Undefined index: Davidhood C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-07-14 16:57:19 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 16:57:19 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 16:57:19 --> Final output sent to browser
DEBUG - 2018-07-14 16:57:19 --> Total execution time: 0.0584
ERROR - 2018-07-14 16:57:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 16:57:19 --> Config Class Initialized
INFO - 2018-07-14 16:57:19 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:57:19 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:57:19 --> Utf8 Class Initialized
INFO - 2018-07-14 16:57:19 --> URI Class Initialized
DEBUG - 2018-07-14 16:57:19 --> No URI present. Default controller set.
INFO - 2018-07-14 16:57:19 --> Router Class Initialized
INFO - 2018-07-14 16:57:19 --> Output Class Initialized
INFO - 2018-07-14 16:57:19 --> Security Class Initialized
DEBUG - 2018-07-14 16:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:57:19 --> Input Class Initialized
INFO - 2018-07-14 16:57:19 --> Language Class Initialized
INFO - 2018-07-14 16:57:19 --> Loader Class Initialized
INFO - 2018-07-14 16:57:19 --> Controller Class Initialized
INFO - 2018-07-14 16:57:19 --> Database Driver Class Initialized
INFO - 2018-07-14 16:57:19 --> Model Class Initialized
INFO - 2018-07-14 16:57:19 --> Helper loaded: url_helper
DEBUG - 2018-07-14 16:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:57:19 --> Model Class Initialized
INFO - 2018-07-14 16:57:19 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-14 16:57:19 --> Final output sent to browser
DEBUG - 2018-07-14 16:57:19 --> Total execution time: 0.0588
ERROR - 2018-07-14 16:57:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 16:57:21 --> Config Class Initialized
INFO - 2018-07-14 16:57:21 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:57:21 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:57:21 --> Utf8 Class Initialized
INFO - 2018-07-14 16:57:21 --> URI Class Initialized
INFO - 2018-07-14 16:57:21 --> Router Class Initialized
INFO - 2018-07-14 16:57:21 --> Output Class Initialized
INFO - 2018-07-14 16:57:21 --> Security Class Initialized
DEBUG - 2018-07-14 16:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:57:21 --> Input Class Initialized
INFO - 2018-07-14 16:57:21 --> Language Class Initialized
INFO - 2018-07-14 16:57:21 --> Loader Class Initialized
INFO - 2018-07-14 16:57:21 --> Controller Class Initialized
INFO - 2018-07-14 16:57:21 --> Database Driver Class Initialized
INFO - 2018-07-14 16:57:21 --> Model Class Initialized
INFO - 2018-07-14 16:57:21 --> Helper loaded: url_helper
DEBUG - 2018-07-14 16:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:57:21 --> Model Class Initialized
ERROR - 2018-07-14 16:57:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 16:57:21 --> Config Class Initialized
INFO - 2018-07-14 16:57:21 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:57:21 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:57:21 --> Utf8 Class Initialized
INFO - 2018-07-14 16:57:21 --> URI Class Initialized
INFO - 2018-07-14 16:57:21 --> Router Class Initialized
INFO - 2018-07-14 16:57:21 --> Output Class Initialized
INFO - 2018-07-14 16:57:21 --> Security Class Initialized
DEBUG - 2018-07-14 16:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:57:21 --> Input Class Initialized
INFO - 2018-07-14 16:57:21 --> Language Class Initialized
INFO - 2018-07-14 16:57:21 --> Loader Class Initialized
INFO - 2018-07-14 16:57:21 --> Controller Class Initialized
INFO - 2018-07-14 16:57:21 --> Database Driver Class Initialized
INFO - 2018-07-14 16:57:21 --> Model Class Initialized
INFO - 2018-07-14 16:57:21 --> Helper loaded: url_helper
DEBUG - 2018-07-14 16:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:57:21 --> Model Class Initialized
INFO - 2018-07-14 16:57:21 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 16:57:21 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 16:57:21 --> Final output sent to browser
DEBUG - 2018-07-14 16:57:21 --> Total execution time: 0.0463
ERROR - 2018-07-14 16:57:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 16:57:23 --> Config Class Initialized
INFO - 2018-07-14 16:57:23 --> Hooks Class Initialized
DEBUG - 2018-07-14 16:57:23 --> UTF-8 Support Enabled
INFO - 2018-07-14 16:57:23 --> Utf8 Class Initialized
INFO - 2018-07-14 16:57:23 --> URI Class Initialized
INFO - 2018-07-14 16:57:23 --> Router Class Initialized
INFO - 2018-07-14 16:57:23 --> Output Class Initialized
INFO - 2018-07-14 16:57:23 --> Security Class Initialized
DEBUG - 2018-07-14 16:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 16:57:23 --> Input Class Initialized
INFO - 2018-07-14 16:57:23 --> Language Class Initialized
INFO - 2018-07-14 16:57:23 --> Loader Class Initialized
INFO - 2018-07-14 16:57:23 --> Controller Class Initialized
INFO - 2018-07-14 16:57:23 --> Database Driver Class Initialized
INFO - 2018-07-14 16:57:23 --> Model Class Initialized
INFO - 2018-07-14 16:57:23 --> Helper loaded: url_helper
DEBUG - 2018-07-14 16:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 16:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 16:57:23 --> Model Class Initialized
INFO - 2018-07-14 16:57:23 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 16:57:23 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 16:57:23 --> Final output sent to browser
DEBUG - 2018-07-14 16:57:23 --> Total execution time: 0.0554
ERROR - 2018-07-14 17:13:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:13:06 --> Config Class Initialized
INFO - 2018-07-14 17:13:06 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:13:06 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:13:06 --> Utf8 Class Initialized
INFO - 2018-07-14 17:13:06 --> URI Class Initialized
INFO - 2018-07-14 17:13:06 --> Router Class Initialized
INFO - 2018-07-14 17:13:06 --> Output Class Initialized
INFO - 2018-07-14 17:13:06 --> Security Class Initialized
DEBUG - 2018-07-14 17:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:13:06 --> Input Class Initialized
INFO - 2018-07-14 17:13:06 --> Language Class Initialized
INFO - 2018-07-14 17:13:06 --> Loader Class Initialized
INFO - 2018-07-14 17:13:06 --> Controller Class Initialized
INFO - 2018-07-14 17:13:06 --> Database Driver Class Initialized
INFO - 2018-07-14 17:13:06 --> Model Class Initialized
INFO - 2018-07-14 17:13:06 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:13:06 --> Model Class Initialized
INFO - 2018-07-14 17:13:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:13:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 17:13:06 --> Final output sent to browser
DEBUG - 2018-07-14 17:13:06 --> Total execution time: 0.4091
ERROR - 2018-07-14 17:14:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:14:06 --> Config Class Initialized
INFO - 2018-07-14 17:14:06 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:14:06 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:14:06 --> Utf8 Class Initialized
INFO - 2018-07-14 17:14:06 --> URI Class Initialized
INFO - 2018-07-14 17:14:06 --> Router Class Initialized
INFO - 2018-07-14 17:14:06 --> Output Class Initialized
INFO - 2018-07-14 17:14:06 --> Security Class Initialized
DEBUG - 2018-07-14 17:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:14:06 --> Input Class Initialized
INFO - 2018-07-14 17:14:06 --> Language Class Initialized
INFO - 2018-07-14 17:14:06 --> Loader Class Initialized
INFO - 2018-07-14 17:14:06 --> Controller Class Initialized
INFO - 2018-07-14 17:14:06 --> Database Driver Class Initialized
INFO - 2018-07-14 17:14:06 --> Model Class Initialized
INFO - 2018-07-14 17:14:06 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:14:06 --> Model Class Initialized
INFO - 2018-07-14 17:14:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:14:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 17:14:06 --> Final output sent to browser
DEBUG - 2018-07-14 17:14:06 --> Total execution time: 0.0501
ERROR - 2018-07-14 17:15:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:15:03 --> Config Class Initialized
INFO - 2018-07-14 17:15:03 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:15:03 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:15:03 --> Utf8 Class Initialized
INFO - 2018-07-14 17:15:03 --> URI Class Initialized
INFO - 2018-07-14 17:15:03 --> Router Class Initialized
INFO - 2018-07-14 17:15:03 --> Output Class Initialized
INFO - 2018-07-14 17:15:03 --> Security Class Initialized
DEBUG - 2018-07-14 17:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:15:03 --> Input Class Initialized
INFO - 2018-07-14 17:15:03 --> Language Class Initialized
INFO - 2018-07-14 17:15:03 --> Loader Class Initialized
INFO - 2018-07-14 17:15:03 --> Controller Class Initialized
INFO - 2018-07-14 17:15:03 --> Database Driver Class Initialized
INFO - 2018-07-14 17:15:03 --> Model Class Initialized
INFO - 2018-07-14 17:15:03 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:15:03 --> Model Class Initialized
INFO - 2018-07-14 17:15:03 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:15:03 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 17:15:03 --> Final output sent to browser
DEBUG - 2018-07-14 17:15:03 --> Total execution time: 0.0509
ERROR - 2018-07-14 17:17:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:17:36 --> Config Class Initialized
INFO - 2018-07-14 17:17:36 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:17:36 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:17:36 --> Utf8 Class Initialized
INFO - 2018-07-14 17:17:36 --> URI Class Initialized
INFO - 2018-07-14 17:17:36 --> Router Class Initialized
INFO - 2018-07-14 17:17:36 --> Output Class Initialized
INFO - 2018-07-14 17:17:36 --> Security Class Initialized
DEBUG - 2018-07-14 17:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:17:36 --> Input Class Initialized
INFO - 2018-07-14 17:17:36 --> Language Class Initialized
INFO - 2018-07-14 17:17:36 --> Loader Class Initialized
INFO - 2018-07-14 17:17:36 --> Controller Class Initialized
INFO - 2018-07-14 17:17:36 --> Database Driver Class Initialized
INFO - 2018-07-14 17:17:36 --> Model Class Initialized
INFO - 2018-07-14 17:17:36 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:17:36 --> Model Class Initialized
INFO - 2018-07-14 17:17:36 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:17:36 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 17:17:36 --> Final output sent to browser
DEBUG - 2018-07-14 17:17:36 --> Total execution time: 0.0643
ERROR - 2018-07-14 17:18:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:18:10 --> Config Class Initialized
INFO - 2018-07-14 17:18:10 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:18:10 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:18:10 --> Utf8 Class Initialized
INFO - 2018-07-14 17:18:10 --> URI Class Initialized
INFO - 2018-07-14 17:18:10 --> Router Class Initialized
INFO - 2018-07-14 17:18:10 --> Output Class Initialized
INFO - 2018-07-14 17:18:10 --> Security Class Initialized
DEBUG - 2018-07-14 17:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:18:10 --> Input Class Initialized
INFO - 2018-07-14 17:18:10 --> Language Class Initialized
INFO - 2018-07-14 17:18:10 --> Loader Class Initialized
INFO - 2018-07-14 17:18:10 --> Controller Class Initialized
INFO - 2018-07-14 17:18:10 --> Database Driver Class Initialized
INFO - 2018-07-14 17:18:10 --> Model Class Initialized
INFO - 2018-07-14 17:18:10 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:18:10 --> Model Class Initialized
INFO - 2018-07-14 17:18:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:18:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 17:18:10 --> Final output sent to browser
DEBUG - 2018-07-14 17:18:10 --> Total execution time: 0.0753
ERROR - 2018-07-14 17:18:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:18:38 --> Config Class Initialized
INFO - 2018-07-14 17:18:38 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:18:38 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:18:38 --> Utf8 Class Initialized
INFO - 2018-07-14 17:18:38 --> URI Class Initialized
INFO - 2018-07-14 17:18:38 --> Router Class Initialized
INFO - 2018-07-14 17:18:38 --> Output Class Initialized
INFO - 2018-07-14 17:18:39 --> Security Class Initialized
DEBUG - 2018-07-14 17:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:18:39 --> Input Class Initialized
INFO - 2018-07-14 17:18:39 --> Language Class Initialized
INFO - 2018-07-14 17:18:39 --> Loader Class Initialized
INFO - 2018-07-14 17:18:39 --> Controller Class Initialized
INFO - 2018-07-14 17:18:39 --> Database Driver Class Initialized
INFO - 2018-07-14 17:18:39 --> Model Class Initialized
INFO - 2018-07-14 17:18:39 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:18:39 --> Model Class Initialized
INFO - 2018-07-14 17:18:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:18:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 17:18:39 --> Final output sent to browser
DEBUG - 2018-07-14 17:18:39 --> Total execution time: 0.0516
ERROR - 2018-07-14 17:18:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:18:51 --> Config Class Initialized
INFO - 2018-07-14 17:18:51 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:18:51 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:18:51 --> Utf8 Class Initialized
INFO - 2018-07-14 17:18:51 --> URI Class Initialized
INFO - 2018-07-14 17:18:51 --> Router Class Initialized
INFO - 2018-07-14 17:18:51 --> Output Class Initialized
INFO - 2018-07-14 17:18:51 --> Security Class Initialized
DEBUG - 2018-07-14 17:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:18:51 --> Input Class Initialized
INFO - 2018-07-14 17:18:51 --> Language Class Initialized
INFO - 2018-07-14 17:18:51 --> Loader Class Initialized
INFO - 2018-07-14 17:18:51 --> Controller Class Initialized
INFO - 2018-07-14 17:18:51 --> Database Driver Class Initialized
INFO - 2018-07-14 17:18:51 --> Model Class Initialized
INFO - 2018-07-14 17:18:51 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:18:51 --> Model Class Initialized
INFO - 2018-07-14 17:18:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:18:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 17:18:52 --> Final output sent to browser
DEBUG - 2018-07-14 17:18:52 --> Total execution time: 0.0559
ERROR - 2018-07-14 17:20:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:20:08 --> Config Class Initialized
INFO - 2018-07-14 17:20:08 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:20:08 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:20:08 --> Utf8 Class Initialized
INFO - 2018-07-14 17:20:08 --> URI Class Initialized
INFO - 2018-07-14 17:20:08 --> Router Class Initialized
INFO - 2018-07-14 17:20:08 --> Output Class Initialized
INFO - 2018-07-14 17:20:08 --> Security Class Initialized
DEBUG - 2018-07-14 17:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:20:08 --> Input Class Initialized
INFO - 2018-07-14 17:20:08 --> Language Class Initialized
INFO - 2018-07-14 17:20:08 --> Loader Class Initialized
INFO - 2018-07-14 17:20:08 --> Controller Class Initialized
INFO - 2018-07-14 17:20:08 --> Database Driver Class Initialized
INFO - 2018-07-14 17:20:08 --> Model Class Initialized
INFO - 2018-07-14 17:20:08 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:20:08 --> Model Class Initialized
INFO - 2018-07-14 17:20:08 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:20:08 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 17:20:08 --> Final output sent to browser
DEBUG - 2018-07-14 17:20:08 --> Total execution time: 0.0809
ERROR - 2018-07-14 17:22:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:22:18 --> Config Class Initialized
INFO - 2018-07-14 17:22:18 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:22:18 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:22:18 --> Utf8 Class Initialized
INFO - 2018-07-14 17:22:18 --> URI Class Initialized
INFO - 2018-07-14 17:22:18 --> Router Class Initialized
INFO - 2018-07-14 17:22:18 --> Output Class Initialized
INFO - 2018-07-14 17:22:18 --> Security Class Initialized
DEBUG - 2018-07-14 17:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:22:18 --> Input Class Initialized
INFO - 2018-07-14 17:22:18 --> Language Class Initialized
INFO - 2018-07-14 17:22:18 --> Loader Class Initialized
INFO - 2018-07-14 17:22:18 --> Controller Class Initialized
INFO - 2018-07-14 17:22:18 --> Database Driver Class Initialized
INFO - 2018-07-14 17:22:18 --> Model Class Initialized
INFO - 2018-07-14 17:22:18 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:22:18 --> Model Class Initialized
INFO - 2018-07-14 17:22:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:22:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 17:22:18 --> Final output sent to browser
DEBUG - 2018-07-14 17:22:18 --> Total execution time: 0.0520
ERROR - 2018-07-14 17:24:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:24:00 --> Config Class Initialized
INFO - 2018-07-14 17:24:00 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:24:00 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:24:00 --> Utf8 Class Initialized
INFO - 2018-07-14 17:24:00 --> URI Class Initialized
INFO - 2018-07-14 17:24:00 --> Router Class Initialized
INFO - 2018-07-14 17:24:00 --> Output Class Initialized
INFO - 2018-07-14 17:24:00 --> Security Class Initialized
DEBUG - 2018-07-14 17:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:24:00 --> Input Class Initialized
INFO - 2018-07-14 17:24:00 --> Language Class Initialized
INFO - 2018-07-14 17:24:00 --> Loader Class Initialized
INFO - 2018-07-14 17:24:00 --> Controller Class Initialized
INFO - 2018-07-14 17:24:00 --> Database Driver Class Initialized
INFO - 2018-07-14 17:24:00 --> Model Class Initialized
INFO - 2018-07-14 17:24:00 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:24:00 --> Model Class Initialized
INFO - 2018-07-14 17:24:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:24:00 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:24:00 --> Final output sent to browser
DEBUG - 2018-07-14 17:24:00 --> Total execution time: 0.0701
ERROR - 2018-07-14 17:24:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:24:53 --> Config Class Initialized
INFO - 2018-07-14 17:24:53 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:24:53 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:24:53 --> Utf8 Class Initialized
INFO - 2018-07-14 17:24:53 --> URI Class Initialized
INFO - 2018-07-14 17:24:53 --> Router Class Initialized
INFO - 2018-07-14 17:24:53 --> Output Class Initialized
INFO - 2018-07-14 17:24:53 --> Security Class Initialized
DEBUG - 2018-07-14 17:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:24:53 --> Input Class Initialized
INFO - 2018-07-14 17:24:53 --> Language Class Initialized
INFO - 2018-07-14 17:24:54 --> Loader Class Initialized
INFO - 2018-07-14 17:24:54 --> Controller Class Initialized
INFO - 2018-07-14 17:24:54 --> Database Driver Class Initialized
INFO - 2018-07-14 17:24:54 --> Model Class Initialized
INFO - 2018-07-14 17:24:54 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:24:54 --> Model Class Initialized
INFO - 2018-07-14 17:24:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:24:54 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:24:54 --> Final output sent to browser
DEBUG - 2018-07-14 17:24:54 --> Total execution time: 0.0479
ERROR - 2018-07-14 17:30:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:30:37 --> Config Class Initialized
INFO - 2018-07-14 17:30:37 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:30:38 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:30:38 --> Utf8 Class Initialized
INFO - 2018-07-14 17:30:38 --> URI Class Initialized
INFO - 2018-07-14 17:30:38 --> Router Class Initialized
INFO - 2018-07-14 17:30:38 --> Output Class Initialized
INFO - 2018-07-14 17:30:38 --> Security Class Initialized
DEBUG - 2018-07-14 17:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:30:38 --> Input Class Initialized
INFO - 2018-07-14 17:30:38 --> Language Class Initialized
INFO - 2018-07-14 17:30:38 --> Loader Class Initialized
INFO - 2018-07-14 17:30:38 --> Controller Class Initialized
INFO - 2018-07-14 17:30:38 --> Database Driver Class Initialized
INFO - 2018-07-14 17:30:38 --> Model Class Initialized
INFO - 2018-07-14 17:30:38 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:30:38 --> Model Class Initialized
INFO - 2018-07-14 17:30:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:30:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 17:30:38 --> Final output sent to browser
DEBUG - 2018-07-14 17:30:38 --> Total execution time: 0.0514
ERROR - 2018-07-14 17:30:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:30:51 --> Config Class Initialized
INFO - 2018-07-14 17:30:51 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:30:51 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:30:51 --> Utf8 Class Initialized
INFO - 2018-07-14 17:30:51 --> URI Class Initialized
INFO - 2018-07-14 17:30:51 --> Router Class Initialized
INFO - 2018-07-14 17:30:51 --> Output Class Initialized
INFO - 2018-07-14 17:30:51 --> Security Class Initialized
DEBUG - 2018-07-14 17:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:30:51 --> Input Class Initialized
INFO - 2018-07-14 17:30:51 --> Language Class Initialized
INFO - 2018-07-14 17:30:51 --> Loader Class Initialized
INFO - 2018-07-14 17:30:51 --> Controller Class Initialized
INFO - 2018-07-14 17:30:51 --> Database Driver Class Initialized
INFO - 2018-07-14 17:30:51 --> Model Class Initialized
INFO - 2018-07-14 17:30:51 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:30:51 --> Model Class Initialized
INFO - 2018-07-14 17:30:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:30:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:30:51 --> Final output sent to browser
DEBUG - 2018-07-14 17:30:51 --> Total execution time: 0.0730
ERROR - 2018-07-14 17:31:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:31:44 --> Config Class Initialized
INFO - 2018-07-14 17:31:44 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:31:44 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:31:44 --> Utf8 Class Initialized
INFO - 2018-07-14 17:31:44 --> URI Class Initialized
INFO - 2018-07-14 17:31:44 --> Router Class Initialized
INFO - 2018-07-14 17:31:44 --> Output Class Initialized
INFO - 2018-07-14 17:31:44 --> Security Class Initialized
DEBUG - 2018-07-14 17:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:31:44 --> Input Class Initialized
INFO - 2018-07-14 17:31:44 --> Language Class Initialized
INFO - 2018-07-14 17:31:44 --> Loader Class Initialized
INFO - 2018-07-14 17:31:44 --> Controller Class Initialized
INFO - 2018-07-14 17:31:44 --> Database Driver Class Initialized
INFO - 2018-07-14 17:31:44 --> Model Class Initialized
INFO - 2018-07-14 17:31:44 --> Helper loaded: form_helper
INFO - 2018-07-14 17:31:44 --> Helper loaded: url_helper
ERROR - 2018-07-14 17:31:44 --> Severity: Notice --> Undefined index: Davidhood C:\xampp\htdocs\davidhood\application\views\header.php 141
INFO - 2018-07-14 17:31:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
ERROR - 2018-07-14 17:31:44 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\user_profile.php 68
ERROR - 2018-07-14 17:31:44 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\user_profile.php 73
ERROR - 2018-07-14 17:31:44 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\user_profile.php 82
ERROR - 2018-07-14 17:31:44 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\user_profile.php 92
ERROR - 2018-07-14 17:31:44 --> Severity: Notice --> Undefined index: biper C:\xampp\htdocs\davidhood\application\views\user_profile.php 101
INFO - 2018-07-14 17:31:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user_profile.php
INFO - 2018-07-14 17:31:44 --> Final output sent to browser
DEBUG - 2018-07-14 17:31:44 --> Total execution time: 0.0859
ERROR - 2018-07-14 17:31:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:31:44 --> Config Class Initialized
INFO - 2018-07-14 17:31:44 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:31:44 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:31:44 --> Utf8 Class Initialized
INFO - 2018-07-14 17:31:44 --> URI Class Initialized
INFO - 2018-07-14 17:31:44 --> Router Class Initialized
INFO - 2018-07-14 17:31:44 --> Output Class Initialized
INFO - 2018-07-14 17:31:44 --> Security Class Initialized
DEBUG - 2018-07-14 17:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:31:44 --> Input Class Initialized
INFO - 2018-07-14 17:31:44 --> Language Class Initialized
ERROR - 2018-07-14 17:31:44 --> 404 Page Not Found: UploadImages/admin
ERROR - 2018-07-14 17:31:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:31:44 --> Config Class Initialized
INFO - 2018-07-14 17:31:44 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:31:44 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:31:44 --> Utf8 Class Initialized
INFO - 2018-07-14 17:31:44 --> URI Class Initialized
DEBUG - 2018-07-14 17:31:44 --> No URI present. Default controller set.
INFO - 2018-07-14 17:31:44 --> Router Class Initialized
INFO - 2018-07-14 17:31:44 --> Output Class Initialized
INFO - 2018-07-14 17:31:44 --> Security Class Initialized
DEBUG - 2018-07-14 17:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:31:44 --> Input Class Initialized
INFO - 2018-07-14 17:31:44 --> Language Class Initialized
INFO - 2018-07-14 17:31:44 --> Loader Class Initialized
INFO - 2018-07-14 17:31:44 --> Controller Class Initialized
INFO - 2018-07-14 17:31:44 --> Database Driver Class Initialized
INFO - 2018-07-14 17:31:44 --> Model Class Initialized
INFO - 2018-07-14 17:31:44 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:31:44 --> Model Class Initialized
INFO - 2018-07-14 17:31:44 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-07-14 17:31:44 --> Final output sent to browser
DEBUG - 2018-07-14 17:31:44 --> Total execution time: 0.0719
ERROR - 2018-07-14 17:31:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:31:47 --> Config Class Initialized
INFO - 2018-07-14 17:31:47 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:31:47 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:31:47 --> Utf8 Class Initialized
INFO - 2018-07-14 17:31:47 --> URI Class Initialized
INFO - 2018-07-14 17:31:47 --> Router Class Initialized
INFO - 2018-07-14 17:31:47 --> Output Class Initialized
INFO - 2018-07-14 17:31:47 --> Security Class Initialized
DEBUG - 2018-07-14 17:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:31:47 --> Input Class Initialized
INFO - 2018-07-14 17:31:47 --> Language Class Initialized
INFO - 2018-07-14 17:31:47 --> Loader Class Initialized
INFO - 2018-07-14 17:31:47 --> Controller Class Initialized
INFO - 2018-07-14 17:31:47 --> Database Driver Class Initialized
INFO - 2018-07-14 17:31:47 --> Model Class Initialized
INFO - 2018-07-14 17:31:47 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:31:47 --> Model Class Initialized
ERROR - 2018-07-14 17:31:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:31:47 --> Config Class Initialized
INFO - 2018-07-14 17:31:47 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:31:47 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:31:47 --> Utf8 Class Initialized
INFO - 2018-07-14 17:31:47 --> URI Class Initialized
INFO - 2018-07-14 17:31:47 --> Router Class Initialized
INFO - 2018-07-14 17:31:47 --> Output Class Initialized
INFO - 2018-07-14 17:31:47 --> Security Class Initialized
DEBUG - 2018-07-14 17:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:31:47 --> Input Class Initialized
INFO - 2018-07-14 17:31:47 --> Language Class Initialized
INFO - 2018-07-14 17:31:47 --> Loader Class Initialized
INFO - 2018-07-14 17:31:47 --> Controller Class Initialized
INFO - 2018-07-14 17:31:47 --> Database Driver Class Initialized
INFO - 2018-07-14 17:31:47 --> Model Class Initialized
INFO - 2018-07-14 17:31:47 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:31:47 --> Model Class Initialized
INFO - 2018-07-14 17:31:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:31:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:31:47 --> Final output sent to browser
DEBUG - 2018-07-14 17:31:47 --> Total execution time: 0.0519
ERROR - 2018-07-14 17:31:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:31:53 --> Config Class Initialized
INFO - 2018-07-14 17:31:53 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:31:53 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:31:53 --> Utf8 Class Initialized
INFO - 2018-07-14 17:31:53 --> URI Class Initialized
INFO - 2018-07-14 17:31:53 --> Router Class Initialized
INFO - 2018-07-14 17:31:53 --> Output Class Initialized
INFO - 2018-07-14 17:31:53 --> Security Class Initialized
DEBUG - 2018-07-14 17:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:31:53 --> Input Class Initialized
INFO - 2018-07-14 17:31:53 --> Language Class Initialized
INFO - 2018-07-14 17:31:53 --> Loader Class Initialized
INFO - 2018-07-14 17:31:53 --> Controller Class Initialized
INFO - 2018-07-14 17:31:53 --> Database Driver Class Initialized
INFO - 2018-07-14 17:31:53 --> Model Class Initialized
INFO - 2018-07-14 17:31:53 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:31:53 --> Model Class Initialized
INFO - 2018-07-14 17:31:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:31:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:31:53 --> Final output sent to browser
DEBUG - 2018-07-14 17:31:53 --> Total execution time: 0.0714
ERROR - 2018-07-14 17:31:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:31:55 --> Config Class Initialized
INFO - 2018-07-14 17:31:55 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:31:55 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:31:55 --> Utf8 Class Initialized
INFO - 2018-07-14 17:31:55 --> URI Class Initialized
INFO - 2018-07-14 17:31:55 --> Router Class Initialized
INFO - 2018-07-14 17:31:55 --> Output Class Initialized
INFO - 2018-07-14 17:31:55 --> Security Class Initialized
DEBUG - 2018-07-14 17:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:31:55 --> Input Class Initialized
INFO - 2018-07-14 17:31:55 --> Language Class Initialized
INFO - 2018-07-14 17:31:55 --> Loader Class Initialized
INFO - 2018-07-14 17:31:55 --> Controller Class Initialized
INFO - 2018-07-14 17:31:55 --> Database Driver Class Initialized
INFO - 2018-07-14 17:31:55 --> Model Class Initialized
INFO - 2018-07-14 17:31:55 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:31:55 --> Model Class Initialized
INFO - 2018-07-14 17:31:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:31:55 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:31:55 --> Final output sent to browser
DEBUG - 2018-07-14 17:31:55 --> Total execution time: 0.0508
ERROR - 2018-07-14 17:39:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:39:51 --> Config Class Initialized
INFO - 2018-07-14 17:39:51 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:39:51 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:39:51 --> Utf8 Class Initialized
INFO - 2018-07-14 17:39:51 --> URI Class Initialized
INFO - 2018-07-14 17:39:51 --> Router Class Initialized
INFO - 2018-07-14 17:39:51 --> Output Class Initialized
INFO - 2018-07-14 17:39:51 --> Security Class Initialized
DEBUG - 2018-07-14 17:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:39:51 --> Input Class Initialized
INFO - 2018-07-14 17:39:51 --> Language Class Initialized
INFO - 2018-07-14 17:39:51 --> Loader Class Initialized
INFO - 2018-07-14 17:39:51 --> Controller Class Initialized
INFO - 2018-07-14 17:39:51 --> Database Driver Class Initialized
INFO - 2018-07-14 17:39:51 --> Model Class Initialized
INFO - 2018-07-14 17:39:51 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:39:51 --> Model Class Initialized
INFO - 2018-07-14 17:39:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:39:51 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:39:51 --> Final output sent to browser
DEBUG - 2018-07-14 17:39:51 --> Total execution time: 0.0566
ERROR - 2018-07-14 17:40:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:40:10 --> Config Class Initialized
INFO - 2018-07-14 17:40:10 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:40:10 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:40:10 --> Utf8 Class Initialized
INFO - 2018-07-14 17:40:10 --> URI Class Initialized
INFO - 2018-07-14 17:40:10 --> Router Class Initialized
INFO - 2018-07-14 17:40:10 --> Output Class Initialized
INFO - 2018-07-14 17:40:10 --> Security Class Initialized
DEBUG - 2018-07-14 17:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:40:10 --> Input Class Initialized
INFO - 2018-07-14 17:40:10 --> Language Class Initialized
INFO - 2018-07-14 17:40:10 --> Loader Class Initialized
INFO - 2018-07-14 17:40:10 --> Controller Class Initialized
INFO - 2018-07-14 17:40:10 --> Database Driver Class Initialized
INFO - 2018-07-14 17:40:10 --> Model Class Initialized
INFO - 2018-07-14 17:40:10 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:40:10 --> Model Class Initialized
INFO - 2018-07-14 17:40:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:40:10 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:40:10 --> Final output sent to browser
DEBUG - 2018-07-14 17:40:10 --> Total execution time: 0.0493
ERROR - 2018-07-14 17:40:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:40:47 --> Config Class Initialized
INFO - 2018-07-14 17:40:47 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:40:47 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:40:47 --> Utf8 Class Initialized
INFO - 2018-07-14 17:40:47 --> URI Class Initialized
INFO - 2018-07-14 17:40:47 --> Router Class Initialized
INFO - 2018-07-14 17:40:47 --> Output Class Initialized
INFO - 2018-07-14 17:40:47 --> Security Class Initialized
DEBUG - 2018-07-14 17:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:40:47 --> Input Class Initialized
INFO - 2018-07-14 17:40:47 --> Language Class Initialized
INFO - 2018-07-14 17:40:47 --> Loader Class Initialized
INFO - 2018-07-14 17:40:47 --> Controller Class Initialized
INFO - 2018-07-14 17:40:47 --> Database Driver Class Initialized
INFO - 2018-07-14 17:40:47 --> Model Class Initialized
INFO - 2018-07-14 17:40:47 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:40:47 --> Model Class Initialized
INFO - 2018-07-14 17:40:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:40:47 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:40:47 --> Final output sent to browser
DEBUG - 2018-07-14 17:40:47 --> Total execution time: 0.0731
ERROR - 2018-07-14 17:42:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:42:38 --> Config Class Initialized
INFO - 2018-07-14 17:42:38 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:42:38 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:42:38 --> Utf8 Class Initialized
INFO - 2018-07-14 17:42:38 --> URI Class Initialized
INFO - 2018-07-14 17:42:38 --> Router Class Initialized
INFO - 2018-07-14 17:42:38 --> Output Class Initialized
INFO - 2018-07-14 17:42:38 --> Security Class Initialized
DEBUG - 2018-07-14 17:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:42:38 --> Input Class Initialized
INFO - 2018-07-14 17:42:38 --> Language Class Initialized
INFO - 2018-07-14 17:42:38 --> Loader Class Initialized
INFO - 2018-07-14 17:42:38 --> Controller Class Initialized
INFO - 2018-07-14 17:42:38 --> Database Driver Class Initialized
INFO - 2018-07-14 17:42:38 --> Model Class Initialized
INFO - 2018-07-14 17:42:38 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:42:38 --> Model Class Initialized
INFO - 2018-07-14 17:42:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:42:38 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:42:38 --> Final output sent to browser
DEBUG - 2018-07-14 17:42:38 --> Total execution time: 0.0454
ERROR - 2018-07-14 17:43:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:43:02 --> Config Class Initialized
INFO - 2018-07-14 17:43:02 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:43:02 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:43:02 --> Utf8 Class Initialized
INFO - 2018-07-14 17:43:02 --> URI Class Initialized
INFO - 2018-07-14 17:43:02 --> Router Class Initialized
INFO - 2018-07-14 17:43:02 --> Output Class Initialized
INFO - 2018-07-14 17:43:02 --> Security Class Initialized
DEBUG - 2018-07-14 17:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:43:02 --> Input Class Initialized
INFO - 2018-07-14 17:43:02 --> Language Class Initialized
INFO - 2018-07-14 17:43:02 --> Loader Class Initialized
INFO - 2018-07-14 17:43:02 --> Controller Class Initialized
INFO - 2018-07-14 17:43:02 --> Database Driver Class Initialized
INFO - 2018-07-14 17:43:02 --> Model Class Initialized
INFO - 2018-07-14 17:43:02 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:43:02 --> Model Class Initialized
INFO - 2018-07-14 17:43:02 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:43:02 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:43:02 --> Final output sent to browser
DEBUG - 2018-07-14 17:43:02 --> Total execution time: 0.0514
ERROR - 2018-07-14 17:45:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:45:49 --> Config Class Initialized
INFO - 2018-07-14 17:45:49 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:45:49 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:45:49 --> Utf8 Class Initialized
INFO - 2018-07-14 17:45:49 --> URI Class Initialized
INFO - 2018-07-14 17:45:49 --> Router Class Initialized
INFO - 2018-07-14 17:45:49 --> Output Class Initialized
INFO - 2018-07-14 17:45:49 --> Security Class Initialized
DEBUG - 2018-07-14 17:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:45:49 --> Input Class Initialized
INFO - 2018-07-14 17:45:49 --> Language Class Initialized
INFO - 2018-07-14 17:45:49 --> Loader Class Initialized
INFO - 2018-07-14 17:45:49 --> Controller Class Initialized
INFO - 2018-07-14 17:45:49 --> Database Driver Class Initialized
INFO - 2018-07-14 17:45:49 --> Model Class Initialized
INFO - 2018-07-14 17:45:49 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:45:49 --> Model Class Initialized
INFO - 2018-07-14 17:45:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:45:49 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:45:49 --> Final output sent to browser
DEBUG - 2018-07-14 17:45:49 --> Total execution time: 0.0736
ERROR - 2018-07-14 17:45:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:45:52 --> Config Class Initialized
INFO - 2018-07-14 17:45:52 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:45:52 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:45:52 --> Utf8 Class Initialized
INFO - 2018-07-14 17:45:52 --> URI Class Initialized
INFO - 2018-07-14 17:45:52 --> Router Class Initialized
INFO - 2018-07-14 17:45:52 --> Output Class Initialized
INFO - 2018-07-14 17:45:52 --> Security Class Initialized
DEBUG - 2018-07-14 17:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:45:52 --> Input Class Initialized
INFO - 2018-07-14 17:45:52 --> Language Class Initialized
INFO - 2018-07-14 17:45:52 --> Loader Class Initialized
INFO - 2018-07-14 17:45:52 --> Controller Class Initialized
INFO - 2018-07-14 17:45:52 --> Database Driver Class Initialized
INFO - 2018-07-14 17:45:52 --> Model Class Initialized
INFO - 2018-07-14 17:45:52 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:45:52 --> Model Class Initialized
INFO - 2018-07-14 17:45:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:45:52 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:45:52 --> Final output sent to browser
DEBUG - 2018-07-14 17:45:52 --> Total execution time: 0.0668
ERROR - 2018-07-14 17:45:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:45:53 --> Config Class Initialized
INFO - 2018-07-14 17:45:53 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:45:53 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:45:53 --> Utf8 Class Initialized
INFO - 2018-07-14 17:45:53 --> URI Class Initialized
INFO - 2018-07-14 17:45:53 --> Router Class Initialized
INFO - 2018-07-14 17:45:53 --> Output Class Initialized
INFO - 2018-07-14 17:45:53 --> Security Class Initialized
DEBUG - 2018-07-14 17:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:45:53 --> Input Class Initialized
INFO - 2018-07-14 17:45:53 --> Language Class Initialized
INFO - 2018-07-14 17:45:53 --> Loader Class Initialized
INFO - 2018-07-14 17:45:53 --> Controller Class Initialized
INFO - 2018-07-14 17:45:53 --> Database Driver Class Initialized
INFO - 2018-07-14 17:45:53 --> Model Class Initialized
INFO - 2018-07-14 17:45:53 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:45:53 --> Model Class Initialized
INFO - 2018-07-14 17:45:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:45:53 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:45:53 --> Final output sent to browser
DEBUG - 2018-07-14 17:45:53 --> Total execution time: 0.0520
ERROR - 2018-07-14 17:46:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:46:05 --> Config Class Initialized
INFO - 2018-07-14 17:46:05 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:46:05 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:46:05 --> Utf8 Class Initialized
INFO - 2018-07-14 17:46:06 --> URI Class Initialized
INFO - 2018-07-14 17:46:06 --> Router Class Initialized
INFO - 2018-07-14 17:46:06 --> Output Class Initialized
INFO - 2018-07-14 17:46:06 --> Security Class Initialized
DEBUG - 2018-07-14 17:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:46:06 --> Input Class Initialized
INFO - 2018-07-14 17:46:06 --> Language Class Initialized
INFO - 2018-07-14 17:46:06 --> Loader Class Initialized
INFO - 2018-07-14 17:46:06 --> Controller Class Initialized
INFO - 2018-07-14 17:46:06 --> Database Driver Class Initialized
INFO - 2018-07-14 17:46:06 --> Model Class Initialized
INFO - 2018-07-14 17:46:06 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:46:06 --> Model Class Initialized
INFO - 2018-07-14 17:46:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:46:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:46:06 --> Final output sent to browser
DEBUG - 2018-07-14 17:46:06 --> Total execution time: 0.0609
ERROR - 2018-07-14 17:46:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:46:08 --> Config Class Initialized
INFO - 2018-07-14 17:46:08 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:46:08 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:46:08 --> Utf8 Class Initialized
INFO - 2018-07-14 17:46:08 --> URI Class Initialized
INFO - 2018-07-14 17:46:08 --> Router Class Initialized
INFO - 2018-07-14 17:46:08 --> Output Class Initialized
INFO - 2018-07-14 17:46:08 --> Security Class Initialized
DEBUG - 2018-07-14 17:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:46:08 --> Input Class Initialized
INFO - 2018-07-14 17:46:08 --> Language Class Initialized
INFO - 2018-07-14 17:46:08 --> Loader Class Initialized
INFO - 2018-07-14 17:46:08 --> Controller Class Initialized
INFO - 2018-07-14 17:46:08 --> Database Driver Class Initialized
INFO - 2018-07-14 17:46:08 --> Model Class Initialized
INFO - 2018-07-14 17:46:08 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:46:08 --> Model Class Initialized
INFO - 2018-07-14 17:46:08 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:46:08 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 17:46:08 --> Final output sent to browser
DEBUG - 2018-07-14 17:46:08 --> Total execution time: 0.0481
ERROR - 2018-07-14 17:46:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:46:11 --> Config Class Initialized
INFO - 2018-07-14 17:46:11 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:46:11 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:46:11 --> Utf8 Class Initialized
INFO - 2018-07-14 17:46:11 --> URI Class Initialized
INFO - 2018-07-14 17:46:11 --> Router Class Initialized
INFO - 2018-07-14 17:46:11 --> Output Class Initialized
INFO - 2018-07-14 17:46:11 --> Security Class Initialized
DEBUG - 2018-07-14 17:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:46:11 --> Input Class Initialized
INFO - 2018-07-14 17:46:11 --> Language Class Initialized
INFO - 2018-07-14 17:46:11 --> Loader Class Initialized
INFO - 2018-07-14 17:46:11 --> Controller Class Initialized
INFO - 2018-07-14 17:46:11 --> Database Driver Class Initialized
INFO - 2018-07-14 17:46:11 --> Model Class Initialized
INFO - 2018-07-14 17:46:11 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:46:11 --> Model Class Initialized
INFO - 2018-07-14 17:46:11 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:46:11 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:46:11 --> Final output sent to browser
DEBUG - 2018-07-14 17:46:11 --> Total execution time: 0.0512
ERROR - 2018-07-14 17:46:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:46:13 --> Config Class Initialized
INFO - 2018-07-14 17:46:13 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:46:13 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:46:13 --> Utf8 Class Initialized
INFO - 2018-07-14 17:46:13 --> URI Class Initialized
INFO - 2018-07-14 17:46:13 --> Router Class Initialized
INFO - 2018-07-14 17:46:13 --> Output Class Initialized
INFO - 2018-07-14 17:46:13 --> Security Class Initialized
DEBUG - 2018-07-14 17:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:46:13 --> Input Class Initialized
INFO - 2018-07-14 17:46:13 --> Language Class Initialized
INFO - 2018-07-14 17:46:13 --> Loader Class Initialized
INFO - 2018-07-14 17:46:13 --> Controller Class Initialized
INFO - 2018-07-14 17:46:13 --> Database Driver Class Initialized
INFO - 2018-07-14 17:46:13 --> Model Class Initialized
INFO - 2018-07-14 17:46:13 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:46:13 --> Model Class Initialized
INFO - 2018-07-14 17:46:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:46:13 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 17:46:13 --> Final output sent to browser
DEBUG - 2018-07-14 17:46:13 --> Total execution time: 0.0523
ERROR - 2018-07-14 17:46:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:46:15 --> Config Class Initialized
INFO - 2018-07-14 17:46:15 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:46:15 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:46:15 --> Utf8 Class Initialized
INFO - 2018-07-14 17:46:15 --> URI Class Initialized
INFO - 2018-07-14 17:46:15 --> Router Class Initialized
INFO - 2018-07-14 17:46:15 --> Output Class Initialized
INFO - 2018-07-14 17:46:15 --> Security Class Initialized
DEBUG - 2018-07-14 17:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:46:15 --> Input Class Initialized
INFO - 2018-07-14 17:46:15 --> Language Class Initialized
INFO - 2018-07-14 17:46:15 --> Loader Class Initialized
INFO - 2018-07-14 17:46:15 --> Controller Class Initialized
INFO - 2018-07-14 17:46:15 --> Database Driver Class Initialized
INFO - 2018-07-14 17:46:15 --> Model Class Initialized
INFO - 2018-07-14 17:46:15 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:46:15 --> Model Class Initialized
INFO - 2018-07-14 17:46:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:46:15 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:46:15 --> Final output sent to browser
DEBUG - 2018-07-14 17:46:15 --> Total execution time: 0.0458
ERROR - 2018-07-14 17:46:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:46:16 --> Config Class Initialized
INFO - 2018-07-14 17:46:16 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:46:16 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:46:16 --> Utf8 Class Initialized
INFO - 2018-07-14 17:46:16 --> URI Class Initialized
INFO - 2018-07-14 17:46:16 --> Router Class Initialized
INFO - 2018-07-14 17:46:16 --> Output Class Initialized
INFO - 2018-07-14 17:46:16 --> Security Class Initialized
DEBUG - 2018-07-14 17:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:46:16 --> Input Class Initialized
INFO - 2018-07-14 17:46:16 --> Language Class Initialized
INFO - 2018-07-14 17:46:16 --> Loader Class Initialized
INFO - 2018-07-14 17:46:16 --> Controller Class Initialized
INFO - 2018-07-14 17:46:16 --> Database Driver Class Initialized
INFO - 2018-07-14 17:46:16 --> Model Class Initialized
INFO - 2018-07-14 17:46:16 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:46:16 --> Model Class Initialized
INFO - 2018-07-14 17:46:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:46:16 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 17:46:16 --> Final output sent to browser
DEBUG - 2018-07-14 17:46:16 --> Total execution time: 0.0608
ERROR - 2018-07-14 17:47:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:47:06 --> Config Class Initialized
INFO - 2018-07-14 17:47:06 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:47:06 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:47:06 --> Utf8 Class Initialized
INFO - 2018-07-14 17:47:06 --> URI Class Initialized
INFO - 2018-07-14 17:47:06 --> Router Class Initialized
INFO - 2018-07-14 17:47:06 --> Output Class Initialized
INFO - 2018-07-14 17:47:06 --> Security Class Initialized
DEBUG - 2018-07-14 17:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:47:06 --> Input Class Initialized
INFO - 2018-07-14 17:47:06 --> Language Class Initialized
INFO - 2018-07-14 17:47:06 --> Loader Class Initialized
INFO - 2018-07-14 17:47:06 --> Controller Class Initialized
INFO - 2018-07-14 17:47:06 --> Database Driver Class Initialized
INFO - 2018-07-14 17:47:06 --> Model Class Initialized
INFO - 2018-07-14 17:47:06 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:47:06 --> Model Class Initialized
INFO - 2018-07-14 17:47:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:47:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 17:47:06 --> Final output sent to browser
DEBUG - 2018-07-14 17:47:06 --> Total execution time: 0.0596
ERROR - 2018-07-14 17:47:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:47:08 --> Config Class Initialized
INFO - 2018-07-14 17:47:08 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:47:08 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:47:08 --> Utf8 Class Initialized
INFO - 2018-07-14 17:47:08 --> URI Class Initialized
INFO - 2018-07-14 17:47:08 --> Router Class Initialized
INFO - 2018-07-14 17:47:08 --> Output Class Initialized
INFO - 2018-07-14 17:47:08 --> Security Class Initialized
DEBUG - 2018-07-14 17:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:47:08 --> Input Class Initialized
INFO - 2018-07-14 17:47:08 --> Language Class Initialized
INFO - 2018-07-14 17:47:08 --> Loader Class Initialized
INFO - 2018-07-14 17:47:08 --> Controller Class Initialized
INFO - 2018-07-14 17:47:08 --> Database Driver Class Initialized
INFO - 2018-07-14 17:47:08 --> Model Class Initialized
INFO - 2018-07-14 17:47:08 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:47:08 --> Model Class Initialized
INFO - 2018-07-14 17:47:08 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:47:08 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 17:47:08 --> Final output sent to browser
DEBUG - 2018-07-14 17:47:08 --> Total execution time: 0.0496
ERROR - 2018-07-14 17:47:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:47:14 --> Config Class Initialized
INFO - 2018-07-14 17:47:14 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:47:14 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:47:14 --> Utf8 Class Initialized
INFO - 2018-07-14 17:47:14 --> URI Class Initialized
INFO - 2018-07-14 17:47:14 --> Router Class Initialized
INFO - 2018-07-14 17:47:14 --> Output Class Initialized
INFO - 2018-07-14 17:47:14 --> Security Class Initialized
DEBUG - 2018-07-14 17:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:47:14 --> Input Class Initialized
INFO - 2018-07-14 17:47:14 --> Language Class Initialized
INFO - 2018-07-14 17:47:14 --> Loader Class Initialized
INFO - 2018-07-14 17:47:14 --> Controller Class Initialized
INFO - 2018-07-14 17:47:14 --> Database Driver Class Initialized
INFO - 2018-07-14 17:47:14 --> Model Class Initialized
INFO - 2018-07-14 17:47:14 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:47:14 --> Model Class Initialized
INFO - 2018-07-14 17:47:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:47:14 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:47:14 --> Final output sent to browser
DEBUG - 2018-07-14 17:47:14 --> Total execution time: 0.0478
ERROR - 2018-07-14 17:47:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:47:17 --> Config Class Initialized
INFO - 2018-07-14 17:47:17 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:47:17 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:47:17 --> Utf8 Class Initialized
INFO - 2018-07-14 17:47:17 --> URI Class Initialized
INFO - 2018-07-14 17:47:17 --> Router Class Initialized
INFO - 2018-07-14 17:47:17 --> Output Class Initialized
INFO - 2018-07-14 17:47:17 --> Security Class Initialized
DEBUG - 2018-07-14 17:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:47:17 --> Input Class Initialized
INFO - 2018-07-14 17:47:17 --> Language Class Initialized
INFO - 2018-07-14 17:47:17 --> Loader Class Initialized
INFO - 2018-07-14 17:47:17 --> Controller Class Initialized
INFO - 2018-07-14 17:47:17 --> Database Driver Class Initialized
INFO - 2018-07-14 17:47:17 --> Model Class Initialized
INFO - 2018-07-14 17:47:17 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:47:18 --> Model Class Initialized
INFO - 2018-07-14 17:47:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:47:18 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:47:18 --> Final output sent to browser
DEBUG - 2018-07-14 17:47:18 --> Total execution time: 0.0475
ERROR - 2018-07-14 17:47:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:47:19 --> Config Class Initialized
INFO - 2018-07-14 17:47:19 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:47:19 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:47:19 --> Utf8 Class Initialized
INFO - 2018-07-14 17:47:19 --> URI Class Initialized
INFO - 2018-07-14 17:47:19 --> Router Class Initialized
INFO - 2018-07-14 17:47:19 --> Output Class Initialized
INFO - 2018-07-14 17:47:19 --> Security Class Initialized
DEBUG - 2018-07-14 17:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:47:19 --> Input Class Initialized
INFO - 2018-07-14 17:47:19 --> Language Class Initialized
INFO - 2018-07-14 17:47:19 --> Loader Class Initialized
INFO - 2018-07-14 17:47:19 --> Controller Class Initialized
INFO - 2018-07-14 17:47:19 --> Database Driver Class Initialized
INFO - 2018-07-14 17:47:19 --> Model Class Initialized
INFO - 2018-07-14 17:47:19 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:47:19 --> Model Class Initialized
INFO - 2018-07-14 17:47:19 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:47:19 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:47:19 --> Final output sent to browser
DEBUG - 2018-07-14 17:47:19 --> Total execution time: 0.0667
ERROR - 2018-07-14 17:47:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:47:28 --> Config Class Initialized
INFO - 2018-07-14 17:47:28 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:47:28 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:47:28 --> Utf8 Class Initialized
INFO - 2018-07-14 17:47:28 --> URI Class Initialized
INFO - 2018-07-14 17:47:28 --> Router Class Initialized
INFO - 2018-07-14 17:47:28 --> Output Class Initialized
INFO - 2018-07-14 17:47:28 --> Security Class Initialized
DEBUG - 2018-07-14 17:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:47:28 --> Input Class Initialized
INFO - 2018-07-14 17:47:28 --> Language Class Initialized
INFO - 2018-07-14 17:47:28 --> Loader Class Initialized
INFO - 2018-07-14 17:47:28 --> Controller Class Initialized
INFO - 2018-07-14 17:47:28 --> Database Driver Class Initialized
INFO - 2018-07-14 17:47:28 --> Model Class Initialized
INFO - 2018-07-14 17:47:28 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:47:28 --> Model Class Initialized
INFO - 2018-07-14 17:47:28 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:47:28 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:47:28 --> Final output sent to browser
DEBUG - 2018-07-14 17:47:28 --> Total execution time: 0.0543
ERROR - 2018-07-14 17:47:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:47:29 --> Config Class Initialized
INFO - 2018-07-14 17:47:29 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:47:29 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:47:29 --> Utf8 Class Initialized
INFO - 2018-07-14 17:47:29 --> URI Class Initialized
INFO - 2018-07-14 17:47:29 --> Router Class Initialized
INFO - 2018-07-14 17:47:29 --> Output Class Initialized
INFO - 2018-07-14 17:47:29 --> Security Class Initialized
DEBUG - 2018-07-14 17:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:47:29 --> Input Class Initialized
INFO - 2018-07-14 17:47:29 --> Language Class Initialized
INFO - 2018-07-14 17:47:29 --> Loader Class Initialized
INFO - 2018-07-14 17:47:29 --> Controller Class Initialized
INFO - 2018-07-14 17:47:29 --> Database Driver Class Initialized
INFO - 2018-07-14 17:47:29 --> Model Class Initialized
INFO - 2018-07-14 17:47:30 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:47:30 --> Model Class Initialized
INFO - 2018-07-14 17:47:30 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:47:30 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:47:30 --> Final output sent to browser
DEBUG - 2018-07-14 17:47:30 --> Total execution time: 0.0664
ERROR - 2018-07-14 17:47:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:47:45 --> Config Class Initialized
INFO - 2018-07-14 17:47:45 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:47:45 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:47:45 --> Utf8 Class Initialized
INFO - 2018-07-14 17:47:45 --> URI Class Initialized
INFO - 2018-07-14 17:47:45 --> Router Class Initialized
INFO - 2018-07-14 17:47:45 --> Output Class Initialized
INFO - 2018-07-14 17:47:45 --> Security Class Initialized
DEBUG - 2018-07-14 17:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:47:45 --> Input Class Initialized
INFO - 2018-07-14 17:47:45 --> Language Class Initialized
INFO - 2018-07-14 17:47:45 --> Loader Class Initialized
INFO - 2018-07-14 17:47:45 --> Controller Class Initialized
INFO - 2018-07-14 17:47:45 --> Database Driver Class Initialized
INFO - 2018-07-14 17:47:45 --> Model Class Initialized
INFO - 2018-07-14 17:47:45 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:47:45 --> Model Class Initialized
INFO - 2018-07-14 17:47:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:47:45 --> File loaded: C:\xampp\htdocs\davidhood\application\views\user.php
INFO - 2018-07-14 17:47:45 --> Final output sent to browser
DEBUG - 2018-07-14 17:47:45 --> Total execution time: 0.0568
ERROR - 2018-07-14 17:47:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 17:47:48 --> Config Class Initialized
INFO - 2018-07-14 17:47:48 --> Hooks Class Initialized
DEBUG - 2018-07-14 17:47:48 --> UTF-8 Support Enabled
INFO - 2018-07-14 17:47:48 --> Utf8 Class Initialized
INFO - 2018-07-14 17:47:48 --> URI Class Initialized
INFO - 2018-07-14 17:47:48 --> Router Class Initialized
INFO - 2018-07-14 17:47:48 --> Output Class Initialized
INFO - 2018-07-14 17:47:48 --> Security Class Initialized
DEBUG - 2018-07-14 17:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 17:47:48 --> Input Class Initialized
INFO - 2018-07-14 17:47:48 --> Language Class Initialized
INFO - 2018-07-14 17:47:48 --> Loader Class Initialized
INFO - 2018-07-14 17:47:48 --> Controller Class Initialized
INFO - 2018-07-14 17:47:48 --> Database Driver Class Initialized
INFO - 2018-07-14 17:47:48 --> Model Class Initialized
INFO - 2018-07-14 17:47:48 --> Helper loaded: url_helper
DEBUG - 2018-07-14 17:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-07-14 17:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-07-14 17:47:48 --> Model Class Initialized
INFO - 2018-07-14 17:47:48 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-07-14 17:47:48 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-07-14 17:47:48 --> Final output sent to browser
DEBUG - 2018-07-14 17:47:48 --> Total execution time: 0.0751
ERROR - 2018-07-14 18:01:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 18:01:23 --> Config Class Initialized
INFO - 2018-07-14 18:01:23 --> Hooks Class Initialized
DEBUG - 2018-07-14 18:01:23 --> UTF-8 Support Enabled
INFO - 2018-07-14 18:01:23 --> Utf8 Class Initialized
INFO - 2018-07-14 18:01:23 --> URI Class Initialized
INFO - 2018-07-14 18:01:23 --> Router Class Initialized
INFO - 2018-07-14 18:01:23 --> Output Class Initialized
INFO - 2018-07-14 18:01:23 --> Security Class Initialized
DEBUG - 2018-07-14 18:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 18:01:23 --> Input Class Initialized
INFO - 2018-07-14 18:01:23 --> Language Class Initialized
INFO - 2018-07-14 18:01:23 --> Loader Class Initialized
INFO - 2018-07-14 18:01:23 --> Controller Class Initialized
INFO - 2018-07-14 18:01:23 --> Database Driver Class Initialized
INFO - 2018-07-14 18:01:23 --> Model Class Initialized
INFO - 2018-07-14 18:01:23 --> Helper loaded: url_helper
INFO - 2018-07-14 18:01:23 --> Model Class Initialized
INFO - 2018-07-14 18:01:23 --> Final output sent to browser
DEBUG - 2018-07-14 18:01:23 --> Total execution time: 0.0467
ERROR - 2018-07-14 18:05:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 18:05:14 --> Config Class Initialized
INFO - 2018-07-14 18:05:14 --> Hooks Class Initialized
DEBUG - 2018-07-14 18:05:14 --> UTF-8 Support Enabled
INFO - 2018-07-14 18:05:14 --> Utf8 Class Initialized
INFO - 2018-07-14 18:05:14 --> URI Class Initialized
INFO - 2018-07-14 18:05:14 --> Router Class Initialized
INFO - 2018-07-14 18:05:14 --> Output Class Initialized
INFO - 2018-07-14 18:05:14 --> Security Class Initialized
DEBUG - 2018-07-14 18:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 18:05:14 --> Input Class Initialized
INFO - 2018-07-14 18:05:14 --> Language Class Initialized
INFO - 2018-07-14 18:05:14 --> Loader Class Initialized
INFO - 2018-07-14 18:05:14 --> Controller Class Initialized
INFO - 2018-07-14 18:05:14 --> Database Driver Class Initialized
INFO - 2018-07-14 18:05:14 --> Model Class Initialized
INFO - 2018-07-14 18:05:14 --> Helper loaded: url_helper
INFO - 2018-07-14 18:05:14 --> Model Class Initialized
INFO - 2018-07-14 18:05:14 --> Final output sent to browser
DEBUG - 2018-07-14 18:05:14 --> Total execution time: 0.0410
ERROR - 2018-07-14 18:10:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 18:10:51 --> Config Class Initialized
INFO - 2018-07-14 18:10:51 --> Hooks Class Initialized
DEBUG - 2018-07-14 18:10:51 --> UTF-8 Support Enabled
INFO - 2018-07-14 18:10:51 --> Utf8 Class Initialized
INFO - 2018-07-14 18:10:51 --> URI Class Initialized
INFO - 2018-07-14 18:10:51 --> Router Class Initialized
INFO - 2018-07-14 18:10:51 --> Output Class Initialized
INFO - 2018-07-14 18:10:51 --> Security Class Initialized
DEBUG - 2018-07-14 18:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 18:10:51 --> Input Class Initialized
INFO - 2018-07-14 18:10:51 --> Language Class Initialized
INFO - 2018-07-14 18:10:51 --> Loader Class Initialized
INFO - 2018-07-14 18:10:51 --> Controller Class Initialized
INFO - 2018-07-14 18:10:51 --> Database Driver Class Initialized
INFO - 2018-07-14 18:10:51 --> Model Class Initialized
INFO - 2018-07-14 18:10:51 --> Helper loaded: url_helper
INFO - 2018-07-14 18:10:51 --> Model Class Initialized
INFO - 2018-07-14 18:10:51 --> Final output sent to browser
DEBUG - 2018-07-14 18:10:51 --> Total execution time: 0.0454
ERROR - 2018-07-14 18:37:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 18:37:32 --> Config Class Initialized
INFO - 2018-07-14 18:37:32 --> Hooks Class Initialized
DEBUG - 2018-07-14 18:37:32 --> UTF-8 Support Enabled
INFO - 2018-07-14 18:37:32 --> Utf8 Class Initialized
INFO - 2018-07-14 18:37:32 --> URI Class Initialized
INFO - 2018-07-14 18:37:32 --> Router Class Initialized
INFO - 2018-07-14 18:37:32 --> Output Class Initialized
INFO - 2018-07-14 18:37:32 --> Security Class Initialized
DEBUG - 2018-07-14 18:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 18:37:32 --> Input Class Initialized
INFO - 2018-07-14 18:37:32 --> Language Class Initialized
INFO - 2018-07-14 18:37:32 --> Loader Class Initialized
INFO - 2018-07-14 18:37:32 --> Controller Class Initialized
INFO - 2018-07-14 18:37:32 --> Database Driver Class Initialized
INFO - 2018-07-14 18:37:32 --> Model Class Initialized
INFO - 2018-07-14 18:37:32 --> Helper loaded: url_helper
INFO - 2018-07-14 18:37:32 --> Model Class Initialized
INFO - 2018-07-14 18:37:32 --> Final output sent to browser
DEBUG - 2018-07-14 18:37:32 --> Total execution time: 0.0419
ERROR - 2018-07-14 18:48:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 18:48:46 --> Config Class Initialized
INFO - 2018-07-14 18:48:46 --> Hooks Class Initialized
DEBUG - 2018-07-14 18:48:46 --> UTF-8 Support Enabled
INFO - 2018-07-14 18:48:46 --> Utf8 Class Initialized
INFO - 2018-07-14 18:48:46 --> URI Class Initialized
INFO - 2018-07-14 18:48:46 --> Router Class Initialized
INFO - 2018-07-14 18:48:46 --> Output Class Initialized
INFO - 2018-07-14 18:48:46 --> Security Class Initialized
DEBUG - 2018-07-14 18:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 18:48:46 --> Input Class Initialized
INFO - 2018-07-14 18:48:46 --> Language Class Initialized
INFO - 2018-07-14 18:48:46 --> Loader Class Initialized
INFO - 2018-07-14 18:48:46 --> Controller Class Initialized
INFO - 2018-07-14 18:48:46 --> Database Driver Class Initialized
INFO - 2018-07-14 18:48:46 --> Model Class Initialized
INFO - 2018-07-14 18:48:46 --> Helper loaded: url_helper
INFO - 2018-07-14 18:48:46 --> Model Class Initialized
ERROR - 2018-07-14 18:48:46 --> Severity: Notice --> Undefined variable: out_array C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 42
INFO - 2018-07-14 18:48:46 --> Final output sent to browser
DEBUG - 2018-07-14 18:48:46 --> Total execution time: 0.0441
ERROR - 2018-07-14 18:49:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 18:49:38 --> Config Class Initialized
INFO - 2018-07-14 18:49:38 --> Hooks Class Initialized
DEBUG - 2018-07-14 18:49:38 --> UTF-8 Support Enabled
INFO - 2018-07-14 18:49:38 --> Utf8 Class Initialized
INFO - 2018-07-14 18:49:38 --> URI Class Initialized
INFO - 2018-07-14 18:49:38 --> Router Class Initialized
INFO - 2018-07-14 18:49:38 --> Output Class Initialized
INFO - 2018-07-14 18:49:38 --> Security Class Initialized
DEBUG - 2018-07-14 18:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 18:49:38 --> Input Class Initialized
INFO - 2018-07-14 18:49:38 --> Language Class Initialized
INFO - 2018-07-14 18:49:38 --> Loader Class Initialized
INFO - 2018-07-14 18:49:38 --> Controller Class Initialized
INFO - 2018-07-14 18:49:38 --> Database Driver Class Initialized
INFO - 2018-07-14 18:49:38 --> Model Class Initialized
INFO - 2018-07-14 18:49:38 --> Helper loaded: url_helper
INFO - 2018-07-14 18:49:38 --> Model Class Initialized
ERROR - 2018-07-14 18:49:38 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 21
ERROR - 2018-07-14 18:49:38 --> Severity: Notice --> Undefined variable: out_array C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 42
INFO - 2018-07-14 18:49:38 --> Final output sent to browser
DEBUG - 2018-07-14 18:49:38 --> Total execution time: 0.0421
ERROR - 2018-07-14 18:49:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 18:49:46 --> Config Class Initialized
INFO - 2018-07-14 18:49:46 --> Hooks Class Initialized
DEBUG - 2018-07-14 18:49:46 --> UTF-8 Support Enabled
INFO - 2018-07-14 18:49:46 --> Utf8 Class Initialized
INFO - 2018-07-14 18:49:46 --> URI Class Initialized
INFO - 2018-07-14 18:49:46 --> Router Class Initialized
INFO - 2018-07-14 18:49:46 --> Output Class Initialized
INFO - 2018-07-14 18:49:46 --> Security Class Initialized
DEBUG - 2018-07-14 18:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 18:49:46 --> Input Class Initialized
INFO - 2018-07-14 18:49:46 --> Language Class Initialized
INFO - 2018-07-14 18:49:46 --> Loader Class Initialized
INFO - 2018-07-14 18:49:46 --> Controller Class Initialized
INFO - 2018-07-14 18:49:46 --> Database Driver Class Initialized
INFO - 2018-07-14 18:49:46 --> Model Class Initialized
INFO - 2018-07-14 18:49:46 --> Helper loaded: url_helper
INFO - 2018-07-14 18:49:46 --> Model Class Initialized
ERROR - 2018-07-14 18:49:46 --> Severity: Notice --> Undefined variable: out_array C:\xampp\htdocs\davidhood\application\controllers\Mobile.php 42
INFO - 2018-07-14 18:49:46 --> Final output sent to browser
DEBUG - 2018-07-14 18:49:46 --> Total execution time: 0.0523
ERROR - 2018-07-14 18:50:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 18:50:46 --> Config Class Initialized
INFO - 2018-07-14 18:50:46 --> Hooks Class Initialized
DEBUG - 2018-07-14 18:50:46 --> UTF-8 Support Enabled
INFO - 2018-07-14 18:50:46 --> Utf8 Class Initialized
INFO - 2018-07-14 18:50:46 --> URI Class Initialized
INFO - 2018-07-14 18:50:46 --> Router Class Initialized
INFO - 2018-07-14 18:50:46 --> Output Class Initialized
INFO - 2018-07-14 18:50:46 --> Security Class Initialized
DEBUG - 2018-07-14 18:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 18:50:46 --> Input Class Initialized
INFO - 2018-07-14 18:50:46 --> Language Class Initialized
INFO - 2018-07-14 18:50:47 --> Loader Class Initialized
INFO - 2018-07-14 18:50:47 --> Controller Class Initialized
INFO - 2018-07-14 18:50:47 --> Database Driver Class Initialized
INFO - 2018-07-14 18:50:47 --> Model Class Initialized
INFO - 2018-07-14 18:50:47 --> Helper loaded: url_helper
INFO - 2018-07-14 18:50:47 --> Model Class Initialized
INFO - 2018-07-14 18:50:47 --> Final output sent to browser
DEBUG - 2018-07-14 18:50:47 --> Total execution time: 0.0419
ERROR - 2018-07-14 18:51:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-07-14 18:51:26 --> Config Class Initialized
INFO - 2018-07-14 18:51:26 --> Hooks Class Initialized
DEBUG - 2018-07-14 18:51:26 --> UTF-8 Support Enabled
INFO - 2018-07-14 18:51:26 --> Utf8 Class Initialized
INFO - 2018-07-14 18:51:26 --> URI Class Initialized
INFO - 2018-07-14 18:51:26 --> Router Class Initialized
INFO - 2018-07-14 18:51:26 --> Output Class Initialized
INFO - 2018-07-14 18:51:26 --> Security Class Initialized
DEBUG - 2018-07-14 18:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-07-14 18:51:26 --> Input Class Initialized
INFO - 2018-07-14 18:51:26 --> Language Class Initialized
INFO - 2018-07-14 18:51:26 --> Loader Class Initialized
INFO - 2018-07-14 18:51:26 --> Controller Class Initialized
INFO - 2018-07-14 18:51:26 --> Database Driver Class Initialized
INFO - 2018-07-14 18:51:26 --> Model Class Initialized
INFO - 2018-07-14 18:51:26 --> Helper loaded: url_helper
INFO - 2018-07-14 18:51:26 --> Model Class Initialized
INFO - 2018-07-14 18:51:26 --> Final output sent to browser
DEBUG - 2018-07-14 18:51:26 --> Total execution time: 0.0491
