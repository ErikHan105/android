<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-03 17:30:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-03 17:30:09 --> Config Class Initialized
INFO - 2017-09-03 17:30:09 --> Hooks Class Initialized
DEBUG - 2017-09-03 17:30:09 --> UTF-8 Support Enabled
INFO - 2017-09-03 17:30:09 --> Utf8 Class Initialized
INFO - 2017-09-03 17:30:09 --> URI Class Initialized
DEBUG - 2017-09-03 17:30:09 --> No URI present. Default controller set.
INFO - 2017-09-03 17:30:09 --> Router Class Initialized
INFO - 2017-09-03 17:30:09 --> Output Class Initialized
INFO - 2017-09-03 17:30:09 --> Security Class Initialized
DEBUG - 2017-09-03 17:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-03 17:30:09 --> Input Class Initialized
INFO - 2017-09-03 17:30:09 --> Language Class Initialized
INFO - 2017-09-03 17:30:10 --> Loader Class Initialized
INFO - 2017-09-03 17:30:10 --> Controller Class Initialized
INFO - 2017-09-03 17:30:10 --> Database Driver Class Initialized
INFO - 2017-09-03 17:30:10 --> Model Class Initialized
INFO - 2017-09-03 17:30:10 --> Helper loaded: form_helper
INFO - 2017-09-03 17:30:10 --> Helper loaded: url_helper
INFO - 2017-09-03 17:30:10 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-09-03 17:30:10 --> Final output sent to browser
DEBUG - 2017-09-03 17:30:10 --> Total execution time: 0.3380
ERROR - 2017-09-03 17:30:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-03 17:30:14 --> Config Class Initialized
INFO - 2017-09-03 17:30:14 --> Hooks Class Initialized
DEBUG - 2017-09-03 17:30:14 --> UTF-8 Support Enabled
INFO - 2017-09-03 17:30:14 --> Utf8 Class Initialized
INFO - 2017-09-03 17:30:14 --> URI Class Initialized
INFO - 2017-09-03 17:30:14 --> Router Class Initialized
INFO - 2017-09-03 17:30:14 --> Output Class Initialized
INFO - 2017-09-03 17:30:14 --> Security Class Initialized
DEBUG - 2017-09-03 17:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-03 17:30:14 --> Input Class Initialized
INFO - 2017-09-03 17:30:14 --> Language Class Initialized
INFO - 2017-09-03 17:30:14 --> Loader Class Initialized
INFO - 2017-09-03 17:30:14 --> Controller Class Initialized
INFO - 2017-09-03 17:30:14 --> Database Driver Class Initialized
INFO - 2017-09-03 17:30:14 --> Model Class Initialized
INFO - 2017-09-03 17:30:14 --> Helper loaded: form_helper
INFO - 2017-09-03 17:30:14 --> Helper loaded: url_helper
INFO - 2017-09-03 17:30:14 --> Model Class Initialized
ERROR - 2017-09-03 17:30:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-03 17:30:14 --> Config Class Initialized
INFO - 2017-09-03 17:30:14 --> Hooks Class Initialized
DEBUG - 2017-09-03 17:30:14 --> UTF-8 Support Enabled
INFO - 2017-09-03 17:30:14 --> Utf8 Class Initialized
INFO - 2017-09-03 17:30:14 --> URI Class Initialized
INFO - 2017-09-03 17:30:14 --> Router Class Initialized
INFO - 2017-09-03 17:30:14 --> Output Class Initialized
INFO - 2017-09-03 17:30:14 --> Security Class Initialized
DEBUG - 2017-09-03 17:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-03 17:30:14 --> Input Class Initialized
INFO - 2017-09-03 17:30:14 --> Language Class Initialized
INFO - 2017-09-03 17:30:14 --> Loader Class Initialized
INFO - 2017-09-03 17:30:14 --> Controller Class Initialized
INFO - 2017-09-03 17:30:14 --> Database Driver Class Initialized
INFO - 2017-09-03 17:30:14 --> Model Class Initialized
INFO - 2017-09-03 17:30:14 --> Helper loaded: form_helper
INFO - 2017-09-03 17:30:14 --> Helper loaded: url_helper
INFO - 2017-09-03 17:30:14 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-09-03 17:30:14 --> Model Class Initialized
INFO - 2017-09-03 17:30:15 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-09-03 17:30:15 --> Final output sent to browser
DEBUG - 2017-09-03 17:30:15 --> Total execution time: 0.1580
ERROR - 2017-09-03 17:30:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-03 17:30:17 --> Config Class Initialized
INFO - 2017-09-03 17:30:17 --> Hooks Class Initialized
DEBUG - 2017-09-03 17:30:17 --> UTF-8 Support Enabled
INFO - 2017-09-03 17:30:17 --> Utf8 Class Initialized
INFO - 2017-09-03 17:30:17 --> URI Class Initialized
INFO - 2017-09-03 17:30:17 --> Router Class Initialized
INFO - 2017-09-03 17:30:17 --> Output Class Initialized
INFO - 2017-09-03 17:30:17 --> Security Class Initialized
DEBUG - 2017-09-03 17:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-03 17:30:17 --> Input Class Initialized
INFO - 2017-09-03 17:30:17 --> Language Class Initialized
INFO - 2017-09-03 17:30:17 --> Loader Class Initialized
INFO - 2017-09-03 17:30:17 --> Controller Class Initialized
INFO - 2017-09-03 17:30:17 --> Database Driver Class Initialized
INFO - 2017-09-03 17:30:17 --> Model Class Initialized
INFO - 2017-09-03 17:30:17 --> Helper loaded: form_helper
INFO - 2017-09-03 17:30:17 --> Helper loaded: url_helper
INFO - 2017-09-03 17:30:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-09-03 17:30:17 --> Model Class Initialized
INFO - 2017-09-03 17:30:17 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-09-03 17:30:17 --> Final output sent to browser
DEBUG - 2017-09-03 17:30:17 --> Total execution time: 0.2090
ERROR - 2017-09-03 17:30:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-03 17:30:19 --> Config Class Initialized
INFO - 2017-09-03 17:30:19 --> Hooks Class Initialized
DEBUG - 2017-09-03 17:30:19 --> UTF-8 Support Enabled
INFO - 2017-09-03 17:30:19 --> Utf8 Class Initialized
INFO - 2017-09-03 17:30:19 --> URI Class Initialized
INFO - 2017-09-03 17:30:19 --> Router Class Initialized
INFO - 2017-09-03 17:30:19 --> Output Class Initialized
INFO - 2017-09-03 17:30:19 --> Security Class Initialized
DEBUG - 2017-09-03 17:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-03 17:30:19 --> Input Class Initialized
INFO - 2017-09-03 17:30:19 --> Language Class Initialized
INFO - 2017-09-03 17:30:19 --> Loader Class Initialized
INFO - 2017-09-03 17:30:19 --> Controller Class Initialized
INFO - 2017-09-03 17:30:19 --> Database Driver Class Initialized
INFO - 2017-09-03 17:30:19 --> Model Class Initialized
INFO - 2017-09-03 17:30:19 --> Helper loaded: form_helper
INFO - 2017-09-03 17:30:19 --> Helper loaded: url_helper
INFO - 2017-09-03 17:30:19 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-09-03 17:30:19 --> Model Class Initialized
INFO - 2017-09-03 17:30:19 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-09-03 17:30:19 --> Final output sent to browser
DEBUG - 2017-09-03 17:30:19 --> Total execution time: 0.0680
