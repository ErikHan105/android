<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-19 07:35:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-19 07:35:57 --> Config Class Initialized
INFO - 2017-08-19 07:35:57 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:35:57 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:35:57 --> Utf8 Class Initialized
INFO - 2017-08-19 07:35:57 --> URI Class Initialized
DEBUG - 2017-08-19 07:35:57 --> No URI present. Default controller set.
INFO - 2017-08-19 07:35:57 --> Router Class Initialized
INFO - 2017-08-19 07:35:57 --> Output Class Initialized
INFO - 2017-08-19 07:35:57 --> Security Class Initialized
DEBUG - 2017-08-19 07:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:35:57 --> Input Class Initialized
INFO - 2017-08-19 07:35:57 --> Language Class Initialized
INFO - 2017-08-19 07:35:57 --> Loader Class Initialized
INFO - 2017-08-19 07:35:57 --> Controller Class Initialized
INFO - 2017-08-19 07:35:57 --> Database Driver Class Initialized
INFO - 2017-08-19 07:35:57 --> Model Class Initialized
INFO - 2017-08-19 07:35:57 --> Helper loaded: form_helper
INFO - 2017-08-19 07:35:57 --> Helper loaded: url_helper
INFO - 2017-08-19 07:35:57 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-08-19 07:35:57 --> Final output sent to browser
DEBUG - 2017-08-19 07:35:57 --> Total execution time: 0.0350
ERROR - 2017-08-19 07:36:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-19 07:36:00 --> Config Class Initialized
INFO - 2017-08-19 07:36:00 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:36:00 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:36:00 --> Utf8 Class Initialized
INFO - 2017-08-19 07:36:00 --> URI Class Initialized
INFO - 2017-08-19 07:36:00 --> Router Class Initialized
INFO - 2017-08-19 07:36:00 --> Output Class Initialized
INFO - 2017-08-19 07:36:00 --> Security Class Initialized
DEBUG - 2017-08-19 07:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:36:00 --> Input Class Initialized
INFO - 2017-08-19 07:36:00 --> Language Class Initialized
INFO - 2017-08-19 07:36:00 --> Loader Class Initialized
INFO - 2017-08-19 07:36:00 --> Controller Class Initialized
INFO - 2017-08-19 07:36:00 --> Database Driver Class Initialized
INFO - 2017-08-19 07:36:00 --> Model Class Initialized
INFO - 2017-08-19 07:36:00 --> Helper loaded: form_helper
INFO - 2017-08-19 07:36:00 --> Helper loaded: url_helper
INFO - 2017-08-19 07:36:00 --> Model Class Initialized
ERROR - 2017-08-19 07:36:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-19 07:36:00 --> Config Class Initialized
INFO - 2017-08-19 07:36:00 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:36:00 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:36:00 --> Utf8 Class Initialized
INFO - 2017-08-19 07:36:00 --> URI Class Initialized
INFO - 2017-08-19 07:36:00 --> Router Class Initialized
INFO - 2017-08-19 07:36:00 --> Output Class Initialized
INFO - 2017-08-19 07:36:00 --> Security Class Initialized
DEBUG - 2017-08-19 07:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:36:00 --> Input Class Initialized
INFO - 2017-08-19 07:36:00 --> Language Class Initialized
INFO - 2017-08-19 07:36:00 --> Loader Class Initialized
INFO - 2017-08-19 07:36:00 --> Controller Class Initialized
INFO - 2017-08-19 07:36:00 --> Database Driver Class Initialized
INFO - 2017-08-19 07:36:00 --> Model Class Initialized
INFO - 2017-08-19 07:36:00 --> Helper loaded: form_helper
INFO - 2017-08-19 07:36:00 --> Helper loaded: url_helper
INFO - 2017-08-19 07:36:00 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-19 07:36:00 --> Model Class Initialized
INFO - 2017-08-19 07:36:00 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-08-19 07:36:00 --> Final output sent to browser
DEBUG - 2017-08-19 07:36:00 --> Total execution time: 0.0640
ERROR - 2017-08-19 07:36:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-19 07:36:09 --> Config Class Initialized
INFO - 2017-08-19 07:36:09 --> Hooks Class Initialized
DEBUG - 2017-08-19 07:36:09 --> UTF-8 Support Enabled
INFO - 2017-08-19 07:36:09 --> Utf8 Class Initialized
INFO - 2017-08-19 07:36:09 --> URI Class Initialized
INFO - 2017-08-19 07:36:09 --> Router Class Initialized
INFO - 2017-08-19 07:36:09 --> Output Class Initialized
INFO - 2017-08-19 07:36:09 --> Security Class Initialized
DEBUG - 2017-08-19 07:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 07:36:09 --> Input Class Initialized
INFO - 2017-08-19 07:36:09 --> Language Class Initialized
INFO - 2017-08-19 07:36:09 --> Loader Class Initialized
INFO - 2017-08-19 07:36:09 --> Controller Class Initialized
INFO - 2017-08-19 07:36:09 --> Database Driver Class Initialized
INFO - 2017-08-19 07:36:09 --> Model Class Initialized
INFO - 2017-08-19 07:36:09 --> Helper loaded: form_helper
INFO - 2017-08-19 07:36:09 --> Helper loaded: url_helper
INFO - 2017-08-19 07:36:09 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-19 07:36:09 --> Model Class Initialized
INFO - 2017-08-19 07:36:09 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-08-19 07:36:09 --> Final output sent to browser
DEBUG - 2017-08-19 07:36:09 --> Total execution time: 0.0890
ERROR - 2017-08-19 08:57:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-08-19 08:57:11 --> Config Class Initialized
INFO - 2017-08-19 08:57:11 --> Hooks Class Initialized
DEBUG - 2017-08-19 08:57:11 --> UTF-8 Support Enabled
INFO - 2017-08-19 08:57:11 --> Utf8 Class Initialized
INFO - 2017-08-19 08:57:11 --> URI Class Initialized
INFO - 2017-08-19 08:57:11 --> Router Class Initialized
INFO - 2017-08-19 08:57:11 --> Output Class Initialized
INFO - 2017-08-19 08:57:11 --> Security Class Initialized
DEBUG - 2017-08-19 08:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-19 08:57:11 --> Input Class Initialized
INFO - 2017-08-19 08:57:11 --> Language Class Initialized
INFO - 2017-08-19 08:57:11 --> Loader Class Initialized
INFO - 2017-08-19 08:57:11 --> Controller Class Initialized
INFO - 2017-08-19 08:57:11 --> Database Driver Class Initialized
INFO - 2017-08-19 08:57:11 --> Model Class Initialized
INFO - 2017-08-19 08:57:11 --> Helper loaded: form_helper
INFO - 2017-08-19 08:57:11 --> Helper loaded: url_helper
INFO - 2017-08-19 08:57:11 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-08-19 08:57:11 --> Model Class Initialized
INFO - 2017-08-19 08:57:11 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-08-19 08:57:11 --> Final output sent to browser
DEBUG - 2017-08-19 08:57:11 --> Total execution time: 0.0690
