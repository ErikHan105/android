<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-04 12:18:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-04 12:18:10 --> Config Class Initialized
INFO - 2017-09-04 12:18:10 --> Hooks Class Initialized
DEBUG - 2017-09-04 12:18:10 --> UTF-8 Support Enabled
INFO - 2017-09-04 12:18:10 --> Utf8 Class Initialized
INFO - 2017-09-04 12:18:10 --> URI Class Initialized
DEBUG - 2017-09-04 12:18:10 --> No URI present. Default controller set.
INFO - 2017-09-04 12:18:10 --> Router Class Initialized
INFO - 2017-09-04 12:18:10 --> Output Class Initialized
INFO - 2017-09-04 12:18:10 --> Security Class Initialized
DEBUG - 2017-09-04 12:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-04 12:18:10 --> Input Class Initialized
INFO - 2017-09-04 12:18:10 --> Language Class Initialized
INFO - 2017-09-04 12:18:10 --> Loader Class Initialized
INFO - 2017-09-04 12:18:10 --> Controller Class Initialized
INFO - 2017-09-04 12:18:10 --> Database Driver Class Initialized
INFO - 2017-09-04 12:18:10 --> Model Class Initialized
INFO - 2017-09-04 12:18:10 --> Helper loaded: form_helper
INFO - 2017-09-04 12:18:10 --> Helper loaded: url_helper
INFO - 2017-09-04 12:18:11 --> File loaded: C:\xampp\htdocs\mystage\application\views\login.php
INFO - 2017-09-04 12:18:11 --> Final output sent to browser
DEBUG - 2017-09-04 12:18:11 --> Total execution time: 0.9001
ERROR - 2017-09-04 12:18:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-04 12:18:13 --> Config Class Initialized
INFO - 2017-09-04 12:18:13 --> Hooks Class Initialized
DEBUG - 2017-09-04 12:18:13 --> UTF-8 Support Enabled
INFO - 2017-09-04 12:18:13 --> Utf8 Class Initialized
INFO - 2017-09-04 12:18:13 --> URI Class Initialized
INFO - 2017-09-04 12:18:13 --> Router Class Initialized
INFO - 2017-09-04 12:18:13 --> Output Class Initialized
INFO - 2017-09-04 12:18:13 --> Security Class Initialized
DEBUG - 2017-09-04 12:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-04 12:18:13 --> Input Class Initialized
INFO - 2017-09-04 12:18:13 --> Language Class Initialized
INFO - 2017-09-04 12:18:13 --> Loader Class Initialized
INFO - 2017-09-04 12:18:13 --> Controller Class Initialized
INFO - 2017-09-04 12:18:14 --> Database Driver Class Initialized
INFO - 2017-09-04 12:18:14 --> Model Class Initialized
INFO - 2017-09-04 12:18:14 --> Helper loaded: form_helper
INFO - 2017-09-04 12:18:14 --> Helper loaded: url_helper
INFO - 2017-09-04 12:18:14 --> Model Class Initialized
ERROR - 2017-09-04 12:18:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-04 12:18:14 --> Config Class Initialized
INFO - 2017-09-04 12:18:14 --> Hooks Class Initialized
DEBUG - 2017-09-04 12:18:14 --> UTF-8 Support Enabled
INFO - 2017-09-04 12:18:14 --> Utf8 Class Initialized
INFO - 2017-09-04 12:18:14 --> URI Class Initialized
INFO - 2017-09-04 12:18:14 --> Router Class Initialized
INFO - 2017-09-04 12:18:14 --> Output Class Initialized
INFO - 2017-09-04 12:18:14 --> Security Class Initialized
DEBUG - 2017-09-04 12:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-04 12:18:14 --> Input Class Initialized
INFO - 2017-09-04 12:18:14 --> Language Class Initialized
INFO - 2017-09-04 12:18:14 --> Loader Class Initialized
INFO - 2017-09-04 12:18:14 --> Controller Class Initialized
INFO - 2017-09-04 12:18:14 --> Database Driver Class Initialized
INFO - 2017-09-04 12:18:14 --> Model Class Initialized
INFO - 2017-09-04 12:18:14 --> Helper loaded: form_helper
INFO - 2017-09-04 12:18:14 --> Helper loaded: url_helper
INFO - 2017-09-04 12:18:14 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-09-04 12:18:14 --> Model Class Initialized
INFO - 2017-09-04 12:18:14 --> File loaded: C:\xampp\htdocs\mystage\application\views\dashboard.php
INFO - 2017-09-04 12:18:14 --> Final output sent to browser
DEBUG - 2017-09-04 12:18:14 --> Total execution time: 0.2780
ERROR - 2017-09-04 12:18:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-04 12:18:16 --> Config Class Initialized
INFO - 2017-09-04 12:18:16 --> Hooks Class Initialized
DEBUG - 2017-09-04 12:18:16 --> UTF-8 Support Enabled
INFO - 2017-09-04 12:18:16 --> Utf8 Class Initialized
INFO - 2017-09-04 12:18:16 --> URI Class Initialized
INFO - 2017-09-04 12:18:16 --> Router Class Initialized
INFO - 2017-09-04 12:18:16 --> Output Class Initialized
INFO - 2017-09-04 12:18:16 --> Security Class Initialized
DEBUG - 2017-09-04 12:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-04 12:18:16 --> Input Class Initialized
INFO - 2017-09-04 12:18:16 --> Language Class Initialized
INFO - 2017-09-04 12:18:16 --> Loader Class Initialized
INFO - 2017-09-04 12:18:16 --> Controller Class Initialized
INFO - 2017-09-04 12:18:16 --> Database Driver Class Initialized
INFO - 2017-09-04 12:18:16 --> Model Class Initialized
INFO - 2017-09-04 12:18:16 --> Helper loaded: form_helper
INFO - 2017-09-04 12:18:16 --> Helper loaded: url_helper
INFO - 2017-09-04 12:18:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-09-04 12:18:16 --> Model Class Initialized
INFO - 2017-09-04 12:18:16 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-09-04 12:18:16 --> Final output sent to browser
DEBUG - 2017-09-04 12:18:16 --> Total execution time: 0.1420
ERROR - 2017-09-04 12:18:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-04 12:18:20 --> Config Class Initialized
INFO - 2017-09-04 12:18:20 --> Hooks Class Initialized
DEBUG - 2017-09-04 12:18:20 --> UTF-8 Support Enabled
INFO - 2017-09-04 12:18:20 --> Utf8 Class Initialized
INFO - 2017-09-04 12:18:20 --> URI Class Initialized
INFO - 2017-09-04 12:18:20 --> Router Class Initialized
INFO - 2017-09-04 12:18:20 --> Output Class Initialized
INFO - 2017-09-04 12:18:20 --> Security Class Initialized
DEBUG - 2017-09-04 12:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-04 12:18:20 --> Input Class Initialized
INFO - 2017-09-04 12:18:20 --> Language Class Initialized
INFO - 2017-09-04 12:18:20 --> Loader Class Initialized
INFO - 2017-09-04 12:18:20 --> Controller Class Initialized
INFO - 2017-09-04 12:18:20 --> Database Driver Class Initialized
INFO - 2017-09-04 12:18:20 --> Model Class Initialized
INFO - 2017-09-04 12:18:20 --> Helper loaded: form_helper
INFO - 2017-09-04 12:18:20 --> Helper loaded: url_helper
INFO - 2017-09-04 12:18:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-09-04 12:18:20 --> Model Class Initialized
INFO - 2017-09-04 12:18:20 --> File loaded: C:\xampp\htdocs\mystage\application\views\song_detail.php
INFO - 2017-09-04 12:18:20 --> Final output sent to browser
DEBUG - 2017-09-04 12:18:20 --> Total execution time: 0.1840
ERROR - 2017-09-04 12:22:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\mystage\application\vendor/autoload.php was not found.
INFO - 2017-09-04 12:22:08 --> Config Class Initialized
INFO - 2017-09-04 12:22:08 --> Hooks Class Initialized
DEBUG - 2017-09-04 12:22:08 --> UTF-8 Support Enabled
INFO - 2017-09-04 12:22:08 --> Utf8 Class Initialized
INFO - 2017-09-04 12:22:08 --> URI Class Initialized
INFO - 2017-09-04 12:22:08 --> Router Class Initialized
INFO - 2017-09-04 12:22:08 --> Output Class Initialized
INFO - 2017-09-04 12:22:08 --> Security Class Initialized
DEBUG - 2017-09-04 12:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-04 12:22:08 --> Input Class Initialized
INFO - 2017-09-04 12:22:08 --> Language Class Initialized
INFO - 2017-09-04 12:22:08 --> Loader Class Initialized
INFO - 2017-09-04 12:22:08 --> Controller Class Initialized
INFO - 2017-09-04 12:22:08 --> Database Driver Class Initialized
INFO - 2017-09-04 12:22:08 --> Model Class Initialized
INFO - 2017-09-04 12:22:08 --> Helper loaded: form_helper
INFO - 2017-09-04 12:22:08 --> Helper loaded: url_helper
INFO - 2017-09-04 12:22:08 --> File loaded: C:\xampp\htdocs\mystage\application\views\header.php
INFO - 2017-09-04 12:22:08 --> Model Class Initialized
INFO - 2017-09-04 12:22:08 --> File loaded: C:\xampp\htdocs\mystage\application\views\songs.php
INFO - 2017-09-04 12:22:08 --> Final output sent to browser
DEBUG - 2017-09-04 12:22:08 --> Total execution time: 0.0680
