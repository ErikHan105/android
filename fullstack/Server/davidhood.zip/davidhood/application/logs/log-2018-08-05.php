<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-05 15:38:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-05 15:38:35 --> Config Class Initialized
INFO - 2018-08-05 15:38:35 --> Hooks Class Initialized
DEBUG - 2018-08-05 15:38:35 --> UTF-8 Support Enabled
INFO - 2018-08-05 15:38:35 --> Utf8 Class Initialized
INFO - 2018-08-05 15:38:35 --> URI Class Initialized
DEBUG - 2018-08-05 15:38:35 --> No URI present. Default controller set.
INFO - 2018-08-05 15:38:35 --> Router Class Initialized
INFO - 2018-08-05 15:38:35 --> Output Class Initialized
INFO - 2018-08-05 15:38:35 --> Security Class Initialized
DEBUG - 2018-08-05 15:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-05 15:38:35 --> Input Class Initialized
INFO - 2018-08-05 15:38:35 --> Language Class Initialized
INFO - 2018-08-05 15:38:35 --> Loader Class Initialized
INFO - 2018-08-05 15:38:35 --> Controller Class Initialized
INFO - 2018-08-05 15:38:35 --> Database Driver Class Initialized
INFO - 2018-08-05 15:38:35 --> Model Class Initialized
INFO - 2018-08-05 15:38:35 --> Helper loaded: url_helper
DEBUG - 2018-08-05 15:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-05 15:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-05 15:38:35 --> Model Class Initialized
INFO - 2018-08-05 15:38:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-05 15:38:35 --> Final output sent to browser
DEBUG - 2018-08-05 15:38:35 --> Total execution time: 0.4081
ERROR - 2018-08-05 15:38:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-05 15:38:35 --> Config Class Initialized
INFO - 2018-08-05 15:38:35 --> Hooks Class Initialized
DEBUG - 2018-08-05 15:38:35 --> UTF-8 Support Enabled
INFO - 2018-08-05 15:38:35 --> Utf8 Class Initialized
INFO - 2018-08-05 15:38:35 --> URI Class Initialized
DEBUG - 2018-08-05 15:38:35 --> No URI present. Default controller set.
INFO - 2018-08-05 15:38:35 --> Router Class Initialized
INFO - 2018-08-05 15:38:35 --> Output Class Initialized
INFO - 2018-08-05 15:38:35 --> Security Class Initialized
DEBUG - 2018-08-05 15:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-05 15:38:35 --> Input Class Initialized
INFO - 2018-08-05 15:38:35 --> Language Class Initialized
INFO - 2018-08-05 15:38:35 --> Loader Class Initialized
INFO - 2018-08-05 15:38:35 --> Controller Class Initialized
INFO - 2018-08-05 15:38:35 --> Database Driver Class Initialized
INFO - 2018-08-05 15:38:35 --> Model Class Initialized
INFO - 2018-08-05 15:38:35 --> Helper loaded: url_helper
DEBUG - 2018-08-05 15:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-05 15:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-05 15:38:35 --> Model Class Initialized
INFO - 2018-08-05 15:38:35 --> File loaded: C:\xampp\htdocs\davidhood\application\views\login.php
INFO - 2018-08-05 15:38:35 --> Final output sent to browser
DEBUG - 2018-08-05 15:38:35 --> Total execution time: 0.0474
ERROR - 2018-08-05 15:38:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-05 15:38:39 --> Config Class Initialized
INFO - 2018-08-05 15:38:39 --> Hooks Class Initialized
DEBUG - 2018-08-05 15:38:39 --> UTF-8 Support Enabled
INFO - 2018-08-05 15:38:39 --> Utf8 Class Initialized
INFO - 2018-08-05 15:38:39 --> URI Class Initialized
INFO - 2018-08-05 15:38:39 --> Router Class Initialized
INFO - 2018-08-05 15:38:39 --> Output Class Initialized
INFO - 2018-08-05 15:38:39 --> Security Class Initialized
DEBUG - 2018-08-05 15:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-05 15:38:39 --> Input Class Initialized
INFO - 2018-08-05 15:38:39 --> Language Class Initialized
INFO - 2018-08-05 15:38:39 --> Loader Class Initialized
INFO - 2018-08-05 15:38:39 --> Controller Class Initialized
INFO - 2018-08-05 15:38:40 --> Database Driver Class Initialized
INFO - 2018-08-05 15:38:40 --> Model Class Initialized
INFO - 2018-08-05 15:38:40 --> Helper loaded: url_helper
DEBUG - 2018-08-05 15:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-05 15:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-05 15:38:40 --> Model Class Initialized
ERROR - 2018-08-05 15:38:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-05 15:38:40 --> Config Class Initialized
INFO - 2018-08-05 15:38:40 --> Hooks Class Initialized
DEBUG - 2018-08-05 15:38:40 --> UTF-8 Support Enabled
INFO - 2018-08-05 15:38:40 --> Utf8 Class Initialized
INFO - 2018-08-05 15:38:40 --> URI Class Initialized
INFO - 2018-08-05 15:38:40 --> Router Class Initialized
INFO - 2018-08-05 15:38:40 --> Output Class Initialized
INFO - 2018-08-05 15:38:40 --> Security Class Initialized
DEBUG - 2018-08-05 15:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-05 15:38:40 --> Input Class Initialized
INFO - 2018-08-05 15:38:40 --> Language Class Initialized
INFO - 2018-08-05 15:38:40 --> Loader Class Initialized
INFO - 2018-08-05 15:38:40 --> Controller Class Initialized
INFO - 2018-08-05 15:38:40 --> Database Driver Class Initialized
INFO - 2018-08-05 15:38:40 --> Model Class Initialized
INFO - 2018-08-05 15:38:40 --> Helper loaded: url_helper
DEBUG - 2018-08-05 15:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-05 15:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-05 15:38:40 --> Model Class Initialized
INFO - 2018-08-05 15:38:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-05 15:38:40 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-05 15:38:40 --> Final output sent to browser
DEBUG - 2018-08-05 15:38:40 --> Total execution time: 0.1048
ERROR - 2018-08-05 15:38:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-05 15:38:42 --> Config Class Initialized
INFO - 2018-08-05 15:38:42 --> Hooks Class Initialized
DEBUG - 2018-08-05 15:38:42 --> UTF-8 Support Enabled
INFO - 2018-08-05 15:38:42 --> Utf8 Class Initialized
INFO - 2018-08-05 15:38:42 --> URI Class Initialized
INFO - 2018-08-05 15:38:42 --> Router Class Initialized
INFO - 2018-08-05 15:38:42 --> Output Class Initialized
INFO - 2018-08-05 15:38:42 --> Security Class Initialized
DEBUG - 2018-08-05 15:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-05 15:38:42 --> Input Class Initialized
INFO - 2018-08-05 15:38:42 --> Language Class Initialized
INFO - 2018-08-05 15:38:42 --> Loader Class Initialized
INFO - 2018-08-05 15:38:42 --> Controller Class Initialized
INFO - 2018-08-05 15:38:42 --> Database Driver Class Initialized
INFO - 2018-08-05 15:38:42 --> Model Class Initialized
INFO - 2018-08-05 15:38:42 --> Helper loaded: url_helper
DEBUG - 2018-08-05 15:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-05 15:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-05 15:38:42 --> Model Class Initialized
INFO - 2018-08-05 15:38:42 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-05 15:38:42 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-08-05 15:38:42 --> Final output sent to browser
DEBUG - 2018-08-05 15:38:42 --> Total execution time: 0.0668
ERROR - 2018-08-05 16:53:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-05 16:53:31 --> Config Class Initialized
INFO - 2018-08-05 16:53:31 --> Hooks Class Initialized
DEBUG - 2018-08-05 16:53:31 --> UTF-8 Support Enabled
INFO - 2018-08-05 16:53:31 --> Utf8 Class Initialized
INFO - 2018-08-05 16:53:31 --> URI Class Initialized
INFO - 2018-08-05 16:53:31 --> Router Class Initialized
INFO - 2018-08-05 16:53:31 --> Output Class Initialized
INFO - 2018-08-05 16:53:31 --> Security Class Initialized
DEBUG - 2018-08-05 16:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-05 16:53:31 --> Input Class Initialized
INFO - 2018-08-05 16:53:31 --> Language Class Initialized
INFO - 2018-08-05 16:53:31 --> Loader Class Initialized
INFO - 2018-08-05 16:53:31 --> Controller Class Initialized
INFO - 2018-08-05 16:53:31 --> Database Driver Class Initialized
INFO - 2018-08-05 16:53:31 --> Model Class Initialized
INFO - 2018-08-05 16:53:31 --> Helper loaded: url_helper
DEBUG - 2018-08-05 16:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-05 16:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-05 16:53:31 --> Model Class Initialized
INFO - 2018-08-05 16:53:31 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-05 16:53:31 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-08-05 16:53:31 --> Final output sent to browser
DEBUG - 2018-08-05 16:53:31 --> Total execution time: 0.0585
ERROR - 2018-08-05 16:54:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-05 16:54:06 --> Config Class Initialized
INFO - 2018-08-05 16:54:06 --> Hooks Class Initialized
DEBUG - 2018-08-05 16:54:06 --> UTF-8 Support Enabled
INFO - 2018-08-05 16:54:06 --> Utf8 Class Initialized
INFO - 2018-08-05 16:54:06 --> URI Class Initialized
INFO - 2018-08-05 16:54:06 --> Router Class Initialized
INFO - 2018-08-05 16:54:06 --> Output Class Initialized
INFO - 2018-08-05 16:54:06 --> Security Class Initialized
DEBUG - 2018-08-05 16:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-05 16:54:06 --> Input Class Initialized
INFO - 2018-08-05 16:54:06 --> Language Class Initialized
INFO - 2018-08-05 16:54:06 --> Loader Class Initialized
INFO - 2018-08-05 16:54:06 --> Controller Class Initialized
INFO - 2018-08-05 16:54:06 --> Database Driver Class Initialized
INFO - 2018-08-05 16:54:06 --> Model Class Initialized
INFO - 2018-08-05 16:54:06 --> Helper loaded: url_helper
DEBUG - 2018-08-05 16:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-05 16:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-05 16:54:06 --> Model Class Initialized
INFO - 2018-08-05 16:54:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-05 16:54:06 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-08-05 16:54:06 --> Final output sent to browser
DEBUG - 2018-08-05 16:54:06 --> Total execution time: 0.0549
ERROR - 2018-08-05 16:55:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-05 16:55:26 --> Config Class Initialized
INFO - 2018-08-05 16:55:26 --> Hooks Class Initialized
DEBUG - 2018-08-05 16:55:26 --> UTF-8 Support Enabled
INFO - 2018-08-05 16:55:26 --> Utf8 Class Initialized
INFO - 2018-08-05 16:55:26 --> URI Class Initialized
INFO - 2018-08-05 16:55:26 --> Router Class Initialized
INFO - 2018-08-05 16:55:26 --> Output Class Initialized
INFO - 2018-08-05 16:55:26 --> Security Class Initialized
DEBUG - 2018-08-05 16:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-05 16:55:26 --> Input Class Initialized
INFO - 2018-08-05 16:55:26 --> Language Class Initialized
INFO - 2018-08-05 16:55:26 --> Loader Class Initialized
INFO - 2018-08-05 16:55:26 --> Controller Class Initialized
INFO - 2018-08-05 16:55:26 --> Database Driver Class Initialized
INFO - 2018-08-05 16:55:26 --> Model Class Initialized
INFO - 2018-08-05 16:55:26 --> Helper loaded: url_helper
DEBUG - 2018-08-05 16:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-05 16:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-05 16:55:26 --> Model Class Initialized
INFO - 2018-08-05 16:55:26 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-05 16:55:26 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-08-05 16:55:26 --> Final output sent to browser
DEBUG - 2018-08-05 16:55:26 --> Total execution time: 0.0576
ERROR - 2018-08-05 16:55:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-05 16:55:39 --> Config Class Initialized
INFO - 2018-08-05 16:55:39 --> Hooks Class Initialized
DEBUG - 2018-08-05 16:55:39 --> UTF-8 Support Enabled
INFO - 2018-08-05 16:55:39 --> Utf8 Class Initialized
INFO - 2018-08-05 16:55:39 --> URI Class Initialized
INFO - 2018-08-05 16:55:39 --> Router Class Initialized
INFO - 2018-08-05 16:55:39 --> Output Class Initialized
INFO - 2018-08-05 16:55:39 --> Security Class Initialized
DEBUG - 2018-08-05 16:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-05 16:55:39 --> Input Class Initialized
INFO - 2018-08-05 16:55:39 --> Language Class Initialized
INFO - 2018-08-05 16:55:39 --> Loader Class Initialized
INFO - 2018-08-05 16:55:39 --> Controller Class Initialized
INFO - 2018-08-05 16:55:39 --> Database Driver Class Initialized
INFO - 2018-08-05 16:55:39 --> Model Class Initialized
INFO - 2018-08-05 16:55:39 --> Helper loaded: url_helper
DEBUG - 2018-08-05 16:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-05 16:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-05 16:55:39 --> Model Class Initialized
INFO - 2018-08-05 16:55:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-05 16:55:39 --> File loaded: C:\xampp\htdocs\davidhood\application\views\add_advertisement.php
INFO - 2018-08-05 16:55:39 --> Final output sent to browser
DEBUG - 2018-08-05 16:55:39 --> Total execution time: 0.1126
ERROR - 2018-08-05 16:55:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\davidhood\application\vendor/autoload.php was not found.
INFO - 2018-08-05 16:55:40 --> Config Class Initialized
INFO - 2018-08-05 16:55:40 --> Hooks Class Initialized
DEBUG - 2018-08-05 16:55:40 --> UTF-8 Support Enabled
INFO - 2018-08-05 16:55:40 --> Utf8 Class Initialized
INFO - 2018-08-05 16:55:40 --> URI Class Initialized
INFO - 2018-08-05 16:55:40 --> Router Class Initialized
INFO - 2018-08-05 16:55:40 --> Output Class Initialized
INFO - 2018-08-05 16:55:40 --> Security Class Initialized
DEBUG - 2018-08-05 16:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-05 16:55:40 --> Input Class Initialized
INFO - 2018-08-05 16:55:40 --> Language Class Initialized
INFO - 2018-08-05 16:55:40 --> Loader Class Initialized
INFO - 2018-08-05 16:55:40 --> Controller Class Initialized
INFO - 2018-08-05 16:55:40 --> Database Driver Class Initialized
INFO - 2018-08-05 16:55:40 --> Model Class Initialized
INFO - 2018-08-05 16:55:40 --> Helper loaded: url_helper
DEBUG - 2018-08-05 16:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-05 16:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-05 16:55:40 --> Model Class Initialized
INFO - 2018-08-05 16:55:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\header.php
INFO - 2018-08-05 16:55:41 --> File loaded: C:\xampp\htdocs\davidhood\application\views\advertisement.php
INFO - 2018-08-05 16:55:41 --> Final output sent to browser
DEBUG - 2018-08-05 16:55:41 --> Total execution time: 0.0559
